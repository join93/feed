opkg update
sleep 2;
exit 0
