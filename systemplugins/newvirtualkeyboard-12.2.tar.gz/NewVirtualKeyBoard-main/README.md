NewVirtualKeyBoard [![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0) [![NewVirtualKeyBoard](https://github.com/fairbird/NewVirtualKeyBoard/actions/workflows/NewVirtualKeyBoard.yml/badge.svg)](https://github.com/fairbird/NewVirtualKeyBoard/actions/workflows/NewVirtualKeyBoard.yml)
=========
NewVirtualKeyBoard plugin by (mfaraj57 & RAED) to New VirtualKeyBoard Based on E2iplayer VirtualKeyBoard (Thank's SSS).

To install plugin directly online from telnet be this command ... لتثبيت البلجن مباشرة من خلال الإنترنيت بواسطة التلنت بهذا الأمر
```
wget https://raw.githubusercontent.com/fairbird/NewVirtualKeyBoard/main/installer.sh -O - | /bin/sh
```
This install script for SubsSupport plugin to make compatible with NewVirtualKeyBoard
```
wget https://raw.githubusercontent.com/fairbird/NewVirtualKeyBoard/main/subsinstaller.sh -O - | /bin/sh
```
