import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVQBlh   = "v8.8.0"
VVVU4H    = "16-03-2023"
EASY_MODE    = 0
VVL0kR   = 0
VVMfg0   = 0
VVRjMt  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VV0bR7  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VV90k3    = "/media/usb/"
VVteaw    = "/usr/share/enigma2/picon/"
VVCGMF = "/etc/enigma2/blacklist"
VVWgjG   = "/etc/enigma2/"
VVfn31   = "AJPan"
VV2tYb  = "AUTO FIND"
VVabsf  = "Custom"
VV9iBJ  = None
VVQe5Q    = ""
VV5uhb = "Regular"
VVMCv4 = "Fixed"
VViQwH  = "AJP_Main"
VVqTeW = "AJP_Terminal"
VVXdLX = "AJP_System"
VVoGd5  = VV5uhb
VVw0M8    = ""
VV18Av   = " && echo 'Successful' || echo 'Failed!'"
VVGxSM  = "Cannot continue (No Enough Memory) !"
VVdPa0  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VV6Kiq    = ["KeyMap_RC", "KeyMap_KeyBoard"]
VVnekd  = "utf8"
VVVgKz    = ("-" * 100, )
SEP      = "-" * 80
VVf1FF  = False
VVUwTh  = False
VVhMIG     = 0
VVXu3w    = 1
VV17Kk    = 2
VVIYnp   = 3
VVRmp1    = 4
VV0ab3    = 5
VV07bh = 6
VVzHVs = 7
VV893L  = 8
VV3S9Z   = 9
VVxHqF  = 10
VVwiM3  = 11
VVvzSJ = 12
VVx7nb = 13
VVmMUl = 14
VVxEJp  = 15
VVWtHv    = 16
VVnl3C   = 17
VVzUu4   = 18
VVjSjD    = 19
VV7zQY    = 20
VVuMjv  = 21
VV3ZOe    = 22
VVV4jO   = 0
VVzxgP   = 1
VVlduB   = 2
def FFhFm8():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVoGd5
  if VViQwH in lst and CFG.fontPathMain.getValue(): VVoGd5 = VViQwH
  else               : VVoGd5 = VV5uhb
  return lst
 else:
  return [VV5uhb]
def FFgCge(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVnekd)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VV2tYb, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelectionNumber(default=2, stepwidth=1, min=1, max=5, wraparound=False)
CFG.PIconsPath     = ConfigDirectory(default=VVteaw, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VV90k3, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.lastFindRepl_fnd   = ConfigText(default="")
CFG.lastFindRepl_rpl   = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVoGd5, choices=[(x,  x) for x in FFhFm8()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFM3AM():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVGSxu  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVbY2Y = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVGSxu  : return 0
  elif VVbY2Y : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVLsEj = FFM3AM()
VVJvHF = VVhSN2 = VVWABP = VVWEO1 = VVnviq = VVUVBT = VVEqIl = VV8sRc = VVijSd = VVUrbH = VVWhci = VVfZXg = VVN1ah = VVZoWi = VViTDo = VVoR97 = ""
def FFZCUy()  : FFHb6Y(FFq0eM())
def FFcLcW()  : FFHb6Y(FFGmOF())
def FFH4tQ(tDict): FFHb6Y(iDumps(tDict, indent=4, sort_keys=True))
def FFTYq5(*args): FF2LyJ(True, True, *args)
def FFHb6Y(*args) : FF2LyJ(True , False , *args)
def FF4l5X(*args): FF2LyJ(False, False, *args)
def FF2LyJ(addSep=True, isArray=True, *args):
 if VVL0kR:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFQtFn(fnc):
 def VVoPP8(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFHb6Y(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVoPP8
def FFIQ6Y(*args):
 if VVL0kR:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FF4l5X("Added to : %s" % path)
def FF9ZL0(txt, isAppend=True, ignoreErr=False):
 if VVL0kR:
  tm = FF0lG2()
  err = ""
  if not ignoreErr:
   err = FFGmOF()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFHb6Y(err)
  FFHb6Y("Output Log File : %s" % fileName)
def FFGmOF():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FF0lG2()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFq0eM():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVJ2wA = 0
def FFN0fw():
 global VVJ2wA
 VVJ2wA = iTime()
def FFPSUw(txt=""):
 FFHb6Y(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVJ2wA)).rstrip("0"), txt))
VVNCIL = []
def FFeEwo(win):
 global VVNCIL
 if not win in VVNCIL:
  VVNCIL.append(win)
def FFCuPQ(*args):
 global VVNCIL
 for win in VVNCIL:
  try:
   win.close()
  except:
   pass
 VVNCIL = []
def FFAUiv(vTxt):
 if vTxt in globals(): del globals()[vTxt]
def FFj2E3():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVQkC2 = FFj2E3()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFePNU()    : return PluginDescriptor(fnc=FFyjL5, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFUKbv()      : return getDescriptor(FFFffJ , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFKIar()     : return getDescriptor(FF7hI6  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FF1jcQ()  : return getDescriptor(FFqkK3, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFahql() : return getDescriptor(FFuauH , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFMAhE()  : return getDescriptor(FF8gMM , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFOmpG()  : return getDescriptor(FFfyQ4  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFYdpt()      : return getDescriptor(FFcJMo, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFKIar() , FFUKbv() , FFePNU() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FF1jcQ())
  result.append(FFahql())
  result.append(FFMAhE())
  result.append(FFOmpG())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFYdpt())
 return result
def FFyjL5(reason, **kwargs):
 if reason == 0:
  CCswir.VVT9R8()
  if "session" in kwargs:
   session = kwargs["session"]
   FFxkS0(session)
   CCiNEg(session)
def FFFffJ(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FF7hI6, PLUGIN_NAME, 45)]
 else:
  return []
def FF7hI6(session, **kwargs):
 session.open(Main_Menu)
def FFqkK3(session, **kwargs):
 session.open(CCLyBs)
def FFuauH(session, **kwargs):
 session.open(CCDrYI)
def FF8gMM(session, **kwargs):
 CCTKa3.VV3qn6(session)
def FFfyQ4(session, **kwargs):
 FFtC9K(session, reopen=True)
def FFcJMo(session, **kwargs):
 session.open(CCVNso, fncMode=CCVNso.VV9EG1)
def FFbNeh():
 FF5P3M(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FF1jcQ(), FFahql(), FFMAhE(), FFOmpG() ])
 FF5P3M(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFYdpt() ])
def FF5P3M(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFxkS0(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFaDGk, session, "lok")
 hk.actions["longCancel"]= BF(FFaDGk, session, "lesc")
 hk.actions["longRed"] = BF(FFaDGk, session, "lred")
 for k in (CC0Hnq.VVwZbG, CC0Hnq.VVAbbX, CC0Hnq.VVj5Sh):
  hk.actions[k] = BF(CC0Hnq.VVHZXA, session, k)
def FFaDGk(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCz9Ar.VV4zAf:
    CCz9Ar.VV4zAf.close()
   if not CCTKa3.VVvj2H:
    CCTKa3.VV3qn6(session)
  except:
   pass
def FFSKZx(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFCOTe(SELF, title="", addLabel=False, addScrollLabel=False, VVGIDM=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFpdY0()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VVK1kj = eTimer()
 try: SELF.VVXzsS = SELF.VVK1kj.timeout.connect(BF(FFUuNU, SELF))
 except: SELF.VVK1kj.callback.append(BF(FFUuNU, SELF))
 SELF.onClose.append(SELF.VVK1kj.stop)
 FFUuNU(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCIn9L(SELF)
 if VVGIDM:
  SELF["myMenu"] = MenuList(VVGIDM)
  SELF["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok" : SELF.VVLgni ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(VV6Kiq,
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFIfkB(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFIj7h, SELF, "0"),
  "1" : BF(FFIj7h, SELF, "1"),
  "2" : BF(FFIj7h, SELF, "2"),
  "3" : BF(FFIj7h, SELF, "3"),
  "4" : BF(FFIj7h, SELF, "4"),
  "5" : BF(FFIj7h, SELF, "5"),
  "6" : BF(FFIj7h, SELF, "6"),
  "7" : BF(FFIj7h, SELF, "7"),
  "8" : BF(FFIj7h, SELF, "8"),
  "9" : BF(FFIj7h, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFuNf8, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFIj7h(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVoR97:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVoR97 + SELF.keyPressed + VVhSN2)
    txt = VVhSN2 + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFqgHP(SELF, txt)
def FFuNf8(SELF, tableObj, colNum, isMenu):
 FFqgHP(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFLKj3(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVwPcs(i)
     else  : SELF.VVyaYN(i)
     break
 except:
  pass
def FFpdY0():
 return ("  %s" % VVw0M8)
def FFbJWj(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFLKj3(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFRpt5(color):
 return parseColor(color).argb()
def FFtmqG(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FF21Xy(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFTfvW(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFpC0R(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVoR97)
 else:
  return ""
def FFmeBG(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VVoR97)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FFEK4e(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVoR97
def FFWads(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFpC0R(SEP, VVWhci))
 else : return "echo -e '%s';" % SEP
def FFu7MN(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FFEK4e(title, color)
def FFyjr3(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFiwu1(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFEuIr(fncCB):
 tCons = CCcJGn()
 tCons.ePopen(":", BF(FFeqTs, fncCB))
def FFeqTs(fncCB, result, retval):
 fncCB()
def FFVCur(SELF, fnc, title="Processing ...", clearMsg=True):
 FFqgHP(SELF, title)
 tCons = CCcJGn()
 tCons.ePopen(":", BF(FFPwY3, SELF, fnc, clearMsg))
def FFPwY3(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFqgHP(SELF)
def FFuNwj(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVGxSM
  else       : return ""
def FF30Q2(cmd):
 txt = FFuNwj(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFunaH(cmd):
 lines = FF30Q2(cmd)
 if lines: return lines[0]
 else : return ""
def FFhuUm(SELF, cmd):
 lines = FF30Q2(cmd)
 VVnhmb = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVnhmb.append((key, val))
  elif line:
   VVnhmb.append((line, ""))
 if VVnhmb:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFfJU2(SELF, None, header=header, VVZAt4=VVnhmb, VVbiLs=widths, VVNdFV=28)
 else:
  FFhTGc(SELF, cmd)
def FFyakl(cmd):
 return os.system(FFbUbn(cmd)) == 0
def FFqj03(cmd):
 return os.system(FFCbk8(cmd)) == 0
def FFbUbn(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFCbk8(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFhTGc(    SELF, cmd, **kwargs): SELF.session.open(CCc4FI, VV1Y5G=cmd, VVLf8a=True, VVvR9T=VVzxgP, **kwargs)
def FFoTrM(  SELF, cmd, **kwargs): SELF.session.open(CCc4FI, VV1Y5G=cmd, **kwargs)
def FF0JeX(   SELF, cmd, **kwargs): SELF.session.open(CCc4FI, VV1Y5G=cmd, VVWcUz=True, VVkaA2=True, VVvR9T=VVzxgP, **kwargs)
def FF53hC(  SELF, cmd, **kwargs): SELF.session.open(CCc4FI, VV1Y5G=cmd, VVWcUz=True, VVkaA2=True, VVvR9T=VVlduB, **kwargs)
def FF8jLK(  SELF, cmd, **kwargs): SELF.session.open(CCc4FI, VV1Y5G=cmd, VVX6l4=True , **kwargs)
def FF2Mh6(  session, cmd, **kwargs):      session.open(CCc4FI, VV1Y5G=cmd, VVX6l4=True , **kwargs)
def FFSoHw( SELF, cmd, **kwargs): SELF.session.open(CCc4FI, VV1Y5G=cmd, VVf9w3=True   , **kwargs)
def FFDlYP( SELF, cmd, **kwargs): SELF.session.open(CCc4FI, VV1Y5G=cmd, VVaAu9=True  , **kwargs)
def FFE0hR(cmd):
 return FFyakl("which %s" % cmd)
def FF0tZq():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFunaH(cmd)
def FFRGqa(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VVJwhx     = 0
VVQTjf      = 1
VVH9np   = 2
VVbxJT   = 3
VVRLzP      = 4
VVOU4o      = 5
VVjJTW     = 6
VVmclw     = 7
VVP2Dj     = 8
VV80Ym = 9
VVCu09 = 10
VVhCIY = 11
VVxBkr  = 12
VVNK7J     = 13
VVgFzV  = 14
VVXzTR  = 15
def FFthHn(parmNum, grepTxt):
 if   parmNum == VVJwhx  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVQTjf   : param = ["list"   , "apt list"    ]
 elif parmNum == VVH9np: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVbxJT: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FF0tZq()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFM6zB(parmNum, package):
 if   parmNum == VVRLzP      : param = ["info"      , "apt show"         ]
 elif parmNum == VVOU4o      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVjJTW     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVmclw     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VVP2Dj     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VV80Ym : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVCu09 : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVhCIY : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVxBkr  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVNK7J     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVgFzV  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VVXzTR  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FF0tZq()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFjDBy():
 result = FFunaH("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFM6zB(VVP2Dj, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFbUbn("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFbUbn("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFpC0R(failed1, VVWhci))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFpC0R(failed2, VVWhci))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFpC0R(failed3, VVWABP))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFhXFT(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFM6zB(VVP2Dj , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFbUbn("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFpC0R(failed1, VVWhci))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFpC0R(failed2, VVWABP))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FF3unD(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCme0M.VVDoVu()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FF5p6q(path, keepends=False, maxSize=-1, encLst=None):
 txt = FF3unD(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFJmvd(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFl8II(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FF3unD(path, maxSize=maxSize, encLst=encLst)
  if lines: FFDLqC(SELF, lines, title=title, VVvR9T=VVzxgP, width=1600, height=1000, titleFontSize=30)
  else : FFuRB8(SELF, path, title=title)
 else:
  FFAhcl(SELF, path, title)
def FFog0j(SELF, fName, title):
 path = VV6OO5 + fName
 if fileExists(path):
  txt = FF3unD(path)
  txt = txt.replace("#W#", VVoR97)
  txt = txt.replace("#Y#", VVfZXg)
  txt = txt.replace("#G#", VVhSN2)
  txt = txt.replace("#C#", VVN1ah)
  txt = txt.replace("#P#", VVnviq)
  FFDLqC(SELF, txt, title=title)
 else:
  FFAhcl(SELF, path, title)
def FFh9LG(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFlkVY(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF80Mz(parent)
 else    : return FFYRE0(parent)
def FFlW1I(path):
 return os.path.basename(os.path.normpath(path))
def FFHxsx(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFl8II(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FF31Ce(path):
 path = FFYRE0(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFg1qW(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFPXso(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFbUco(path):
 try: os.remove(path)
 except: pass
def FFjfx9(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFCy5V(path):
 return FFyakl("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFWyyp(path):
 return FFyakl("cp -f '%s' '%s.bak'" % (path, path))
def FF80Mz(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFYRE0(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFHs6q():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVRjMt)
 paths.append(VVRjMt.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFh9LG(ba)
 for p in list:
  p = ba + p + VVRjMt
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VVfn31, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVRjMt, VVfn31 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVBlSs, VV6OO5 = FFHs6q()
def FFZ1EG():
 def VVOmXq(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVpbe3   = VVOmXq(CFG.backupPath, CC6wkq.VVn071())
 VVNWJ2   = VVOmXq(CFG.downloadedPackagesPath, t)
 VVhwez  = VVOmXq(CFG.exportedTablesPath, t)
 VVafWw  = VVOmXq(CFG.exportedPIconsPath, t)
 VVIUAR   = VVOmXq(CFG.packageOutputPath, t)
 global VV90k3
 VV90k3 = FF80Mz(CFG.backupPath.getValue())
 if VVpbe3 or VVIUAR or VVNWJ2 or VVhwez or VVafWw or oldMovieDownloadPath:
  configfile.save()
 return VVpbe3, VVIUAR, VVNWJ2, VVhwez, VVafWw, oldMovieDownloadPath
def FFvxWt(path):
 path = FFYRE0(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFDNgQ(SELF, pathList, tarFileName, addTimeStamp=True):
 VVZAt4 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVZAt4.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVZAt4.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVZAt4.append(path)
 if not VVZAt4:
  FFryuM(SELF, "Files not found!")
 elif not pathExists(VV90k3):
  FFryuM(SELF, "Path not found!\n\n%s" % VV90k3)
 else:
  VVVRme = FF80Mz(VV90k3)
  tarFileName = "%s%s" % (VVVRme, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFOa0m())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVZAt4:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFpC0R(tarFileName, VVijSd))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFpC0R(failed, VVijSd))
  cmd += "fi;"
  cmd +=  sep
  FFoTrM(SELF, cmd)
def FF9NP9(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFLUTg(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFLUTg(SELF["keyInfo"], "info")
def FFLUTg(barObj, fName):
 path = "%s%s%s" % (VV6OO5, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFGaI7(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFhNZa(satNum)
  return satName
def FFhNZa(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFFcgz(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFGaI7(val)
  else  : sat = FFhNZa(val)
 return sat
def FF28st(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFGaI7(num)
 except:
  pass
 return sat
def FFAWqG(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFzMYS(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFXVji(info, iServiceInformation.sServiceref)
   prov = FFXVji(info, iServiceInformation.sProvider)
   state = str(FFXVji(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFkZVp(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFqwVq(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFXVji(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FF1rzp(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FF7smR(refCode):
 info = FFlcpd(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFKVYD(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFQHiZ(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFlcpd(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVXX0J = eServiceCenter.getInstance()
  if VVXX0J:
   info = VVXX0J.info(service)
 return info
def FFnh1l(SELF, refCode, VV5sxe=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFqwVq(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCJVUC()
  if pr.VVgJOf(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVIo5U(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFYdkV(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VV5sxe:
   FF5wFW(SELF, isFromSession)
 try:
  VVIeIC = InfoBar.instance
  if VVIeIC:
   VVTb5M = VVIeIC.servicelist
   if VVTb5M:
    servRef = eServiceReference(refCode)
    VVTb5M.saveChannel(servRef)
 except:
  pass
def FFYdkV(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCJVUC()
    if pr.VVgJOf(refCode, chName, decodedUrl, iptvRef):
     pr.VVIo5U(SELF, isFromSession)
def FFkZVp(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFUkkg(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFHhMF(url): return FFNcCV(url) or FF8I4s(url)
def FFNcCV(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FF8I4s(url): return any(x in url for x in ("/series/", "mode=series"))
def FFqwVq(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFuEJn(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFuEJn(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFO7Oa(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFq8pW(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFxoCd(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFSca3(txt):
 try:
  return FFq8pW(FFxoCd(txt)) == txt
 except:
  return False
def FFqy37(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FF80Mz(newPath), patt))
def FF5wFW(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCTKa3.VV3qn6(session)
 else      : FFtC9K(session, reopen=True)
def FFtC9K(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFtC9K, session), CCz9Ar)
  except:
   try:
    FFF6fE(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFj8UV(refCode):
 tp = CCSMOW()
 if tp.VVYbiE(refCode) : return True
 else        : return False
def FFkDjt(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFWH63(True)
     return True
 return False
def FFWH63(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFRwvu()
def FFRwvu():
 VVIeIC = InfoBar.instance
 if VVIeIC:
  VVTb5M = VVIeIC.servicelist
  if VVTb5M:
   VVTb5M.setMode()
def FFsac0(root, mode=0):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVXX0J = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    flags = service.flags
    if mode == 0 and service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    ref, info = service.toString(), VVXX0J.info(service)
    name = info.getName(service)
    if   mode == 0: lst.append((ref, name))
    elif mode == 1: lst.append((ref, name, flags))
 except:
  pass
 return lst
def FFrYrU():
 VVo54S = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVPs5l = list(VVo54S)
 return VVPs5l, VVo54S
def FFaHKF():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFFCZ1(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFkL2p(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FF2gGN():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFOa0m():
 return FF2gGN().replace(" ", "_").replace("-", "").replace(":", "")
def FFTaUe(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF0lG2():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFgHO0(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCDrYI.VV5ztg(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCDrYI.VVOPP7(fName)
     phpFile = tmpDir + fName + ext
     FFyakl("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFQCNW(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFlPiz(num):
 return "s" if num > 1 else ""
def FFEApF(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFOn9F(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFPzst(a, b):
 return (a > b) - (a < b)
def FFz52H(a, b):
 def VViZW3(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VViZW3(a)
 b = VViZW3(b)
 return (a > b) - (a < b)
def FFkp5b(mycmp):
 class CC5swF(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CC5swF
def FF6mzu(SELF, message, title="", VViIM0=None):
 SELF.session.openWithCallback(VViIM0, CCqeTQ, title=title, message=message, VVijyJ=True)
def FFDLqC(SELF, message, title="", VVvR9T=VVzxgP, VViIM0=None, **kwargs):
 SELF.session.openWithCallback(VViIM0, CCqeTQ, title=title, message=message, VVvR9T=VVvR9T, **kwargs)
def FF4jzU(SELF, txt):
 SELF.session.open(CCmt5Q, txt)
def FFryuM(SELF, message, title="")  : FFF6fE(SELF.session, message, title)
def FFAhcl(SELF, path, title="") : FFF6fE(SELF.session, "File not found !\n\n%s" % path, title)
def FFuRB8(SELF, path, title="") : FFF6fE(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFRzIz(SELF, title="")  : FFF6fE(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFF6fE(session, message, title="") : session.open(BF(CCA7Fu, title=title, message=message))
def FF9Fmo(SELF, VViIM0, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VViIM0, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VViIM0, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFryuM(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFP9Be(SELF, callBack_Yes, VVcsne, callBack_No=None, title="", VVi1cr=False, VVfGaL=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFGGYs, callBack_Yes, callBack_No)
         , BF(CC3lLL, title=title, VVcsne=VVcsne, VVfGaL=VVfGaL, VVi1cr=VVi1cr))
def FFGGYs(callBack_Yes, callBack_No, FFP9Beed):
 if FFP9Beed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFqgHP(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FF21Xy(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VVK1kj.start(timeout, True)
  except: pass
 else: FFUuNU(SELF)
def FFe82w(*kargs, **kwargs):
 FFEuIr(BF(FFqgHP, *kargs, **kwargs))
def FFUuNU(SELF):
 try:
  SELF.VVK1kj.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFaIEn(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFfJU2(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CC5cb1, **kwargs))
  else   : win = SELF.session.open(BF(CC5cb1, **kwargs))
  FFeEwo(win)
  return win
 except:
  return None
def FFzctu(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CC1wtj, **kwargs))
 FFeEwo(win)
 return win
def FFBeKw(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFzUJ4(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFNmLy(SELF, **kwargs):
 SELF.session.open(CCVNso, **kwargs)
def FFOuQx(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFuM3s(SELF[name], "#000000", 3)
  except:
   pass
def FFuM3s(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFfD2k(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVoGd5, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFkK1B(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFfD2k(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFChi8(SELF, winSize.width(), winSize.height())
def FFChi8(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFiI6j():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FF0QHc(VVNdFV):
 screenSize  = FFiI6j()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVNdFV)
 return bodyFontSize
def FFn3C3(VVNdFV, extraSpace):
 font = gFont(VVoGd5, VVNdFV)
 VVN35T = fontRenderClass.getInstance().getLineHeight(font) or (VVNdFV * 1.25)
 return int(VVN35T + VVN35T * extraSpace)
def FFLEcJ(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFiI6j()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVoGd5, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFn3C3(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVoGd5, titleFontSize, alignLeftCenter)
 if winType in (VVhMIG, VVXu3w):
  if winType == VVXu3w : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVuMjv:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VV7zQY:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVoGd5, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVWtHv:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF6mzuL = b2Left2 + timeW + marginLeft
  FF6mzuW = b2Left3 - marginLeft - FF6mzuL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF6mzuL , b2Top, FF6mzuW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVnl3C:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVRmp1:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VV17Kk:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVIYnp:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVoGd5, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVoGd5, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVxHqF:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVoGd5, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVzUu4:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVoGd5, fontH, alignCenter)
 elif winType in (VVwiM3, VVvzSJ, VVx7nb, VVmMUl, VVxEJp):
  if   winType == VVwiM3  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVvzSJ : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVx7nb : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VVmMUl : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVwiM3:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVoGd5, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVoGd5, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVoGd5, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVoGd5, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVoGd5, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVoGd5, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVoGd5, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVjSjD:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VV0ab3:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVzHVs : align = alignLeftCenter
  elif winType == VV07bh : align = alignLeftTop
  else          : align = alignCenter
  if winType == VV3S9Z:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVoGd5
  if usefixedFont and winType == VV07bh:
   fLst = FFhFm8()
   if   VVqTeW in fLst and CFG.fontPathTerm.getValue(): fontName = VVqTeW
   elif VVMCv4 in fLst         : fontName = VVMCv4
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVNdFV = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVoGd5, VVNdFV, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVoGd5, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVdPa0[i], VVoGd5, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VV07bh:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVdPa0[i], VVoGd5, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 800, 1000, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVv294 = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVQBlh)
  VVGIDM = []
  if VVMfg0:
   VVGIDM.append(("-- MY TEST --", "myTest" ))
  VVGIDM.append(("File Manager"  , "fMan" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("IPTV"    , "iptv" ))
  VVGIDM.append(("Movies Browser" , "movie" ))
  VVGIDM.append(("Services/Channels", "chan" ))
  VVGIDM.append(("Bouquet Editor" , "bouq" ))
  VVGIDM.append(("PIcons"   , "picon" ))
  VVGIDM.append(("EPG"    , "epg"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Terminal"   , "term" ))
  VVGIDM.append(("SoftCam"   , "soft" ))
  VVGIDM.append(("Plugins"   , "plug" ))
  VVGIDM.append(("Backup & Restore" , "bakup" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Date/Time"  , "date" ))
  VVGIDM.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVGIDM):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVGIDM[ndx] = tuple(item)
  FFCOTe(self, title=self.Title, VVGIDM=VVGIDM)
  FFbJWj(self["keyRed"] , "Exit")
  FFbJWj(self["keyGreen"] , "Settings")
  FFbJWj(self["keyYellow"], "Dev. Info.")
  FFbJWj(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVKBA6      ,
   "yellow": self.VVZKQr      ,
   "blue" : self.VVPGTb     ,
   "info" : BF(FFVCur, self, self.VVXoVh) ,
   "text" : self.VVtfyf      ,
   "menu" : self.VVKM4p    ,
   "0"  : BF(self.VVI8yp, 0)   ,
   "1"  : BF(self.VVETXS, "fMan")   ,
   "2"  : BF(self.VVETXS, "iptv")   ,
   "3"  : BF(self.VVETXS, "movie")   ,
   "4"  : BF(self.VVETXS, "chan")   ,
   "5"  : BF(self.VVETXS, "bouq")   ,
   "6"  : BF(self.VVETXS, "picon")   ,
   "7"  : BF(self.VVETXS, "epg")   ,
   "8"  : BF(self.VVETXS, "term")   ,
   "9"  : BF(self.VVETXS, "soft")   ,
   "last" : BF(self.VVETXS, "plug")   ,
   "next" : BF(self.VVETXS, "bakup")
  })
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
  global VVf1FF, VVUwTh, VVzKlk
  VVf1FF = VVUwTh = False
  VVzKlk = True
 def VVLgni(self):
  self.VVETXS(self["myMenu"].l.getCurrentSelection()[1])
 def VVETXS(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVw0M8
   VVw0M8 = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVl9VT()
   elif item == "fMan"  : self.session.open(CCLyBs)
   elif item == "iptv"  : self.session.open(CCDrYI)
   elif item == "movie" : FFVCur(self, BF(CCKJ5i.VV8mMe, self))
   elif item == "chan"  : self.session.open(CCTc7M)
   elif item == "bouq"  : self.session.open(CCT3R4)
   elif item == "picon" : self.VVTK6q()
   elif item == "epg"  : self.session.open(CCgL5j)
   elif item == "term"  : self.session.open(CCrHuk)
   elif item == "soft"  : self.session.open(CCgegl)
   elif item == "plug"  : self.session.open(CCiRwv)
   elif item == "bakup" : self.session.open(CC7Vv3)
   elif item == "date"  : self.session.open(CCUPpf)
   elif item == "net"  : self.session.open(CCVOkN)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
  FFOuQx(self)
  FF9NP9(self)
  VVpbe3, VVIUAR, VVNWJ2, VVhwez, VVafWw, oldMovieDownloadPath = FFZ1EG()
  if VVpbe3 or VVIUAR or VVNWJ2 or VVhwez or VVafWw or oldMovieDownloadPath:
   VVR7gd = lambda path, subj: "%s:\n%s\n\n" % (subj, FFEK4e(path, VVWEO1)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVR7gd(VVpbe3   , "Backup/Restore Path"    )
   txt += VVR7gd(VVIUAR  , "Created Package Files (IPK/DEB)" )
   txt += VVR7gd(VVNWJ2  , "Download Packages (from feeds)" )
   txt += VVR7gd(VVhwez , "Exported Tables"     )
   txt += VVR7gd(VVafWw , "Exported PIcons"     )
   txt += VVR7gd(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFDLqC(self, txt, title="Settings Paths")
  self.VVWxqh()
  if (EASY_MODE or VVL0kR or VVMfg0):
   FF21Xy(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFqgHP(self, "Welcome", 300)
  FFEuIr(self.VV76Qa)
 def VV76Qa(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CC6wkq.VVpV62()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFyakl("rm -f /tmp/ajp_*")
  global VVf1FF, VVUwTh
  VVf1FF = VVUwTh = False
  FFAUiv("VVzKlk")
 def VVI8yp(self, digit):
  self.VVv294 += str(digit)
  ln = len(self.VVv294)
  global VVf1FF
  if ln == 4:
   if self.VVv294 == "0" * ln:
    VVf1FF = True
    FF21Xy(self["myTitle"], "#11805040")
   else:
    self.VVv294 = "x"
 def VVtfyf(self):
  self.VVv294 += "t"
  if self.VVv294 == "0" * 4 + "t" * 2:
   global VVUwTh
   VVUwTh = True
   FF21Xy(self["myTitle"], "#dd5588")
 def VVTK6q(self):
  found = False
  pPath = CC9p8T.VVH8Sz()
  if pathExists(pPath):
   for fName, fType in CC9p8T.VVCByH(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CC9p8T)
  else:
   VVGIDM = []
   VVGIDM.append(("PIcons Tools" , "CC9p8T" ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(CC9p8T.VVav9G())
   VVGIDM.append(VVVgKz)
   VVGIDM += CC9p8T.VVa1SJ()
   FFzctu(self, self.VVu4Wq, VVGIDM=VVGIDM)
 def VVu4Wq(self, item=None):
  if item:
   if   item == "CC9p8T"   : self.session.open(CC9p8T)
   elif item == "VVxrMA"  : CC9p8T.VVxrMA(self)
   elif item == "VVxnFU"  : CC9p8T.VVxnFU(self)
   elif item == "findPiconBrokenSymLinks" : CC9p8T.VVOBbh(self, True)
   elif item == "FindAllBrokenSymLinks" : CC9p8T.VVOBbh(self, False)
 def VVXoVh(self):
  changeLogFile = VV6OO5 + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FF5p6q(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFEK4e("\n%s\n%s\n%s" % (SEP, line, SEP), VVWhci, VVoR97)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFEK4e(line, VVhSN2, VVoR97)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFDLqC(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVQBlh, PLUGIN_DESCRIPTION), VVNdFV=28, width=1600, height=1000, VVasam="#11000011")
 def VVKM4p(self):
  VVGIDM = []
  VVGIDM.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Keys Help"     , "hlp" ))
  FFzctu(self, self.VVY6Tc, VVGIDM=VVGIDM, width=650, title="Options")
 def VVY6Tc(self, item=None):
  if item:
   if   item == "libr" : FFVCur(self, BF(self.VV1hxj))
   elif item == "hlp" : FFog0j(self, "_help_main", "Main Page (Keys Help)")
 def VVKBA6(self) : self.session.open(CC6wkq)
 def VVZKQr(self) : self.session.open(CC1Nwg)
 def VVPGTb(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVUrbH, VVWEO1, VVfZXg, VVUVBT
  VVGIDM = []
  VVGIDM.append((c1 + "Change Title Colors"   , "title"  ))
  VVGIDM.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVGIDM.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVGIDM.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVGIDM.append((c2 + "Reset Colors"    , "resetColor" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVGIDM.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c4 + "Change System Font"    , "sysFont"  ))
  FFzctu(self, BF(self.VVLb59, title), VVGIDM=VVGIDM, width=600, title=title)
 def VVLb59(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVpcXz()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVBJrm, tDict, item), CC8Pjn, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFP9Be(self, self.VV6aFG, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVdM2Z(VViQwH  )
   elif item == "termFont"  : self.VVdM2Z(VVqTeW)
   elif item == "sysFont"  : self.VVdM2Z(VVXdLX  )
 def VV1hxj(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVnhmb, pkgs = self.VVp7Ul()
  VVoXaA = ("Install", BF(self.VVxDfB, title, pkgs)  , [])
  VVUm5B  = ("Update Sys. Packages", self.VVQ3xv , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVyaAW = (LEFT  , CENTER , LEFT  )
  VVxL8T = FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=28, width=1350, VVoXaA=VVoXaA, VVUm5B=VVUm5B, VVPYhe="#00ffffaa", VV4wMI=1)
 def VVxDfB(self, Title, pkgs, VVxL8T, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVYJvY, VVxL8T)
   item = colList[0]
   if   item == "requests" : CCOnT0.VVqlCJ(self, cbFnc=cbFnc)
   elif item == "Imaging" : CC0Hnq.VVi4Av(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FF8jLK(self, FFjDBy(), VVZgJA=cbFnc)
   elif item in pkgs  : FF8jLK(self, FFhXFT(item, item, item.capitalize()), VVZgJA=cbFnc)
  else:
   FFqgHP(VVxL8T, "Already installed.", 700, isGrn=True)
 def VVQ3xv(self, VVxL8T, title, txt, colList):
  CCiRwv.VVTsh3(self)
 def VVYJvY(self, VVxL8T):
  VVnhmb, pkgs = self.VVp7Ul()
  VVxL8T.VVkQYa(VVnhmb[VVxL8T.VVsf2R()])
 def VVp7Ul(self):
  tDict = {}
  path = VV6OO5 + "_sup_lib"
  if fileExists(path):
   for line in FF5p6q(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVR7gd(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFEK4e("Installed", VVijSd), txt)
   else : return (lib, FFEK4e("Not installed", VVWABP), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVnhmb = []
  VVnhmb.append(VVR7gd("requests", CCOnT0.VVqlCJ(self, install=False)))
  VVnhmb.append(VVR7gd("Imaging" , CC0Hnq.VVi4Av(self, "", False, install=False)))
  VVnhmb.append(VVR7gd("ar"   , FFyakl("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for item in pkgs: VVnhmb.append(VVR7gd(item, FFE0hR(item)))
  VVnhmb.sort(key=lambda x: x[0].lower())
  return VVnhmb, pkgs
 def VVhMYh(self):
  return VV90k3 + "ajpanel_colors"
 def VVpcXz(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVhMYh()
  if fileExists(p):
   txt = FF3unD(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVBJrm(self, tDict, item, fg, bg):
  if fg:
   self.VV56vZ(item, fg)
   self.VV9UqQ(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVziR0(tDict)
 def VVziR0(self, tDict):
   p = self.VVhMYh()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VV56vZ(self, item, fg):
  if   item == "title" : FFtmqG(self["myTitle"], fg)
  elif item == "body"  :
   FFtmqG(self["myMenu"], fg)
   FFtmqG(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFtmqG(self[item], fg)
 def VV9UqQ(self, item, bg):
  if   item == "title" : FF21Xy(self["myTitle"], bg)
  elif item == "body"  :
   FF21Xy(self["myMenu"], bg)
   FF21Xy(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FF21Xy(self["myBar"], bg)
 def VV6aFG(self):
  FFyakl("rm '%s'" % self.VVhMYh())
  self.close()
 def VVWxqh(self):
  tDict = self.VVpcXz()
  for item in ("title", "body", "cursor", "bar"):
   self.VVc4wb(tDict, item)
 def VVc4wb(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VV56vZ(name, fg)
  if bg: self.VV9UqQ(name, bg)
 def VVdM2Z(self, which):
  if   which == VViQwH  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVqTeW : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVXdLX  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CCzUL4.VVHiJu(self, "Change %s Font" % title, defFnt, rest, BF(self.VVku5Z, which))
 def VVku5Z(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VViQwH  : FFSKZx(CFG.fontPathMain, path)
   elif which == VVqTeW: FFSKZx(CFG.fontPathTerm, path)
   elif which == VVXdLX  : FFSKZx(CFG.fontPathSys , path)
   err = Main_Menu.VVP2q8(which)
   if err          : FFryuM(self, err, title=title)
   elif which == VViQwH   : self.close()
   elif which == VVqTeW  : FFqgHP(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVXdLX and path: FFqgHP(self, "System font applied", 1500, isGrn=True)
   elif which == VVXdLX   : FFP9Be(self, BF(Main_Menu.VVf9w3, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVf9w3(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVP2q8(name):
  if   name == VViQwH : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVqTeW: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVXdLX : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFhFm8()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVXdLX:
   nameLst = []
   for nm in FFhFm8():
    if not nm in (VViQwH, VVqTeW):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFgCge(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFhFm8()
  else    : return "Could not add font"
 def VVl9VT(self):
  self.session.open(CCT3R4)
class CCVOkN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VV90k3, "ajpanel_network")
  c1, c2 = VVfZXg, VVUrbH
  VVGIDM = []
  VVGIDM.append((c1 + "Network Devices"     , "dev" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Network Scanner (ping)"    , "ping"))
  VVGIDM.append(("Port Scanner (scan for famous ports)" , "port"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c2 + "Check Internet Connection"  , "intr"))
  FFCOTe(self, title="Network Tools", VVGIDM=VVGIDM)
  FFCOTe(self, VVGIDM=VVGIDM)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFVCur(self, self.VVp9Nm, title="REading Devices ...")
  elif item == "ping" : FFVCur(self, self.VVAo7v, title="Scanning ...")
  elif item == "port" : CCXzSR.VVsV73(self, self.VVgC4a, title="Select host to scan")
  elif item == "intr" : self.session.open(CCAtLz)
 def VVp9Nm(self, canCencel=False):
  title = "Network Devices"
  VVnhmb = self.VVVCRX()
  if VVnhmb:
   bg = "#0a223333"
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVU1op = BF(self.VVh88m, canCencel)
   VVRWOd  = ("Start FTP"   , self.VVUo7B    , [])
   VVMCbu = ("Entry Options"  , self.VV6w9G  , [])
   VVUm5B = ("Scan for Devices" , self.VV5tBL , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVyaAW = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVxL8T = FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, width=1500, height=900, VVbiLs=widths, VVNdFV=28, VVRWOd=VVRWOd, VVU1op=VVU1op, VVMCbu=VVMCbu, VVUm5B=VVUm5B
       , VVXsDY=bg, VVEEoV=bg, VVasam=bg, VVPYhe="#11ffff00", VVhaQs="#11220000", VVAXDQ="#00333333", VVilD4="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVxL8T.VVyaYN(ndx)
  else:
   FFP9Be(self, BF(FFVCur, self, BF(self.VVg9rr, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVh88m, canCencel), title=title)
 def VV6w9G(self, VVxL8T, title, txt, colList):
  VVGIDM = []
  VVGIDM.append(("Change Username"   , "user"))
  VVGIDM.append(("Change Password"   , "pass"))
  VVGIDM.append(("Change Remarks"   , "rem"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Remove Selected Server" , "del"))
  FFzctu(self, BF(self.VVHAnq, VVxL8T), VVGIDM=VVGIDM, title="Entry Options")
 def VVHAnq(self, VVxL8T, item=None):
  if item:
   if   item == "user" : self.VV62s5("u", VVxL8T)
   elif item == "pass" : self.VV62s5("p", VVxL8T)
   elif item == "rem" : self.VV62s5("r", VVxL8T)
   elif item == "del" : FFP9Be(self, BF(FFVCur, self, BF(self.VVo1L8, VVxL8T), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVh88m(self, canCencel, VVxL8T=None):
  if VVxL8T: VVxL8T.cancel()
  if canCencel : self.close()
 def VVUo7B(self, VVxL8T, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFSKZx(CFG.lastNetworkDevice, VVxL8T.VVsf2R())
  self.session.openWithCallback(BF(self.VV8LVS, entry, VVxL8T), CCyAri, entry)
 def VV8LVS(self, entry, VVxL8T, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VV5EbI("d", newPath, ip, u, p, path, rem)
    self.VV3JZA(VVxL8T)
 def VV5tBL(self, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVg9rr, mainTableInst=VVxL8T), title="Scanning Network ...")
 def VVg9rr(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCXzSR.VV73Gw(CCXzSR.VVD21A)
  if err:
   FFryuM(self, err, title=title)
   return
  telLst, err = CCXzSR.VV73Gw(CCXzSR.VVLXHj)
  if err:
   FFryuM(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVLEC4(p1, p2): return FFz52H(p1[0], p2[0])
   lst.sort(key=FFkp5b(VVLEC4))
   bg = "#0a202020"
   VVU1op = BF(self.VVh88m, canCencel)
   VVRWOd  = ("Add to Devices" , BF(self.VVCXC0, mainTableInst, canCencel), [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVyaAW = (LEFT   , CENTER  , CENTER  )
   FFfJU2(self, None, title=title, header=header, VVZAt4=lst, VVyaAW=VVyaAW, VVbiLs=widths, width=1200, VVNdFV=30, VVRWOd=VVRWOd, VVU1op=VVU1op, VV4wMI=2
     , VVXsDY=bg, VVEEoV=bg, VVasam=bg, VVhaQs="#0a225555", VVilD4="#11403040")
  else:
   FFryuM(self, "No devices found !", title=title)
 def VVAo7v(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCXzSR.VV73Gw(-1)
  if err:
   FFryuM(self, err, title=title)
  elif lst:
   def VVLEC4(p1, p2): return FFz52H(p1[0], p2[0])
   lst.sort(key=FFkp5b(VVLEC4))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVyaAW = (LEFT   , LEFT   )
   FFfJU2(self, None, title=title, header=header, VVZAt4=lst, VVyaAW=VVyaAW, VVbiLs=widths, width=1000, height=700, VVNdFV=30
     , VVXsDY=bg, VVEEoV=bg, VVasam=bg, VVhaQs="#0a225555", VVilD4="#11403040")
  else:
   FFryuM(self, "Network scanning failed !", title=title)
 def VVgC4a(self, ip=None):
  if ip:
   FFVCur(self, BF(self.VVrjSE, ip), title="Scanning %s" % ip)
 def VVrjSE(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCXzSR.VV7rSy(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCXzSR.VVqWp3(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFDLqC(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVVCRX(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FF3unD(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVLEC4(p1, p2): return FFz52H(p1[0], p2[0])
  tLst.sort(key=FFkp5b(VVLEC4))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVVCRX(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FF3unD(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVLEC4(p1, p2): return FFz52H(p1[0], p2[0])
  tLst.sort(key=FFkp5b(VVLEC4))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVCXC0(self, mainTableInst, canCencel, VVxL8T, title, txt, colList):
  ip, mac, typ = VVxL8T.VVtH1g(VVxL8T.VVsf2R())
  if "Own" in ip:
   FFqgHP(VVxL8T, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVVCRX():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FFjfx9(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVfKw6(ip, u, p, path, rem))
   if mainTableInst: self.VV3JZA(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVp9Nm(canCencel)
   VVxL8T.cancel()
 def VVfKw6(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVo1L8(self, VVxL8T):
  num, ip, u, p, path, rem = VVxL8T.VVtH1g(VVxL8T.VVsf2R())
  lst = self.VVVCRX()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVfKw6(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VV3JZA(VVxL8T)
  else:
   VVxL8T.cancel()
 def VV62s5(self, col, VVxL8T):
  num, ip, u, p, path, rem = VVxL8T.VVtH1g(VVxL8T.VVsf2R())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FF9Fmo(self, BF(self.VVUgSR, col, orig, VVxL8T, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVUgSR(self, col, orig, VVxL8T, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFqgHP(VVxL8T, "No change", 1500)
   elif not newTxt and col == "u":
    FFqgHP(VVxL8T, "No user !", 2000)
   else:
    self.VV5EbI(col, newTxt, ip, u, p, path, rem)
    self.VV3JZA(VVxL8T)
 def VV5EbI(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVVCRX()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVfKw6(ip1, u1, p1, path1, rem1))
 def VV3JZA(self, VVxL8T, newEntry=None):
  VVnhmb = self.VVVCRX()
  if VVnhmb : VVxL8T.VVlCGq(VVnhmb, tableRefreshCB=BF(self.VVRBeB, newEntry))
  else  : VVxL8T.cancel()
 def VVRBeB(self, newEntry, VVxL8T, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVxL8T.VVWcfU()):
    if row[1:] == newEntry:
     VVxL8T.VVyaYN(ndx)
 def VVh88m(self, canCencel, VVxL8T=None):
  if VVxL8T: VVxL8T.cancel()
  if canCencel : self.close()
class CCXzSR():
 VVD21A = 21
 VVLXHj = 23
 def __init__(self):
  self.VVLrEl()
 def VVLrEl(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVuLCA(self, ip, User, Pass, timeout=5):
  myIp = CCXzSR.VVGZ8y()
  if ip != myIp:
   if CCXzSR.VVqWp3(ip, CCXzSR.VVD21A):
    self.VVLrEl()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVnXIJ(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVIvW9(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVOE84(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVIvW9()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VV0QSl(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVsO7T(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVrHuB(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VV6S1w(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVDizJ(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VV6S1w()
   if self.VVrHuB(path) : typ = "d"
   else      : typ = "b"
   self.VVrHuB(curDir)
   return typ
 def VVwcVk(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVrHuB(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVvXKS(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVXMgz(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVEQEF(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVJ1Wd(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVwcVk(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFbUco(locFile)
   return "", sz, str(e)
 def VVO9tN(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVLrEl()
 @staticmethod
 def VVS0Ai():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VVGZ8y():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVlGww():
  myIp = CCXzSR.VVGZ8y()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVFEix():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFunaH("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVf8Oq(port=-1):
  lst = []
  def VVh9t0(ip):
   if port > -1: ok = CCXzSR.VVqWp3(ip, port)
   else  : ok = CCXzSR.VV7rSy(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCXzSR.VVlGww()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVh9t0, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VV73Gw(port):
  myIp = CCXzSR.VVGZ8y()
  myGw = CCXzSR.VVFEix()
  tDict = { myIp: CCXzSR.VVS0Ai() }
  devLst, err = CCXzSR.VVf8Oq(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFuNwj("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVfZXg
    elif key == myGw: txt = " %s Gateway" % VVfZXg
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VV7rSy(ip):
  return FFyakl("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVqWp3(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVGqI0(ip="1.1.1.1", timeout=1):
  if CCXzSR.VVqWp3(ip, 53, timeout):
   return True
  if CCXzSR.VV7rSy(ip):
   return True
  return FFyakl("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVsV73(SELF, okFnc, title):
  baseIp = CCXzSR.VVlGww()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFzctu(SELF, okFnc, VVGIDM=lst, width=600, title=title, VVXsDY="#222222", VVEEoV="#222222")
class CCyAri(Screen, CCXzSR):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVNdFV  = self.skinParam["bodyFontSize"]
  self.VVN35T  = self.skinParam["bodyLineH"]
  self.VVZa0q  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CC8QHN.VV8n8R("fil")
  self.png_dir  = CC8QHN.VV8n8R("dir")
  self.png_dirup  = CC8QHN.VV8n8R("dirup")
  self.png_slwfil  = CC8QHN.VV8n8R("slwfil")
  self.png_slbfil  = CC8QHN.VV8n8R("slbfil")
  self.png_slwdir  = CC8QHN.VV8n8R("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCXzSR.__init__(self)
  VVGIDM = [("Item-%d" % x,) for x in range(50)]
  FFCOTe(self, title=self.Title, VVGIDM=VVGIDM)
  FFbJWj(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVGIDM, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVoGd5, self.VVNdFV))
  self["myMenu"].l.setItemHeight(self.VVN35T)
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "red" : BF(self.VV3q1m, True) ,
   "ok" : self.VVLgni    ,
   "cancel": self.VV3q1m    ,
   "menu" : self.VVjVpw   ,
   "info" : self.VVvGUD  ,
   "pageUp": self.VV6dxL    ,
   "chanUp": self.VV6dxL
  })
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVAFaL)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
  FFOuQx(self)
  FF9NP9(self)
  FF21Xy(self["keyBlue"], "#11333333")
  FFVCur(self, self.VVzgBF, title="Connecting ...")
 def VVzgBF(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVuLCA(ip, u, p)
  if err:
   FFryuM(self, err, title=self.Title)
   FFbJWj(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFbJWj(self["keyBlue"], self.ftpIp)
   if not self.VVrHuB(path):
    path = "/"
   self.VVi6Ry(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVIvW9():
   self.VVO9tN()
 def VVLgni(self):
  if self.VVqD17():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVi6Ry(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VV6dxL()
    else         : self.VVB2ud(os.path.join(self.curDir, name))
 def VV3q1m(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VV6dxL()
 def VVqD17(self):
  if self.VVIvW9():
   return True
  else:
   FFryuM(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVB2ud(self, path):
  cat = self.VV1378(path)
  if cat in ("pic"):
   FFVCur(self, BF(self.VVR6tY, path))
  elif cat in ("mov", "mus"):
   if CCDrYI.VVGemA("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFVCur(self, BF(CCLyBs.VVKTM4, self, url, rType=rType), title="Playing Media ...")
 def VVR6tY(self, path):
  locFile, size, err = self.VVJ1Wd(path)
  if err: FFryuM(self, err, title="View Picture File")
  else  : CCceHb.VVLNYv(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFbUco))
 def VVAFaL(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CC8QHN.VV49i1 else sel[0][0])
  else  : title=  VVWABP + "  No Files Found !"
  self["myTitle"].setText(title)
 def VV6dxL(self):
  if self.VVqD17():
   lastPart = FFlW1I(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVi6Ry(parentDir, lastPart, "d")
 def VVi6Ry(self, Dir, moveTo="", moveToType=""):
  FFVCur(self, BF(self.VVfVb7, Dir, moveTo, moveToType))
 def VVfVb7(self, Dir, moveTo, moveToType):
  files, err = self.VVsO7T(Dir, isLong=True)
  self.curDir = self.VV6S1w() or "/"
  self.VVaIdD(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VVaIdD(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVQBF9(CC8QHN.VV49i1, CC8QHN.VV49i1, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVDizJ(target)
    color = VVWABP if targetState == "b" else VVijSd
    origName = name + VVWhci + linkSep + color + " "+ target
   self.list.append(self.VVQBF9(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVQBF9(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VV1378(name)
    if cat: png = LoadPixmap("%s%s.png" % (VV6OO5, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CC8QHN.VV49i1: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVN35T + 10, 0, self.VVZa0q, self.VVN35T, 0, LEFT | RT_VALIGN_CENTER, origName))
  tableRow.append(CC5cb1.VVecW5(0, 2, self.VVN35T-4, self.VVN35T-4, png))
  return tableRow
 def VV1378(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CC8QHN.VVzGQB().items():
    if ext in lst:
     return cat
  return ""
 def VVjVpw(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CC8QHN.VV49i1
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VV84H0(titl, ref, chk, color=""):
   if chk: return VVGIDM.append((color + titl, ref))
   else  : return VVGIDM.append((titl, ))
  VVGIDM = []
  VV84H0("Properties", "VVvGUD", not isTop)
  c = VVfZXg
  VVGIDM.append(VVVgKz)
  VV84H0("Download Selected File ..."    , "FFgHO0FromServer", isFile, c)
  VV84H0("Upload a Local File to Remote Server ...", "VVgJEj" , True  , c)
  VVGIDM.append(VVVgKz)
  VV84H0("Create new directory", "VV9iUM", True)
  VV84H0("Rename", "VVeocx", not isTop)
  VV84H0("DELETE", "VVzDfd", not isTop, VVnviq)
  VVGIDM.append(VVVgKz)
  VV84H0("FTP Server Information", "VVeytH", True)
  VVGIDM.append(VVVgKz)
  VV84H0("Refresh File List", "refresh", True)
  FFzctu(self, self.VVSDUf, VVGIDM=VVGIDM, title="Options")
 def VVSDUf(self, item=None):
  if item:
   if   item == "VVvGUD"     : self.VVvGUD()
   elif item == "FFgHO0FromServer"   : self.FFgHO0FromServer()
   elif item == "VVgJEj"   : self.VVgJEj()
   elif item == "VV9iUM"   : self.VV9iUM()
   elif item == "VVeocx"   : self.VVeocx()
   elif item == "VVzDfd"   : self.VVzDfd()
   elif item == "VVeytH"    : self.VVeytH()
   elif item == "refresh"and self.VVqD17() : self.VVi6Ry(self.curDir)
 def VVvGUD(self):
  if self.VVqD17():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFEK4e("Path", VVfZXg), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVwcVk(path)
    if sz > -1: txt += "Size\t: %s" % CCLyBs.VVM24t(sz)
   else:
    txt = "Nothing selected"
   FFDLqC(self, txt, title="Properties")
 def VVeytH(self):
  if self.VVqD17():
   Sys  = self.VVnXIJ() or " -"
   txt = "%s\n  %s\n\n" % (FFEK4e("System:", VVfZXg), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VV0QSl() or " -"
   txt += "%s\n" % (FFEK4e("Status:", VVfZXg))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFDLqC(self, txt, title="FTP Server Information")
 def VV9iUM(self, name=""):
  if self.VVqD17():
   title = "Add New Directory"
   FF9Fmo(self, BF(self.VVXM8V, title), defaultText=name, title=title, message="Enter Directory name")
 def VVXM8V(self, title, name):
  if name and name.strip():
   if self.VVvXKS(name) : self.VVi6Ry(self.curDir, name, "d")
   else     : FFryuM(self, "Failed to create : %s" % name, title)
 def VVeocx(self):
  if self.VVqD17():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FF9Fmo(self, BF(self.VV05O8, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VV05O8(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVEQEF(name, newName.strip()) : self.VVi6Ry(self.curDir, newName, flag)
   else          : FFryuM(self, "Failed to rename to : %s" % newName, title)
 def VVzDfd(self):
  if self.VVqD17():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFP9Be(self, BF(FFVCur, self, BF(self.VVsJCA, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVsJCA(self, name, flag):
  if self.VVXMgz(name, flag) : self.VVi6Ry(self.curDir)
  else         : FFryuM(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFgHO0FromServer(self):
  if self.VVqD17():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVwcVk(remFile)
    if size == -1:
     FFryuM(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VV90k3
     self.session.openWithCallback(BF(self.VV4Vba, title, remFile, name, size), BF(CCLyBs, mode=CCLyBs.VVSgRQ, VVWkA9="Download here", VV8MX1=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VV4Vba(self, title, remFile, name, size, locPath):
  if locPath:
   FFSKZx(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCChia, barTheme=CCChia.VV1d7P, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVWXbD, remFile, size, locFile)
       , VViIM0 = BF(self.VVB3Fj, remFile, size, locFile))
 def VVWXbD(self, remFile, size, locFile, VVWRJ1):
  VVWRJ1.VVsWOI(size)
  VVWRJ1.VVfN1b = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVLIE8(data):
     if not VVWRJ1 or VVWRJ1.isCancelled:
      return
     locFileObj.write(data)
     VVWRJ1.VVYksR(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVLIE8)
   except Exception as e:
    VVWRJ1.VVfN1b = str(e)
 def VVB3Fj(self, remFile, size, locFile, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVfN1b:
   FFryuM(self, "%s\n\nftp:/%s" % (VVfN1b, remFile), title="Download Error")
   delF = True
  elif not VVmEsn:
   FFryuM(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFl8II(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FF6mzu(self, txt, title=title)
   else:
    FFryuM(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFbUco(locFile)
 def VVgJEj(self):
  if self.VVqD17():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VV90k3
   self.session.openWithCallback(self.VVlfQt, BF(CCLyBs, VVWkA9="Upload selected file", VV8MX1=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVlfQt(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFSKZx(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFl8II(locFile)
   if size == -1:
    FFryuM(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCChia, barTheme=CCChia.VV1d7P, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VV5sN1, locFile, size, remFile)
        , VViIM0 = BF(self.VV8Xii, locFile, size, remFile))
 def VV5sN1(self, locFile, size, remFile, VVWRJ1):
  VVWRJ1.VVsWOI(size)
  VVWRJ1.VVfN1b = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVYKjQ(data):
     if not VVWRJ1 or VVWRJ1.isCancelled:
      VVWRJ1.VVfN1b = "Upload cancelled"
      locFileObj.close()
      return
     VVWRJ1.VVYksR(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVYKjQ)
   except Exception as e:
    VVWRJ1.VVfN1b = VVWRJ1.VVfN1b or str(e)
 def VV8Xii(self, locFile, size, remFile, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVmEsn:
   if size == FFl8II(locFile) : FF6mzu(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVfN1b : err = "%s\n\n%s" % (VVfN1b, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFryuM(self, err, title=title)
   self.VVOE84()
   self.VVXMgz(remFile, "")
  self.VVi6Ry(self.curDir)
class CC0Hnq():
 VVwZbG  = "all"
 VVAbbX = "vid"
 VVj5Sh  = "osd"
 @staticmethod
 def VVHZXA(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFE0hR("grab"):
    winShown = session.current_dialog.shown
    if k == CC0Hnq.VVAbbX and winShown: session.current_dialog.hide()
    FFEuIr(BF(CC0Hnq.VVxMGU, title, session, k, winShown))
   else:
    FFF6fE(session, "No Grab command !", title=title)
 @staticmethod
 def VVxMGU(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CC0Hnq.VVj5Sh:
   if not winShown:
    FFF6fE(session, "No Window to capture !", title=title)
    return
   if not CC0Hnq.VVi4Av(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CC0Hnq.VV3exu(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFF6fE(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FF80Mz(CFG.exportedPIconsPath.getValue()), fTitle, FFOa0m(), ext)
  ok = FFqj03("grab -q -s %s > '%s'" % (typ, path))
  if k == CC0Hnq.VVAbbX and winShown:
   session.current_dialog.show()
  elif k == CC0Hnq.VVj5Sh:
   ok = CC0Hnq.VVFKFj(path, x, y, w, h)
   if not ok:
    FFbUco(path)
    FFF6fE(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCceHb, title=path, VVpjN9=path))
  else      : FFF6fE(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVi4Av(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFP9Be(SELF, BF(CC0Hnq.VVVEcq, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVVEcq(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FF2Mh6, VVZgJA=cbFnc)
  else    : fnc = BF(FF8jLK , VVZgJA=cbFnc)
  fnc(SELF, FFM6zB(VVP2Dj, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VV3exu(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVFKFj(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFiI6j()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFOn9F(x , 0, scrW, 0, w)
     y  = FFOn9F(y , 0, scrH, 0, h)
     x1 = FFOn9F(x1, 0, scrW, 0, w)
     y1 = FFOn9F(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVdhVw(path):
  size = FFl8II(path)
  sizeTxt = CCLyBs.VVM24t(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CCzUL4(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFEK4e(" (Requires GUI Restart)", VVUVBT) if withRestart else ""
  VVGIDM = []
  for path in self.fontsList:
   VVGIDM.append((os.path.splitext(os.path.basename(path))[0], path))
  VVGIDM.sort(key=lambda x: x[0].lower())
  VVGIDM.insert(0, VVVgKz)
  VVGIDM.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVGIDM):
    if len(item) == 2 and item[1] == self.defFnt:
     VVGIDM[ndx] = (VVijSd + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVGIDM[curIndex] = (VVijSd + VVGIDM[curIndex][0], VVGIDM[curIndex][1])
  FFCOTe(self, VVGIDM=VVGIDM, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
  self["myBar"].setText(self.VVPU3o())
  self["myBar"].instance.setHAlign(1)
  self["myMenu"].onSelectionChanged.append(self.VV00jm)
  self.VV00jm()
 def VVLgni(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VV00jm(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFgCge(path, fnt, isRepl=1)
  else:
   fnt = VV5uhb
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVPU3o(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVHiJu(SELF, title, defFnt, rest, VViIM0):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFqy37(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VViIM0, CCzUL4, title, fontsList, defFnt, rest)
  else  : FFryuM(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCiqqe(Screen):
 def __init__(self, session, path, VVGIDM, title):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFCOTe(self, VVGIDM=VVGIDM, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok"  : self.VVLgni   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VV8aEH,
   "chanUp" : self.VV8aEH,
   "pageDown" : self.VVO5rt ,
   "chanDown" : self.VVO5rt ,
  }, -1)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
  FF21Xy(self["myLabelFrm"], "#11110000")
  FF21Xy(self["myLabelTit"], "#11663322")
  FF21Xy(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVoPAX)
  self.VVoPAX()
 def VVoPAX(self):
  if fileExists(self.path): txt = FF3unD(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVLgni(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VV8aEH(self) : self["myMenu"].moveToIndex(0)
 def VVO5rt(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCme0M():
 @staticmethod
 def VVDoVu():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VV2Fjz(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFfJU2(SELF, None, VVZAt4=lst, VVNdFV=30, VV4wMI=1)
 @staticmethod
 def VVfBpm(path, SELF=None):
  for enc in CCme0M.VVDoVu():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFryuM(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVZsja(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVhV58(SELF, path, cbFnc, curEnc=VVnekd, title="Select Encoding"):
  lst = CCme0M.VVpgRE(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCiqqe, path, lst, title)
 @staticmethod
 def VVjhER(SELF, cbFnc, curEnc=VVnekd, title="Select Encoding"):
  lst = CCme0M.VVpgRE(SELF, "", "")
  if lst:
   FFzctu(SELF, cbFnc, title=title, VVGIDM=lst, width=1000, height=1000, VVXsDY="#22220000", VVEEoV="#22220000", VVglmG=True)
 @staticmethod
 def VVpgRE(SELF, path, curEnc):
  lst = CCme0M.VVYtTA(path)
  if lst:
   VVGIDM = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVijSd
    elif enc == VVnekd: c = VVWhci
    else      : c = ""
    VVGIDM.append((c + txt, enc))
   return VVGIDM
  else:
   FFe82w(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVYtTA(path=""):
  encLst = []
  cPath = VV6OO5 + "_sup_codecs"
  if fileExists(cPath):
   lines = FF5p6q(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCme0M.VVDoVu())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CC1Nwg(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVGIDM = []
  VVGIDM.append(("Settings File"   , "SettingsFile"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Box Info"     , "VV7asX"   ))
  VVGIDM.append(("Tuners Info"    , "VV9Xeh"  ))
  VVGIDM.append(("Python Version"   , "VVOxPa"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Screen Size"    , "ScreenSize"   ))
  VVGIDM.append(("Language/Locale"   , "Locale"    ))
  VVGIDM.append(("Processor"    , "Processor"   ))
  VVGIDM.append(("Operating System"   , "OperatingSystem"  ))
  VVGIDM.append(("Drivers"     , "drivers"    ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("System Users"    , "SystemUsers"   ))
  VVGIDM.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVGIDM.append(("Uptime"     , "Uptime"    ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Host Name"    , "HostName"   ))
  VVGIDM.append(("MAC Address"    , "MACAddress"   ))
  VVGIDM.append(("Network Configuration" , "NetworkConfiguration"))
  VVGIDM.append(("Network Status"   , "NetworkStatus"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Disk Usage"    , "VVB1Gh"   ))
  VVGIDM.append(("Mount Points"    , "MountPoints"   ))
  VVGIDM.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVGIDM.append(("USB Devices"    , "USB_Devices"   ))
  VVGIDM.append(("List Block-Devices"  , "listBlockDevices" ))
  VVGIDM.append(("Directory Size"   , "DirectorySize"  ))
  VVGIDM.append(("Memory"     , "Memory"    ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVGIDM.append(("Running Processes"  , "RunningProcesses" ))
  VVGIDM.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFCOTe(self, VVGIDM=VVGIDM, title="Device Information")
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCUY1j)
   elif item == "VV7asX"   : self.VV7asX()
   elif item == "VV9Xeh"  : self.VV9Xeh()
   elif item == "VVOxPa"  : self.VVOxPa()
   elif item == "ScreenSize"   : FFDLqC(self, "Width\t: %s\nHeight\t: %s" % (FFiI6j()[0], FFiI6j()[1]))
   elif item == "Locale"    : CCme0M.VV2Fjz(self)
   elif item == "Processor"   : self.VV3rg9()
   elif item == "OperatingSystem"  : FFhTGc(self, "uname -a")
   elif item == "drivers"    : self.VV5GpS()
   elif item == "SystemUsers"   : FFhTGc(self, "id")
   elif item == "LoggedInUsers"  : FFhTGc(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFhTGc(self, "uptime")
   elif item == "HostName"    : FFhTGc(self, "hostname")
   elif item == "MACAddress"   : self.VV9bEG()
   elif item == "NetworkConfiguration" : FFhTGc(self, "ifconfig %s %s" % (FFpC0R("HWaddr", VViTDo), FFpC0R("addr:", VVWhci)))
   elif item == "NetworkStatus"  : FFhTGc(self, "netstat -tulpn", VVNdFV=24, consFont=True)
   elif item == "VVB1Gh"   : self.VVB1Gh()
   elif item == "MountPoints"   : FFhTGc(self, "mount %s" % (FFpC0R(" on ", VVWhci)))
   elif item == "FileSystemTable"  : FFhTGc(self, "cat /etc/fstab", VVNdFV=24, consFont=True)
   elif item == "USB_Devices"   : FFhTGc(self, "lsusb")
   elif item == "listBlockDevices"  : FFhTGc(self, "blkid")
   elif item == "DirectorySize"  : FFhTGc(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVeQqS="Reading size ...")
   elif item == "Memory"    : FFhTGc(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVonqn()
   elif item == "RunningProcesses"  : FFhTGc(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFhTGc(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVsmYy()
   else        : self.close()
 def VV9bEG(self):
  res = FFuNwj("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFDLqC(self, txt)
  else:
   FFhTGc(self, "ip link")
 def VV5SKB(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FF30Q2(cmd)
  return lines
 def VVz4fV(self, lines, headerRepl, widths, VVyaAW):
  VVnhmb = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVnhmb.append(parts)
  if VVnhmb and len(header) == len(widths):
   VVnhmb.sort(key=lambda x: x[0].lower())
   FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=28, VV4wMI=1)
   return True
  else:
   return False
 def VVB1Gh(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFuNwj(cmd)
  if not "invalid option" in txt:
   lines  = self.VV5SKB(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVyaAW = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVz4fV(lines, headerRepl, widths, VVyaAW)
  else:
   cmd = "df -h"
   lines  = self.VV5SKB(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVyaAW = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVz4fV(lines, headerRepl, widths, VVyaAW)
  if not allOK:
   lines = FF30Q2(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFYRE0(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVijSd:
     note = "\n%s" % FFEK4e("Green = Mounted Partitions", VVijSd)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVWhci
     elif line.endswith(mountList) : color = VVijSd
     else       : color = VVhSN2
     txt += FFEK4e(line, color) + "\n"
    FFDLqC(self, txt + note)
   else:
    FFryuM(self, "Not data from system !")
 def VVonqn(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VV5SKB(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVyaAW = (LEFT , CENTER, LEFT )
  allOK = self.VVz4fV(lines, headerRepl, widths, VVyaAW)
  if not allOK:
   FFhTGc(self, cmd)
 def VV5GpS(self):
  cmd = FFthHn(VVH9np, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFhTGc(self, cmd)
  else : FFRzIz(self)
 def VV3rg9(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFhTGc(self, cmd)
 def VVsmYy(self):
  cmd = FFthHn(VVQTjf, "| grep secondstage")
  if cmd : FFhTGc(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFRzIz(self)
 def VV7asX(self):
  c = VVijSd
  VVZAt4 = []
  VVZAt4.append((FFEK4e("Box Type"  , c), FFEK4e(self.VVLiOT("boxtype").upper(), c)))
  VVZAt4.append((FFEK4e("Board Version", c), FFEK4e(self.VVLiOT("board_revision") , c)))
  VVZAt4.append((FFEK4e("Chipset"  , c), FFEK4e(self.VVLiOT("chipset")  , c)))
  VVZAt4.append((FFEK4e("S/N"   , c), FFEK4e(self.VVLiOT("sn")    , c)))
  VVZAt4.append((FFEK4e("Version"  , c), FFEK4e(self.VVLiOT("version")  , c)))
  VVMLbu   = []
  VVTQIa = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVTQIa = SystemInfo[key]
     else:
      VVMLbu.append((FFEK4e(str(key), VVN1ah), FFEK4e(str(SystemInfo[key]), VVN1ah)))
  except:
   pass
  if VVTQIa:
   VVFpvo = self.VVwvT7(VVTQIa)
   if VVFpvo:
    VVFpvo.sort(key=lambda x: x[0].lower())
    VVZAt4 += VVFpvo
  if VVMLbu:
   VVMLbu.sort(key=lambda x: x[0].lower())
   VVZAt4 += VVMLbu
  if VVZAt4:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFfJU2(self, None, header=header, VVZAt4=VVZAt4, VVbiLs=widths, VVNdFV=28, VV4wMI=1)
  else:
   FFDLqC(self, "Could not read info!")
 def VVLiOT(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FF5p6q(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVwvT7(self, mbDict):
  try:
   mbList = list(mbDict)
   VVZAt4 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVZAt4.append((FFEK4e(subject, VVWhci), FFEK4e(value, VVWhci)))
  except:
   pass
  return VVZAt4
 def VV9Xeh(self):
  txt = self.VVlWWF("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVlWWF("/proc/bus/nim_sockets")
  if not txt: txt = self.VVy27M()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFDLqC(self, txt)
 def VVy27M(self):
  txt = ""
  VVR7gd = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVR7gd("Slot Name" , slot.getSlotName())
     txt += FFEK4e(slotName, VVWhci)
     txt += VVR7gd("Description"  , slot.getFullDescription())
     txt += VVR7gd("Frontend ID"  , slot.frontend_id)
     txt += VVR7gd("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVlWWF(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FF5p6q(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFEK4e(line, VVWhci)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVOxPa(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFDLqC(self, txt)
 @staticmethod
 def VVyb14():
  def VVR7gd(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVR7gd(v,0), "/etc/issue.net": VVR7gd(v,1), "/etc/image-version": VVR7gd(v,2)}
  for p1, d in v.items():
   img = CC1Nwg.VVLVxG(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVR7gd(v,0), p + "Plugins/": VVR7gd(v,1), VV0bR7: VVR7gd(v,2), VVRjMt: VVR7gd(v,3)}
  for p1, d in v.items():
   img = CC1Nwg.VVYXbL(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVLVxG(path, d):
  if fileExists(path):
   txt = FF3unD(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVYXbL(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCUY1j(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVGIDM = []
  VVGIDM.append(("Settings (All)"   , "Settings_All"   ))
  VVGIDM.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVGIDM.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVGIDM.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVGIDM.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVGIDM.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVGIDM.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVUwTh:
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVGIDM.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFCOTe(self, VVGIDM=VVGIDM)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVWgjG
   grep = " | grep "
   if   item == "Settings_All"   : FFhTGc(self, cmd)
   elif item == "Settings_HotKeys"  : FFhTGc(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFhTGc(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFhTGc(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFhTGc(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFhTGc(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFhTGc(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFhTGc(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFhTGc(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCgegl(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVe82P, VVD1HX, VVJSCB, camCommand = CCgegl.VV4zmH()
  self.VVD1HX = VVD1HX
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVD1HX:
   c = VVUrbH if VVJSCB else VVZoWi
   if   "oscam" in VVD1HX : camName, oC = "OSCam", c
   elif "ncam"  in VVD1HX : camName, nC = "NCam" , c
  VVGIDM = []
  VVGIDM.append(("OSCam Files" , "OSCamFiles" ))
  VVGIDM.append(("NCam Files" , "NCamFiles" ))
  VVGIDM.append(("CCcam Files" , "CCcamFiles" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((VVfZXg + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VV4XER" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVGIDM.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVGIDM.append(VVVgKz)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVGIDM.append(FFzUJ4(txt, "camInfo", VVD1HX, c))
  VVGIDM.append(VVVgKz)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVD1HX:
   for item in camLst: VVGIDM.append(item)
  else:
   for item in camLst: VVGIDM.append((item[0], ))
  FFCOTe(self, VVGIDM=VVGIDM)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCcodM, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCcodM, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCcodM, "cccam"))
   elif item == "VV4XER" : self.VV4XER()
   elif item == "OSCamReaders"  : self.VVjfm7("os")
   elif item == "NSCamReaders"  : self.VVjfm7("n")
   elif item == "camInfo"   : FFhuUm(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCgegl.VVbqrZ(self.session, CCQaoh.VVDjQo)
   elif item == "camLiveReaders" : CCgegl.VVbqrZ(self.session, CCQaoh.VVi0E9)
   elif item == "camLiveLog"  : CCgegl.VVbqrZ(self.session, CCQaoh.VVMpr3)
   else       : self.close()
 def VV4XER(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VV90k3, FFOa0m())
  if fileExists(path):
   lines = FF5p6q("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVR7gd = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVR7gd("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVR7gd("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVR7gd("protocol"   , "cccam"))
      f.write(VVR7gd("device"    , "%s,%s" % (host, port)))
      f.write(VVR7gd("user"    , User))
      f.write(VVR7gd("password"   , Pass))
      f.write(VVR7gd("fallback"   , "1"))
      f.write(VVR7gd("group"    , "64"))
      f.write(VVR7gd("cccversion"   , "2.3.2"))
      f.write(VVR7gd("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF6mzu(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFlPiz(tot), outFile))
   else:
    FFqgHP(self, "No valid CCcam lines", 1500)
  else:
   FFqgHP(self, "%s not found" % path, 1500)
 def VVjfm7(self, camPrefix):
  VVnhmb = self.VVswp1(camPrefix)
  if VVnhmb:
   VVnhmb.sort(key=lambda x: int(x[0]))
   if self.VVD1HX and self.VVD1HX.startswith(camPrefix):
    VVoXaA = ("Toggle State", self.VVs0EW, [camPrefix], "Changing State ...")
   else:
    VVoXaA = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVyaAW  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVoXaA=VVoXaA, VVehvv=True)
 def VVswp1(self, camPrefix):
  readersFile = self.VVe82P + camPrefix + "cam.server"
  VVnhmb = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FF5p6q(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVnhmb.append((str(len(VVnhmb) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVnhmb:
    FFryuM(self, "No readers found !")
  else:
   FFAhcl(self, readersFile)
  return VVnhmb
 def VVs0EW(self, VVxL8T, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVe82P, camPrefix)
  readerState  = VVxL8T.VVJ5dP(1)
  readerLabel  = VVxL8T.VVJ5dP(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCgegl.VVXtZT(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVxL8T.VVKZ4j()
    FFryuM(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVnhmb = self.VVswp1(camPrefix)
   if VVnhmb:
    VVxL8T.VVlCGq(VVnhmb)
  else:
   VVxL8T.VVKZ4j()
 @staticmethod
 def VVXtZT(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FF5p6q(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFryuM(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFryuM(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFAhcl(SELF, confFile)
   return None
  if not iRequest:
   FFryuM(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCgegl.VV7mKU(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFryuM(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VV7mKU(SELF):
  if iElem:
   return True
  else:
   FFryuM(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVbqrZ(session, VVYM2m):
  VVe82P, VVD1HX, VVJSCB, camCommand = CCgegl.VV4zmH()
  if VVD1HX:
   runLog = False
   if   VVYM2m == CCQaoh.VVDjQo : runLog = True
   elif VVYM2m == CCQaoh.VVi0E9 : runLog = True
   elif not VVJSCB          : FFF6fE(session, message="SoftCam not started yet!")
   elif fileExists(VVJSCB)        : runLog = True
   else             : FFF6fE(session, message="File not found !\n\n%s" % VVJSCB)
   if runLog:
    session.open(BF(CCQaoh, VVe82P=VVe82P, VVD1HX=VVD1HX, VVJSCB=VVJSCB, VVYM2m=VVYM2m))
  else:
   FFF6fE(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VV4zmH():
  VVe82P = "/etc/tuxbox/config/"
  VVD1HX = None
  VVJSCB  = None
  camCommand = FFunaH("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVD1HX = "oscam"
   elif camCmd.startswith("ncam") : VVD1HX = "ncam"
  if VVD1HX:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FF3unD(path), IGNORECASE)
     if span:
      VVe82P = FF80Mz(span.group(1))
      break
   else:
    path = FFunaH(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FF80Mz(path)
    if pathExists(path):
     VVe82P = path
   tFile = FF80Mz(VVe82P) + VVD1HX + ".conf"
   tFile = FFunaH("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVJSCB = tFile
  return VVe82P, VVD1HX, VVJSCB, camCommand
class CCcodM(Screen):
 def __init__(self, VVU3N2, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVe82P, VVD1HX, VVJSCB, camCommand = CCgegl.VV4zmH()
  if   VVU3N2 == "ncam" : self.prefix = "n"
  elif VVU3N2 == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVGIDM = []
  if self.prefix == "":
   VVGIDM.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVGIDM.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVGIDM.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVGIDM.append(("constant.cw"         , "x_constant_cw" ))
   VVGIDM.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVGIDM.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVGIDM.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVGIDM.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVGIDM.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVGIDM.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVGIDM.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVGIDM.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVGIDM.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVGIDM.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVGIDM.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFCOTe(self, VVGIDM=VVGIDM)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFJmvd(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFJmvd(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFJmvd(self, self.VVe82P + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFJmvd(self, self.VVe82P + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVGyaV("cam.ccache")
   elif item == "x_cam_conf"  : self.VVGyaV("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVGyaV("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVGyaV("cam.provid")
   elif item == "x_cam_server"  : self.VVGyaV("cam.server")
   elif item == "x_cam_services" : self.VVGyaV("cam.services")
   elif item == "x_cam_srvid2"  : self.VVGyaV("cam.srvid2")
   elif item == "x_cam_user"  : self.VVGyaV("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VViLpx()
   elif item == "x_CCcam_cfg"  : FFJmvd(self, self.VVe82P + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFJmvd(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFJmvd(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFJmvd(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVGyaV(self, fileName):
  FFJmvd(self, self.VVe82P + self.prefix + fileName)
 def VViLpx(self):
  path = self.VVe82P + "SoftCam.Key"
  if fileExists(path) : FFJmvd(self, path)
  else    : FFJmvd(self, path.replace(".Key", ".key"))
class CCQaoh(Screen):
 VVDjQo  = 0
 VVi0E9 = 1
 VVMpr3 = 2
 def __init__(self, session, VVe82P="", VVD1HX="", VVJSCB="", VVYM2m=VVDjQo):
  self.skin, self.skinParam = FFLEcJ(VV07bh, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVJSCB   = VVJSCB
  self.VVYM2m  = VVYM2m
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVe82P + VVD1HX + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVD1HX : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVe82P, self.camPrefix)
  if self.VVYM2m == self.VVDjQo:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVYM2m == self.VVi0E9:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFCOTe(self, self.Title, addScrollLabel=True)
  FFbJWj(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVus0M
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self["myLabel"].VVSAed(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFOuQx(self)
  self.VVus0M()
 def onExit(self):
  self.timer.stop()
 def VVQcOA(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV4vUe)
  except:
   self.timer.callback.append(self.VV4vUe)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFqgHP(self, "Started", 1000)
 def VVedwK(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV4vUe)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFqgHP(self, "Stopped", 1000)
 def VVus0M(self):
  if self.timerRunning:
   self.VVedwK()
  else:
   self.VVQcOA()
   if self.VVYM2m == self.VVDjQo or self.VVYM2m == self.VVi0E9:
    if self.VVYM2m == self.VVDjQo : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCgegl.VVXtZT(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFEuIr(self.VVt08O)
    else:
     self.close()
   else:
    self.VVNXzn()
 def VV4vUe(self):
  if self.timerRunning:
   if   self.VVYM2m == self.VVDjQo : self.VVI26c()
   elif self.VVYM2m == self.VVi0E9 : self.VVI26c()
   else            : self.VVNXzn()
 def VVNXzn(self):
  if fileExists(self.VVJSCB):
   fTime = FFkL2p(os.path.getmtime(self.VVJSCB))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVambx(), VVvR9T=VVlduB)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVJSCB)
 def VVt08O(self):
  self.VVI26c()
 def VVI26c(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFEK4e("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVnviq))
   self.camWebIfErrorFound = True
   self.VVedwK()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVYM2m == self.VVDjQo : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFEK4e("Error while parsing data elements !\n\nError = %s" % str(e), VVWABP)
   self.camWebIfErrorFound = True
   self.VVedwK()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVdYEI(root)
  self["myLabel"].setText(txt, VVvR9T=VVlduB)
  self["myBar"].setText("Last Update : %s" % FF2gGN())
 def VVdYEI(self, rootElement):
  def VVR7gd(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVYM2m == self.VVDjQo:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFEK4e(status, VVijSd)
    else          : status = FFEK4e(status, VVWABP)
    txt += SEP + "\n"
    txt += VVR7gd("Name"  , name)
    txt += VVR7gd("Description" , desc)
    txt += VVR7gd("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVR7gd("Protocol" , protocol)
    txt += VVR7gd("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFEK4e("Yes", VVijSd)
    else    : enabTxt = FFEK4e("No", VVWABP)
    txt += SEP + "\n"
    txt += VVR7gd("Label"  , label)
    txt += VVR7gd("Protocol" , protocol)
    txt += VVR7gd("Enabled" , enabTxt)
  return txt
 def VVambx(self):
  lines = FF30Q2("tail -n %d %s" % (100, self.VVJSCB))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVUVBT + line[:19] + VVhSN2 + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVEqIl + "WebIf" + VVhSN2)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVN1ah + h1 + h2 + VVhSN2 + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVijSd + span.group(2) + VVfZXg + span.group(3) + VVhSN2 + span.group(4)
    line = self.VVjLBL(line, VVfZXg, ("(webif)", ))
    line = self.VVjLBL(line, VVfZXg, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVjLBL(line, VVijSd, ("OSCam", "NCam", "log switched"))
    line = self.VVjLBL(line, VVWEO1, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVWhci + line[ndx + 3:] + VVhSN2
   elif line.startswith("----") or ">>" in line:
    line = FFEK4e(line, VVoR97)
   txt += line + "\n"
  return txt
 def VVjLBL(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVhSN2 + t3
  return line
class CC7Vv3(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVGIDM = []
  VVGIDM.append(("Backup Channels"    , "VVUCFP"   ))
  VVGIDM.append(("Restore Channels"    , "Restore_Channels"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Backup SoftCAM Files"   , "VVhKEr" ))
  VVGIDM.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVGIDM.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVGIDM.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Backup Network Settings"  , "VVUj9t"   ))
  VVGIDM.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVUwTh:
   VVGIDM.append(VVVgKz)
   VVGIDM.append((VVnviq + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVTgix"   ))
   VVGIDM.append((VVijSd + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVVU4H), "createMyIpk"   ))
   VVGIDM.append((VVijSd + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVVU4H), "createMyDeb"   ))
   VVGIDM.append((VVN1ah + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVGIDM.append((VVN1ah + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVou1b" ))
   VVGIDM.append((VVN1ah + "Show Windows Stats"           , "VVaL4j" ))
  FFCOTe(self, VVGIDM=VVGIDM)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVUCFP"    : self.VVUCFP()
   elif item == "Restore_Channels"    : self.VVrkJJ("channels_backup*.tar.gz", self.VVHqIY, isChan=True)
   elif item == "VVhKEr"   : self.VVhKEr()
   elif item == "Restore_SoftCAM_Files"  : self.VVrkJJ("softcam_backup*.tar.gz", self.VVNVUs)
   elif item == "Backup_TunerDiSEqC"   : self.VVx8xq("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVrkJJ("tuner_backup*.backup", BF(self.VVRX4p, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVx8xq("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVrkJJ("hotkey_*backup*.backup", BF(self.VVRX4p, "misc"))
   elif item == "VVUj9t"    : self.VVUj9t()
   elif item == "Restore_Network"    : self.VVrkJJ("network_backup*.tar.gz", self.VVrPKn)
   elif item == "VVTgix"     : FFP9Be(self, BF(FFVCur, self, BF(CC7Vv3.VVTgix, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VV2uZk(False)
   elif item == "createMyDeb"     : self.VV2uZk(True)
   elif item == "createMyTar"     : self.VVTBma()
   elif item == "VVou1b"   : self.VVou1b()
   elif item == "VVaL4j"    : CC7Vv3.VVaL4j(self)
 @staticmethod
 def VV2zAD(SELF):
  OBF_Path = VVBlSs + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFAhcl(SELF, OBF_Path)
   return None
 @staticmethod
 def VVaL4j(SELF):
  obf = CC7Vv3.VV2zAD(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFDLqC(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVTgix(SELF):
  obf = CC7Vv3.VV2zAD(SELF)
  if obf:
   txt, err = obf.fixCode(VVBlSs, VVQBlh, VVVU4H)
   if err : FFryuM(SELF, err)
   else : FFDLqC(SELF, txt)
 def VV2uZk(self, VV76sq):
  OBF_Path = VVBlSs + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFryuM(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFyakl("rm -f %s__pycache__/" % VVBlSs)
  FFyakl("mv -f '%smain.py' '%s'" % (VVBlSs, OBF_Path))
  FFyakl("mv -f '%splugin.py' '%s'" % (VVBlSs, OBF_Path))
  FFyakl("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VVBlSs))
  self.session.openWithCallback(self.VVMiFo, BF(CCeghF, path=VVBlSs, VV76sq=VV76sq))
 def VVMiFo(self):
  FFyakl("mv -f %s %s" % (VVBlSs + "OBF/main.py" , VVBlSs))
  FFyakl("mv -f %s %s" % (VVBlSs + "OBF/plugin.py", VVBlSs))
 def VVou1b(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFryuM(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFryuM(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVSjwF("%s*.list" % path)
  if err:
   FFAhcl(self, path + "*.list")
   return
  srcF, err = self.VVSjwF("%s*main_final.py" % path)
  if err:
   FFAhcl(self, path + "*.final.py")
   return
  VVZAt4 = []
  for f in files:
   f = os.path.basename(f)
   VVZAt4.append((f, f))
  FFzctu(self, BF(self.VVSffo, path, codF, srcF), VVGIDM=VVZAt4)
 def VVSffo(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFAhcl(self, logF)
   else     : FFVCur(self, BF(self.VVtBoy, logF, codF, srcF))
 def VVtBoy(self, logF, codF, srcF):
  lst  = []
  lines = FF5p6q(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFryuM(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVavE3(lst, logF, newLogF)
  totSrc  = self.VVavE3(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFDLqC(self, txt)
 def VVSjwF(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVavE3(self, lst, f1, f2):
  txt = FF3unD(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVTBma(self):
  VVZAt4 = []
  VVZAt4.append("%s%s" % (VVBlSs, "*.py"))
  VVZAt4.append("%s%s" % (VVBlSs, "*.png"))
  VVZAt4.append("%s%s" % (VVBlSs, "*.xml"))
  VVZAt4.append("%s"  % (VV6OO5))
  FFDNgQ(self, VVZAt4, "%s_%s" % (PLUGIN_NAME, VVQBlh), addTimeStamp=False)
 def VVUCFP(self):
  path1 = VVWgjG
  path2 = "/etc/tuxbox/"
  VVZAt4 = []
  VVZAt4.append("%s%s" % (path1, "*.tv"))
  VVZAt4.append("%s%s" % (path1, "*.radio"))
  VVZAt4.append("%s%s" % (path1, "*list"))
  VVZAt4.append("%s%s" % (path1, "lamedb*"))
  VVZAt4.append("%s%s" % (path2, "*.xml"))
  FFDNgQ(self, VVZAt4, self.VVCeSr("channels_backup"), addTimeStamp=True)
 def VVhKEr(self):
  VVZAt4 = []
  VVZAt4.append("/etc/tuxbox/config/")
  VVZAt4.append("/usr/keys/")
  VVZAt4.append("/usr/scam/")
  VVZAt4.append("/etc/CCcam.cfg")
  FFDNgQ(self, VVZAt4, self.VVCeSr("softcam_backup"), addTimeStamp=True)
 def VVUj9t(self):
  VVZAt4 = []
  VVZAt4.append("/etc/hostname")
  VVZAt4.append("/etc/default_gw")
  VVZAt4.append("/etc/resolv.conf")
  VVZAt4.append("/etc/wpa_supplicant*.conf")
  VVZAt4.append("/etc/network/interfaces")
  VVZAt4.append("%snameserversdns.conf" % VVWgjG)
  FFDNgQ(self, VVZAt4, self.VVCeSr("network_backup"), addTimeStamp=True)
 def VVCeSr(self, fName):
  img = CC1Nwg.VVyb14()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVHqIY(self, fileName=None):
  if fileName:
   FFP9Be(self, BF(FFVCur, self, BF(self.VVT62z, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVT62z(self, fileName):
  path = "%s%s" % (VV90k3, fileName)
  if fileExists(path):
   if CCLyBs.VVl4x1(path):
    VVlXNT , VVg1DL = CCTc7M.VVws8E()
    VVuQny, VVHXCZ = CCTc7M.VVbHSy()
    cmd  = FFbUbn("cd %s" % VVWgjG)
    cmd += FFbUbn("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVg1DL, VVHXCZ))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFyakl(cmd)
    FFWH63()
    if ok: FF6mzu(self, "Channels Restored.")
    else : FFryuM(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFryuM(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFAhcl(self, path)
 def VVNVUs(self, fileName=None):
  if fileName:
   FFP9Be(self, BF(self.VVOW6b, fileName), "Overwrite SoftCAM files ?")
 def VVOW6b(self, fileName):
  fileName = "%s%s" % (VV90k3, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FF53hC(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFpC0R(note, VVWhci), sep))
  else:
   FFAhcl(self, fileName)
 def VVrPKn(self, fileName=None):
  if fileName:
   FFP9Be(self, BF(self.VVDZ3m, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VVDZ3m(self, fileName):
  fileName = "%s%s" % (VV90k3, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF8jLK(self,  cmd)
  else:
   FFAhcl(self, fileName)
 def VVrkJJ(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFpdY0()
  if pathExists(VV90k3):
   myFiles = FFqy37(VV90k3, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVZAt4 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVZAt4.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVV7uB = ("Sat. List", self.VV28Xt)
    elif isChan and iTar: VVV7uB = ("Bouquets Importer", CCYcg2.VVio2g)
    else    : VVV7uB = None
    FFzctu(self, callBackFunction, title=title, width=1200, VVGIDM=VVZAt4, VVV7uB=VVV7uB, VVfIfT=VV90k3)
   else:
    FFryuM(self, "No files found in:\n\n%s" % VV90k3, title)
  else:
   FFryuM(self, "Path not found:\n\n%s" % VV90k3, title)
 def VVx8xq(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVWgjG
  tCons = CCcJGn()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVGGEW, filePrefix))
 def VVGGEW(self, filePrefix, result, retval):
  title = FFpdY0()
  if pathExists(VV90k3):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFryuM(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VV90k3, filePrefix, self.VVCeSr(""), FFOa0m())
    try:
     VVZAt4 = str(result.strip()).split()
     if VVZAt4:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVZAt4:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FFEK4e(fName, VVWhci), SEP)
       FFDLqC(self, txt, title=title, VVvR9T=VVlduB)
      else:
       FFryuM(self, "File creation failed!", title)
     else:
      FFryuM(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFyakl("rm %s" % fName)
     FFryuM(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFyakl("rm %s" % fName)
     FFryuM(self, "Error while writing file.")
  else:
   FFryuM(self, "Path not found:\n\n%s" % VV90k3, title)
 def VVRX4p(self, mode, path=None):
  if path:
   path = "%s%s" % (VV90k3, path)
   if fileExists(path):
    lines = FF5p6q(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFP9Be(self, BF(self.VV52IW, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FFuRB8(self, path, title=FFpdY0())
   else:
    FFAhcl(self, path)
 def VV52IW(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VV1Y5G = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VV1Y5G.append("echo -e 'Reading current settings ...'")
  VV1Y5G.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VV1Y5G.append("echo -e 'Preparing new settings ...'")
  VV1Y5G.append(settingsLines)
  VV1Y5G.append("echo -e 'Applying new settings ...'")
  VV1Y5G.append("mv -f %s %s" % (tFile, sFile))
  FFDlYP(self, VV1Y5G)
 def VV28Xt(self, selectionObj, path):
  if not path:
   return
  path = VV90k3 + path
  if not fileExists(path):
   FFAhcl(self, path)
   return
  txt = FF3unD(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFGaI7(item[1]))
   FFDLqC(self, txt, title="Satellites List")
  else:
   FFryuM(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCYcg2():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVio2g(SELF, fName):
  bi = CCYcg2(SELF)
  bi.instance = bi
  bi.VVaeit(SELF, fName)
 @staticmethod
 def VV3qIY(SELF):
  bi = CCYcg2(SELF)
  bi.instance = bi
  bi.VV2NTp()
 def VVaeit(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VV90k3 + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFVCur(waitObg, self.VVSlFv, title="Reading bouquets ...")
  else      : self.VVoWdh(self.filePath)
 def VVInOH(self, txt) : FFryuM(self.SELF, txt, title=self.Title)
 def VVO6nE(self, txt)  : FFqgHP(self, txt, 1500)
 def VVoWdh(self, path) : FFAhcl(self.SELF, path, title=self.Title)
 def VV2NTp(self):
  if pathExists(VV90k3):
   lst = FFqy37(VV90k3, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVFtpf())
   if len(lst) > 0:
    VVGIDM = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFEK4e(item, VVfZXg) if item.endswith(".zip") else item
     VVGIDM.append((txt, item))
    VVGIDM.sort(key=lambda x: x[1].lower())
    VV4v1i = self.VVccm8
    FFzctu(self.SELF, self.VVKUiy, minRows=3, title=self.Title, width=1200, VVGIDM=VVGIDM, VV4v1i=VV4v1i, VVfIfT=VV90k3, VVXsDY="#22111111", VVEEoV="#22111111")
   else:
    self.VVInOH("No valid backup files found in:\n\n%s" % VV90k3)
  else:
   self.VVInOH("Backup Directory not found:\n\n%s" % VV90k3)
 def VVccm8(self, item=None):
  if item:
   VVXrLB, txt, fName, ndx = item
   self.VVaeit(VVXrLB, fName)
 def VVKUiy(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVFtpf(self):
  files = FFqy37(VV90k3, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVSlFv(self):
  lines, err = CCYcg2.VVXY8j(self.filePath, "bouquets.tv")
  if err:
   self.VVInOH(err)
   return
  bTvSortLst  = self.VVshSq(lines)
  lines, err = CCYcg2.VVXY8j(self.filePath, "bouquets.radio")
  if err:
   self.VVInOH(err)
   return
  bRadSortLst = self.VVshSq(lines)
  VVnhmb = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVmgum(f, mode, len(VVnhmb), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVnhmb.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVmgum(f, mode, len(VVnhmb), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVmgum(f, mode, len(VVnhmb), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVnhmb.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVmgum(f, mode, len(VVnhmb), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVnhmb:
   VVnhmb.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVnhmb): VVnhmb[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVnhmb):
     if key == os.path.basename(row[9]):
      VVnhmb = VVnhmb[:ndx+1] + lst + VVnhmb[ndx+1:]
      break
   for ndx, item in enumerate(VVnhmb): VVnhmb[ndx][0] = str(ndx + 1)
   VVasam = "#11000600"
   VVRWOd  = ("Show Services" , self.VVOYNw  , [], "Reading ..." )
   VVMOfU = (""    , self.VVFRbb, [])
   VVMCbu = ("Options"  , self.VVeo1A, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVyaAW  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFfJU2(self.SELF, None, title=self.Title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=24, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVMCbu=VVMCbu, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVXsDY=VVasam, VVEEoV=VVasam, VVasam=VVasam, VVhaQs="#00004455", VVAXDQ="#0a282828")
  else:
   self.VVInOH("No valid bouquets in:\n\n%s" % self.filePath)
 def VVshSq(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVFRbb(self, VVxL8T, title, txt, colList):
  FFDLqC(self.SELF, FFLKj3(txt), title=title)
 def VVeo1A(self, VVxL8T, title, txt, colList):
  mSel = CCMUYz(self.SELF, VVxL8T)
  if VVxL8T.VV1dHJ:
   totSel = VVxL8T.VVwKPO()
   if totSel: VVGIDM = [("Import %s Bouquet%s" % (FFEK4e(str(totSel), VVijSd), FFlPiz(totSel)), "imp")]
   else  : VVGIDM = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFEK4e(bName, VVijSd)
   VVGIDM = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFVCur, VVxL8T, BF(CCYcg2.VV8tBc, self.SELF, VVxL8T, self.filePath))}
  mSel.VVtH9B(VVGIDM, cbFncDict)
 def VVOYNw(self, VVxL8T, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCYcg2.VVXY8j(self.filePath, "lamedb")
   if err:
    self.VVInOH(err)
    return
   dbServLst = CCTc7M.VVhRUp(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVxL8T.VVoYvr()
   lines, err = CCYcg2.VVXY8j(self.filePath, os.path.basename(fName))
   if err:
    self.VVInOH(err)
    return
   VVnhmb = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVnhmb.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVnhmb.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVnhmb.append((span.group(1).strip() or "-", "Stream Relay" if FFUkkg(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVnhmb.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVnhmb.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCTc7M.VVu6SV(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVnhmb.append((name.strip() or "-", FFFcgz(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVnhmb):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCYcg2.VVXY8j(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVnhmb[ndx] = (bName, descr)
   if VVnhmb:
    VVasam = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVyaAW = (LEFT  , CENTER)
    FFfJU2(self.SELF, None, title="Services in : %s" % bName, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=28, VVXsDY=VVasam, VVEEoV=VVasam, VVasam=VVasam, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFqgHP(VVxL8T, err, 1500)
  else : VVxL8T.VVKZ4j()
 def VVmgum(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVInOH("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFUkkg(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVu8zC(var):
   return str(var) if var else VVJvHF + str(var)
  totItem = VVWhci + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVnviq   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVfZXg, "Sub-B."
  else  : bColor, totBnb = ""      , VVu8zC(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVu8zC(totDVB), VVu8zC(totIptv), VVu8zC(totSRelay), VVu8zC(totLoc), VVu8zC(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VV8tBc(SELF, VVxL8T, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVWgjG + "bouquets.tv"
  radBouquetFile = VVWgjG + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFAhcl(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFAhcl(SELF, radBouquetFile, title=title)
   return
  isMulti = VVxL8T.VV1dHJ
  if isMulti : rows = VVxL8T.VVo1A6()
  else  : rows = [VVxL8T.VVoYvr()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFryuM(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFLKj3(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFLKj3(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVWgjG + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVWgjG + newFile
    CCYcg2.VVQzZg(archPath, fName, VVWgjG, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FFjfx9(tvBouquetFile)
   FFjfx9(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCYcg2.VV6lvh(SELF, archPath, bList)
   FFWH63()
  txt  = FFEK4e("Added:\n", VVfZXg)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFEK4e("Imported to lamedab:\n", VVfZXg)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFEK4e("Missing from archived lamedb:\n", VVnviq)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFDLqC(SELF, txt, title=title, width=1000)
 @staticmethod
 def VV6lvh(SELF, archPath, bList):
  VVlXNT, err = CCTc7M.VVcW6O(SELF, VVyxvV=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCTc7M.VVvpiE(VVlXNT, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FF5p6q(VVWgjG + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCTc7M.VVu6SV(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCTc7M.VVYLV9(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCYcg2.VVKW9f(archPath, dbName)
   CCYcg2.VVQzZg(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCTc7M.VVvpiE(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCTc7M.VVvpiE(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCTc7M.VVvpiE(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCTc7M.VVvpiE(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFbUco(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVlXNT + ".tmp"
   lines   = FF5p6q(VVlXNT)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFyakl("mv -f '%s' '%s'" % (tmpDbFile, VVlXNT))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVo254(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVKW9f(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVQzZg(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVXY8j(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCmKOJ():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VVORib()
 def VVORib(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVW5Ke(self):
  FFVCur(self, self.VVym4k)
 def VVym4k(self):
  if pathExists(self.projMainPath):
   lst = FFh9LG(self.projMainPath)
   VVGIDM = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVGIDM.append((prName, prName))
   if VVGIDM:
    VVGIDM.sort(key=lambda x: x[1].lower())
    VV4v1i = self.VVheUi
    VVV7uB = ("Add new project", self.VVv6H9)
    VVQaYB= ("Delete Project" , self.VV13km)
    self.projMenu = FFzctu(self, None, VVGIDM=VVGIDM, width=1100, VV4v1i=VV4v1i, VVV7uB=VVV7uB, VVQaYB=VVQaYB, minRows=5, VVXsDY="#22111133", VVEEoV="#22111133")
   else:
    FFP9Be(self, self.VVPZFR, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VVgotN("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVPZFR(self)    : FFVCur(self, BF(self.VVlTbK))
 def VVv6H9(self, VVXrLB, item) : FFVCur(self.projMenu, BF(self.VVlTbK))
 def VVlTbK(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVpUNm(name)
 def VVpUNm(self, name, cbFnc=None):
  FF9Fmo(self, cbFnc or self.VVLmG9, defaultText=name, title="New Project Name", message="Enter project name")
 def VVLmG9(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFP9Be(self, BF(self.VVpUNm, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFHxsx(path)
    if err:
     self.VVgotN("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVzCFO((item, item), isSort=True)
     else   : self.VVW5Ke()
 def VV13km(self, VVXrLB, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFPXso(path)
    FFP9Be(self, BF(self.VV7CpY, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VV7CpY(self, path):
  if FFyakl("rm -rf '%s'" % path):
   self.projMenu.VVk2T1()
 def VVheUi(self, item=None):
  if item:
   VVXrLB, txt, Dir, ndx = item
   self.VVORib()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VV6OO5
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FF5p6q(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FF2gGN()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVZCWJ()
   else      : self.VVgotN("Cannot create project file:\n\n%s" % self.projFile)
 def VVZCWJ(self, VVXrLB=None, jmpDict=None):
  FFVCur(VVXrLB or self.projTable or self, BF(self.VVKBIm, jmpDict))
 def VVKBIm(self, jmpDict):
  self.VVORib()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FF5p6q(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVyeEt(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VVgotN('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFl8II(path)
    if sz > -1: size = CCLyBs.VVM24t(sz, mode=4)
    else   : size = FFEK4e("Size error", VVnviq)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FF5p6q(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVKJE6(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVyrIT(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FFEK4e("Unknown value", VVnviq), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FFEK4e(rem, VVnviq), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVnhmb = pkgRows
  VVnhmb.extend(actnRows)
  VVnhmb.extend(ctrlRows)
  VVnhmb.extend(fileRows)
  VVnhmb.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVnhmb):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FFEK4e("Valid", VVijSd), " ... " + Remarks if Remarks else "")
    VVnhmb[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVlCGq(VVnhmb, tableRefreshCB=BF(self.VVEtvI, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVMOfU = (""     , self.VVlFLO   , [])
   menuButtonFnc = (""     , self.VV7Rrv   , [])
   VVr0hN = ("Create Package"  , self.VVn4OU , [])
   VVMCbu = ("Post Install Action", self.VVk8mh, [])
   VVUm5B = ("Edit File"   , self.VVSI21  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVyaAW = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, width=1850, height=1040, VVNdFV=26, VVMOfU=VVMOfU, menuButtonFnc=menuButtonFnc, VVr0hN=VVr0hN, VVMCbu=VVMCbu, VVUm5B=VVUm5B, searchCol=2
         , VVXsDY=bg, VVEEoV=bg, VVasam=bg, VVhaQs="#00664411", VVAXDQ="#00444444", VVilD4="#08442211")
   self.projTable.VVa866(self.VVyMEt, True)
 def VVEtvI(self, jmpDict, VVxL8T, title, txt, colList):
  self.projTable.VVWFhX(jmpDict)
 def VVyMEt(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVoYvr()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVyeEt(self, line):
  def VVh9t0(patt, val, Len):
   if len(val) < Len   : return FFEK4e("Length error" , VVnviq)
   elif not iMatch(patt, val) : return FFEK4e("Invalid format" , VVnviq)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVh9t0(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVh9t0(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVKJE6(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FF31Ce(path)
  path = FFYRE0(path)
  c = VVnviq
  if   typ == "Mount" : rem = FFEK4e("Not allowed", c)
  elif not typ  : rem = FFEK4e("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FFEK4e("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFg1qW(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FF31Ce(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FFEK4e("Not allowed", c)
     elif targetType == "Directory" : sz = FFg1qW(targetPath)
     elif targetType == "File"  : sz = FFl8II(targetPath)
     else       : sz, rem = FFl8II(path), FFEK4e("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFl8II(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCLyBs.VVM24t(sz, mode=4)
     else:
      size = FFEK4e("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVyrIT(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVSI21(self, VVxL8T, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CC8yF1(self, path, VViIM0=self.VVByes, curRowNum=lineNdx)
  else    : FFAhcl(self, path)
 def VVByes(self, fileChanged):
  if fileChanged:
   self.VVZCWJ()
 def VVgotN(self, txt):
  FFryuM(self, txt, title=self.projTitle)
 def VVlFLO(self, VVxL8T, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVfZXg
  s  = FFu7MN("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFu7MN("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCLyBs.VVM24t(self.projFilesSize))
  FFDLqC(self, s, title="Project Info", width=1600)
 def VV7Rrv(self, VVxL8T, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVUrbH, VVZoWi, VVfZXg
  VVGIDM = []
  VVGIDM.append((c1 + "Add Resource File"  , "addFile" ))
  VVGIDM.append((c1 + "Add Resource Directory" , "addDir" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Change Package Name"   , "pkgNam" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c2 + "Add Dependency"   , "addDep" ))
  VVGIDM.append((c2 + "Remove Dependency"  , "delDep" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVGIDM.append(FFzUJ4('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(FFzUJ4("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVnviq))
  FFzctu(self, self.VVm0FG, VVGIDM=VVGIDM, width=1050, title="Options", VVXsDY="#11001122", VVEEoV="#11001122")
 def VVm0FG(self, item=None):
  if item:
   if   item == "addFile" : self.VVW5mi(False)
   elif item == "addDir" : self.VVW5mi(True)
   elif item == "pkgNam" : self.VVXBC8()
   elif item == "addDep" : FFVCur(self.projTable, self.VVKP8R)
   elif item == "delDep" : self.VVfvvl()
   elif item == "ctrlFMan" : self.VV20pV()
   elif item == "ctrlImprt": FFVCur(self.projTable, self.VVJ2AO)
   elif item == "ctrlUndo" : self.VVeSFG()
   elif item == "delRow" : self.VVwkNN()
 def VVW5mi(self, isDir):
  Dir = FFlkVY(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VV2jKs, BF(CCLyBs, mode=CCLyBs.VVSgRQ, VV8MX1=Dir))
  else : self.session.openWithCallback(self.VV2jKs, BF(CCLyBs, patternMode="all", VV8MX1=Dir))
 def VV2jKs(self, path):
  if path:
   FFSKZx(CFG.lastPkgProjDir, path)
   self.VVT8Y5(path, 2)
 def VV20pV(self):
  Dir = FFlkVY(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVa9Nq, BF(CCLyBs, patternMode="pkgCtrl", VV8MX1=Dir))
 def VVa9Nq(self, path):
  if path:
   FFSKZx(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFyakl("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVZCWJ()
    self.projTable.VVWFhX({1:"Script", 2:fName})
 def VVJ2AO(self):
  cmd = FFthHn(VVH9np, "")
  if not cmd:
   FFRzIz(self)
   return
  lst = FF30Q2(cmd)
  if lst:
   err = CCLyBs.VVkPRf(lst, fromFind=False)
   if err:
    self.VVgotN(err)
    return
   lst.sort()
   VVnhmb = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVnhmb.append(("", span.group(1), span.group(2)))
   if VVnhmb:
    VVoXaA = ("Import 'control' data", self.VVnlRs, [])
    VVMCbu = ("Package Info.", self.VV1Gsw     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVbiLs=widths, VVNdFV=30, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VV30ES=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVXsDY="#22110011", VVEEoV="#22191111", VVasam="#22191111", VVhaQs="#00003030", VVAXDQ="#00333333")
   else:
    self.VVgotN("Cannot process installed packages !")
  else:
   self.VVgotN("Cannot read installed packages !")
 def VVeSFG(self):
  if FFyakl("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVZCWJ(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VVgotN("Process Failed !")
 def VVnlRs(self, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVqa5x, VVxL8T, colList[1]))
 def VVqa5x(self, VVxL8T, pkg):
  lines = []
  for line in FF30Q2(FFM6zB(VVRLzP, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFP9Be(self, BF(self.VVdx7G, VVxL8T, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VVgotN("Cannot import from this package:\n\n%s" % pkg)
 def VVdx7G(self, VVxL8T, lines):
  VVxL8T.cancel()
  FFWyyp(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVZCWJ(jmpDict={1:"Control", 2:"Package"})
 def VVwkNN(self):
  lineNum = int(self.projTable.VVoYvr()[0]) + 1
  FFyakl("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVZCWJ()
 def VVT8Y5(self, line, jmp):
  if fileExists(self.projFile):
   FFWyyp(self.projFile)
   FFjfx9(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVZCWJ(jmpDict=jmpDict)
  else:
   FFAhcl(self, self.projFile, title=self.projTitle)
 def VVk8mh(self, VVxL8T, title, txt, colList):
  VVGIDM = []
  VVGIDM.append(FFzUJ4("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVGIDM.append(FFzUJ4("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVGIDM.append(FFzUJ4("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(FFzUJ4("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVGIDM.append(FFzUJ4("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVGIDM.append(FFzUJ4("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFzctu(self, self.VVh5TH, VVGIDM=VVGIDM, title="Action (after the package is installed/removed)")
 def VVh5TH(self, item=None):
  if item:
   if   item == "instNon" : self.VV8o2L("postinst", 0)
   elif item == "instRes" : self.VV8o2L("postinst", 1)
   elif item == "instReb" : self.VV8o2L("postinst", 2)
   elif item == "rmNon" : self.VV8o2L("postrm", 0)
   elif item == "rmRes" : self.VV8o2L("postrm", 1)
   elif item == "rmReb" : self.VV8o2L("postrm", 2)
 def VV8o2L(self, subj, val):
  if fileExists(self.projFile):
   lines = FF5p6q(self.projFile)
   FFWyyp(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VVT8Y5("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVZCWJ()
 def VVXBC8(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVGIDM = []
  VVGIDM.append((pkg, pkg))
  VVGIDM.append(VVVgKz)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVfZXg if name == self.projPkg else ""
    VVGIDM.append((c + name, name))
   else:
    VVGIDM.append(VVVgKz)
  FFzctu(self, self.VVKoal, VVGIDM=VVGIDM, title="Package Name")
 def VVKoal(self, item=None):
  if item:
   self.VVgRFq("Package", item)
 def VVKP8R(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVGIDM = []
   for item in lst: VVGIDM.append((item, item))
   VVGIDM.sort(key=lambda x: x[0].lower())
   VVXrLB = FFzctu(self, self.VV1lR6, VVGIDM=VVGIDM, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVXrLB.VVJSVD(self.projLastDepends)
  else:
   self.VVgotN("Cannot read dependencies list !")
 def VV1lR6(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FF5p6q(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVgRFq("Depends", ", ".join(lst))
   else:
    FFqgHP(self.projTable, "Already added", 1500)
    self.projTable.VVWFhX({1:"Control", 2:"Depends"})
 def VVfvvl(self):
  lst = []
  for row in self.projTable.VVWcfU():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVGIDM = []
   for item in lst: VVGIDM.append((item, item))
   FFzctu(self, BF(self.VVSp8N, lst), VVGIDM=VVGIDM, title="Remove Dependency")
  else:
   self.VVgotN("No dependencies to remove !")
 def VVSp8N(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVgRFq("Depends", ", ".join(lst))
   else:
    FFyakl("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVZCWJ()
 def VVgRFq(self, subj, val):
  lines = FF5p6q(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVZCWJ(jmpDict={1:"Control", 2:subj})
 def VVn4OU(self, VVxL8T, title, txt, colList):
  VVGIDM = []
  VVGIDM.append(("Create .ipk"  , "ipk"))
  VVGIDM.append(("Create .deb"  , "deb"))
  VVGIDM.append(("Create .tar.gz" , "tar"))
  FFzctu(self, self.VVTCRw, VVGIDM=VVGIDM, width=500, title=self.projTitle)
 def VVTCRw(self, item=None):
  if item:
   FFVCur(self.projTable, BF(self.VVMri3, item))
 def VVMri3(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VVgotN("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VV76sq, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VV76sq, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VVgotN(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFbUbn("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFpC0R(result  , VVijSd))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFpC0R(failed, VVWABP))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFbUbn("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVWcfU()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FF8jLK(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFyakl(cmd) or not pathExists(ctrlDir):
   VVgotN(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVh9t0(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFyakl("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVh9t0(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FFjfx9(dstF)
   FFyakl("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFjDBy()
  if VV76sq:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFhXFT("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FF8jLK(self, cmd)
class CCiRwv(Screen, CCmKOJ):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCmKOJ.__init__(self)
  c1, c2, c3, c4 = VVUrbH, VVZoWi, VVUVBT, VVfZXg
  VVGIDM = []
  VVGIDM.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c3 + "Remove Packages (show all)"     , "VV3z22sAll"  ))
  VVGIDM.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c2 + "Update Packages List from Feed"    , "VVTsh3"  ))
  VVGIDM.append((c2 + "Upgradable Packages"       , "VVzBdY" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Packaging Tool"         , "VVwfby"   ))
  VVGIDM.append(("Active Feeds"          , "VV62mD"   ))
  FFCOTe(self, VVGIDM=VVGIDM)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCu5fi.VVy0SQ(self)
   elif item == "downloadInstallPackages"  : FFVCur(self, BF(self.VVkMpl, 0, ""))
   elif item == "VV3z22sAll"   : FFVCur(self, BF(self.VVkMpl, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFVCur(self, BF(self.VVkMpl, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVTsh3"   : CCiRwv.VVTsh3(self)
   elif item == "VVzBdY"  : FFVCur(self, self.VVzBdY)
   elif item == "packageCreator"    : self.VVW5Ke()
   elif item == "VVwfby"    : self.VVwfby()
   elif item == "VV62mD"    : FFVCur(self, self.VV62mD)
   else          : self.close()
 def VV62mD(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVnhmb = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVnhmb.append((os.path.basename(path), str(tot)))
  if VVnhmb:
   VVnhmb.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVyaAW = (LEFT  , CENTER )
   FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, width=1000, VVNdFV=26, VV4wMI=2)
  else:
   self.VVgotN("Cannot read packages list !")
 def VVzBdY(self, VVxL8T=None):
  lst = FF30Q2(FFthHn(VVbxJT, ""))
  VVnhmb = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVnhmb.append((str(len(VVnhmb) + 1), pkg, curV, newVer))
   if VVnhmb:
    if VVxL8T:
     VVxL8T.VVlCGq(VVnhmb, VVj0IZMsg=True)
    else:
     bg = "#00221111"
     VVoXaA = ("Upgrade", self.VVwvvN   , [])
     VVMCbu = ("Package Info.", self.VV1Gsw , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVyaAW = (CENTER , LEFT  , LEFT  , LEFT   )
     FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, width=1700, VVNdFV=26, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVehvv=True, VVCR7e=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVXsDY=bg, VVEEoV=bg, VVasam=bg, VVPYhe="#00ffff55", VVhaQs="#00003040")
  if not VVnhmb:
   FFe82w(self, "Nothing to upgrade", 1500)
   if VVxL8T: VVxL8T.cancel()
 def VVwvvN(self, VVxL8T, title, txt, colList):
  pkg = colList[1]
  cmd = FFM6zB(VVP2Dj, pkg)
  if cmd : FF8jLK(self, cmd, title="Installing : %s" % pkg, VVZgJA=BF(self.VVzBdY, VVxL8T))
  else : FFRzIz(SELF)
 def VVwfby(self):
  pkg = FF0tZq()
  aptT = "apt - Advanced Package Tool" if FFE0hR("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FF6mzu(self, txt or "No packaging tools found!")
 def VVkMpl(self, mode, grep, VVxL8T=None, title=""):
  if   mode == 0: cmd = FFthHn(VVQTjf    , grep)
  elif mode == 1: cmd = FFthHn(VVH9np , grep)
  elif mode == 2: cmd = FFthHn(VVH9np , grep)
  if not cmd:
   FFRzIz(self)
   return
  VVnhmb = FF30Q2(cmd)
  if VVnhmb:
   err = CCLyBs.VVkPRf(VVnhmb, fromFind=False)
   if err:
    FFryuM(self, err)
    return
  else:
   if VVxL8T: VVxL8T.VVKZ4j()
   FFryuM(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVZAt4  = []
  for item in VVnhmb:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVZAt4.append((name, package, version))
  if mode > 0:
   extensions = FF30Q2("ls %s -l | grep '^d' | awk '{print $9}'" % VVRjMt)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVZAt4:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VVfn31: name += "el"
      VVZAt4.append((name, VVRjMt + item, "-"))
   systemPlugins = FF30Q2("ls %s -l | grep '^d' | awk '{print $9}'" % VV0bR7)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVZAt4:
      if item.lower() == row[0].lower():
       break
     else:
      VVZAt4.append((item, VV0bR7 + item, "-"))
  if not VVZAt4:
   FFryuM(self, "No packages found!")
   return
  if VVxL8T:
   VVZAt4.sort(key=lambda x: x[0].lower())
   VVxL8T.VVlCGq(VVZAt4, title)
  else:
   widths = (20, 50, 30)
   VVoXaA = None
   VVUm5B = None
   if mode == 0:
    VVr0hN = ("Install" , self.VVb9dr   , [])
    VVoXaA = ("Download" , self.VV9pcu   , [])
    VVUm5B = ("Filter"  , self.VVcSqn , [])
   elif mode == 1:
    VVr0hN = ("Uninstall", self.VV3z22, [])
   elif mode == 2:
    VVr0hN = ("Uninstall", self.VV3z22, [])
    widths= (18, 57, 25)
   VVZAt4.sort(key=lambda x: x[0].lower())
   VVMCbu = ("Package Info.", self.VV1Gsw, [])
   header   = ("Name" ,"Package" , "Version" )
   FFfJU2(self, None, header=header, VVZAt4=VVZAt4, VVbiLs=widths, VVNdFV=28, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VV30ES=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVXsDY="#22110011", VVEEoV="#22191111", VVasam="#22191111", VVhaQs="#00003030", VVAXDQ="#00333333")
 def VV1Gsw(self, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVyvVo, VVxL8T, colList[1]))
 def VVyvVo(self, VVxL8T, pkg):
  if pathExists(pkg):
   pkg, err = CCiRwv.VVgXQW(pkg)
   if err:
    FFe82w(VVxL8T, err, 1000)
    return
  CCiRwv.VVlNoe(self, pkg)
 def VVcSqn(self, VVxL8T, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVGIDM = []
  VVGIDM.append(("All Packages", "all"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVGIDM.append(VVVgKz)
  for word in words:
   VVGIDM.append((word, word))
  FFzctu(self, BF(self.VVRT3t, VVxL8T), VVGIDM=VVGIDM, title="Select Filter")
 def VVRT3t(self, VVxL8T, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFVCur(VVxL8T, BF(self.VVkMpl, 0, grep, VVxL8T, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VV3z22(self, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVy3mK, VVxL8T, colList[1]))
 def VVy3mK(self, VVxL8T, package):
  if pathExists(package):
   pkg, err = CCiRwv.VVgXQW(package)
   if pkg:
    package = pkg
  if package.startswith((VVRjMt, VV0bR7)):
   FFP9Be(self, BF(self.VVl6s2, VVxL8T, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVGIDM = []
   VVGIDM.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVGIDM.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVGIDM.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFzctu(self, BF(self.VVfEJq, VVxL8T, package), VVGIDM=VVGIDM)
 def VVl6s2(self, VVxL8T, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VV18Av)
  FF8jLK(self, cmd, VVZgJA=BF(self.VVjd02, VVxL8T))
 def VVfEJq(self, VVxL8T, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVNK7J
   elif item == "remove_ForceRemove"  : cmdOpt = VVgFzV
   elif item == "remove_IgnoreDepends"  : cmdOpt = VVXzTR
   FFP9Be(self, BF(self.VVM0Cg, VVxL8T, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVM0Cg(self, VVxL8T, package, cmdOpt):
  self.lastSelectedRow = VVxL8T.VVsf2R()
  cmd = FFM6zB(cmdOpt, package)
  if cmd : FF8jLK(self, cmd, VVZgJA=BF(self.VVjd02, VVxL8T))
  else : FFRzIz(self)
 def VVjd02(self, VVxL8T):
  VVxL8T.cancel()
  FFaHKF()
 def VVb9dr(self, VVxL8T, title, txt, colList):
  package  = colList[1]
  VVGIDM = []
  VVGIDM.append(("Install Package"        , "install_CheckVersion" ))
  VVGIDM.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVGIDM.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVGIDM.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVGIDM.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFzctu(self, BF(self.VVy9iU, package), VVGIDM=VVGIDM)
 def VVy9iU(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VVP2Dj
   elif item == "install_ForceReinstall" : cmdOpt = VV80Ym
   elif item == "install_ForceOverwrite" : cmdOpt = VVCu09
   elif item == "install_ForceDowngrade" : cmdOpt = VVhCIY
   elif item == "install_IgnoreDepends" : cmdOpt = VVxBkr
   FFP9Be(self, BF(self.VVoXz5, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVoXz5(self, package, cmdOpt):
  cmd = FFM6zB(cmdOpt, package)
  if cmd : FF8jLK(self, cmd, VVZgJA=FFaHKF, checkNetAccess=True)
  else : FFRzIz(self)
 def VV9pcu(self, VVxL8T, title, txt, colList):
  package  = colList[1]
  FFP9Be(self, BF(self.VV7rP2, package), "Download Package ?\n\n%s" % package)
 def VV7rP2(self, package):
  if CCXzSR.VVGqI0():
   cmd = FFM6zB(VVmclw, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFpC0R(success, VVijSd))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFpC0R(fail, VVWABP))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF8jLK(self, cmd, VVba7Y=[VVWABP, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFRzIz(self)
  else:
   FFryuM(self, "No internet connection !")
 @staticmethod
 def VVTsh3(SELF):
  cmd = FFthHn(VVJwhx, "")
  if cmd : FF8jLK(SELF, cmd, checkNetAccess=True)
  else : FFRzIz(SELF)
 @staticmethod
 def VVgXQW(path):
  pkg = err = ""
  if pathExists(path):
   for line in FF30Q2(FFM6zB(VVjJTW, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVlNoe(SELF, package, title=""):
  title = title or package
  infoCmd  = FFM6zB(VVRLzP, package)
  filesCmd = FFM6zB(VVOU4o, package)
  listInstCmd = FFthHn(VVH9np, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFWads(VVWhci)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFpC0R(notInst, VVnviq))
   cmd += "else "
   cmd +=   FFmeBG("System Info", VVWhci)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFmeBG("Related Files", VVWhci)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FF0JeX(SELF, cmd, title=title)
  else:
   FFRzIz(SELF, title=title)
class CCKKWJ():
 def VVWBYU(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVsWf4()
 def VVsWf4(self):
  files = FFqy37(VV90k3, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVGIDM = []
   for fil in files:
    VVGIDM.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVXsDY, VVEEoV = "#22221133", "#22221133"
   else    : VVXsDY, VVEEoV = "#22003344", "#22002233"
   VVV7uB  = ("Add new File", self.VVUFEM)
   FFzctu(self, self.VVpzLI, VVGIDM=VVGIDM, width=1100, VVV7uB=VVV7uB, VVfIfT="", minRows=4, VVXsDY=VVXsDY, VVEEoV=VVEEoV)
  else:
   FFP9Be(self, self.VVPnFm, "No files found.\n\nCreate a new file ?")
 def VVPnFm(self):
  path = self.VVOMAP()
  if fileExists(path) : self.VVsWf4()
  else    : FFqgHP(self, "Cannot create file", 1500)
 def VVUFEM(self, VVXrLB, path):
  path = self.VVOMAP()
  VVXrLB.VVzCFO((os.path.basename(path), path), isSort=True)
 def VVOMAP(self):
  path = "%s%s%s.xml" % (VV90k3, self.shareFilePrefix, FFOa0m())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVpzLI(self, path=None):
  if path:
   FFVCur(self, BF(self.VV33A0, path))
 def VV33A0(self, path):
  if not fileExists(path):
   FFAhcl(self, path)
   return
  elif not CCLyBs.VVzL6D(self, path, FFpdY0()):
   return
  else:
   self.shareFilePath = path
  if not CCgegl.VV7mKU(self):
   return
  tree = CCTc7M.VV6jUs(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCpURW.VVxszo()
  def VVR7gd(refCode):
   if   FFj8UV(refCode): return FFEK4e("DVB", VVUrbH)
   elif refCode in refLst     : return FFEK4e("IPTV", VVUrbH)
   else         : return ""
  VVnhmb= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVvzt6(ch)
   if ok:
    srcTxt = VVR7gd(srcRef)
    dstTxt = VVR7gd(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVnhmb:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVnhmb.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVnhmb:
   if self.shareIsRef : VVXsDY, VVEEoV, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVXsDY, VVEEoV, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VV6aZX = (""    , BF(self.VV1Nuh, dupl), [])
   VVMOfU = (""    , self.VVpeuH    , [])
   VVr0hN = ("Delete Entry" , self.VVBJBc   , [])
   VVoXaA = ("Add Entry"  , self.VV5gQB   , [])
   VVMCbu = (optTxt   , self.VV6fOV  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVyaAW = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVxL8T = FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=24, VV6aZX=VV6aZX, VVMOfU=VVMOfU, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVehvv=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVXsDY=VVXsDY, VVEEoV=VVEEoV, VVasam=VVEEoV, VVhaQs="#0a000000")
  else:
   FFryuM(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VV1Nuh(self, dupl, VVxL8T, title, txt, colList):
  if dupl:
   VVxL8T.VVurur("Skipped %d duplicate%s" % (dupl, FFlPiz(dupl)), 2000)
 def VVpeuH(self, VVxL8T, title, txt, colList):
  def VVR7gd(key, val): return "%s\t: %s\n" % (key, val or FFEK4e("?", VVWEO1))
  Keys = VVxL8T.VVoaZ9()
  Vals = VVxL8T.VVoYvr()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVR7gd(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVijSd, VVWEO1
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFDLqC(self, txt + txt1, title=title)
 def VVvzt6(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVBJBc(self, VVxL8T, title, txt, colList):
  if VVxL8T.VVsf2R() == 0 and VVxL8T.VVERJ7() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFP9Be(self, BF(self.VVUwUI, isLast, VVxL8T), ques)
 def VVUwUI(self, isLast, VVxL8T):
  if isLast:
   FFbUco(self.shareFilePath)
   VVxL8T.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVxL8T.VVoYvr()
   if self.VVRKLM(srcName, srcRef, dstName, dstRef):
    VVxL8T.VVO7yn()
    VVxL8T.VVncK2()
    FFqgHP(VVxL8T, "Deleted", 500, isGrn=True)
   else:
    FFqgHP(VVxL8T, "Cannot delete from file", 2000)
 def VV5gQB(self, VVxL8T, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVAB5v(VVxL8T, isDvb=True)
  else    : self.VVZx9k(VVxL8T, "Source Channel", "#22003344", "#22002233")
 def VVZx9k(self, mainTableInst, title, VVXsDY, VVEEoV):
  FFzctu(self, BF(self.VVENA5, mainTableInst, title), VVGIDM=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVXsDY=VVXsDY, VVEEoV=VVEEoV)
 def VVENA5(self, mainTableInst, title, item=None):
  if item:
   FFVCur(mainTableInst, BF(self.VVyKn7, mainTableInst, title, item), clearMsg=False)
 def VVyKn7(self, mainTableInst, title, item):
  FFqgHP(mainTableInst)
  if item == "DVB": self.VVAB5v(mainTableInst, isDvb=True)
  else   : self.VVAB5v(mainTableInst, isDvb=False)
 def VVieWb(self, mainTableInst, chType, VVxL8T, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVxL8T.VVsf2R()
  if   chType == "DVB" : FFSKZx(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFSKZx(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVWcfU()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFryuM(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVIXwa(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVyCTE((str(mainTableInst.VVERJ7() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFqgHP(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFqgHP(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFqgHP(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVAB5v(mainTableInst, isDvb=False)
   else    : FFEuIr(BF(self.VVZx9k, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVxL8T.cancel()
 def VVdHvk(self, item, VVxL8T, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVxL8T.VVyaYN(ndx)
 def VVAB5v(self, VVxL8T, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVieWb, VVxL8T, typ)
  doneFnc = BF(self.VVdHvk, typ)
  if isDvb: CCKKWJ.VVaJmA(VVxL8T , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCKKWJ.VV9LHF(VVxL8T, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVaJmA(SELF, title, okFnc, doneFnc=None):
  FFVCur(SELF, BF(CCKKWJ.VVFCcw, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVFCcw(SELF, title, okFnc, doneFnc=None):
  VVnhmb, err = CCTc7M.VVKjmx(SELF, CCTc7M.VVp7EA)
  if VVnhmb:
   color = "#0a000022"
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVRWOd = ("Select" , okFnc, [])
   VV6aZX= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVyaAW = (LEFT  , LEFT  , CENTER, LEFT    )
   FFfJU2(SELF, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVXsDY=color, VVEEoV=color, VVasam=color, VVRWOd=VVRWOd, VV6aZX=VV6aZX, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFryuM(SELF, "No DVB Services !")
 @staticmethod
 def VV9LHF(SELF, title, okFnc, doneFnc=None):
  FFVCur(SELF, BF(CCKKWJ.VVwcCL, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVwcCL(SELF, title, okFnc, doneFnc=None):
  VVnhmb = CCKKWJ.VVUGLP()
  if VVnhmb:
   color = "#0a112211"
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVRWOd = ("Select" , okFnc, [])
   VV6aZX= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFfJU2(SELF, None, title=title, header=header, VVZAt4=VVnhmb, VVbiLs=widths, VVNdFV=26, VVXsDY=color, VVEEoV=color, VVasam=color, VVRWOd=VVRWOd, VV6aZX=VV6aZX, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFryuM(SELF, "No IPTV Services !")
 @staticmethod
 def VVUGLP():
  VVnhmb = []
  files  = CCDrYI.VVSss8()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FF3unD(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVgs9R = span.group(1)
    else : VVgs9R = ""
    VVgs9R_lCase = VVgs9R.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVnhmb.append((chName, VVgs9R, url, refCode))
  return VVnhmb
 def VVIXwa(self, srcName, srcRef, dstName, dstRef):
  tree = CCTc7M.VV6jUs(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVpsrg(tree, root)
  return True
 def VVRKLM(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCTc7M.VV6jUs(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVvzt6(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVpsrg(tree, root)
  return found
 def VVpsrg(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCTc7M.VVJtQe(xmlTxt)
  parser = CCTc7M.CC0WXT()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VV6fOV(self, VVxL8T, title, txt, colList):
  if self.onlyEpg:
   self.VVDxvs(VVxL8T, "epg")
  else:
   if self.shareIsRef:
    FFP9Be(self, BF(FFVCur, VVxL8T, BF(self.VVGG7U, VVxL8T)), "Copy all References from Source to Destination ?")
   else:
    VVGIDM = []
    VVGIDM.append(("Copy EPG\t (All List)" , "epg"  ))
    VVGIDM.append(("Copy Picons\t (All List)" , "picon" ))
    FFzctu(self, BF(self.VVDxvs, VVxL8T), VVGIDM=VVGIDM, width=1000)
 def VVDxvs(self, VVxL8T, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVgW31  , "EPG"
   elif item == "picon": fnc, txt = self.VVlODE , "PIcons"
   title = "Copy %s" % txt
   tot   = VVxL8T.VVERJ7()
   FFP9Be(self, BF(FFVCur, VVxL8T, BF(fnc, VVxL8T, title)), "Overwrite %s for %d Service%s ?" % (FFEK4e(txt, VVWhci), tot, FFlPiz(tot)), title=title)
 def VVGG7U(self, VVxL8T):
  files = CCDrYI.VVSss8()
  totChange = 0
  if files:
   for path in files:
    txt = FF3unD(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVxL8T.VVWcfU():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFWH63()
  tot = VVxL8T.VVERJ7()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFDLqC(self, txt)
 def VVlODE(self, VVxL8T, title):
  if not iCopyfile:
   FFryuM(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CC9p8T.VVH8Sz()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVxL8T.VVWcfU():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVxL8T.VVERJ7()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFDLqC(self, txt, title=title)
 def VVgW31(self, VVxL8T, title):
  txt, err = CCgL5j.VVZ8hJ(VVxL8T, title)
  if err : FFryuM(self, err, title=title)
  else : FFDLqC(self, txt, title=title)
 class CC0WXT(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VV6jUs(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCTc7M.CC0WXT())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFEK4e("XML Parse Error in:", VVWEO1), path)
   txt += "%s\n%s\n\n" % (FFEK4e("Error:", VVWEO1), str(e))
   FFDLqC(SELF, txt, VVasam="#11220000", title=title)
   return None
 @staticmethod
 def VVJtQe(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCgL5j(Screen, CCKKWJ):
 VVLmi9  = "BDTSE"
 VVox66   = "save"
 VVbtGx   = "load"
 VV65bO  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCgL5j.VVc0KU()
  qUrl, iptvRef = CCDrYI.VVPFFr(self)
  VVGIDM = []
  VVGIDM.append((VVUrbH + "Cache File Info." , "inf"))
  VVGIDM.append(VVVgKz)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVGIDM.append(FFzUJ4("Save EPG to File%s" % fTxt , self.VVox66, valid))
  VVGIDM.append(FFzUJ4("Load EPG from File%s" % fTxt , self.VVbtGx, valid))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((VVnviq + "Delete EPG (from RAM only)", self.VV65bO))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(FFzUJ4("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVGIDM.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Translate Current Channel EPG %s(Experimental)" % VVnviq, "VVNed7"))
  FFCOTe(self, VVGIDM=VVGIDM)
  self.onShown.append(self.VVg3Fx)
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVZW25()
   elif item in (self.VVox66, self.VVbtGx, self.VV65bO):
    reset = item == self.VVbtGx
    FFP9Be(self, BF(FFVCur, self, BF(self.VVrctj, item, reset)), VVcsne="Continue ?")
   elif item == "refreshIptvEPG"  : CCDrYI.VVoFXZ(self)
   elif item == "VVNed7" : self.VVNed7()
   elif item == "copyEpg"    : self.VVWBYU(False, onlyEpg=True)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VVrctj(self, act, reset=False):
  ok = CCgL5j.VVFPYj(act)
  if ok:
   if reset:
    CCgL5j.VViO1C(self)
   FF6mzu(self, "Done")
  else:
   FF6mzu(self, "Failed!")
 def VVZW25(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCgL5j.VVc0KU()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFEK4e("File not found (check System EPG settings).", VVnviq))
   FFDLqC(self, txt, title=title)
  else:
   FFryuM(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVYHIE():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVNed7(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVRWOd  = (""  , BF(self.VVY4bW, title, True) , [])
  VVoXaA = ("Start" , BF(self.VVY4bW, title, False), [])
  VVUm5B = ("Change Language", self.VVEGK9      , [])
  widths  = (70 , 30)
  VVyaAW = (LEFT , CENTER)
  FFfJU2(self, None, title=title, VVZAt4=self.VVDJcA(), VVyaAW=VVyaAW, VVbiLs=widths, width=1200, vMargin=20, VVNdFV=30, VVRWOd=VVRWOd, VVoXaA=VVoXaA, VVUm5B=VVUm5B, VV4wMI=2
    , VVXsDY="#11201010", VVEEoV=bg, VVasam=bg, VVhaQs="#00004455", VVAXDQ=bg)
 def VVDJcA(self):
  Def, ch = "DISABLED", dict(CCgL5j.VVYHIE())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVZAt4 = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVZAt4
 def VVEGK9(self, VVxL8T, title, txt, colList):
  ndx = VVxL8T.VVsf2R()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CC6wkq.VVwW0V(self, confItem, title, lst=CCgL5j.VVYHIE(), cbFnc=BF(self.VV2gkM, VVxL8T), isSave=True)
 def VV2gkM(self, VVxL8T):
  for ndx, row in enumerate(self.VVDJcA()):
   VVxL8T.VVk6Jb(ndx, row)
 def VVY4bW(self, Title, isAsk, VVxL8T, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFqgHP(VVxL8T, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
   refCode, evList, err = CCgL5j.VVFyjU(refCode)
   fnc = BF(self.VVQ26n, Title, refCode, evList, VVxL8T)
   if   err : FFryuM(self, err, title=Title)
   elif isAsk : FFP9Be(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVQ26n(self, title, refCode, evList, VVxL8T):
  self.session.open(CCChia, barTheme=CCChia.VV1d7P, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVXhvM, evList)
      , VViIM0 = BF(self.VVpszz, title, refCode))
  VVxL8T.cancel()
 def VVXhvM(self, evList, VVWRJ1):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVWRJ1.VVsWOI(totEv)
  VVWRJ1.VVfN1b = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCgL5j.VVKoSn(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   VVWRJ1.VVYksR(1)
   VVWRJ1.VV6QlR(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVWRJ1.VVfN1b = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVpszz(self, title, refCode, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVfN1b
  if newLst: totEv, totOK = CCgL5j.VVpL8h(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCgL5j.VVECSd()
   CCgL5j.VViO1C(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFDLqC(self, txt, title=title)
 @staticmethod
 def VVKoSn(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVR7gd(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCgL5j.VVdXAa(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVR7gd, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVdXAa(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFO7Oa(txt))
   txt, err = CCDrYI.VVI941(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFuEJn(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCgL5j.VVaanV(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVc0KU():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFl8II(path)
   szTxt = CCLyBs.VVM24t(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VV0jn2():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVECSd(): CCgL5j.VVFPYj(CCgL5j.VVox66)
 @staticmethod
 def VVFPYj(act):
  ec, inst = CCgL5j.VV0jn2()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VViO1C(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVFyjU(refCode):
  ec, inst = CCgL5j.VV0jn2()
  if inst:
   try:
    evList = inst.lookupEvent([CCgL5j.VVLmi9, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVpL8h(refCode, events, longDescDays=0):
  ec, inst = CCgL5j.VV0jn2()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVA7Lr(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCgL5j.VV0jn2()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCgL5j.VVjnWb(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCVNso.CCgL5j(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVjnWb(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCgL5j.VVzfs9(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVhFfu(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCgL5j.VV0jn2()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCgL5j.VVjnWb(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFkL2p(evTime)
       evEndTxt  = FFkL2p(evEnd)
       evDurTxt  = FFTaUe(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFTaUe(evPos)
        evRem = evEnd - now
        evRemTxt = FFTaUe(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFTaUe(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVzfs9(event):
  genre = PR = ""
  try:
   genre  = CCgL5j.VVKFgL(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCgL5j.VVGcLc(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVGcLc(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVKFgL(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCgL5j.VVxuH1()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVxuH1():
  path = VV6OO5 + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FF3unD(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FF3unD(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVZ8hJ(VVxL8T, title):
  ec, inst = CCgL5j.VV0jn2()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVxL8T.VVWcfU():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCgL5j.VVLmi9, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCgL5j.VVpL8h(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCgL5j.VVECSd()
  txt  = "Services\t: %d\n"  % VVxL8T.VVERJ7()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVSVED(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCgL5j.VVSi26(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCgL5j.VVSi26(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCgL5j.VVSi26(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVSi26(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCgL5j.VVjnWb(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCgL5j.VVKoSn(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFEK4e(evName, VVfZXg)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFEK4e(evNameTransl, VVfZXg))
    if evTime           : txt += "Start Time\t: %s\n" % FFkL2p(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFkL2p(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFTaUe(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFTaUe(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFTaUe(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFEK4e(evShort, VVZoWi)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFEK4e(evDesc , VVZoWi)
    if txt:
     txt = FFEK4e("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVfZXg) + txt
  return txt
 @staticmethod
 def VVaanV(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCTc7M(Screen, CCKKWJ):
 VVZpna  = 0
 VVKAvz = 1
 VVfonr  = 2
 VVclL2  = 3
 VVAtdA = 4
 VV5ZYX = 5
 VVvHcL = 6
 VVp7EA   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVt58t = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVGIDM = self.VV5t6f()
  FFCOTe(self, VVGIDM=VVGIDM, title="Services/Channels")
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self["myMenu"].setList(self.VV5t6f())
  FFyjr3(self["myMenu"])
  FFkK1B(self)
 def VV5t6f(self):
  VVGIDM = []
  c = VVUrbH
  VVGIDM.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVGIDM.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVGIDM.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVGIDM.append(VVVgKz)
  c = VVfZXg
  VVGIDM.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVGIDM.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVGIDM.append((VVWEO1 + "More tables ..."     , "VV1XdH"    ))
  c = VVZoWi
  VVGIDM.append(VVVgKz)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVGIDM.append((c + txt          , "VV3qIY"  ))
  else : VVGIDM.append((txt           ,          ))
  VVGIDM.append((c + 'Export Services to "channels.xml"'    , "VV2GkG"      ))
  VVGIDM.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVUVBT
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVGIDM.append((c + "Invalid Services Cleaner"       , "VVWvjq"    ))
  c = VVUVBT
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c + "Delete Channels with no names"     , "VVDtdP"    ))
  VVGIDM.append((c + "Delete Empty Bouquets"       , "VVDogl"     ))
  VVGIDM.append(VVVgKz)
  VVlXNT, VVg1DL = CCTc7M.VVws8E()
  if fileExists(VVlXNT):
   enab = fileExists(VVg1DL)
   if enab: VVGIDM.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVGIDM.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVGIDM.append(("Reset Parental Control Settings"      , "VVOFQK"    ))
  VVGIDM.append(("Reload Channels and Bouquets"       , "VVIIvW"      ))
  return VVGIDM
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCTKa3.VV3qn6(self.session)
   elif item == "openSignal"       : FFtC9K(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFNmLy(self, fncMode=CCVNso.VV9EG1)
   elif item == "lameDB_allChannels_with_refCode"  : FFVCur(self, self.VVOuhb)
   elif item == "lameDB_allChannels_with_tranaponder" : FFVCur(self, self.VVLIao)
   elif item == "VV1XdH"     : self.VV1XdH()
   elif item == "VV3qIY"  : CCYcg2.VV3qIY(self)
   elif item == "VV2GkG"      : self.VV2GkG()
   elif item == "copyEpgPicons"      : self.VVWBYU(False)
   elif item == "SatellitesCleaner"     : FFVCur(self, self.FFVCur_SatellitesCleaner)
   elif item == "VVWvjq"    : FFVCur(self, BF(self.VVWvjq))
   elif item == "VVDtdP"    : FFVCur(self, self.VVDtdP)
   elif item == "VVDogl"     : self.VVDogl(self)
   elif item == "enableHiddenChannels"     : self.VVmCuo(True)
   elif item == "disableHiddenChannels"    : self.VVmCuo(False)
   elif item == "VVOFQK"    : FFP9Be(self, self.VVOFQK, "Reset and Restart ?")
   elif item == "VVIIvW"      : FFVCur(self, BF(CCTc7M.VVIIvW, self))
 def VV1XdH(self):
  VVGIDM = []
  VVGIDM.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVGIDM.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVGIDM.append(("Services with PIcons for the System"  , "VVPlbG"    ))
  VVGIDM.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVGIDM.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFzctu(self, self.VVpqLe, VVGIDM=VVGIDM, title="Service Information", VVglmG=True)
 def VVpqLe(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFVCur(self, BF(self.VVOTNk, title))
   elif ref == "parentalControlChannels"   : FFVCur(self, BF(self.VV6NaF, title))
   elif ref == "showHiddenChannels"    : FFVCur(self, BF(self.VV5EdP, title))
   elif ref == "VVPlbG"    : FFVCur(self, BF(self.VVXppG, title))
   elif ref == "servicesWithMissingPIcons"   : FFVCur(self, BF(self.VVYbKE, title))
   elif ref == "TranspondersStats"     : FFVCur(self, BF(self.VVzuZz, title))
   elif ref == "SatellitesXmlStats"    : FFVCur(self, BF(self.VVPRJy, title))
 def VV2GkG(self):
  VVGIDM = []
  VVGIDM.append(("All DVB-S/C/T Services", "all"))
  VVGIDM.extend(CCpURW.VVAnRt())
  FFzctu(self, self.VVqeDg, VVGIDM=VVGIDM, title="", VVglmG=True)
 def VVqeDg(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCTc7M.VVuOkS("1:7:")
   else   : lst = FFsac0(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFFcgz(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFUkkg(r)  : sat = "Stream Relay"
       elif FFkZVp(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FF80Mz(CFG.exportedTablesPath.getValue()), FFOa0m())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF6mzu(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFqgHP(self, "No Services found !", 1500)
 @staticmethod
 def VVIIvW(SELF):
  FFWH63()
  FF6mzu(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVOuhb(self):
  self.VVt58t = None
  self.lastfilterUsed  = None
  self.filterObj   = CCgoW8(self)
  VVnhmb, err = CCTc7M.VVKjmx(self, self.VVZpna)
  if VVnhmb:
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVRWOd  = ("Zap"   , self.VVwifv     , [])
   VVMOfU = (""    , self.VVKLPL   , [])
   VVMCbu = ("Options"  , self.VVRP5c , [])
   VVoXaA = ("Current Service", self.VV8n1J , [])
   VVUm5B = ("Filter"   , self.VVo1J8  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVyaAW  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindServices)
 def VVLIao(self):
  self.VVt58t = None
  self.lastfilterUsed  = None
  self.filterObj   = CCgoW8(self)
  VVnhmb, err = CCTc7M.VVKjmx(self, self.VVKAvz)
  if VVnhmb:
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVRWOd  = ("Zap"   , self.VVwifv      , [])
   VVMOfU = (""    , self.VVKLPL    , [])
   VVoXaA = ("Current Service", self.VV8n1J  , [])
   VVMCbu = ("Options"  , self.VVIkr7 , [])
   VVUm5B = ("Filter"   , self.VVhtFt  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVyaAW  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindServices)
 def VVRP5c(self, VVxL8T, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCMUYz(self, VVxL8T)
  VVGIDM = []
  isMulti = VVxL8T.VV1dHJ
  if isMulti:
   refCodeList = VVxL8T.VVgXLx(3)
   if refCodeList:
    VVGIDM.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVGIDM.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVGIDM.append(VVVgKz)
    VVGIDM.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVGIDM.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVGIDM.append(VVVgKz)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVGIDM.append((txt1, "parentalControl_add" ))
    VVGIDM.append((txt2,        ))
   else:
    VVGIDM.append((txt1,       ))
    VVGIDM.append((txt2, "parentalControl_remove" ))
   VVGIDM.append(VVVgKz)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVGIDM.append((txt1, "hiddenServices_add"  ))
    VVGIDM.append((txt2,       ))
   else:
    VVGIDM.append((txt1,        ))
    VVGIDM.append((txt2, "hiddenServices_remove" ))
   VVGIDM.append(VVVgKz)
  cbFncDict = { "parentalControl_add"   : BF(self.VVnv69, VVxL8T, refCode, True)
     , "parentalControl_remove"  : BF(self.VVnv69, VVxL8T, refCode, False)
     , "hiddenServices_add"   : BF(self.VVLm9S, VVxL8T, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVLm9S, VVxL8T, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVaJjX, VVxL8T, True)
     , "parentalControl_sel_remove" : BF(self.VVaJjX, VVxL8T, False)
     , "hiddenServices_sel_add"  : BF(self.VVwRKm, VVxL8T, True)
     , "hiddenServices_sel_remove" : BF(self.VVwRKm, VVxL8T, False)
     }
  VVGIDM1, cbFncDict1 = CCTc7M.VVf2Oa(self, VVxL8T, servName, 3)
  VVGIDM.extend(VVGIDM1)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVtH9B(VVGIDM, cbFncDict)
 def VVIkr7(self, VVxL8T, title, txt, colList):
  servName = colList[0]
  mSel = CCMUYz(self, VVxL8T)
  VVGIDM, cbFncDict = CCTc7M.VVf2Oa(self, VVxL8T, servName, 3)
  mSel.VVtH9B(VVGIDM, cbFncDict)
 @staticmethod
 def VVf2Oa(SELF, VVxL8T, servName, refCodeCol):
  tot = VVxL8T.VVwKPO()
  if tot > 0:
   sTxt = FFEK4e("%d Service%s" % (tot, FFlPiz(tot)), VVfZXg)
   VVGIDM = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFLKj3(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFEK4e(servName, VVfZXg)
   VVGIDM = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCTc7M.VVKBbh, SELF, VVxL8T, refCodeCol, True)
     , "addToBouquet_one" : BF(CCTc7M.VVKBbh, SELF, VVxL8T, refCodeCol, False)
     }
  return VVGIDM, cbFncDict
 @staticmethod
 def VVKBbh(SELF, VVxL8T, refCodeCol, isMulti):
  picker = CCpURW(SELF, VVxL8T, "Add to Bouquet", BF(CCTc7M.VVIr7u, VVxL8T, refCodeCol, isMulti))
 @staticmethod
 def VVIr7u(VVxL8T, refCodeCol, isMulti):
  if isMulti : refCodeList = VVxL8T.VVgXLx(refCodeCol)
  else  : refCodeList = [VVxL8T.VVoYvr()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVnv69(self, VVxL8T, refCode, isAddToBlackList):
  VVxL8T.VV61sj("Processing ...")
  FFEuIr(BF(self.VVwRw4, VVxL8T, [refCode], isAddToBlackList))
 def VVaJjX(self, VVxL8T, isAddToBlackList):
  refCodeList = VVxL8T.VVgXLx(3)
  if not refCodeList:
   FFryuM(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVxL8T.VV61sj("Processing ...")
  FFEuIr(BF(self.VVwRw4, VVxL8T, refCodeList, isAddToBlackList))
 def VVwRw4(self, VVxL8T, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVCGMF, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVCGMF):
   lines = FF5p6q(VVCGMF)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVCGMF, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVxL8T.VV1dHJ
   if isMulti:
    self.VV4aRl(VVxL8T, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV4CcN(VVxL8T, refCode)
    VVxL8T.VVKZ4j()
  else:
   VVxL8T.VVurur("No changes")
 def VVLm9S(self, VVxL8T, refCode, isHide):
  title = "Change Hidden State"
  if FFj8UV(refCode):
   VVxL8T.VV61sj("Processing ...")
   ret = FFkDjt(refCode, isHide)
   if ret : FFVCur(self, BF(self.VV4CcN, VVxL8T, refCode))
   else : FFryuM(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFryuM(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV4CcN(self, VVxL8T, refCode):
  VVnhmb, err = CCTc7M.VVKjmx(self, self.VVZpna, VVR1ao=[3, [refCode], False])
  done = False
  if VVnhmb:
   data = VVnhmb[0]
   if data[3] == refCode:
    done = VVxL8T.VVkQYa(data)
  if not done:
   self.VVjOxN(VVxL8T, VVxL8T.VVPL4Q(), self.VVZpna)
  VVxL8T.VVKZ4j()
 def VV4aRl(self, VVxL8T, totRefCodes):
  VVnhmb, err = CCTc7M.VVKjmx(self, self.VVZpna, VVR1ao=self.VVt58t)
  VVxL8T.VVlCGq(VVnhmb)
  VVxL8T.VVAi8G(False)
  VVxL8T.VVurur("%d Processed" % totRefCodes)
 def VVwRKm(self, VVxL8T, isHide):
  refCodeList = VVxL8T.VVgXLx(3)
  if not refCodeList:
   FFryuM(self, "Nothing selected", title="Change Hidden State")
   return
  VVxL8T.VV61sj("Processing ...")
  FFEuIr(BF(self.VVNWMD, VVxL8T, refCodeList, isHide))
 def VVNWMD(self, VVxL8T, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFkDjt(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFWH63(True)
   self.VV4aRl(VVxL8T, len(refCodeList))
  else:
   VVxL8T.VVurur("No changes")
 def VVo1J8(self, VVxL8T, title, txt, colList):
  inFilterFnc = BF(self.VVebsk, VVxL8T) if self.VVt58t else None
  self.filterObj.VVzE9v(1, VVxL8T, 2, BF(self.VVASS2, VVxL8T), inFilterFnc=inFilterFnc)
 def VVASS2(self, VVxL8T, item):
  self.VVsNiB(VVxL8T, False, item, 2, self.VVZpna)
 def VVebsk(self, VVxL8T, VVXrLB, item):
  self.VVsNiB(VVxL8T, True, item, 2, self.VVZpna)
 def VVhtFt(self, VVxL8T, title, txt, colList):
  inFilterFnc = BF(self.VVEulW, VVxL8T) if self.VVt58t else None
  self.filterObj.VVzE9v(2, VVxL8T, 4, BF(self.VVETnY, VVxL8T), inFilterFnc=inFilterFnc)
 def VVETnY(self, VVxL8T, item):
  self.VVsNiB(VVxL8T, False, item, 4, self.VVKAvz)
 def VVEulW(self, VVxL8T, VVXrLB, item):
  self.VVsNiB(VVxL8T, True, item, 4, self.VVKAvz)
 def VVQBsN(self, VVxL8T, title, txt, colList):
  inFilterFnc = BF(self.VVVsVf, VVxL8T) if self.VVt58t else None
  self.filterObj.VVzE9v(0, VVxL8T, 4, BF(self.VVaggN, VVxL8T), inFilterFnc=inFilterFnc)
 def VVaggN(self, VVxL8T, item):
  self.VVsNiB(VVxL8T, False, item, 4, self.VVfonr)
 def VVVsVf(self, VVxL8T, VVXrLB, item):
  self.VVsNiB(VVxL8T, True, item, 4, self.VVfonr)
 def VVsNiB(self, VVxL8T, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVxL8T.VVJ5dP(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVt58t = None
  else:
   words, asPrefix = CCgoW8.VV15EP(words)
   self.VVt58t = [col, words, asPrefix]
  if words: FFVCur(VVxL8T, BF(self.VVjOxN, VVxL8T, title, mode), clearMsg=False)
  else : FFqgHP(VVxL8T, "Incorrect filter", 2000)
 def VVjOxN(self, VVxL8T, title, mode):
  VVnhmb, err = CCTc7M.VVKjmx(self, mode, VVR1ao=self.VVt58t, VVCFmo=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVxL8T.VVWcfU():
    try:
     ndx = VVnhmb.index(tuple(list(map(str.strip, row))))
     lst.append(VVnhmb[ndx])
    except:
     pass
   VVnhmb = lst
  if VVnhmb:
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVxL8T.VVlCGq(VVnhmb, title, VVj0IZMsg=True)
  else:
   FFqgHP(VVxL8T, "Not found!", 1500)
 def VV4BQl(self, title, VVZAt4, VVRWOd=None, VVMOfU=None, VVr0hN=None, VVoXaA=None, VVMCbu=None, VVUm5B=None):
  VVoXaA = ("Current Service", self.VV8n1J, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVyaAW = (LEFT  , LEFT  , CENTER, LEFT    )
  FFfJU2(self, None, title=title, header=header, VVZAt4=VVZAt4, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindServices)
 def VV8n1J(self, VVxL8T, title, txt, colList):
  self.VVV2uu(VVxL8T)
 def VVSyFp(self, VVxL8T, title, txt, colList):
  self.VVV2uu(VVxL8T, True)
 def VVV2uu(self, VVxL8T, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVxL8T.VVWFhX(colDict, VVO6nE=True)
   else:
    VVxL8T.VVvq3F(3, refCode, True)
   return
  FFryuM(self, "Cannot read current Reference Code !")
 def VVOTNk(self, title):
  self.VVt58t = None
  self.lastfilterUsed  = None
  self.filterObj   = CCgoW8(self)
  VVnhmb, err = CCTc7M.VVKjmx(self, self.VVfonr)
  if VVnhmb:
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVMOfU = (""    , self.VVJd1v , []      )
   VVoXaA = ("Current Service", self.VVSyFp  , []      )
   VVUm5B = ("Filter"   , self.VVQBsN   , [], "Loading Filters ..." )
   VVRWOd  = ("Zap"   , self.VVsLgv      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVyaAW  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVoXaA=VVoXaA, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindServices)
 def VVJd1v(self, VVxL8T, title, txt, colList):
  refCode  = self.VVx5KX(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFNmLy(self, fncMode=CCVNso.VVjRFt, refCode=refCode, chName=chName, text=txt)
 def VVsLgv(self, VVxL8T, title, txt, colList):
  refCode = self.VVx5KX(colList)
  FFnh1l(self, refCode)
 def VVwifv(self, VVxL8T, title, txt, colList):
  FFnh1l(self, colList[3])
 def VVx5KX(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VVvpiE(VVlXNT, mode=0):
  lines = FF5p6q(VVlXNT, encLst=["UTF-8"])
  return CCTc7M.VVhRUp(lines, mode)
 @staticmethod
 def VVhRUp(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVKjmx(SELF, mode, VVR1ao=None, VVCFmo=True, VVyxvV=True):
  VVlXNT, err = CCTc7M.VVcW6O(SELF, VVyxvV)
  if err:
   return None, err
  asPrefix = False
  if VVR1ao:
   filterCol = VVR1ao[0]
   filterWords = VVR1ao[1]
   asPrefix = VVR1ao[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCTc7M.VVZpna:
   blackList = None
   if fileExists(VVCGMF):
    blackList = FF5p6q(VVCGMF)
    if blackList:
     blackList = set(blackList)
  elif mode == CCTc7M.VVKAvz:
   tp = CCSMOW()
  VVPs5l, VVo54S = FFrYrU()
  if mode in (CCTc7M.VV5ZYX, CCTc7M.VVvHcL):
   VVnhmb = {}
  else:
   VVnhmb = []
  tagFound = False
  with ioOpen(VVlXNT, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFhNZa(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCTc7M.VVfonr:
       if sTypeInt in VVPs5l:
        STYPE = VVo54S[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVnhmb.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVnhmb.append(tRow)
       else:
        VVnhmb.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCTc7M.VVp7EA:
        VVnhmb.append((chName, chProv, sat, refCode))
       elif mode == CCTc7M.VV5ZYX:
        VVnhmb[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCTc7M.VVvHcL:
        VVnhmb[chName] = refCode
       elif mode == CCTc7M.VVZpna:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVnhmb.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVnhmb.append(tRow)
        else:
         VVnhmb.append(tRow)
       elif mode == CCTc7M.VVKAvz:
        if sTypeInt in VVPs5l:
         STYPE = VVo54S[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVIGT8(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVnhmb.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVnhmb.append(tRow)
        else:
         VVnhmb.append(tRow)
       elif mode == CCTc7M.VVclL2:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVnhmb.append((chName, chProv, sat, refCode))
       elif mode == CCTc7M.VVAtdA:
        VVnhmb.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVnhmb and VVCFmo:
   FFryuM(SELF, "No services found!")
  return VVnhmb, ""
 def VV6NaF(self, title):
  if fileExists(VVCGMF):
   lines = FF5p6q(VVCGMF)
   if lines:
    newRows = []
    VVnhmb, err = CCTc7M.VVKjmx(self, self.VVAtdA)
    if VVnhmb:
     lines = set(lines)
     for item in VVnhmb:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVnhmb = newRows
      VVnhmb.sort(key=lambda x: x[0].lower())
      VVMOfU = ("", self.VVKLPL, [])
      VVRWOd = ("Zap", self.VVwifv, [])
      self.VV4BQl(title, VVnhmb, VVRWOd=VVRWOd, VVMOfU=VVMOfU)
     else:
      FFDLqC(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVnhmb)))
   else:
    FF6mzu(self, "No active Parental Control services.", FFpdY0())
  else:
   FFAhcl(self, VVCGMF)
 def VV5EdP(self, title):
  VVnhmb, err = CCTc7M.VVKjmx(self, self.VVclL2)
  if VVnhmb:
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVMOfU = ("" , self.VVKLPL, [])
   VVRWOd  = ("Zap", self.VVwifv, [])
   self.VV4BQl(title, VVnhmb, VVRWOd=VVRWOd, VVMOfU=VVMOfU)
  elif err:
   pass
  else:
   FF6mzu(self, "No hidden services.", FFpdY0())
 def VVWvjq(self):
  title = "Services unused in Tuner Configuration"
  VVlXNT, err = CCTc7M.VVcW6O(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCTc7M.VVT6ce()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVL639(str(item[0]))
    nsLst.add(ns)
  sysLst = CCTc7M.VVuOkS("1:7:")
  tpLst  = CCTc7M.VVvpiE(VVlXNT, mode=1)
  VVnhmb = []
  for refCode, chName in sysLst:
   servID = CCTc7M.VVu6SV(refCode)
   tpID = CCTc7M.VVYLV9(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVnhmb.append((chName, FFFcgz(refCode, False), refCode, servID))
  if VVnhmb:
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVMCbu = ("Options"   , BF(self.VV7j8u, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVyaAW  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVMCbu=VVMCbu, VVXsDY="#0a001122", VVEEoV="#0a001122", VVasam="#0a001122", VVhaQs="#00004455", VVAXDQ="#0a333333", VVilD4="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF6mzu(self, "No invalid service found !", title=title)
 def VV7j8u(self, Title, VVxL8T, title, txt, colList):
  mSel = CCMUYz(self, VVxL8T)
  isMulti = VVxL8T.VV1dHJ
  if isMulti : txt = "Remove %s Services" % FFEK4e(str(VVxL8T.VVwKPO()), VVWEO1)
  else  : txt = "Remove : %s" % FFEK4e(VVxL8T.VVoYvr()[0], VVWEO1)
  VVGIDM = [(txt, "del")]
  cbFncDict = {"del": BF(FFVCur, VVxL8T, BF(self.VVDc5f, VVxL8T, Title))}
  mSel.VVtH9B(VVGIDM, cbFncDict)
 def VVDc5f(self, VVxL8T, title):
  VVlXNT, err = CCTc7M.VVcW6O(self, title=title)
  if err:
   return
  isMulti = VVxL8T.VV1dHJ
  skipLst = []
  if isMulti : skipLst = VVxL8T.VVgXLx(3)
  else  : skipLst = [VVxL8T.VVoYvr()[3]]
  tpLst = CCTc7M.VVvpiE(VVlXNT, mode=0)
  servLst = CCTc7M.VVvpiE(VVlXNT, mode=10)
  tmpDbFile = VVlXNT + ".tmp"
  lines   = FF5p6q(VVlXNT)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFyakl("mv -f '%s' '%s'" % (tmpDbFile, VVlXNT))
  VVnhmb = []
  for row in VVxL8T.VVWcfU():
   if not row[3] in skipLst:
    VVnhmb.append(row)
  FFWH63()
  FFDLqC(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVnhmb:
   VVxL8T.VVlCGq(VVnhmb, title)
   VVxL8T.VVAi8G(False)
  else:
   VVxL8T.cancel()
 def VVzuZz(self, title):
  VVlXNT, err = CCTc7M.VVcW6O(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVrSnu(VVlXNT)
  txt = FFEK4e("Total Transponders:\n\n", VVN1ah)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFEK4e("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVN1ah)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFAWqG(item), satList.count(item))
  FFDLqC(self, txt, title)
 def VVrSnu(self, VVlXNT):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVlXNT, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVPRJy(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFAhcl(self, path, title=title)
   return
  elif not CCLyBs.VVzL6D(self, path, title):
   return
  if not CCgegl.VV7mKU(self):
   return
  tree = CCTc7M.VV6jUs(self, path, title=title)
  if not tree:
   return
  VVnhmb = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFhNZa(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVnhmb.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVnhmb:
   VVnhmb.sort(key=lambda x: int(x[1]))
   VVoXaA = ("Current Satellite", BF(self.VV0QBa, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVyaAW  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=25, VVCR7e=1, VVoXaA=VVoXaA, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFryuM(self, "No data found !", title=title)
 def VV0QBa(self, satCol, VVxL8T, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  sat = FFFcgz(refCode, False)
  for ndx, row in enumerate(VVxL8T.VVWcfU()):
   if sat == row[satCol].strip():
    VVxL8T.VVyaYN(ndx)
    break
  else:
   FFqgHP(VVxL8T, "No listed !", 1500)
 def FFVCur_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFryuM(self, "No Satellites found !")
   return
  usedSats = CCTc7M.VVT6ce()
  VVnhmb = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVnhmb.append((sat[1], posTxt, FFhNZa(sat[0]), tuners, str(posVal)))
  if VVnhmb:
   VVasam = "#11222222"
   VVnhmb.sort(key=lambda x: int(x[1]))
   VVoXaA = ("Current Satellite" , BF(self.VV0QBa, 2) , [])
   VVMCbu = ("Options"   , self.VVLv4M  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVyaAW  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=28, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVXsDY=VVasam, VVEEoV=VVasam, VVasam=VVasam, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFryuM(self, "No data found !")
 def VVLv4M(self, VVxL8T, title, txt, colList):
  mSel = CCMUYz(self, VVxL8T)
  isMulti = VVxL8T.VV1dHJ
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFEK4e(str(VVxL8T.VVwKPO()), VVWEO1)
  else  : txt = "Remove ALL Services on : %s" % FFEK4e(VVxL8T.VVoYvr()[0], VVWEO1)
  VVGIDM = []
  VVGIDM.append((txt, "deleteSat"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Delete Empty Bouquets", "VVDogl"))
  cbFncDict = { "deleteSat"   : BF(FFVCur, VVxL8T, BF(self.VVBsxX, VVxL8T))
     , "VVDogl" : BF(self.VVDogl, VVxL8T)
     }
  mSel.VVtH9B(VVGIDM, cbFncDict)
 def VVBsxX(self, VVxL8T):
  posLst = []
  isMulti = VVxL8T.VV1dHJ
  posLst = []
  if isMulti : posLst = VVxL8T.VVgXLx(4)
  else  : posLst = [VVxL8T.VVoYvr()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVL639(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVYCH9(nsLst)
  FFWH63(True)
  FFDLqC(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVDogl(self, winObj):
  title = "Delete Empty Bouquets"
  FFP9Be(self, BF(FFVCur, winObj, BF(self.VVwKeX, title)), "Delete bouquets with no services ?", title=title)
 def VVwKeX(self, title):
  bList = CCpURW.VVzbQv()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCpURW.VVRe5b(bRef)
    bPath = VVWgjG + bFile
    FFbUco(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVWgjG + fil
     if fileExists(path):
      lines = FF5p6q(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFWH63(True)
  if bNames: txt = "%s\n\n%s" % (FFEK4e("Deleted Bouquets:", VVfZXg), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFDLqC(self, txt, title=title)
 def VVL639(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVYCH9(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVWgjG)
  for srcF in files:
   if fileExists(srcF):
    lines = FF5p6q(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFKVYD(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VVXppG(self, title)   : self.VVPlbG(title, True)
 def VVYbKE(self, title) : self.VVPlbG(title, False)
 def VVPlbG(self, title, isWithPIcons):
  piconsPath = CC9p8T.VVH8Sz()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CC9p8T.VVCByH(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVnhmb, err = CCTc7M.VVKjmx(self, self.VVAtdA)
    if VVnhmb:
     channels = []
     for (chName, chProv, sat, refCode) in VVnhmb:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFQHiZ(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVnhmb)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVR7gd(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVR7gd("PIcons Path"  , piconsPath)
     txt += VVR7gd("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVR7gd("Total services" , totalServices)
     txt += VVR7gd("With PIcons"  , totalWithPIcons)
     txt += VVR7gd("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFDLqC(self, txt)
     else:
      VVMOfU     = (""      , self.VVKLPL , [])
      if isWithPIcons : VVUm5B = ("Export Current PIcon", self.VVvwHj  , [])
      else   : VVUm5B = None
      VVMCbu     = ("Statistics", FFDLqC, [txt])
      VVRWOd      = ("Zap", self.VVwifv, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VV4BQl(title, channels, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVMCbu=VVMCbu, VVUm5B=VVUm5B)
   else:
    FFryuM(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFryuM(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVKLPL(self, VVxL8T, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFNmLy(self, fncMode=CCVNso.VVjRFt, refCode=refCode, chName=chName, text=txt)
 def VVvwHj(self, VVxL8T, title, txt, colList):
  png, path = CC9p8T.VVlW3d(colList[3], colList[0])
  if path:
   CC9p8T.VVanRw(self, png, path)
 @staticmethod
 def VVws8E():
  VVlXNT  = "%slamedb" % VVWgjG
  VVg1DL = "%slamedb.disabled" % VVWgjG
  return VVlXNT, VVg1DL
 @staticmethod
 def VVbHSy():
  VVuQny  = "%slamedb5" % VVWgjG
  VVHXCZ = "%slamedb5.disabled" % VVWgjG
  return VVuQny, VVHXCZ
 def VVmCuo(self, isEnable):
  VVlXNT, VVg1DL = CCTc7M.VVws8E()
  if isEnable and not fileExists(VVg1DL):
   FF6mzu(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVlXNT):
   FFryuM(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFP9Be(self, BF(self.VVHs9J, isEnable), "%s Hidden Channels ?" % word)
 def VVHs9J(self, isEnable):
  VVlXNT , VVg1DL = CCTc7M.VVws8E()
  VVuQny, VVHXCZ = CCTc7M.VVbHSy()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVg1DL, VVg1DL, VVlXNT)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVHXCZ, VVHXCZ, VVuQny)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVlXNT  , VVlXNT , VVg1DL)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVuQny , VVuQny, VVHXCZ)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVg1DL, VVlXNT )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVHXCZ, VVuQny)
  ok = FFyakl(cmd)
  FFWH63()
  if ok: FF6mzu(self, "Hidden List %s" % word)
  else : FFryuM(self, "Error while restoring:\n\n%s" % fileName)
 def VVOFQK(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVWgjG
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVWgjG
  FFDlYP(self, cmd)
 def VVDtdP(self):
  VVlXNT, err = CCTc7M.VVcW6O(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFbUco(tmpFile)
  totChan = totRemoved = 0
  lines = FF5p6q(VVlXNT, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFP9Be(self, BF(FFVCur, self, BF(self.VVbuqQ, tmpFile, VVlXNT, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFlPiz(totRemoved), totChan, FFlPiz(totChan))
      , callBack_No=BF(self.VVIU4I, tmpFile))
  else:
   FFDLqC(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVbuqQ(self, tmpFile, VVlXNT, totRemoved, totChan):
  FFyakl("mv -f '%s' '%s'" % (tmpFile, VVlXNT))
  FFWH63()
  FFDLqC(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVIU4I(self, tmpFile):
  FFbUco(tmpFile)
 @staticmethod
 def VVcW6O(SELF, VVyxvV=True, title=""):
  VVlXNT, VVg1DL = CCTc7M.VVws8E()
  if   not fileExists(VVlXNT)       : err = "File not found !\n\n%s" % VVlXNT
  elif not CCLyBs.VVzL6D(SELF, VVlXNT) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVyxvV:
   FFryuM(SELF, err, title=title)
  return VVlXNT, err
 @staticmethod
 def VVYLV9(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVu6SV(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVuOkS(servTypes):
  VVXX0J  = eServiceCenter.getInstance()
  VVKFgZ   = '%s ORDER BY name' % servTypes
  VVa9sJ   = eServiceReference(VVKFgZ)
  VVCw4y = VVXX0J.list(VVa9sJ)
  if VVCw4y: return VVCw4y.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVT6ce():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCVNso(Screen):
 VV9EG1  = 0
 VVrqDl   = 1
 VVIsVS   = 2
 VVjRFt    = 3
 VVWbH6    = 4
 VV0PAt   = 5
 VVszz1   = 6
 VVPV73    = 7
 VVoDFh   = 8
 VVfJ0f   = 9
 VVJPu1   = 10
 VV5QQz   = 11
 EPG_MODE_BOUQUET_EDITOR   = 12
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFLEcJ(VV07bh, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VV9EG1)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FFEK4e("%s\n", VVJvHF) % SEP
  self.picViewer  = None
  FFCOTe(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVtVmy })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self["myLabel"].VVSAed(outputFileToSave="chann_info")
  if   self.fncMode == self.VV9EG1 : fnc = self.VVSCua
  elif self.fncMode == self.VVrqDl  : fnc = self.VVSCua
  elif self.fncMode == self.VVIsVS  : fnc = self.VVSCua
  elif self.fncMode == self.VVjRFt  : fnc = self.VV1wFI
  elif self.fncMode == self.VVWbH6  : fnc = self.VVquCV
  elif self.fncMode == self.VV0PAt  : fnc = self.VVYr6G
  elif self.fncMode == self.VVszz1  : fnc = self.VVMYWm
  elif self.fncMode == self.VVPV73  : fnc = self.VVJSUt
  elif self.fncMode == self.VVoDFh  : fnc = self.VV0xaM
  elif self.fncMode == self.VVfJ0f : fnc = self.VVgN2Y
  elif self.fncMode == self.VVJPu1  : fnc = self.VV5Rg0
  elif self.fncMode == self.VV5QQz : fnc = self.VVvBEq
  elif self.fncMode == self.EPG_MODE_BOUQUET_EDITOR : fnc = self.VVtU4J
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVT70L()
  FFEuIr(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVHmn7()
 def VVd9MX(self, err):
  self["myLabel"].setText(err)
  FF21Xy(self["myTitle"], "#22200000")
  FF21Xy(self["myBody"], "#22200000")
  self["myLabel"].VVLGbZ("#22200000")
  self["myLabel"].VVT70L()
 def VVSCua(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  self.refCode = refCode
  self.VVEXME(chName)
 def VV1wFI(self):
  self.VVEXME(self.chName)
 def VVquCV(self):
  self.VVEXME(self.chName)
 def VVYr6G(self):
  self.VVEXME(self.chName)
 def VVMYWm(self):
  self.VVEXME("Picon Info")
 def VVJSUt(self):
  self.VVEXME(self.chName)
 def VV0xaM(self):
  self.VVEXME(self.chName)
 def VVgN2Y(self):
  self.VVEXME(self.chName)
 def VV5Rg0(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFxoCd(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVFHjW(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVEXME(self.chName)
 def VVvBEq(self):
  self.VVEXME(self.chName)
 def VVtU4J(self):
  self.VVK3gG(self.picPath)
  self.VVmO6f()
 def VVEXME(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFzMYS(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVRzq0(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    self.text = self.text.rstrip() + "\n\nURL:\n%s\n" % FFEK4e(self.VV3yr3(tUrl), VVhSN2)
  if not self.epg:
   epg = CCgL5j.VVSVED(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVK3gG(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CC9p8T.VVlW3d(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVK3gG(path)
  self.VVexOE()
  self.VVTiBv(decodedUrl)
  self.VVmO6f()
 def VVmO6f(self):
  self["myLabel"].setText(self.text or "   No active service", VVvR9T=VVzxgP)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVT70L(minHeight=minH)
 def VVTiBv(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FFkZVp(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VV12qh(FFuEJn(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCPf1i.VVc1r5(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCPf1i.VVc1r5(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FFu7MN("EPG:", VVfZXg) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVexOE()
 def VVexOE(self):
  if not self.piconShown and self.picUrl:
   path, err = FFgHO0(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVK3gG(path)
    if self.piconShown and self.refCode:
     self.VVFZsB(path, self.refCode)
 def VVFZsB(self, path, refCode):
  if path and fileExists(path) and FFE0hR("ffmpeg"):
   pPath = CC9p8T.VVH8Sz()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCVNso.VVCQjh(path)
    cmd += FFbUbn("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFyakl(cmd)
 def VVK3gG(self, path):
  if path and fileExists(path):
   err, w, h = self.VVrfF4(path)
   if not err:
    if h > w:
     self.VV3Qwk(self["myPicF"], w, h, True)
     self.VV3Qwk(self["myPicB"], w, h, False)
     self.VV3Qwk(self["myPic"] , w, h, False)
   self.picViewer = CCpTQt.VVseWq(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VV3Qwk(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVrfF4(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFunaH(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVRzq0(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFEK4e(chName, VVfZXg)
  txt += self.VVR7gd(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFEK4e(state, VVnviq)
   txt += "State\t: %s\n" % state
  w = FFXVji(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFXVji(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVAm6o(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVR7gd(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVR7gd(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVR7gd(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVElXh()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVJQRJ()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCVNso.VV36ET(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFEK4e("Stream-Relay" if FFUkkg(decodedUrl) else "IPTV", VVN1ah)
   txt += self.VVPMXZ(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVU0Sp(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCSMOW()
    tpTxt, namespace = tp.VV5fa5(refCode)
    if tpTxt:
     txt += FFEK4e("Tuner:\n", VVfZXg)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFEK4e("Codes:\n", VVfZXg)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVR7gd(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVR7gd(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVR7gd(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVR7gd(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVR7gd(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVR7gd(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVR7gd(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVR7gd(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVR7gd(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVAm6o(info):
  if info:
   aspect = FFXVji(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVR7gd(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFXVji(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVWZxX(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVWZxX(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVElXh(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVJQRJ(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVU0Sp(self, refCode, iptvRef, chName):
  refCode = FF1rzp(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FF3unD(VVWgjG + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FF3unD(VVWgjG + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVZAt4 = []
  tmpRefCode = FFuEJn(refCode)
  for item in fList:
   path = VVWgjG + item
   if fileExists(path):
    txt = FF3unD(path)
    if tmpRefCode in FFuEJn(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVZAt4.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVZAt4:
   if len(VVZAt4) == 1:
    txt += "%s\t: %s%s\n" % (FFEK4e("Bouquet", VVfZXg), VVZAt4[0][0], " (%s)" % VVZAt4[0][1] if VVf1FF else "")
   else:
    txt += FFEK4e("Bouquets:\n", VVfZXg)
    for ndx, item in enumerate(VVZAt4):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVf1FF else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVPMXZ(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFqwVq(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCPf1i()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVSbpM(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFEK4e("URL:", VVN1ah) + "\n%s\n" % self.VV3yr3(decodedUrl)
  else:
   txt = "\n"
   txt += FFEK4e("Reference:", VVN1ah) + "\n%s\n" % refCode
  return txt
 def VV3yr3(self, url):
  if not FFUkkg(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVUwTh:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFuEJn(url)
 def VV12qh(self, decodedUrl):
  if not CCXzSR.VVGqI0():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCDrYI.VV5ztg(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCDrYI.VVI941(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVzSMU(tDict)
   elif uType == "movie" : epg, picUrl = CCVNso.VVPJbK(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVzSMU(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCDrYI.VVklIB(item, "title"    , is_base64=True )
     lang    = CCDrYI.VVklIB(item, "lang"         ).upper()
     description   = CCDrYI.VVklIB(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCDrYI.VVklIB(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCDrYI.VVklIB(item, "start_timestamp"      )
     stop_timestamp  = CCDrYI.VVklIB(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCDrYI.VVklIB(item, "stop_timestamp"       )
     now_playing   = CCDrYI.VVklIB(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVoR97, ""
      else     : color, txt = VVnviq , "    (CURRENT EVENT)"
      epg += FFEK4e("_" * 32 + "\n", VVJvHF)
      epg += FFEK4e("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFEK4e(description, VVhSN2)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCgL5j.VVpL8h(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVPJbK(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCDrYI.VVklIB(item, "movie_image" )
    genre  = CCDrYI.VVklIB(item, "genre"   ) or "-"
    plot  = CCDrYI.VVklIB(item, "plot"   ) or "-"
    country  = CCDrYI.VVklIB(item, "country"  ) or "-"
    actors  = CCDrYI.VVklIB(item, "actors"   ) or "-"
    cast  = CCDrYI.VVklIB(item, "cast"   ) or "-"
    rating  = CCDrYI.VVklIB(item, "rating"   ) or "-"
    director = CCDrYI.VVklIB(item, "director"  ) or "-"
    releasedate = CCDrYI.VVklIB(item, "releasedate" ) or "-"
    duration = CCDrYI.VVklIB(item, "duration"  ) or "-"
    try:
     lang = CCDrYI.VVklIB(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFEK4e(cast if cast != "-" else actors, VVhSN2)
    epg += "Plot:\n%s"    % FFEK4e(plot, VVhSN2)
   except:
    pass
  return epg, movie_image
 def VVtVmy(self):
  if VVUwTh:
   def VVR7gd(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVR7gd(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCPf1i()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVSbpM(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVR7gd(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFqgHP(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVOsO7(SELF):
  if not CCOnT0.VVqlCJ(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(SELF)
  err = url =  fSize = resumable = ""
  if FFHhMF(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCPf1i.VVKIr3(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCPf1i.VVcBjZ(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFryuM(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCLyBs.VVM24t(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFEK4e(" (M3U/M3U8 File)", VVhSN2)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CC6EZK.VVvvSZ(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVu8zC(subj, val):
   return "%s\n%s\n\n" % (FFEK4e("%s:" % subj, VVfZXg), val)
  title = "File Size"
  txt  = VVu8zC(title , fSize or "?")
  txt += VVu8zC("Name" , chName)
  txt += VVu8zC("URL" , url)
  if resumable: txt += VVu8zC("Supports Download-Resume", resumable)
  if err  : txt += FFEK4e("Error:\n", VVnviq) + err
  FFDLqC(SELF, txt, title=title)
 @staticmethod
 def VV36ET(SELF):
  fPath, fDir, fName = CCLyBs.VVK93s(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVCQjh(path):
  return FFbUbn("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VVH8tG(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CC9p8T.VVH8Sz() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVXbMs(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFkZVp(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFKVYD(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCPf1i():
 def __init__(self):
  self.VVNnTB()
  self.VVc4Z6    = ""
  self.VV9FZE   = "#f#11ffffaa#User"
  self.VVwzyA   = "#f#11aaffff#Server"
 def VVNnTB(self):
  self.VV5VB0   = ""
  self.VVZqGU    = ""
  self.VVID28   = ""
  self.VVmH6q = ""
  self.VVYNBn  = ""
  self.VVRs8c = 0
 def VVChpu(self, url, mac, ph1="", VVO6nE=True):
  self.VVNnTB()
  self.VVc4Z6 = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVdHVE(url)
  if not host:
   if VVO6nE:
    self.VVInOH("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVPFYg(mac)
  if not host:
   if VVO6nE:
    self.VVInOH("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VV5VB0 = host
  self.VVZqGU  = mac
  return True
 def VV4uXG(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVc4Z6, "")
 def VVdHVE(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVPFYg(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVkIQb(self):
  res, err = self.VVvTvx(self.VVaTY3())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VV5VB0.endswith("/c"):
    self.VV5VB0 = self.VV5VB0[:-2]
    res, err = self.VVvTvx(self.VVaTY3())
   elif self.VV5VB0.endswith("/stalker_portal"):
    self.VV5VB0 = self.VV5VB0[:-15]
    res, err = self.VVvTvx(self.VVaTY3())
   else:
    self.VV5VB0 += "/c"
    res, err = self.VVvTvx(self.VVaTY3())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCDrYI.VVklIB(tDict["js"], "token")
    rand  = CCDrYI.VVklIB(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVXks0(self, VVO6nE=True):
  if not self.VVc4Z6:
   self.VVgngS()
  err = blkMsg = FF6mzuTxt = ""
  try:
   token, rand, err = self.VVkIQb()
   if token:
    self.VVID28 = token
    self.VVmH6q = rand
    if rand:
     self.VVRs8c = 2
    prof, retTxt = self.VVJWeO(True)
    if prof:
     self.VVYNBn = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVRs8c = 3
      prof, retTxt = self.VVJWeO(False)
      if retTxt:
       self.VVYNBn = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF6mzuTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF6mzuTxt: tErr += "\n%s" % FF6mzuTxt
  if VVO6nE:
   self.VVInOH(tErr)
  return "", "", tErr
 def VVgngS(self):
  try:
   import requests
   url = self.VV5iZi()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCPf1i.VVcBjZ(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCPf1i.VVcBjZ(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VV5VB0 = url
       self.VVc4Z6 = span.group(1)
       return
  except:
   pass
  self.VVc4Z6 = "/server/load.php"
 def VV5iZi(self):
  url = self.VV5VB0.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVTtsI(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVvTvx("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVvTvx("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVJWeO(self, capMac):
  res, err = self.VVvTvx(self.VVOMZz(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCDrYI.VVklIB(tDict["js"], "block_%s" % word)
    FF6mzuTxt = CCDrYI.VVklIB(tDict["js"], word)
    return tDict, FF6mzuTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVOMZz(self, capMac):
  param = ""
  if self.VVYNBn or self.VVmH6q:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVZqGU.upper() if capMac else self.VVZqGU.lower(), self.VVmH6q))
  return self.VV0Ej8() + "type=stb&action=get_profile" + param
 exec(FFxoCd("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVT1mz(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVrpk3()
  if len(rows) < 10:
   rows = self.VVQBGz()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VV5VB0 ))
   rows.append(("MAC (from URL)" , self.VVZqGU ))
   rows.append(("Token"   , self.VVID28 ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VV9FZE  , "MAC" , self.VVZqGU ))
   rows.append(("2", self.VVwzyA, "Host" , self.VV5VB0 ))
   rows.append(("2", self.VVwzyA, "Token" , self.VVID28 ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVOKmR(self, isPhp=True, VVO6nE=False):
  token, profile, tErr = self.VVXks0(VVO6nE)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVDHNH()
  res, err = self.VVvTvx(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCDrYI.VVklIB(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFO7Oa(span.group(2))
     pass1 = FFO7Oa(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVrpk3(self):
  m3u_Url, host, user1, pass1, err = self.VVOKmR()
  rows = []
  if m3u_Url:
   res, err = self.VVvTvx(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFkL2p(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VV9FZE, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFkL2p(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVwzyA, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVQBGz(self):
  token, profile, tErr = self.VVXks0()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFSca3(val): val = FFxoCd(val.decode("UTF-8"))
     else     : val = self.VVZqGU
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFkL2p(int(parts[1]))
      if parts[2] : ends = FFkL2p(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFkL2p(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVFHjW(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVXks0(VVO6nE=False)
  if not token:
   return ""
  crLinkUrl = self.VVRXdz(mode, chCm, epNum, epId)
  res, err = self.VVvTvx(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCDrYI.VVklIB(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VV0Ej8(self):
  return self.VV5VB0 + self.VVc4Z6 + "?"
 def VVaTY3(self):
  return self.VV0Ej8() + "type=stb&action=handshake&token=&mac=%s" % self.VVZqGU
 def VV4t3t(self, mode):
  url = self.VV0Ej8() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVyVaK(self, catID):
  return self.VV0Ej8() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVes2R(self, mode, catID, page):
  url = self.VV0Ej8() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVdjtf(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VV0Ej8() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVOBEr(self, stID):
  return self.VV0Ej8() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVRXdz(self, mode, chCm, serCode, serId):
  url = self.VV0Ej8() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVDHNH(self):
  return self.VV0Ej8() + "type=itv&action=create_link"
 def VVe9v0(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV7Xb3(catID, stID, chNum)
  query = self.VVur2h(mode, self.VV4uXG(), FFq8pW(host), FFq8pW(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVur2h(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVSbpM(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVur2h(mode, ph1, host, mac, epNum, epId, FFO7Oa(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFxoCd(host)
  mac   = FFxoCd(mac)
  valid = False
  if self.VVdHVE(playHost) and self.VVdHVE(host) and self.VVdHVE(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVvTvx(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCPf1i.VVcBjZ()
   if self.VVID28:
    headers["Authorization"] = "Bearer %s" % self.VVID28
   if useCookies : cookies = {"mac": self.VVZqGU, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVybt6(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCPf1i.VVcBjZ(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVcBjZ():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVInOH(self, err, title="Portal Browser"):
  FFryuM(self, str(err), title=title)
 def VV6yyb(self, mode):
  if   mode in ("itv"  , CCDrYI.VVMGQg , CCDrYI.VVWmy2)  : return "Live"
  elif mode in ("vod"  , CCDrYI.VVe9b1 , CCDrYI.VVllZx)  : return "VOD"
  elif mode in ("series" , CCDrYI.VVSiDX , CCDrYI.VVgzyM) : return "Series"
  else                          : return "IPTV"
 def VVbXEA(self, mode, searchName):
  return 'Find in %s : %s' % (self.VV6yyb(mode), FFEK4e(searchName, VVhSN2))
 def VV1lQb(self, catchup=False):
  VVGIDM = []
  VVGIDM.append(("Live"    , "live"  ))
  VVGIDM.append(("VOD"    , "vod"   ))
  VVGIDM.append(("Series"   , "series"  ))
  if catchup:
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Catch-up TV" , "catchup"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Account Info." , "accountInfo" ))
  return VVGIDM
 @staticmethod
 def VVt91K(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCPf1i()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVSbpM(decodedUrl)
  if valid:
   ok = p.VVChpu(host, mac, ph1, VVO6nE=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VVOKmR(isPhp=False, VVO6nE=False)
    streamId = CCPf1i.VVis24(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVis24(decodedUrl):
  p = CCPf1i()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVSbpM(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFxoCd(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVKIr3(decodedUrl):
  p = CCPf1i()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVSbpM(decodedUrl)
  if valid:
   if CCPf1i.VVYhDq(chCm):
    return FFuEJn(chCm)
   else:
    ok = p.VVChpu(host, mac, ph1, VVO6nE=False)
    if ok:
     try:
      chUrl = p.VVFHjW(mode, chCm, epNum, epId)
      return FFuEJn(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVYhDq(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVc1r5(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCPf1i()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVSbpM(decodedUrl)
   if valid:
    if not stID:
     stID = CCPf1i.VVis24(decodedUrl)
    if stID:
     if p.VVChpu(host, mac, ph1, VVO6nE=False):
      token, profile, tErr = p.VVXks0(VVO6nE=False)
      if token:
       res, err = p.VVvTvx(p.VVOBEr(stID))
       if res:
        epg, err = CCPf1i.VVy7uy(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCPf1i.VVy7uy(res.text, retLst=True)
         if pList:
          totEv, totOK = CCgL5j.VVpL8h(refCode, pList)
  return epg, err
 @staticmethod
 def VVy7uy(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CCDrYI.VVklIB(item, "actor"       )
    category   = CCDrYI.VVklIB(item, "category"      )
    descr    = CCDrYI.VVklIB(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CCDrYI.VVklIB(item, "director"      )
    name    = CCDrYI.VVklIB(item, "name"   , is_base64=True)
    start_timestamp  = CCDrYI.VVklIB(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CCDrYI.VVklIB(item, "start_timestamp"    )
    stop_timestamp  = CCDrYI.VVklIB(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CCDrYI.VVklIB(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FFEK4e("    (CURRENT EVENT)", VVUrbH)
     except:
      pass
     if not skip:
      epg += FFEK4e("_" * 32 + "\n", VVJvHF)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FFEK4e(name, VVfZXg)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FFEK4e(descr , VVhSN2) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FFEK4e(category, VVhSN2) if category else ""
      epg += "Actors:\n%s\n"  % FFEK4e(actor , VVhSN2) if actor else ""
      epg += "Director:\n%s\n" % FFEK4e(director, VVhSN2) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCJVUC(CCPf1i):
 def __init__(self):
  CCPf1i.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVgJOf(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVSbpM(decodedUrl)
  if valid:
   if self.VVChpu(host, mac, ph1, VVO6nE=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVIo5U(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  if self.chCm.startswith("Zz1"):
   self.chCm = FFxoCd(self.chCm[3:])
  else:
   try:
    chUrl = self.VVFHjW(self.mode, self.chCm, self.epNum, self.epId)
   except:
    return False
  isDirect = False
  if CCPf1i.VVYhDq(self.chCm):
   chUrl = FFuEJn(self.chCm)
   chUrl = FFO7Oa(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVAlCo(chUrl)
  bPath = CCpURW.VVa98V()
  if newIptvRef:
   if passedSELF:
    FFnh1l(passedSELF, newIptvRef, VV5sxe=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFnh1l(self, newIptvRef, VV5sxe=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVu6MS(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVAlCo(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVu6MS(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FF5p6q(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFWH63()
class CCiNEg(CCJVUC):
 def __init__(self, passedSession):
  CCJVUC.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVP2q8(VViQwH  )
  Main_Menu.VVP2q8(VVqTeW)
  Main_Menu.VVP2q8(VVXdLX  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVYi5r, iPlayableService.evEOF: self.VVv1hz, iPlayableService.evEnd: self.VVd6v1})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVLKMk)
  except:
   self.timer2.callback.append(self.VVLKMk)
  self.timer2.start(3000, False)
  self.VVLKMk()
 def VVLKMk(self):
  if not CFG.downloadMonitor.getValue():
   self.VVrXJX()
   return
  lst = CC6EZK.VVII63()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFl8II(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CC6EZK.VVG3QL(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CCRdl4.VVo0qy(self.passedSession, txt, 30)
   else    : CCRdl4.VV4WYi(self.dnldWin, txt)
  elif self.dnldWin:
   self.VVrXJX()
 def VVrXJX(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVYi5r(self):
  self.startTime = iTime()
 def VVv1hz(self):
  global VVtKHB
  VVtKHB = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFHhMF(decodedUrl):
     self.isFromEOF = True
     CCRdl4(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVd6v1(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVVmQq)
  except:
   self.timer1.callback.append(self.VVVmQq)
  self.timer1.start(100, True)
 def VVVmQq(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVgJOf(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCTKa3.VVvj2H:
       self.isFromEOF = False
       self.VVIo5U(self.passedSession, isFromSession=True)
class CCfr3d():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F]{,3}\ (.+)")
  self.prefixRemoveList = self.VVJYN4(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVJYN4(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVJYN4(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VV6OO5, VV90k3):
    path += fName
    if fileExists(path):
     for line in FF5p6q(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVyWFU(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCDrYI.VVmrAp(name):
   return CCDrYI.VV0D2E(name)
  return self.VVrPcj(name)
 def VVrPcj(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VVLa8M(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVrPcj(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVnTZP(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVqWGY(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVNX3i(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CCOnT0(CCPf1i):
 def __init__(self):
  self.curPortalCatId = ""
  CCPf1i.__init__(self)
 def VV55qp(self):
  if CCOnT0.VVqlCJ(self):
   FFVCur(self, BF(self.VVOc4F, 2), title="Searching ...")
 def VVU6T5(self, winSession, url, mac):
  self.curUrl = url
  if CCOnT0.VVqlCJ(self):
   if self.VVChpu(url, mac):
    FFVCur(winSession, self.VVhojv, title="Checking Server ...")
   else:
    FFryuM(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VV2H2O(self, item=None):
  if item:
   VVXrLB, txt, path, ndx = item
   enc = CCme0M.VVfBpm(path, self)
   if enc == -1:
    return
   self.session.open(CCChia, barTheme=CCChia.VVzhbG
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVL43A, path, enc)
       , VViIM0 = BF(self.VVrlM3, VVXrLB, path))
 def VVL43A(self, path, enc, VVWRJ1):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVWRJ1.VVsWOI(totLines)
  VVWRJ1.VVfN1b = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVWRJ1 or VVWRJ1.isCancelled:
     return
    VVWRJ1.VVYksR(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVdHVE(url)
     mac  = self.VVPFYg(mac)
     if host and mac and VVWRJ1:
      VVWRJ1.VVfN1b.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVdHVE(url)
      mac  = self.VVPFYg(mac)
      if host and mac and not mac.startswith("AC") and VVWRJ1:
       VVWRJ1.VVfN1b.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVrlM3(self, VVXrLB, path, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVfN1b:
   VVr0hN  = ("Home Menu"  , FFCuPQ            , [])
   VVMCbu = ("Edit File"  , BF(self.VVLBgl, path)       , [])
   VVoXaA = ("M3U Options" , self.VVQj6e         , [])
   VVUm5B = ("Check & Filter" , BF(self.VViqVS, VVXrLB, path), [])
   VVRWOd  = ("Select"   , self.VV5UUC      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVyaAW  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVxL8T = FFfJU2(self, None, title=title, header=header, VVZAt4=VVfN1b, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VVXsDY="#0a001122", VVEEoV="#0a001122", VVasam="#0a001122", VVhaQs="#00004455", VVAXDQ="#0a333333", VVilD4="#11331100", VVehvv=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVmEsn:
    FFqgHP(VVxL8T, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVmEsn:
    FFryuM(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVQj6e(self, VVxL8T, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVGIDM = []
  VVGIDM.append(("Browse as M3U"  , "browse"))
  VVGIDM.append(("Download M3U File" , "downld"))
  FFzctu(self, BF(self.VVx2VN, VVxL8T, host, mac), title=title, VVGIDM=VVGIDM, width=600, VVglmG=True)
 def VVx2VN(self, VVxL8T, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFVCur(VVxL8T, BF(self.VVtpk4, VVxL8T, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFP9Be(self, BF(FFVCur, VVxL8T, BF(self.VVtpk4, VVxL8T, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVtpk4(self, VVxL8T, title, host, mac, item):
  p = CCPf1i()
  m3u_Url = ""
  ok = p.VVChpu(host, mac, VVO6nE=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVOKmR(VVO6nE=False)
  if m3u_Url:
   if   item == "browse": self.VV83PW(title, m3u_Url)
   elif item == "downld": self.VVqOnJ(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFryuM(self, err or "No response from Server !", title=title)
 def VV5UUC(self, VVxL8T, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVU6T5(VVxL8T, url, mac)
 def VVLBgl(self, path, VVxL8T, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC8yF1(self, path, VViIM0=BF(self.VVcEKf, VVxL8T), curRowNum=rowNum)
  else    : FFAhcl(self, path)
 def VViqVS(self, VVXrLB, path, VVxL8T, title, txt, colList):
  self.session.open(CCChia, barTheme=CCChia.VV1d7P
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VVByRE, VVxL8T)
      , VViIM0 = BF(self.VV6ttq, VVXrLB, VVxL8T, path))
 def VVByRE(self, VVxL8T, VVWRJ1):
  VVWRJ1.VVfN1b = []
  VVWRJ1.VVsWOI(VVxL8T.VVERJ7())
  for row in VVxL8T.VVWcfU():
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   VVWRJ1.VVYksR(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVChpu(host, mac, VVO6nE=False):
    token, profile, tErr = self.VVXks0(VVO6nE=False)
    if token and VVWRJ1 and not VVWRJ1.isCancelled:
     res, err = self.VVvTvx(self.VV4t3t("itv"))
     if res and VVWRJ1 and not VVWRJ1.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVWRJ1.VVYksR(0, showFound=True)
       VVWRJ1.VVfN1b.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVWRJ1:
    return
 def VV6ttq(self, VVXrLB, VVxL8T, path, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  if VVfN1b:
   VVxL8T.close()
   VVXrLB.close()
   newPath = "%s_OK_%s.txt" % (path, FFOa0m())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVfN1b:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFEK4e(str(threadCounter), VVnviq)
    skipped = FFEK4e(str(threadTotal - threadCounter), VVnviq)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVfN1b)
   txt += "%s\n\n%s"    %  (FFEK4e("Result File:", VVfZXg), newPath)
   FFDLqC(self, txt, title="Accessible Portals")
  elif VVmEsn:
   FFryuM(self, "No portal access found !", title="Accessible Portals")
 def VVHiu7(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFxoCd(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVhojv(self):
  token, profile, tErr = self.VVXks0()
  if token:
   dots = "." * self.VVRs8c
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VV4uXG(), "")
   dots += "*" if not self.VV5VB0 == self.curUrl else ""
   VVGIDM  = self.VV1lQb()
   VV4v1i = self.VV5g7A
   VVx6LK = self.VV34Zb
   VVw5pZ = ("Home Menu", FFCuPQ)
   VVQaYB= ("Add to Menu", BF(CCDrYI.VV9N60, self, True, self.VV5VB0 + "\t" + self.VVZqGU))
   VVacc0 = ("Bookmark Server", BF(CCDrYI.VVUfGj, self, True, self.VV5VB0 + "\t" + self.VVZqGU))
   VVXrLB = FFzctu(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVZqGU, dots), VVGIDM=VVGIDM, VV4v1i=VV4v1i, VVx6LK=VVx6LK, VVw5pZ=VVw5pZ, VVQaYB=VVQaYB, VVacc0=VVacc0)
   self.VVgcLo(VVXrLB)
 def VV5g7A(self, item=None):
  if item:
   VVXrLB, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFVCur(VVXrLB, BF(self.VV4gRy, mode), title="Reading Categories ...")
   else : FFVCur(VVXrLB, BF(self.VVgihK, VVXrLB, title), title="Reading Account ...")
 def VVgihK(self, VVXrLB, title, forceMoreInfo=False):
  rows, totCols = self.VVT1mz(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVZqGU)
  VVr0hN  = ("Home Menu" , FFCuPQ           , [])
  VVoXaA  = None
  if VVUwTh:
   VVoXaA = ("Get JS"  , BF(self.VV8O9Z, self.VV5iZi()) , [])
  if totCols == 2:
   VVUm5B = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVUm5B = ("More Info.", BF(self.VV8NPa, VVXrLB)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFfJU2(self, None, title=title, width=1200, header=header, VVZAt4=rows, VVbiLs=widths, VVNdFV=26, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVUm5B=VVUm5B, VVXsDY="#0a00292B", VVEEoV="#0a002126", VVasam="#0a002126", VVhaQs="#00000000", searchCol=searchCol)
 def VV8O9Z(self, url, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVV7Cj, url), title="Getting JS ...")
 def VVV7Cj(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVZqGU)
  ver, err = self.VVTtsI(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVTtsI(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFDLqC(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VV8NPa(self, VVXrLB, VVxL8T, title, txt, colList):
  VVxL8T.cancel()
  FFVCur(VVXrLB, BF(self.VVgihK, VVXrLB, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VV4gRy(self, mode):
  token, profile, tErr = self.VVXks0()
  if not token:
   return
  res, err = self.VVvTvx(self.VV4t3t(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CCDrYI.VVklIB(item, "id"       )
      Title  = CCDrYI.VVklIB(item, "title"      )
      censored = CCDrYI.VVklIB(item, "censored"     )
      Title = self.VVnTZP(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVf1FF:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VV6yyb(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVXsDY, VVEEoV, VVasam, VVhaQs = self.VVSqeR(mode)
   mName = self.VV6yyb(mode)
   VV6aZX  = (""     , BF(self.VVv5Xy, mode), [])
   VVRWOd   = ("Show List"   , BF(self.VV6F98, mode)   , [])
   VVr0hN  = ("Home Menu"   , FFCuPQ        , [])
   if mode in ("vod", "series"):
    VVMCbu = ("Find in %s" % mName , BF(self.VVSYMm, mode, False), [])
    VVUm5B = ("Find in Selected" , BF(self.VVSYMm, mode, True) , [])
   else:
    VVMCbu = None
    VVUm5B = None
   header   = None
   widths   = (100   , 0  )
   FFfJU2(self, None, title=title, width=1200, header=header, VVZAt4=list, VVbiLs=widths, VVNdFV=30, VVr0hN=VVr0hN, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VV6aZX=VV6aZX, VVRWOd=VVRWOd, VVXsDY=VVXsDY, VVEEoV=VVEEoV, VVasam=VVasam, VVhaQs=VVhaQs, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVYNBn:
     txt += "\n\n( %s )" % self.VVYNBn
   else:
    txt = "Could not get Categories from server!"
   FFryuM(self, txt, title=title)
 def VVCEql(self, mode, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VV2oFx, mode, VVxL8T, title, txt, colList), title="Downloading ...")
 def VV2oFx(self, mode, VVxL8T, title, txt, colList):
  token, profile, tErr = self.VVXks0()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVvTvx(self.VVyVaK(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CCDrYI.VVklIB(item, "id"    )
      actors   = CCDrYI.VVklIB(item, "actors"   )
      added   = CCDrYI.VVklIB(item, "added"   )
      age    = CCDrYI.VVklIB(item, "age"   )
      category_id  = CCDrYI.VVklIB(item, "category_id" )
      description  = CCDrYI.VVklIB(item, "description" )
      director  = CCDrYI.VVklIB(item, "director"  )
      genres_str  = CCDrYI.VVklIB(item, "genres_str"  )
      name   = CCDrYI.VVklIB(item, "name"   )
      path   = CCDrYI.VVklIB(item, "path"   )
      screenshot_uri = CCDrYI.VVklIB(item, "screenshot_uri" )
      series   = CCDrYI.VVklIB(item, "series"   )
      cmd    = CCDrYI.VVklIB(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VV6aZX = (""     , BF(self.VVcOMK, mode, True)  , [])
   VVRWOd  = ("Play"    , BF(self.VVa1Vs, mode)       , [])
   VVMOfU = (""     , BF(self.VVYkbW, mode)     , [])
   VVr0hN = ("Home Menu"   , FFCuPQ            , [])
   VVoXaA = ("Download Options" , BF(self.VVtBV2, mode, "sp", seriesName) , [])
   VVMCbu = ("Options"   , BF(self.VVeSeG, "pEp", mode, seriesName) , [])
   VVUm5B = ("Posters Mode"  , BF(self.VV0OqK, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVyaAW  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFfJU2(self, None, title=seriesName, width=1200, header=header, VVZAt4=list, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VV6aZX=VV6aZX, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindIptv, VVXsDY="#0a00292B", VVEEoV="#0a002126", VVasam="#0a002126", VVhaQs="#00000000")
  else:
   FFryuM(self, "Could not get Episodes from server!", title=seriesName)
 def VVSYMm(self, mode, searchInCat, VVxL8T, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVGIDM = []
  VVGIDM.append(("Keyboard"  , "manualEntry"))
  VVGIDM.append(("From Filter" , "fromFilter"))
  FFzctu(self, BF(self.VVGybg, VVxL8T, mode, searchCatId), title="Input Type", VVGIDM=VVGIDM, width=400)
 def VVGybg(self, VVxL8T, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF9Fmo(self, BF(self.VVQB6S, VVxL8T, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCgoW8(self)
    filterObj.VV1oDN(BF(self.VVQB6S, VVxL8T, mode, searchCatId))
 def VVQB6S(self, VVxL8T, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFSKZx(CFG.lastFindIptv, searchName)
   title = self.VVbXEA(mode, searchName)
   if "," in searchName : FFryuM(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFryuM(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVqWGY([searchName]):
     FFryuM(self, self.VVNX3i(), title=title)
    else:
     self.VVlH7y(mode, searchName, "", searchName, searchCatId)
 def VV6F98(self, mode, VVxL8T, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVlH7y(mode, bName, catID, "", "")
 def VVlH7y(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCChia, barTheme=CCChia.VVzhbG
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVnXGc, mode, bName, catID, searchName, searchCatId)
      , VViIM0 = BF(self.VVBEBd, mode, bName, catID, searchName, searchCatId))
 def VVBEBd(self, mode, bName, catID, searchName, searchCatId, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVbXEA(mode, searchName)
  else   : title = "%s : %s" % (self.VV6yyb(mode), bName)
  if VVfN1b:
   VVoXaA = None
   VVMCbu = None
   if mode == "series":
    VVXsDY, VVEEoV, VVasam, VVhaQs = self.VVSqeR("series2")
    VVRWOd  = ("Episodes"   , BF(self.VVCEql, mode)           , [])
   else:
    VVXsDY, VVEEoV, VVasam, VVhaQs = self.VVSqeR("")
    VVRWOd  = ("Play"    , BF(self.VVa1Vs, mode)           , [])
    VVoXaA = ("Download Options" , BF(self.VVtBV2, mode, "vp" if mode == "vod" else "", "") , [])
    VVMCbu = ("Options"   , BF(self.VVeSeG, "pCh", mode, bName)      , [])
   VV6aZX = (""      , BF(self.VVcOMK, mode, False)      , [])
   VVMOfU = (""      , BF(self.VVEIWz, mode)         , [])
   VVr0hN = ("Home Menu"    , FFCuPQ                , [])
   VVUm5B = ("Posters Mode"   , BF(self.VV0OqK, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVyaAW  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVxL8T = FFfJU2(self, None, title=title, header=header, VVZAt4=VVfN1b, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindIptv, VVRWOd=VVRWOd, VV6aZX=VV6aZX, VVMOfU=VVMOfU, VVXsDY=VVXsDY, VVEEoV=VVEEoV, VVasam=VVasam, VVhaQs=VVhaQs, VVehvv=True, searchCol=1)
   if not VVmEsn:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVxL8T.VVL9w5(VVxL8T.VVPL4Q() + tot)
    if threadErr: FFqgHP(VVxL8T, "Error while reading !", 2000)
    else  : FFqgHP(VVxL8T, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFryuM(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFryuM(self, "Could not get list from server !", title=title)
 def VVEIWz(self, mode, VVxL8T, title, txt, colList):
  ttl = lambda x, y: "%s:\n%s\n\n" % (FFEK4e(x, VVfZXg), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFNmLy(self, fncMode=CCVNso.VV5QQz, portalHost=self.VV5VB0, portalMac=self.VVZqGU, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVK2NN(mode, VVxL8T, title, txt, colList)
 def VVYkbW(self, mode, VVxL8T, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFEK4e(colList[10], VVhSN2)
  txt += "Description:\n%s" % FFEK4e(colList[11], VVhSN2)
  self.VVK2NN(mode, VVxL8T, title, txt, colList)
 def VVK2NN(self, mode, VVxL8T, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVUcYo(mode, colList)
  refCode, chUrl = self.VVe9v0(self.VV5VB0, self.VVZqGU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFNmLy(self, fncMode=CCVNso.VVJPu1, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVnXGc(self, mode, bName, catID, searchName, searchCatId, VVWRJ1):
  try:
   token, profile, tErr = self.VVXks0()
   if not token:
    return
   if VVWRJ1.isCancelled:
    return
   VVWRJ1.VVfN1b, total_items, max_page_items, err = self.VVmIaW(mode, catID, 1, 1, searchName, searchCatId)
   if VVWRJ1.isCancelled:
    return
   if VVWRJ1.VVfN1b and total_items > -1 and max_page_items > -1:
    VVWRJ1.VVsWOI(total_items)
    VVWRJ1.VVYksR(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVWRJ1.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVmIaW(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVWRJ1.VVssOF()
     if VVWRJ1.isCancelled:
      return
     if list:
      VVWRJ1.VVfN1b += list
      VVWRJ1.VVYksR(len(list), True)
  except:
   pass
 def VVmIaW(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVdjtf(mode, searchName, searchCatId, page)
  else   : url = self.VVes2R(mode, catID, page)
  res, err = self.VVvTvx(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVxSlE(CCDrYI.VVklIB(item, "total_items" ))
     max_page_items = self.VVxSlE(CCDrYI.VVklIB(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCDrYI.VVklIB(item, "id"    )
      name   = CCDrYI.VVklIB(item, "name"   )
      o_name   = CCDrYI.VVklIB(item, "o_name"   )
      category_id  = CCDrYI.VVklIB(item, "category_id" )
      tv_genre_id  = CCDrYI.VVklIB(item, "tv_genre_id" )
      number   = CCDrYI.VVklIB(item, "number"   ) or str(counter)
      logo   = CCDrYI.VVklIB(item, "logo"   )
      screenshot_uri = CCDrYI.VVklIB(item, "screenshot_uri" )
      pic    = CCDrYI.VVklIB(item, "pic"   )
      cmd    = CCDrYI.VVklIB(item, "cmd"   )
      censored  = CCDrYI.VVklIB(item, "censored"  )
      genres_str  = CCDrYI.VVklIB(item, "genres_str"  )
      curPlay   = CCDrYI.VVklIB(item, "cur_playing" )
      actors   = CCDrYI.VVklIB(item, "actors"   )
      descr   = CCDrYI.VVklIB(item, "description" )
      director  = CCDrYI.VVklIB(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFq8pW(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VV5VB0 + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVyWFU(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVxSlE(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVa1Vs(self, mode, VVxL8T, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVUcYo(mode, colList)
  refCode, chUrl = self.VVe9v0(self.VV5VB0, self.VVZqGU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVmrAp(chName):
   FFqgHP(VVxL8T, "This is a marker!", 300)
  else:
   FFVCur(VVxL8T, BF(self.VVmoQV, mode, VVxL8T, chUrl), title="Playing ...")
 def VVmoQV(self, mode, VVxL8T, chUrl):
  FFnh1l(self, chUrl, VV5sxe=False)
  CCTKa3.VV3qn6(self.session, iptvTableParams=(self, VVxL8T, mode))
 def VVKBl1(self, mode, VVxL8T, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVUcYo(mode, colList)
  refCode, chUrl = self.VVe9v0(self.VV5VB0, self.VVZqGU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVUcYo(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVqlCJ(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVGIDM = []
    VVGIDM.append((title        , "inst" ))
    VVGIDM.append(("Update Packages then %s" % title , "updInst" ))
    FFzctu(SELF, BF(CCOnT0.VVih6l, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVGIDM=VVGIDM)
   return False
 @staticmethod
 def VVih6l(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFthHn(VVJwhx, "")
   if cmdUpd:
    cmdInst = FFM6zB(VVP2Dj, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FF8jLK(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVZgJA=cbFnc)
   else:
    FFRzIz(SELF)
 def VVgnUB(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVSbpM(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVgcLo(self, VVXrLB):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVgnUB()
  if all((curMode, curHost, curCat)) and curHost == self.VV5VB0:
   VVXrLB.VVwPcs({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVv5Xy(self, mode, VVxL8T, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVgnUB()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VV5VB0:
   VVxL8T.VVWFhX({1:curCat})
 def VVcOMK(self, mode, isEp, VVxL8T, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVgnUB()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VV5VB0:
   if mode in ("itv", "vod"):
    VVxL8T.VVWFhX({2:curStID})
   else: #series
    if isEp:
     VVxL8T.VVWFhX({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVxL8T.VVWFhX({2:ser2})
     if not ok: VVxL8T.VVWFhX({2:ser1})
class CCDrYI(Screen, CCOnT0, CCfr3d, CCKKWJ):
 VV4D8a    = 0
 VVEM9n    = 1
 VVpqU2    = 2
 VVfHwd    = 3
 VVxJHl     = 4
 VVVMRW     = 5
 VVWq8O     = 6
 VVYfa9     = 7
 VV134O     = 8
 VV6joj     = 9
 VVU75w      = 10
 VVvUWD     = 11
 VV1OA8     = 12
 VV8H6w     = 13
 VVi0DH     = 14
 VVobvA      = 15
 VVdnLG      = 16
 VVrXIn      = 17
 VVMoIM      = 18
 VVZv1s      = 19
 VVHrYo    = 0
 VVMGQg   = 1
 VVe9b1   = 2
 VVSiDX   = 3
 VVX0qk  = 4
 VVKWsc  = 5
 VVWmy2   = 6
 VVllZx   = 7
 VVgzyM  = 8
 VV6riH  = 9
 VVCJvV  = 10
 VVgq0m = 0
 VVqslv = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVxL8T    = None
  self.tableTitle     = "IPTV Channels List"
  self.VV8ZxGData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCDrYI.VVSss8(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CCOnT0.__init__(self)
  CCfr3d.__init__(self)
  VVGIDM = self.VV5t6f()
  FFCOTe(self, title="IPTV", VVGIDM=VVGIDM)
  self["myActionMap"].actions.update({
   "menu" : self.VVeZjI
  })
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV5eOb)
  global VVoMrG
  VVoMrG = True
 def VVg3Fx(self):
  self["myMenu"].setList(self.VV5t6f())
  FFkK1B(self)
  FF9NP9(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFyjr3(self["myMenu"])
   FFeEwo(self)
   if self.m3uOrM3u8File:
    self.VVClIK(self.m3uOrM3u8File)
   else:
    self.VVmcih()
 def VVmcih(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  if "chCode" in decodedUrl:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  FFAUiv("VVoMrG")
 def VV5eOb(self):
  if self["myMenu"].getCurrent()[1] in ("VVKdBr", "VVYXV0Portal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVeZjI(self):
  if self["myMenu"].getVisible():
   title, item = self["myMenu"].getCurrent()
   if   item == "VVYXV0Portal" : confItem = CFG.favServerPortal
   elif item == "VVKdBr" : confItem = CFG.favServerPlaylist
   else         : return
   FFP9Be(self, BF(self.VVyTnt, confItem), 'Remove from menu ?', title=title)
 def VVyTnt(self, confItem):
  FFSKZx(confItem, "")
  self.VVg3Fx()
 def VV5t6f(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVUVBT
  VVGIDM = []
  if isFav1: VVGIDM.append((c +  "Favourite Playlist Server"   , "VVKdBr" ))
  if isFav2: VVGIDM.append((c +  "Favourite Portal Server"    , "VVYXV0Portal" ))
  VVGIDM.append(("IPTV Server Browser (from Playlists)"     , "VV8ZxG_fromPlayList" ))
  VVGIDM.append(("IPTV Server Browser (from Portal List)"    , "VV8ZxG_fromMac"  ))
  VVGIDM.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VV8ZxG_fromM3u"  ))
  qUrl, iptvRef = CCDrYI.VVPFFr(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVGIDM.append(FFzUJ4("IPTV Server Browser (from Current Channel)", "VV8ZxG_fromCurrChan", fromCurCond))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("M3U/M3U8 File Browser"        , "VVv690"   ))
  if self.iptvFileAvailable:
   VVGIDM.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(FFzUJ4("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVGIDM.append(FFzUJ4("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVGIDM.append(VVVgKz)
   c1, c2 = VVZoWi, VVfZXg
   t1 = FFEK4e("auto-match names", VVUVBT)
   t2 = FFEK4e("from xml file"  , VVUVBT)
   VVGIDM.append((c1 + "Count Available IPTV Channels"    , "VViJwV"    ))
   VVGIDM.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVGIDM.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVqrxn" ))
   VVGIDM.append((VVWEO1 + "More Reference Tools ..."  , "VVOWKI"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Reload Channels and Bouquets"       , "VVIIvW"   ))
  VVGIDM.append(VVVgKz)
  if not CC6EZK.VVtCyi():
   VVGIDM.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVGIDM.append(("Download Manager ... No downloads"    ,       ))
  return VVGIDM
 def VVETXS(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVkVSB"   : self.VVkVSB()
   elif item == "VVHgzo" : FFP9Be(self, self.VVHgzo, "Change Current List References to Unique Codes ?")
   elif item == "VVi63O_rows" : FFP9Be(self, BF(FFVCur, self.VVxL8T, self.VVi63O), "Change Current List References to Identical Codes ?")
   elif item == "VVc69P"   : self.VVc69P(tTitle)
   elif item == "VVm1Ht"   : self.VVm1Ht(tTitle)
   elif item == "VVKdBr" : self.VVYXV0(False)
   elif item == "VVYXV0Portal" : self.VVYXV0(True)
   elif item == "VV8ZxG_fromPlayList" : FFVCur(self, BF(self.VVOc4F, 1), title=title)
   elif item == "VV8ZxG_fromM3u"  : FFVCur(self, BF(self.VV4bjn, CCDrYI.VVgq0m), title=title)
   elif item == "VV8ZxG_fromMac"  : self.VV55qp()
   elif item == "VV8ZxG_fromCurrChan" : self.VV81iG()
   elif item == "VVv690"   : self.VVv690()
   elif item == "iptvTable_all"   : FFVCur(self, BF(self.VVS6AV, self.VV4D8a), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCDrYI.VVoFXZ(self)
   elif item == "refreshIptvPicons"  : self.VVRQ1w()
   elif item == "VViJwV"    : FFVCur(self, self.VViJwV)
   elif item == "copyEpgPicons"   : self.VVWBYU(False)
   elif item == "renumIptvRef_fromFile" : self.VVWBYU(True)
   elif item == "VVqrxn" : FFP9Be(self, BF(FFVCur, self, self.VVqrxn), VVcsne="Continue ?")
   elif item == "VVOWKI"    : self.VVOWKI()
   elif item == "VVIIvW"   : FFVCur(self, BF(CCTc7M.VVIIvW, self))
   elif item == "dload_stat"    : CC6EZK.VVAVyn(self)
 def VVv690(self):
  if CCOnT0.VVqlCJ(self):
   FFVCur(self, BF(self.VV4bjn, CCDrYI.VVqslv), title="Searching ...")
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVETXS(item)
 def VVS6AV(self, mode):
  VVnhmb = self.VVwX0i(mode)
  if VVnhmb:
   VVoXaA = ("Current Service", self.VVEvc9 , [])
   VVMCbu = ("Options"  , self.VVQwyV   , [])
   VVUm5B = ("Filter"   , self.VV2Ec3   , [])
   VVRWOd  = ("Play"   , BF(self.VVcyZQ)  , [])
   VVMOfU = (""    , self.VVEyjZ    , [])
   VV6aZX = (""    , self.VV2s5g     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVyaAW  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFfJU2(self, None, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26
     , VVRWOd=VVRWOd, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VVMOfU=VVMOfU, VV6aZX=VV6aZX
     , VVXsDY="#0a00292B", VVEEoV="#0a002126", VVasam="#0a002126", VVhaQs="#00000000", VVehvv=True, searchCol=1)
  else:
   if mode == self.VV6joj: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFryuM(self, err)
 def VV2s5g(self, VVxL8T, title, txt, colList):
  self.VVxL8T = VVxL8T
 def VVQwyV(self, VVxL8T, title, txt, colList):
  VVGIDM = []
  VVGIDM.append(("Add Current List to a New Bouquet"    , "VVkVSB"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Change Current List References to Unique Codes" , "VVHgzo"))
  VVGIDM.append(("Change Current List References to Identical Codes", "VVi63O_rows" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Share Reference with DVB Service (manual entry)" , "VVc69P"   ))
  VVGIDM.append(("Share Reference with DVB Service (auto-find)"  , "VVm1Ht"   ))
  FFzctu(self, self.VVETXS, title="IPTV Tools", VVGIDM=VVGIDM)
 def VV2Ec3(self, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVs0AC, VVxL8T))
 def VVs0AC(self, VVxL8T):
  VVGIDM = []
  VVGIDM.append(("All"         , "all"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Prefix of Selected Channel"   , "sameName" ))
  VVGIDM.append(("Suggest Words from Selected Channel" , "partName" ))
  VVGIDM.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVGIDM.append(("Duplicate References"     , "depRef"  ))
  VVGIDM.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVGIDM.append(("Stream Relay"       , "SRelay"  ))
  VVGIDM.append(FFBeKw("Category"))
  VVGIDM.append(("Live TV"        , "live"  ))
  VVGIDM.append(("VOD"         , "vod"   ))
  VVGIDM.append(("Series"        , "series"  ))
  VVGIDM.append(("Uncategorised"      , "uncat"  ))
  VVGIDM.append(FFBeKw("Media"))
  VVGIDM.append(("Video"        , "video"  ))
  VVGIDM.append(("Audio"        , "audio"  ))
  VVGIDM.append(FFBeKw("File Type"))
  VVGIDM.append(("MKV"         , "MKV"   ))
  VVGIDM.append(("MP4"         , "MP4"   ))
  VVGIDM.append(("MP3"         , "MP3"   ))
  VVGIDM.append(("AVI"         , "AVI"   ))
  VVGIDM.append(("FLV"         , "FLV"   ))
  VVGIDM.extend(CCpURW.VVAnRt(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVhmPl, VVxL8T) if VVxL8T.VVPL4Q().startswith("IPTV Filter ") else None
  filterObj = CCgoW8(self)
  filterObj.VVkN7u(VVGIDM, VVGIDM, BF(self.VVEu0K, VVxL8T, False), inFilterFnc=inFilterFnc)
 def VVhmPl(self, VVxL8T, VVXrLB, item):
  self.VVEu0K(VVxL8T, True, item)
 def VVEu0K(self, VVxL8T, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVxL8T.VVJ5dP(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VV4D8a , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVEM9n , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVpqU2 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVfHwd , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVWq8O  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVYfa9  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VV134O  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VV6joj  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVU75w   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVvUWD  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VV1OA8  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VV8H6w  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVi0DH  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVobvA   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVdnLG   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVrXIn   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVMoIM   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVZv1s   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVxJHl  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVVMRW  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVpqU2:
   VVGIDM = []
   chName = VVxL8T.VVJ5dP(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVGIDM.append((item, item))
    if not VVGIDM and chName:
     VVGIDM.append((chName, chName))
    FFzctu(self, BF(self.VVub1t, title), title="Words from Current Selection", VVGIDM=VVGIDM)
   else:
    VVxL8T.VVurur("Invalid Channel Name")
  else:
   words, asPrefix = CCgoW8.VV15EP(words)
   if not words and mode in (self.VVxJHl, self.VVVMRW):
    FFqgHP(self.VVxL8T, "Incorrect filter", 2000)
   else:
    FFVCur(self.VVxL8T, BF(self.VVodTx, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVub1t(self, title, word=None):
  if word:
   words = [word.lower()]
   FFVCur(self.VVxL8T, BF(self.VVodTx, self.VVpqU2, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VV0D2E(txt):
  return "#f#11ffff00#" + txt
 def VVodTx(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVnhmb = self.VVQBHI(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVnhmb = self.VVwX0i(mode=mode, words=words, asPrefix=asPrefix)
  if VVnhmb : self.VVxL8T.VVlCGq(VVnhmb, title)
  else  : self.VVxL8T.VVurur("Not found")
 def VVQBHI(self, mode=0, words=None, asPrefix=False):
  VVnhmb = []
  for row in self.VVxL8T.VVWcfU():
   row = list(map(str.strip, row))
   chNum, chName, VVgs9R, chType, refCode, url = row
   if self.VVrkPA(mode, refCode, FFuEJn(url).lower(), chName, words, VVgs9R.lower(), asPrefix):
    VVnhmb.append(row)
  VVnhmb = self.VVucbd(mode, VVnhmb)
  return VVnhmb
 def VVwX0i(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVnhmb = []
  files = CCDrYI.VVSss8()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FF3unD(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVgs9R = span.group(1)
    else : VVgs9R = ""
    VVgs9R_lCase = VVgs9R.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVmrAp(chName): chNameMod = self.VV0D2E(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVgs9R, chType + (" SRel" if FFUkkg(url) else ""), refCode, url)
     if self.VVrkPA(mode, refCode, FFuEJn(url).lower(), chName, words, VVgs9R_lCase, asPrefix):
      VVnhmb.append(row)
      chNum += 1
  VVnhmb = self.VVucbd(mode, VVnhmb)
  return VVnhmb
 def VVucbd(self, mode, VVnhmb):
  newRows = []
  if VVnhmb and mode == self.VVWq8O:
   counted  = iCounter(elem[4] for elem in VVnhmb)
   for item in VVnhmb:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVnhmb
 def VVrkPA(self, mode, refCode, tUrl, chName, words, VVgs9R_lCase, asPrefix):
  if   mode == self.VV4D8a : return True
  elif mode == self.VVWq8O : return True
  elif mode == self.VVYfa9  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VV134O : return FFUkkg(tUrl)
  elif mode == self.VV8H6w  : return CCDrYI.VV5ztg(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVi0DH  : return CCDrYI.VV5ztg(tUrl, getAudVid=True) == "aud"
  elif mode == self.VV6joj  : return CCDrYI.VV5ztg(tUrl, compareType="live")
  elif mode == self.VVU75w  : return CCDrYI.VV5ztg(tUrl, compareType="movie")
  elif mode == self.VVvUWD : return CCDrYI.VV5ztg(tUrl, compareType="series")
  elif mode == self.VV1OA8  : return CCDrYI.VV5ztg(tUrl, compareType="")
  elif mode == self.VVobvA  : return CCDrYI.VV5ztg(tUrl, compareExt="mkv")
  elif mode == self.VVdnLG  : return CCDrYI.VV5ztg(tUrl, compareExt="mp4")
  elif mode == self.VVrXIn  : return CCDrYI.VV5ztg(tUrl, compareExt="mp3")
  elif mode == self.VVMoIM  : return CCDrYI.VV5ztg(tUrl, compareExt="avi")
  elif mode == self.VVZv1s  : return CCDrYI.VV5ztg(tUrl, compareExt="flv")
  elif mode == self.VVEM9n: return chName.lower().startswith(words[0])
  elif mode == self.VVpqU2: return words[0] in chName.lower()
  elif mode == self.VVfHwd: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVxJHl : return words[0] == VVgs9R_lCase
  elif mode == self.VVVMRW :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVkVSB(self):
  picker = CCpURW(self, self.VVxL8T, "Add to Bouquet", self.VVaU5Z)
 def VVaU5Z(self):
  chUrlLst = []
  for row in self.VVxL8T.VVWcfU():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVOWKI(self):
  t1 = FFEK4e("Bouquet" , VVfZXg)
  t2 = FFEK4e("ALL"  , VVWEO1)
  t3 = FFEK4e("Unique"  , VVZoWi)
  t4 = FFEK4e("Identical" , VVUVBT)
  VVGIDM = []
  VVGIDM.append((VVUrbH + "Check System Acceptable Reference Types", "VV9q1z"))
  VVGIDM.append(FFzUJ4("Check Reference Codes Format", "VVcJbt", self.iptvFileAvailable, VVUrbH))
  VVGIDM.append(VVVgKz)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVGIDM.append((txt % t1, "VVYHyK" ))
  VVGIDM.append((txt % t2, "VVbhDX_all"  ))
  VVGIDM.append(VVVgKz)
  txt = "Change %s References to %s Codes .."
  VVGIDM.append((txt % (t1, t3), "VVBDA1" ))
  VVGIDM.append((txt % (t2, t3), "VVH6k3"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Change %s References to %s Codes" % (t2, t4) , "VVi63O_all"))
  VV4v1i = self.VVmYMs
  FFzctu(self, None, width=1150, title="IPTV Reference Tools", VVGIDM=VVGIDM, VV4v1i=VV4v1i, VVXsDY="#22002233", VVEEoV="#22001122")
 def VVmYMs(self, item=None):
  if item:
   ques = "Continue ?"
   VVXrLB, txt, item, ndx = item
   if   item == "VV9q1z"    : FFVCur(VVXrLB, self.VV9q1z)
   elif item == "VVcJbt"     : FFVCur(VVXrLB, self.VVcJbt)
   elif item == "VVYHyK" : self.VVvN4P(VVXrLB, self.VVsjOX)
   elif item == "VVbhDX_all"  : self.VVsjOX(VVXrLB, None, None)
   elif item == "VVBDA1" : self.VVBDA1(VVXrLB, txt)
   elif item == "VVH6k3"  : FFP9Be(self, BF(self.VVH6k3 , VVXrLB, txt), title=txt, VVcsne=ques)
   elif item == "VVi63O_all"  : FFP9Be(self, BF(FFVCur, VVXrLB, self.VVi63O), title=txt, VVcsne=ques)
 def VVsjOX(self, VVXrLB, bName, bPath):
  VVGIDM = []
  for rt in CCDrYI.VVeGkX():
   VVGIDM.append(("%s\t ... %s" % (rt, CCDrYI.VV6clU(rt)), rt))
  FFzctu(self, BF(self.VVlALF, VVXrLB, bName, bPath), VVGIDM=VVGIDM, width=800, title="Change Reference Types to:")
 def VVlALF(self, VVXrLB, bName, bPath, rType=None):
  if rType:
   self.VVduSe(VVXrLB, bName, bPath, rType)
 def VVvN4P(self, VVXrLB, fnc):
  VVGIDM = CCpURW.VVAnRt()
  if VVGIDM:
   FFzctu(self, BF(self.VV8FV0, VVXrLB, fnc), VVGIDM=VVGIDM, title="IPTV Bouquets", VVglmG=True)
  else:
   FFqgHP(VVXrLB, "No bouquets Found !", 1500)
 def VV8FV0(self, VVXrLB, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVWgjG + span.group(1)
    if fileExists(bPath): fnc(VVXrLB, bName, bPath)
    else    : FFqgHP(VVXrLB, "Bouquet file not found!", 2000)
   else:
    FFqgHP(VVXrLB, "Cannot process bouquet !", 2000)
 def VVduSe(self, VVXrLB, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFEK4e(bName, VVWhci)
  else : title = "Change for %s" % FFEK4e("All IPTV Services", VVWhci)
  FFP9Be(self, BF(FFVCur, VVXrLB, BF(self.VV686O, VVXrLB, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFEK4e(rType, VVWhci), title=title)
 def VV686O(self, VVXrLB, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CCDrYI.VVSss8()
  if files:
   newRType = rType + ":"
   piconPath = CC9p8T.VVH8Sz()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCLyBs.VVzL6D(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFryuM(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFyakl("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFyakl(cmd)
  self.VVywx0(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VViJwV(self):
  totFiles = 0
  files  = CCDrYI.VVSss8()
  if files:
   totFiles = len(files)
  totChans = 0
  VVnhmb = self.VVwX0i()
  if VVnhmb:
   totChans = len(VVnhmb)
  FFDLqC(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVcJbt(self):
  files = CCDrYI.VVSss8()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FF3unD(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVijSd
   else    : color = VVnviq
   totInvalid = FFEK4e(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFEK4e("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFDLqC(self, txt, title="Check IPTV References")
 def VV9q1z(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCDrYI.VVeGkX()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCpURW.VVAuig(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVmXQH = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVmXQH:
   VVdbaC = FFsac0(VVmXQH)
   if VVdbaC:
    for service in VVdbaC:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVWgjG + userBName
  bFile = VVWgjG + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFbUbn("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFbUbn("rm -f '%s'" % path)
  FFyakl(cmd)
  FFWH63()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVijSd
    else     : res, color = "No" , VVnviq
    pl = CCDrYI.VV6clU(item)
    txt += "    %s\t: %s%s\n" % (item, FFEK4e(res, color), FFEK4e("\t... %s" % pl, VVhSN2) if pl else "")
   FFDLqC(self, txt, title=title)
  else:
   txt = FFryuM(self, "Could not complete the test on your system!", title=title)
 def VVqrxn(self):
  VVTSmb, err = CCTc7M.VVKjmx(self, CCTc7M.VVvHcL)
  if VVTSmb:
   totChannels = 0
   totChange = 0
   for path in CCDrYI.VVSss8():
    toSave = False
    txt = FF3unD(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVTSmb.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVywx0(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFryuM(self, 'No channels in "lamedb" !')
 def VVH6k3(self, VVXrLB, title):
  bFiles = CCDrYI.VVSss8()
  if bFiles: self.VVXb7j(bFiles, title)
  else  : FFqgHP(VVXrLB, "No bouquets files !", 1500)
 def VVBDA1(self, VVXrLB, title):
  self.VVvN4P(VVXrLB, BF(self.VVkZSZ, title))
 def VVkZSZ(self, title, VVXrLB, bName, bPath):
  self.VVXb7j([bPath], title)
 def VVXb7j(self, bFiles, title):
  self.session.open(CCChia, barTheme=CCChia.VV1d7P
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVabzv, bFiles)
      , VViIM0 = BF(self.VVN2XE, title))
 def VVabzv(self, bFiles, VVWRJ1):
  VVWRJ1.VVfN1b = ""
  VVWRJ1.VVDS8r("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FF5p6q(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVWRJ1 or VVWRJ1.isCancelled:
   return
  elif not totLines:
   VVWRJ1.VVfN1b = "No IPTV Services !"
   return
  else:
   VVWRJ1.VVsWOI(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FF5p6q(path)
    for ndx, line in enumerate(lines):
     if not VVWRJ1 or VVWRJ1.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVWRJ1:
       VVWRJ1.VVDS8r("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVWRJ1:
       VVWRJ1.VVYksR(1)
      refCode, startId, startNS = CCpURW.VVwEdd(rType, CCpURW.VVxj1O, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVWRJ1:
        VVWRJ1.VVfN1b = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVN2XE(self, title, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVfN1b:
   txt += "\n\n%s\n%s" % (FFEK4e("Ended with Error:", VVnviq), VVfN1b)
  self.VVywx0(True, title, txt)
 def VVHgzo(self):
  bFiles = CCDrYI.VVSss8()
  if not bFiles:
   FFqgHP(self.VVxL8T, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVxL8T.VVWcfU():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFqgHP(self.VVxL8T, "Cannot read list", 1500)
   return
  self.session.open(CCChia, barTheme=CCChia.VV1d7P
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVYu1E, bFiles, tableRefList)
      , VViIM0 = BF(self.VVN2XE, "Change Current List References to Unique Codes"))
 def VVYu1E(self, bFiles, tableRefList, VVWRJ1):
  VVWRJ1.VVfN1b = ""
  VVWRJ1.VVDS8r("Reading System References ...")
  refLst = CCpURW.VVzNZv(CCpURW.VVxj1O, stripRType=True)
  if not VVWRJ1 or VVWRJ1.isCancelled:
   return
  VVWRJ1.VVsWOI(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FF3unD(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVWRJ1 or VVWRJ1.isCancelled:
     return
    VVWRJ1.VVDS8r("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVWRJ1 or VVWRJ1.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVWRJ1.VVYksR(1)
      refCode, startId, startNS = CCpURW.VVwEdd(rType, CCpURW.VVxj1O, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVWRJ1:
        VVWRJ1.VVfN1b = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVi63O(self):
  list = None
  if self.VVxL8T:
   list = []
   for row in self.VVxL8T.VVWcfU():
    list.append(row[4] + row[5])
  files = CCDrYI.VVSss8()
  totChange = 0
  if files:
   for path in files:
    lines = FF5p6q(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVywx0(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVywx0(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFWH63()
   if refreshTable and self.VVxL8T:
    VVnhmb = self.VVwX0i()
    if VVnhmb and self.VVxL8T:
     self.VVxL8T.VVlCGq(VVnhmb, self.tableTitle)
     self.VVxL8T.VVurur(txt)
   FFDLqC(self, txt, title=title)
  else:
   FF6mzu(self, "No changes.")
 @staticmethod
 def VVSss8(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVWgjG + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FF3unD(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVEyjZ(self, VVxL8T, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFuEJn(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFNmLy(self, fncMode=CCVNso.VVPV73, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVbBVE(self, VVxL8T, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVcyZQ(self, VVxL8T, title, txt, colList):
  chName, chUrl = self.VVbBVE(VVxL8T, colList)
  self.VVaowx(VVxL8T, chName, chUrl, "localIptv")
 def VV1c1s(self, mode, VVxL8T, colList):
  chName, chUrl, picUrl, refCode = self.VV2Tdl(mode, colList)
  return chName, chUrl
 def VVEPiE(self, mode, VVxL8T, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV2Tdl(mode, colList)
  self.VVaowx(VVxL8T, chName, chUrl, mode)
 def VVaowx(self, VVxL8T, chName, chUrl, playerFlag):
  chName = FFLKj3(chName)
  if self.VVmrAp(chName):
   FFqgHP(VVxL8T, "This is a marker!", 300)
  else:
   FFVCur(VVxL8T, BF(self.VVW3N6, VVxL8T, chUrl, playerFlag), title="Playing ...")
 def VVW3N6(self, VVxL8T, chUrl, playerFlag):
  FFnh1l(self, chUrl, VV5sxe=False)
  CCTKa3.VV3qn6(self.session, iptvTableParams=(self, VVxL8T, playerFlag))
 @staticmethod
 def VVmrAp(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVEvc9(self, VVxL8T, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  if refCode:
   url1 = FFuEJn(origUrl.strip())
   for ndx, row in enumerate(VVxL8T.VVWcfU()):
    if refCode in row[4]:
     tableRow = FFuEJn(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVxL8T.VVyaYN(ndx)
      break
   else:
    FFqgHP(VVxL8T, "No found", 1000)
 def VV4bjn(self, m3uMode):
  lines = self.VVRkKI(3)
  if lines:
   lines.sort()
   VVGIDM = []
   for line in lines:
    VVGIDM.append((line, line))
   if m3uMode == CCDrYI.VVgq0m:
    title = "Browse Server from M3U URLs"
    VVacc0 = ("All to Playlist", self.VVKcFX)
   else:
    title = "M3U/M3U8 File Browser"
    VVacc0 = None
   VV4v1i = BF(self.VVwx8S, m3uMode, title)
   VVx6LK = self.VVoXWv
   FFzctu(self, None, title=title, VVGIDM=VVGIDM, width=1200, VV4v1i=VV4v1i, VVx6LK=VVx6LK, VVfIfT="", VVacc0=VVacc0, VVXsDY="#11221122", VVEEoV="#11221122")
 def VVwx8S(self, m3uMode, title, item=None):
  if item:
   VVXrLB, txt, path, ndx = item
   if m3uMode == CCDrYI.VVgq0m:
    FFVCur(VVXrLB, BF(self.VVq8ax, title, path))
   else:
    FFVCur(VVXrLB, BF(self.VVClIK, path))
 def VVClIK(self, path, m3uFilterParam=None, VVxL8T=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FF3unD(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VV0XWn(propLine, "group-title") or "-"
   if not group == "-" and self.VVnTZP(group):
    if not chName or self.VVyWFU(chName):
     if self.VVrkPA(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVnhmb = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVnhmb.append((name, str(tot), name))
    totAll += tot
   VVnhmb.sort(key=lambda x: x[0].lower())
   VVnhmb.insert(0, ("ALL", str(totAll), ""))
  if VVnhmb:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVxL8T:
    VVxL8T.VVlCGq(VVnhmb, newTitle=title, VVj0IZMsg=True)
   else:
    VVU1op = self.VVNnKg
    VVRWOd  = ("Select" , BF(self.VV64Ay, path, m3uFilterParam)  , [])
    VVUm5B = ("Filter" , BF(self.VV7IpM, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVyaAW  = (LEFT  , CENTER , LEFT )
    FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, width= 1400, height= 1000, VVNdFV=28, VVRWOd=VVRWOd, VVUm5B=VVUm5B, VVU1op=VVU1op, lastFindConfigObj=CFG.lastFindIptv
      , VVXsDY="#11110022", VVEEoV="#11110022", VVasam="#11110022", VVhaQs="#00444400")
  elif VVxL8T:
   FFe82w(VVxL8T, "Not found !", 1500)
  else:
   self.VVvIcn(FF3unD(path), "", m3uFilterParam)
 def VV64Ay(self, path, m3uFilterParam, VVxL8T, title, txt, colList):
  self.VVvIcn(FF3unD(path), colList[2], m3uFilterParam)
 def VV7IpM(self, path, m3uFilterParam, VVxL8T, title, txt, colList):
  VVGIDM = []
  VVGIDM.append(("All"      , "all"  ))
  VVGIDM.append(FFBeKw("Category"))
  VVGIDM.append(("Live TV"     , "live" ))
  VVGIDM.append(("VOD"      , "vod"  ))
  VVGIDM.append(("Series"     , "series" ))
  VVGIDM.append(("Uncategorised"   , "uncat" ))
  VVGIDM.append(FFBeKw("Media"))
  VVGIDM.append(("Video"     , "video" ))
  VVGIDM.append(("Audio"     , "audio" ))
  VVGIDM.append(FFBeKw("File Type"))
  VVGIDM.append(("MKV"      , "MKV"  ))
  VVGIDM.append(("MP4"      , "MP4"  ))
  VVGIDM.append(("MP3"      , "MP3"  ))
  VVGIDM.append(("AVI"      , "AVI"  ))
  VVGIDM.append(("FLV"      , "FLV"  ))
  filterObj = CCgoW8(self, VVXsDY="#11332244", VVEEoV="#11222244")
  filterObj.VVkN7u(VVGIDM, [], BF(self.VVFMcb, VVxL8T, path), inFilterFnc=None)
 def VVFMcb(self, VVxL8T, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VV4D8a , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VV6joj  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVU75w  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVvUWD  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VV1OA8  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VV8H6w  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVi0DH  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVobvA  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVdnLG  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVrXIn  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVMoIM  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVZv1s  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVVMRW  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCgoW8.VV15EP(words)
   if not mode == self.VV4D8a:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFEK4e(fTitle, VVhSN2)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFVCur(VVxL8T, BF(self.VVClIK, path, m3uFilterParam, VVxL8T), title="Filtering ...")
 def VVvIcn(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCChia, barTheme=CCChia.VVzhbG
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVfV0u, lst, filterGroup, m3uFilterParam)
       , VViIM0 = BF(self.VV8G6w, title, bName))
  else:
   self.VV5kmM("No valid lines found !", title)
 def VVfV0u(self, lst, filterGroup, m3uFilterParam, VVWRJ1):
  VVWRJ1.VVfN1b = []
  VVWRJ1.VVsWOI(len(lst))
  num = 0
  for cols in lst:
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   VVWRJ1.VVYksR(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VV0XWn(propLine, "group-title") or "-"
   picon = self.VV0XWn(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVnTZP(group) : skip = True
    elif chName and not self.VVyWFU(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVrkPA(mode, "", FFuEJn(url).lower(), chName, words, "", asPrefix)
    if not skip and VVWRJ1:
     num += 1
     VVWRJ1.VVfN1b.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VV8G6w(self, title, bName, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  if VVfN1b:
   VVU1op = self.VVNnKg
   VVRWOd  = ("Select"   , BF(self.VVjERH, title)   , [])
   VVMOfU = (""    , self.VV28dZ        , [])
   VVoXaA = ("Download PIcons", self.VV1hSN       , [])
   VVMCbu = ("Options"  , BF(self.VVeSeG, "m3Ch", "", bName) , [])
   VVUm5B = ("Posters Mode" , BF(self.VV0OqK, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVyaAW  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFfJU2(self, None, title=title, header=header, VVZAt4=VVfN1b, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=28, VVRWOd=VVRWOd, VVU1op=VVU1op, VVMOfU=VVMOfU, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindIptv, VVehvv=True, searchCol=1
     , VVXsDY="#0a00192B", VVEEoV="#0a00192B", VVasam="#0a00192B", VVhaQs="#00000000")
  else:
   self.VV5kmM("Not found !", title)
 def VV1hSN(self, VVxL8T, title, txt, colList):
  self.VVdIhB(VVxL8T, "m3u/m3u8")
 def VViygN(self, rowNum, url, chName):
  refCode = self.VVYew7(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFO7Oa(url), chName)
  return chUrl
 def VVYew7(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VV7Xb3(catID, stID, chNum)
  return refCode
 def VV0XWn(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVjERH(self, Title, VVxL8T, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFVCur(VVxL8T, BF(self.VVNDUU, Title, VVxL8T, colList), title="Checking Server ...")
  else:
   self.VVL39H(VVxL8T, url, chName)
 def VVNDUU(self, title, VVxL8T, colList):
  if not CCOnT0.VVqlCJ(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCPf1i.VVybt6(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVGIDM = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCDrYI.VVD1KR(url, fPath)
     VVGIDM.append((resol, fullUrl))
    if VVGIDM:
     if len(VVGIDM) > 1:
      FFzctu(self, BF(self.VVTGK2, VVxL8T, chName), VVGIDM=VVGIDM, title="Resolution", VVglmG=True, VVoaDe=True)
     else:
      self.VVL39H(VVxL8T, VVGIDM[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVL39H(VVxL8T, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCDrYI.VVD1KR(url, span.group(1))
       self.VVL39H(VVxL8T, fullUrl, chName)
      else:
       self.VVInOH("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVvIcn(txt, filterGroup="")
      return
    self.VVL39H(VVxL8T, url, chName)
   else:
    self.VV5kmM("Cannot process this channel !", title)
  else:
   self.VV5kmM(err, title)
 def VVTGK2(self, VVxL8T, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVL39H(VVxL8T, resolUrl, chName)
 def VVL39H(self, VVxL8T, url, chName):
  FFVCur(VVxL8T, BF(self.VVY2S2, VVxL8T, url, chName), title="Playing ...")
 def VVY2S2(self, VVxL8T, url, chName):
  chUrl = self.VViygN(VVxL8T.VVsf2R(), url, chName)
  FFnh1l(self, chUrl, VV5sxe=False)
  CCTKa3.VV3qn6(self.session, iptvTableParams=(self, VVxL8T, "m3u/m3u8"))
 def VVKO59(self, VVxL8T, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VViygN(VVxL8T.VVsf2R(), url, chName)
  return chName, chUrl
 def VV28dZ(self, VVxL8T, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFNmLy(self, fncMode=CCVNso.VVPV73, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VV5kmM(self, err, title):
  FFryuM(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVNnKg(self, VVxL8T):
  if self.m3uOrM3u8File:
   self.close()
  VVxL8T.cancel()
 def VVKcFX(self, selectionObj, item=None):
  FFVCur(selectionObj, BF(self.VVo34C, selectionObj, item))
 def VVo34C(self, selectionObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(selectionObj.VVGIDM):
    path = item[1]
    if fileExists(path):
     enc = CCme0M.VVfBpm(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCDrYI.VVE4Yj(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCDrYI.VV7Ska()
    pListF = "%sPlaylist_%s.txt" % (path, FFOa0m())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(selectionObj.VVGIDM)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFDLqC(self, txt, title=title)
   else:
    FFryuM(self, "Could not obtain URLs from this file list !", title=title)
 def VVOc4F(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVJLjf
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VV2H2O
  lines = self.VVRkKI(mode)
  if lines:
   lines.sort()
   VVGIDM = []
   for line in lines:
    VVGIDM.append((FFEK4e(line, VVfZXg) if "Bookmarks" in line else line, line))
   VVx6LK = self.VVoXWv
   FFzctu(self, None, title=title, VVGIDM=VVGIDM, width=1200, VV4v1i=okFnc, VVx6LK=VVx6LK, VVfIfT="")
 def VVoXWv(self, VVXrLB, txt, ref, ndx):
  txt = ref
  sz = FFl8II(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCLyBs.VVM24t(sz)
  FFDLqC(self, txt, title="File Path")
 def VVJLjf(self, item=None):
  if item:
   VVXrLB, txt, path, ndx = item
   FFVCur(VVXrLB, BF(self.VVVH0r, VVXrLB, path), title="Processing File ...")
 def VVVH0r(self, VV3yiy, path):
  enc = CCme0M.VVfBpm(path, self)
  if enc == -1:
   return
  VVnhmb = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF80Mz(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCDrYI.VV8Rhr(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVnhmb:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVnhmb.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVnhmb:
   title = "Playlist File : %s" % os.path.basename(path)
   VVRWOd  = ("Start"    , BF(self.VVVOKl, "Playlist File")      , [])
   VVr0hN = ("Home Menu"   , FFCuPQ             , [])
   VVoXaA = ("Download M3U File" , self.VVYWPf         , [])
   VVMCbu = ("Edit File"   , BF(self.VV3iXa, path)        , [])
   VVUm5B = ("Check & Filter"  , BF(self.VVEHQB, VV3yiy, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVyaAW  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVr0hN=VVr0hN, VVUm5B=VVUm5B, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVXsDY="#11001116", VVEEoV="#11001116", VVasam="#11001116", VVhaQs="#00003635", VVAXDQ="#0a333333", VVilD4="#11331100", VVehvv=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFryuM(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVYWPf(self, VVxL8T, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFP9Be(self, BF(FFVCur, VVxL8T, BF(self.VVqOnJ, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVqOnJ(self, title, url):
  path, err = FFgHO0(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFryuM(self, err, title=errTitle)
  elif fileExists(path):
   txt = FF3unD(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFbUco(path)
    FFryuM(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFbUco(path)
    FFryuM(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCDrYI.VV7Ska() + fName
    FFyakl("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FF6mzu(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFryuM(self, "Could not download the M3U file!", title=errTitle)
 def VVVOKl(self, Title, VVxL8T, title, txt, colList):
  url = colList[6]
  FFVCur(VVxL8T, BF(self.VV83PW, Title, url), title="Checking Server ...")
 def VV3iXa(self, path, VVxL8T, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CC8yF1(self, path, VViIM0=BF(self.VVcEKf, VVxL8T), curRowNum=rowNum)
  else    : FFAhcl(self, path)
 def VVcEKf(self, VVxL8T, fileChanged):
  if fileChanged:
   VVxL8T.cancel()
 def VVc69P(self, title):
  curChName = self.VVxL8T.VVJ5dP(1)
  FF9Fmo(self, BF(self.VVmpPr, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVmpPr(self, title, name):
  if name:
   VVTSmb, err = CCTc7M.VVKjmx(self, CCTc7M.VVAtdA, VVCFmo=False, VVyxvV=False)
   list = []
   if VVTSmb:
    name = self.VVLa8M(name)
    ratio = "1"
    for item in VVTSmb:
     if name in item[0].lower():
      list.append((item[0], FF28st(item[2]), item[3], ratio))
   if list : self.VVspHZ(list, title)
   else : FFryuM(self, "Not found:\n\n%s" % name, title=title)
 def VVm1Ht(self, title):
  curChName = self.VVxL8T.VVJ5dP(1)
  self.session.open(CCChia, barTheme=CCChia.VVzhbG
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVAsIT
      , VViIM0 = BF(self.VVibXb, title, curChName))
 def VVAsIT(self, VVWRJ1):
  curChName = self.VVxL8T.VVJ5dP(1)
  VVTSmb, err = CCTc7M.VVKjmx(self, CCTc7M.VV5ZYX, VVCFmo=False, VVyxvV=False)
  if not VVTSmb or not VVWRJ1 or VVWRJ1.isCancelled:
   return
  VVWRJ1.VVfN1b = []
  VVWRJ1.VVsWOI(len(VVTSmb))
  curCh = self.VVLa8M(curChName)
  for refCode in VVTSmb:
   chName, sat, inDB = VVTSmb.get(refCode, ("", "", 0))
   ratio = CC9p8T.VVijCP(chName.lower(), curCh)
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   VVWRJ1.VVYksR(1, True)
   if VVWRJ1 and ratio > 50:
    VVWRJ1.VVfN1b.append((chName, FF28st(sat), refCode.replace("_", ":"), str(ratio)))
 def VVibXb(self, title, curChName, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  if VVfN1b: self.VVspHZ(VVfN1b, title)
  elif VVmEsn: FFryuM(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVspHZ(self, VVnhmb, title):
  curChName = self.VVxL8T.VVJ5dP(1)
  VVK1gn = self.VVxL8T.VVJ5dP(4)
  curUrl  = self.VVxL8T.VVJ5dP(5)
  VVnhmb.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVRWOd  = ("Share Sat/C/T Ref.", BF(self.VVQJmH, title, curChName, VVK1gn, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVXsDY="#0a00112B", VVEEoV="#0a001126", VVasam="#0a001126", VVhaQs="#00000000")
 def VVQJmH(self, newtitle, curChName, VVK1gn, curUrl, VVxL8T, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVK1gn, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFP9Be(self.VVxL8T, BF(FFVCur, self.VVxL8T, BF(self.VVtSaH, VVxL8T, data)), ques, title=newtitle, VVi1cr=True)
 def VVtSaH(self, VVxL8T, data):
  VVxL8T.cancel()
  title, curChName, VVK1gn, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVK1gn = VVK1gn.strip()
  newRefCode = newRefCode.strip()
  if not VVK1gn.endswith(":") : VVK1gn += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVK1gn, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVK1gn + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CCDrYI.VVSss8():
    txt = FF3unD(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFWH63()
    newRow = []
    for i in range(6):
     newRow.append(self.VVxL8T.VVJ5dP(i))
    newRow[4] = newRefCode
    done = self.VVxL8T.VVkQYa(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFEuIr(BF(FF6mzu , self, resTxt, title=title))
  elif resErr: FFEuIr(BF(FFryuM, self, resErr, title=title))
 def VVEHQB(self, VV3yiy, path, VVxL8T, title, txt, colList):
  self.session.open(CCChia, barTheme=CCChia.VV1d7P
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVt6oL, VVxL8T)
      , VViIM0 = BF(self.VVFP1G, VV3yiy, path, VVxL8T))
 def VVt6oL(self, VVxL8T, VVWRJ1):
  VVWRJ1.VVsWOI(VVxL8T.VV9lfv())
  VVWRJ1.VVfN1b = []
  for row in VVxL8T.VVWcfU():
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   VVWRJ1.VVYksR(1, True)
   qUrl = self.VVDq86(self.VVHrYo, row[6])
   txt, err = self.VVI941(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVklIB(item, "auth") == "0":
       VVWRJ1.VVfN1b.append(qUrl)
    except:
     pass
 def VVFP1G(self, VV3yiy, path, VVxL8T, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  if VVmEsn:
   list = VVfN1b
   title = "Authorized Servers"
   if list:
    totChk = VVxL8T.VV9lfv()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFOa0m()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVOc4F(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFEK4e(str(totAuth), VVijSd)
     txt += "%s\n\n%s"    %  (FFEK4e("Result File:", VVfZXg), newPath)
     FFDLqC(self, txt, title=title)
     VVxL8T.close()
     VV3yiy.close()
    else:
     FF6mzu(self, "All URLs are authorized.", title=title)
   else:
    FFryuM(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVI941(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VV8Rhr(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VV5ztg(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CC8QHN.VVzGQB()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVNkCY(decodedUrl):
  return CCDrYI.VV5ztg(decodedUrl, justRetDotExt=True)
 def VVDq86(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV8Rhr(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVHrYo   : return "%s"            % url
  elif mode == self.VVMGQg   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVe9b1   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVSiDX  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVX0qk  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVKWsc : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVWmy2   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVllZx    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVgzyM  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVCJvV : return "%s&action=get_live_streams"      % url
  elif mode == self.VV6riH  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVklIB(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFkL2p(int(val))
    elif is_base64 : val = FFxoCd(val)
    elif isToHHMMSS : val = FFTaUe(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVq8ax(self, title, path):
  if fileExists(path):
   enc = CCme0M.VVfBpm(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCDrYI.VVE4Yj(line)
     if qUrl:
      break
   if qUrl : self.VV83PW(title, qUrl)
   else : FFryuM(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFryuM(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV81iG(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCDrYI.VVPFFr(self)
  if qUrl or "chCode" in iptvRef:
   p = CCPf1i()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVSbpM(iptvRef)
   if valid:
    self.VVU6T5(self, host, mac)
    return
   elif qUrl:
    FFVCur(self, BF(self.VV83PW, title, qUrl), title="Checking Server ...")
    return
  FFryuM(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVPFFr(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(SELF)
  qUrl = CCDrYI.VVE4Yj(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVE4Yj(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VV83PW(self, title, url):
  self.curUrl = url
  self.VV8ZxGData = {}
  qUrl = self.VVDq86(self.VVHrYo, url)
  txt, err = self.VVI941(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VV8ZxGData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VV8ZxGData["username"    ] = self.VVklIB(item, "username"        )
    self.VV8ZxGData["password"    ] = self.VVklIB(item, "password"        )
    self.VV8ZxGData["message"    ] = self.VVklIB(item, "message"        )
    self.VV8ZxGData["auth"     ] = self.VVklIB(item, "auth"         )
    self.VV8ZxGData["status"    ] = self.VVklIB(item, "status"        )
    self.VV8ZxGData["exp_date"    ] = self.VVklIB(item, "exp_date"    , isDate=True )
    self.VV8ZxGData["is_trial"    ] = self.VVklIB(item, "is_trial"        )
    self.VV8ZxGData["active_cons"   ] = self.VVklIB(item, "active_cons"       )
    self.VV8ZxGData["created_at"   ] = self.VVklIB(item, "created_at"   , isDate=True )
    self.VV8ZxGData["max_connections"  ] = self.VVklIB(item, "max_connections"      )
    self.VV8ZxGData["allowed_output_formats"] = self.VVklIB(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VV8ZxGData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VV8ZxGData["url"    ] = self.VVklIB(item, "url"        )
    self.VV8ZxGData["port"    ] = self.VVklIB(item, "port"        )
    self.VV8ZxGData["https_port"  ] = self.VVklIB(item, "https_port"      )
    self.VV8ZxGData["server_protocol" ] = self.VVklIB(item, "server_protocol"     )
    self.VV8ZxGData["rtmp_port"   ] = self.VVklIB(item, "rtmp_port"       )
    self.VV8ZxGData["timezone"   ] = self.VVklIB(item, "timezone"       )
    self.VV8ZxGData["timestamp_now"  ] = self.VVklIB(item, "timestamp_now"  , isDate=True )
    self.VV8ZxGData["time_now"   ] = self.VVklIB(item, "time_now"       )
    VVGIDM  = self.VV1lQb(True)
    VV4v1i = self.VVvc4p
    VVx6LK = self.VV34Zb
    VVw5pZ = ("Home Menu", FFCuPQ)
    VVQaYB= ("Add to Menu", BF(CCDrYI.VV9N60, self, False, self.VV8ZxGData["playListURL"]))
    VVacc0 = ("Bookmark Server", BF(CCDrYI.VVUfGj, self, False, self.VV8ZxGData["playListURL"]))
    FFzctu(self, None, title="IPTV Server Resources", VVGIDM=VVGIDM, VV4v1i=VV4v1i, VVx6LK=VVx6LK, VVw5pZ=VVw5pZ, VVQaYB=VVQaYB, VVacc0=VVacc0)
   else:
    err = "Could not get data from server !"
  if err:
   FFryuM(self, err, title=title)
  FFqgHP(self)
 def VVvc4p(self, item=None):
  if item:
   VVXrLB, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFVCur(VVXrLB, BF(self.VV7mM0, self.VVMGQg  , title=title), title=wTxt)
   elif ref == "vod"   : FFVCur(VVXrLB, BF(self.VV7mM0, self.VVe9b1  , title=title), title=wTxt)
   elif ref == "series"  : FFVCur(VVXrLB, BF(self.VV7mM0, self.VVSiDX , title=title), title=wTxt)
   elif ref == "catchup"  : FFVCur(VVXrLB, BF(self.VV7mM0, self.VVX0qk , title=title), title=wTxt)
   elif ref == "accountInfo" : FFVCur(VVXrLB, BF(self.VVmGNy           , title=title), title=wTxt)
 def VV34Zb(self, VVXrLB, txt, ref, ndx):
  FFVCur(VVXrLB, self.VV8prp)
 def VV8prp(self):
  txt = self.curUrl
  if VVUwTh:
   ver, err = self.VVTtsI(self.VV5iZi())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VV5VB0
   txt += "PHP\t: %s\n"  % self.VVc4Z6
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVRs8c, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFDLqC(self, txt, title="Current Server URL")
 def VVmGNy(self, title):
  rows = []
  for key, val in self.VV8ZxGData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVwzyA
   else:
    num, part = "1", self.VV9FZE
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVr0hN  = ("Home Menu", FFCuPQ, [])
  VVoXaA  = None
  if VVUwTh:
   VVoXaA = ("Get JS" , BF(self.VV8O9Z, "/".join(self.VV8ZxGData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFfJU2(self, None, title=title, width=1200, header=header, VVZAt4=rows, VVbiLs=widths, VVNdFV=26, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVXsDY="#0a00292B", VVEEoV="#0a002126", VVasam="#0a002126", VVhaQs="#00000000", searchCol=2)
 def VV2JJv(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVWmy2, self.VV6riH):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVklIB(item, "num"         )
      name     = self.VVklIB(item, "name"        )
      stream_id    = self.VVklIB(item, "stream_id"       )
      stream_icon    = self.VVklIB(item, "stream_icon"       )
      epg_channel_id   = self.VVklIB(item, "epg_channel_id"      )
      added     = self.VVklIB(item, "added"    , isDate=True )
      is_adult    = self.VVklIB(item, "is_adult"       )
      category_id    = self.VVklIB(item, "category_id"       )
      tv_archive    = self.VVklIB(item, "tv_archive"       )
      direct_source   = self.VVklIB(item, "direct_source"      )
      tv_archive_duration  = self.VVklIB(item, "tv_archive_duration"     )
      name = self.VVyWFU(name, is_adult)
      if name:
       if mode == self.VVWmy2 or mode == self.VV6riH and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVllZx:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVklIB(item, "num"         )
      name    = self.VVklIB(item, "name"        )
      stream_id   = self.VVklIB(item, "stream_id"       )
      stream_icon   = self.VVklIB(item, "stream_icon"       )
      added    = self.VVklIB(item, "added"    , isDate=True )
      is_adult   = self.VVklIB(item, "is_adult"       )
      category_id   = self.VVklIB(item, "category_id"       )
      container_extension = self.VVklIB(item, "container_extension"     ) or "mp4"
      name = self.VVyWFU(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVgzyM:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVklIB(item, "num"        )
      name    = self.VVklIB(item, "name"       )
      series_id   = self.VVklIB(item, "series_id"      )
      cover    = self.VVklIB(item, "cover"       )
      genre    = self.VVklIB(item, "genre"       )
      episode_run_time = self.VVklIB(item, "episode_run_time"    )
      category_id   = self.VVklIB(item, "category_id"      )
      container_extension = self.VVklIB(item, "container_extension"    ) or "mp4"
      name = self.VVyWFU(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VV7mM0(self, mode, title):
  cList, err = self.VVMx3G(mode)
  if cList and mode == self.VVX0qk:
   cList = self.VVl9Mo(cList)
  if err:
   FFryuM(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVXsDY, VVEEoV, VVasam, VVhaQs = self.VVSqeR(mode)
   mName = self.VV6yyb(mode)
   if   mode == self.VVMGQg  : fMode = self.VVWmy2
   elif mode == self.VVe9b1  : fMode = self.VVllZx
   elif mode == self.VVSiDX : fMode = self.VVgzyM
   elif mode == self.VVX0qk : fMode = self.VV6riH
   if mode == self.VVX0qk:
    VVMCbu = None
    VVUm5B = None
   else:
    VVMCbu = ("Find in %s" % mName , BF(self.VVMVos, fMode, True) , [])
    VVUm5B = ("Find in Selected" , BF(self.VVMVos, fMode, False) , [])
   VVRWOd   = ("Show List"   , BF(self.VVs4X2, mode)  , [])
   VVr0hN  = ("Home Menu"   , FFCuPQ         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFfJU2(self, None, title=title, width=1200, header=header, VVZAt4=cList, VVbiLs=widths, VVNdFV=30, VVr0hN=VVr0hN, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VVRWOd=VVRWOd, VVXsDY=VVXsDY, VVEEoV=VVEEoV, VVasam=VVasam, VVhaQs=VVhaQs, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFryuM(self, "No list from server !", title=title)
  FFqgHP(self)
 def VVMx3G(self, mode):
  qUrl  = self.VVDq86(mode, self.VV8ZxGData["playListURL"])
  txt, err = self.VVI941(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVklIB(item, "category_id"  )
     category_name = self.VVklIB(item, "category_name" )
     parent_id  = self.VVklIB(item, "parent_id"  )
     category_name = self.VVnTZP(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVl9Mo(self, catList):
  mode  = self.VV6riH
  qUrl  = self.VVDq86(mode, self.VV8ZxGData["playListURL"])
  txt, err = self.VVI941(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VV2JJv(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVs4X2(self, mode, VVxL8T, title, txt, colList):
  title = colList[1]
  FFVCur(VVxL8T, BF(self.VVKRRN, mode, VVxL8T, title, txt, colList), title="Downloading ...")
 def VVKRRN(self, mode, VVxL8T, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VV6yyb(mode) + " : "+ bName
  if   mode == self.VVMGQg  : mode = self.VVWmy2
  elif mode == self.VVe9b1  : mode = self.VVllZx
  elif mode == self.VVSiDX : mode = self.VVgzyM
  elif mode == self.VVX0qk : mode = self.VV6riH
  qUrl  = self.VVDq86(mode, self.VV8ZxGData["playListURL"], catID)
  txt, err = self.VVI941(qUrl)
  list  = []
  if not err and mode in (self.VVWmy2, self.VVllZx, self.VVgzyM, self.VV6riH):
   list, err = self.VV2JJv(mode, txt)
  if err:
   FFryuM(self, err, title=title)
  elif list:
   VVr0hN  = ("Home Menu"   , FFCuPQ            , [])
   if mode in (self.VVWmy2, self.VV6riH):
    VVXsDY, VVEEoV, VVasam, VVhaQs = self.VVSqeR(mode)
    VVMOfU = (""     , BF(self.VVN3Tv, mode)      , [])
    VVoXaA = ("Download Options" , BF(self.VVtBV2, mode, "", "")   , [])
    VVMCbu = ("Options"   , BF(self.VVeSeG, "lv", mode, bName)   , [])
    VVUm5B = ("Posters Mode"  , BF(self.VV0OqK, mode, False)     , [])
    if mode == self.VVWmy2:
     VVRWOd = ("Play"    , BF(self.VVEPiE, mode)       , [])
    else:
     VVRWOd = ("Programs"   , BF(self.VVQzJZ, mode, bName) , [])
   elif mode == self.VVllZx:
    VVXsDY, VVEEoV, VVasam, VVhaQs = self.VVSqeR(mode)
    VVRWOd  = ("Play"    , BF(self.VVEPiE, mode)       , [])
    VVMOfU = (""     , BF(self.VVN3Tv, mode)      , [])
    VVoXaA = ("Download Options" , BF(self.VVtBV2, mode, "v", "")   , [])
    VVMCbu = ("Options"   , BF(self.VVeSeG, "v", mode, bName)   , [])
    VVUm5B = ("Posters Mode"  , BF(self.VV0OqK, mode, False)     , [])
   elif mode == self.VVgzyM:
    VVXsDY, VVEEoV, VVasam, VVhaQs = self.VVSqeR("series2")
    VVRWOd  = ("Show Seasons"  , BF(self.VVl7kn, mode)       , [])
    VVMOfU = (""     , BF(self.VVyOcI, mode)     , [])
    VVoXaA = None
    VVMCbu = None
    VVUm5B = ("Posters Mode"  , BF(self.VV0OqK, mode, True)      , [])
   header, widths, VVyaAW = self.VVO5Ck(mode)
   FFfJU2(self, None, title=title, header=header, VVZAt4=list, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindIptv, VVMOfU=VVMOfU, VVXsDY=VVXsDY, VVEEoV=VVEEoV, VVasam=VVasam, VVhaQs=VVhaQs, VVehvv=True, searchCol=1)
  else:
   FFryuM(self, "No Channels found !", title=title)
  FFqgHP(self)
 def VVO5Ck(self, mode):
  if mode in (self.VVWmy2, self.VV6riH):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVyaAW  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVllZx:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVyaAW  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVgzyM:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVyaAW  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVyaAW
 def VVQzJZ(self, mode, bName, VVxL8T, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VV8ZxGData["playListURL"]
  ok_fnc  = BF(self.VVOazi, hostUrl, chName, catId, streamId)
  FFVCur(VVxL8T, BF(CCDrYI.VVn1Th, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVOazi(self, chUrl, chName, catId, streamId, VVxL8T, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCDrYI.VV8Rhr(chUrl)
   chNum = "333"
   refCode = CCDrYI.VV7Xb3(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFnh1l(self, chUrl, VV5sxe=False)
   CCTKa3.VV3qn6(self.session)
  else:
   FFryuM(self, "Incorrect Timestamp", pTitle)
 def VVl7kn(self, mode, VVxL8T, title, txt, colList):
  title = colList[1]
  FFVCur(VVxL8T, BF(self.VVRCoh, mode, VVxL8T, title, txt, colList), title="Downloading ...")
 def VVRCoh(self, mode, VVxL8T, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVDq86(self.VVKWsc, self.VV8ZxGData["playListURL"], series_id)
  txt, err = self.VVI941(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVklIB(tDict["info"], "name"   )
      category_id = self.VVklIB(tDict["info"], "category_id" )
      icon  = self.VVklIB(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVklIB(EP, "id"     )
        episode_num   = self.VVklIB(EP, "episode_num"   )
        epTitle    = self.VVklIB(EP, "title"     )
        container_extension = self.VVklIB(EP, "container_extension" )
        seasonNum   = self.VVklIB(EP, "season"    )
        epTitle = self.VVyWFU(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFryuM(self, err, title=title)
  elif list:
   VVr0hN = ("Home Menu"   , FFCuPQ          , [])
   VVoXaA = ("Download Options" , BF(self.VVtBV2, mode, "s", title), [])
   VVMCbu = ("Options"   , BF(self.VVeSeG, "s", mode, title) , [])
   VVUm5B = ("Posters Mode"  , BF(self.VV0OqK, mode, False)   , [])
   VVMOfU = (""     , BF(self.VVN3Tv, mode)    , [])
   VVRWOd  = ("Play"    , BF(self.VVEPiE, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVyaAW  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFfJU2(self, None, title=title, header=header, VVZAt4=list, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVMCbu=VVMCbu, VVUm5B=VVUm5B, lastFindConfigObj=CFG.lastFindIptv, VVXsDY="#0a00292B", VVEEoV="#0a002126", VVasam="#0a002126", VVhaQs="#00000000")
  else:
   FFryuM(self, "No Channels found !", title=title)
  FFqgHP(self)
 def VVMVos(self, mode, isAll, VVxL8T, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVGIDM = []
  VVGIDM.append(("Keyboard"  , "manualEntry"))
  VVGIDM.append(("From Filter" , "fromFilter"))
  FFzctu(self, BF(self.VVy6J3, VVxL8T, mode, onlyCatID), title="Input Type", VVGIDM=VVGIDM, width=400)
 def VVy6J3(self, VVxL8T, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FF9Fmo(self, BF(self.VVcsEr, VVxL8T, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCgoW8(self)
    filterObj.VV1oDN(BF(self.VVcsEr, VVxL8T, mode, onlyCatID))
 def VVcsEr(self, VVxL8T, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFSKZx(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCgoW8.VV15EP(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFryuM(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFryuM(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVqWGY(words):
      FFryuM(self, self.VVNX3i(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCChia, barTheme=CCChia.VVzhbG
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VV7u1O, VVxL8T, mode, onlyCatID, title, words, toFind, asPrefix)
          , VViIM0 = BF(self.VVOUZj, mode, toFind, title))
   if not words:
    FFqgHP(VVxL8T, "Nothing to find !", 1500)
 def VV7u1O(self, VVxL8T, mode, onlyCatID, title, words, toFind, asPrefix, VVWRJ1):
  VVWRJ1.VVsWOI(VVxL8T.VVERJ7() if onlyCatID is None else 1)
  VVWRJ1.VVfN1b = []
  for row in VVxL8T.VVWcfU():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   VVWRJ1.VVYksR(1)
   VVWRJ1.VVIHyJ(catName)
   qUrl  = self.VVDq86(mode, self.VV8ZxGData["playListURL"], catID)
   txt, err = self.VVI941(qUrl)
   if not err:
    tList, err = self.VV2JJv(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVyWFU(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVWRJ1 or VVWRJ1.isCancelled:
        return
       VVWRJ1.VVfN1b.append(item)
       VVWRJ1.VVIHyJ(catName)
 def VVOUZj(self, mode, toFind, title, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  if VVfN1b:
   title = self.VVbXEA(mode, toFind)
   if mode == self.VVWmy2 or mode == self.VVllZx:
    if mode == self.VVllZx : typ = "v"
    else          : typ = ""
    bName   = CCDrYI.VVOPP7(toFind)
    VVRWOd  = ("Play"     , BF(self.VVEPiE, mode)     , [])
    VVoXaA = ("Download Options" , BF(self.VVtBV2, mode, typ, "") , [])
    VVMCbu = ("Options"   , BF(self.VVeSeG, "fnd", mode, bName), [])
    VVUm5B = ("Posters Mode"  , BF(self.VV0OqK, mode, False)   , [])
    VVMOfU = (""     , BF(self.VVN3Tv, mode)    , [])
   elif mode == self.VVgzyM:
    VVRWOd  = ("Show Seasons"  , BF(self.VVl7kn, mode)     , [])
    VVMCbu = None
    VVoXaA = None
    VVUm5B = ("Posters Mode"  , BF(self.VV0OqK, mode, True)    , [])
    VVMOfU = (""     , BF(self.VVyOcI, mode)   , [])
   VVr0hN  = ("Home Menu"   , FFCuPQ          , [])
   header, widths, VVyaAW = self.VVO5Ck(mode)
   VVxL8T = FFfJU2(self, None, title=title, header=header, VVZAt4=VVfN1b, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VVMOfU=VVMOfU, VVXsDY="#0a00292B", VVEEoV="#0a002126", VVasam="#0a002126", VVhaQs="#00000000", VVehvv=True, searchCol=1)
   if not VVmEsn:
    FFqgHP(VVxL8T, "Stopped" , 1000)
  else:
   if VVmEsn:
    FFryuM(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VV2Tdl(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVWmy2, self.VV6riH):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVllZx:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFLKj3(chName)
  url = self.VV8ZxGData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VV8Rhr(url)
  refCode = self.VV7Xb3(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVN3Tv(self, mode, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVCe7U, mode, VVxL8T, title, txt, colList))
 def VVCe7U(self, mode, VVxL8T, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VV2Tdl(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFNmLy(self, fncMode=CCVNso.VVoDFh, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVyOcI(self, mode, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VV8CMG, mode, VVxL8T, title, txt, colList))
 def VV8CMG(self, mode, VVxL8T, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFNmLy(self, fncMode=CCVNso.VVfJ0f, chName=name, text=txt, picUrl=Cover)
 def VV0OqK(self, mode, isSerNames, VVxL8T, title, txt, colList):
  if   mode in ("itv"  , CCDrYI.VVWmy2, CCDrYI.VV6riH): category = "live"
  elif mode in ("vod"  , CCDrYI.VVllZx )          : category = "vod"
  elif mode in ("series" , CCDrYI.VVgzyM)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVWmy2 : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV6riH : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVllZx  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVgzyM : picCol, descCol, descTxt = 5, 0, "Season"
  FFVCur(VVxL8T, BF(self.session.open, CCqBwG, VVxL8T, category, nameCol, picCol, descCol, descTxt))
 def VVtBV2(self, mode, typ, seriesName, VVxL8T, title, txt, colList):
  VVGIDM = []
  isMulti = VVxL8T.VV1dHJ
  tot  = VVxL8T.VVwKPO()
  if isMulti:
   if tot < 1:
    FFqgHP(VVxL8T, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVGIDM.append(("Download %s PIcon%s" % (name, FFlPiz(tot)), "dnldPicons" ))
  if typ:
   VVGIDM.append(VVVgKz)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVGIDM.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVGIDM.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVGIDM.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CC6EZK.VVtCyi():
    VVGIDM.append(VVVgKz)
    VVGIDM.append(("Download Manager"      , "dload_stat" ))
  FFzctu(self, BF(self.VVdkCm, VVxL8T, mode, typ, seriesName, colList), title="Download Options", VVGIDM=VVGIDM)
 def VVdkCm(self, VVxL8T, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVdIhB(VVxL8T, mode)
   elif item == "dnldSel"  : self.VV8LrP(VVxL8T, mode, typ, colList, True)
   elif item == "addSel"  : self.VV8LrP(VVxL8T, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVbOqY(VVxL8T, mode, typ, seriesName)
   elif item == "dload_stat" : CC6EZK.VVAVyn(self, VVxL8T)
 def VV8LrP(self, VVxL8T, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVUnN5(mode, typ, colList)
  if startDnld:
   CC6EZK.VVWkuu(self, decodedUrl)
  else:
   self.VVRfQc(VVxL8T, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVbOqY(self, VVxL8T, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVxL8T.VVWcfU():
   chName, decodedUrl = self.VVUnN5(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVRfQc(VVxL8T, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVRfQc(self, VVxL8T, title, chName, decodedUrl_list, startDnld):
  FFP9Be(self, BF(self.VV4y7v, VVxL8T, decodedUrl_list, startDnld), chName, title=title)
 def VV4y7v(self, VVxL8T, decodedUrl_list, startDnld):
  added, skipped = CC6EZK.VVEq5N(decodedUrl_list)
  FFqgHP(VVxL8T, "Added", 1000)
 def VVUnN5(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VV2Tdl(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVUcYo(mode, colList)
   refCode, chUrl = self.VVe9v0(self.VV5VB0, self.VVZqGU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFqwVq(chUrl)
  return chName, decodedUrl
 def VVdIhB(self, VVxL8T, mode):
  if FFE0hR("ffmpeg"):
   self.session.open(CCChia, barTheme=CCChia.VV1d7P
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVWsyx, VVxL8T, mode)
       , VViIM0 = self.VVZ33T)
  else:
   FFP9Be(self, BF(CCDrYI.VVVTNI, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVZ33T(self, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVfN1b["proces"], VVfN1b["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVfN1b["ok"], VVfN1b["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVfN1b["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVfN1b["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVfN1b["badURL"]
  txt += "Download Failure\t: %d\n"   % VVfN1b["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVfN1b["path"]
  if not VVmEsn  : color = "#11402000"
  elif VVfN1b["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVfN1b["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVfN1b["err"], txt)
  title = "PIcons Download Result"
  if not VVmEsn:
   title += "  (cancelled)"
  FFDLqC(self, txt, title=title, VVasam=color)
 def VVWsyx(self, VVxL8T, mode, VVWRJ1):
  isMulti = VVxL8T.VV1dHJ
  if isMulti : totRows = VVxL8T.VVwKPO()
  else  : totRows = VVxL8T.VVERJ7()
  VVWRJ1.VVsWOI(totRows)
  VVWRJ1.VVlvVO(0)
  counter     = VVWRJ1.counter
  maxValue    = VVWRJ1.maxValue
  pPath     = CC9p8T.VVH8Sz()
  VVWRJ1.VVfN1b = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVxL8T.VVWcfU()):
    if VVWRJ1.isCancelled:
     break
    if not isMulti or VVxL8T.VVeezj(rowNum):
     VVWRJ1.VVfN1b["proces"] += 1
     VVWRJ1.VVYksR(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVUcYo(mode, row)
      refCode = CCDrYI.VV7Xb3(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVYew7(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VV2Tdl(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVWRJ1.VVfN1b["attempt"] += 1
       path, err = FFgHO0(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVWRJ1:
         VVWRJ1.VVfN1b["ok"] += 1
         VVWRJ1.VVlvVO(VVWRJ1.VVfN1b["ok"])
        if FFl8II(path) > 0:
         cmd = CCVNso.VVCQjh(path)
         cmd += FFbUbn("mv -f '%s' '%s'" % (path, pPath))
         FFyakl(cmd)
        else:
         if VVWRJ1:
          VVWRJ1.VVfN1b["size0"] += 1
         FFbUco(path)
       elif err:
        if VVWRJ1:
         VVWRJ1.VVfN1b["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVWRJ1:
          VVWRJ1.VVfN1b["err"] = err.title()
         break
      else:
       if VVWRJ1:
        VVWRJ1.VVfN1b["exist"] += 1
     else:
      if VVWRJ1:
       VVWRJ1.VVfN1b["badURL"] += 1
  except:
   pass
 def VVRQ1w(self):
  title = "Download PIcons for Current Bouquet"
  if FFE0hR("ffmpeg"):
   self.session.open(CCChia, barTheme=CCChia.VV1d7P
       , titlePrefix = ""
       , fncToRun  = self.VVaRff
       , VViIM0 = BF(self.VV7XS0, title))
  else:
   FFP9Be(self, BF(CCDrYI.VVVTNI, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVaRff(self, VVWRJ1):
  bName = CCpURW.VVTAtr()
  pPath = CC9p8T.VVH8Sz()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVWRJ1.VVfN1b = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCpURW.VV4QEE()
  if not VVWRJ1 or VVWRJ1.isCancelled:
   return
  if not services or len(services) == 0:
   VVWRJ1.VVfN1b = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVWRJ1.VVsWOI(totCh)
  VVWRJ1.VVlvVO(0)
  for serv in services:
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   VVWRJ1.VVfN1b = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVWRJ1.VVYksR(1)
   VVWRJ1.VVlvVO(totPic)
   fullRef  = serv[0]
   if FFkZVp(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFqwVq(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCPf1i.VVt91K(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCDrYI.VV5ztg(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCDrYI.VVI941(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCVNso.VVPJbK(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFgHO0(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVWRJ1:
     VVWRJ1.VVlvVO(totPic)
    if FFl8II(path) > 0:
     cmd = CCVNso.VVCQjh(path)
     cmd += FFbUbn("mv -f '%s' '%s'" % (path, pPath))
     FFyakl(cmd)
     totPicOK += 1
    else:
     totSize0
     FFbUco(path)
  if VVWRJ1:
   VVWRJ1.VVfN1b = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VV7XS0(self, title, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVfN1b
  if err:
   FFryuM(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFEK4e(str(totExist)  , VVnviq)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFEK4e(str(totNotIptv)  , VVnviq)
    if totServErr : txt += "Server Errors\t: %s\n" % FFEK4e(str(totServErr) + t1, VVnviq)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFEK4e(str(totParseErr) , VVnviq)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFEK4e(str(totInvServ)  , VVnviq)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFEK4e(str(totInvPicUrl) , VVnviq)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFEK4e(str(totSize0)  , VVnviq)
   if not VVmEsn:
    title += "  (stopped)"
   FFDLqC(self, txt, title=title)
 @staticmethod
 def VVVTNI(SELF):
  cmd = FFM6zB(VVP2Dj, "ffmpeg")
  if cmd : FF8jLK(SELF, cmd, title="Installing FFmpeg")
  else : FFRzIz(SELF)
 @staticmethod
 def VVoFXZ(SELF):
  SELF.session.open(CCChia, barTheme=CCChia.VV1d7P
      , titlePrefix = ""
      , fncToRun  = CCDrYI.VVxt2w
      , VViIM0 = BF(CCDrYI.VV7wlD, SELF))
 @staticmethod
 def VVxt2w(VVWRJ1):
  bName = CCpURW.VVTAtr()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVWRJ1.VVfN1b = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCpURW.VV4QEE()
  if not VVWRJ1 or VVWRJ1.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVWRJ1.VVsWOI(totCh)
   for serv in services:
    if not VVWRJ1 or VVWRJ1.isCancelled:
     return
    VVWRJ1.VVYksR(1)
    fullRef = serv[0]
    if FFkZVp(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFqwVq(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCPf1i.VVc1r5(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CCDrYI.VV5ztg(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CCDrYI.VV6ukR(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVWRJ1:
      VVWRJ1.VVlMI5(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCgL5j.VVpL8h(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVWRJ1:
     VVWRJ1.VVfN1b = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVWRJ1.VVfN1b = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VV7wlD(SELF, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVfN1b
  title = "IPTV EPG Import"
  if err:
   FFryuM(SELF, err, title=title)
  else:
   if VVmEsn and totEpgOK > 0:
    CCgL5j.VVECSd()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFEK4e(str(totNotIptv), VVnviq)
    if totServErr : txt += "Server Errors\t: %s\n" % FFEK4e(str(totServErr) + t1, VVnviq)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFEK4e(str(totInv), VVnviq)
   if not VVmEsn:
    title += "  (stopped)"
   FFDLqC(SELF, txt, title=title)
 @staticmethod
 def VV6ukR(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCDrYI.VV8Rhr(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCDrYI.VVI941(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCDrYI.VVklIB(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCDrYI.VVklIB(item, "lang"        ).upper()
    now_playing   = CCDrYI.VVklIB(item, "now_playing"      )
    start    = CCDrYI.VVklIB(item, "start"        )
    start_timestamp  = CCDrYI.VVklIB(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCDrYI.VVklIB(item, "start_timestamp"     )
    stop_timestamp  = CCDrYI.VVklIB(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCDrYI.VVklIB(item, "stop_timestamp"      )
    tTitle    = CCDrYI.VVklIB(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV7Xb3(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCDrYI.VVIiAL(catID, MAX_4b)
  TSID = CCDrYI.VVIiAL(chNum, MAX_4b)
  ONID = CCDrYI.VVIiAL(chNum, MAX_4b)
  NS  = CCDrYI.VVIiAL(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVIiAL(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVOPP7(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVSqeR(mode):
  if   mode in ("itv"  , CCDrYI.VVMGQg)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCDrYI.VVe9b1)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCDrYI.VVSiDX) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCDrYI.VVX0qk) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCDrYI.VV6riH    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVRkKI(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VV2tYb:
   excl = FFRGqa(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFryuM(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FF30Q2('find %s %s %s' % (path, excl, par))
  if files:
   err = CCLyBs.VVkPRf(files)
   if err : FFryuM(self, err + FFEK4e('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVfZXg))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFryuM(self, err)
  return []
 @staticmethod
 def VV7Ska():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FF80Mz(path)
  return "/"
 @staticmethod
 def VVn1Th(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCDrYI.VV6ukR(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFryuM(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVXsDY, VVEEoV, VVasam, VVhaQs = CCDrYI.VVSqeR("")
   VVr0hN = ("Home Menu" , FFCuPQ, [])
   VVRWOd  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVyaAW  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFfJU2(SELF, None, title="Programs for : " + chName, header=header, VVZAt4=pList, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=24, VVRWOd=VVRWOd, VVr0hN=VVr0hN, VVXsDY=VVXsDY, VVEEoV=VVEEoV, VVasam=VVasam, VVhaQs=VVhaQs)
  else:
   FFryuM(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVD1KR(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VV9N60(self, isPortal, line, selectionObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFP9Be(self, BF(self.VVyMSK, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFSKZx(confItem, line)
   FF6mzu(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVyMSK(self, title, confItem):
  FFSKZx(confItem, "")
  FF6mzu(self, "Removed from IPTV Menu.", title=title)
 def VVYXV0(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVU6T5(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFVCur(self, BF(self.VV83PW, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFryuM(self, "Incorrect server data !")
 @staticmethod
 def VVUfGj(SELF, isPortal, line, selectionObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCDrYI.VV7Ska()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFryuM(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF6mzu(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFryuM(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVeSeG(self, source, mode, curBName, VVxL8T, title, txt, colList):
  isMulti = VVxL8T.VV1dHJ
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVxL8T.VVwKPO()
   totTxt = "%d Service%s" % (tot, FFlPiz(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFEK4e(totTxt, VVfZXg)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCMUYz(self, VVxL8T, addSep=False)
  thTxt = "Adding Services ..."
  VVGIDM, cbFncDict = [], None
  VVGIDM.append(VVVgKz)
  if itemsOK:
   VVGIDM.append(("Add %s to New Bouquet : %s"    % (totTxt, FFEK4e(curBName , VVijSd)), "addToCur1"))
   if curBName2: VVGIDM.append(("Add %s to New Bouquet : %s" % (totTxt, FFEK4e(curBName2, VVN1ah)) , "addToCur2"))
   VVGIDM.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFVCur, mSel.VVxL8T, BF(self.VV2WJL,source, mode, curBName , VVxL8T, title), title=thTxt)
      , "addToCur2": BF(FFVCur, mSel.VVxL8T, BF(self.VV2WJL,source, mode, curBName2, VVxL8T, title), title=thTxt)
      , "addToNew" : BF(self.VVtfcy, source, mode, curBName, VVxL8T, title)
      }
  else:
   VVGIDM.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVtH9B(VVGIDM, cbFncDict, width=1400)
 def VV2WJL(self, source, mode, curBName, VVxL8T, Title):
  chUrlLst = self.VVK8vD(source, mode, VVxL8T)
  CCpURW.VVAuig(self, Title, curBName, "", chUrlLst)
 def VVtfcy(self, source, mode, curBName, VVxL8T, Title):
  picker = CCpURW(self, VVxL8T, Title, BF(self.VVK8vD, source, mode, VVxL8T), defBName=curBName)
 def VVK8vD(self, source, mode, VVxL8T):
  totChange = 0
  isMulti = VVxL8T.VV1dHJ
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVxL8T.VVWcfU()):
   if not isMulti or VVxL8T.VVeezj(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVUcYo(mode, row)
     refCode, chUrl = self.VVe9v0(self.VV5VB0, self.VVZqGU, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VViygN(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VV2Tdl(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVqxKO():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVeGkX():
  return sorted(tuple(CCDrYI.VVqxKO()))
 @staticmethod
 def VV6clU(rt):
  return CCDrYI.VVqxKO().get(str(rt), "")
 @staticmethod
 def VVC4SX(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCDrYI.VV6clU(span.group(1)) if span else ""
 @staticmethod
 def VVGemA(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVuv4i():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVGIDM = []
  for ndx, rt in enumerate(CCDrYI.VVeGkX()):
   VVGIDM.append(FFzUJ4("%s\t... %s" % (CCDrYI.VV6clU(rt), rt), rt, CCDrYI.VVGemA(rt), VVUrbH if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVGIDM.append(VVVgKz)
  return VVGIDM
class CCEatc(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVmAxY(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FF21Xy(self.frm, frmColor)
  FF21Xy(self.bak, bakColor)
  FF21Xy(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVbO8N(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFOn9F(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCs3Aw(CCEatc):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCEatc.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VViLku()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(VV6Kiq,
  {
   "up" : self.VVNU12   ,
   "down" : self.VV4R52  ,
   "left" : self.VVzWM3  ,
   "right" : self.VVAwZj  ,
   "next" : self.VVEwYo ,
   "last" : self.VV1nfR
  }, -1)
 def VVAGqH(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVmAxY(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VVbFXy()
  self["myPiconPtr"].hide()
 def VVDrtQ(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVNU12(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVPLyK()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVyPON()
 def VV4R52(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVrp7Z()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVyPON()
 def VVzWM3(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVPLyK()
  else:
   self.curCol -= 1
   self.VVyPON()
 def VVAwZj(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVrp7Z()
  else:
   self.curCol += 1
   self.VVyPON()
 def VV1nfR(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVyPON(oldPage != self.curPage)
 def VVEwYo(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVyPON(oldPage != self.curPage)
 def VVrp7Z(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVyPON(force)
 def VVPLyK(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVyPON(force)
 def VVyPON(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVuy7Y = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVuy7Y: self.curPage = VVuy7Y
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVnoUa()
  self["myPiconPtr"].hide()
  self.VVbO8N(self.curPage + 1, self.totalPages)
  FFEuIr(BF(self.VVJhup, force or not oldPage == self.curPage, VVuy7Y))
 def VVJhup(self, force, VVuy7Y):
  try:
   if force:
    self.VVM4h4()
   if self.curPage == VVuy7Y:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVnoUa()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VVpiDp(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVyPON(False if oldPage == self.curPage else True)
  else:
   FFqgHP(self, "Not found", 1000)
 def VVLdFx(self):
  self.VVpiDp(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VViLku(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVH7o9(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVYpYW, CC8Pjn, defFG=fg, defBG=bg, onlyBG=True)
 def VVYpYW(self, fg, bg):
  if self.colorCfg and bg:
   FFSKZx(self.colorCfg, bg)
   self.VVbFXy()
 def VVbFXy(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FF21Xy(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VV6aac(self, lbl, txt, color=""):
  CCs3Aw.VVpZSq(lbl, txt, color)
 @staticmethod
 def VVpZSq(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVCWUi(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCqBwG(Screen, CCs3Aw):
 def __init__(self, session, VVxL8T, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFLEcJ(VVvzSJ, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVxL8T  = VVxL8T
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVZAt4    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFCOTe(self, self.Title)
  CCs3Aw.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VV90k3, subPath)
  if not pathExists(self.pPath):
   FFyakl("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVLgni    ,
   "cancel": self.close    ,
   "menu" : self.VVtwUh ,
   "info" : self.VV1119  ,
   "0"  : self.VVLdFx
  })
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FF9NP9(self)
  FFOuQx(self)
  self.VVAGqH()
  self.VVisaq()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVtwUh(self):
  chName, subj, desc, fName, picUrl = self.VVZAt4[self.curIndex]
  VVGIDM = []
  VVGIDM.append(FFzUJ4("Show Selected Picture"        , "VVktZ0"  , fName))
  VVGIDM.append(FFzUJ4("Copy Selected Picture to Export-Directory"   , "VVUqEP" , fName))
  VVGIDM.append(FFzUJ4("Set Selected Picture as a Poster for a Local Media" , "VV9SYx", fName))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Cache details"       , "VVhOjl"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Change Poster/Picon Transparency Color" , "VVH7o9" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Help (Keys)"        , "help"     ))
  FFzctu(self, self.VVf6GE, title=self.Title, VVGIDM=VVGIDM)
 def VVf6GE(self, item=None):
  if item is not None:
   if   item == "VVktZ0"   : self.VVktZ0()
   elif item == "VVUqEP"   : self.VVUqEP()
   elif item == "VV9SYx"  : self.VV9SYx()
   elif item == "VVhOjl"  : FFVCur(self, self.VVhOjl, title="Calculating ...")
   elif item == "VVH7o9": self.VVH7o9()
   elif item == "help"     : FFog0j(self, "_help_servBr", "Server Browser (Keys)")
 def VVLgni(self):
  self.VVxL8T.VVyaYN(self.curIndex)
  self.VVxL8T.VV6BK0()
 def VV1119(self):
  self.VVxL8T.VVyaYN(self.curIndex)
  self.VVxL8T.VVwAG3()
 def VVisaq(self):
  for colList in self.VVxL8T.VVWcfU():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVZAt4.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVZAt4)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVxL8T.VVsf2R()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVyPON(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVewm8)
  except:
   self.timer.callback.append(self.VVewm8)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VV8O9q)
  self.myThread.start()
 def VV8O9q(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVZAt4):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFgHO0(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFyakl("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVZAt4[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVewm8(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVWABP + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVZAt4[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVZAt4[ndx] = (chName, subj, desc, fName, "")
     CCs3Aw.VVCWUi(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVM4h4(self):
  self.VViLku()
  f1, f2 = self.VVDrtQ()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVZAt4[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VV6aac(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VV6OO5 + "iptv.png"
   CCs3Aw.VVCWUi(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVnoUa(self):
  chName, subj, desc, fName, picUrl = self.VVZAt4[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVktZ0(self):
  chName, subj, desc, fName, picUrl = self.VVZAt4[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCceHb.VVLNYv(self, self.pPath + fName)
  else          : FFqgHP(self, "File not found", 1500)
 def VVUqEP(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVZAt4[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFyakl("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FF6mzu(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFryuM(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFryuM(self, "No Poster/PIcon found", title=title)
 def VV9SYx(self):
  self.session.openWithCallback(self.VV1FXs, BF(CCLyBs, patternMode="movies", VV8MX1=CFG.MovieDownloadPath.getValue()))
 def VV1FXs(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVZAt4[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFyakl("cp -f '%s' '%s'" % (srcF, dstF)):
     FF6mzu(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFryuM(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCKJ5i.VValij(dstF)
   else:
    FFryuM(self, "No Poster/PIcon found", title=title)
 def VVhOjl(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VV90k3, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFunaH("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCLyBs.VVM24t(size)
   txt += "%s\n    %s\n\n" % (FFEK4e(path, VVfZXg), size)
  mainPath = "%sPosters" % VV90k3
  totFiles = FFunaH("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFlPiz(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFEK4e("Total space used by Posters/PIcons%s:" % totFTxt, VVWhci), CCLyBs.VVM24t(totSize))
  mountPath = CCLyBs.VVyxXy(mainPath)
  if pathExists(mountPath):
   totSize  = CCLyBs.VV7JZt(mountPath)
   freeSize = CCLyBs.VVJ8wE(mountPath)
   usedSize = CCLyBs.VVM24t(totSize - freeSize)
   totSize  = CCLyBs.VVM24t(totSize)
   freeSize = CCLyBs.VVM24t(freeSize)
   txt += "%s\n" % SEP
   txt += FFEK4e("Media Space:\n", VVUVBT)
   txt += "    Media Path\t: %s\n" % FFEK4e(mountPath, VVZoWi)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFDLqC(self, txt, title="Cache Used Size", height=1000)
class CCKJ5i(Screen, CCs3Aw):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFLEcJ(VVx7nb, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVZAt4    = lst
  FFCOTe(self, self.Title)
  CCs3Aw.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVLgni    ,
   "cancel": self.close    ,
   "menu" : self.VVmOdP ,
   "info" : self.VVT1aL  ,
   "0"  : self.VVLdFx
  })
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FF9NP9(self)
  FFOuQx(self)
  self.VVAGqH()
  self.totalItems = len(self.VVZAt4)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVyPON(True)
 def VVM4h4(self):
  self.VViLku()
  f1, f2 = self.VVDrtQ()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVZAt4[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VV6OO5 + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VV6aac(lbl, os.path.splitext(os.path.basename(path))[0])
   CCs3Aw.VVCWUi(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVnWOE(self):
  path, movie, poster = self.VVZAt4[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVnoUa(self):
  path, poster = self.VVnWOE()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVmOdP(self):
  path, poster = self.VVnWOE()
  VVGIDM = []
  VVGIDM.append(("Go to movie ...", "VVzXtE"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(FFzUJ4("Show Poster"      , "VVktZ0" , poster))
  VVGIDM.append(FFzUJ4("Copy Poster to Export-Directory" , "VVUqEP", poster))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Change Poster/Picon Transparency Color"  , "VVH7o9" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Change Poster (from current movie path) ..." , "VVHF2D1"  ))
  VVGIDM.append(("Change Poster (locate manually) ..."   , "VVHF2D2"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Help (Keys)"         , "help"     ))
  FFzctu(self, self.VVjLZN, title=self.Title, VVGIDM=VVGIDM)
 def VVjLZN(self, item=None):
  if item is not None:
   if   item == "VVzXtE"    : self.VVzXtE()
   elif item == "VVUqEP"    : self.VVUqEP()
   elif item == "VVktZ0"    : self.VVktZ0()
   elif item == "VVH7o9" : self.VVH7o9()
   elif item == "VVHF2D1"  : self.VVHF2D()
   elif item == "VVHF2D2"  : self.VVHF2D(True)
   elif item == "help"      : FFog0j(self, "_help_movBr", "Movies Browser (Keys)")
 def VVzXtE(self):
  VVnhmb = []
  for ndx, item in enumerate(self.VVZAt4):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVnhmb.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVnhmb.sort(key=lambda x: x[0].lower())
  VVRWOd = ("Select" , self.VVMwhs, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFfJU2(self, None, title="Select Movie", width=1800, height=1000, header=header, VVZAt4=VVnhmb, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, lastFindConfigObj=CFG.lastFindMovie)
 def VVMwhs(self, VVxL8T, title, txt, colList):
  self.VVpiDp(int(colList[2].strip()))
  VVxL8T.cancel()
 def VVLgni(self):
  path, poster = self.VVnWOE()
  FFVCur(self, BF(CCLyBs.VVKTM4, self, path), title="Playing Media ...")
 def VVT1aL(self):
  path, poster = self.VVnWOE()
  txt = "%s:\n%s\n\n" % (FFEK4e("Path", VVfZXg), path)
  size = FFl8II(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFEK4e("File Size", VVfZXg), CCLyBs.VVM24t(size))
  if poster:
   txt += "%s:\n%s" % (FFEK4e("Poster", VVfZXg), poster)
  FFDLqC(self, txt, title="Media File Information")
 def VVktZ0(self):
  path, poster = self.VVnWOE()
  if fileExists(poster): CCceHb.VVLNYv(self, poster)
  else     : FFqgHP(self, "No Poster", 1500)
 def VVUqEP(self):
  title = "Copy Poster"
  path, poster = self.VVnWOE()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFyakl("cp -f '%s' '%s'" % (poster, dstF)):
    FF6mzu(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFryuM(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFqgHP(self, "No Poster", 1500)
 def VVHF2D(self, isManual=False):
  path, poster = self.VVnWOE()
  sDir = FF80Mz(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVX4FB, sDir, path), BF(CCLyBs, patternMode="poster", VV8MX1=sDir))
  else:
   VVGIDM = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVGIDM.append((os.path.basename(item), sDir + item))
   if VVGIDM:
    VVGIDM.sort(key=lambda x: x[0].lower())
    VVx6LK = self.VVl9mX
    FFzctu(self, BF(self.VVX4FB, sDir, path), VVGIDM=VVGIDM, title="Posters", VVx6LK=VVx6LK, VVfIfT=sDir)
   else:
    FFqgHP(self, "No jpg/png in current dir", 1500)
 def VVl9mX(self, VVXrLB, txt, ref, ndx):
  CCceHb.VVLNYv(self, VVpjN9=ref)
 def VVX4FB(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFyakl("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVZAt4[self.curIndex] = (self.VVZAt4[self.curIndex][0], self.VVZAt4[self.curIndex][1], os.path.basename(newPath))
    FFVCur(self, self.VVM4h4)
    CCKJ5i.VValij(newPath)
   else:
    FFqgHP(self, "Cannot copy file", 1000)
 @staticmethod
 def VValij(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFyakl("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VV8mMe(SELF):
  eLst = CC8QHN.VVzGQB()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCKJ5i, title, lst)
  else  : FFryuM(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCRS9Z(Screen, CCs3Aw):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFLEcJ(VVmMUl, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVZAt4    = lst
  self.pPath    = CC9p8T.VVH8Sz()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFCOTe(self, self.Title)
  FFbJWj(self["keyRed"] , "OK = Zap (Review)")
  FFbJWj(self["keyGreen"] , "Zap & Exit")
  FFbJWj(self["keyYellow"], "Find Current Service")
  CCs3Aw.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVpWRx, False),
   "cancel" : self.VV3q1m      ,
   "menu"  : self.VVMsWT   ,
   "red"  : self.VV3q1m      ,
   "green"  : BF(self.VVpWRx, True) ,
   "yellow" : BF(self.VVBgIP, True)  ,
   "0"   : self.VVLdFx
  })
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FF9NP9(self)
   FFOuQx(self)
   FF21Xy(self["keyRed"], "#0a333333")
   self.VVAGqH()
  else:
   pName, srvLst = CCRS9Z.VVX5dV()
   if srvLst and not srvLst == self.VVZAt4:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVZAt4 = srvLst
   else:
    force = False
  self.totalItems = len(self.VVZAt4)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVyPON(force)
  self.VVBgIP()
 def VVMsWT(self):
  VVGIDM = []
  VVGIDM.append(("Find Name (sorted list)" , "findSrt"  ))
  VVGIDM.append(("Find Name (as listed)" , "findNoSrt"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Change Background Color" , "VVH7o9"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Help (Keys)", "help"))
  FFzctu(self, self.VVtqHQ, title="Options", VVGIDM=VVGIDM)
 def VVtqHQ(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVR1aC(True)
   elif item == "findNoSrt"   : self.VVR1aC(False)
   elif item == "VVH7o9": self.VVH7o9()
   elif item == "help"     : FFog0j(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVR1aC(self, isSort):
  VVGIDM = []
  for ndx, item in enumerate(self.VVZAt4):
   VVGIDM.append((item[1], ndx))
  if isSort:
   VVGIDM.sort(key=lambda x: x[0].lower())
  FFzctu(self, self.VVa3Tr, title="Find Name", VVGIDM=VVGIDM, width=1300)
 def VVa3Tr(self, ndx=None):
  if ndx is not None:
   self.VVpiDp(ndx)
 def VV3q1m(self):
  if self.shown: self.close()
  else   : self.show()
 def VVpWRx(self, isExit):
  FFVCur(self, BF(self.VVLsSo, isExit), title="Starting ...")
 def VVLsSo(self, isExit):
  try:
   if self.shown:
    FFnh1l(self, self.VVZAt4[self.curIndex][0], VV5sxe=False)
    if isExit: self.close()
    else  : CCTKa3.VV3qn6(self.session)
   else:
    self.show()
  except:
   pass
 def VVBgIP(self, VVO6nE=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVZAt4):
    if curRef == item[0]:
     self.VVpiDp(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVO6nE and err:
   FFqgHP(self, err, 500)
  return -1
 def VVM4h4(self):
  self.VViLku()
  f1, f2 = self.VVDrtQ()
  row = col = 0
  noPos = VV6OO5 + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVZAt4[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VV6aac(lbl, name)
   path = CC9p8T.VV3wNa(self.pPath, ref, name) or noPos
   CCs3Aw.VVCWUi(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVnoUa(self):
  ref, name = self.VVZAt4[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVTQAz():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVIeIC = InfoBar.instance
  if VVIeIC:
   csel = VVIeIC.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FF7smR(rootRef)
    refName  = FF7smR(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVX5dV(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCRS9Z.VVTQAz()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFsac0(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCpURW.VV4QEE()
   pName  = CCpURW.VVTAtr() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVqFjC(SELF):
  pName, srvLst = CCRS9Z.VVX5dV()
  if srvLst: SELF.session.open(CCRS9Z, pName, srvLst)
  else  : FFryuM(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCu5fi(Screen, CCs3Aw):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFLEcJ(VVxEJp, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVZAt4    = CCu5fi.VVg53e(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FFCOTe(self, self.Title)
  FFbJWj(self["keyRed"] , "OK = Start Plugin")
  FFbJWj(self["keyYellow"], "Package Info.")
  FFbJWj(self["keyBlue"] , "Plugins Group")
  CCs3Aw.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVy5rv   ,
   "cancel" : self.VV3q1m    ,
   "menu"  : self.VVOa5t ,
   "info"  : self.VVZywF  ,
   "red"  : self.VV3q1m    ,
   "yellow" : BF(FFVCur, self, self.VVUDYb),
   "blue"  : self.VVPCzW  ,
   "0"   : self.VVLdFx
  })
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FF9NP9(self)
  FFOuQx(self)
  FF21Xy(self["keyRed"], "#0a333333")
  self.VVAGqH()
  self.totalItems = len(self.VVZAt4)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVyPON(True)
 def VV3q1m(self):
  self.close()
 def VVy5rv(self):
  name, desc = self.VVGzD0(self.curIndex)
  if name == PLUGIN_NAME:
   FFqgHP(self, "Already running.", 500)
  else:
   try:
    p = self.VVZAt4[self.curIndex]
    p(session=self.session)
   except:
    FFryuM(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVZywF(self):
  def VVR7gd(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVZAt4[self.curIndex]
  txt = ""
  try:
   txt += VVR7gd("Path"  , p.path  )
   txt += VVR7gd("Description" , p.description )
   txt += VVR7gd("Icon"  , p.iconstr  )
   txt += VVR7gd("Wakeup Fnc" , p.wakeupfnc )
   txt += VVR7gd("NeedsRestart", p.needsRestart)
   txt += VVR7gd("Internal" , p.internal )
   txt += VVR7gd("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVGzD0(self.curIndex)
  if txt : FFDLqC(self, txt, title=name)
  else : FFryuM(self, "Could not read plugin info.", title=name)
 def VVUDYb(self):
  p = self.VVZAt4[self.curIndex]
  name, desc = self.VVGzD0(self.curIndex)
  path = p.path
  pkg, err = CCiRwv.VVgXQW(path)
  if pkg : CCiRwv.VVlNoe(self, pkg, name)
  else : FFe82w(self, err, 1000)
 def VVOa5t(self):
  path = self.VVZAt4[self.curIndex].path
  VVGIDM = []
  txt = "Open Plugin Path in File Manager"
  VVGIDM.append(FFzUJ4("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Use Original Icon Size", "setOrigSize"))
  FFzctu(self, self.VVfjny, title="Plugins Group", VVGIDM=VVGIDM)
 def VVfjny(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCLyBs, mode=CCLyBs.VVEYzK, VV8MX1=self.VVZAt4[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVyPON(True)
 def VVPCzW(self):
  FFzctu(self, self.VVRKCw, title="Plugins Group", VVGIDM=CCu5fi.VVHTs2(True, True), width=700, VVglmG=True)
 def VVRKCw(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCu5fi.VVpSP2(where)
   if lst:
    self.VVZAt4 = CCu5fi.VVg53e(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVZAt4)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVyPON(True)
   else:
    FFryuM(self, "Not found !", title=self.Title)
 def VVM4h4(self):
  self.VViLku()
  f1, f2 = self.VVDrtQ()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVGzD0(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VV6aac(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVZAt4[ndx].icon:
    try:
     pngSz = self.VVZAt4[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVZAt4[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVZAt4[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VV6OO5 + "plugin.png")
    for path in icons:
     pixMap = CCs3Aw.VVCWUi(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVGzD0(self, ndx):
  name = str(self.VVZAt4[ndx].name).strip()
  desc = str(self.VVZAt4[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFlW1I(self.VVZAt4[ndx].path)
  return name, desc
 def VVnoUa(self):
  name, desc = self.VVGzD0(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVHTs2(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCu5fi.VVpSP2(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVhSN2, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVVgKz)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVpSP2(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVg53e(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFlW1I(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVy0SQ(SELF):
  title = "Plugins Browser"
  lst = CCu5fi.VVpSP2(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CCu5fi, title, lst)
  else : FFryuM(SELF, "No plugins found !", title=title)
class CCswir(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVOpt4  = 0
  self.VVupbD = 1
  self.VVtT0S  = 2
  VVGIDM = []
  VVGIDM.append(("Find in All Service (from filter)" , "VVBYgS" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Find in All (Manual Entry)"   , "VV6yk3"    ))
  VVGIDM.append(("Find in TV"       , "VVvQzY"    ))
  VVGIDM.append(("Find in Radio"      , "VVa9ca"   ))
  if self.VVkyw4():
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Hide Channel: %s" % self.servName , "VVDoVJ"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Zap History"       , "VVU0DZ"    ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("IPTV Tools"       , "iptv"      ))
  VVGIDM.append(("PIcons Tools"       , "PIconsTools"     ))
  VVGIDM.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVGIDM.append(("EPG Tools"       , "epgTools"     ))
  FFCOTe(self, VVGIDM=VVGIDM, title=title)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self)
  if self.isFindMode:
   self.VVDaA0(self.VV38U1())
 def VVLgni(self):
  global VVw0M8
  VVw0M8 = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VV6yk3"    : self.VV6yk3()
   elif item == "VVBYgS" : self.VVBYgS()
   elif item == "VVvQzY"    : self.VVvQzY()
   elif item == "VVa9ca"   : self.VVa9ca()
   elif item == "VVDoVJ"   : self.VVDoVJ()
   elif item == "VVU0DZ"    : self.VVU0DZ()
   elif item == "iptv"       : self.session.open(CCDrYI)
   elif item == "PIconsTools"     : self.session.open(CC9p8T)
   elif item == "ChannelsTools"    : self.session.open(CCTc7M)
   elif item == "epgTools"      : self.session.open(CCgL5j)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVvQzY(self) : self.VVDaA0(self.VVOpt4)
 def VVa9ca(self) : self.VVDaA0(self.VVupbD)
 def VV6yk3(self) : self.VVDaA0(self.VVtT0S)
 def VVDaA0(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FF9Fmo(self, BF(self.VVSAP4, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VVBYgS(self):
  filterObj = CCgoW8(self)
  filterObj.VV1oDN(self.VVoT6f)
 def VVoT6f(self, item):
  self.VVSAP4(self.VVtT0S, item)
 def VVkyw4(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFkZVp(self.refCode)        : return False
  return True
 def VVSAP4(self, mode, VVSKx2):
  FFVCur(self, BF(self.VVUyWx, mode, VVSKx2), title="Searching ...")
 def VVUyWx(self, mode, VVSKx2):
  if VVSKx2:
   VVSKx2 = VVSKx2.strip()
  if VVSKx2:
   self.findTxt = VVSKx2
   CFG.lastFindContextFind.setValue(VVSKx2)
   if   mode == self.VVOpt4  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVupbD : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVSKx2)
   if len(title) > 55:
    title = title[:55] + ".."
   VVnhmb = self.VVsB40(VVSKx2, servTypes)
   if self.isFindMode or mode == self.VVtT0S:
    VVnhmb += self.VV2O7X(VVSKx2)
   if VVnhmb:
    VVnhmb.sort(key=lambda x: x[0].lower())
    VVU1op = self.VVxlxn
    VVRWOd  = ("Zap"   , self.VVRVdM    , [])
    VVoXaA = ("Current Service", self.VVJT2r , [])
    VVMCbu = ("Options"  , self.VVesa6 , [])
    VVMOfU = (""    , self.VVWD0J , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVyaAW  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVU1op=VVU1op, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVMOfU=VVMOfU, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVDaA0(self.VV38U1())
    FF6mzu(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVsB40(self, VVSKx2, servTypes):
  VVZAt4 = CCTc7M.VVuOkS(servTypes)
  VVnhmb = []
  if VVZAt4:
   VVPs5l, VVo54S = FFrYrU()
   tp = CCSMOW()
   words, asPrefix = CCgoW8.VV15EP(VVSKx2)
   colorYellow  = CCvWVD.VVhK0P(VVWhci)
   colorWhite  = CCvWVD.VVhK0P(VVoR97)
   for s in VVZAt4:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFFcgz(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVPs5l:
        STYPE = VVo54S[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVIGT8(refCode)
       if not "-S" in syst:
        sat = syst
       VVnhmb.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVnhmb
 def VV2O7X(self, VVSKx2):
  VVSKx2 = VVSKx2.lower()
  VVnhmb = []
  colorYellow  = CCvWVD.VVhK0P(VVWhci)
  colorWhite  = CCvWVD.VVhK0P(VVoR97)
  for b in CCpURW.VVV8Dp():
   VVgs9R  = b[0]
   VVtQFp  = b[1].toString()
   VVmXQH = eServiceReference(VVtQFp)
   VVdbaC = FFsac0(VVmXQH)
   for service in VVdbaC:
    refCode  = service[0]
    if FFkZVp(refCode):
     servName = service[1]
     if VVSKx2 in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVSKx2), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVnhmb.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVnhmb
 def VV38U1(self):
  mode = CCT3R4.VVDdyC(default=-1)
  return self.VVtT0S if mode == -1 else mode
 def VVxlxn(self, VVxL8T):
  self.close()
  VVxL8T.cancel()
 def VVRVdM(self, VVxL8T, title, txt, colList):
  FFnh1l(VVxL8T, colList[2], VV5sxe=False, checkParentalControl=True)
 def VVJT2r(self, VVxL8T, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(VVxL8T)
  if refCode:
   VVxL8T.VVvq3F(2, FF1rzp(refCode, iptvRef, chName), True)
 def VVesa6(self, VVxL8T, title, txt, colList):
  servName = colList[0]
  mSel = CCMUYz(self, VVxL8T)
  VVGIDM, cbFncDict = CCTc7M.VVf2Oa(self, VVxL8T, servName, 2)
  mSel.VVtH9B(VVGIDM, cbFncDict)
 def VVWD0J(self, VVxL8T, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFNmLy(self, fncMode=CCVNso.VVWbH6, refCode=refCode, chName=chName, text=txt)
 def VVDoVJ(self):
  FFP9Be(self, self.VV6VC0, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VV6VC0(self):
  ret = FFkDjt(self.refCode, True)
  if ret:
   self.VVfB0e()
   self.close()
  else:
   FFqgHP(self, "Cannot change state" , 1000)
 def VVfB0e(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVSts8()
  except:
   self.VVQXXG()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFYdkV(self, serviceRef)
 def VVSts8(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVIeIC = InfoBar.instance
   if VVIeIC:
    VVTb5M = VVIeIC.servicelist
    if VVTb5M:
     hList = VVTb5M.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVTb5M.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVTb5M.history  = newList
       VVTb5M.history_pos = pos
 def VVQXXG(self):
  VVIeIC = InfoBar.instance
  if VVIeIC:
   VVTb5M = VVIeIC.servicelist
   if VVTb5M:
    VVTb5M.history  = []
    VVTb5M.history_pos = 0
 def VVU0DZ(self):
  VVIeIC = InfoBar.instance
  VVnhmb = []
  if VVIeIC:
   VVTb5M = VVIeIC.servicelist
   if VVTb5M:
    VVPs5l, VVo54S = FFrYrU()
    for serv in VVTb5M.history:
     refCode = serv[-1].toString()
     chName = FF7smR(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFkZVp(refCode)
     isSRel = FFUkkg(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFFcgz(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVPs5l:
       STYPE = VVo54S[sTypeInt]
     VVnhmb.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVnhmb:
   VVRWOd  = ("Zap"   , self.VVzcMP   , [])
   VVMCbu = ("Clear History" , self.VV4W4G   , [])
   VVMOfU = (""    , self.VVZSEx , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVyaAW  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=28, VVRWOd=VVRWOd, VVMCbu=VVMCbu, VVMOfU=VVMOfU)
  else:
   FF6mzu(self, "History is empty.", title=title)
 def VVzcMP(self, VVxL8T, title, txt, colList):
  FFnh1l(VVxL8T, colList[3], VV5sxe=False, checkParentalControl=True)
 def VV4W4G(self, VVxL8T, title, txt, colList):
  FFP9Be(self, BF(self.VVswho, VVxL8T), "Clear Zap History ?")
 def VVswho(self, VVxL8T):
  self.VVQXXG()
  VVxL8T.cancel()
 def VVZSEx(self, VVxL8T, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFNmLy(self, fncMode=CCVNso.VV0PAt, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVT9R8():
  try:
   global VV9iBJ
   if VV9iBJ is None:
    VV9iBJ    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCswir.VVMBWs
   ChannelContextMenu.VVphTl = CCswir.VVphTl
  except:
   pass
 @staticmethod
 def VVMBWs(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VV9iBJ(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   for ndx, title in enumerate(("Channels Browser", "Find", "Bouquet Editor", "Channels Tools")):
    title = "%s - %s" % (PLUGIN_NAME, title)
    SELF["menu"].list.insert(ndx, ChoiceEntryComponent(key=" ", text=(title , BF(SELF.VVphTl, csel, ndx, title))))
 @staticmethod
 def VVphTl(SELF, csel, mode, title):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FF7smR(refCode)
  except:
   refCode = refName = ""
  if   mode == 0: CCRS9Z.VVqFjC(SELF)
  elif mode == 2: SELF.session.open(CCT3R4)
  else    : SELF.session.open(CCswir, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False)
  SELF.close()
class CCT3R4(Screen):
 def __init__(self, session, refCode="", servName=""):
  self.skin, self.skinParam = FFLEcJ(VV3ZOe, 10, 10, 30, 0, 0, "#ff000000", "#ff000000", 30)
  self.session = session
  self.Title  = "Bouquet Editor"
  self.pPath  = CC9p8T.VVH8Sz()
  self.bTables = []
  FFCOTe(self)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self.VV2SnU()
 def VV5t43(self, tbl, bName, bRef):
  self.bTables.append(tbl)
  tbl.bouqName = bName
  tbl.bouqRef  = bRef
 def VV2SnU(self):
  rootStr = CCT3R4.VVxxMi()
  rows = self.VVGrZv(rootStr)
  if rows :
   self.VVuShu(self, "Main Bouquets List", rootStr, rows)
   refCode, refName, rootRef, rootName, inBouquet = CCRS9Z.VVTQAz()
   if not self.bTables[-1].VVWFhX({3:refCode}):
    self.bTables[-1].VVWFhX({3:rootRef})
  else:
   FFryuM(self, "No bouquets Found !", title=self.Title)
   self.close()
 def VVHK1W(self):
  self.bTables[-1].cancel()
  if len(self.bTables) > 0: del self.bTables[-1]
  if not len(self.bTables): self.close()
 def VVGrZv(self, bRef=None):
  blkLst = CCT3R4.VVVuyt()
  rows = []
  for ndx, row in enumerate(FFsac0(eServiceReference(bRef), mode=1), start=1):
   ref, name, flags = row
   fTxt, fColor = CCT3R4.VVp2le(flags)
   lck = "1" if CCT3R4.VVGYKJ(ref, blkLst) > -1 else ""
   rows.append((str(ndx), "", fColor + name, ref, fTxt, str(flags), lck))
  return rows
 def VVuShu(self, selfObj, bName, bRef, rows):
  totTbl = len(self.bTables)
  title = {0:"Main Bouquets List", 1:"%s %s" % (FFEK4e("Fav: ", VVhSN2), bName), 2:"%s %s" % (FFEK4e("Sub: ", VVhSN2), bName)}.get(totTbl, bName)
  bg  = {0:"#11002233", 1:"#0a112222"}.get(totTbl, "#0a131111")
  VVU1op = self.VVcfOY
  VVMOfU = (""    , self.VVVMO1  , [])
  VVRWOd  = ("Enter Bouquet" , self.VVes0Q , [])
  VVr0hN = ("Delete"   , self.VVC0XX , [])
  VVMCbu = ("Options"  , self.VV9eFh , [])
  VVUm5B = ("Move Here"  , self.VVeeYf , [])
  picParams  = (1, self.VVqvQl, None)
  widths  = (12   , 7   , 81 , 0  , 0   , 0   , 0   )
  VVyaAW = (CENTER  , CENTER , LEFT , LEFT , LEFT  , CENTER , CENTER )
  tbl = FFfJU2(self, None, title=title, VVZAt4=rows, VVyaAW=VVyaAW, width=1500, height=1000, VVbiLs=widths, VVNdFV=28, addSort=False, VVMOfU=VVMOfU, VVRWOd=VVRWOd, VVU1op=VVU1op, VVr0hN=VVr0hN, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VVehvv=True, searchCol=1, picParams=picParams, lastFindConfigObj=CFG.lastFindServices
     , VVXsDY=bg, VVEEoV=bg, VVasam=bg, VVhaQs="#0a442200", borderWidth=0, VVilD4="#11330000")
  tbl.VVa866(BF(self.VV8Kaq, tbl), True)
  self.VV5t43(tbl, bName, bRef)
 def VVMfOq(self, VVxL8T, mutableList, tot, jumpDict=None):
  if tot:
   if mutableList:
    mutableList.flushChanges()
   FFWH63()
   rows = self.VVGrZv(VVxL8T.bouqRef)
   if rows:
    VVxL8T.VVAi8G(False)
    VVxL8T.VVlCGq(rows, VVj0IZMsg=True, isSort=False, tableRefreshCB=BF(self.VVbf17, jumpDict))
   else:
    self.VVHK1W()
    totTbl = len(self.bTables)
    FFqgHP(self.bTables[-1] if totTbl > 0 else self, "Empty List !", 1500)
  else:
   FFe82w(VVxL8T, "No change !", 1500)
 def VVbf17(self, jumpDict, VVxL8T, title, txt, colList):
  if jumpDict:
   VVxL8T.VVWFhX(jumpDict)
 def VV8Kaq(self, VVxL8T):
  VVxL8T["keyRed"].hide()
  VVxL8T["keyBlue"].hide()
  if VVxL8T.VV1dHJ:
   if VVxL8T.VVwKPO() > 0:
    VVxL8T["keyRed"].show()
    VVxL8T["keyBlue"].show()
  else:
   VVxL8T["keyRed"].show()
 def VVVMO1(self, VVxL8T, title, txt, colList):
  c1, c2, c3 = VVWhci, VVN1ah, VVnviq
  ttl = lambda x, y, color=c1: "%s:\n%s\n\n" % (FFEK4e(x, color), y) if y else ""
  num, picon, name, ref, rem, flags, lck = colList
  path = CCT3R4.VVxZnI(ref, mode=1)
  txt  = ttl("Name"    , name)
  txt += ttl("Bouquet File"  , path if path.startswith("/") else "")
  txt += ttl("Parent Bouquet"  , VVxL8T.bouqName, c2)
  txt += ttl("Parent Bouquet File", CCT3R4.VVxZnI(VVxL8T.bouqRef, mode=1), c2)
  txt += ttl("Ref."    , ref, c3) if VVUwTh else ""
  txt += ttl("Remarks"   , rem, c3) if VVUwTh else ""
  path = CC9p8T.VV3wNa(self.pPath, ref, name)
  FFNmLy(self, fncMode=CCVNso.EPG_MODE_BOUQUET_EDITOR, text=txt, picPath=path)
 def VVes0Q(self, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVqbjV, VVxL8T, colList) )
 def VVqbjV(self, VVxL8T, colList):
  maxLev = 2
  num, picon, name, ref, rem, flags, lck = colList
  if "FROM BOUQUET " in ref:
   if len(self.bTables) <= maxLev:
    rows = self.VVGrZv(ref)
    if rows : self.VVuShu(VVxL8T, name, ref, rows)
    else : FFe82w(VVxL8T, "Empty list !", 1500)
   else:
    FFryuM(self, "Maximum Level of Recursive Bouquets (%d) !" % maxLev, title=self.Title)
  elif CCT3R4.VVNDkF(ref) == 0:
   FFnh1l(self, ref, VV5sxe=False)
   FF4jzU(self, "Cancel to go back to table")
  else:
   FFqgHP(VVxL8T, "No action", 300)
 def VVcfOY(self, VVxL8T):
  if VVxL8T.VV1dHJ:
   VVxL8T.VVAi8G(False)
   self.VV8Kaq(VVxL8T)
  else:
   self.VVHK1W()
 def VV9eFh(self, VVxL8T, title, txt, colList):
  VVGIDM = []
  iMulSel = VVxL8T.VVTpqf()
  sortItem = ("Sort", )
  if iMulSel:
   tot = VVxL8T.VVwKPO()
   if tot > 1: sortItem = ("Sort", "sort")
   isSel = tot > 0
   bTxt = "Bouquet%s" % FFlPiz(tot)
  else:
   isSel = True
   bTxt = "Bouquet"
  inMain = len(self.bTables) == 1
  VVGIDM.append(FFzUJ4("Rename"   , "renm" , not iMulSel))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(FFzUJ4("Add Marker"  , "mrkr" , not iMulSel))
  VVGIDM.append(FFzUJ4("Add Empty Bouquet", "addBouq" , not iMulSel and inMain))
  if inMain:
   VVGIDM.append(VVVgKz)
   VVGIDM.append(FFzUJ4("Hide %s" % bTxt , "hidOn" , isSel))
   VVGIDM.append(FFzUJ4("Unhide %s" % bTxt , "hidOff" , isSel))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(FFzUJ4("Protect %s" % bTxt , "lckOn" , isSel))
   VVGIDM.append(FFzUJ4("Unprotect %s" % bTxt , "lckOff" , isSel))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(sortItem)
  VVGIDM.append(FFzUJ4("Copy to Bouquet" , "toBouq" , isSel))
  cbFncDict = { "renm" : BF(self.VVNo6L  , VVxL8T)
     , "mrkr" : BF(self.VV1ozt , VVxL8T)
     , "addBouq" : BF(self.VVWRHb, VVxL8T)
     , "hidOn" : BF(self.VVpOw0  , VVxL8T, True)
     , "hidOff" : BF(self.VVpOw0  , VVxL8T, False)
     , "lckOn" : BF(self.VVb8WX  , VVxL8T, True)
     , "lckOff" : BF(self.VVb8WX  , VVxL8T, False)
     , "sort" : BF(self.VVEmPj  , VVxL8T)
     , "toBouq" : BF(self.VVPW8K , VVxL8T) }
  fnc = BF(self.VV8Kaq, VVxL8T)
  mSel = CCMUYz(self, VVxL8T)
  mSel.VVtH9B(VVGIDM, cbFncDict, okFnc=fnc, onMultiSelFnc=fnc)
 def VVC0XX(self, VVxL8T, title, txt, colList):
  txt, totSel = "", 0
  if VVxL8T.VVTpqf():
   totSel = VVxL8T.VVwKPO()
   if totSel:
    txt = "Delete %s item%s" % (FFEK4e(str(totSel), VVWhci), FFlPiz(totSel))
  else:
   num, picon, name, ref, rem, flags, lck = colList
   txt = "Delete : %s" % FFEK4e(name, VVWhci)
  if txt:
   FFP9Be(self, BF(self.VVaDO3, VVxL8T), "%s\n\nContinue ?" % txt, title=self.Title)
 def VVaDO3(self, VVxL8T):
  FFVCur(VVxL8T, BF(self.VV71R0, VVxL8T))
 def VV71R0(self, VVxL8T):
  lst, mutableList, csel, bServ = self.VV6TcP(VVxL8T)
  if mutableList is not None:
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.removeService(serv):
     tot += 1
   self.VVMfOq(VVxL8T, mutableList, tot)
 def VVeeYf(self, VVxL8T, title, txt, colList):
  FFVCur(VVxL8T, BF(self.VVPTjK, VVxL8T))
 def VVPTjK(self, VVxL8T):
  lst, mutableList, csel, bServ = self.VV6TcP(VVxL8T)
  if mutableList is not None:
   curNdx = VVxL8T.VVsf2R()
   if curNdx <= VVxL8T.VVesQT(): lst = reversed(lst)
   else             : curNdx -= 1
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVMfOq(VVxL8T, mutableList, tot)
 def VVEmPj(self, VVxL8T):
  FFVCur(VVxL8T, BF(self.VVC2nK, VVxL8T))
 def VVC2nK(self, VVxL8T):
  lst, mutableList, csel, bServ = self.VV6TcP(VVxL8T)
  if mutableList is not None:
   nmlst = VVxL8T.VVgXLx(2)
   lst = list(zip(nmlst, lst))
   lst.sort(key=lambda x: x[0].lower())
   curNdx = VVxL8T.VVesQT()
   tot = 0
   for name, ref in reversed(lst):
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VVMfOq(VVxL8T, mutableList, tot)
 def VVNo6L(self, VVxL8T, item=None):
  name = VVxL8T.VVoYvr()[2]
  FF9Fmo(self, BF(self.VVPM1a, VVxL8T), defaultText=name, title="Rename", message="Enter new name")
 def VVPM1a(self, VVxL8T, name):
  lst, mutableList, csel, bServ = self.VV6TcP(VVxL8T)
  if name and csel and mutableList:
   name = name.strip()
   if name:
    ref = VVxL8T.VVoYvr()[3]
    if "FROM BOUQUET " in ref:
     CCpURW.VV1gGz(ref, name)
    else:
     serv = eServiceReference(ref)
     if serv.valid():
      serv.setName(name)
      mutableList.removeService(serv)
      mutableList.addService(serv)
      mutableList.moveService(serv, VVxL8T.VVsf2R())
    self.VVMfOq(VVxL8T, mutableList, 1)
 def VV1ozt(self, VVxL8T):
  name = "%s Marker %s" % ("=" * 7, "=" * 7)
  FFVCur(VVxL8T, BF(self.VVBZrU, VVxL8T, name))
 def VVBZrU(self, VVxL8T, name):
  lst, mutableList, csel, bServ = self.VV6TcP(VVxL8T)
  if mutableList is not None:
   curServ = eServiceReference(VVxL8T.VVoYvr()[3])
   cnt = tot = 0
   while mutableList:
    serv = eServiceReference("1:64:%d:0:0:0:0:0:0:0::%s" % (cnt, name))
    if curServ and curServ.valid():
     if not mutableList.addService(serv, curServ):
      csel.servicelist.addService(serv, True)
      tot += 1
      break
    elif not mutableList.addService(serv):
     csel.servicelist.addService(serv, True)
     tot += 1
     break
    cnt += 1
   self.VVMfOq(VVxL8T, mutableList, tot)
 def VVWRHb(self, VVxL8T):
  names = VVxL8T.VVeNp0(2)
  name = "Bouquet-1"
  num = 0
  while name in names:
   num += 1
   name = "Bouquet-%s" % num
  FF9Fmo(self, BF(self.VVJp3H, VVxL8T), defaultText=name, title="New Bouquet", message="Enter Bouquet name")
 def VVJp3H(self, VVxL8T, name=None):
  if name and name.strip():
   FFVCur(VVxL8T, BF(self.VVvq39, VVxL8T, name.strip()))
 def VVvq39(self, VVxL8T, bName):
  CCpURW.VVdhjw(bName)
  self.VVMfOq(VVxL8T, None, 1, jumpDict={2:bName})
 def VVPW8K(self, VVxL8T):
  bRows = CCpURW.VVwWAm()
  if VVxL8T.VV1dHJ : lst = VVxL8T.VVgXLx(3)
  else        : lst = [VVxL8T.VVoYvr()[3]]
  VVGIDM = []
  for name, ref in bRows:
   if not ref in lst:
    VVGIDM.append((name, ref))
  if VVGIDM : FFzctu(self,  BF(self.VVJxSb, VVxL8T), VVGIDM=VVGIDM, width=1100, height=900, VVXsDY="#22220000", VVEEoV="#22110000", title="Destination Bouquet", VVglmG=True)
  else  : FFqgHP(VVxL8T, "No bouquets left !", 1000)
 def VVJxSb(self, VVxL8T, item=None):
  if item:
   bName, bRef, ndx = item
   FFVCur(VVxL8T, BF(self.VVbvW5, VVxL8T, bName, bRef))
 def VVbvW5(self, VVxL8T, bName, bRef):
  if VVxL8T.VV1dHJ : lst = VVxL8T.VVgXLx(3)
  else        : lst = [VVxL8T.VVoYvr()[3]]
  dstFile = CCpURW.VVRe5b(bRef)
  tot = 0
  for ref in lst:
   ok = CCpURW.VV73S4(ref, dstFile)
   if ok:
    tot += 1
  self.VVMfOq(VVxL8T, None, tot)
  ttl = lambda x, y: "%s:\n%s\n\n" % (FFEK4e(x, VVfZXg), y)
  txt  = ttl("Source Bouquet"  , VVxL8T.bouqName)
  txt += ttl("Destination Bouquet", bName)
  txt += ttl("Copied Services" , tot)
  FFDLqC(VVxL8T, txt, title="Copy Services")
 def VVpOw0(self, VVxL8T, isHide):
  FFVCur(VVxL8T, BF(self.VVUVFK, VVxL8T, isHide))
 def VVUVFK(self, VVxL8T, isHide):
  lst, mutableList, csel, bServ = self.VV6TcP(VVxL8T)
  mode = CCT3R4.VVDdyC()
  path = VVWgjG + "bouquets.%s" % ("tv" if mode==0 else "radio")
  if fileExists(path):
   tot = 0
   lines = list(map(str.strip, FF5p6q(path)))
   for ref in lst:
    if "FROM BOUQUET " in ref:
     ref = "#SERVICE " + ref
     nrm = ref.replace("1:519:", "1:7:")
     hid = ref.replace("1:7:"  , "1:519:")
     if isHide: r1, r2 = nrm, hid
     else  : r1, r2 = hid, nrm
     if r1 in lines:
      ndx = lines.index(r1)
      lines[ndx] = r2
      tot += 1
   if tot:
    with open(path, "w") as f:
     for line in lines:
      f.write("%s\n" % line)
    self.VVMfOq(VVxL8T, None, tot)
 def VVb8WX(self, VVxL8T, isLck):
  FFVCur(VVxL8T, BF(self.VVlxUL, VVxL8T, isLck))
 def VVlxUL(self, VVxL8T, isLck):
  lst, mutableList, csel, bServ = self.VV6TcP(VVxL8T)
  blkLst = CCT3R4.VVVuyt()
  tot = 0
  for ref in lst:
   if "FROM BOUQUET " in ref:
    ndx = CCT3R4.VVGYKJ(ref, blkLst)
    if isLck:
     if ndx == -1:
      ref = ref.replace("1:519:", "1:0:").replace("1:7:", "1:0:")
      blkLst.append(ref)
      tot += 1
    else:
     if ndx > -1:
      blkLst[ndx] = ""
      tot += 1
  if tot:
   with open(VVCGMF, "w") as f:
    for line in blkLst:
     if line.strip():
      f.write("%s\n" % line)
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   self.VVMfOq(VVxL8T, None, tot)
 def VV6TcP(self, VVxL8T, bServ=None):
  if VVxL8T.VV1dHJ : lst = VVxL8T.VVgXLx(3)
  else        : lst = [VVxL8T.VVoYvr()[3]]
  mutableList = csel = None
  VVIeIC = InfoBar.instance
  if VVIeIC:
   csel = VVIeIC.servicelist
   if csel:
    if not bServ:
     bServ = eServiceReference(VVxL8T.bouqRef)
    if bServ.valid():
     mutableList = csel.getMutableList(bServ)
  return lst,  mutableList, csel, bServ
 def VVqvQl(self, colList):
  num, picon, name, ref, rem, flags, lck = colList
  png = lambda x: "%s%s.png" % (VV6OO5, x)
  if   rem == "Marker"   : return png("mrk1")
  elif rem == "Numbered Marker" : return png("mrk2")
  elif rem == "Group"    : return png("grp")
  elif "FROM BOUQUET " in ref:
   if   lck == "1" and rem == "Invisible" : return png("dirLckInvis")
   elif lck == "1"       : return png("dirLck")
   elif rem == "Invisible"     : return png("dirInvis")
   else         : return png("dir1")
  else:
   return CC9p8T.VV3wNa(self.pPath, ref, name)
 @staticmethod
 def VVp2le(flag):
  t = c = ""
  try:
   if   flag & eServiceReference.isInvisible  : t, c = "Invisible"  , "#f#00ff7722#"
   elif flag & eServiceReference.FFQCNWedMarker : t, c = "Numbered Marker" , "#f#00ffffaa#"
   elif flag & eServiceReference.isGroup   : t, c = "Group"   , "#f#00bbffbb#"
   elif flag & eServiceReference.isMarker   : t, c = "Marker"   , "#f#00ffffaa#"
   elif flag & eServiceReference.isDirectory  : t, c = "Directory"  , ""
  except:
   pass
  return t, c
 @staticmethod
 def VVxZnI(ref, mode=0):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   path = serv.getPath()
   if path and not VVUwTh:
    path = iSub(r"[&?]mode=.+end=", r"", path, flags=IGNORECASE)
   if mode == 1:
    span = iSearch(r'FROM\s+BOUQUET\s+"(.+)"\s+ORDER\s+BY\s+bouquet', path, IGNORECASE)
    if span:
     path = VVWgjG + span.group(1)
  return path
 @staticmethod
 def VVNDkF(ref):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   return serv.flags
  return -1
 @staticmethod
 def VVDdyC(default=0):
  VVIeIC = InfoBar.instance
  if VVIeIC:
   csel = VVIeIC.servicelist
   if csel:
    return csel.mode
  return default
 @staticmethod
 def VVxxMi():
  VVIeIC = InfoBar.instance
  if VVIeIC:
   csel = VVIeIC.servicelist
   if csel:
    return csel.bouquet_rootstr
  return ""
 @staticmethod
 def VVVuyt():
  return FF5p6q(VVCGMF) if fileExists(VVCGMF) else []
 @staticmethod
 def VVGYKJ(ref, lst=None):
  if not lst:
   lst = CCT3R4.VVVuyt()
  if "FROM BOUQUET " in ref:
   ref1 = ref.replace("1:7:", "1:0:")
   ref2 = ref.replace("1:519:", "1:0:")
   if   ref1 in lst: return lst.index(ref1)
   elif ref2 in lst: return lst.index(ref2)
  return -1
class CC9p8T(Screen, CCs3Aw, CCfr3d):
 VV0xmy   = 0
 VVRI6Z  = 1
 VVCWcN  = 2
 VVyvsG  = 3
 VVbNOV  = 4
 VVXgbJ  = 5
 VVVCy0  = 6
 VVBZ1G  = 7
 VVeOr5 = 8
 VVr6Da = 9
 VVNflx = 10
 VVfNUH = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFLEcJ(VVwiM3, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CC9p8T.VVH8Sz()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVZAt4    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFCOTe(self, self.Title)
  FFbJWj(self["keyRed"] , "OK = Zap")
  FFbJWj(self["keyGreen"] , "Current Service")
  FFbJWj(self["keyYellow"], "Page Options")
  FFbJWj(self["keyBlue"] , "Filter")
  CCs3Aw.__init__(self, 5, 7, CFG.transpColorPicons)
  CCfr3d.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VV42sR     ,
   "green"  : self.VVRpUo    ,
   "yellow" : self.VVwivW     ,
   "blue"  : self.VVSGOb     ,
   "menu"  : self.VVNYFT     ,
   "info"  : self.VVfapP    ,
   "pageUp" : BF(self.VVIy1U, True) ,
   "chanUp" : BF(self.VVIy1U, True) ,
   "pageDown" : BF(self.VVIy1U, False) ,
   "chanDown" : BF(self.VVIy1U, False) ,
   "0"   : self.VVLdFx  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FF9NP9(self)
  FFOuQx(self)
  FF21Xy(self["keyRed"], "#0a333333")
  self.VVAGqH()
  FFVCur(self, BF(self.VV2GtV, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVNYFT(self):
  if not self.isBusy:
   VVGIDM = []
   VVGIDM.append(("Statistics"           , "VVSqiU"    ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Suggest PIcons for Current Channel"     , "VVgW3z"   ))
   VVGIDM.append(("Set to Current Channel (copy file)"     , "VVqBT9_file"  ))
   VVGIDM.append(("Set to Current Channel (as SymLink)"     , "VVqBT9_link"  ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Export Current File Names List"      , "VVyb7q" ))
   VVGIDM.append(CC9p8T.VVav9G())
   VVGIDM.append(VVVgKz)
   c, cond = VVWEO1, self.filterTitle == "PIcons without Channels"
   VVGIDM.append(FFzUJ4("Move Unused PIcons to a Directory", "VVq68V" , cond, c))
   VVGIDM.append(FFzUJ4("DELETE Unused PIcons"    , "VVlemk" , cond, c))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVKe1h"  ))
   VVGIDM.append(VVVgKz)
   VVGIDM += CC9p8T.VVa1SJ()
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Change Poster/Picon Transparency Color"    , "VVH7o9" ))
   VVGIDM.append(("Keys Help"           , "VVwVgb"    ))
   FFzctu(self, self.VVETXS, width=1100, height=1050, title=self.Title, VVGIDM=VVGIDM)
 def VVETXS(self, item=None):
  if item is not None:
   if   item == "VVSqiU"    : self.VVSqiU()
   elif item == "VVgW3z"   : self.VVgW3z()
   elif item == "VVqBT9_file"  : self.VVqBT9(0)
   elif item == "VVqBT9_link"  : self.VVqBT9(1)
   elif item == "VVyb7q"  : self.VVyb7q()
   elif item == "VVxrMA"  : CC9p8T.VVxrMA(self)
   elif item == "VVq68V"   : self.VVq68V()
   elif item == "VVlemk"  : self.VVlemk()
   elif item == "VVKe1h"  : self.VVKe1h()
   elif item == "VVxnFU"  : CC9p8T.VVxnFU(self)
   elif item == "findPiconBrokenSymLinks" : CC9p8T.VVOBbh(self, True)
   elif item == "FindAllBrokenSymLinks" : CC9p8T.VVOBbh(self, False)
   elif item == "VVH7o9" : self.VVH7o9()
   elif item == "VVwVgb"     : FFog0j(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVwivW(self):
  if not self.isBusy:
   VVGIDM = []
   VVGIDM.append(("Go to First PIcon"  , "VVrp7Z"  ))
   VVGIDM.append(("Go to Last PIcon"   , "VVPLyK"  ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Sort by Channel Name"     , "sortByChan" ))
   VVGIDM.append(("Sort by File Name"  , "sortByFile" ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Find from File List .." , "VVQ7ZS" ))
   FFzctu(self, self.VVTYW1, title=self.Title, VVGIDM=VVGIDM)
 def VVTYW1(self, item=None):
  if item is not None:
   if   item == "VVrp7Z"   : self.VVrp7Z()
   elif item == "VVPLyK"   : self.VVPLyK()
   elif item == "sortByChan"  : self.VVH3Iq(2)
   elif item == "sortByFile"  : self.VVH3Iq(0)
   elif item == "VVQ7ZS"  : self.VVQ7ZS()
 def VVQ7ZS(self):
  VVGIDM = []
  for item in self.VVZAt4:
   VVGIDM.append((item[0], item[0]))
  FFzctu(self, self.VVRuME, title='PIcons ".png" Files', VVGIDM=VVGIDM, VVglmG=True)
 def VVRuME(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVpiDp(ndx)
 def VV42sR(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVQvYk()
   if refCode:
    FFnh1l(self, refCode)
    self.VV287a()
    self.VVnoUa()
 def VVIy1U(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VV287a()
   self.VVnoUa()
  except:
   pass
 def VVRpUo(self):
  if self["keyGreen"].getVisible():
   self.VVpiDp(self.curChanIndex)
 def VVH3Iq(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFVCur(self, BF(self.VV2GtV, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVqBT9(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVQvYk()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVGIDM = []
     VVGIDM.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVGIDM.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFzctu(self, BF(self.VVvzGm, mode, curChF, selPiconF), VVGIDM=VVGIDM, title="Current Channel PIcon (already exists)")
    else:
     self.VVvzGm(mode, curChF, selPiconF, "overwrite")
   else:
    FFryuM(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFryuM(self, "Could not read current channel info. !", title=title)
 def VVvzGm(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFyakl(cmd)
   FFVCur(self, BF(self.VV2GtV, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VVq68V(self):
  defDir = FF80Mz(CC9p8T.VVH8Sz() + "picons_backup")
  FFyakl("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VV4u6h, defDir), BF(CCLyBs
         , mode=CCLyBs.VVSgRQ, VV8MX1=CC9p8T.VVH8Sz()))
 def VV4u6h(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CC9p8T.VVH8Sz():
    FFryuM(self, "Cannot move to same directory !", title=title)
   else:
    if not FF80Mz(path) == FF80Mz(defDir):
     self.VVevz1(defDir)
    FFP9Be(self, BF(FFVCur, self, BF(self.VVYuJm, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVZAt4), path), title=title)
  else:
   self.VVevz1(defDir)
 def VVYuJm(self, title, defDir, toPath):
  if not iMove:
   self.VVevz1(defDir)
   FFryuM(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FF80Mz(toPath)
  pPath = CC9p8T.VVH8Sz()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVZAt4:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVZAt4)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFDLqC(self, txt, title=title, VVasam="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVjLA3("all")
 def VVevz1(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVlemk(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVZAt4)
  FFP9Be(self, BF(FFVCur, self, BF(self.VVMpj4, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFlPiz(tot)), title=title)
 def VVMpj4(self, title):
  pPath = CC9p8T.VVH8Sz()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVZAt4:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVZAt4)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFEK4e(str(totErr), VVnviq)
  FFDLqC(self, txt, title=title)
 def VVKe1h(self):
  lines = FF30Q2("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFP9Be(self, BF(self.VVqUFI, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFlPiz(tot)), VVi1cr=True)
  else:
   FF6mzu(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVqUFI(self, fList):
  FFyakl("find -L '%s' -type l -delete" % self.pPath)
  FF6mzu(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVfapP(self):
  FFVCur(self, self.VVW3Ji)
 def VVW3Ji(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVQvYk()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFEK4e("PIcon Directory:\n", VVN1ah)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFvxWt(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFvxWt(path)
   txt += FFEK4e("PIcon File:\n", VVN1ah)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFEK4e("Found %d SymLink%s to this file from:\n" % (tot, FFlPiz(tot)), VVN1ah)
     for fPath in slLst:
      txt += "  %s\n" % FFEK4e(fPath, VVhSN2)
     txt += "\n"
   if chName:
    txt += FFEK4e("Channel:\n", VVN1ah)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFEK4e(chName, VVijSd)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFEK4e("Remarks:\n", VVN1ah)
    txt += "  %s\n" % FFEK4e("Unused", VVnviq)
  else:
   txt = "No info found"
  FFNmLy(self, fncMode=CCVNso.VVszz1, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVQvYk(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVZAt4[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FF28st(sat)
  return fName, refCode, chName, sat, inDB
 def VV287a(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVZAt4):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVnoUa(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVQvYk()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFEK4e("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVN1ah))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVQvYk()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFUkkg(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFEK4e(self.curChanName, VVWhci)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVQvYk()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVSqiU(self):
  VVPs5l, VVo54S = FFrYrU()
  sTypeNameDict = {}
  for key, val in VVo54S.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVZAt4:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVo54S: sTypeDict[VVo54S[stNum]] = sTypeDict.get(VVo54S[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFunaH("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVnhmb = []
  c = "#b#11003333#"
  VVnhmb.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVnhmb.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVnhmb.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVnhmb.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVnhmb.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVnhmb.append((c + "Satellites"    , str(len(self.nsList))))
  VVnhmb.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVnhmb.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVnhmb.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVnhmb.extend(sTypeRows)
  FFfJU2(self, None, title=self.Title, VVZAt4=VVnhmb, VVNdFV=28, VVhaQs="#00003333", VVAXDQ="#00222222")
 def VVyb7q(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FF80Mz(CFG.exportedTablesPath.getValue()), txt, FFOa0m())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVZAt4:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF6mzu(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVSGOb(self):
  if not self.isBusy:
   VVGIDM = []
   VVGIDM.append(("All"        , "all"  ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Used by Channels"     , "used" ))
   VVGIDM.append(("Unused PIcons"     , "unused" ))
   VVGIDM.append(("IPTV PIcons"      , "iptv" ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("PIcons Files"      , "pFiles" ))
   VVGIDM.append(("SymLinks to PIcons"    , "pLinks" ))
   VVGIDM.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVGIDM.append(("By Files Date ..."    , "pDate" ))
   VVGIDM.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVGIDM.append(FFBeKw("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFhNZa(val)
      VVGIDM.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCgoW8(self)
   filterObj.VVkN7u(VVGIDM, self.nsList, self.VVz6KS)
 def VVz6KS(self, item=None):
  if item is not None:
   self.VVjLA3(item)
 def VVjLA3(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VV0xmy   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVRI6Z   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVCWcN  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VVVCy0   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVyvsG  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVbNOV  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVXgbJ  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVNflx , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVfNUH , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVBZ1G   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVeOr5 , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVXgbJ:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FF30Q2("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFlW1I(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFqgHP(self, "Not found", 1000)
     return
   elif mode == self.VVNflx:
    self.VVDHc7(mode)
    return
   elif mode == self.VVfNUH:
    self.VVYWN4(mode)
    return
   elif mode == self.VVr6Da:
    return
   else:
    words, asPrefix = CCgoW8.VV15EP(words)
   if not words and mode in (self.VVBZ1G, self.VVeOr5):
    FFqgHP(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFVCur(self, BF(self.VV2GtV, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVDHc7(self, mode):
  VVGIDM = []
  VVGIDM.append(("Today"   , "today" ))
  VVGIDM.append(("Since Yesterday" , "yest" ))
  VVGIDM.append(("Since 7 days"  , "week" ))
  FFzctu(self, BF(self.VV5xFd, mode), VVGIDM=VVGIDM, title="Filter by Added/Modified Date")
 def VV5xFd(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFFCZ1(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFFCZ1(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFFCZ1(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFVCur(self, BF(self.VV2GtV, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVYWN4(self, mode):
  VVPs5l, VVo54S = FFrYrU()
  lst = set()
  for key, val in VVo54S.items():
   lst.add(val)
  VVGIDM = []
  for item in lst:
   VVGIDM.append((item, item))
  VVGIDM.sort(key=lambda x: x[0])
  FFzctu(self, BF(self.VVjiF1, mode), VVGIDM=VVGIDM, title="Filter by Service Type")
 def VVjiF1(self, mode, item=None):
  if item:
   VVPs5l, VVo54S = FFrYrU()
   sTypeList = []
   for key, val in VVo54S.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFVCur(self, BF(self.VV2GtV, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVgW3z(self):
  self.session.open(CCChia, barTheme=CCChia.VVzhbG
      , titlePrefix = ""
      , fncToRun  = self.VVy29u
      , VViIM0 = self.VV2q7k)
 def VVy29u(self, VVWRJ1):
  VVTSmb, err = CCTc7M.VVKjmx(self, CCTc7M.VV5ZYX, VVCFmo=False, VVyxvV=False)
  files = []
  words = []
  if not VVWRJ1 or VVWRJ1.isCancelled:
   return
  VVWRJ1.VVfN1b = []
  VVWRJ1.VVsWOI(len(VVTSmb))
  if VVTSmb:
   curCh = self.VVLa8M(self.curChanName)
   for refCode in VVTSmb:
    if not VVWRJ1 or VVWRJ1.isCancelled:
     return
    VVWRJ1.VVYksR(1, True)
    chName, sat, inDB = VVTSmb.get(refCode, ("", "", 0))
    ratio = CC9p8T.VVijCP(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CC9p8T.VVHMPG(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFlW1I(f)
       fil = f.replace(".png", "")
       if not fil in VVWRJ1.VVfN1b:
        VVWRJ1.VVfN1b.append(fil)
 def VV2q7k(self, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  if VVfN1b : FFVCur(self, BF(self.VV2GtV, mode=self.VVr6Da, words=VVfN1b), title="Loading ...")
  else   : FFqgHP(self, "Not found", 2000)
 def VV2GtV(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVmiBX(isFirstTime):
   return
  self.isBusy = True
  VVyxvV = True if isFirstTime else False
  VVTSmb, err = CCTc7M.VVKjmx(self, CCTc7M.VV5ZYX, VVCFmo=False, VVyxvV=VVyxvV)
  if err:
   self.close()
  iptvRefList = self.VVH4Vh()
  tList = []
  for fName, fType in CC9p8T.VVCByH(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVTSmb:
    if fName in VVTSmb:
     chName, sat, inDB = VVTSmb.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VV0xmy:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVRI6Z  and chName         : isAdd = True
   elif mode == self.VVCWcN and not chName        : isAdd = True
   elif mode == self.VVyvsG  and fType == 0        : isAdd = True
   elif mode == self.VVbNOV  and fType == 1        : isAdd = True
   elif mode == self.VVXgbJ  and fName in words       : isAdd = True
   elif mode == self.VVr6Da and fName in words       : isAdd = True
   elif mode == self.VVVCy0  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVBZ1G  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVeOr5:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVNflx:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVfNUH:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVZAt4   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFqgHP(self)
  else:
   self.isBusy = False
   FFqgHP(self, "Not found", 1000)
   return
  self.VVZAt4.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VV287a()
  self.totalItems = len(self.VVZAt4)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVyPON(True)
 def VVmiBX(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CC9p8T.VVCByH(self.pPath):
    if fName:
     return True
   if isFirstTime : FFryuM(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFqgHP(self, "Not found", 1000)
  else:
   FFryuM(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVH4Vh(self):
  VVnhmb = {}
  files  = CCDrYI.VVSss8()
  if files:
   for path in files:
    txt = FF3unD(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVnhmb[refCode] = item[1]
  return VVnhmb
 def VVM4h4(self):
  self.VViLku()
  f1, f2 = self.VVDrtQ()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVZAt4[ndx]
   fName = self.VVZAt4[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCs3Aw.VVCWUi(pic, path) : color = VVijSd if inDB else ""
   elif not chName           : color = ""
   else             : color = VViTDo
   self.VV6aac(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVijCP(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VVav9G():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVxrMA")
 @staticmethod
 def VVa1SJ():
  VVGIDM = []
  VVGIDM.append(("Find SymLinks (to PIcon Directory)"   , "VVxnFU"  ))
  VVGIDM.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVGIDM.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVGIDM
 @staticmethod
 def VVxrMA(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(SELF)
  png, path = CC9p8T.VVlW3d(refCode)
  if path : CC9p8T.VVanRw(SELF, png, path)
  else : FFryuM(SELF, "No PIcon found for current channel in:\n\n%s" % CC9p8T.VVH8Sz())
 @staticmethod
 def VVxnFU(SELF):
  if VVWhci:
   sed1 = FFpC0R("->", VVWhci)
   sed2 = FFpC0R("picon", VVnviq)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VViTDo, VVoR97)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FF0JeX(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFRGqa(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVOBbh(SELF, isPIcon):
  sed1 = FFpC0R("->", VViTDo)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFpC0R("picon", VVnviq)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FF0JeX(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFRGqa(), grep, sed1, sed2))
 @staticmethod
 def VVanRw(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFpC0R("%s%s" % (dest, png), VVijSd))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFpC0R(errTxt, VVWABP))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFhTGc(SELF, cmd)
 @staticmethod
 def VVCByH(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVH8Sz():
  path = CFG.PIconsPath.getValue()
  return FF80Mz(path)
 @staticmethod
 def VVlW3d(refCode, chName=None):
  if FFkZVp(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFqwVq(refCode)
  allPath, fName, refCodeFile, pList = CC9p8T.VVHMPG(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VV3wNa(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCDrYI.VVeGkX():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFLKj3(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VVHMPG(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CC9p8T.VVH8Sz()
   pList = []
   lst = FFqy37(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFLKj3(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFlW1I(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC5ePH():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVY68H  = None
  self.VVy5sI = ""
  self.VV6vYm  = noService
  self.VVXJK2 = 0
  self.VVcgUQ  = noService
  self.VVd3GN = 0
  self.VVnTmd  = "-"
  self.VVftQs = 0
  self.VVjZzh  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VVZZ34(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVY68H = frontEndStatus
     self.VV1pPp()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VV1pPp(self):
  if self.VVY68H:
   val = self.VVY68H.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVy5sI = "%3.02f dB" % (val / 100.0)
   else         : self.VVy5sI = ""
   val = self.VVY68H.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVXJK2 = int(val)
   self.VV6vYm  = "%d%%" % val
   val = self.VVY68H.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVd3GN = int(val)
   self.VVcgUQ  = "%d%%" % val
   val = self.VVY68H.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VVnTmd  = "%d" % val
   val = int(val * 100 / 500)
   self.VVftQs = min(500, val)
   val = self.VVY68H.get("tuner_locked", 0)
   if val == 1 : self.VVjZzh = "Locked"
   else  : self.VVjZzh = "Not locked"
 def VVYYVs(self)   : return self.VVy5sI
 def VVjqqP(self)   : return self.VV6vYm
 def VVTpsJ(self)  : return self.VVXJK2
 def VVK8rY(self)   : return self.VVcgUQ
 def VVIE2H(self)  : return self.VVd3GN
 def VVfqjK(self)   : return self.VVnTmd
 def VVp6Yc(self)  : return self.VVftQs
 def VVx1RQ(self)   : return self.VVjZzh
 def VVnIRE(self) : return self.serviceName
class CCSMOW():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVIKIG(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFKVYD(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV3VjX(self.ORPOS  , mod=1   )
      self.sat2  = self.VV3VjX(self.ORPOS  , mod=2   )
      self.freq  = self.VV3VjX(self.FREQ  , mod=3   )
      self.sr   = self.VV3VjX(self.SR   , mod=4   )
      self.inv  = self.VV3VjX(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV3VjX(self.POL  , self.D_POL )
      self.fec  = self.VV3VjX(self.FEC  , self.D_FEC )
      self.syst  = self.VV3VjX(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV3VjX("modulation" , self.D_MOD )
       self.rolof = self.VV3VjX("rolloff"  , self.D_ROLOF )
       self.pil = self.VV3VjX("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV3VjX("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV3VjX("pls_code"  )
       self.iStId = self.VV3VjX("is_id"   )
       self.t2PlId = self.VV3VjX("t2mi_plp_id" )
       self.t2PId = self.VV3VjX("t2mi_pid"  )
 def VV3VjX(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFhNZa(val)
  elif mod == 2   : return FFGaI7(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VV5fa5(self, refCode):
  txt = ""
  self.VVIKIG(refCode)
  if self.data:
   def VVR7gd(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVR7gd("System"   , self.syst)
    txt += VVR7gd("Satellite"  , self.sat2)
    txt += VVR7gd("Frequency"  , self.freq)
    txt += VVR7gd("Inversion"  , self.inv)
    txt += VVR7gd("Symbol Rate"  , self.sr)
    txt += VVR7gd("Polarization" , self.pol)
    txt += VVR7gd("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVR7gd("Modulation" , self.mod)
     txt += VVR7gd("Roll-Off" , self.rolof)
     txt += VVR7gd("Pilot"  , self.pil)
     txt += VVR7gd("Input Stream", self.iStId)
     txt += VVR7gd("T2MI PLP ID" , self.t2PlId)
     txt += VVR7gd("T2MI PID" , self.t2PId)
     txt += VVR7gd("PLS Mode" , self.plsMod)
     txt += VVR7gd("PLS Code" , self.plsCod)
   else:
    txt += VVR7gd("System"   , self.txMedia)
    txt += VVR7gd("Frequency"  , self.freq)
  return txt, self.namespace
 def VVkCYN(self, refCode):
  txt = "Transpoder : ?"
  self.VVIKIG(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVIGT8(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFKVYD(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV3VjX(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV3VjX(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV3VjX(self.SYST, self.D_SYS_S)
     freq = self.VV3VjX(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV3VjX(self.POL , self.D_POL)
      fec = self.VV3VjX(self.FEC , self.D_FEC)
      sr = self.VV3VjX(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVYbiE(self, refCode):
  self.data = None
  self.VVIKIG(refCode)
  if self.data and self.freq : return True
  else      : return False
class CC8yF1():
 def __init__(self, VVEUyd, path, VViIM0=None, curRowNum=-1):
  self.VVEUyd  = VVEUyd
  self.origFile   = path
  self.Title    = "File Editor: " + FFlW1I(path)
  self.VViIM0  = VViIM0
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  self.editorTable  = None
  if FFyakl("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FFVCur(self.VVEUyd, BF(self.VVo4d8, curRowNum), title="Loading file ...")
  else:
   FFryuM(self.VVEUyd, "Error while preparing edit!")
 def VVo4d8(self, curRowNum):
  VVnhmb = self.VVo3eY()
  VVoXaA = ("Save Changes" , self.VVfhTR   , [])
  VVRWOd  = ("Edit Line"  , self.VV4mf3    , [])
  VVMCbu = ("Options"  , self.VVS0mH  , [])
  VVUm5B = ("Line Options" , self.VV4cxo   , [])
  VV6aZX = (""    , self.VVII0c , [])
  VVU1op = self.VVToSI
  VVHQPO  = self.VVfXMp
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVyaAW  = (CENTER  , LEFT  )
  bg    = "#11001111"
  self.editorTable = FFfJU2(self.VVEUyd, None, title=self.Title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, width=1600, height=1000, VVNdFV=26, isEditor=True, VVoXaA=VVoXaA, VVRWOd=VVRWOd, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VVU1op=VVU1op, VVHQPO=VVHQPO, VV6aZX=VV6aZX, VVehvv=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
        , VVXsDY=bg, VVEEoV=bg, VVasam=bg, VVhaQs="#05333333", VVAXDQ="#00303030", VVilD4="#11331133")
  self.editorTable.VVyaYN(curRowNum)
 def VVfXMp(self, VVxL8T):
  VVxL8T.VVbwhi()
 def VVS0mH(self, VVxL8T, title, txt, colList):
  VVGIDM = []
  VVGIDM.append(("Go to Line Num" , "toLine"))
  VVGIDM.append(("Find & Replace" , "repl"))
  FFzctu(self.VVEUyd, self.VVid2y, VVGIDM=VVGIDM, width=500, title="Options", VVglmG=True)
 def VVid2y(self, item=None):
  if item:
   title, ref, ndx = item
   if   ref == "toLine" : self.VVztVz()
   elif ref == "repl"  : self.VVwhPN(title)
 def VVwhPN(self, title):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  lst = [(" Find", fnd, str(len(fnd))), (" Replace with", rpl, str(len(rpl)))]
  bg = "#11101010"
  VVRWOd  = ("Change" , BF(self.VV4zOz, title, lst) , [])
  VVoXaA = ("Start" , BF(self.VV3ofI, title)  , [])
  header  = (" Subject", " Text" , "Len.")
  widths  = (20   , 70  , 10 )
  VVyaAW = (LEFT   , LEFT  , CENTER)
  FFfJU2(self.VVEUyd, None, title=title, VVZAt4=lst, header=header, VVyaAW=VVyaAW, VVbiLs=widths, width=1200, VVNdFV=30, isEditor=True, VVRWOd=VVRWOd, VVoXaA=VVoXaA, VV4wMI=2
    , VVXsDY=bg, VVEEoV=bg, VVasam=bg, VVhaQs="#06224455", VVAXDQ="#0a303030")
 def VV4zOz(self, Title, lst, VVxL8T, title, txt, colList):
  title = VVxL8T.VVJ5dP(0)
  ndx = VVxL8T.VVsf2R()
  txt = CFG.lastFindRepl_fnd.getValue() if ndx == 0 else CFG.lastFindRepl_rpl.getValue()
  FF9Fmo(self.VVEUyd, BF(self.VVyIu7, VVxL8T, ndx), title=title, defaultText=txt, message="New entry")
 def VVyIu7(self, VVxL8T, ndx, newTxt=None):
  if newTxt:
   if ndx == 0 : FFSKZx(CFG.lastFindRepl_fnd, newTxt)
   else  : FFSKZx(CFG.lastFindRepl_rpl, newTxt)
   VVxL8T.VVxFpI({1:newTxt, 2:len(newTxt)})
 def VV3ofI(self, Title, VVxL8T, title, txt, colList):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  if len(fnd) > 0:
   txt = FF3unD(self.tmpFile)
   tot = txt.count(fnd)
   if tot > 0:
    FFP9Be(self.VVEUyd, BF(FFVCur, VVxL8T, BF(self.VVhxGF, VVxL8T, fnd, rpl), title="Replacing ..."), "Replace %d occurrences ?" % tot, title=Title)
   else:
    FFqgHP(VVxL8T, "Not found in file !", 1000)
    VVxL8T.VVyaYN(0)
  else:
   FFqgHP(VVxL8T, "Nothing to find", 1000)
 def VVhxGF(self, VVxL8T, fnd, rpl):
  txt = FF3unD(self.tmpFile)
  txt = txt.replace(fnd, rpl)
  with open(self.tmpFile, "w") as f:
   f.write(txt)
  VVxL8T.cancel()
  self.fileChanged = True
  self.editorTable.VVvtnk()
  VVnhmb = self.VVo3eY()
  self.editorTable.VVlCGq(VVnhmb)
 def VVztVz(self):
  totRows = self.editorTable.VVERJ7()
  lineNum = self.editorTable.VVsf2R() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FF9Fmo(self.VVEUyd, BF(self.VVXPTr, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVXPTr(self, lineNum, totRows, VVxkNp):
  if VVxkNp:
   VVxkNp = VVxkNp.strip()
   if VVxkNp.isdigit():
    num = FFEApF(int(VVxkNp) - 1, 0, totRows)
    self.editorTable.VVyaYN(num)
    self.lastLineNum = num + 1
   else:
    FFqgHP(self.editorTable, "Incorrect number", 1500)
 def VV4cxo(self, VVxL8T, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVxL8T.VV9lfv()
  VVGIDM = []
  VVGIDM.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVGIDM.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVmmSr"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVQe5Q:
   VVGIDM.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(  ("Delete Line"         , "deleteLine"   ))
  FFzctu(self.VVEUyd, BF(self.VVpLop, lineNum), VVGIDM=VVGIDM, title="Line Options")
 def VVpLop(self, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVVbVS("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile))
   elif item == "VVmmSr"  : self.VVmmSr(lineNum)
   elif item == "copyToClipboard"  : self.VVjSNr(lineNum)
   elif item == "pasteFromClipboard" : self.VVlIsc(lineNum)
   elif item == "deleteLine"   : self.VVVbVS("sed -i '%dd' '%s'" % (lineNum, self.tmpFile))
 def VVII0c(self, VVxL8T, title, txt, colList):
  if   self.insertMode == 1: VVxL8T.VV6yqc()
  elif self.insertMode == 2: VVxL8T.VVxQfy()
  self.insertMode = 0
 def VVmmSr(self, lineNum):
  if lineNum == self.editorTable.VV9lfv():
   self.insertMode = 1
   self.VVVbVS("echo '' >> '%s'" % self.tmpFile)
  else:
   self.insertMode = 2
   self.VVVbVS("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile))
 def VVjSNr(self, lineNum):
  global VVQe5Q
  VVQe5Q = FFunaH("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  self.editorTable.VVurur("Copied to clipboard")
 def VVfhTR(self, VVxL8T, title, txt, colList):
  if self.fileChanged:
   if FFWyyp(self.origFile):
    if FFyakl("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVxL8T.VVurur("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVxL8T.VVbwhi()
    else:
     FFryuM(self.VVEUyd, "Cannot save file!")
   else:
    FFryuM(self.VVEUyd, "Cannot create backup copy of original file!")
 def VVToSI(self, VVxL8T):
  if self.fileChanged:
   FFP9Be(self.VVEUyd, BF(self.VVWZ5o, VVxL8T), "Cancel changes ?")
  else:
   FFyakl("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVWZ5o(VVxL8T)
 def VVWZ5o(self, VVxL8T):
  VVxL8T.cancel()
  FFbUco(self.tmpFile)
  if self.VViIM0:
   self.VViIM0(self.fileSaved)
 def VV4mf3(self, VVxL8T, title, txt, colList):
  lineNum = int(VVxL8T.VVJ5dP(0))
  lineTxt = VVxL8T.VVJ5dP(1, isStrip=False)
  message = VVoR97 + "ORIGINAL TEXT:\n" + VVhSN2 + lineTxt
  FF9Fmo(self.VVEUyd, BF(self.VVdh7h, lineNum), title="File Line", defaultText=lineTxt, message=message)
 def VVdh7h(self, lineNum, VVxkNp):
  if not VVxkNp is None:
   if self.editorTable.VV9lfv() <= 1:
    self.VVVbVS("echo %s > '%s'" % (VVxkNp, self.tmpFile))
   else:
    self.VVqpVd(lineNum, VVxkNp)
 def VVlIsc(self, lineNum):
  if lineNum == self.editorTable.VV9lfv() and self.editorTable.VV9lfv() == 1:
   self.VVVbVS("echo %s >> '%s'" % (VVQe5Q, self.tmpFile))
  else:
   self.VVqpVd(lineNum, VVQe5Q)
 def VVqpVd(self, lineNum, newTxt):
  self.editorTable.VV61sj("Saving ...")
  lines = FF5p6q(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  self.editorTable.VVvtnk()
  VVnhmb = self.VVo3eY()
  self.editorTable.VVlCGq(VVnhmb)
 def VVVbVS(self, cmd):
  tCons = CCcJGn()
  tCons.ePopen(cmd, self.VVxB5V)
  self.fileChanged = True
  self.editorTable.VVvtnk()
 def VVxB5V(self, result, retval):
  VVnhmb = self.VVo3eY()
  self.editorTable.VVlCGq(VVnhmb)
 def VVo3eY(self):
  if fileExists(self.tmpFile):
   lines = FF5p6q(self.tmpFile)
   VVnhmb = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVnhmb.append((str(ndx), line))
   if not VVnhmb:
    VVnhmb.append((str(1), ""))
   return VVnhmb
  else:
   FFAhcl(self.VVEUyd, self.tmpFile)
class CCgoW8():
 def __init__(self, callingSELF, VVXsDY="#22003344", VVEEoV="#22002233"):
  self.callingSELF = callingSELF
  self.VVGIDM  = []
  self.satList  = []
  self.VVXsDY  = VVXsDY
  self.VVEEoV   = VVEEoV
 def VV1oDN(self, VViIM0):
  self.VVGIDM = []
  VVGIDM, VV8S8F = CCgoW8.VVD8QJ(self.callingSELF, False, True)
  if VVGIDM:
   self.VVGIDM += VVGIDM
   self.VVyJxc(VViIM0, VV8S8F)
 def VVzE9v(self, mode, VVxL8T, satCol, VViIM0, inFilterFnc=None):
  VVxL8T.VV61sj("Loading Filters ...")
  self.VVGIDM = []
  self.VVGIDM.append(("All Services" , "all"))
  if mode == 1:
   self.VVGIDM.append(VVVgKz)
   self.VVGIDM.append(("Parental Control", "parentalControl" ))
   self.VVGIDM.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVGIDM.append(VVVgKz)
   self.VVGIDM.append(("Selected Transponder"   , "selectedTP" ))
   self.VVGIDM.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VV52i2(VVxL8T, satCol)
  VVGIDM, VV8S8F = CCgoW8.VVD8QJ(self.callingSELF, True, False)
  if VVGIDM:
   VVGIDM.insert(0, FFBeKw("Custom Words"))
   self.VVGIDM += VVGIDM
  VVxL8T.VVKZ4j()
  self.VVyJxc(VViIM0, VV8S8F, inFilterFnc)
 def VVkN7u(self, VVGIDM, sats, VViIM0, inFilterFnc=None):
  self.VVGIDM = VVGIDM
  VVGIDM, VV8S8F = CCgoW8.VVD8QJ(self.callingSELF, True, False)
  if VVGIDM:
   self.VVGIDM.append(FFBeKw("Custom Words"))
   self.VVGIDM += VVGIDM
  self.VVyJxc(VViIM0, VV8S8F, inFilterFnc)
 def VVyJxc(self, VViIM0, VV8S8F, inFilterFnc=None):
  VVV7uB  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVQaYB = ("Edit Filter"  , BF(self.VVenqI, VV8S8F))
  VVacc0  = ("Filter Help"  , BF(self.VV4G2f, VV8S8F))
  FFzctu(self.callingSELF, BF(self.VVxWJy, VViIM0), VVGIDM=self.VVGIDM, title="Select Filter", VVV7uB=VVV7uB, VVQaYB=VVQaYB, VVacc0=VVacc0, VVoaDe=True, VVXsDY=self.VVXsDY, VVEEoV=self.VVEEoV)
 def VVxWJy(self, VViIM0, item):
  if item:
   VViIM0(item)
 def VVenqI(self, VV8S8F, selectionObj, sel):
  if fileExists(VV8S8F) : CC8yF1(self.callingSELF, VV8S8F, VViIM0=None)
  else       : FFAhcl(self.callingSELF, VV8S8F)
  selectionObj.cancel()
 def VV4G2f(self, VV8S8F, selectionObj, sel):
  FFog0j(self.callingSELF, "_help_service_filter", "Service Filter")
 def VV52i2(self, VVxL8T, satColNum):
  if not self.satList:
   satList = VVxL8T.VVeNp0(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FF28st(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFBeKw("Satellites"))
  if self.VVGIDM:
   self.VVGIDM += self.satList
 @staticmethod
 def VVD8QJ(SELF, addTag, VVO6nE):
  FFZ1EG()
  fileName  = "ajpanel_services_filter"
  VV8S8F = VV90k3 + fileName
  VVGIDM  = []
  if not fileExists(VV8S8F):
   FFyakl("cp -f '%s' '%s'" % (VV6OO5 + fileName, VV8S8F))
  fileFound = False
  if fileExists(VV8S8F):
   fileFound = True
   lines = FF5p6q(VV8S8F)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVGIDM.append((line, "__w__" + line))
       else  : VVGIDM.append((line, line))
  if VVO6nE:
   if   not fileFound : FFAhcl(SELF, VV8S8F)
   elif not VVGIDM : FFuRB8(SELF, VV8S8F)
  return VVGIDM, VV8S8F
 @staticmethod
 def VV15EP(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCMUYz():
 def __init__(self, callingSELF, VVxL8T, addSep=True):
  self.callingSELF = callingSELF
  self.VVxL8T = VVxL8T
  self.VVGIDM = []
  iMulSel = self.VVxL8T.VVTpqf()
  if iMulSel : self.VVGIDM.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVGIDM.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVxL8T.VVwKPO()
  self.VVGIDM.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVGIDM.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVGIDM.append(VVVgKz)
 def VVtH9B(self, extraMenu, cbFncDict, width=1000, okFnc=None, onMultiSelFnc=None):
  self.VVxL8T.onMultiSelFnc = onMultiSelFnc
  if extraMenu:
   self.VVGIDM.extend(extraMenu)
  FFzctu(self.callingSELF, BF(self.VViw2h, cbFncDict, okFnc), width=width, title="Options", VVGIDM=self.VVGIDM)
 def VViw2h(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVxL8T.VVAi8G(True)
   elif item == "MultSelDisab" : self.VVxL8T.VVAi8G(False)
   elif item == "selectAll" : self.VVxL8T.VVxQIA()
   elif item == "unselectAll" : self.VVxL8T.VVojoM()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCUPpf(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVIYnp, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFCOTe(self)
  FFbJWj(self["keyRed"]  , "Exit")
  FFbJWj(self["keyGreen"]  , "Save")
  FFbJWj(self["keyYellow"] , "Refresh")
  FFbJWj(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(VV6Kiq,
  {
   "red" : self.VVWTDp  ,
   "green" : self.VVvCEM ,
   "yellow": self.VVo2Na  ,
   "blue" : self.VVgS26   ,
   "up" : self.VVNU12    ,
   "down" : self.VV4R52   ,
   "left" : self.VVzWM3   ,
   "right" : self.VVAwZj   ,
   "cancel": self.VVWTDp
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self.VVo2Na()
  self.VV9fur()
  FFOuQx(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVYkSz)
  except:
   self.timer.callback.append(self.VVYkSz)
  self.timer.start(1000, False)
  self.VVYkSz()
 def onExit(self):
  self.timer.stop()
 def VVWTDp(self) : self.close(True)
 def VVtMIa(self) : self.close(False)
 def VVgS26(self):
  self.session.openWithCallback(self.VVhvfC, BF(CCNz7s))
 def VVhvfC(self, closeAll):
  if closeAll:
   self.close()
 def VVYkSz(self):
  self["curTime"].setText(str(FFkL2p(iTime())))
 def VVNU12(self):
  self.VVhjVU(1)
 def VV4R52(self):
  self.VVhjVU(-1)
 def VVzWM3(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV9fur()
 def VVAwZj(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV9fur()
 def VVhjVU(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VV6IwM(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VV6IwM(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VV6IwM(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVwvLK(year)):
   days += 1
  return days
 def VVwvLK(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV9fur(self):
  for obj in self.list:
   FF21Xy(obj, "#11404040")
  FF21Xy(self.list[self.index], "#11ff8000")
 def VVo2Na(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVvCEM(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CCcJGn()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVN852)
 def VVN852(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FF6mzu(self, "Nothing returned from the system!")
  else    : FF6mzu(self, str(result))
class CCNz7s(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VVzHVs, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFCOTe(self, addLabel=True)
  FFbJWj(self["keyRed"]  , "Exit")
  FFbJWj(self["keyGreen"]  , "Sync")
  FFbJWj(self["keyYellow"] , "Refresh")
  FFbJWj(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(VV6Kiq,
  {
   "red" : self.VVWTDp   ,
   "green" : self.VVzu4X  ,
   "yellow": self.VVisiE ,
   "blue" : self.VVpAaa  ,
   "cancel": self.VVWTDp
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVj0IZ()
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  FFOuQx(self)
  FFEuIr(self.VVFuAU)
 def VVFuAU(self):
  self.VVKvjT()
  self.VVepGc(False)
 def VVWTDp(self)  : self.close(True)
 def VVpAaa(self) : self.close(False)
 def VVj0IZ(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVKvjT(self):
  self.VViO3v()
  self.VVt6ya()
  self.VVVsIQ()
  self.VVih71()
 def VVisiE(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVj0IZ()
   self.VVKvjT()
   FFEuIr(self.VVFuAU)
 def VVzu4X(self):
  if len(self["keyGreen"].getText()) > 0:
   FFP9Be(self, self.VVDp3L, "Synchronize with Internet Date/Time ?")
 def VVDp3L(self):
  self.VVKvjT()
  FFEuIr(BF(self.VVepGc, True))
 def VViO3v(self)  : self["keyRed"].show()
 def VVQPgv(self)  : self["keyGreen"].show()
 def VVkNOe(self) : self["keyYellow"].show()
 def VVJFro(self)  : self["keyBlue"].show()
 def VVt6ya(self)  : self["keyGreen"].hide()
 def VVVsIQ(self) : self["keyYellow"].hide()
 def VVih71(self)  : self["keyBlue"].hide()
 def VVepGc(self, sync):
  localTime = FF2gGN()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVpZuY(server)
   if epoch_time is not None:
    ntpTime = FFkL2p(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CCcJGn()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVN852, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVkNOe()
  self.VVJFro()
  if ok:
   self.VVQPgv()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVN852(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVepGc(False)
  except:
   pass
 def VVpZuY(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCXzSR.VVGqI0():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCAtLz(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFLEcJ(VV893L, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFCOTe(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFEuIr(self.VVq8Go)
 def VVq8Go(self):
  if CCXzSR.VVGqI0() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FF21Xy(self["myBody"], color)
   FF21Xy(self["myLabel"], color)
  except:
   pass
class CCz9Ar(Screen):
 VV4zAf = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFiI6j()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFLEcJ(VVxHqF, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCCORl(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCCORl(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCCORl(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC5ePH()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFCOTe(self, title="Signal")
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok"  : self.close      ,
   "up"  : self.VVNU12       ,
   "down"  : self.VV4R52      ,
   "left"  : self.VVzWM3      ,
   "right"  : self.VVAwZj      ,
   "info"  : self.VVWwZ6     ,
   "epg"  : self.VVWwZ6     ,
   "menu"  : self.VVwVgb      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVGd2x, -1)  ,
   "next"  : BF(self.VVGd2x, 1)  ,
   "pageUp" : BF(self.VVpRrI, True) ,
   "chanUp" : BF(self.VVpRrI, True) ,
   "pageDown" : BF(self.VVpRrI, False) ,
   "chanDown" : BF(self.VVpRrI, False) ,
   "0"   : BF(self.VVGd2x, 0)  ,
   "1"   : BF(self.VV57cn, pos=1) ,
   "2"   : BF(self.VV57cn, pos=2) ,
   "3"   : BF(self.VV57cn, pos=3) ,
   "4"   : BF(self.VV57cn, pos=4) ,
   "5"   : BF(self.VV57cn, pos=5) ,
   "6"   : BF(self.VV57cn, pos=6) ,
   "7"   : BF(self.VV57cn, pos=7) ,
   "8"   : BF(self.VV57cn, pos=8) ,
   "9"   : BF(self.VV57cn, pos=9) ,
  }, -1)
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  if not CCz9Ar.VV4zAf:
   CCz9Ar.VV4zAf = self
  self.sliderSNR.VVPQkX()
  self.sliderAGC.VVPQkX()
  self.sliderBER.VVPQkX(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV57cn()
  self.VVajCB()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVroBa)
  except:
   self.timer.callback.append(self.VVroBa)
  self.timer.start(500, False)
 def VVajCB(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VVZZ34(service)
  serviceName = self.tunerInfo.VVnIRE()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  tp = CCSMOW()
  tpTxt, satTxt = tp.VVkCYN(refCode)
  if tpTxt == "?" :
   tpTxt = FFEK4e("NO SIGNAL", VVWEO1)
  self["myTPInfo"].setText(tpTxt + "  " + FFEK4e(satTxt, VVfZXg))
 def VVroBa(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VVZZ34(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVYYVs())
   self["mySNR"].setText(self.tunerInfo.VVjqqP())
   self["myAGC"].setText(self.tunerInfo.VVK8rY())
   self["myBER"].setText(self.tunerInfo.VVfqjK())
   self.sliderSNR.VVRbMv(self.tunerInfo.VVTpsJ())
   self.sliderAGC.VVRbMv(self.tunerInfo.VVIE2H())
   self.sliderBER.VVRbMv(self.tunerInfo.VVp6Yc())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVRbMv(0)
   self.sliderAGC.VVRbMv(0)
   self.sliderBER.VVRbMv(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
    if state and not state == "Tuned":
     FFqgHP(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVWwZ6(self):
  FFNmLy(self, fncMode=CCVNso.VVrqDl)
 def VVwVgb(self):
  FFog0j(self, "_help_signal", "Signal Monitor (Keys)")
 def VVNU12(self)  : self.VV57cn(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VV4R52(self) : self.VV57cn(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVzWM3(self) : self.VV57cn(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVAwZj(self) : self.VV57cn(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV57cn(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFSKZx(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVGd2x(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFEApF(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFSKZx(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCz9Ar.VV4zAf = None
 def VVpRrI(self, isUp):
  FFqgHP(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVajCB()
  except:
   pass
class CCCORl(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVPQkX(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FF21Xy(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VV6OO5 +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FF21Xy(self.covObj, self.covColor)
   else:
    FF21Xy(self.covObj, "#00006688")
    self.isColormode = True
  self.VVRbMv(0)
 def VVRbMv(self, val):
  val  = FFEApF(val, self.minN, self.maxN)
  width = int(FFOn9F(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFEApF(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCChia(Screen):
 VVzhbG    = 0
 VV1d7P = 1
 VVWIWO = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VViIM0=None, barTheme=VVzhbG, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VViPl6(barTheme)
  self.skin, self.skinParam = FFLEcJ(VVzUu4, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VViIM0 = VViIM0
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVfN1b = None
  self.timer   = eTimer()
  self.myThread  = None
  FFCOTe(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(VV6Kiq, { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self.VVVRKl()
  self["myProgBarVal"].setText("0%")
  FF21Xy(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVLePI()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVLePI)
  except:
   self.timer.callback.append(self.VVLePI)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVsWOI(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVIHyJ(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVfN1b), self.counter, self.maxValue, catName)
 def VVlMI5(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVlvVO(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VV6QlR(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVIIGi(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVgcPO(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVDS8r(self, txt):
  self.newTitle = txt
 def VVYksR(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVfN1b), self.counter, self.maxValue)
  except:
   pass
 def VVpHDZ(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVmRFa(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VVssOF(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFqgHP(self, "Cancelling ...")
  self.isCancelled = True
  self.VVFz8i(False)
 def VVFz8i(self, isDone):
  FFEuIr(BF(self.VV2pK9, isDone))
 def VV2pK9(self, isDone):
  if self.VViIM0:
   self.VViIM0(isDone, self.VVfN1b, self.counter, self.maxValue, self.isError)
  self.close()
 def VVLePI(self):
  val = FFEApF(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFOn9F(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVFz8i(True)
 def VVVRKl(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VV1d7P, self.VVWIWO):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VViPl6(self, barTheme):
  if   barTheme == self.VV1d7P : return 0.7
  if   barTheme == self.VVWIWO : return 0.5
  else             : return 1
class CCcJGn(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VViIM0 = {}
  self.commandRunning = False
  self.VV76sq  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VViIM0, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VViIM0[name] = VViIM0
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VV76sq:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVbgXT, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VV3wjJ , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVbgXT, name))
    self.appContainers[name].appClosed.append(BF(self.VV3wjJ , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VV3wjJ(name, retval)
  return True
 def VVbgXT(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFEK4e("[UN-DECODED STRING]", VVWEO1))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VV3wjJ(self, name, retval):
  if not self.VV76sq:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VViIM0[name]:
   self.VViIM0[name](self.appResults[name], retval)
  del self.VViIM0[name]
 def VVWA8R(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCc4FI(Screen):
 def __init__(self, session, title="", VV1Y5G=None, VVLf8a=False, VVkaA2=False, VVf9w3=False, VVaAu9=False, VVWcUz=False, VVX6l4=False, VVvR9T=VVV4jO, VVZgJA=None, VVXCZg=False, VVba7Y=None, VVeQqS="", checkNetAccess=False, VVNdFV=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFLEcJ(VV07bh, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVNdFV, usefixedFont=consFont)
  self.session   = session
  self.VVeQqS = VVeQqS
  FFCOTe(self, addScrollLabel=True)
  self.VVLf8a   = VVLf8a
  self.VVkaA2   = VVkaA2
  self.VVf9w3   = VVf9w3
  self.VVaAu9  = VVaAu9
  self.VVWcUz = VVWcUz
  self.VVX6l4 = VVX6l4
  self.VVvR9T   = VVvR9T
  self.VVZgJA = VVZgJA
  self.VVXCZg  = VVXCZg
  self.VVba7Y  = VVba7Y
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CCcJGn()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFpdY0()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VV1Y5G, str):
   self.VV1Y5G = [VV1Y5G]
  else:
   self.VV1Y5G = VV1Y5G
  if self.VVf9w3 or self.VVaAu9:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VV1Y5G.append("echo -e '\n%s\n' %s" % (restartNote, FFpC0R(restartNote, VVWhci)))
   if self.VVf9w3:
    self.VV1Y5G.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VV1Y5G.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVWcUz:
   FFqgHP(self, "Processing ...")
  self.onLayoutFinish.append(self.VV5tER)
  self.onClose.append(self.VVj9oW)
 def VV5tER(self):
  self["myLabel"].VVSAed(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVeQqS or "Processing ..."))
  if self.VVLf8a:
   self["myLabel"].VVT70L()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV7Srw()
  else:
   self.VV4Uw2()
 def VV7Srw(self):
  if CCXzSR.VVGqI0():
   self["myLabel"].setText("Processing ...")
   self.VV4Uw2()
  else:
   self["myLabel"].setText(FFEK4e("\n   No connection to internet!", VVnviq))
 def VV4Uw2(self):
  allOK = self.container.ePopen(self.VV1Y5G[0], self.VVAonQ, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVAonQ("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVX6l4 or self.VVf9w3 or self.VVaAu9:
    self["myLabel"].setText(FFu7MN("STARTED", VVWhci) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVba7Y:
   colorWhite = CCvWVD.VVhK0P(VVoR97)
   color  = CCvWVD.VVhK0P(self.VVba7Y[0])
   words  = self.VVba7Y[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVvR9T=self.VVvR9T)
 def VVAonQ(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VV1Y5G):
   allOK = self.container.ePopen(self.VV1Y5G[self.cmdNum], self.VVAonQ, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVAonQ("Cannot connect to Console!", -1)
  else:
   if self.VVWcUz and FFaIEn(self):
    FFqgHP(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVX6l4:
    self["myLabel"].appendText("\n" + FFu7MN("FINISHED", VVWhci), self.VVvR9T)
   if self.VVLf8a or self.VVkaA2:
    self["myLabel"].VVT70L()
   if self.VVZgJA is not None:
    self.VVZgJA()
   if not retval and self.VVXCZg:
    self.VVj9oW()
 def VVj9oW(self):
  if self.container.VVWA8R():
   self.container.killAll()
class CCrHuk(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFLEcJ(VV07bh, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VV90k3 + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFunaH("pwd") or "/home/root"
  self.container   = CCcJGn()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFCOTe(self, title="Terminal", addScrollLabel=True)
  FFbJWj(self["keyRed"] , self.exitBtnText)
  FFbJWj(self["keyGreen"] , "OK = History")
  FFbJWj(self["keyYellow"], "Menu = Custom Cmds")
  FFbJWj(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVuVkt ,
   "cancel": self.VVYep3  ,
   "menu" : self.VVSQfD ,
   "last" : self.VVMdIY  ,
   "next" : self.VVMdIY  ,
   "1"  : self.VVMdIY  ,
   "2"  : self.VVMdIY  ,
   "3"  : self.VVMdIY  ,
   "4"  : self.VVMdIY  ,
   "5"  : self.VVMdIY  ,
   "6"  : self.VVMdIY  ,
   "7"  : self.VVMdIY  ,
   "8"  : self.VVMdIY  ,
   "9"  : self.VVMdIY  ,
   "0"  : self.VVMdIY
  })
  self.onLayoutFinish.append(self.VVg3Fx)
  self.onClose.append(self.VVIgtI)
 def VVg3Fx(self):
  self["myLabel"].VVSAed(isResizable=False, outputFileToSave="terminal")
  FFtmqG(self["keyRed"]  , "#00ff8000")
  FF21Xy(self["keyRed"]  , self.skinParam["titleColor"])
  FF21Xy(self["keyGreen"]  , self.skinParam["titleColor"])
  FF21Xy(self["keyYellow"] , self.skinParam["titleColor"])
  FF21Xy(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVUB8S(FFunaH("date"), 5)
  result = FFunaH("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVB70r()
  self.VVedPr()
 def VVedPr(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VV90k3 + "LinuxCommands.lst"
  templPath = VV6OO5 + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFyakl("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFqj03("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VVIgtI(self):
  if self.container.VVWA8R():
   self.container.killAll()
   self.VVUB8S("Process killed\n", 4)
   self.VVB70r()
 def VVYep3(self):
  if self.container.VVWA8R():
   self.VVIgtI()
  else:
   FFP9Be(self, self.close, "Exit ?", VVfGaL=False)
 def VVB70r(self):
  self.VVUB8S(self.prompt, 1)
  self["keyRed"].hide()
 def VVUB8S(self, txt, mode):
  if   mode == 1 : color = VVWhci
  elif mode == 2 : color = VVN1ah
  elif mode == 3 : color = VVoR97
  elif mode == 4 : color = VVnviq
  elif mode == 5 : color = VVhSN2
  elif mode == 6 : color = VVJvHF
  else   : color = VVoR97
  try:
   self["myLabel"].appendText(FFEK4e(txt, color))
  except:
   pass
 def VVuVkt(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVl06c() == "":
   self.VVo9Yw("cd /tmp")
   self.VVo9Yw("ls")
  VVnhmb = []
  if fileExists(self.commandHistoryFile):
   lines  = FF5p6q(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVnhmb.append((str(c), line, str(lNum)))
   self.VVYib5(VVnhmb, title, self.commandHistoryFile, isHistory=True)
  else:
   FFAhcl(self, self.commandHistoryFile, title=title)
 def VVl06c(self):
  lastLine = FFunaH("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVo9Yw(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVSQfD(self, VVxL8T=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FF5p6q(self.customCommandsFile)
   VVnhmb = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVnhmb.append((str(c), line, str(lNum)))
   if VVxL8T:
    VVxL8T.VVlCGq(VVnhmb)
    VVxL8T.VVyaYN(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVYib5(VVnhmb, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFAhcl(self, self.customCommandsFile, title=title)
 def VVYib5(self, VVnhmb, title, filePath=None, isHistory=False):
  if VVnhmb:
   VVhaQs = "#05333333"
   if isHistory: VVXsDY = VVEEoV = VVasam = "#11000020"
   else  : VVXsDY = VVEEoV = VVasam = "#06002020"
   VVRWOd   = ("Send"   , BF(self.VV7OGY, isHistory)  , [])
   VVoXaA  = ("Modify & Send" , self.VVgMO6     , [])
   if isHistory:
    VVMCbu = ("Clear History" , self.VVph6y     , [])
    VVUm5B = None
    VVMOfU = None
   elif filePath:
    VVMCbu = ("Options"  , self.VVFDBF      , [])
    VVUm5B = ("Edit File"  , BF(self.VVEHNh, filePath) , [])
    VVMOfU = (""    , self.VVCVWm     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVyaAW = (CENTER , LEFT   , CENTER )
   VVxL8T = FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B, VVMOfU=VVMOfU, lastFindConfigObj=CFG.lastFindTerminal, VVehvv=True, searchCol=1
         , VVXsDY=VVXsDY, VVEEoV=VVEEoV, VVasam=VVasam, VVhaQs=VVhaQs)
   if not isHistory:
    VVxL8T.VVyaYN(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFP9Be(self, BF(self.VVlXE0, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVCVWm(self, VVxL8T, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FFEK4e("Command:", VVfZXg), colList[1])
  txt += "%s\n%s\n\n" % (FFEK4e("Line %s in File:" % colList[2], VVfZXg), self.customCommandsFile)
  FFDLqC(self, txt, title=title)
 def VVFDBF(self, VVxL8T, title, txt, colList):
  mSel = CCMUYz(self, VVxL8T)
  VVGIDM = []
  txt1 = "Change Custom Commands File"
  if VVxL8T.VV1dHJ:
   VVGIDM.append((txt1, ))
   VVGIDM.append(VVVgKz)
   totSel = VVxL8T.VVwKPO()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FFEK4e(totTxt, VVWhci) if totSel else totTxt, FFlPiz(totSel))
   VVGIDM.append((txt2, "send") if totSel else (txt2,))
  else:
   VVGIDM.append((txt1, "newFile"))
   VVGIDM.append(VVVgKz)
   txt2 = "Send current line"
   VVGIDM.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVlXE0, VVxL8T, txt1)
     , "send" : BF(self.VV7OGY, False, VVxL8T, title, txt2, colList) }
  mSel.VVtH9B(VVGIDM, cbFncDict, okFnc=BF(self.VVenhd, VVxL8T))
 def VVlXE0(self, VVxL8T, title):
  VVGIDM = []
  for fName in os.listdir(VV90k3):
   path = os.path.join(VV90k3, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVGIDM.append((fName, path))
  VVGIDM.sort(key=lambda x: x[0].lower())
  if VVGIDM : FFzctu(self, BF(self.VVVguV, VVxL8T, title), VVGIDM=VVGIDM, title=title, minRows=3, VVXsDY="#11220000", VVEEoV="#11220000")
  else  : FFryuM(self, "No valid files found in:\n\n%s" % VV90k3, title=title)
 def VVVguV(self, VVxL8T, title, path=None):
  if path:
   if CCLyBs.VVjqqH(path):
    FFryuM(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FF5p6q(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFSKZx(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFSKZx(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVSQfD(VVxL8T)
      break
    else:
     FFryuM(self, "File is empty:\n\n%s" % path, title=title)
 def VVenhd(self, VVxL8T):
  if VVxL8T.VV1dHJ : VVxL8T.VVbwhi()
  else        : VVxL8T.VVvtnk()
 def VV7OGY(self, isHistory, VVxL8T, title, txt, colList):
  if VVxL8T.VV1dHJ:
   lst = VVxL8T.VVgXLx(1)
   curNdx = VVxL8T.VVesQT()
  else:
   lst = [colList[1]]
   curNdx = VVxL8T.VVsf2R()
  if not isHistory:
   FFSKZx(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVxL8T.cancel()
  FFEuIr(self.VVCHEn)
 def VVCHEn(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVUB8S("\n%s\n" % cmd, 6)
    self.VVUB8S(self.prompt, 1)
    self.VVCHEn()
   else:
    self.VV3wjo(cmd)
 def VV3wjo(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVUB8S(cmd, 2)
   self.VVUB8S("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVUB8S(ch, 0)
   self.VVUB8S("\nor\n", 4)
   self.VVUB8S("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVB70r()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFEK4e(parts[0].strip(), VVN1ah)
    right = FFEK4e("#" + parts[1].strip(), VVJvHF)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVUB8S(txt, 2)
   lastLine = self.VVl06c()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVo9Yw(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVAonQ, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFryuM(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVUB8S(data, 3)
 def VVAonQ(self, data, retval):
  if not retval == 0:
   self.VVUB8S("Exit Code : %d\n" % retval, 4)
  self.VVB70r()
  if self.commandsList:
   self.VVCHEn()
 def VVgMO6(self, VVxL8T, title, txt, colList):
  if VVxL8T.VVLeTy():
   cmd = colList[1]
   self.VVBpsP(VVxL8T, cmd)
 def VVph6y(self, VVxL8T, title, txt, colList):
  FFP9Be(self, BF(self.VVpy9t, VVxL8T), "Reset History File ?", title="Command History")
 def VVpy9t(self, VVxL8T):
  FFqj03("> '%s'" % self.commandHistoryFile)
  VVxL8T.cancel()
 def VVEHNh(self, filePath, VVxL8T, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CC8yF1(self, filePath, VViIM0=BF(self.VVn3I2, VVxL8T), curRowNum=rowNum)
  else     : FFAhcl(self, filePath)
 def VVn3I2(self, VVxL8T, fileChanged):
  if fileChanged:
   VVxL8T.cancel()
   FFEuIr(self.VVSQfD)
 def VVMdIY(self):
  self.VVBpsP(None, self.lastCommand)
 def VVBpsP(self, VVxL8T, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FF9Fmo(self, BF(self.VVMx5j, VVxL8T), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVMx5j(self, VVxL8T, cmd):
  if cmd and len(cmd) > 0:
   self.VV3wjo(cmd)
   if VVxL8T:
    VVxL8T.cancel()
class CCqeTQ(Screen):
 def __init__(self, session, title="", message="", VVvR9T=VVV4jO, width=1400, height=900, VVijyJ=False, titleBg="#22002020", VVasam="#22001122", VVNdFV=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFLEcJ(VV07bh, width, height, titleFontSize, 30, 20, titleBg, VVasam, VVNdFV)
  self.session   = session
  FFCOTe(self, title, addScrollLabel=True)
  self.VVvR9T   = VVvR9T
  self.VVijyJ   = VVijyJ
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self["myLabel"].VVSAed(VVijyJ=self.VVijyJ, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVvR9T)
  self["myLabel"].VVT70L()
class CCmt5Q(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FFLEcJ(VVuMjv, 1800, 60, 30, 30, 20, "#55000000", "#ff000000", 30)
  self.session  = session
  self.txt   = txt
  self["myWinTitle"] = Label()
  FFCOTe(self, " ", addCloser=True)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  CCRdl4.VV4WYi(self, self.txt)
  self.instance.move(ePoint((getDesktop(0).size().width() - self.instance.size().width()) // 2, 20))
class CCA7Fu(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFLEcJ(VV3S9Z, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFCOTe(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFLUTg(self["errPic"], "err")
class CCKQlj(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFLEcJ(VVuMjv, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFCOTe(self, " ", addCloser=True)
class CCRdl4():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CCRdl4.VVo0qy(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VVPuIk)
  except: self.timer.callback.append(self.VVPuIk)
  self.timer.start(timeout, True)
 def VVPuIk(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVo0qy(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCKQlj, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFuM3s(win["myWinTitle"], shadColor, shadW)
  CCRdl4.VV4WYi(win, txt)
  return win
 @staticmethod
 def VV4WYi(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CC6EZK():
 VV8tpZ    = 0
 VVsvo7  = 1
 VVE4Ds   = ""
 VVCBE7    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVxL8T   = None
  self.timer     = eTimer()
  self.VVuVEb   = 0
  self.VV1ls0  = 1
  self.VVZ2Lr  = 2
  self.VVXUkd   = 3
  self.VVGENI   = 4
  VVnhmb = self.VVYjvK()
  if VVnhmb:
   self.VVxL8T = self.VVBvGj(VVnhmb)
  if not VVnhmb and mode == self.VV8tpZ:
   self.VVInOH("Download list is empty !")
   self.cancel()
  if mode == self.VVsvo7:
   FFVCur(self.VVxL8T or self.SELF, BF(self.VV7ODs, startDnld, decodedUrl), title="Checking Server ...")
  self.VVZTuo(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZTuo)
  except:
   self.timer.callback.append(self.VVZTuo)
  self.timer.start(1000, False)
 def VVBvGj(self, VVnhmb):
  VVnhmb.sort(key=lambda x: int(x[0]))
  VVU1op = self.VVACIB
  VVRWOd  = ("Play"  , self.VVT7pn , [])
  VVMOfU = (""   , self.VVqcN5  , [])
  VVr0hN = ("Stop"  , self.VVVvfm  , [])
  VVoXaA = ("Resume"  , self.VVzTpx , [])
  VVMCbu = ("Options" , self.VVNYFT  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVyaAW  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFfJU2(self.SELF, None, title=self.Title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVRWOd=VVRWOd, VVMOfU=VVMOfU, VVU1op=VVU1op, VVr0hN=VVr0hN, VVoXaA=VVoXaA, VVMCbu=VVMCbu, lastFindConfigObj=CFG.lastFindIptv, VVXsDY="#11220022", VVEEoV="#11110011", VVasam="#11110011", VVhaQs="#00223025", VVAXDQ="#0a333333", VVilD4="#0a400040", VVehvv=True, searchCol=1)
 def VVYjvK(self):
  lines = CC6EZK.VVXtSR()
  VVnhmb = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVgwsR(decodedUrl)
      if fName:
       if   FFNcCV(decodedUrl) : sType = "Movie"
       elif FF8I4s(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVK680(decodedUrl, fName)
       if size > -1: sizeTxt = CCLyBs.VVM24t(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVnhmb.append((str(len(VVnhmb) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVnhmb
 def VVg19s(self):
  VVnhmb = self.VVYjvK()
  if VVnhmb:
   if self.VVxL8T : self.VVxL8T.VVlCGq(VVnhmb, VVj0IZMsg=False)
   else     : self.VVxL8T = self.VVBvGj(VVnhmb)
  else:
   self.cancel()
 def VVZTuo(self, force=False):
  if self.VVxL8T:
   thrListUrls = self.VVxSja()
   VVnhmb = []
   changed = False
   for ndx, row in enumerate(self.VVxL8T.VVWcfU()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVuVEb
    if m3u8Log:
     percent = CC6EZK.VVG3QL(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVXUkd , "%.2f %%" % percent
      else   : flag, progr = self.VVGENI , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFl8II(mPath)
     if curSize > -1:
      fSize = CCLyBs.VVM24t(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCLyBs.VVM24t(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFl8II(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVXUkd , "%.2f %%" % percent
       else   : flag, progr = self.VVGENI , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCLyBs.VVM24t(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VVZ2Lr
     if m3u8Log :
      if not speed and not force : flag = self.VV1ls0
      elif curSize == -1   : self.VVDynP(False)
    elif flag == self.VVuVEb  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVuVEb  : color2 = "#f#00555555#"
    elif flag == self.VV1ls0 : color2 = "#f#0000FFFF#"
    elif flag == self.VVZ2Lr : color2 = "#f#0000FFFF#"
    elif flag == self.VVXUkd  : color2 = "#f#00FF8000#"
    elif flag == self.VVGENI  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVlBNe(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVnhmb.append(row)
   if changed or force:
    self.VVxL8T.VVlCGq(VVnhmb, VVj0IZMsg=False)
 def VVlBNe(self, flag):
  tDict = self.VVOdB5()
  return tDict.get(flag, "?")
 def VV7p2N(self, state):
  for flag, txt in self.VVOdB5().items():
   if txt == state:
    return flag
  return -1
 def VVOdB5(self):
  return { self.VVuVEb: "Not started", self.VV1ls0: "Connecting", self.VVZ2Lr: "Downloading", self.VVXUkd: "Stopped", self.VVGENI: "Completed" }
 def VVpYgd(self, title):
  colList = self.VVxL8T.VVoYvr()
  path = colList[6]
  url  = colList[8]
  if self.VVEQWo() : self.VVInOH("Cannot delete !\n\nFile is downloading.")
  else      : FFP9Be(self.SELF, BF(self.VV8mZv, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV8mZv(self, path, url):
  m3u8Log = self.VVxL8T.VVoYvr()[12]
  if m3u8Log : FFyakl("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFyakl("rm -rf '%s'" % path)
  self.VVbiWE(False)
  self.VVg19s()
 def VVbiWE(self, VVO6nE=True):
  if self.VVEQWo():
   FFqgHP(self.VVxL8T, self.VVlBNe(self.VVZ2Lr), 500)
  else:
   colList  = self.VVxL8T.VVoYvr()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VV7p2N(state) in (self.VVuVEb, self.VVGENI, self.VVXUkd):
    lines = CC6EZK.VVXtSR()
    newLines = []
    found = False
    for line in lines:
     if CC6EZK.VVkATb(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVPNbW(newLines)
     self.VVg19s()
     FFqgHP(self.VVxL8T, "Removed.", 1000)
    else:
     FFqgHP(self.VVxL8T, "Not found.", 1000)
   elif VVO6nE:
    self.VVInOH("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VViBOJ(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFP9Be(self.SELF, BF(self.VVOQUW, flag), ques, title=title)
 def VVOQUW(self, flag):
  list = []
  for ndx, row in enumerate(self.VVxL8T.VVWcfU()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VV7p2N(state)
   if   flag == flagVal == self.VVGENI: list.append(decodedUrl)
   elif flag == flagVal == self.VVuVEb : list.append(decodedUrl)
  lines = CC6EZK.VVXtSR()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVPNbW(newLines)
   self.VVg19s()
   FFqgHP(self.VVxL8T, "%d removed." % totRem, 1000)
  else:
   FFqgHP(self.VVxL8T, "Not found.", 1000)
 def VVeWJX(self):
  colList  = self.VVxL8T.VVoYvr()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFqgHP(self.VVxL8T, "Poster exists", 1500)
  else    : FFVCur(self.VVxL8T, BF(self.VVajFS, decodedUrl, path, png), title="Checking Server ...")
 def VVajFS(self, decodedUrl, path, png):
  err = self.VVbXfo(decodedUrl, path, png)
  if err:
   FFryuM(self.SELF, err, title="Poster Download")
 def VVbXfo(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCPf1i.VVKIr3(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCDrYI.VV5ztg(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCDrYI.VVI941(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCDrYI.VVklIB(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFgHO0(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFyakl("mv -f '%s' '%s'" % (tPath, png))
   CCceHb.VVLNYv(self.SELF, VVpjN9=png, showGrnMsg="Downloaded")
   return ""
 def VVqcN5(self, VVxL8T, title, txt, colList):
  def VVu8zC(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVR7gd(key, val) : return "\n%s:\n%s\n" % (FFEK4e(key, VVfZXg), val.strip())
  heads  = self.VVxL8T.VVoaZ9()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVu8zC(heads[i]  , CCLyBs.VVM24t(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVu8zC("Downloaded" , CCLyBs.VVM24t(int(curSize), mode=0))
   else:
    txt += VVu8zC(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVR7gd(heads[i], colList[i])
  FFDLqC(self.SELF, txt, title=title)
 def VVT7pn(self, VVxL8T, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCLyBs.VVKTM4(self.SELF, path)
  else    : FFqgHP(self.VVxL8T, "File not found", 1000)
 def VVACIB(self, VVxL8T):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVxL8T:
   self.VVxL8T.cancel()
  del self
 def VVNYFT(self, VVxL8T, title, txt, colList):
  c1, c2, c3 = VVUVBT, VVnviq, VVfZXg
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVGIDM = []
  VVGIDM.append((c1 + "Remove current row"       , "VVbiWE" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVGIDM.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c2 + "Delete the file (and remove from list)"  , "VVpYgd"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((resumeTxt + " Auto Resume"       , "VV0kTi" ))
  VVGIDM.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVGIDM.append(VVVgKz)
  cond = FFNcCV(decodedUrl)
  VVGIDM.append(FFzUJ4("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVeWJX", cond, c3))
  VVGIDM.append(FFzUJ4("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFzctu(self.SELF, BF(self.VVhHmD, VVxL8T), VVGIDM=VVGIDM, title=self.Title, VVglmG=True, width=800, VVoaDe=True, VVXsDY="#1a001122", VVEEoV="#1a001122")
 def VVhHmD(self, VVxL8T, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVbiWE"  : self.VVbiWE()
   elif ref == "remFinished"   : self.VViBOJ(self.VVGENI, txt)
   elif ref == "remPending"   : self.VViBOJ(self.VVuVEb, txt)
   elif ref == "VVpYgd" : self.VVpYgd(txt)
   elif ref == "VVeWJX"  : self.VVeWJX()
   elif ref == "VV0kTi"  : FFSKZx(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFSKZx(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCLyBs, mode=CCLyBs.VVGziO, jumpToFile=path)
    else    : FFqgHP(VVxL8T, "Path not found !", 1500)
 def VV7ODs(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCPf1i.VVKIr3(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVInOH("Could not get download link !\n\nTry again later.")
     return
  for line in CC6EZK.VVXtSR():
   if CC6EZK.VVkATb(decodedUrl, line):
    if self.VVxL8T:
     self.VVkpk0(decodedUrl)
     FFEuIr(BF(FFqgHP, self.VVxL8T, "Already listed !", 2000))
    break
  else:
   params = self.VVbyOg(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVInOH(params[0])
   elif len(params) == 2:
    FFP9Be(self.SELF, BF(self.VVz2W9, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCLyBs.VVM24t(fSize)
    FFP9Be(self.SELF, BF(self.VVETLb, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVETLb(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CC6EZK.VVqFve(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVg19s()
  if self.VVxL8T:
   self.VVxL8T.VVxQfy()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CC6EZK.VVCBE7, path, decodedUrl)
   self.VV58zQ(threadName, url, decodedUrl, path, resp)
 def VVkpk0(self, decodedUrl):
  if self.VVxL8T:
   for ndx, row in enumerate(self.VVxL8T.VVWcfU()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVxL8T:
     self.VVxL8T.VVyaYN(ndx)
     break
 def VVbyOg(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVgwsR(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVK680(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCPf1i.VVKIr3(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCPf1i.VVcBjZ()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CC6EZK.VVvvSZ(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CC6EZK.VVw6KK(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVz2W9(self, resp, decodedUrl):
  if not FFE0hR("ffmpeg"):
   FFP9Be(self.SELF, BF(CCDrYI.VVVTNI, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVgwsR(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVqJwv(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFP9Be(self.SELF, BF(self.VVYiyH, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVYiyH(rTxt, rUrl)
  else:
   self.VVInOH("Cannot process m3u8 file !")
 def VVqJwv(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVGIDM = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCDrYI.VVD1KR(rUrl, fPath)
   VVGIDM.append((resol, fullUrl))
  if VVGIDM:
   FFzctu(self.SELF, self.VVtQAq, VVGIDM=VVGIDM, title="Resolution", VVglmG=True, VVoaDe=True)
  else:
   self.VVInOH("Cannot get Resolutions list from server !")
 def VVtQAq(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFP9Be(self.SELF, BF(FFEuIr, BF(self.VV7Mt7, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFEuIr(BF(self.VV7Mt7, resolUrl))
 def VV7Mt7(self, resolUrl):
  txt, err = CCPf1i.VVybt6(resolUrl)
  if err : self.VVInOH(err)
  else : self.VVYiyH(txt, resolUrl)
 def VV4HLg(self, logF, decodedUrl):
  found = False
  lines = CC6EZK.VVXtSR()
  with open(CC6EZK.VVqFve(), "w") as f:
   for line in lines:
    if CC6EZK.VVkATb(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CC6EZK.VVqFve(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVg19s()
  if self.VVxL8T:
   self.VVxL8T.VVxQfy()
 def VVYiyH(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCDrYI.VVD1KR(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVInOH("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VV4HLg(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFbUbn("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CC6EZK.VVCBE7, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVG3QL(dnldLog):
  if fileExists(dnldLog):
   dur = CC6EZK.VV2xAO(dnldLog)
   if dur > -1:
    tim = CC6EZK.VV4dl4(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VV2xAO(dnldLog):
  lines = FF30Q2("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VV4dl4(dnldLog):
  lines = FF30Q2("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVK680(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FF8I4s(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFyakl("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VV58zQ(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVxL8T.VVoYvr()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VVR2N6, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VVR2N6(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVE4Ds == path:
       break
     else:
      break
  except:
   return
  if CC6EZK.VVE4Ds:
   CC6EZK.VVE4Ds = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFl8II(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVbyOg(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VVR2N6(url, decodedUrl, path, resp, totFileSize, True)
 def VVVvfm(self, VVxL8T, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVQqDN() : FFqgHP(self.VVxL8T, self.VVlBNe(self.VVGENI), 500)
  elif not self.VVEQWo() : FFqgHP(self.VVxL8T, self.VVlBNe(self.VVXUkd), 500)
  elif m3u8Log      : FFP9Be(self.SELF, self.VVDynP, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVxSja():
    CC6EZK.VVE4Ds = colList[6]
    FFqgHP(self.VVxL8T, "Stopping ...", 1000)
   else:
    FFqgHP(self.VVxL8T, "Stopped", 500)
 def VVDynP(self, withMsg=True):
  if withMsg:
   FFqgHP(self.VVxL8T, "Stopping ...", 1000)
  FFyakl("killall -INT ffmpeg")
 def VVzTpx(self, *args):
  if   self.VVQqDN() : FFqgHP(self.VVxL8T, self.VVlBNe(self.VVGENI) , 500)
  elif self.VVEQWo() : FFqgHP(self.VVxL8T, self.VVlBNe(self.VVZ2Lr), 500)
  else:
   resume = False
   m3u8Log = self.VVxL8T.VVoYvr()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFP9Be(self.SELF, BF(self.VV1LZs, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVVUNJ():
    resume = True
   if resume: FFVCur(self.VVxL8T, BF(self.VVHAbf), title="Checking Server ...")
   else  : FFqgHP(self.VVxL8T, "Cannot resume !", 500)
 def VV1LZs(self, m3u8Log):
  FFyakl("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FFVCur(self.VVxL8T, BF(self.VVHAbf), title="Checking Server ...")
 def VVHAbf(self):
  colList  = self.VVxL8T.VVoYvr()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCPf1i.VVKIr3(decodedUrl)
   if url:
    decodedUrl = self.VVKzbx(decodedUrl, url)
   else:
    self.VVInOH("Could not get download link !\n\nTry again later.")
    return
  curSize = FFl8II(path)
  params = self.VVbyOg(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVInOH(params[0])
   return
  elif len(params) == 2:
   self.VVz2W9(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVKzbx(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CC6EZK.VVCBE7, path, decodedUrl)
  if resumable: self.VV58zQ(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVInOH("Cannot resume from server !")
 def VVgwsR(self, decodedUrl):
  fileExt = CCDrYI.VVNkCY(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFHhMF(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVInOH(self, txt):
  FFryuM(self.SELF, txt, title=self.Title)
 def VVxSja(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CC6EZK.VVCBE7, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVEQWo(self):
  decodedUrl = self.VVxL8T.VVoYvr()[9]
  return decodedUrl in self.VVxSja()
 def VVQqDN(self):
  colList = self.VVxL8T.VVoYvr()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFl8II(path)) == size
 def VVVUNJ(self):
  colList = self.VVxL8T.VVoYvr()
  path = colList[6]
  size = int(colList[7])
  curSize = FFl8II(path)
  if curSize > -1:
   size -= curSize
  err = CC6EZK.VVw6KK(size)
  if err:
   FFryuM(self.SELF, err, title=self.Title)
   return False
  return True
 def VVPNbW(self, list):
  with open(CC6EZK.VVqFve(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVKzbx(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CC6EZK.VVXtSR()
  url = decodedUrl
  with open(CC6EZK.VVqFve(), "w") as f:
   for line in lines:
    if CC6EZK.VVkATb(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVg19s()
  return url
 @staticmethod
 def VVXtSR():
  list = []
  if fileExists(CC6EZK.VVqFve()):
   for line in FF5p6q(CC6EZK.VVqFve()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVkATb(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVw6KK(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCLyBs.VVJ8wE(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCLyBs.VVM24t(size), CCLyBs.VVM24t(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVXK5F(SELF):
  tot = CC6EZK.VV7f7z()
  if tot:
   FFryuM(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VV7f7z():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CC6EZK.VVCBE7):
    c += 1
  return c
 @staticmethod
 def VVII63():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CC6EZK.VVCBE7, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVtCyi():
  return len(CC6EZK.VVXtSR()) == 0
 @staticmethod
 def VVZJsb():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VV5hTc():
  mPoints = CC6EZK.VVZJsb()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFyakl("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVqFve():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVAVyn(SELF, waitMsgObj=None):
  FFVCur(waitMsgObj or SELF, BF(CC6EZK.VVz72W, SELF, CC6EZK.VV8tpZ))
 @staticmethod
 def VVq7M9(SELF):
  CC6EZK.VVz72W(SELF, CC6EZK.VVsvo7, startDnld=True)
 @staticmethod
 def VVWkuu(SELF, url):
  CC6EZK.VVz72W(SELF, CC6EZK.VVsvo7, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVsILg(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(SELF)
  added, skipped = CC6EZK.VVEq5N([decodedUrl])
  FFqgHP(SELF, "Added", 1000)
 @staticmethod
 def VVEq5N(list):
  added = skipped = 0
  for line in CC6EZK.VVXtSR():
   for ndx, url in enumerate(list):
    if url and CC6EZK.VVkATb(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CC6EZK.VVqFve(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVz72W(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CCOnT0.VVqlCJ(SELF):
   return
  if mode == CC6EZK.VV8tpZ and CC6EZK.VVtCyi():
   FFryuM(SELF, "Download list is empty !", title=title)
  else:
   inst = CC6EZK(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVvvSZ(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCTKa3(Screen, CCJVUC):
 VVvj2H = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFLEcJ(VVWtHv, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCJVUC.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFCOTe(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVCW5Z())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(VV6Kiq,
  {
   "ok"  : self.VVLgni       ,
   "info"  : self.VVWwZ6      ,
   "epg"  : self.VVWwZ6      ,
   "menu"  : self.VVgLvJ     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVYTHD   ,
   "green"  : self.VVECRh  ,
   "blue"  : self.VVwizV      ,
   "yellow" : self.VVpnd7 ,
   "left"  : BF(self.VVsMr3, -1)    ,
   "right"  : BF(self.VVsMr3,  1)    ,
   "play"  : self.VVYmK7      ,
   "pause"  : self.VVYmK7      ,
   "playPause" : self.VVYmK7      ,
   "stop"  : self.VVYmK7      ,
   "rewind" : self.VVdkr8      ,
   "forward" : self.VVcMcX      ,
   "rewindDm" : self.VVdkr8      ,
   "forwardDm" : self.VVcMcX      ,
   "last"  : self.VVCF95      ,
   "next"  : self.VVfiEL      ,
   "pageUp" : BF(self.VVHUsZ, True)  ,
   "pageDown" : BF(self.VVHUsZ, False)  ,
   "chanUp" : BF(self.VVHUsZ, True)  ,
   "chanDown" : BF(self.VVHUsZ, False)  ,
   "up"  : BF(self.VVHUsZ, True)  ,
   "down"  : BF(self.VVHUsZ, False)  ,
   "audio"  : BF(self.VVf0F7, True)  ,
   "subtitle" : BF(self.VVf0F7, False)  ,
   "text"  : self.VVZfLo  ,
   "0"   : BF(self.VVrW5A , 10)   ,
   "1"   : BF(self.VVrW5A , 1)   ,
   "2"   : BF(self.VVrW5A , 2)   ,
   "3"   : BF(self.VVrW5A , 3)   ,
   "4"   : BF(self.VVrW5A , 4)   ,
   "5"   : BF(self.VVrW5A , 5)   ,
   "6"   : BF(self.VVrW5A , 6)   ,
   "7"   : BF(self.VVrW5A , 7)   ,
   "8"   : BF(self.VVrW5A , 8)   ,
   "9"   : BF(self.VVrW5A , 9)
  }, -1)
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FF9NP9(self)
  if not CCTKa3.VVvj2H:
   CCTKa3.VVvj2H = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFLUTg(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFLUTg(self["myPlayRpt"], "rpt")
  self.VVfNwF()
  self.instance.move(ePoint(40, 40))
  self.VVY1mD(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVRaMc)
  except:
   self.timer.callback.append(self.VVRaMc)
  self.timer.start(250, False)
  self.VVRaMc("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVShyQ()
 def VVECRh(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  self.lastSubtitle = CCA1Ob.VVP0hS()
  if "chCode" in iptvRef:
   if CCOnT0.VVqlCJ(self):
    self.VVShyQ(True)
  else:
   self.VVRaMc("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVfNwF(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVHnzd()
  chName = FFLKj3(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVWEO1 + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FF21Xy(self["myTitle"], tColor)
  FF21Xy(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FF21Xy(self["myPlay%s" % item], tColor)
  picFile = CCVNso.VVH8tG(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCVNso.VV36ET(self)
  cl = CCpTQt.VVseWq(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVRaMc(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CC6EZK.VV7f7z()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVHnzd()
  if evName:
   evName = "    %s    " % FFEK4e(evName, VVhSN2)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVLBLu():
   FFtmqG(self["myPlayBlu"], "#00FFFFFF")
   FF21Xy(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFtmqG(self["myPlayBlu"], "#00FFFF88")
   FF21Xy(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCDrYI.VVC4SX(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVJvHF + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FF21Xy(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFEApF(percVal, 0, 100)
   width = int(FFOn9F(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FF21Xy(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFtmqG(self["myPlayMsg"], "#0000ffff")
   else  : FFtmqG(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFtmqG(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFtmqG(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVl8xT()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VV7xtz(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCA1Ob.VVB7G7(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVCF95()
  state = self.VVPF4I()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFtmqG(self["myPlayMsg"], "#0000ff00")
  else     : FFtmqG(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVHnzd(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFzMYS(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCTKa3.VV2yL9(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCVNso.VVXbMs(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCSMOW()
   tpTxt, satTxt = tp.VVkCYN(refCode)
   self.satInfo_TP = tpTxt + "  " + FFEK4e(satTxt, VVZoWi)
  evName = evNameNext = ""
  evLst = CCgL5j.VVhFfu(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFXVji(info, iServiceInformation.sVideoWidth) or -1
   h = FFXVji(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFXVji(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCVNso.VVAm6o(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VV2yL9(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFTaUe(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFTaUe(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFTaUe(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVgLvJ(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVHnzd()
  FFNcCVSeries = FFHhMF(decodedUrl)
  VVGIDM = []
  if not "VVzKlk" in globals() and not "VVoMrG" in globals():
   VVGIDM.append((VVZoWi + "IPTV Menu", "iptv"))
   VVGIDM.append(VVVgKz)
  if isIptv and not "&end=" in decodedUrl and not FFNcCVSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCDrYI.VV5ztg(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVGIDM.append((VVZoWi + "Catchup Programs", "catchup" ))
    VVGIDM.append(VVVgKz)
  if refCode:
   c = VVWEO1
   VVGIDM.append((c + "Stop Current Service"  , "stop"  ))
   VVGIDM.append((c + "Restart Current Service" , "restart"  ))
   VVGIDM.append(FFzUJ4("Replay with ..." , "replayWith", not isDvb, c))
   VVGIDM.append(VVVgKz)
  if FFNcCVSeries:
   VVGIDM.append((VVZoWi + "File Size (on server)", "fileSize" ))
   VVGIDM.append(VVVgKz)
  if self.enableDownloadMenu:
   c = VVZoWi
   addSep = False
   if isIptv and FFNcCVSeries:
    VVGIDM.append((c + "Start Download"  , "dload_cur" ))
    VVGIDM.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CC6EZK.VVtCyi():
    VVGIDM.append((VVZoWi + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVGIDM.append(VVVgKz)
  fPath, fDir, fName = CCLyBs.VVK93s(self)
  if fPath:
   c = VVUrbH
   if not "VVljBx" in globals():
    VVGIDM.append((c + "Open path in File Manager", "VVsqD5"))
   VVGIDM.append((c + "Add to Bouquet"             , "VV0QtF" ))
   VVGIDM.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVr21W"  ))
   VVGIDM.append(VVVgKz)
  elif isFtp:
   VVGIDM.append((VVfZXg + "Add FTP Media to Bouquet"     , "VVAYz9"))
  if isDvb:
   VVGIDM.append((VVZoWi + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVGIDM.append((VVfZXg + "Start Subtitle", "VVVYnw"))
   VVGIDM.append(VVVgKz)
  if CFG.playerPos.getValue() : VVGIDM.append(("Move Bar to Bottom" , "botm"))
  else      : VVGIDM.append(("Move Bar to Top" , "top" ))
  VVGIDM.append(("Help", "help"))
  FFzctu(self, self.VVvUmw, VVGIDM=VVGIDM, width=600, title="Options")
 def VVvUmw(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVpnd7()
   elif item == "stop"     : self.VVCp48(0)
   elif item == "restart"    : self.VVCp48(1)
   elif item == "replayWith"   : self.VVwbeg()
   elif item == "fileSize"    : FFVCur(self, BF(CCVNso.VVOsO7, self), title="Checking Server")
   elif item == "dload_cur"   : CC6EZK.VVq7M9(self)
   elif item == "addToDload"   : CC6EZK.VVsILg(self)
   elif item == "dload_stat"   : CC6EZK.VVAVyn(self)
   elif item == "VVsqD5" : self.close("close_openInFileMan")
   elif item == "VV0QtF" : self.VV0QtF()
   elif item == "VVAYz9" : self.VVAYz9()
   elif item == "VVVYnw"  : self.VV97cT()
   elif item == "VVr21W"  : self.VVr21W()
   elif item == "botm"     : self.VVY1mD(0)
   elif item == "top"     : self.VVY1mD(1)
   elif item == "sigMon"    : self.VVYTHD()
   elif item == "help"     : FFog0j(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCTKa3.VVvj2H = None
 def VVCp48(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVfNwF()
   elif typ == 1:
    self.VVRaMc("Restarting Service ...")
    FFEuIr(BF(self.VVgCgR, serv))
 def VVgCgR(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  if "&end=" in decodedUrl: BF(self.VVShyQ, True)
  else     : self.session.nav.playService(serv)
 def VVwbeg(self):
  FFzctu(self, self.VVcDks, VVGIDM=CCDrYI.VVuv4i(), width=650, title="Select Player", VVXsDY="#11220000", VVEEoV="#11220000")
 def VVcDks(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFYdkV(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVRaMc("No active service !")
 def VV0QtF(self):
  fPath, fDir, fName = CCLyBs.VVK93s(self)
  if fPath: picker = CCpURW(self, self, "Add Current Movie to a Bouquet", BF(self.VVKsYv, [fPath]))
  else : FFqgHP(self, "Path not found !", 1500)
 def VVKsYv(self, pathLst):
  return CCpURW.VV1K5k(pathLst)
 def VVAYz9(self):
  picker = CCpURW(self, self, "Add FTP Media to Bouquet", self.VVvJMS)
 def VVvJMS(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  return CCpURW.VV1K5k([origUrl], rType=refCode.split(":", 1)[0])
 def VVr21W(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCTKa3.VV2yL9(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVRaMc(txt, highlight=ok)
 def VVY1mD(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFSKZx(CFG.playerPos, pos)
 def VVYTHD(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCVNso.VVXbMs(serv)
   if isDvb: self.close("close_sig")
   else : self.VVRaMc("No Signal for Current Service")
 def VV97cT(self):
  self.session.openWithCallback(self.VVBjn6, BF(CCA1Ob))
 def VVZfLo(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVHnzd()
   if posTxt and durTxt: self.VV97cT()
   else    : self.VVRaMc("No duration Info. !")
 def VVBjn6(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVHUsZ(True)
  elif reason == "subtZapDn" : self.VVHUsZ(False)
  elif reason == "pause"  : self.VVYmK7()
  elif reason == "audio"  : self.VVf0F7(True)
  elif reason == "subtitle" : self.VVf0F7(False)
  elif reason == "rewind"     : self.VVdkr8()
  elif reason == "forward" : self.VVcMcX()
  elif reason == "rewindDm" : self.VVdkr8()
  elif reason == "forwardDm" : self.VVcMcX()
  else      : txt = reason
  if txt:
   FFqgHP(self, txt, 2000)
 def VVLgni(self):
  if self.isManualSeek:
   self.VVijPi()
   self.VV7xtz(self.manualSeekPts)
  elif self.shown:
   if CCA1Ob.VVGqV6(self): self.VV97cT()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVijPi()
  else    : self.close()
 def VVWwZ6(self):
  FFNmLy(self, fncMode=CCVNso.VVIsVS)
 def VVYmK7(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVRaMc("Toggling Play/Pause ...")
 def VVijPi(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVsMr3(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCTKa3.VV2yL9(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVsyv7()
   else:
    self.manualSeekSec += direc * self.VVsyv7()
    self.manualSeekSec = FFEApF(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFOn9F(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFTaUe(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVrW5A(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVCW5Z())
   FFSKZx(CFG.playerJumpMin, self.jumpMinutes)
  self.VVRaMc("Changed Seek Time to : %d%s" % (val, self.VVmGeZ()))
 def VVCW5Z(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVmGeZ())
 def VVmGeZ(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVq2Ni(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVsyv7(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVl8xT(self):
  if "VVtKHB" in globals():
   global VVtKHB
   if VVtKHB:
    VVtKHB = VVtKHB[1:-1]
    if len(VVtKHB) == 3: VVtKHB = ""
    else     : return VVtKHB
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVwizV(self):
  cList = self.VVLBLu()
  if cList:
   VVGIDM = []
   for pts, what in cList:
    txt = FFTaUe(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVGIDM.append((txt, pts))
   FFzctu(self, self.VVR1Ia, VVGIDM=VVGIDM, title="Cut List")
  else:
   self.VVRaMc("No Cut-List for this channel !")
 def VVR1Ia(self, item=None):
  if item:
   self.VV7xtz(item)
 def VVLBLu(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVcMcX(self) : self.VVHSu2(1)
 def VVdkr8(self) : self.VVHSu2(-1)
 def VVHSu2(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCTKa3.VV2yL9(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVsyv7() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVq2Ni())
    self.VVRaMc(txt)
  except:
   self.VVRaMc("Cannot jump")
 def VV7xtz(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVRaMc("Changing Time ...")
 def VVCF95(self):
  self.VVCp48(1)
  self.VVRaMc("Replaying ...")
  self.VVijPi()
 def VVfiEL(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCTKa3.VV2yL9(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVRaMc("Jumping to end ...")
  except:
   pass
 def VVPF4I(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVHUsZ(self, isUp):
  if self.enableZapping:
   self.VVRaMc("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVijPi()
   if self.iptvTableParams:
    FFEuIr(BF(self.VVSgP4, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
    if "/timeshift/" in decodedUrl:
     self.VVRaMc("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VV4aZJ()
  else:
   self.VVRaMc("Zap Disabled !")
 def VV4aZJ(self):
  self.lastPlayPos = 0
  self.VVfNwF()
  self.VVShyQ()
 def VVSgP4(self, isUp):
  CCDrYI_inatance, VVxL8T, mode = self.iptvTableParams
  if isUp : VVxL8T.VVdFDv()
  else : VVxL8T.VVWfUV()
  colList = VVxL8T.VVoYvr()
  if mode == "localIptv":
   chName, chUrl = CCDrYI_inatance.VVbBVE(VVxL8T, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCDrYI_inatance.VVKO59(VVxL8T, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCDrYI_inatance.VV1c1s(mode, VVxL8T, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCDrYI_inatance.VVKBl1(mode, VVxL8T, colList)
  else:
   self.VVRaMc("Cannot Zap")
   return
  FFnh1l(self, chUrl, VV5sxe=False)
  self.VV4aZJ()
 def VVShyQ(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCTKa3.VV2yL9(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
   if not self.VVgJOf(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVRaMc("Refreshing Portal")
   FFEuIr(self.VVePJX)
  except:
   pass
 def VVePJX(self):
  self.restoreLastPlayPos = self.VVIo5U()
 def VVpnd7(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
  if not decodedUrl or FFHhMF(decodedUrl):
   self.VVRaMc("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCDrYI.VV5ztg(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVRaMc("Reading Program List ...")
   ok_fnc = BF(self.VVoeFQ, refCode, chName, streamId, uHost, uUser, uPass)
   FFEuIr(BF(CCDrYI.VVn1Th, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVRaMc("Cannot process this channel")
 def VVoeFQ(self, refCode, chName, streamId, uHost, uUser, uPass, VVxL8T, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVxL8T.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVRaMc("Changing Program ...")
   FFEuIr(BF(self.VVnVBa, chUrl))
  else:
   self.VVRaMc("Incorrect Timestamp !")
 def VVnVBa(self, chUrl):
  FFnh1l(self, chUrl, VV5sxe=False)
  self.lastPlayPos = 0
  self.VVfNwF()
 def VVf0F7(self, isAudio):
  try:
   VVIeIC = InfoBar.instance
   if VVIeIC:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVIeIC)
    else  : self.session.open(SubtitleSelection, VVIeIC)
  except:
   pass
 @staticmethod
 def VVZCs9(session, mode=None):
  if   mode == "close_sig"   : FFtC9K(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCDrYI)
  elif mode == "close_openInFileMan" : session.open(CCLyBs, gotoMovie=True)
 @staticmethod
 def VV3qn6(session, **kwargs):
  session.openWithCallback(BF(CCTKa3.VVZCs9, session), CCTKa3, **kwargs)
class CC3lLL(Screen):
 def __init__(self, session, title="", VVcsne="Continue?", VVfGaL=True, VVi1cr=False):
  self.skin, self.skinParam = FFLEcJ(VVRmp1, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVcsne = VVcsne
  self.VVi1cr = VVi1cr
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVfGaL : VVGIDM = [no , yes]
  else   : VVGIDM = [yes, no ]
  FFCOTe(self, title, VVGIDM=VVGIDM, addLabel=True)
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok" : self.VVLgni ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVcsne)
  if self.VVi1cr:
   self["myLabel"].instance.setHAlign(0)
  self.VVcHQY()
  FFyjr3(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFiwu1(self["myMenu"])
  FFfD2k(self, self["myMenu"])
 def VVLgni(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVcHQY(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CC1wtj(Screen):
 def __init__(self, session, title="", VVGIDM=None, width=1000, height=850, VVNdFV=30, barText="", minRows=1, VV4v1i=None, VVx6LK=None, VVw5pZ=None, VVV7uB=None, VVQaYB=None, VVacc0=None, VVglmG=False, VVoaDe=False, VVfIfT=None, VVF69c=True, VVXsDY="#22003344", VVEEoV="#22002233"):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, width, height, 50, 40, 30, VVXsDY, VVEEoV, VVNdFV, barHeight=40, topRightBtns=3 if VVx6LK else 0)
  self.session   = session
  self.VVGIDM   = VVGIDM
  self.barText   = barText
  self.minRows   = minRows
  self.VV4v1i   = VV4v1i
  self.VVx6LK   = VVx6LK
  self.VVw5pZ   = VVw5pZ
  self.VVV7uB  = VVV7uB
  self.VVQaYB  = ("Delete File", BF(self.VVL5Gi, VVfIfT)) if not VVfIfT is None else VVQaYB
  self.VVacc0   = VVacc0
  self.VVglmG  = VVglmG
  self.VVoaDe  = VVoaDe
  self.Title    = title
  FFCOTe(self, title, VVGIDM=VVGIDM)
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok"  : self.VVLgni    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVqplw   ,
   "red"  : self.VVeXRt   ,
   "green"  : self.VV2Qge   ,
   "yellow" : self.VV3aKZ   ,
   "blue"  : self.VVes9k   ,
   "pageUp" : self.VV8aEH ,
   "chanUp" : self.VV8aEH ,
   "pageDown" : self.VVO5rt  ,
   "chanDown" : self.VVO5rt  ,
   "0"   : BF(self.VVOYyG, 0) ,
   "1"   : BF(self.VVOYyG, 1) ,
   "2"   : BF(self.VVOYyG, 2) ,
   "3"   : BF(self.VVOYyG, 3) ,
   "4"   : BF(self.VVOYyG, 4) ,
   "5"   : BF(self.VVOYyG, 5) ,
   "6"   : BF(self.VVOYyG, 6) ,
   "7"   : BF(self.VVOYyG, 7) ,
   "8"   : BF(self.VVOYyG, 8) ,
   "9"   : BF(self.VVOYyG, 9)
  }, -1)
  if VVF69c:
   FFIfkB(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFyjr3(self["myMenu"])
  FFkK1B(self, minRows=self.minRows)
  FF9NP9(self)
  self.VVPXlc(self["keyRed"]  , self.VVw5pZ )
  self.VVPXlc(self["keyGreen"] , self.VVV7uB )
  self.VVPXlc(self["keyYellow"] , self.VVQaYB )
  self.VVPXlc(self["keyBlue"]  , self.VVacc0 )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFOuQx(self)
 def VVPXlc(self, btnObj, btnFnc):
  if btnFnc:
   FFbJWj(btnObj, btnFnc[0])
 def VVfPxm(self, fnc=None):
  self.VVV7uB = fnc
  if fnc : self.VVPXlc(self["keyGreen"], self.VVV7uB)
  else : self["keyGreen"].hide()
 def VVOYyG(self, digit):
  digit = str(digit)
  VVGIDM = self["myMenu"].list
  for ndx, item in enumerate(VVGIDM):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFLKj3(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVwPcs(ndx)
     self.VVLgni()
     break
 def VVLgni(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VV4v1i:
    self.VV4v1i((self, txt, ref, ndx))
   else:
    if self.VVglmG: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVqplw(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVx6LK and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVx6LK(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVeXRt(self)  : self.VVTg5V(self.VVw5pZ)
 def VV2Qge(self) : self.VVTg5V(self.VVV7uB)
 def VV3aKZ(self) : self.VVTg5V(self.VVQaYB)
 def VVes9k(self) : self.VVTg5V(self.VVacc0)
 def VVTg5V(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVoaDe:
    self.cancel()
 def VVk2T1(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVGIDM = self["myMenu"].list
  VVGIDM.pop(ndx)
  if len(VVGIDM) > 0: self["myMenu"].setList(VVGIDM)
  else    : self.close()
 def VVL5Gi(self, basePath, menuObj, fName):
  FFP9Be(self, BF(self.VVTu1j, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVTu1j(self, path):
  FFbUco(path)
  if fileExists(path) : FFqgHP(self, "Not deleted", 1000)
  else    : self.VVk2T1()
 def VVqrwk(self, VVGIDM):
  if len(VVGIDM) > 0:
   newList = []
   for item in VVGIDM:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFkK1B(self, minRows=self.minRows)
  else:
   self.close("")
 def VVzCFO(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFkK1B(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVjqBz(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVwPcs(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVMxLG(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVwPcs(ndx)
    break
 def VVJSVD(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVwPcs(ndx)
    break
 def VV8aEH(self) : self["myMenu"].moveToIndex(0)
 def VVO5rt(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CC5cb1(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVZAt4=None, VVyaAW=None, VVbiLs=None, VVNdFV=26, isEditor=False, addSort=True, VVehvv=False, VVCR7e=0, picParams=None, VVRWOd=None, VVMOfU=None, menuButtonFnc=None, VVr0hN=None, VVoXaA=None, VVMCbu=None, VVUm5B=None, VVHQPO=None, VV6aZX=None, VVU1op=None, VV30ES=-1, VV4wMI=0, searchCol=0, lastFindConfigObj=None, VVXsDY="#22003344", VVEEoV="#22002233", VV63bc="#00dddddd", VVasam="#11002233", VVPYhe=None, VVhaQs="#11111111", borderWidth=1, VVAXDQ="#0a555555", VVMuBE="#0affffff", VVilD4="#11552200", VV5aeh="#0055ff55", VV5aehRev="#0000bbff"):
  self.skin, self.skinParam = FFLEcJ(VV17Kk, width, height, 50, 10, vMargin, VVXsDY, VVEEoV, 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFCOTe(self, title)
  self.Title     = title
  self.header     = header
  self.VVZAt4     = VVZAt4
  self.totalCols    = len(VVZAt4[0])
  self.VVCR7e   = VVCR7e
  self.picParams    = picParams
  self.lastSortModeIsReverese = False
  self.VVehvv   = VVehvv
  self.VVfydj   = 0.01
  self.VVZ25C   = 0.02
  self.VVXTDT = 0.03
  self.VVeUbK  = 1
  self.VVbiLs = VVbiLs
  self.colWidthPixels   = []
  self.VVRWOd   = VVRWOd
  self.OKButtonObj   = None
  self.VVMOfU   = VVMOfU
  self.VVr0hN   = VVr0hN
  self.VVoXaA   = VVoXaA
  self.VVMCbu  = VVMCbu
  self.VVUm5B   = VVUm5B
  self.VVHQPO    = VVHQPO
  self.VV6aZX   = VV6aZX
  self.tableRefreshCB   = None
  self.VVU1op  = VVU1op
  self.menuButtonFnc   = menuButtonFnc
  self.VV30ES    = VV30ES
  self.VV4wMI   = VV4wMI
  self.searchCol    = searchCol
  self.VVyaAW    = VVyaAW
  self.keyPressed    = -1
  self.VVNdFV    = FF0QHc(VVNdFV)
  self.isEditor    = isEditor
  self.addSort    = addSort
  self.VVN35T    = FFn3C3(self.VVNdFV, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVXsDY    = VVXsDY
  self.VVEEoV      = VVEEoV
  self.VV63bc    = FFRpt5(VV63bc)
  self.VVasam    = FFRpt5(VVasam)
  self.VVPYhe    = VVPYhe
  self.VVhaQs    = FFRpt5(VVhaQs)
  self.borderWidth   = borderWidth
  self.VVAXDQ   = FFRpt5(VVAXDQ)
  self.VVMuBE    = FFRpt5(VVMuBE)
  self.VVilD4    = FFRpt5(VVilD4)
  self.VV5aeh   = FFRpt5(VV5aeh)
  self.VV5aehRev  = FFRpt5(VV5aehRev)
  self.VV1dHJ  = False
  self.selectedItems   = 0
  self.VVcQEH   = FFRpt5("#06542132")
  self.onMultiSelFnc   = None
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VV4wMI:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VV4wMI == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok"  : self.VV6BK0  ,
   "red"  : self.VVq9Q6  ,
   "green"  : self.VVUWby ,
   "yellow" : self.VVEuvo ,
   "blue"  : self.VVuVGH  ,
   "menu"  : self.VVjZyg ,
   "info"  : self.VVwAG3  ,
   "cancel" : self.VV2uRj  ,
   "up"  : self.VVWfUV    ,
   "down"  : self.VVdFDv  ,
   "left"  : self.VV1nfR   ,
   "right"  : self.VVEwYo  ,
   "next"  : self.VV8k3O  ,
   "last"  : self.VVjJSl  ,
   "home"  : self.VV8WVx  ,
   "pageUp" : self.VV8WVx  ,
   "chanUp" : self.VV8WVx  ,
   "end"  : self.VVxQfy  ,
   "pageDown" : self.VVxQfy  ,
   "chanDown" : self.VVxQfy
  }, -1)
  FFIfkB(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FF9NP9(self)
  try:
   self.VVwYBw()
  except Exception as e:
   FFryuM(self, str(e), title=self.Title)
   self.close(None)
 def VVwYBw(self):
  FFOuQx(self)
  self.VVPXlc(self.VVr0hN , self["keyRed"])
  self.VVPXlc(self.VVoXaA , self["keyGreen"])
  self.VVPXlc(self.VVMCbu, self["keyYellow"])
  self.VVPXlc(self.VVUm5B , self["keyBlue"])
  if self.VVRWOd:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVRWOd[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVRWOd[0])
    FF21Xy(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVN35T)
  self["myTableH"].l.setFont(0, gFont(VVoGd5, self.VVNdFV))
  self["myTable"].l.setItemHeight(self.VVN35T)
  self["myTable"].l.setFont(0, gFont(VVoGd5, self.VVNdFV))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVN35T)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVN35T))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVN35T)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVN35T
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVN35T * len(self.VVZAt4) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVbiLs:
   self.VVbiLs = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVbiLs)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVyaAW:
   self.VVyaAW = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVyaAW
   self.VVyaAW = []
   for item in tmpList:
    self.VVyaAW.append(item | RT_VALIGN_CENTER)
  self.VVWcxg()
  if self.VVHQPO:
   self.VVHQPO(self)
 def VVPXlc(self, btnFnc, btn):
  if btnFnc : FFbJWj(btn, btnFnc[0])
  else  : FFbJWj(btn, "")
 def VVQGA9(self, waitTxt):
  FFVCur(self, self.VVWcxg, title=waitTxt)
 def VVWcxg(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VV5aehRev if self.lastSortModeIsReverese else self.VV5aeh
    self["myTableH"].setList([self.VVR8wC(0, self.header, self.VVMuBE, self.VVilD4, self.VVMuBE, self.VVilD4, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVZAt4):
    self["myTable"].list.append(self.VVR8wC(c, row, self.VV63bc, self.VVasam, self.VVPYhe, self.VVhaQs, None))
   self.VVZAt4 = []
   self["myTable"].setList(self["myTable"].list)
   if self.VV30ES > -1:
    self["myTable"].moveToIndex(self.VV30ES )
   self.VVkTQy()
   if self.VV4wMI:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVN35T * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFChi8(self, width, newH)
   if self.VV6aZX:
    self.VVTg5V(self.VV6aZX, None)
   if self.tableRefreshCB:
    self.VVTg5V(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFryuM(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVR8wC(self, keyIndex, columns, VV63bc, VVasam, VVPYhe, VVhaQs, VV5aeh):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VV5aeh and ndx == self.VVCR7e : textColor = VV5aeh
   else           : textColor = VV63bc
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFRpt5(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVasam = c
    entry = span.group(3)
   if not self.isEditor and self.VVyaAW[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVN35T)
           , font   = 0
           , flags   = self.VVyaAW[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVasam
           , color_sel  = VVPYhe or textColor
           , backcolor_sel = VVhaQs
           , border_width = self.borderWidth
           , border_color = self.VVAXDQ
           ))
   posX += self.colWidthPixels[ndx]
  if not VV5aeh and self.picParams:
   picPosCol, picFnc, pathCol = self.picParams
   if   picFnc : png = picFnc(columns)
   elif pathCol: png = columns[pathCol].strip()
   else  : png = ""
   if png.startswith("/"):
    try:
     pngX = sum(self.colWidthPixels[:picPosCol])
     row.append(CC5cb1.VVecW5(pngX+2, picPosCol+2, self.colWidthPixels[picPosCol]-4, self.VVN35T-4, LoadPixmap(png)))
    except:
     pass
  return row
 def VVwAG3(self):
  rowData = self.VVxXQn()
  if rowData:
   title, txt, colList = rowData
   if self.VVMOfU:
    fnc  = self.VVMOfU[1]
    params = self.VVMOfU[2]
    fnc(self, title, txt, colList)
   else:
    FFDLqC(self, txt, title)
 def VV6BK0(self):
  if   self.VV1dHJ : self.VVbEbW(self.VVsf2R(), mode=2)
  elif self.VVRWOd  : self.VVTg5V(self.VVRWOd, None)
  else      : self.VVwAG3()
 def VVq9Q6(self) : self.VVTg5V(self.VVr0hN , self["keyRed"])
 def VVUWby(self) : self.VVTg5V(self.VVoXaA , self["keyGreen"])
 def VVEuvo(self): self.VVTg5V(self.VVMCbu , self["keyYellow"])
 def VVuVGH(self) : self.VVTg5V(self.VVUm5B , self["keyBlue"])
 def VVTg5V(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFqgHP(self, buttonFnc[3])
    FFEuIr(BF(self.VVdNnd, buttonFnc))
   else:
    self.VVdNnd(buttonFnc)
 def VVdNnd(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVxXQn()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVbEbW(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][10] == self.VVcQEH
   if mode == 0 or (mode == 2 and isSelected):
    bg = self.VVasam
    if isSelected:
     self.selectedItems -= 1
   else:
    bg = self.VVcQEH
    if not isSelected:
     self.selectedItems += 1
   for col in range(1, len(row)):
    cols = list(row[col])
    if cols[0] == 0:
     cols[10] = bg
    row[col] = tuple(cols)
   self["myTable"].l.invalidate()
   if self.VVsf2R() < len(self["myTable"].list) - 1 : self.VVdFDv()
   else              : self.VVkTQy()
   if self.onMultiSelFnc:
    self.onMultiSelFnc()
 def VVxQIA(self)  : FFVCur(self, BF(self.VV6E1N, True ), title="Selecting all ..."  )
 def VVojoM(self) : FFVCur(self, BF(self.VV6E1N, False), title="Unselecting all ...")
 def VV6E1N(self, isSel=True):
  if isSel:
   bg = self.VVcQEH
   self.selectedItems = len(self["myTable"].list)
   self.VVAi8G(True)
  else:
   bg = self.VVasam
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][10] == self.VVcQEH
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     cols = list(self["myTable"].list[ndx][col])
     if cols[0] == 0:
      cols[10] = bg
     self["myTable"].list[ndx][col] = tuple(cols)
  self["myTable"].l.invalidate()
 def VVxXQn(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVbiLs[i] > 1 or self.VVbiLs[i] == self.VVfydj or self.VVbiLs[i] == self.VVXTDT:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VV2uRj(self):
  self["myTable"].onSelectionChanged = []
  if self.VVU1op : self.VVU1op(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVPL4Q(self):
  return self["myTitle"].getText().strip()
 def VVoaZ9(self):
  return self.header
 def VVL9w5(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVKlb6(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFtmqG(self["myBar"], color)
 def VV61sj(self, txt):
  FFqgHP(self, txt)
 def VVurur(self, txt, Time=1000):
  FFqgHP(self, txt, Time)
 def VVvtnk(self): self["keyGreen"].show()
 def VVbwhi(self): self["keyGreen"].hide()
 def VVLeTy(self): return self["keyGreen"].visible
 def VVKZ4j(self):
  FFqgHP(self)
 def VVa866(self, fnc, callFnc=False):
  self["myTable"].onSelectionChanged.append(fnc)
  if callFnc:
   fnc()
 def VV9lfv(self):
  return len(self["myTable"].list)
 def VVsf2R(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVERJ7(self):
  return len(self["myTable"].list)
 def VVAi8G(self, isOn):
  self.VV1dHJ = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVUm5B: self["keyBlue"].hide()
   if self.VVRWOd and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.VVXsDY
   self["keyMenu"].show()
   if self.VVUm5B: self["keyBlue"].show()
   if self.VVRWOd and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVRWOd[0])
   self.VVojoM()
  FF21Xy(self["myTitle"], color)
  FF21Xy(self["myBar"]  , color)
 def VVTpqf(self):
  return self.VV1dHJ
 def VVwKPO(self):
  return self.selectedItems
 def VV6yqc(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVkTQy()
 def VV5Iil(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VV53A5(self):
  txt  = "Total Rows\t: %d\n\n" % self.VV9lfv()
  txt += FFu7MN("Total Unique Items", VVnviq)
  for i in range(self.totalCols):
   if self.VVbiLs[i - 1] > 1 or self.VVbiLs[i - 1] == self.VVfydj or self.VVbiLs[i - 1] == self.VVXTDT:
    name, tot = self.VV5Iil(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFDLqC(self, txt)
 def VVJ5dP(self, colNum, isStrip=True):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip() if isStrip else item[colNum + 1][7]
  else : return None
 def VVoYvr(self):
  return self.VVtH1g(self["myTable"].l.getCurrentSelectionIndex())
 def VVtH1g(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVlCGq(self, newList, newTitle="", VVj0IZMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVL9w5(newTitle)
  if newList:
   self.VVZAt4 = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVehvv and self.VVCR7e == 0:
    isNum = True
   else:
    for cols in self.VVZAt4:
     if not FFQCNW(cols[self.VVCR7e]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVZAt4.sort(key=lambda x: int(x[self.VVCR7e])  , reverse=self.lastSortModeIsReverese)
    else : self.VVZAt4.sort(key=lambda x: x[self.VVCR7e].lower() , reverse=self.lastSortModeIsReverese)
   if VVj0IZMsg : self.VVQGA9("Refreshing ...")
   else   : self.VVWcxg()
  else:
   FFryuM(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVyCTE(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVR8wC(self.VVERJ7(), row, self.VV63bc, self.VVasam, self.VVPYhe, self.VVhaQs, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVxQfy()
 def VVO7yn(self):
  self["myTable"].list.pop(self.VVsf2R())
  self["myTable"].l.setList(self["myTable"].list)
 def VVkQYa(self, data):
  ndx = self.VVsf2R()
  newRow = self.VVR8wC(ndx, data, self.VV63bc, self.VVasam, self.VVPYhe, self.VVhaQs, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVkTQy()
   return True
  else:
   return False
 def VVxFpI(self, tDict):
  ndx = self.VVsf2R()
  for colNum, val in tDict.items():
   txt = str(val)
   if not self.isEditor and self.VVyaAW[ndx] & LEFT:
    txt = " %s " % txt.strip()
   col = list(self["myTable"].list[ndx][colNum + 1])
   col[7] = txt
   self["myTable"].list[ndx][colNum + 1] = tuple(col)
  self.VVkfJ6()
 def VVk6Jb(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVR8wC(ndx, data, self.VV63bc, self.VVasam, self.VVPYhe, self.VVhaQs, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVkfJ6()
 def VVkfJ6(self):
  self["myTable"].l.setList(self["myTable"].list)
  self.VVkTQy()
 def VVncK2(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVvq3F(self, colNum, textToFind, VVO6nE=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVkTQy()
    break
  else:
   if VVO6nE:
    FFqgHP(self, "Not found", 1000)
 def VVWFhX(self, colDict, VVO6nE=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVkTQy()
    return
  if VVO6nE:
   FFqgHP(self, "Not found", 1000)
  return False
 def VVeNp0(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVgls0(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFQCNW(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVgXLx(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVcQEH:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVesQT(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][10] == self.VVcQEH:
     return ndx
  return -1
 def VVo1A6(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVcQEH:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVeezj(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][10] == self.VVcQEH : return True
  else        : return False
 def VVWcfU(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVjZyg(self):
  if self.menuButtonFnc:
   self.VVdNnd(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VV4wMI:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVsf2R()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVGIDM1, VV8S8F = CCgoW8.VVD8QJ(self, False, False)
  VVGIDM = []
  VVGIDM.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVGIDM.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVGIDM.append(("Find ...\t\t%s" % (FFEK4e(txt, VVN1ah) if txt else ""), "findNew"   ))
  VVGIDM.append(itemOf(bool(VVGIDM1)    , "Find (from Filter) ..."   , "filter"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Table Statistcis"             , "tableStat"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((FFEK4e("Export Table to .html"     , VVnviq) , "VVKxZh" ))
  VVGIDM.append((FFEK4e("Export Table to .csv"     , VVnviq) , "VVbSMl" ))
  VVGIDM.append((FFEK4e("Export Table to .txt (Tab Separated)", VVnviq) , "VVXcOd" ))
  if self.addSort:
   sList = []
   tot  = 0
   for i in range(self.totalCols):
    if self.VVbiLs[i] > 1 or self.VVbiLs[i] == self.VVZ25C:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     sList.append(("Sort by : %s" % name, i))
   if tot:
    VVGIDM.append(VVVgKz)
    if tot == 1 : VVGIDM.append(("Sort", sList[0][1]))
    else  : VVGIDM += sList
  VVacc0 = ("Keys Help", self.FFfJU2Help)
  FFzctu(self, self.VVphiE, VVGIDM=VVGIDM, title=self.VVPL4Q(), VVacc0=VVacc0)
 def VVphiE(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVO3dq()
   elif item == "findPrev"  : self.VVO3dq(isPrev=True)
   elif item == "findNew"  : self.VVhGtX()
   elif item == "filter"  : self.VV0smT()
   elif item == "tableStat" : self.VV53A5()
   elif item == "VVKxZh": FFVCur(self, self.VVKxZh, title=title)
   elif item == "VVbSMl" : FFVCur(self, self.VVbSMl , title=title)
   elif item == "VVXcOd" : FFVCur(self, self.VVXcOd , title=title)
   else:
    if self.VVCR7e == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVCR7e, self.lastSortModeIsReverese = item, False
    if self.VVehvv and self.VVCR7e == 0 or self.VVgls0(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVWcxg(onlyHeader=True)
 def FFfJU2Help(self, VVXrLB, path):
  FFog0j(self, "_help_table", "Table (Keys Help)")
 def VVWfUV(self):
  self["myTable"].up()
  self.VVkTQy()
 def VVdFDv(self):
  self["myTable"].down()
  self.VVkTQy()
 def VV1nfR(self):
  self["myTable"].pageUp()
  self.VVkTQy()
 def VVEwYo(self):
  self["myTable"].pageDown()
  self.VVkTQy()
 def VV8WVx(self):
  self["myTable"].moveToIndex(0)
  self.VVkTQy()
 def VVxQfy(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVkTQy()
 def VVyaYN(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVkTQy()
 def VV8k3O(self):
  if self.lastFindConfigObj.getValue():
   if self.VVsf2R() == len(self["myTable"].list) - 1 : FFqgHP(self, "End reached", 1000)
   else              : self.VVO3dq()
  else:
   FFqgHP(self, 'Set "Find" in Menu', 1500)
 def VVjJSl(self):
  if self.lastFindConfigObj.getValue():
   if self.VVsf2R() == 0 : FFqgHP(self, "Top reached", 1000)
   else       : self.VVO3dq(isPrev=True)
  else:
   FFqgHP(self, 'Set "Find" in Menu', 1500)
 def VVMMQR(self, txt):
  FFSKZx(self.lastFindConfigObj, txt)
 def VVhGtX(self):
  FF9Fmo(self, self.VVr6LT, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVr6LT(self, VVxkNp):
  if not VVxkNp is None:
   txt = VVxkNp.strip()
   self.VVMMQR(txt)
   if VVxkNp: self.VVO3dq(reset=True)
   else  : FFqgHP(self, "Nothing to find !", 1500)
 def VV0smT(self):
  VVGIDM, VV8S8F = CCgoW8.VVD8QJ(self, False, False)
  VVQaYB = ("Edit Filter", BF(self.VVqkDg, VV8S8F))
  if VVGIDM : FFzctu(self, self.VVJGmm, VVGIDM=VVGIDM, VVQaYB=VVQaYB, title="Find from Filter")
  else  : FFqgHP(self, "Filter Error !", 1500)
 def VVJGmm(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVMMQR(txt)
    self.VVO3dq(reset=True)
   else:
    FFqgHP(self, "No entry !", 1500)
 def VVqkDg(self, VV8S8F, selectionObj, sel):
  if fileExists(VV8S8F) : CC8yF1(self, VV8S8F, VViIM0=None)
  else       : FFAhcl(self, VV8S8F)
  selectionObj.cancel()
 def VVO3dq(self, reset=False, isPrev=False):
  curRow = self.VVsf2R()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCgoW8.VV15EP(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVyaYN(i)
      break
    elif any(x in line for x in tupl):
     self.VVyaYN(i)
     break
   else:
    FFqgHP(self, "Not found", 1000)
  else:
   FFqgHP(self, "Check your query", 1500)
 def VVXcOd(self):
  expFile = self.VVCgLT() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVGvtf()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVtH1g(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVbiLs[ndx] > self.VVeUbK or self.VVbiLs[ndx] == self.VVXTDT:
      col = self.VVABC9(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVtXyY(expFile)
 def VVbSMl(self):
  expFile = self.VVCgLT() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVGvtf()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVtH1g(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVbiLs[ndx] > self.VVeUbK or self.VVbiLs[ndx] == self.VVXTDT:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVABC9(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVtXyY(expFile)
 def VVKxZh(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVPL4Q(), PLUGIN_NAME, VVQBlh)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVPL4Q()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVGvtf()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVbiLs:
   colgroup += '   <colgroup>'
   for w in self.VVbiLs:
    if w > self.VVeUbK or w == self.VVXTDT:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVCgLT() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVtH1g(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVbiLs[ndx] > self.VVeUbK or self.VVbiLs[ndx] == self.VVXTDT:
      col = self.VVABC9(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVtXyY(expFile)
 def VVGvtf(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVbiLs[ndx] > self.VVeUbK or self.VVbiLs[ndx] == self.VVXTDT:
     newRow.append(col.strip())
  return newRow
 def VVABC9(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFLKj3(col)
 def VVCgLT(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVPL4Q())
  fileName = fileName.replace("__", "_")
  path  = FF80Mz(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFOa0m()
  return expFile
 def VVtXyY(self, expFile):
  FF6mzu(self, "File exported to:\n\n%s" % expFile, title=self.VVPL4Q())
 def VVkTQy(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   totCols = len(row)
   if row[totCols - 1][0] == 0 : lastCol = totCols - 1
   else      : lastCol = totCols - 2
   x, y, w, h = row[lastCol][1:5]
   self["myTable"].l.setSelectionClip(eRect(0, 0, int(x + w), int(h)), True)
 @staticmethod
 def VVecW5(x, y, w, h, png, bg=None, bgSel=None):
  typ = eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST
  if VVQkC2: return (typ, x, y, w, h, png, bg, bgSel, VVQkC2 | CENTER)
  else   : return (typ, x, y, w, h, png, bg, bgSel)
class CCpTQt():
 def __init__(self, pixmapObj, picPath, VVasam=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVasam  = VVasam or "#2200002a"
 def VVLZUI(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVVkhx)
    except:
     self.picLoad.PictureData.get().append(self.VVVkhx)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVasam])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVVkhx(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVHmn7(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVseWq(pixmapObj, path, VVasam=None):
  cl = CCpTQt(pixmapObj, path, VVasam)
  ok = cl.VVLZUI()
  if ok: return cl
  else : return None
class CCceHb(Screen):
 def __init__(self, session, VVpjN9, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFiI6j()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFLEcJ(VV0ab3, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVpjN9 = VVpjN9
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFCOTe(self)
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVtIM8  ,
   "up" : BF(self.VVmlPN, -1),
   "down" : BF(self.VVmlPN,  1),
   "left" : BF(self.VVmlPN, -1),
   "right" : BF(self.VVmlPN,  1)
  }, -1)
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FF9NP9(self)
  self.VVAFaL()
  self.picViewer = CCpTQt.VVseWq(self["myPic"], self.VVpjN9)
  if self.picViewer:
   if self.showGrnMsg:
    FFqgHP(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFryuM(self, "Cannot view picture file:\n\n%s" % self.VVpjN9)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVHmn7()
  if self.cbFnc  : self.cbFnc(self.VVpjN9)
 def VVmlPN(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVpjN9 = FF80Mz(os.path.dirname(self.VVpjN9)) + fName
    self.picViewer.picPath = self.VVpjN9
    self.picViewer.VVLZUI()
    self.VVAFaL()
 def VVtIM8(self):
  txt = "%s:\n  %s" % (FFEK4e("Path", VVfZXg), self.fakePath or self.VVpjN9)
  size, sizeTxt, resTxt, form, mode = CC0Hnq.VVdhVw(self.VVpjN9)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFEK4e("Properties", VVfZXg)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFDLqC(self, txt, title="File Information")
 def VVAFaL(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVpjN9)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVLNYv(SELF, VVpjN9, **kwargs):
  SELF.session.open(CCceHb, VVpjN9, **kwargs)
class CCJggj(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFLEcJ(VV3ZOe, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFCOTe(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.onExit)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFyakl("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVHWO2(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCJggj.VVWAub, SELF), CCJggj, mviFile)
 @staticmethod
 def VVWAub(SELF, reason=None):
  if reason == -1: FFryuM(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CC6wkq(Screen, ConfigListScreen):
 VVBYy3 = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFLEcJ(VVXu3w, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFCOTe(self, title=self.Title)
  FFbJWj(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VV1SVO()
  self.onShown.append(self.VVg3Fx)
 def VV1SVO(self):
  kList = {
    "ok" : self.VVLgni   ,
    "green" : self.VVGoxW ,
    "menu" : self.VVlTCv ,
    "cancel": self.VVL8gi ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVyFRr, 0)
     kList["chanDown"] = BF(self["config"].VVyFRr, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(VV6Kiq, kList, -1)
  else:
   self["actions"] = ActionMap(VV6Kiq, kList, -1)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FF9NP9(self)
  FFyjr3(self["config"])
  FFkK1B(self, self["config"])
  FFOuQx(self)
  self["config"].onSelectionChanged.append(self.VVtQu2)
  self.VVtQu2()
  FF21Xy(self["keyRed"], "#11000000")
  self["keyRed"].show()
 def VVtQu2(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVLgni(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVAvgn()
   elif item == CFG.MovieDownloadPath   : self.VVnzRF(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVDeiT()
   elif isinstance(item, ConfigDirectory) : self.VVk0r1(item)
   else         : CC6wkq.VVwW0V(self, item, title)
 @staticmethod
 def VVwW0V(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)   : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelectionNumber): lst = [(x, x) for x in confItem.choices.choices]
   elif isinstance(confItem, ConfigSelection)  : lst = confItem.choices.choices
   else           : return
  curNdx = defNdx = -1
  VVGIDM = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVN1ah + txt
    elif val == confItem.default: defNdx, txt = ndx, VVWhci + txt
   VVGIDM.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVacc0  = ("Current", BF(CC6wkq.VVbkWq, curNdx))
  VVQaYB = ("Default", BF(CC6wkq.VVbkWq, defNdx))
  VVXrLB = FFzctu(SELF, BF(CC6wkq.VVDq2S, confItem, cbFnc, isSave), VVGIDM=VVGIDM, width=1200, VVQaYB=VVQaYB, VVacc0=VVacc0, title=title, VVXsDY="#33221111", VVEEoV="#33110011")
  VVXrLB.VVwPcs(curNdx)
 @staticmethod
 def VVDq2S(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFSKZx(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VVbkWq(ndx, selectionObj, item):
  selectionObj.VVwPcs(ndx)
 @staticmethod
 def VVY0Bi(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVnzRF(self, item, title):
  tot = CC6EZK.VV7f7z()
  if tot : FFryuM(self, "Cannot change while downloading.", title=title)
  else : self.VVk0r1(item)
 def VVDeiT(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCme0M.VVpgRE(self, "", curEnc)
  if lst:
   VVQaYB = ("Default", self.VV2pn7)
   VVacc0  = ("Current", self.VVcaFO)
   VVXrLB = FFzctu(self, self.VVRe6P, title="Select Priority Encoding", VVGIDM=lst, width=1000, height=1000, VVacc0=VVacc0, VVQaYB=VVQaYB, VVXsDY="#22220000", VVEEoV="#22220000", VVglmG=True)
   VVXrLB.VVMxLG(curEnc)
 def VVRe6P(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VV2pn7(self, VVXrLB, item): VVXrLB.VVMxLG(VVnekd)
 def VVcaFO(self, VVXrLB, item): VVXrLB.VVMxLG(CFG.subtDefaultEnc.getValue())
 def VVAvgn(self):
  VVGIDM = []
  VVGIDM.append(("Auto Find" , "auto"))
  VVGIDM.append(("Custom Path" , "cust"))
  FFzctu(self, self.VV8wp5, VVGIDM=VVGIDM, title="IPTV Hosts Files Path")
 def VV8wp5(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VV2tYb)
   elif item == "cust":
    VVnhmb = self.VV5iCT()
    if VVnhmb : self.VV3ud1(VVnhmb)
    else  : self.session.openWithCallback(self.VVMzjf, BF(CCLyBs, mode=CCLyBs.VVSgRQ, VV8MX1="/"))
 def VV3ud1(self, VVnhmb):
  VVU1op = self.VVBQ6n
  VVr0hN = ("Remove"  , self.VV7cAt , [])
  VVMCbu = ("Add "  , self.VVcDhR, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVyaAW  = (LEFT   , LEFT  )
  FFfJU2(self, None, title="IPTV Hosts Search Paths", header=header, VVZAt4=VVnhmb, width=1200, height=700, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=26, VVU1op=VVU1op, VVr0hN=VVr0hN, VVMCbu=VVMCbu
    , VVXsDY="#22220000", VVEEoV="#22110000", VVasam="#22110011", VVhaQs="#11223025", VVAXDQ="#0a333333", VVilD4="#11400040")
 def VVBQ6n(self, VVxL8T):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVabsf)
  VVxL8T.cancel()
 def VVMzjf(self, path):
  if path:
   FFSKZx(CFG.iptvHostsDirs, FF80Mz(path.strip()))
   VVnhmb = self.VV5iCT()
   if VVnhmb : self.VV3ud1(VVnhmb)
   else  : FFqgHP(self, "Cannot add dir", 1500)
 def VVW6wv(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VV2tYb:
   return []
  return lst
 def VV5iCT(self):
  lst = self.VVW6wv()
  if lst:
   VVnhmb = []
   for Dir in lst:
    VVnhmb.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVnhmb.sort(key=lambda x: x[0].lower())
   return VVnhmb
  else:
   return []
 def VVcDhR(self, VVxL8T, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VV6ym5, VVxL8T)
         , BF(CCLyBs, mode=CCLyBs.VVSgRQ, VV8MX1=sDir))
 def VV6ym5(self, VVxL8T, path):
  if path:
   path = FF80Mz(path.strip())
   if self.VVftf8(VVxL8T, path):
    FFqgHP(VVxL8T, "Already added", 1500)
   else:
    lst = self.VVW6wv()
    lst.append(path)
    FFSKZx(CFG.iptvHostsDirs, ",".join(lst))
    VVnhmb = self.VV5iCT()
    VVxL8T.VVlCGq(VVnhmb, tableRefreshCB=BF(self.VVfSiR, path))
 def VVfSiR(self, path, VVxL8T, title, txt, colList):
  self.VVftf8(VVxL8T, path)
 def VVftf8(self, VVxL8T, path):
  for ndx, row in enumerate(VVxL8T.VVWcfU()):
   if row[0].strip() == path.strip():
    VVxL8T.VVyaYN(ndx)
    return True
  return False
 def VV7cAt(self, VVxL8T, title, txt, colList):
  path = colList[0]
  FFP9Be(self, BF(self.VVVr72, VVxL8T), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVVr72(self, VVxL8T):
  row = VVxL8T.VVoYvr()
  path, rem = row[0], row[1]
  VVnhmb = []
  lst = []
  for ndx, row in enumerate(VVxL8T.VVWcfU()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVnhmb.append((tPath, tRem))
  if len(VVnhmb) > 0:
   FFSKZx(CFG.iptvHostsDirs, ",".join(lst))
   VVxL8T.VVlCGq(VVnhmb)
   FFqgHP(VVxL8T, "Deleted", 1500)
  else:
   FFSKZx(CFG.iptvHostsMode, VV2tYb)
   FFSKZx(CFG.iptvHostsDirs, "")
   VVxL8T.cancel()
   FFEuIr(BF(FFqgHP, self, "Changed to Auto-Find", 1500))
 def VVk0r1(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVp1aN, configObj)
         , BF(CCLyBs, mode=CCLyBs.VVSgRQ, VV8MX1=sDir))
 def VVp1aN(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVL8gi(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFP9Be(self, self.VVGoxW, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVGoxW(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVffR7()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVlTCv(self):
  VVGIDM = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVGIDM.append((txt    , "VV9LKe"   ))
  else        : VVGIDM.append((txt    ,       ))
  VVGIDM.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Reset %s Settings" % PLUGIN_NAME      , "VVMmTS"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Backup %s Settings" % PLUGIN_NAME      , "VVTyOM"  ))
  VVGIDM.append(("Restore %s Settings" % PLUGIN_NAME     , "VVTUBH"  ))
  if fileExists(VV90k3 + CC6wkq.VVBYy3):
   VVGIDM.append(VVVgKz)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVGIDM.append(('%s Checking for Update' % txt1     , txt2     ))
   VVGIDM.append(("Reinstall %s" % PLUGIN_NAME      , "VV9T7Z"  ))
   VVGIDM.append(("Update %s" % PLUGIN_NAME      , "VVXX4o"   ))
  FFzctu(self, self.VVLQQH, VVGIDM=VVGIDM, title="Config. Options")
 def VVLQQH(self, item=None):
  if item:
   if   item == "VV9LKe"  : FFP9Be(self, self.VV9LKe , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCvWVD)
   elif item == "VVMmTS"  : FFP9Be(self, BF(self.VVMmTS, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVTyOM" : self.VVTyOM()
   elif item == "VVTUBH" : FFVCur(self, self.VVTUBH, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFSKZx(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFSKZx(CFG.checkForUpdateAtStartup, False)
   elif item == "VV9T7Z" : FFVCur(self, BF(self.VVn1oU, True ), "Checking Server ...")
   elif item == "VVXX4o"  : FFVCur(self, BF(self.VVn1oU, False), "Checking Server ...")
 def VVTyOM(self):
  path = "%sajpanel_settings_%s" % (VV90k3, FFOa0m())
  FFqj03("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVWgjG, path))
  FF6mzu(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVTUBH(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FF30Q2("find / %s -iname '%s*' | grep %s" % (FFRGqa(1), name, name))
  if files:
   err = CCLyBs.VVkPRf(files)
   if err:
    FFP9Be(self, BF(self.VVSj3N, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVGIDM = []
    for line in files:
     VVGIDM.append((line, line))
    FFzctu(self, BF(self.VVwduS, title), title=title, VVGIDM=VVGIDM, width=1200, VVfIfT="")
  else:
   FFryuM(self, "No settings files found !", title=title)
 def VVSj3N(self, title, path=None):
  sDir = "/"
  for path in (VV90k3, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVwduS, title), BF(CCLyBs, patternMode="ajpSet", VV8MX1=sDir))
 def VVwduS(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FF5p6q(path)
    self.VVMmTS()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVffR7()
    FFZ1EG()
    FFqgHP(self, "Apllied", 1500, isGrn=True)
   else:
    FFAhcl(self, path, title=title)
 def VV9LKe(self):
  newPath = FF80Mz(VV90k3)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVffR7()
 @staticmethod
 def VVn071():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVMmTS(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVffR7()
  if exit:
   self.close()
 def VVffR7(self):
  configfile.save()
  global VV90k3
  VV90k3 = CFG.backupPath.getValue()
  FFbNeh()
 def VVn1oU(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CC6wkq.VVpV62()
  if   err    : FFryuM(self, err, title)
  elif isHigher or force : FFP9Be(self, BF(FFVCur, self, BF(self.VVlAHW, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FF6mzu(self, FFEK4e("No update required.", VVijSd) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVlAHW(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FF0tZq() == "dpkg" else "ipk")
  path, err = FFgHO0(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFM6zB(VV80Ym, path)
   else : cmd = FFM6zB(VVCu09, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FF8jLK(self, cmd, title=title)
   else:
    FFRzIz(self, title=title)
  else:
   FFryuM(self, err, title=title)
 @staticmethod
 def VVpV62():
  span = iSearch(r"v*(\d.\d.\d)", VVQBlh, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VV90k3 + CC6wkq.VVBYy3
  if fileExists(path):
   span = iSearch(r"(http.+)", FF3unD(path), IGNORECASE)
   if span : url = FF80Mz(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFgHO0(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FF3unD(path).strip().replace(" ", "")
   FFbUco(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCvWVD(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFLEcJ(VVnl3C, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVLsEj
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFCOTe(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVU1ni("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVU1ni("\c00888888", i) + sp + "GREY\n"
   txt += self.VVU1ni("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVU1ni("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVU1ni("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVU1ni("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVU1ni("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVU1ni("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVU1ni("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVU1ni("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVU1ni("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVU1ni("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok" : self.VVLgni ,
   "green" : self.VVLgni ,
   "left" : self.VVzWM3 ,
   "right" : self.VVAwZj ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  self.VVING1()
 def VVLgni(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFP9Be(self, self.VV6JV0, "Change to : %s" % txt, title=self.Title)
 def VV6JV0(self):
  FFSKZx(CFG.mixedColorScheme, self.cursorPos)
  global VVLsEj
  VVLsEj = self.cursorPos
  self.VVYX7i()
  self.close()
 def VVzWM3(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVING1()
 def VVAwZj(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVING1()
 def VVING1(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVU1ni(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VVhK0P(color):
  if VVWhci: return "\\" + color
  else    : return ""
 @staticmethod
 def VVYX7i():
  global VVJvHF, VVhSN2, VVWABP, VVWEO1, VVnviq, VVUVBT, VVEqIl, VV8sRc, VVijSd, VVUrbH, VVWhci, VVfZXg, VVN1ah, VVZoWi, VViTDo, VVoR97
  VVoR97   = CCvWVD.VVU1ni("\c00FFFFFF", VVLsEj)
  VVhSN2    = CCvWVD.VVU1ni("\c00888888", VVLsEj)
  VVJvHF  = CCvWVD.VVU1ni("\c005A5A5A", VVLsEj)
  VV8sRc    = CCvWVD.VVU1ni("\c00FF0000", VVLsEj)
  VVWABP   = CCvWVD.VVU1ni("\c00FF5000", VVLsEj)
  VVWEO1   = CCvWVD.VVU1ni("\c00FFBB66", VVLsEj)
  VVWhci   = CCvWVD.VVU1ni("\c00FFFF00", VVLsEj)
  VVfZXg = CCvWVD.VVU1ni("\c00FFFFAA", VVLsEj)
  VVijSd   = CCvWVD.VVU1ni("\c0000FF00", VVLsEj)
  VVUrbH  = CCvWVD.VVU1ni("\c00AAFFAA", VVLsEj)
  VVEqIl    = CCvWVD.VVU1ni("\c000066FF", VVLsEj)
  VVN1ah    = CCvWVD.VVU1ni("\c0000FFFF", VVLsEj)
  VVZoWi  = CCvWVD.VVU1ni("\c00AAFFFF", VVLsEj)  #
  VViTDo   = CCvWVD.VVU1ni("\c00FA55E7", VVLsEj)
  VVnviq    = CCvWVD.VVU1ni("\c00FF8F5F", VVLsEj)
  VVUVBT  = CCvWVD.VVU1ni("\c00FFC0C0", VVLsEj)
CCvWVD.VVYX7i()
class CCeghF(Screen):
 def __init__(self, session, path, VV76sq):
  self.skin, self.skinParam = FFLEcJ(VVzHVs, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVNDnh   = path
  self.VVFjeF   = ""
  self.VVyqph   = ""
  self.VV76sq    = VV76sq
  self.VVIImr    = ""
  self.VVFFy6  = ""
  self.VVetFL    = False
  self.VV5reJ  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVj4vL  = "enigma2-plugin-extensions-"
  self.VV4wix  = "enigma2-plugin-systemplugins-"
  self.VVrj2V = "enigma2-"
  self.VVeEPX  = 0
  self.VVkD73  = 1
  self.VVtWL9  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV0aRO = "DEBIAN"
  else        : self.VV0aRO = "CONTROL"
  self.controlPath = self.Path + self.VV0aRO
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VV76sq:
   self.packageExt  = ".deb"
   self.VVasam  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVasam  = "#11001020"
  FFCOTe(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFbJWj(self["keyRed"] , "Create")
  FFbJWj(self["keyGreen"] , "Post Install")
  FFbJWj(self["keyYellow"], "Installation Path")
  FFbJWj(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(VV6Kiq,
  {
   "red"   : self.VVAEPn  ,
   "green"   : self.VVhB2X ,
   "yellow"  : self.VVFnmB  ,
   "blue"   : self.VVTBEt  ,
   "cancel"  : self.VVWTDp
  }, -1)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFOuQx(self)
  if self.VVasam:
   FF21Xy(self["myBody"], self.VVasam)
   FF21Xy(self["myLabel"], self.VVasam)
  self.VVlpWG(True)
  self.VVxENo(True)
 def VVxENo(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VV3ewZ()
  if isFirstTime:
   if   package.startswith(self.VVj4vL) : self.VVNDnh = VVRjMt + self.VVIImr + "/"
   elif package.startswith(self.VV4wix) : self.VVNDnh = VV0bR7 + self.VVIImr + "/"
   else            : self.VVNDnh = self.Path
  if self.VVetFL : myColor = VVnviq
  else    : myColor = VVoR97
  txt  = ""
  txt += "Source Path\t: %s\n" % FFEK4e(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFEK4e(self.VVNDnh, VVWhci)
  if self.VVyqph : txt += "Package File\t: %s\n" % FFEK4e(self.VVyqph, VVhSN2)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFEK4e("Check Control File fields : %s" % errTxt, VVWABP)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFEK4e("Restart GUI", VVnviq)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFEK4e("Reboot Device", VVnviq)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFEK4e("Post Install", VVijSd), act)
  if not errTxt and VVWABP in controlInfo:
   txt += "Warning\t: %s\n" % FFEK4e("Errors in control file may affect the result package.", VVWABP)
  txt += "\nControl File\t: %s\n" % FFEK4e(self.controlFile, VVhSN2)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVhB2X(self):
  if self["keyGreen"].getVisible():
   VVGIDM = []
   VVGIDM.append(("No Action"    , "noAction"  ))
   VVGIDM.append(("Restart GUI"    , "VVf9w3"  ))
   VVGIDM.append(("Reboot Device"   , "rebootDev"  ))
   FFzctu(self, self.VVL5Y7, title="Package Installation Option (after completing installation)", VVGIDM=VVGIDM)
 def VVL5Y7(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVf9w3"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVlpWG(False)
   self.VVxENo()
 def VVFnmB(self):
  rootPath = FFEK4e("/%s/" % self.VVIImr, VVfZXg)
  VVGIDM = []
  VVGIDM.append(("Current Path"        , "toCurrent"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Extension Path"       , "toExtensions" ))
  VVGIDM.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVGIDM.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFzctu(self, self.VVb3Lj, title="Installation Path", VVGIDM=VVGIDM)
 def VVb3Lj(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVK8d6(FFlkVY(self.Path, True))
   elif item == "toExtensions"  : self.VVK8d6(VVRjMt)
   elif item == "toSystemPlugins" : self.VVK8d6(VV0bR7)
   elif item == "toRootPath"  : self.VVK8d6("/")
   elif item == "toRoot"   : self.VVK8d6("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVm5qM, BF(CCLyBs, mode=CCLyBs.VVSgRQ, VV8MX1=VV90k3))
 def VVm5qM(self, path):
  if len(path) > 0:
   self.VVK8d6(path)
 def VVK8d6(self, parent, withPackageName=True):
  if withPackageName : self.VVNDnh = parent + self.VVIImr + "/"
  else    : self.VVNDnh = "/"
  mode = self.VVxb3L()
  FFyakl("sed -i '/Package/c\Package: %s' %s" % (self.VVRXJV(mode), self.controlFile))
  self.VVxENo()
 def VVTBEt(self):
  if fileExists(self.controlFile):
   lines = FF5p6q(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FF9Fmo(self, self.VVHdBI, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFryuM(self, "Version not found or incorrectly set !")
  else:
   FFAhcl(self, self.controlFile)
 def VVHdBI(self, VVxkNp):
  if VVxkNp:
   version, color = self.VVMagD(VVxkNp, False)
   if color == VVN1ah:
    FFyakl("sed -i '/Version:/c\Version: %s' %s" % (VVxkNp, self.controlFile))
    self.VVxENo()
   else:
    FFryuM(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVWTDp(self):
  if self.newControlPath:
   if self.VVetFL:
    self.VV6gQJ()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFEK4e(self.newControlPath, VVhSN2)
    txt += FFEK4e("Do you want to keep these files ?", VVWhci)
    FFP9Be(self, self.close, txt, callBack_No=self.VV6gQJ, title="Create Package", VVi1cr=True)
  else:
   self.close()
 def VV6gQJ(self):
  FFyakl("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVRXJV(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVFFy6
  if package.startswith(self.VVrj2V):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVrj2V, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVkD73 : prefix = self.VVj4vL
  elif mode == self.VVtWL9 : prefix = self.VV4wix
  return (prefix + name).lower()
 def VVxb3L(self):
  if   self.VVNDnh.startswith(VVRjMt) : return self.VVkD73
  elif self.VVNDnh.startswith(VV0bR7) : return self.VVtWL9
  else            : return self.VVeEPX
 def VVlpWG(self, isFirstTime):
  self.VVIImr   = FFlW1I(self.Path)
  self.VVIImr   = "_".join(self.VVIImr.split())
  self.VVFFy6 = self.VVIImr.lower()
  self.VVetFL = self.VVFFy6 == VVfn31.lower()
  if self.VVetFL and self.VVFFy6.endswith(VVfn31.lower()):
   self.VVFFy6 += "el"
  if self.VVetFL : self.VVFjeF = VV90k3
  else    : self.VVFjeF = CFG.packageOutputPath.getValue()
  self.VVFjeF = FF80Mz(self.VVFjeF)
  if not pathExists(self.controlPath):
   FFyakl("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVxb3L()
  if fileExists(self.controlFile):
   lines = FF5p6q(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVetFL : version, descripton, maintainer = VVQBlh , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVIImr , self.VVIImr
   txt = ""
   txt += "Package: %s\n"  % self.VVRXJV(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVetFL : t = PLUGIN_NAME
  else    : t = self.VVIImr
  self.VVyCpE(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVyCpE(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVetFL : self.VVyCpE(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVQBlh))
  else    : self.VVyCpE(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVIImr)
  if isFirstTime and not mode == self.VVeEPX:
   self.postInstAcion = 1
  txt = self.VVo6CI(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FF3unD(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVo6CI(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFyakl("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVyCpE(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVo6CI(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VV3ewZ(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FF5p6q(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFEK4e(line, VVWABP)
     elif not line.startswith(" ")    : line = FFEK4e(line, VVWABP)
     else          : line = FFEK4e(line, VVN1ah)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVN1ah
   else   : color = VVWABP
   descr = FFEK4e(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVWABP
     elif line.startswith((" ", "\t")) : color = VVWABP
     elif line.startswith("#")   : color = VVhSN2
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVMagD(val, True)
      elif key == "Version"  : version, color = self.VVMagD(val, False)
      elif key == "Maintainer" : maint  , color = val, VVN1ah
      elif key == "Architecture" : arch  , color = val, VVN1ah
      else:
       color = VVN1ah
      if not key == "OE" and not key.istitle():
       color = VVWABP
     else:
      color = VVnviq
     txt += FFEK4e(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVyqph = self.VVFjeF + packageName
   self.VV5reJ = True
   errTxt = ""
  else:
   self.VVyqph  = ""
   self.VV5reJ = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVMagD(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVN1ah
  else          : return val, VVWABP
 def VVAEPn(self):
  if not self.VV5reJ:
   FFryuM(self, "Please fix Control File errors first.")
   return
  if self.VV76sq: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFlkVY(self.VVNDnh, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVIImr
  symlinkTo  = FFYRE0(self.Path)
  dataDir   = self.VVNDnh.rstrip("/")
  removePorjDir = FFbUbn("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFbUbn("rm -f '%s'" % self.VVyqph)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFjDBy()
  if self.VV76sq:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFhXFT("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVetFL:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVNDnh == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV0aRO)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVyqph, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVyqph
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVyqph, FFpC0R(result  , VVijSd))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVNDnh, FFpC0R(instPath, VVN1ah))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFpC0R(failed, VVWABP))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF8jLK(self, cmd)
class CCpURW():
 VVYn3V  = "666"
 VVxj1O   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVXrLB   = None
  self.VVgVVt()
 def VVgVVt(self):
  VVGIDM = CCpURW.VVAnRt()
  if VVGIDM:
   VVQaYB = ("Create New", self.VV6Mqh)
   self.VVXrLB = FFzctu(self.SELF, self.VVTARy, VVGIDM=VVGIDM, title=self.Title, VVQaYB=VVQaYB, VVglmG=True, VVXsDY="#22222233", VVEEoV="#22222233")
  else:
   self.VV6Mqh()
 def VVTARy(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVh6LN(bName, bRef)
  else:
   CCpURW.VVyq4r(self)
 def VV6Mqh(self, selectionObj=None, item=None):
  FF9Fmo(self.SELF, BF(self.VVJsNy), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVJsNy(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVXrLB:
     self.VVXrLB.cancel()
    self.VVh6LN(bName, "")
   else:
    FFqgHP(self.VVXrLB, "Incorrect Bouquet Name !", 2000)
    CCpURW.VVyq4r(self)
 def VVh6LN(self, bName, bRef):
  FFVCur(self.waitMsgSELF, BF(self.VVTyjx, bName, bRef), title="Adding Services ...")
 def VVTyjx(self, bName, bRef):
  CCpURW.VVAuig(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVyq4r(classObj):
  del classObj
 @staticmethod
 def VVAuig(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFryuM(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVWgjG + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFAhcl(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCpURW.VVRe5b(bRef)
   bPath = VVWgjG + bFile
  else:
   fName = CCDrYI.VVOPP7(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVWgjG + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVWgjG + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FFjfx9(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FFjfx9(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CC9p8T.VVH8Sz()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFyakl("cp -f '%s' '%s'" % (poster, picon))
       FFyakl(CCVNso.VVCQjh(picon))
       break
  FFWH63()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFDLqC(SELF, txt, title=title)
 @staticmethod
 def VVdhjw(bName):
  mode = CCT3R4.VVDdyC(default=-1)
  modeTxt = "tv" if mode == 0 else "radio"
  fName = CCDrYI.VVOPP7(bName)
  bFile = "userbouquet.%s.%s" % (fName, modeTxt)
  num   = 0
  while fileExists(VVWgjG + bFile):
   num += 1
   bFile = "userbouquet.%s_%d.%s" % (fName, num, modeTxt)
  with open(VVWgjG + bFile, "w") as f:
   f.write("#NAME %s\n" % bName)
  mainBFile = "%sbouquets.%s" % (VVWgjG, modeTxt)
  if fileExists(mainBFile):
   FFjfx9(mainBFile)
   with open(mainBFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
 @staticmethod
 def VV1gGz(ref, bName):
  bFile = CCpURW.VVRe5b(ref)
  ok = False
  if bFile:
   bFile = VVWgjG + bFile
   if fileExists(bFile):
    lines = FF5p6q(bFile, keepends=True)
    with open(bFile, "w") as f:
     for line in lines:
      if line.startswith("#NAME "):
       f.write("#NAME %s\n" % bName)
       ok = True
      else:
       f.write(line)
  return ok
 @staticmethod
 def VVAnRt(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVGIDM = []
  if mode in (0, 2): VVGIDM.extend(CCpURW.VVuE78(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVGIDM.extend(CCpURW.VVuE78(1, showTitle, prefix, onlyIptv))
  return VVGIDM
 @staticmethod
 def VVuE78(mode, showTitle, prefix, onlyIptv):
  VVGIDM = []
  lst = CCpURW.VVShqs(mode)
  if onlyIptv:
   lst = CCpURW.VV264C(lst)
  if lst:
   if showTitle:
    VVGIDM.append(FFBeKw("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVGIDM.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVGIDM.append((item[0], item[1].toString()))
  return VVGIDM
 @staticmethod
 def VV264C(lst):
  fLst = CCDrYI.VVSss8(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVV8Dp():
  lst = CCpURW.VVShqs(0)
  lst.extend(CCpURW.VVShqs(1))
  return lst
 @staticmethod
 def VVShqs(mode=0):
  bList = []
  VVIeIC = InfoBar.instance
  VVTb5M = VVIeIC and VVIeIC.servicelist
  if VVTb5M:
   curMode = VVTb5M.mode
   CCpURW.VVWgbk(VVTb5M, mode)
   bList.extend(VVTb5M.getBouquetList() or [])
   CCpURW.VVWgbk(VVTb5M, curMode)
  return bList
 @staticmethod
 def VVWgbk(VVTb5M, mode):
  if not mode == VVTb5M.mode:
   if   mode == 0: VVTb5M.setModeTv()
   elif mode == 1: VVTb5M.setModeRadio()
 @staticmethod
 def VVwWAm(isAll=True, onlyMain=False):
  bLst = []
  inst = InfoBar.instance
  if inst:
   csel = inst.servicelist
   if csel:
    root = csel.bouquet_root
    VVXX0J = eServiceCenter.getInstance()
    if onlyMain:
     info = VVXX0J.info(root)
     if info:
      bLst.append((info.getName(root), root.toString()))
    else:
     list = VVXX0J and VVXX0J.list(root)
     if list:
      while True:
       s = list.getNext()
       if not s.valid():
        break
       if isAll or (s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible):
        info = VVXX0J.info(s)
        if info:
         bLst.append((info.getName(s), s.toString()))
  return bLst
 @staticmethod
 def VVRe5b(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VV73S4(ref, dstFile):
  dstFile = VVWgjG + dstFile
  if fileExists(dstFile):
   FFjfx9(dstFile)
   bLine = ""
   srcFile = CCpURW.VVRe5b(ref)
   if srcFile:
    span = iSearch(r"\.(.+)\.(tv|radio)", srcFile, IGNORECASE)
    if span:
     fName, fType = span.group(1), span.group(2)
     newName = "userSubBouquet.%s.%s" % (fName, fType)
     num = 0
     while fileExists(VVWgjG + newName):
      num += 1
      newName = "userSubBouquet.%s_%d.%s" % (fName, num, fType)
     subFile = VVWgjG + newName
     FFyakl("cp -f '%s%s' '%s'" % (VVWgjG, srcFile, subFile))
     if fileExists(subFile):
      bLine = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % newName
   else:
    bLine = ref
   if bLine:
    if fileExists(dstFile):
     with open(dstFile, "a") as f:
      f.write("#SERVICE %s\n" % bLine)
     return True
  return False
 @staticmethod
 def VVa98V():
  try:
   fName = CCpURW.VVRe5b(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVWgjG, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVTAtr():
  path = CCpURW.VVa98V()
  if path:
   txt = FF3unD(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VV4QEE():
  return FFsac0(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VVzbQv():
  lst = []
  for b in CCpURW.VVV8Dp():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVWgjG + CCpURW.VVRe5b(bRef)
   if fileExists(path):
    lines = FF5p6q(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVfLhR(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVzNZv(SID="", stripRType=False):
  if SID : patt = CCpURW.VVfLhR(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCpURW.VVV8Dp():
   for service in FFsac0(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVxszo():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCpURW.VVV8Dp():
   for service in FFsac0(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVwEdd(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VV1K5k(pathLst, rType=""):
  refLst = CCpURW.VVzNZv(CCpURW.VVYn3V, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCpURW.VVwEdd(rType, CCpURW.VVYn3V, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCLyBs(Screen):
 VVGziO   = 0
 VVEYzK  = 1
 VVSgRQ  = 2
 VVbuGK = 3
 VVyjoX    = 20
 VVfnRu   = 0
 VVkJjp   = 1
 VVDCfg   = 2
 def __init__(self, session, VV8MX1="/", mode=VVGziO, VVWkA9="Select", width=1400, height=920, VVNdFV=30, VVXsDY="#22001111", VVEEoV="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFLEcJ(VVhMIG, width, height, 30, 40, 20, VVXsDY, VVEEoV, VVNdFV, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVXsDY   = VVXsDY
  self.VVEEoV    = VVEEoV
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFCOTe(self)
  FFbJWj(self["keyRed"] , "Exit")
  FFbJWj(self["keyYellow"], "More Options")
  FFbJWj(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVWkA9 = VVWkA9
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VV83Fj = None
  if patternMode:
   self.mode = self.VVbuGK
   if   patternMode == "srt"  : VV83Fj = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VV83Fj = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VV83Fj = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VV83Fj = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VV83Fj = ("^.*\.(%s)$" % "|".join(CC8QHN.VVzGQB()["mov"]), IGNORECASE)
   else       : VV83Fj = None
  if self.mode in (self.VVSgRQ, self.VVbuGK):
   FFbJWj(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VV5yDB, self.VV8MX1 = True , FFlkVY(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VV5yDB, self.VV8MX1 = True , CCLyBs.VVK93s(self)[1] or "/"
  elif self.mode == self.VVGziO  : VV5yDB, self.VV8MX1 = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVSgRQ : VV5yDB, self.VV8MX1 = False, VV8MX1
  elif self.mode == self.VVbuGK : VV5yDB, self.VV8MX1 = True , VV8MX1
  else           : VV5yDB, self.VV8MX1 = True , VV8MX1
  self.VV8MX1 = FF80Mz(self.VV8MX1)
  self["myMenu"] = CC8QHN(  directory   = None
         , VV83Fj = VV83Fj
         , VV5yDB   = VV5yDB
         , VV3tSk = True
         , VVbqMa = True
         , VVZa0q   = self.skinParam["width"]
         , VVNdFV   = self.skinParam["bodyFontSize"]
         , VVN35T  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(VV6Kiq,
  {
   "ok" : self.VVLgni    ,
   "red" : self.VVWtFT   ,
   "green" : self.VVLRlU,
   "yellow": self.VVouq6  ,
   "blue" : self.VVLq9z ,
   "menu" : self.VVntzw  ,
   "info" : self.VVEaAV  ,
   "cancel": self.VV9S2L    ,
   "pageUp": self.VVHJ59   ,
   "chanUp": self.VVHJ59
  }, -1)
  FFIfkB(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV9fur)
  global VVljBx
  VVljBx = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VVGziO:
   FFAUiv("VVljBx")
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV9fur)
  FF9NP9(self)
  FFyjr3(self["myMenu"], bg=self.cursorBG)
  FFOuQx(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVSgRQ, self.VVbuGK):
   FFbJWj(self["keyGreen"], self.VVWkA9)
   self.VVANuv(self.VVkJjp)
  self.VV9fur()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVdGQ3(self.VV8MX1) > self.bigDirSize: FFVCur(self, self.VVBeuY, title="Changing directory...")
  else              : self.VVBeuY()
 def VVBeuY(self):
  if self.jumpToFile : self.VVzTtm(self.jumpToFile)
  elif self.gotoMovie : self.VV8c8g(chDir=False)
  else    : self["myMenu"].VVORbb(self.VV8MX1)
 def VVyaYN(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVGYOL(self):
  FFVCur(self, self.VVTs8w, title="Refreshing list ...")
 def VVTs8w(self):
  isSel = self["myMenu"].VVnBFv()
  if not isSel:
   self.VVMUA0(False)
  FFaHKF()
 def VVT8OT(self, saved):
  if saved: self.VVGYOL()
 def VVdGQ3(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVLgni(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVzUWq()
   if ok : self["keyBlue"].setText(self.VVxmNi())
   else : FFqgHP(self, "Cannot select item", 500)
  elif self["myMenu"].VVB2UF(): self.VVFwrG()
  else       : self.VVCjqg()
 def VVHJ59(self):
  if self.multiSelectState:
   FFqgHP(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVxy3e():
    self.VVFwrG()
 def VVFwrG(self, isDirUp=False):
  if self["myMenu"].VVB2UF():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VVZs2T(self.VVCgwv())
   if self.VVdGQ3(path) > self.bigDirSize : FFVCur(self, self.VV0Bhx, title="Changing directory...")
   else           : self.VV0Bhx()
 def VV0Bhx(self):
  self["myMenu"].descent()
  self.VV9fur()
 def VV9S2L(self):
  if   self.multiSelectState     : self.VVMUA0(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVWtFT()
  else          : self.VVHJ59()
 def VVWtFT(self):
  if not FFaIEn(self):
   self.close("")
 def VVLRlU(self):
  path = self.VVZs2T(self.VVCgwv())
  if self.mode == self.VVSgRQ:
   self.close(path)
  elif self.mode == self.VVbuGK:
   if os.path.isfile(path) : self.close(path)
   else     : FFqgHP(self, "Cannot access this file", 1000)
 def VVEaAV(self):
  FFVCur(self, self.VVHjmv, title="Calculating size ...")
 def VVHjmv(self):
  path = self.VVZs2T(self.VVCgwv())
  param = self.VV1rKA(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFunaH("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCLyBs.VV7JZt(path)
     freeSize = CCLyBs.VVJ8wE(path)
     size = totSize - freeSize
     totSize  = CCLyBs.VVM24t(totSize)
     freeSize = CCLyBs.VVM24t(freeSize)
    else:
     size = FFg1qW(path)
   usedSize = CCLyBs.VVM24t(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFEK4e(pathTxt, VVnviq) + "\n"
   if slBroken : fileTime = self.VVmn4L(path)
   else  : fileTime = self.VVErwq(path)
   def VVu8zC(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVu8zC("Path"    , pathTxt)
   txt += VVu8zC("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVu8zC("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVu8zC("Total Size"   , "%s" % totSize)
    txt += VVu8zC("Used Size"   , "%s" % usedSize)
    txt += VVu8zC("Free Size"   , "%s" % freeSize)
   else:
    txt += VVu8zC("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVu8zC("Owner"    , owner)
   txt += VVu8zC("Group"    , group)
   txt += VVu8zC("Perm. (User)"  , permUser)
   txt += VVu8zC("Perm. (Group)"  , permGroup)
   txt += VVu8zC("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVu8zC("Perm. (Ext.)" , permExtra)
   txt += VVu8zC("iNode"    , iNode)
   txt += VVu8zC("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVbsTC(path)
  else:
   FFryuM(self, "Cannot access information !")
  if len(txt) > 0:
   FFDLqC(self, txt)
 def VV1rKA(self, path):
  path = path.strip()
  path = FFYRE0(path)
  result = FFunaH("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVS3t7(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVS3t7(perm, 1, 4)
   permGroup = VVS3t7(perm, 4, 7)
   permOther = VVS3t7(perm, 7, 10)
   permExtra = VVS3t7(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFuNwj("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVbsTC(self, path):
  txt  = ""
  res  = FFunaH("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFEK4e("File Attributes:", VViTDo), txt)
  return txt
 def VVErwq(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFkL2p(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFkL2p(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFkL2p(os.path.getctime(path))
  return txt
 def VVmn4L(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFunaH("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFunaH("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFunaH("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VVZs2T(self, currentSel):
  currentDir  = self["myMenu"].VVRD4K()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVB2UF():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVCgwv(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VV9fur(self):
  path = self.VVZs2T(self.VVCgwv())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VV5KKr()
  if self.mode == self.VVGziO:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVbuGK:
   path = self.VVZs2T(self.VVCgwv())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVntzw(self):
  color1 = VVUVBT
  color2 = VVfZXg
  color3 = VVZoWi
  totSel = 0
  menuW = 1000
  title = "Options"
  VVGIDM= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVPhef()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFlPiz(totSel))
     VVGIDM.append((color1 + txt1     , "VVjPFi1" ))
     VVGIDM.append((color1 + txt1 + txt2   , "VVjPFi2" ))
     VVGIDM.append(VVVgKz)
    VVGIDM.append(("[6] Copy"       , "copyBulk" ))
    VVGIDM.append(("[7] Move"       , "moveBulk" ))
    VVGIDM.append(("[8] %sDELETE" % VVnviq , "VVU006" ))
   else:
    FFqgHP(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVSgRQ, self.VVbuGK):
   VVGIDM.append(("Properties"           , "properties" ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VVZs2T(self.VVCgwv())
   isEditable = self["myMenu"].VV8OQ4()
   VVGIDM.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVGIDM.append(VVVgKz)
     VVGIDM.append((color1 + "Archiving / Packaging", "VVUDla_dir"))
   elif os.path.isfile(path):
    selFile = self.VVCgwv()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVGIDM.append((color1 + "Archive ...", "VVUDla_file"))
    isText = False
    txt = ""
    if   isArch            : VVGIDM.extend(self.VVxzas(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVGIDM.extend(self.VVwPyw(True))
    elif selFile.endswith(".sh"):
     VVGIDM.extend(self.VVKngN(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCLyBs.VVjqqH(path):
     VVGIDM.append(VVVgKz)
     VVGIDM.append((color2 + "View"     , "textView_def"))
     VVGIDM.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVGIDM.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVFDz5(path) == "pic":
     VVGIDM.append(VVVgKz)
     VVGIDM.append((color2 + "Set as PIcon for current channel" , "VVNXe4" ))
     if FFE0hR("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVGIDM.append(VVVgKz)
      VVGIDM.append((color2 + "Convert to MVI (1280 x 720 )" , "VVTzCLHd"   ))
      VVGIDM.append((color2 + "Convert to MVI (1920 x 1080)" , "VVTzCLFhd"   ))
    elif selFile.endswith(CCLyBs.VVmf1H()):
     if selFile.endswith(".mvi"):
      if FFE0hR("showiframe"):
       VVGIDM.append(VVVgKz)
       VVGIDM.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVGIDM.append(VVVgKz)
      VVGIDM.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVGIDM.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVGIDM.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVGIDM.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVGIDM.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVGIDM.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVnZiU" ))
    if len(txt) > 0:
     VVGIDM.append(VVVgKz)
     VVGIDM.append((color1 + txt, "VVCjqg"))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("[4] Create SymLink", "VVuOE2"))
   if isEditable:
    VVGIDM.append(("[5] Rename"      , "VVBWqJ" ))
    VVGIDM.append(("[6] Copy"       , "copyFileOrDir" ))
    VVGIDM.append(("[7] Move"       , "moveFileOrDir" ))
    VVGIDM.append(("[8] %sDELETE" % VVnviq , "VVXvs7" ))
    if fileExists(path):
     VVGIDM.append(VVVgKz)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVGIDM.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVGIDM.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVGIDM.append((chmodTxt + "777)", "chmod777"))
   VVGIDM.append(VVVgKz)
   VVGIDM.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVGIDM.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCLyBs.VVK93s(self)
   if fPath:
    VVGIDM.append(VVVgKz)
    VVGIDM.append((color2 + "Go to Current Movie Dir", "VV8c8g"))
  FFzctu(self, self.VVH8XJ, width=menuW, height=1050, title=title, VVGIDM=VVGIDM, VVF69c=False, VVXsDY="#00101020", VVEEoV="#00101A2A")
 def VVH8XJ(self, item=None):
  if item is not None:
   path = self.VVZs2T(self.VVCgwv())
   selFile = self.VVCgwv()
   if   item == "VVjPFi1"    : self.VVjPFi(False)
   if   item == "VVjPFi2"    : self.VVjPFi(True)
   elif item == "copyBulk"     : self.VVIuh9(False)
   elif item == "moveBulk"     : self.VVIuh9(True)
   elif item == "VVU006"    : self.VVU006()
   elif item == "properties"    : self.VVEaAV()
   elif item == "VVUDla_dir" : self.VVUDla(path, True)
   elif item == "VVUDla_file" : self.VVUDla(path, False)
   elif item == "VVD7dq"  : self.VVD7dq(path)
   elif item == "VVH4Ws"  : self.VVH4Ws(path)
   elif item.startswith("extract_")  : self.VVHVEf(path, selFile, item)
   elif item.startswith("script_")   : self.VVjXx9(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVrN3O(path, selFile, item)
   elif item.startswith("textView_def") : FFJmvd(self, path)
   elif item.startswith("textView_enc") : self.VVCoxx(path)
   elif item.startswith("text_Edit")  : CC8yF1(self, path, VViIM0=self.VVT8OT)
   elif item.startswith("textSave_encUtf8"): self.VVsEoO(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVsEoO(path, "Save as Other Encoding", False)
   elif item.startswith("VVnZiU") : self.VVnZiU(path)
   elif item == "viewAsBootlogo"   : self.VVHqch(path, True)
   elif item == "addMovieToBouquet"  : self.VVZLFG(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVZLFG(path, True)
   elif item == "playWith"     : self.VVdZZW(path)
   elif item == "VVNXe4" : self.VVNXe4(path)
   elif item == "VVTzCLHd"   : FFVCur(self, BF(self.VVTzCL, path, False))
   elif item == "VVTzCLFhd"   : FFVCur(self, BF(self.VVTzCL, path, True))
   elif item == "VVuOE2"   : self.VVuOE2(path, selFile)
   elif item == "VVBWqJ"   : self.VVBWqJ(path, selFile)
   elif item == "copyFileOrDir"   : self.VVdYfd(path, False)
   elif item == "moveFileOrDir"   : self.VVdYfd(path, True)
   elif item == "VVXvs7"   : self.VVXvs7(path, selFile)
   elif item == "chmod644"     : self.VVDndg(path, selFile, "644")
   elif item == "chmod755"     : self.VVDndg(path, selFile, "755")
   elif item == "chmod777"     : self.VVDndg(path, selFile, "777")
   elif item == "createNewFile"   : self.VVQZA7(path, True)
   elif item == "createNewDir"    : self.VVQZA7(path, False)
   elif item == "VV8c8g"   : self.VV8c8g()
   elif item == "VVCjqg"    : self.VVCjqg()
 def VVCjqg(self):
  if self.mode == self.VVbuGK and not self.patternMode == "poster":
   return
  selFile = self.VVCgwv()
  path  = self.VVZs2T(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVFDz5(path)
   if   cat == "pic"       : self.VVIqAx(path)
   elif cat == "txt"       : FFJmvd(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VVlRVR(path, selFile)
   elif cat == "scr"       : self.VVNEBw(path, selFile)
   elif cat == "m3u"       : self.VVKOsm(path, selFile)
   elif cat in ("ipk", "deb")     : self.VV8CzQ(path, selFile)
   elif cat in ("mov", "mus")     : self.VVHqch(path)
   elif not CCLyBs.VVjqqH(path) : FFJmvd(self, path)
 def VVIqAx(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVFDz5(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCceHb.VVLNYv(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVJjmK)
 def VVJjmK(self, path):
  self.VVzTtm(path)
 def VVHqch(self, path, asLogo=False):
  if asLogo : CCJggj.VVHWO2(self, path)
  else  : FFVCur(self, BF(self.VVKTM4, self, path), title="Playing Media ...")
 def VVLq9z(self):
  if self["keyBlue"].getVisible():
   VVZAt4 = self.VVGqH0()
   if VVZAt4:
    path = self.VVZs2T(self.VVCgwv())
    enableGreenBtn = False if path in self.VVGqH0() else True
    newList = []
    for line in VVZAt4:
     newList.append((line, line))
    VVw5pZ  = ("Delete"    , self.VV0esv    )
    VVV7uB  = ("Add Current Dir"   , BF(self.VVvCcM, path) ) if enableGreenBtn else None
    VVQaYB = ("Move Up"     , self.VVvGHv    )
    VVacc0  = ("Move Down"   , self.VVzoC0    )
    self.bookmarkMenu = FFzctu(self, self.VVVFXb, width=1200, title="Bookmarks", VVGIDM=newList, minRows=10 ,VVw5pZ=VVw5pZ, VVV7uB=VVV7uB, VVQaYB=VVQaYB, VVacc0=VVacc0, VVXsDY="#00000022", VVEEoV="#00000022")
 def VV0esv(self, VVXrLB=None, path=None):
  VVZAt4 = self.VVGqH0()
  if VVZAt4:
   while path in VVZAt4:
    VVZAt4.remove(path)
   self.VVUQhx(VVZAt4)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVqrwk(VVZAt4)
   self.bookmarkMenu.VVfPxm(("Add Current Dir", BF(self.VVvCcM, path)))
  else:
   FFqgHP(self, "Removed", 800)
  self.VV5KKr()
 def VVvCcM(self, path, VVXrLB=None, item=None):
  VVZAt4 = self.VVGqH0()
  if len(VVZAt4) >= self.VVyjoX:
   FFryuM(SELF, "Max bookmarks reached (max=%d)." % self.VVyjoX)
  elif not path in VVZAt4:
   if not os.path.isdir(path):
    path = FFlkVY(path, True)
   newList = [path] + VVZAt4
   self.VVUQhx(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVqrwk(newList)
    self.bookmarkMenu.VVfPxm()
   else:
    FFqgHP(self, "Added", 800)
  self.VV5KKr()
 def VVvGHv(self, selectionObj, path):
  if self.bookmarkMenu:
   VVZAt4 = self.bookmarkMenu.VVjqBz(True)
   if VVZAt4:
    self.VVUQhx(VVZAt4)
 def VVzoC0(self, selectionObj, path):
  if self.bookmarkMenu:
   VVZAt4 = self.bookmarkMenu.VVjqBz(False)
   if VVZAt4:
    self.VVUQhx(VVZAt4)
 def VVVFXb(self, folder=None):
  if folder:
   folder = FF80Mz(folder)
   self["myMenu"].VVORbb(folder)
   self["myMenu"].moveToIndex(0)
  self.VV9fur()
 def VVGqH0(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VV7dD6(self):
  return True if VVGqH0() else False
 def VVUQhx(self, VVZAt4):
  line = ",".join(VVZAt4)
  FFSKZx(CFG.browserBookmarks, line)
 def VVzTtm(self, path):
  if fileExists(path):
   fDir  = FF80Mz(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVORbb(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFqgHP(self, "Not found", 1000)
 def VV8c8g(self, chDir=True):
  fPath, fDir, fName = CCLyBs.VVK93s(self)
  self.VVzTtm(fPath)
 def VVouq6(self):
  path = self.VVZs2T(self.VVCgwv())
  isAdd = False if path in self.VVGqH0() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVN1ah, VVUrbH, VVfZXg
  VVGIDM = []
  VVGIDM.append(("Find Files ..." , "find"))
  VVGIDM.append(("Sort ..."   , "sort"))
  VVGIDM.append(VVVgKz)
  if isAdd: VVGIDM.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVGIDM.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVGziO:
   VVGIDM.append(VVVgKz)
   if self.multiSelectState: VVGIDM.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVGIDM.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVGIDM.append(       (c3 + "Select all"    , "selAll"  ))
  FFzctu(self, BF(self.VV0Lz8, path), width=750, title="More Options", VVGIDM=VVGIDM, VVXsDY="#00221111", VVEEoV="#00221111")
 def VV0Lz8(self, path, item):
  if item:
   if   item == "find"  : self.VVzsPU(path)
   elif item == "sort"  : self.VVskcm()
   elif item == "addBM" : self.VVvCcM(path)
   elif item == "remBM" : self.VV0esv(None, path)
   elif item == "start" : self.VVG0vb(path)
   elif item == "multiOn" : self.VVMUA0(True)
   elif item == "multiOff" : self.VVMUA0(False)
   elif item == "selAll" : self.VVMUA0(True, True)
 def VVMUA0(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFVCur(self, BF(self["myMenu"].VVrNNb, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVANuv(self.VVDCfg if isOn else self.VVfnRu)
 def VVANuv(self, mode=0):
  if   mode == self.VVkJjp : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVDCfg: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVXsDY, self.VVEEoV
  FF21Xy(self["myTitle"], titBg)
  FF21Xy(self["myBar"], titBg)
  FF21Xy(self["myBody"], bodBg)
  FF21Xy(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VVxmNi()
  else     : bg, txt = VVdPa0[3], "Bookmarks"
  FFbJWj(self["keyBlue"], txt)
  FF21Xy(self["keyBlue"], bg)
  self.VV5KKr()
 def VVxmNi(self):
  return "Selected Items = %d" % self["myMenu"].VVPhef()
 def VV5KKr(self):
  if self.VVGqH0() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVzsPU(self, path):
  VVGIDM = []
  VVGIDM.append(("Find in Current Directory"    , "findCur"  ))
  VVGIDM.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVGIDM.append(("Find in all Storage Systems"    , "findAll"  ))
  FFzctu(self, BF(self.VV84Es, path), width=700, title="Find File/Pattern", VVGIDM=VVGIDM, VVglmG=True, VVoaDe=True, VVXsDY="#00221111", VVEEoV="#00221111")
 def VV84Es(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VViltK(0, path, title)
   elif item == "findCurR" : self.VViltK(1, path, title)
   elif item == "findAll" : self.VViltK(2, path, title)
 def VViltK(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FF9Fmo(self, BF(self.VVQIJm, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVQIJm(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFSKZx(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFqgHP(self, "No entery", 1500)
   elif badLst  : FFqgHP(self, "Too many file !", 1500)
   else   : FFVCur(self, BF(self.VVVVfE, mode, path, title, filePatt), title="Searching ...")
 def VVVVfE(self, mode, path, title, filePatt):
  lst = FF30Q2(FFCbk8("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCLyBs.VVkPRf(lst)
   if err:
    FFryuM(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVMOfU = (""     , self.VVkeRu , [])
    VVoXaA = ("Go to File Location", self.VV4XYh  , [])
    FFfJU2(self, None, title="%s : %s" % (title, filePatt), header=header, VVZAt4=lst, VVbiLs=widths, VVNdFV=26, VVMOfU=VVMOfU, VVoXaA=VVoXaA)
  else:
   FFe82w(self, "Not found !", 2000)
 def VV4XYh(self, VVxL8T, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVxL8T.cancel()
   self.VVzTtm(path)
  else:
   FFqgHP(VVxL8T, "Path not found !", 1000)
 def VVkeRu(self, VVxL8T, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFEK4e("File:"  , VVfZXg), colList[0])
  txt += "%s\n%s"  % (FFEK4e("Directory:", VVfZXg), FF80Mz(colList[1]))
  FFDLqC(VVxL8T, txt, title=title)
 def VVskcm(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVrQ4d()
  VVGIDM = []
  VVGIDM.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVGIDM.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVGIDM.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVGIDM.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVacc0 = ("Mix", BF(self.VVbtni, True))
  FFzctu(self, BF(self.VVu2os, False), barText=txt, width=650, title="Sort Options", VVGIDM=VVGIDM, VVacc0=VVacc0, VVoaDe=True, VVXsDY="#00221111", VVEEoV="#00221111")
 def VVbtni(self, isMix, VVXrLB, item):
  self.VVu2os(True, item)
 def VVu2os(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVrQ4d()
   title = "Sorting ... "
   if   item == "nameAlp": FFVCur(self, BF(self["myMenu"].VVzp35, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFVCur(self, BF(self["myMenu"].VVzp35, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFVCur(self, BF(self["myMenu"].VVzp35, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFVCur(self, BF(self["myMenu"].VVzp35, typeMode , isMix, False), title=title)
 def VVG0vb(self, path):
  if not os.path.isdir(path):
   path = FFlkVY(path, True)
  FFSKZx(CFG.browserStartPath, path)
  FFqgHP(self, "Done", 500)
 def VViQp6(self, selFile, VVcsne, command):
  FFP9Be(self, BF(FF8jLK, self, command, consFont=True, VVZgJA=self.VVGYOL), "%s\n\n%s" % (VVcsne, selFile))
 def VVxzas(self, path, calledFromMenu):
  destPath = self.VVV91j(path)
  lastPart = FFlW1I(destPath)
  color = VVfZXg if calledFromMenu else ""
  VVGIDM = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVGIDM.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVGIDM.append(VVVgKz)
   VVGIDM.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVGIDM.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVGIDM.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVGIDM.append(VVVgKz)
     VVGIDM.append((color + "Convert .zip to .tar.gz"       , "VVD7dq" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVGIDM.append(VVVgKz)
     VVGIDM.append((color + "Convert .tar.gz to .zip"       , "VVH4Ws" ))
  return VVGIDM
 def VVlRVR(self, path, selFile):
  FFzctu(self, BF(self.VVHVEf, path, selFile), title="Compressed File Options", VVGIDM=self.VVxzas(path, False))
 def VVHVEf(self, path, selFile, item=None):
  if item is not None:
   parent  = FFlkVY(path, False)
   destPath = self.VVV91j(path)
   lastPart = FFlW1I(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFhXFT("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFhXFT("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n\n';" % path
     cmd += "totFiles=$(tar -tf '%s' | wc -l);" % path
     cmd += "if (( $totFiles > 300 )); then moreInf='  ... Will list the first 300 only ...'; else moreInf=''; fi;"
     cmd += "echo -e '\n%s\n--- Contents (Total='$totFiles')'$moreInf'\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s' | head -n300;" % path
     cmd += "if (( $totFiles > 300 )); then echo '\n... Only the first 300 are listed ...'; fi;"
    cmd += "echo '';"
    cmd += linux_sep
    FF0JeX(self, cmd)
   elif path.endswith(".zip"):
    if item == "VVD7dq" : self.VVD7dq(path)
    else       : self.VVTRd5(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVH4Ws" and path.endswith(".tar.gz"):
    self.VVH4Ws(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFunaH("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FF6mzu(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVGYOL()
    else:
     FFryuM(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VV64Cy(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFbUbn("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VViQp6(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VViQp6(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFlkVY(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VViQp6(selFile, "Extract Here ?"      , cmd)
 def VVV91j(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVTRd5(self, item, path, parent, destPath, VVcsne):
  FFP9Be(self, BF(self.VVfUq4, item, path, parent, destPath), VVcsne)
 def VVfUq4(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFhXFT("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFpC0R(destPath, VVijSd))
  cmd +=   sep
  cmd += "fi;"
  FF53hC(self, cmd, VVZgJA=self.VVGYOL)
 def VV64Cy(self, item, path, parent, destPath, VVcsne):
  FFP9Be(self, BF(self.VVQxGO, item, path, parent, destPath), VVcsne)
 def VVQxGO(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF80Mz(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFhXFT("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFpC0R(destPath, VVijSd))
  cmd +=   sep
  cmd += "fi;"
  FF53hC(self, cmd, VVZgJA=self.VVGYOL)
 def VVKngN(self, addSep=False):
  VVGIDM = []
  if addSep:
   VVGIDM.append(VVVgKz)
  VVGIDM.append((VVfZXg + "View Script File"  , "script_View"  ))
  VVGIDM.append((VVfZXg + "Execute Script File" , "script_Execute" ))
  VVGIDM.append((VVfZXg + "Edit"     , "script_Edit"  ))
  return VVGIDM
 def VVNEBw(self, path, selFile):
  FFzctu(self, BF(self.VVjXx9, path, selFile), title="Script File Options", VVGIDM=self.VVKngN())
 def VVjXx9(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFJmvd(self, path)
   elif item == "script_Execute" : self.VViQp6(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CC8yF1(self, path, VViIM0=self.VVT8OT)
 def VVwPyw(self, addSep=False):
  VVGIDM = []
  if addSep:
   VVGIDM.append(VVVgKz)
  VVGIDM.append((VVfZXg + "Browse IPTV Channels" , "m3u_Browse" ))
  VVGIDM.append((VVfZXg + "Edit"     , "m3u_Edit" ))
  VVGIDM.append((VVfZXg + "View"     , "m3u_View" ))
  return VVGIDM
 def VVKOsm(self, path, selFile):
  FFzctu(self, BF(self.VVrN3O, path, selFile), title="M3U/M3U8 File Options", VVGIDM=self.VVwPyw())
 def VVrN3O(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFVCur(self, BF(self.session.open, CCDrYI, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CC8yF1(self, path, VViIM0=self.VVT8OT)
   elif item == "m3u_View"  : FFJmvd(self, path)
 def VVCoxx(self, path):
  if fileExists(path) : FFVCur(self, BF(CCme0M.VVhV58, self, path, BF(self.VV09j8, path)), title="Loading Codecs ...")
  else    : FFAhcl(self, path)
 def VV09j8(self, path, item=None):
  if item:
   FFJmvd(self, path, encLst=item)
 def VVsEoO(self, path, title, asUtf8):
  if fileExists(path) : FFVCur(self, BF(CCme0M.VVhV58, self, path, BF(self.VVMSBZ, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFAhcl(self, path)
 def VVMSBZ(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVOWKf(path, title, fromEnc, "UTF-8")
   else  : CCme0M.VVjhER(self, BF(self.VVOWKf, path, title, fromEnc), title="Convert to Encoding")
 def VVOWKf(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFEK4e("Successful\n\n", VVijSd)
      txt += FFEK4e("From Encoding (%s):\n" % fromEnc, VVWhci)
      txt += "%s\n\n" % path
      txt += FFEK4e("To Encoding (%s):\n" % toEnc, VVWhci)
      txt += "%s\n\n" % outFile
      FFDLqC(self, txt, title=title)
    except:
     FFryuM(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFqgHP(self, "Cannot open file", 2000)
   self.VVGYOL()
 def VVnZiU(self, path):
  title = "File Line-Break Conversion"
  FFP9Be(self, BF(self.VVcrUW, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVcrUW(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFEK4e("File converted:", VVijSd), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF6mzu(self, txt, title=title)
  else:
   FFAhcl(self, path, title=title)
 def VVDndg(self, path, selFile, newChmod):
  FFP9Be(self, BF(self.VVYqHL, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVYqHL(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV18Av)
  result = FFunaH(cmd)
  if result == "Successful" : FF6mzu(self, result)
  else      : FFryuM(self, result)
 def VVuOE2(self, path, selFile):
  parent = FFlkVY(path, False)
  self.session.openWithCallback(self.VV5buH, BF(CCLyBs, mode=CCLyBs.VVSgRQ, VV8MX1=parent, VVWkA9="Create Symlink here"))
 def VV5buH(self, newPath):
  if len(newPath) > 0:
   target = self.VVZs2T(self.VVCgwv())
   target = FFYRE0(target)
   linkName = FFlW1I(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF80Mz(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFryuM(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFP9Be(self, BF(self.VVXe7f, target, link), "Create Soft Link ?\n\n%s" % txt, VVi1cr=True)
 def VVXe7f(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV18Av)
  result = FFunaH(cmd)
  if result == "Successful" : FF6mzu(self, result)
  else      : FFryuM(self, result)
 def VVBWqJ(self, path, selFile):
  lastPart = FFlW1I(path)
  FF9Fmo(self, BF(self.VV6Yih, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VV6Yih(self, path, selFile, VVxkNp):
  if VVxkNp:
   parent = FFlkVY(path, True)
   if os.path.isdir(path):
    path = FFYRE0(path)
   newName = parent + VVxkNp
   cmd = "mv '%s' '%s' %s" % (path, newName, VV18Av)
   if VVxkNp:
    if selFile != VVxkNp:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFP9Be(self, BF(self.VVSwWl, cmd), message, title="Rename file?")
    else:
     FFryuM(self, "Cannot use same name!", title="Rename")
 def VVSwWl(self, cmd):
  result = FFunaH(cmd)
  if "Fail" in result:
   FFryuM(self, result)
  self.VVGYOL()
 def VVjPFi(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCChia, barTheme=CCChia.VV1d7P, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVtoYh, title, preserve)
      , VViIM0 = BF(self.VVJ2LV, title))
 def VVtoYh(self, title, preserve, VVWRJ1):
  totSel = self["myMenu"].VVPhef()
  totOk = totFail = 0
  VVWRJ1.VVsWOI(totSel)
  VVWRJ1.VVfN1b = ["", totSel, totOk, totFail, ""]
  VVWRJ1.VVDS8r("Prepareing targz file")
  curDir = self["myMenu"].VVRD4K()
  lastPart = FFlW1I(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVWRJ1 or VVWRJ1.isCancelled:
      return
     if row[2][6]:
      VVWRJ1.VVYksR(1)
      name  = FFYRE0(row[0][0])
      lastPath = FFlW1I(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVWRJ1:
       VVWRJ1.VVfN1b = [outF, totSel, totOk, totFail, path]
       VVWRJ1.VVgcPO(totOk, lastPath)
  except:
   totFail += 1
   if VVWRJ1:
    VVWRJ1.VVfN1b = [outF, totSel, totOk, totFail, path]
 def VVJ2LV(self, title, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVfN1b
  txt  = "%s:\n%s\n\n"   % (FFEK4e("Output File", VVijSd), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFEK4e("Failed\t: %d\n" % totFail, VVnviq)
  if not VVmEsn: txt += "%s\n%s" % (FFEK4e("\nCancelled while copying:", VVnviq), path)
  FFDLqC(self, txt, title=title)
  self.VVGYOL()
 def VVIuh9(self, isMove):
  self.session.openWithCallback(BF(self.VVFxnf, isMove), BF(CCLyBs, mode=CCLyBs.VVSgRQ, VV8MX1=self["myMenu"].VVRD4K(), VVWkA9="Move to here" if isMove else "Paste here"))
 def VVFxnf(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCChia, barTheme=CCChia.VV1d7P, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVfphr, title, action, isMove, newPath)
       , VViIM0 = BF(self.VVeHHS, title, action, isMove, newPath))
 def VVfphr(self, title, action, isMove, newPath, VVWRJ1):
  curDir = self["myMenu"].VVRD4K()
  totOk = totFail = 0
  totSel = self["myMenu"].VVPhef()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVWRJ1.VVsWOI(totSel)
  VVWRJ1.VVfN1b = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVWRJ1 or VVWRJ1.isCancelled:
    return
   if row[2][6]:
    VVWRJ1.VVYksR(1)
    VVWRJ1.VVIIGi(action, totOk, FFlW1I(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFlW1I(path)
    if os.path.isdir(path): path = FFYRE0(path)
    dest = os.path.join(newPath, lastPart)
    if FFyakl("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVWRJ1:
     VVWRJ1.VVfN1b = [totSel, totOk, totFail, path]
     VVWRJ1.VVIIGi(action, totOk, FFlW1I(row[0][0]))
 def VVeHHS(self, title, action, isMove, newPath, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVfN1b
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFEK4e("Failed\t: %d\n" % totFail, VVnviq)
  if not VVmEsn: txt += "%s\n%s" % (FFEK4e("\nCancelled while copying:", VVnviq), path)
  FFDLqC(self, txt, title=title)
  self.VVGYOL()
 def VVU006(self):
  tot = self["myMenu"].VVPhef()
  FFP9Be(self, BF(FFVCur, self, self.VVFp21, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFlPiz(tot)), title="Delete Selection")
 def VVFp21(self):
  path = self["myMenu"].VVRD4K()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFCy5V(os.path.join(path, row[0][0]))
  FFqgHP(self)
  self.VVGYOL()
 def VVdYfd(self, path, isMove):
  self.session.openWithCallback(BF(self.VVMYtp, isMove, path), BF(CCLyBs, mode=CCLyBs.VVSgRQ, VV8MX1=FFlkVY(path, False), VVWkA9="Move to here" if isMove else "Paste here"))
 def VVMYtp(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFYRE0(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFYRE0(src)
  dst = os.path.join(dst, FFlW1I(src))
  if src == dst:
   FFryuM(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFP9Be(self, BF(self.VVTRsv, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFP9Be(self, BF(self.VVTRsv, prams), "Overwrite Destination Files", title=title)
  else         : self.VVTRsv(prams)
 def VVTRsv(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCLyBs.VVyxXy(src) == CCLyBs.VVyxXy(dst):
   FFVCur(self, BF(self.VVToxZ, prams), title="Moving %s ..." % srcSubj)
  else:
   FFVCur(self, BF(self.VVdSsN, prams), title="Calculating Size ...")
 def VVToxZ(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFunaH("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVGYOL()
  else:
   FFryuM(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VVdSsN(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFl8II(src)
  else  : size = FFg1qW(src)
  if size > -1:
   self.session.open(CCChia, barTheme=CCChia.VV1d7P, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VV38vC, prams, size)
       , VViIM0 = BF(self.VVl1Bs, prams))
  else:
   FFryuM(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VV38vC(self, prams, size, VVWRJ1):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVWRJ1.VVsWOI(size)
  VVWRJ1.VVfN1b = ("", "", False)
  def VVh9t0(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFbUco(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVWRJ1 or VVWRJ1.isCancelled:
        VVWRJ1.VVfN1b = (srcFile, "", True)
        FFbUco(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVWRJ1.VVYksR(len(data))
       except Exception as e:
        VVWRJ1.VVfN1b = (srcFile, str(e), False)
        FFbUco(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFbUco(srcFile)
   return True
  if isFile:
   tot = 1
   VVh9t0(src, dst)
  else:
   VVWRJ1.VVDS8r("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFPXso(src)
   if not VVWRJ1 or VVWRJ1.isCancelled:
    VVWRJ1.VVfN1b = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVWRJ1.VVfN1b = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVWRJ1.VVDS8r("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVh9t0(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFyakl("rm -fr '%s'" % Dir)
   if isMove:
    FFyakl("rm -fr '%s'" % src)
 def VVl1Bs(self, prams, VVmEsn, VVfN1b, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVfN1b
  if err:
   FFryuM(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFqgHP(self, "Canelled", 1000)
   else  : FFryuM(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFqgHP(self, "Done", 1500, isGrn=True)
  if VVmEsn and isMove:
   self.VVGYOL()
 def VVXvs7(self, path, fileName):
  path = FFYRE0(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFP9Be(self, BF(FFVCur, self, BF(self.VVNNyd, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVNNyd(self, path):
  FFCy5V(path)
  FFqgHP(self)
  self.VVGYOL()
 def VVQZA7(self, path, isFile):
  dirName = FF80Mz(os.path.dirname(path))
  if isFile : objName, VVxkNp = "File"  , self.edited_newFile
  else  : objName, VVxkNp = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FF9Fmo(self, BF(self.VV8nBO, dirName, isFile, title), title=title, defaultText=VVxkNp, message="Enter %s Name:" % objName)
 def VV8nBO(self, dirName, isFile, title, VVxkNp):
  if VVxkNp:
   if isFile : self.edited_newFile = VVxkNp
   else  : self.edited_newDir  = VVxkNp
   path = dirName + VVxkNp
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV18Av)
    else  : cmd = "mkdir '%s' %s" % (path, VV18Av)
    result = FFunaH(cmd)
    if "Fail" in result:
     FFryuM(self, result)
    self.VVGYOL()
   else:
    FFryuM(self, "Name already exists !\n\n%s" % path, title)
 def VV8CzQ(self, path, selFile):
  c1, c2, c3 = VVUrbH, VVfZXg, VVUVBT
  VVGIDM = []
  VVGIDM.append((c1 + "List Package Files"         , "VVD23r"     ))
  VVGIDM.append((c1 + "Package Information"         , "VVeUpp"     ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c2 + "Install Package"          , "VVaXrq_CheckVersion" ))
  VVGIDM.append((c2 + "Install Package (force reinstall)"     , "VVaXrq_ForceReinstall" ))
  VVGIDM.append((c2 + "Install Package (force overwrite)"     , "VVaXrq_ForceOverwrite" ))
  VVGIDM.append((c2 + "Install Package (force downgrade)"     , "VVaXrq_ForceDowngrade" ))
  VVGIDM.append((c2 + "Install Package (ignore failed dependencies)"  , "VVaXrq_IgnoreDepends" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c3 + "Remove Related Package"        , "VVu1yU_ExistingPackage" ))
  VVGIDM.append((c3 + "Remove Related Package (force remove)"    , "VVu1yU_ForceRemove"  ))
  VVGIDM.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVu1yU_IgnoreDepends" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Extract Files"           , "VVnFrr"     ))
  VVGIDM.append(("Unbuild Package"           , "VVajl0"     ))
  FFzctu(self, BF(self.VVu8fK, path, selFile), VVGIDM=VVGIDM)
 def VVu8fK(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVD23r"      : self.VVD23r(path, selFile)
   elif item == "VVeUpp"      : self.VVeUpp(path)
   elif item == "VVaXrq_CheckVersion"  : self.VVaXrq(path, selFile, VVP2Dj     )
   elif item == "VVaXrq_ForceReinstall" : self.VVaXrq(path, selFile, VV80Ym )
   elif item == "VVaXrq_ForceOverwrite" : self.VVaXrq(path, selFile, VVCu09 )
   elif item == "VVaXrq_ForceDowngrade" : self.VVaXrq(path, selFile, VVhCIY )
   elif item == "VVaXrq_IgnoreDepends" : self.VVaXrq(path, selFile, VVxBkr )
   elif item == "VVu1yU_ExistingPackage" : self.VVu1yU(path, selFile, VVNK7J     )
   elif item == "VVu1yU_ForceRemove"  : self.VVu1yU(path, selFile, VVgFzV  )
   elif item == "VVu1yU_IgnoreDepends"  : self.VVu1yU(path, selFile, VVXzTR )
   elif item == "VVnFrr"     : self.VVnFrr(path, selFile)
   elif item == "VVajl0"     : self.VVajl0(path, selFile)
 def VVD23r(self, path, selFile):
  if FFE0hR("ar") : cmd = "allOK='1';"
  else    : cmd  = FFjDBy()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFoTrM(self, cmd, VVZgJA=self.VVGYOL)
 def VVnFrr(self, path, selFile):
  lastPart = FFlW1I(path)
  dest  = FFlkVY(path, True) + selFile[:-4]
  cmd  =  FFjDBy()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFbUbn("mkdir '%s'" % dest)
  cmd +=    FFbUbn("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFpC0R(dest, VVijSd))
  cmd += "fi;"
  FF8jLK(self, cmd, VVZgJA=self.VVGYOL)
 def VVajl0(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVVRme = os.path.splitext(path)[0]
  else        : VVVRme = path + "_"
  if path.endswith(".deb")   : VV0aRO = "DEBIAN"
  else        : VV0aRO = "CONTROL"
  cmd  = FFjDBy()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVVRme
  cmd += "  mkdir '%s';"      % VVVRme
  cmd += "  CONTPATH='%s/%s';"    % (VVVRme, VV0aRO)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVVRme
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVVRme, VVVRme)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVVRme
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVVRme, VVVRme)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVVRme
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVVRme
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVVRme, FFpC0R(VVVRme, VVijSd))
  cmd += "fi;"
  FF8jLK(self, cmd, VVZgJA=self.VVGYOL)
 def VVeUpp(self, path):
  listCmd  = FFthHn(VVH9np, "")
  infoCmd  = FFM6zB(VVRLzP , "")
  filesCmd = FFM6zB(VVOU4o, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFWads(VVWhci)
   notInst = "Package not installed."
   cmd  = FFmeBG("File Info", VVWhci)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFmeBG("System Info", VVWhci)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFpC0R(notInst, VVnviq))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFmeBG("Related Files", VVWhci)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FF0JeX(self, cmd)
  else:
   FFRzIz(self)
 def VVaXrq(self, path, selFile, cmdOpt):
  cmd = FFM6zB(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFP9Be(self, BF(FF8jLK, self, cmd, VVZgJA=FFaHKF), "Install Package ?\n\n%s" % selFile)
  else:
   FFRzIz(self)
 def VVu1yU(self, path, selFile, cmdOpt):
  listCmd  = FFthHn(VVH9np, "")
  infoCmd  = FFM6zB(VVRLzP, "")
  instRemCmd = FFM6zB(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFpC0R(errTxt, VVnviq))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFpC0R(cannotTxt, VVnviq))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFpC0R(tryTxt, VVnviq))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFP9Be(self, BF(FF8jLK, self, cmd, VVZgJA=FFaHKF), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFRzIz(self)
 def VVPG6N(self, path):
  hostName = FFunaH("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVUDla(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVGIDM = []
  VVGIDM.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVGIDM.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVGIDM.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVGIDM.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVGIDM.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVGIDM.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVGIDM.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVGIDM.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVGIDM.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVGIDM.append(VVVgKz)
   VVGIDM.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVGIDM.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFzctu(self, BF(self.VVkGgQ, path, isDir, title), VVGIDM=VVGIDM, title=title, VVXsDY=c1, VVEEoV=c2)
 def VVkGgQ(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VV5pLg(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VV5pLg(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VV5pLg(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VV5pLg(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VV5pLg(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VV5pLg(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VV5pLg(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VV5pLg(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VV5pLg(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VV5pLg(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VV8HIi(path, False)
   elif item == "convertDirToDeb" : self.VV8HIi(path, True)
 def VV8HIi(self, path, VV76sq):
  self.session.openWithCallback(self.VVGYOL, BF(CCeghF, path=path, VV76sq=VV76sq))
 def VV5pLg(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFlkVY(path, True)
  lastPart = FFlW1I(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFhXFT("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFhXFT("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFhXFT("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFbUbn("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFpC0R(failed, VVWEO1))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFpC0R(srcTxt, VVN1ah))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFpC0R("Output", VVijSd))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFpC0R(failed, VVWABP))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFoTrM(self, cmd, VVZgJA=self.VVGYOL, title=title)
 def VVZLFG(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCLyBs.VVWhM3(FFlkVY(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCpURW(self, self, title, BF(self.VVKsYv, pathLst))
 def VVKsYv(self, pathLst):
  return CCpURW.VV1K5k(pathLst)
 def VVD7dq(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVCBBR, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFP9Be(self, BF(FFVCur, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFVCur(self, fnc, title=txt)
  else:
   FFryuM(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVCBBR(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFDLqC(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVGYOL()
  else:
   FFbUco(tarPath)
   FFryuM(self, "Error while converting.", title=title)
 def VVH4Ws(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVvVdt, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFP9Be(self, BF(FFVCur, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFVCur(self, fnc, title=txt)
  else:
   FFryuM(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVvVdt(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFDLqC(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVGYOL()
  else:
   FFbUco(zipPath)
   FFryuM(self, "Error while converting.", title=title)
 def VVTzCL(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FF80Mz(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFyakl("rm -f '%s' '%s'" % (m1v, mvi))
  if FFyakl("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFyakl("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVGYOL()
   FF6mzu(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFryuM(self, "Cannot convert this file !", title=title)
 def VVNXe4(self, path):
  title = "Set as PIcon for current channel"
  pPath = CC9p8T.VVH8Sz()
  if pathExists(pPath):
   if CC0Hnq.VVi4Av(self, title, False, cbFnc=BF(self.VVNXe4, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVGIDM = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVGIDM.append(("%d x %d" % (item), item))
    VVx6LK = self.VVKxAw
    VVacc0 = ("Stretch", BF(self.VV0x6p, title, path, picon))
    VVXrLB = FFzctu(self, BF(self.VVlUcI, title, path, picon, False), VVGIDM=VVGIDM, width=700, title='PIcon Max. Size', VVx6LK=VVx6LK, VVacc0=VVacc0, barText="OK = Fit within size")
    VVXrLB.VVwPcs(3)
  else:
   FFryuM(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VV0x6p(self, title, path, picon, selectionObj, item):
  self.VVlUcI(title, path, picon, True, item)
  selectionObj.cancel()
 def VVlUcI(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFNmLy(self, fncMode=CCVNso.VV9EG1)
   except Exception as e:
    FFryuM(self, "Image Processing error:\n\n%s" % e)
 def VVKxAw(self, VVXrLB, txt, ref, ndx):
  FFog0j(self, "_help_resize", "Picture File Resizing")
 def VVdZZW(self, path):
  FFzctu(self, BF(self.VVLbHM, path), VVGIDM=CCDrYI.VVuv4i(), width=650, title="Select Player", VVXsDY="#11220000", VVEEoV="#11220000")
 def VVLbHM(self, path, rType=None):
  if rType:
   FFVCur(self, BF(self.VVKTM4, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVKTM4(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCTKa3.VV3qn6(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVK93s(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF80Mz(fDir), fName
  return "", "", ""
 @staticmethod
 def VV7JZt(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVJ8wE(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVM24t(size, mode=0):
  txt = CCLyBs.VVn2OQ(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVn2OQ(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVjqqH(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVzL6D(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFryuM(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVmf1H():
  tDict = CC8QHN.VVzGQB()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVWhM3(path):
  lst = []
  for ext in CCLyBs.VVmf1H():
   lst.extend(FFqy37(path, "*.%s" % ext))
  return sorted(lst, key=FFkp5b(FFz52H))
 @staticmethod
 def VVl4x1(path):
  return FFyakl("tar -tzf '%s'" % path)
 @staticmethod
 def VVyxXy(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVkPRf(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVGxSM:
   return VVGxSM
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CC8QHN(MenuList):
 VVhdfQ   = 0
 VV4R65   = 1
 VVH8Wu   = 2
 VVKGZr   = 3
 VVdC2U   = 4
 VVCOmI   = 5
 VVQmtb   = 6
 VVW1Xi   = 7
 VV8tKo   = "<List of Storage Devices>"
 VV49i1  = "<Parent Directory>"
 VVYewN   = 0
 VVyZ0J   = 1
 VVHqGE = 2
 VVAd6l  = 3
 VVEYAZ   = 4
 VVqKSU   = 5
 FILE_TYPE_LINK   = 6
 VVOwbv  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVbqMa=False, directory="/", VV1er6=True, VV5yDB=True, VV3tSk=True, VV83Fj=None, VVRdrH=False, VVDNiz=False, VVULWo=False, isTop=False, VVQArl=None, VVZa0q=1000, VVNdFV=30, VVN35T=30):
  MenuList.__init__(self, list, VVbqMa, eListboxPythonMultiContent)
  self.VV1er6  = VV1er6
  self.VV5yDB    = VV5yDB
  self.VV3tSk  = VV3tSk
  self.VV83Fj  = VV83Fj
  self.VVRdrH   = VVRdrH
  self.VVDNiz   = VVDNiz or []
  self.VVULWo   = VVULWo or []
  self.isTop     = isTop
  self.additional_extensions = VVQArl
  self.VVZa0q    = VVZa0q
  self.VVNdFV    = VVNdFV
  self.VVN35T    = VVN35T
  self.EXTENSIONS    = CC8QHN.VVzGQB()
  self.VVXX0J   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFRpt5("#11ff4444")
  self.l.setFont(0, gFont(VVoGd5, self.VVNdFV))
  self.l.setItemHeight(self.VVN35T)
  self.png_mem   = CC8QHN.VV8n8R("mem")
  self.png_usb   = CC8QHN.VV8n8R("usb")
  self.png_fil   = CC8QHN.VV8n8R("fil")
  self.png_dir   = CC8QHN.VV8n8R("dir")
  self.png_dirup   = CC8QHN.VV8n8R("dirup")
  self.png_srv   = CC8QHN.VV8n8R("srv")
  self.png_slwfil   = CC8QHN.VV8n8R("slwfil")
  self.png_slbfil   = CC8QHN.VV8n8R("slbfil")
  self.png_slwdir   = CC8QHN.VV8n8R("slwdir")
  self.VVlZMI()
  self.VVORbb(directory)
 @staticmethod
 def VV8n8R(category):
  return LoadPixmap("%s%s.png" % (VV6OO5, category), getDesktop(0))
 @staticmethod
 def VVzGQB():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVZpBc(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFYRE0(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFEK4e(" -> " , VVWhci) + FFEK4e(os.readlink(path), VVijSd)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVN35T + 10, 0, self.VVZa0q, self.VVN35T, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   tableRow.append(CC5cb1.VVecW5(0, 2, self.VVN35T-4, self.VVN35T-4, png))
  return tableRow
 def VVFDz5(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVlZMI(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVLACQ(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVRkpm(self, file):
  if os.path.realpath(file) == file:
   return self.VVLACQ(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVLACQ(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVLACQ(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVzUWq(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVphpj(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVrNNb(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVphpj(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVphpj(self, row, bg):
  if self.VVJoxV(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVJoxV(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVqKSU, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVEYAZ:
    if   VVf1FF           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VV8OQ4(self):
  return self.VVJoxV(self.list[self.l.getCurrentSelectionIndex()])
 def VVPhef(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVMAnT(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVORbb(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VV3tSk:
    self.current_mountpoint = self.VVRkpm(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VV3tSk:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVULWo and not self.VVMAnT(path, self.VVDNiz):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVZpBc(name=p.description, absolute=path, isDir=True, typ=self.VVYewN, png=png))
    path = "/"
    if path not in self.VVULWo and not self.VVMAnT(path, self.VVDNiz):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVZpBc(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVyZ0J, png=self.png_mem))
  elif self.VVRdrH:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVXX0J = eServiceCenter.getInstance()
   list = VVXX0J.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VV1er6 and not self.isTop:
   if directory == self.current_mountpoint and self.VV3tSk:
    self.list.append(self.VVZpBc(name=self.VV8tKo, absolute=None, isDir=True, typ=self.VVHqGE, png=self.png_dirup))
   elif (directory != "/") and not (self.VVULWo and self.VVLACQ(directory) in self.VVULWo):
    self.list.append(self.VVZpBc(name=self.VV49i1, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVAd6l, png=self.png_dirup))
  if self.VV1er6:
   for x in directories:
    if not (self.VVULWo and self.VVLACQ(x) in self.VVULWo) and not self.VVMAnT(x, self.VVDNiz):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVZpBc(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFYRE0(x)) else self.VVEYAZ, png=png))
  if self.VV5yDB:
   for x in files:
    if self.VVRdrH:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FFEK4e(" -> " , VVWhci) + FFEK4e(target, VVijSd)
       else:
        png = self.png_slbfil
        name += FFEK4e(" -> " , VVWhci) + FFEK4e(target, VVWABP)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVFDz5(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VV6OO5, category))
    if (self.VV83Fj is None) or iCompile(self.VV83Fj[0], flags=self.VV83Fj[1]).search(path):
     self.list.append(self.VVZpBc(name=name, absolute=x , isDir=False, typ=self.VVqKSU, png=png))
  if self.VV3tSk and len(self.list) == 0:
   self.list.append(self.VVZpBc(name=FFEK4e("No USB connected", VVhSN2), absolute=None, isDir=False, typ=self.VVOwbv, png=self.png_usb))
  self.l.setList(self.list)
  self.VVzp35()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVRD4K(self):
  return self.current_directory
 def VVB2UF(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVxy3e(self):
  return self.VVUXsi() and self.VVRD4K()
 def VVUXsi(self):
  return self.list[0][1][7] in (self.VV8tKo, self.VV49i1)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVORbb(self.getSelection()[0], self.current_directory)
 def VVkBog(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVvqh5)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVvqh5)
 def VVvqh5(self, action, device):
  self.VVlZMI()
  if self.current_directory is None:
   self.VVnBFv()
 def VVnBFv(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVORbb(self.current_directory, self.VVkBog())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVrQ4d(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVhdfQ : nameAlpMode, nameAlpTxt = self.VV4R65, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVhdfQ, sAZ
  if mode == self.VVH8Wu : nameNumMode, nameNumTxt = self.VVKGZr, s90
  else       : nameNumMode, nameNumTxt = self.VVH8Wu, s09
  if mode == self.VVdC2U : dateMode, dateTxt = self.VVCOmI, sON
  else       : dateMode, dateTxt = self.VVdC2U, sNO
  if mode == self.VVQmtb : typeMode, typeTxt = self.VVW1Xi, sZA
  else       : typeMode, typeTxt = self.VVQmtb, sAZ
  if   mode in (self.VVhdfQ, self.VV4R65): txt = "Name (%s)" % (sAZ if mode == self.VVhdfQ else sZA)
  elif mode in (self.VVH8Wu, self.VVKGZr): txt = "Name (%s)" % (s09 if mode == self.VVhdfQ else s90)
  elif mode in (self.VVdC2U, self.VVCOmI): txt = "Date (%s)" % (sNO if mode == self.VVdC2U else sON)
  elif mode in (self.VVQmtb, self.VVW1Xi): txt = "Type (%s)" % (sAZ if mode == self.VVQmtb else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVzp35(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFSKZx(CFG.browserSortMode, mode)
   FFSKZx(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVUXsi() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVhdfQ, self.VV4R65):
    rev = True if mode == self.VV4R65 else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVH8Wu, self.VVKGZr):
    rev = True if mode == self.VVKGZr else False
    self.list = sorted(self.list[item0:], key=FFkp5b(BF(self.VVXxsJ, isMix, rev)), reverse=rev)
   elif mode in (self.VVdC2U, self.VVCOmI):
    rev = True if mode == self.VVCOmI else False
    self.list = sorted(self.list[item0:], key=FFkp5b(BF(self.VVnoH2, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVW1Xi else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVXxsJ(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFz52H(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFPzst(dir2, dir1) or FFz52H(name1, name2)
 def VVnoH2(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFPzst(stat2.st_ctime, stat1.st_ctime)
    else : return FFPzst(dir2, dir1) or FFPzst(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CC8Pjn(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFLEcJ(VVjSjD, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVZAt4   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVPAZ3(defFG, "#00FFFFFF")
  self.defBG   = self.VVPAZ3(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFCOTe(self, self.Title)
  self["keyRed"].show()
  FFbJWj(self["keyGreen"] , "< > Transp.")
  FFbJWj(self["keyYellow"], "Foreground")
  FFbJWj(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(VV6Kiq,
  {
   "ok"   : self.VVBCxn     ,
   "green"   : self.VVBCxn     ,
   "yellow"  : BF(self.VVYgcU, False)  ,
   "blue"   : BF(self.VVYgcU, True)  ,
   "up"   : self.VVNU12       ,
   "down"   : self.VV4R52      ,
   "left"   : self.VVzWM3      ,
   "right"   : self.VVAwZj      ,
   "last"   : BF(self.VVL8tc, -5) ,
   "next"   : BF(self.VVL8tc, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VVg3Fx)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FF21Xy(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FF21Xy(self["keyRed"] , c)
  FF21Xy(self["keyGreen"] , c)
  self.VVWtcj()
  self.VVb9sX()
  FFtmqG(self["myColorTst"], self.defFG)
  FF21Xy(self["myColorTst"], self.defBG)
 def VVPAZ3(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVb9sX(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVUhcN(0, 0)
     return
 def VVBCxn(self):
  self.close(self.defFG, self.defBG)
 def VVNU12(self): self.VVUhcN(-1, 0)
 def VV4R52(self): self.VVUhcN(1, 0)
 def VVzWM3(self): self.VVUhcN(0, -1)
 def VVAwZj(self): self.VVUhcN(0, 1)
 def VVUhcN(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVSf4x()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VV5EkJ()
 def VVWtcj(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VV5EkJ(self):
  color = self.VVSf4x()
  if self.isBgMode: FF21Xy(self["myColorTst"], color)
  else   : FFtmqG(self["myColorTst"], color)
 def VVYgcU(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVWtcj()
   self.VVb9sX()
 def VVL8tc(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVUhcN(0, 0)
 def VVkVya(self):
  return hex(self.transp)[2:].zfill(2)
 def VVSf4x(self):
  return ("#%s%s" % (self.VVkVya(), self.colors[self.curRow][self.curCol])).upper()
class CCA1Ob(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFLEcJ(VV7zQY, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFCOTe(self, title="%s%s%s" % (self.Title, " " * 10, FFEK4e("Change values with Up , Down, < , 0 , >", VVhSN2)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(VV6Kiq,
  {
   "ok"  : self.VVLgni      ,
   "cancel" : self.VV3q1m      ,
   "info"  : self.VVbWxX    ,
   "red"  : self.VVAixu  ,
   "green"  : self.VVxGGp   ,
   "yellow" : BF(self.VVOyCP, 0)  ,
   "blue"  : self.VVeWd5    ,
   "menu"  : self.VVnDAb      ,
   "left"  : self.VVzWM3      ,
   "right"  : self.VVAwZj      ,
   "last"  : self.VVJtPC     ,
   "next"  : self.VVqgHk     ,
   "0"   : self.VVRkwz    ,
   "up"  : self.VVNU12       ,
   "down"  : self.VV4R52      ,
   "pageUp" : BF(self.VV8wBI, True) ,
   "pageDown" : BF(self.VV8wBI, False) ,
   "chanUp" : BF(self.VV8wBI, True) ,
   "chanDown" : BF(self.VV8wBI, False) ,
   "play"  : BF(self.VVLyLC, "pause")  ,
   "pause"  : BF(self.VVLyLC, "pause")  ,
   "playPause" : BF(self.VVLyLC, "pause")  ,
   "stop"  : BF(self.VVLyLC, "pause")  ,
   "audio"  : BF(self.VVLyLC, "audio")  ,
   "subtitle" : BF(self.VVLyLC, "subtitle") ,
   "rewind" : BF(self.VVLyLC, "rewind" ) ,
   "forward" : BF(self.VVLyLC, "forward" ) ,
   "rewindDm" : BF(self.VVLyLC, "rewindDm") ,
   "forwardDm" : BF(self.VVLyLC, "forwardDm")
  }, -1)
  self.VVdw8r()
  self.onShown.append(self.VVg3Fx)
  self.onClose.append(self.VVFs6H)
 def VVdw8r(self):
  lst = []
  for fil in FFqy37(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VV5uhb:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VVg3Fx(self):
  self.onShown.remove(self.VVg3Fx)
  FFOuQx(self)
  FF9NP9(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VV2ABI()
  self.VVqvp3()
  self.VVVYnw()
 def VVFs6H(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVXW2n(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FF21Xy(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVIiWm()
 def VV2ABI(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FF21Xy(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVLgni(self):
  if self.settingShown:
   confItem = self.VVw8n3()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVGIDM = []
   if isinstance(lst[0], tuple):
    for item in lst: VVGIDM.append((item[1], item[0]))
   else:
    for item in lst: VVGIDM.append((item, item))
   VVXrLB = FFzctu(self, self.VVaRex, VVGIDM=VVGIDM, width=700, title=title, VVXsDY="#33221111", VVEEoV="#33110011")
   VVXrLB.VVJSVD(confItem.getText())
  else:
   self.close("subtExit")
 def VVaRex(self, item=None):
  if item:
   self.VVw8n3()[self.CursorPos].setValue(item)
   self.VVIiWm()
   self.VVqvp3()
   self.VVqEvt(True)
 def VV3q1m(self):
  for confItem in self.VVw8n3():
   if confItem.isChanged():
    FFP9Be(self, BF(self.VVEXGk, cbFnc=self.VVauwV), "Save Changes ?", callBack_No=self.VVP5Eq, title=self.Title)
    break
  else:
   self.VVauwV()
 def VVauwV(self):
   if self.settingShown: self.VV2ABI()
   else    : self.close("subtExit")
 def VVnDAb(self):
  if self.settingShown: self.VV76LO()
  else    : self.VVXW2n()
 def VVzWM3(self): self.VVfqMg(-1)
 def VVAwZj(self): self.VVfqMg(1)
 def VVfqMg(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVwYIb()
   if pos == -1: ndx = self.VVR62n(posVal)
   else  : ndx = self.VV9zpW(posVal)
   if   ndx < 0      : FFqgHP(self, "Not found" , 500)
   elif ndx == 0      : FFqgHP(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFqgHP(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVFjaa(frmSec)
    if allow:
     self.VVOyCP(delay, True)
     self.VVqEvt(force=True)
     CCRdl4(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFqgHP(self, "Delay out of range", 800)
 def VV8wBI(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVLyLC(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVJtPC(self) : self.VVnY0Q(5)
 def VVqgHk(self) : self.VVnY0Q(6)
 def VVRkwz(self) : self.VVnY0Q(-1)
 def VVNU12(self):
  if self.settingShown: self.VVnY0Q(1)
  else    : self.VV8wBI(True)
 def VV4R52(self):
  if self.settingShown: self.VVnY0Q(0)
  else    : self.VV8wBI(False)
 def VVnY0Q(self, direction):
  if self.settingShown:
   confItem = self.VVw8n3()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVIiWm()
   self.VVqvp3()
   self.VVqEvt(True)
 def VVw8n3(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVP5Eq(self):
  for confItem in self.VVw8n3(): confItem.cancel()
  self.VVIiWm()
  self.VVqvp3()
  self.VV2ABI()
 def VVAixu(self):
  if self.settingShown:
   FFP9Be(self, self.VVWXuY, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVWXuY(self):
  for confItem in self.VVw8n3(): confItem.setValue(confItem.default)
  self.VVEXGk()
  self.VVIiWm()
  self.VVqvp3()
 def VVOyCP(self, delay, force=False):
  if self.settingShown or force:
   FFSKZx(CFG.subtDelaySec, delay)
   self.VVfYrd()
   self.VVIiWm()
   self.VVqvp3()
   if self.settingShown:
    FFqgHP(self, 'Reset to "0"', 800, isGrn=True)
 def VVxGGp(self):
  if self.settingShown:
   self.VVEXGk()
   self.VV2ABI()
 def VVEXGk(self, cbFnc=None):
  for confItem in self.VVw8n3(): confItem.save()
  configfile.save()
  self.VVfYrd()
  FFqgHP(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VVIiWm(self):
  cfgLst = self.VVw8n3()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVqvp3(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFgCge(path, fnt, isRepl=1)
  else:
   fnt = VVoGd5
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFOn9F(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFtmqG(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FF21Xy(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFn3C3(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFOn9F(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFiI6j()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFChi8(self, winW, winH)
 def VVbWxX(self):
  sp = "    "
  txt  = "%s\n"   % FFEK4e("Subtitle File:", VVfZXg)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFEK4e("Subtitle Settings:", VVfZXg)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVwYIb()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFTaUe(frmSec1)
   time2 = FFTaUe(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFEK4e("Timing:", VVfZXg)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFTaUe(durVal)
   txt += sp + "Progress\t: %s\n" % FFTaUe(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFEK4e("Subtitle end reached.", VVWEO1)
  FFDLqC(self, txt, title="Current Subtitle")
 def VVVYnw(self, path="", delay=0, enc=""):
  FFVCur(self, BF(self.VV6bpv, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VV6bpv(self, path="", delay=0, enc=""):
  FFqgHP(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVsyWs(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVIiWm()
     self.VV7AQc()
   else:
    path, delay, enc = CCA1Ob.VV8Drv(self)
    if path:
     self.VVVYnw(path=path, delay=delay, enc=enc)
    else:
     self.VV76LO()
  except:
   pass
 def VV7AQc(self):
  posVal, durVal = self.VVwYIb()
  if self.VVq9uV(posVal):
   return
  CCA1Ob.VVB7G7(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVqEvt)
  except:
   self.timerUpdate.callback.append(self.VVqEvt)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VV0ct1)
  except:
   self.timerEndText.callback.append(self.VV0ct1)
  FFqgHP(self, "Subtitle started", 700, isGrn=True)
 def VVq9uV(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCA1Ob.VVAJAp(self)
   FFbUco(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VV76LO(self):
  c1, c2, c3, c4, c5 = "", VVfZXg, VVZoWi, VVUVBT, VVWEO1
  VVGIDM = []
  VVGIDM.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVGIDM.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVGIDM.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVGIDM.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVGIDM.append(VVVgKz)
   VVGIDM.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVGIDM.append(VVVgKz)
   VVGIDM.append(("Help (Keys)"        , "help"  ))
  FFzctu(self, self.VVN0RI, VVGIDM=VVGIDM, width=700, title='Find Subtitle ".srt" File', VVXsDY="#33221111", VVEEoV="#33110011")
 def VVN0RI(self, item=None):
  if item:
   if   item == "allSrt"   : self.VV6wqN(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VV6wqN(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVq4fy, BF(CCLyBs, patternMode="srt", VV8MX1=sDir))
   elif item.startswith("sugSrt") : self.VV6wqN(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFVCur(self, BF(CCme0M.VVhV58, self, self.lastSubtFile, self.VV9Vlj, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFqgHP(self, "SRT File error", 1000)
   elif item == "disab":
    FFbUco(CCA1Ob.VVAJAp(self))
    self.close("subtExit")
   elif item == "help"    : FFog0j(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VV9Vlj(self, item=None):
  if item:
   FFVCur(self, BF(self.VVVYnw, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVq4fy(self, path):
  if path:
   FFSKZx(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVVYnw(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VV6wqN(self, defSrt="", mode=0, coeff=0.25):
  FFVCur(self, BF(self.VV4lP8, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VV4lP8(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCA1Ob.VVnqUJ(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FF30Q2('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFRGqa(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVhyrv(srtList, coeff)
     if err:
      if self.settingShown: FFe82w(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVnhmb = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FF80Mz(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVnhmb.append((fName, Dir))
   VVRWOd  = ("Select"    , self.VVr3UO     , [])
   VVU1op = self.VVy53Y
   VVMOfU = (""     , self.VVKUUY       , [])
   VV6aZX = (""     , BF(self.VVyYDT, defSrt, False) , [])
   VVoXaA = ("Find Current File" , BF(self.VVyYDT, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVbiLs=widths, VVNdFV=28, VVRWOd=VVRWOd, VVU1op=VVU1op, VVMOfU=VVMOfU, VV6aZX=VV6aZX, VVoXaA=VVoXaA, lastFindConfigObj=CFG.lastFindSubtitle
     , VVXsDY="#11002222", VVEEoV="#33001111", VVasam="#33001111", VVPYhe="#11ffff00", VVhaQs="#11445544", VVAXDQ="#22222222", VVilD4="#11002233")
  elif self.settingShown : FFe82w(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVy53Y(self, VVxL8T):
  VVxL8T.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVKUUY(self, VVxL8T, title, txt, colList):
  fName, Dir = colList
  FFDLqC(VVxL8T, "%s\n\n%s%s" % (FFEK4e("Path:", VVfZXg), Dir, fName), title=title)
 def VVyYDT(self, path, VVO6nE, VVxL8T, title, txt, colList):
  for ndx, row in enumerate(VVxL8T.VVWcfU()):
   if path == row[1].strip() + row[0].strip():
    VVxL8T.VVyaYN(ndx)
    break
  else:
   if VVO6nE:
    FFqgHP(VVxL8T, "Not in list !", 1000)
 def VVr3UO(self, VVxL8T, title, txt, colList):
  VVxL8T.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVVYnw(path=path)
 def VVhyrv(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCgL5j.VVA7Lr(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCgL5j.VVdXAa(evName, "en")[0] or evName
   lst, err = CCA1Ob.VVG9jb(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVsyWs(self, path, enc=None):
  if enc and CCme0M.VVZsja(path, enc)      : enc = enc
  elif CCme0M.VVZsja(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFl8II(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FF5p6q(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVIf26(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVD7Gx(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVfYrd()
  return subtList, ""
 def VVD7Gx(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVIf26(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVfYrd(self):
  path = CCA1Ob.VVAJAp(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVqEvt(self, force=False):
  posVal, durVal = self.VVwYIb()
  if self.VVq9uV(posVal):
   return
  curIndex = self.VVTVVU(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VV0ct1()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFtmqG(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVwYIb(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCTKa3.VV2yL9(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCgL5j.VVA7Lr(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVTVVU(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVR62n(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VV9zpW(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VV0ct1(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFtmqG(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVeWd5(self):
  FFVCur(self, self.VVU6O6, title="Loading Lines ...")
 def VVU6O6(self):
  VVnhmb = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVnhmb.append((cap, FFTaUe(frm), str(frm), firstLine))
  if VVnhmb:
   title = "Select Current Subtitle Line"
   VVHQPO  = self.VVIACG
   VVU1op = self.VVWl99
   VVRWOd  = ("Select"   , self.VVBHFs , [title])
   VVoXaA = ("Current Line" , self.VVH8yi , [True])
   VVMCbu = ("Reset Delay" , self.VVURrp , [])
   VVUm5B = ("New Delay"  , self.VVkom6   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVyaAW  = (CENTER , CENTER, CENTER , LEFT    )
   VVxL8T = FFfJU2(self, None, title=title, header=header, VVZAt4=VVnhmb, VVyaAW=VVyaAW, VVbiLs=widths, VVNdFV=28, VVHQPO=VVHQPO, VVU1op=VVU1op, VVRWOd=VVRWOd, VVoXaA=VVoXaA, VVMCbu=VVMCbu, VVUm5B=VVUm5B
          , VVXsDY="#33002222", VVEEoV="#33001111", VVasam="#33110011", VVPYhe="#11ffff00", VVhaQs="#0a334455", VVAXDQ="#22222222", VVilD4="#33002233")
  else:
   FFe82w(self, "Cannot read lines !", 2000)
 def VVIACG(self, VVxL8T):
  self.subtLinesTable = VVxL8T
  if CFG.subtDelaySec.getValue():
   VVxL8T["keyYellow"].show()
   VVxL8T["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVxL8T["keyYellow"].hide()
  VVxL8T["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FF21Xy(VVxL8T["keyBlue"], "#22222222")
  VVxL8T.VVa866(BF(self.VVfjlt, VVxL8T))
  self.VVH8yi(VVxL8T, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVNSPu)
  except:
   self.timerSubtLines.callback.append(self.VVNSPu)
  self.timerSubtLines.start(1000, False)
 def VVWl99(self, VVxL8T):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVxL8T.cancel()
 def VVNSPu(self):
  if self.subtLinesTable:
   VVxL8T = self.subtLinesTable
   posVal, durVal = self.VVwYIb()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVTVVU(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVxL8T.VVtH1g(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVxL8T.VVk6Jb(self.subtLinesTableNdx, row)
     row = VVxL8T.VVtH1g(curIndex)
     row[0] = color + row[0]
     VVxL8T.VVk6Jb(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVBHFs(self, VVxL8T, Title):
  delay, color, allow = self.VV4u4m(VVxL8T)
  if allow:
   self.VVWl99(VVxL8T)
   self.VVOyCP(delay, True)
  else:
   FFqgHP(VVxL8T, "Delay out of range", 1500)
 def VVH8yi(self, VVxL8T, VVO6nE, onlyColor=False):
  if VVxL8T:
   posVal, durVal = self.VVwYIb()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVTVVU(posVal)
    if curIndex > -1:
     VVxL8T.VVyaYN(curIndex)
    else:
     ndx = self.VVR62n(posVal)
     if ndx > -1:
      VVxL8T.VVyaYN(ndx)
 def VVURrp(self, VVxL8T, title, txt, colList):
  if VVxL8T["keyYellow"].getVisible():
   self.VVOyCP(0, True)
   VVxL8T["keyYellow"].hide()
   self.VVH8yi(VVxL8T, False)
 def VVfjlt(self, VVxL8T):
  delay, color, allow = self.VV4u4m(VVxL8T)
  VVxL8T["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VV4u4m(self, VVxL8T):
  lineTime = float(VVxL8T.VVoYvr()[2].strip())
  return self.VVFjaa(lineTime)
 def VVFjaa(self, lineTime):
  posVal, durVal = self.VVwYIb()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVUrbH
   else     : allow, color = False, VVWEO1
   delay = FFEApF(val, -600, 600)
  return delay, color, allow
 def VVkom6(self, VVxL8T, title, txt, colList):
  pass
 @staticmethod
 def VVGqV6(SELF):
  path, delay, enc = CCA1Ob.VV8Drv(SELF)
  return True if path else False
 @staticmethod
 def VV8Drv(SELF):
  path, delay, enc = CCA1Ob.VV6eWN(SELF)
  if not path:
   path = CCA1Ob.VV8nUT(SELF)
  return path, delay, enc
 @staticmethod
 def VV6eWN(SELF):
  srtCfgPath = CCA1Ob.VVAJAp(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FF5p6q(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVAJAp(SELF):
  fPath, fDir, fName = CCLyBs.VVK93s(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCgL5j.VVA7Lr(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFzMYS(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VV8nUT(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCLyBs.VVK93s(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCA1Ob.VVnqUJ(SELF)
    bLst, err = CCA1Ob.VVG9jb(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVnqUJ(SELF):
  fPath, fDir, fName = CCLyBs.VVK93s(SELF)
  if pathExists(fDir):
   files = FFqy37(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVG9jb(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVP0hS():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVB7G7(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCA1Ob.VVfFAF()
 @staticmethod
 def VVfFAF():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCIn9L(ScrollLabel):
 def __init__(self, parentSELF, text="", VVJuEg=True):
  ScrollLabel.__init__(self, text)
  self.VVJuEg   = VVJuEg
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVRdvk  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVNdFV    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(VV6Kiq,
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVcQD0 ,
   "green"   : self.VVJwBx ,
   "yellow"  : self.VVxcf7 ,
   "blue"   : self.VVXXBj ,
   "up"   : self.VV1nfR   ,
   "down"   : self.VVEwYo  ,
   "left"   : self.VV1nfR   ,
   "right"   : self.VVEwYo  ,
   "last"   : BF(self.VV7kUF, 0) ,
   "0"    : BF(self.VV7kUF, 1) ,
   "next"   : BF(self.VV7kUF, 2) ,
   "pageUp"  : self.VV9CWx   ,
   "chanUp"  : self.VV9CWx   ,
   "pageDown"  : self.VVuy7Y   ,
   "chanDown"  : self.VVuy7Y
  }, -1)
 def VVSAed(self, isResizable=True, VVijyJ=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFtmqG(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FF21Xy(self.parentSELF["keyRedTop"], "#113A5365")
  FFOuQx(self.parentSELF, True)
  self.isResizable = isResizable
  if VVijyJ:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVNdFV  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FF21Xy(self, color)
 def VVLGbZ(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVN35T  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVN35T)
  margin   = int(VVN35T / 6)
  self.pageHeight = int(self.pageLines * VVN35T)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVRdvk - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVcXXH()
 def VV1nfR(self):
  if self.VVRdvk > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVEwYo(self):
  if self.VVRdvk > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VV9CWx(self):
  self.setPos(0)
 def VVuy7Y(self):
  self.setPos(self.VVRdvk-self.pageHeight)
 def VVgUjU(self):
  return self.VVRdvk <= self.pageHeight or self.curPos == self.VVRdvk - self.pageHeight
 def getText(self):
  return self.message
 def VVcXXH(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVRdvk, 3))
   start = int((100 - vis) * self.curPos / (self.VVRdvk - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVvR9T=VVV4jO):
  old_VVgUjU = self.VVgUjU()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVRdvk = self.long_text.calculateSize().height()
   if self.VVJuEg and self.VVRdvk > self.pageHeight:
    self.scrollbar.show()
    self.VVcXXH()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVRdvk))
    self.VVRdvk = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVRdvk))
   else:
    self.scrollbar.hide()
   if   VVvR9T == VVzxgP: self.setPos(0)
   elif VVvR9T == VVlduB : self.VVuy7Y()
   elif old_VVgUjU    : self.VVuy7Y()
 def appendText(self, text, VVvR9T=VVlduB):
  self.setText(self.message + str(text), VVvR9T=VVvR9T)
 def VVxcf7(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVluQx(size)
 def VVXXBj(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVluQx(size)
 def VVJwBx(self):
  self.VVluQx(self.VVNdFV)
 def VVluQx(self, VVNdFV):
  self.long_text.setFont(gFont(self.fontFamily, VVNdFV))
  self.setText(self.message, VVvR9T=VVV4jO)
  self.VVT70L()
 def VV7kUF(self, align):
  self.long_text.setHAlign(align)
 def VVcQD0(self):
  VVGIDM = []
  VVGIDM.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Align Left" , "left" ))
  VVGIDM.append(("Align Center" , "center" ))
  VVGIDM.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVGIDM.append(VVVgKz)
   VVGIDM.append((FFEK4e("Save to File", VVfZXg), "save"))
  VVGIDM.append(VVVgKz)
  VVGIDM.append(("Keys (Shortcuts)", "help"))
  FFzctu(self.parentSELF, self.VVcBVB, VVGIDM=VVGIDM, title="Text Option", width=500)
 def VVcBVB(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VV7kUF(0)
   elif item == "center" : self.VV7kUF(1)
   elif item == "right" : self.VV7kUF(2)
   elif item == "save"  : self.VVA6JB()
   elif item == "help"  : FFog0j(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVA6JB(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FF80Mz(expPath), self.outputFileToSave, FFOa0m())
   with open(outF, "w") as f:
    f.write(FFLKj3(self.message))
   FF6mzu(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFryuM(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVT70L(self, minHeight=0):
  if self.isResizable:
   VVN35T = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVN35T * (len(self.message.splitlines()) + 1))
   if textH < self.pageHeight and self.VVRdvk < self.pageHeight:
    textH = max(textH, self.VVRdvk)
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
