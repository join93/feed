import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVDJVr   = "v8.8.2"
VVKetr    = "17-03-2023"
EASY_MODE    = 0
VVXTsW   = 0
TEST_FUNCTION   = 0
VVJT98  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVU7z8  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVzbRf    = "/media/usb/"
VVbph6    = "/usr/share/enigma2/picon/"
VVhrYS = "/etc/enigma2/blacklist"
VV7aeL   = "/etc/enigma2/"
VV9Vh8   = "AJPan"
VVikmx  = "AUTO FIND"
VVRtvF  = "Custom"
VV5BEv  = None
VVWcGv    = ""
VVTiT1 = "Regular"
VVbwkZ = "Fixed"
VV2uAD  = "AJP_Main"
VVVJVw = "AJP_Terminal"
VVZKiY = "AJP_System"
VVQgMh  = VVTiT1
VVYUMo    = ""
VV6Dap   = " && echo 'Successful' || echo 'Failed!'"
VV7PZ9  = "Cannot continue (No Enough Memory) !"
VVbCEM  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVO7iZ    = ["KeyMap_RC", "KeyMap_KeyBoard"]
VVsrqw  = "utf8"
VVh3VV    = ("-" * 100, )
SEP      = "-" * 80
VV0GEW  = False
VVNHHG  = False
VVL2J2     = 0
VV79iE    = 1
VVNiyR    = 2
VVFLUo   = 3
VVCp4o    = 4
VVe902    = 5
VV3Zke = 6
VVKs5Q = 7
VVWPLM  = 8
VVJrG6   = 9
VV9X8T  = 10
VVAccY  = 11
VVjv67 = 12
VVyzUX = 13
VVAbQS = 14
VVOhtp  = 15
VVWBOt    = 16
VVJh9Z   = 17
VVxBHE   = 18
VVUEeM    = 19
VVtwgT    = 20
VVJGdz  = 21
VVEosT    = 22
VVDwe9   = 0
VV8sAj   = 1
VVEkFU   = 2
def FFGXRt():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVQgMh
  if VV2uAD in lst and CFG.fontPathMain.getValue(): VVQgMh = VV2uAD
  else               : VVQgMh = VVTiT1
  return lst
 else:
  return [VVTiT1]
def FFJIrJ(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVsrqw)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVikmx, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelectionNumber(default=2, stepwidth=1, min=1, max=5, wraparound=False)
CFG.PIconsPath     = ConfigDirectory(default=VVbph6, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVzbRf, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.lastFindRepl_fnd   = ConfigText(default="")
CFG.lastFindRepl_rpl   = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVQgMh, choices=[(x,  x) for x in FFGXRt()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFNHvp():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVTmbp  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VVU92s = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVTmbp  : return 0
  elif VVU92s : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VVzsiD = FFNHvp()
VVi96Z = VVUpvF = VVKRbh = VVD46d = VVmxw7 = VVOICC = VVOIiN = VVLhUP = VVCKEk = VVs7I8 = VV0V0q = VVwwau = VVTVZG = VVquhO = VVDF46 = VVDysW = ""
def FFxWAa()  : FFS3tn(FFT4p4())
def FFdgxX()  : FFS3tn(FF0Aj6())
def FFK5cP(tDict): FFS3tn(iDumps(tDict, indent=4, sort_keys=True))
def FFJPpT(*args): FFS6Pz(True, True, *args)
def FFS3tn(*args) : FFS6Pz(True , False , *args)
def FFLNvW(*args): FFS6Pz(False, False, *args)
def FFS6Pz(addSep=True, isArray=True, *args):
 if VVXTsW:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFwb4O(fnc):
 def VVJlbb(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFS3tn(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VVJlbb
def FFiKNA(*args):
 if VVXTsW:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FFLNvW("Added to : %s" % path)
def FFshY8(txt, isAppend=True, ignoreErr=False):
 if VVXTsW:
  tm = FF8t1V()
  err = ""
  if not ignoreErr:
   err = FF0Aj6()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFS3tn(err)
  FFS3tn("Output Log File : %s" % fileName)
def FF0Aj6():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FF8t1V()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFT4p4():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVToRf = 0
def FFpwxi():
 global VVToRf
 VVToRf = iTime()
def FF1FSr(txt=""):
 FFS3tn(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVToRf)).rstrip("0"), txt))
VVeCJX = []
def FF5mrw(win):
 global VVeCJX
 if not win in VVeCJX:
  VVeCJX.append(win)
def FFarAp(*args):
 global VVeCJX
 for win in VVeCJX:
  try:
   win.close()
  except:
   pass
 VVeCJX = []
def FFNb6h(vTxt):
 if vTxt in globals(): del globals()[vTxt]
def FFXeI2():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVG5hg = FFXeI2()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFznWq()    : return PluginDescriptor(fnc=FFqrc7, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FF9m6q()      : return getDescriptor(FF2vBD , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FF6fNt()     : return getDescriptor(FFnDEM  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFafvn()  : return getDescriptor(FFUgWs, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FF09bq() : return getDescriptor(FFmMvH , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFFiDH()  : return getDescriptor(FFwgf7 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFChWK()  : return getDescriptor(FFYJm6  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFODSp() : return getDescriptor(FFyHmI , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Terminal"    , descr="Terminal")
def FFvvnC()      : return getDescriptor(FFsF5j, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FF6fNt() , FF9m6q() , FFznWq() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFafvn())
  result.append(FF09bq())
  result.append(FFFiDH())
  result.append(FFChWK())
  result.append(FFODSp())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFvvnC())
 return result
def FFqrc7(reason, **kwargs):
 if reason == 0:
  CCpbsN.VVU4O9()
  if "session" in kwargs:
   session = kwargs["session"]
   FFPicX(session)
   CCZJL4(session)
def FF2vBD(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFnDEM, PLUGIN_NAME, 45)]
 else:
  return []
def FFnDEM(session, **kwargs):
 session.open(Main_Menu)
def FFUgWs(session, **kwargs): session.open(CC5iId)
def FFmMvH(session, **kwargs) : session.open(CCnYqq)
def FFwgf7(session, **kwargs) : CCQFZI.VVbh0Z(session)
def FFYJm6(session, **kwargs)  : FF1dfA(session, reopen=True)
def FFyHmI(session, **kwargs) : session.open(CCPRQ8)
def FFsF5j(session, **kwargs):
 session.open(CCFLza, fncMode=CCFLza.VVO8n6)
def FFvzUJ():
 FFwJQK(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [FFafvn(), FF09bq(), FFFiDH(), FFChWK(), FFODSp()])
 FFwJQK(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFvvnC() ])
def FFwJQK(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFPicX(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFSILG, session, "lok")
 hk.actions["longCancel"]= BF(FFSILG, session, "lesc")
 hk.actions["longRed"] = BF(FFSILG, session, "lred")
 for k in (CC7MvF.VVxskn, CC7MvF.VVvdB1, CC7MvF.VVMOSi):
  hk.actions[k] = BF(CC7MvF.VVKOw2, session, k)
def FFSILG(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCRQgm.VVHrDa:
    CCRQgm.VVHrDa.close()
   if not CCQFZI.VVU617:
    CCQFZI.VVbh0Z(session)
  except:
   pass
def FFSeyu(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFd98D(SELF, title="", addLabel=False, addScrollLabel=False, VVtZf8=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFwW71()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VVjD4Y = eTimer()
 try: SELF.VVWrvF = SELF.VVjD4Y.timeout.connect(BF(FFX445, SELF))
 except: SELF.VVjD4Y.callback.append(BF(FFX445, SELF))
 SELF.onClose.append(SELF.VVjD4Y.stop)
 FFX445(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CC0aUK(SELF)
 if VVtZf8:
  SELF["myMenu"] = MenuList(VVtZf8)
  SELF["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok" : SELF.VVnIt0 ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(VVO7iZ,
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FFcKND(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFExP1, SELF, "0"),
  "1" : BF(FFExP1, SELF, "1"),
  "2" : BF(FFExP1, SELF, "2"),
  "3" : BF(FFExP1, SELF, "3"),
  "4" : BF(FFExP1, SELF, "4"),
  "5" : BF(FFExP1, SELF, "5"),
  "6" : BF(FFExP1, SELF, "6"),
  "7" : BF(FFExP1, SELF, "7"),
  "8" : BF(FFExP1, SELF, "8"),
  "9" : BF(FFExP1, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FFwKej, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFExP1(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVDysW:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVDysW + SELF.keyPressed + VVUpvF)
    txt = VVUpvF + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FFrBcM(SELF, txt)
def FFwKej(SELF, tableObj, colNum, isMenu):
 FFrBcM(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFpnOy(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VVIgUV(i)
     else  : SELF.VV8i74(i)
     break
 except:
  pass
def FFwW71():
 return ("  %s" % VVYUMo)
def FF1N71(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFpnOy(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFV5jv(color):
 return parseColor(color).argb()
def FFBe4X(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFwVrd(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFxUjm(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFPk5q(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVDysW)
 else:
  return ""
def FF9OqO(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VVDysW)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FFxrb0(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVDysW
def FFdk7R(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFPk5q(SEP, VV0V0q))
 else : return "echo -e '%s';" % SEP
def FFElFp(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FFxrb0(title, color)
def FFzlUl(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFfsUc(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFb5Nn(fncCB):
 tCons = CC6Ith()
 tCons.ePopen(":", BF(FF0I1n, fncCB))
def FF0I1n(fncCB, result, retval):
 fncCB()
def FFn5td(SELF, fnc, title="Processing ...", clearMsg=True):
 FFrBcM(SELF, title)
 tCons = CC6Ith()
 tCons.ePopen(":", BF(FF83w1, SELF, fnc, clearMsg))
def FF83w1(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FFrBcM(SELF)
def FFHFMV(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VV7PZ9
  else       : return ""
def FFIM7p(cmd):
 txt = FFHFMV(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FFz86l(cmd):
 lines = FFIM7p(cmd)
 if lines: return lines[0]
 else : return ""
def FFvd5Q(SELF, cmd):
 lines = FFIM7p(cmd)
 VVaKg1 = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVaKg1.append((key, val))
  elif line:
   VVaKg1.append((line, ""))
 if VVaKg1:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FFuI68(SELF, None, header=header, VVBQW6=VVaKg1, VV3FCq=widths, VVJgEp=28)
 else:
  FFlHGt(SELF, cmd)
def FFkQDN(cmd):
 return os.system(FFaBql(cmd)) == 0
def FFnedc(cmd):
 return os.system(FFIjyj(cmd)) == 0
def FFaBql(cmd)  : return cmd.rstrip("\t; ") + " > /dev/null 2>&1;"
def FFIjyj(cmd) : return cmd.rstrip("\t; ") + " 2> /dev/null;"
def FFlHGt(    SELF, cmd, **kwargs): SELF.session.open(CCIYpr, VVaRoH=cmd, VVSoxh=True, VVeLJi=VV8sAj, **kwargs)
def FFtL5B(  SELF, cmd, **kwargs): SELF.session.open(CCIYpr, VVaRoH=cmd, **kwargs)
def FFxN9O(   SELF, cmd, **kwargs): SELF.session.open(CCIYpr, VVaRoH=cmd, VVjU5M=True, VV9gso=True, VVeLJi=VV8sAj, **kwargs)
def FFQwGu(  SELF, cmd, **kwargs): SELF.session.open(CCIYpr, VVaRoH=cmd, VVjU5M=True, VV9gso=True, VVeLJi=VVEkFU, **kwargs)
def FFeWwS(  SELF, cmd, **kwargs): SELF.session.open(CCIYpr, VVaRoH=cmd, VVsjuE=True , **kwargs)
def FFxH1w(  session, cmd, **kwargs):      session.open(CCIYpr, VVaRoH=cmd, VVsjuE=True , **kwargs)
def FFA1zG( SELF, cmd, **kwargs): SELF.session.open(CCIYpr, VVaRoH=cmd, VVCjpM=True   , **kwargs)
def FFvqDM( SELF, cmd, **kwargs): SELF.session.open(CCIYpr, VVaRoH=cmd, VVnFNI=True  , **kwargs)
def FFtTXa(cmd):
 return FFkQDN("which %s" % cmd)
def FFNDlH():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FFz86l(cmd)
def FFwS2p(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VV63qG     = 0
VVFU7m      = 1
VV5oWt   = 2
VVbOZm   = 3
VVl8YC      = 4
VVDid1      = 5
VVCyBl     = 6
VVm1XS     = 7
VV6ESW     = 8
VVJxPG = 9
VVhXh6 = 10
VVQjjG = 11
VVlHps  = 12
VV2r4e     = 13
VVyJXQ  = 14
VV2nyt  = 15
def FFYH4A(parmNum, grepTxt):
 if   parmNum == VV63qG  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVFU7m   : param = ["list"   , "apt list"    ]
 elif parmNum == VV5oWt: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVbOZm: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFNDlH()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFgOTM(parmNum, package):
 if   parmNum == VVl8YC      : param = ["info"      , "apt show"         ]
 elif parmNum == VVDid1      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVCyBl     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVm1XS     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VV6ESW     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVJxPG : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VVhXh6 : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVQjjG : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVlHps  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VV2r4e     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVyJXQ  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV2nyt  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFNDlH()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFJDAH():
 result = FFz86l("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFgOTM(VV6ESW, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFaBql("%s enigma2-plugin-extensions-opkg-tools" % installCmd)
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFaBql("%s binutils" % installCmd)
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFPk5q(failed1, VV0V0q))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFPk5q(failed2, VV0V0q))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFPk5q(failed3, VVKRbh))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FFhejV(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFgOTM(VV6ESW , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFaBql("%s %s" % (installCmd, toolPkgName))
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFPk5q(failed1, VV0V0q))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFPk5q(failed2, VVKRbh))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFl3Sc(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCiVik.VVAo1j()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFMy5k(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFl3Sc(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FF5vJp(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFotbw(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFl3Sc(path, maxSize=maxSize, encLst=encLst)
  if lines: FFVBx2(SELF, lines, title=title, VVeLJi=VV8sAj, width=1600, height=1000, titleFontSize=30)
  else : FF0v65(SELF, path, title=title)
 else:
  FFPQyp(SELF, path, title)
def FF4fCC(SELF, fName, title):
 path = VVG8hM + fName
 if fileExists(path):
  txt = FFl3Sc(path)
  txt = txt.replace("#W#", VVDysW)
  txt = txt.replace("#Y#", VVwwau)
  txt = txt.replace("#G#", VVUpvF)
  txt = txt.replace("#C#", VVTVZG)
  txt = txt.replace("#P#", VVmxw7)
  FFVBx2(SELF, txt, title=title)
 else:
  FFPQyp(SELF, path, title)
def FFmn2G(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FFghFX(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF9GYH(parent)
 else    : return FF3NDk(parent)
def FFzOGe(path):
 return os.path.basename(os.path.normpath(path))
def FF4Qy8(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFotbw(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFvYBl(path):
 path = FF3NDk(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFQzS1(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FFFX6Q(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFKqXn(path):
 try: os.remove(path)
 except: pass
def FF4xUI(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FFFFoV(path):
 return FFkQDN("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFmO9U(path):
 return FFkQDN("cp -f '%s' '%s.bak'" % (path, path))
def FF9GYH(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FF3NDk(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFsitY():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVJT98)
 paths.append(VVJT98.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FFmn2G(ba)
 for p in list:
  p = ba + p + VVJT98
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV9Vh8, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVJT98, VV9Vh8 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VV1fMY, VVG8hM = FFsitY()
def FFCdSV():
 def VVpsxl(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVHk5b   = VVpsxl(CFG.backupPath, CChKAm.VVOMtU())
 VVLBqb   = VVpsxl(CFG.downloadedPackagesPath, t)
 VVvxeY  = VVpsxl(CFG.exportedTablesPath, t)
 VVap1e  = VVpsxl(CFG.exportedPIconsPath, t)
 VVO8t3   = VVpsxl(CFG.packageOutputPath, t)
 global VVzbRf
 VVzbRf = FF9GYH(CFG.backupPath.getValue())
 if VVHk5b or VVO8t3 or VVLBqb or VVvxeY or VVap1e or oldMovieDownloadPath:
  configfile.save()
 return VVHk5b, VVO8t3, VVLBqb, VVvxeY, VVap1e, oldMovieDownloadPath
def FFpoSU(path):
 path = FF3NDk(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFStK7(SELF, pathList, tarFileName, addTimeStamp=True):
 VVBQW6 = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVBQW6.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVBQW6.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVBQW6.append(path)
 if not VVBQW6:
  FFBsVa(SELF, "Files not found!")
 elif not pathExists(VVzbRf):
  FFBsVa(SELF, "Path not found!\n\n%s" % VVzbRf)
 else:
  VVMwIx = FF9GYH(VVzbRf)
  tarFileName = "%s%s" % (VVMwIx, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FF0Isj())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVBQW6:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFPk5q(tarFileName, VVCKEk))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFPk5q(failed, VVCKEk))
  cmd += "fi;"
  cmd +=  sep
  FFtL5B(SELF, cmd)
def FFD5nM(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFBFvR(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFBFvR(SELF["keyInfo"], "info")
def FFBFvR(barObj, fName):
 path = "%s%s%s" % (VVG8hM, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFM86X(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFxluq(satNum)
  return satName
def FFxluq(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFYMB2(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFM86X(val)
  else  : sat = FFxluq(val)
 return sat
def FF9eBo(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFM86X(num)
 except:
  pass
 return sat
def FFUL86(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFMcRT(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFlSvn(info, iServiceInformation.sServiceref)
   prov = FFlSvn(info, iServiceInformation.sProvider)
   state = str(FFlSvn(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FFAXDs(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFR5dT(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFlSvn(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFwFIz(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FF4x0v(refCode):
 info = FFJIwt(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFvzBx(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFt544(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FFJIwt(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVntaB = eServiceCenter.getInstance()
  if VVntaB:
   info = VVntaB.info(service)
 return info
def FFYeVI(SELF, refCode, VVY16B=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFR5dT(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCRdJH()
  if pr.VVIvWO(refCode1, chName, decodedUrl, iptvRef):
   if pr.VV7Ph5(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFgdxP(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVY16B:
   FFWcs1(SELF, isFromSession)
 try:
  VVjKXg = InfoBar.instance
  if VVjKXg:
   VVenrc = VVjKXg.servicelist
   if VVenrc:
    servRef = eServiceReference(refCode)
    VVenrc.saveChannel(servRef)
 except:
  pass
def FFgdxP(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCRdJH()
    if pr.VVIvWO(refCode, chName, decodedUrl, iptvRef):
     pr.VV7Ph5(SELF, isFromSession)
def FFAXDs(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFpPAo(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFbuxP(url): return FFimkp(url) or FFfMNU(url)
def FFimkp(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFfMNU(url): return any(x in url for x in ("/series/", "mode=series"))
def FFR5dT(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFXKeJ(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFXKeJ(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FF7xTp(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FF7iOc(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFyEub(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFa5RN(txt):
 try:
  return FF7iOc(FFyEub(txt)) == txt
 except:
  return False
def FF8hHp(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FF9GYH(newPath), patt))
def FFWcs1(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCQFZI.VVbh0Z(session)
 else      : FF1dfA(session, reopen=True)
def FF1dfA(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FF1dfA, session), CCRQgm)
  except:
   try:
    FFT9sG(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFoesm(refCode):
 tp = CCTy0v()
 if tp.VVEczv(refCode) : return True
 else        : return False
def FFsuwf(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFOnqc(True)
     return True
 return False
def FFOnqc(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FFl4sg()
def FFl4sg():
 VVjKXg = InfoBar.instance
 if VVjKXg:
  VVenrc = VVjKXg.servicelist
  if VVenrc:
   VVenrc.setMode()
def FFemXY(root, mode=0):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVntaB = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    flags = service.flags
    if mode == 0 and service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    ref, info = service.toString(), VVntaB.info(service)
    name = info.getName(service)
    if   mode == 0: lst.append((ref, name))
    elif mode == 1: lst.append((ref, name, flags))
 except:
  pass
 return lst
def FFD3Ic():
 VVNQex = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVTvZo = list(VVNQex)
 return VVTvZo, VVNQex
def FFbfAi():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFFvsp(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FF2ADr(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFByGk():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FF0Isj():
 return FFByGk().replace(" ", "_").replace("-", "").replace(":", "")
def FFNguX(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FF8t1V():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFjgmp(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CCnYqq.VVG1o6(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CCnYqq.VVwgy6(fName)
     phpFile = tmpDir + fName + ext
     FFkQDN("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFty8Y(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FFAHjU(num):
 return "s" if num > 1 else ""
def FFMpNv(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FFUY5i(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFPIiD(a, b):
 return (a > b) - (a < b)
def FFvHSH(a, b):
 def VVPYcT(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVPYcT(a)
 b = VVPYcT(b)
 return (a > b) - (a < b)
def FFKuFF(mycmp):
 class CCz1fx(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCz1fx
def FFx4Fl(SELF, message, title="", VVqhY7=None):
 SELF.session.openWithCallback(VVqhY7, CCoV76, title=title, message=message, VV8l2N=True)
def FFVBx2(SELF, message, title="", VVeLJi=VV8sAj, VVqhY7=None, **kwargs):
 SELF.session.openWithCallback(VVqhY7, CCoV76, title=title, message=message, VVeLJi=VVeLJi, **kwargs)
def FFZMMj(SELF, txt):
 SELF.session.open(CCpDJU, txt)
def FFBsVa(SELF, message, title="")  : FFT9sG(SELF.session, message, title)
def FFPQyp(SELF, path, title="") : FFT9sG(SELF.session, "File not found !\n\n%s" % path, title)
def FF0v65(SELF, path, title="") : FFT9sG(SELF.session, "File is empty !\n\n%s"  % path, title)
def FF5yx0(SELF, title="")  : FFT9sG(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFT9sG(session, message, title="") : session.open(BF(CCzS1c, title=title, message=message))
def FFsCnW(SELF, VVqhY7, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVqhY7, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVqhY7, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFBsVa(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFEN35(SELF, callBack_Yes, VVub3W, callBack_No=None, title="", VV00ww=False, VVls2R=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FF0Bhw, callBack_Yes, callBack_No)
         , BF(CCupAT, title=title, VVub3W=VVub3W, VVls2R=VVls2R, VV00ww=VV00ww))
def FF0Bhw(callBack_Yes, callBack_No, FFEN35ed):
 if FFEN35ed : callBack_Yes()
 elif callBack_No: callBack_No()
def FFrBcM(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFwVrd(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VVjD4Y.start(timeout, True)
  except: pass
 else: FFX445(SELF)
def FFQAm4(*kargs, **kwargs):
 FFb5Nn(BF(FFrBcM, *kargs, **kwargs))
def FFX445(SELF):
 try:
  SELF.VVjD4Y.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFgLwO(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FFuI68(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCLGNO, **kwargs))
  else   : win = SELF.session.open(BF(CCLGNO, **kwargs))
  FF5mrw(win)
  return win
 except:
  return None
def FFd7BR(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCeDmK, **kwargs))
 FF5mrw(win)
 return win
def FFbAzs(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFTjqa(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFqy2T(SELF, **kwargs):
 SELF.session.open(CCFLza, **kwargs)
def FFRet2(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFL9cN(SELF[name], "#000000", 3)
  except:
   pass
def FFL9cN(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFrgYT(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVQgMh, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFzxez(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFrgYT(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFM0oF(SELF, winSize.width(), winSize.height())
def FFM0oF(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FF3tfX():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFO4Er(VVJgEp):
 screenSize  = FF3tfX()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVJgEp)
 return bodyFontSize
def FFMSMB(VVJgEp, extraSpace):
 font = gFont(VVQgMh, VVJgEp)
 VV2u5U = fontRenderClass.getInstance().getLineHeight(font) or (VVJgEp * 1.25)
 return int(VV2u5U + VV2u5U * extraSpace)
def FF98gL(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FF3tfX()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVQgMh, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFMSMB(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVQgMh, titleFontSize, alignLeftCenter)
 if winType == VVEosT:
  pass
 elif winType in (VVL2J2, VV79iE):
  if winType == VV79iE : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VVJGdz:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVtwgT:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVQgMh, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVWBOt:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FFx4FlL = b2Left2 + timeW + marginLeft
  FFx4FlW = b2Left3 - marginLeft - FFx4FlL
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FFx4FlL , b2Top, FFx4FlW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVJh9Z:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVCp4o:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVNiyR:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVFLUo:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVQgMh, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVQgMh, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VV9X8T:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVQgMh, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVxBHE:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVQgMh, fontH, alignCenter)
 elif winType in (VVAccY, VVjv67, VVyzUX, VVAbQS, VVOhtp):
  if   winType == VVAccY  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVjv67 : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVyzUX : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VVAbQS : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVAccY:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVQgMh, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVQgMh, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVQgMh, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVQgMh, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVQgMh, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVQgMh, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVQgMh, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVUEeM:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVe902:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVKs5Q : align = alignLeftCenter
  elif winType == VV3Zke : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVJrG6:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVQgMh
  if usefixedFont and winType == VV3Zke:
   fLst = FFGXRt()
   if   VVVJVw in fLst and CFG.fontPathTerm.getValue(): fontName = VVVJVw
   elif VVbwkZ in fLst         : fontName = VVbwkZ
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVJgEp = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVQgMh, VVJgEp, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVQgMh, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VVbCEM[i], VVQgMh, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VV3Zke:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VVbCEM[i], VVQgMh, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVL2J2, 800, 1000, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVVI88 = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVDJVr)
  VVtZf8 = []
  if TEST_FUNCTION:
   VVtZf8.append(("-- MY TEST --", "myTest" ))
  VVtZf8.append(("File Manager"  , "fMan" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("IPTV"    , "iptv" ))
  VVtZf8.append(("Movies Browser" , "movie" ))
  VVtZf8.append(("Services/Channels", "chan" ))
  VVtZf8.append(("Bouquet Editor" , "bouq" ))
  VVtZf8.append(("PIcons"   , "picon" ))
  VVtZf8.append(("EPG"    , "epg"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Terminal"   , "term" ))
  VVtZf8.append(("SoftCam"   , "soft" ))
  VVtZf8.append(("Plugins"   , "plug" ))
  VVtZf8.append(("Backup & Restore" , "bakup" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Date/Time"  , "date" ))
  VVtZf8.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVtZf8):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVtZf8[ndx] = tuple(item)
  FFd98D(self, title=self.Title, VVtZf8=VVtZf8)
  FF1N71(self["keyRed"] , "Exit")
  FF1N71(self["keyGreen"] , "Settings")
  FF1N71(self["keyYellow"], "Dev. Info.")
  FF1N71(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVdkKr      ,
   "yellow": self.VV4vUP      ,
   "blue" : self.VVP9DG     ,
   "info" : BF(FFn5td, self, self.VVs0pm) ,
   "text" : self.VVYuZM      ,
   "menu" : self.VVTn7x    ,
   "0"  : BF(self.VVA402, 0)   ,
   "1"  : BF(self.VVUurL, "fMan")   ,
   "2"  : BF(self.VVUurL, "iptv")   ,
   "3"  : BF(self.VVUurL, "movie")   ,
   "4"  : BF(self.VVUurL, "chan")   ,
   "5"  : BF(self.VVUurL, "bouq")   ,
   "6"  : BF(self.VVUurL, "picon")   ,
   "7"  : BF(self.VVUurL, "epg")   ,
   "8"  : BF(self.VVUurL, "term")   ,
   "9"  : BF(self.VVUurL, "soft")   ,
   "last" : BF(self.VVUurL, "plug")   ,
   "next" : BF(self.VVUurL, "bakup")
  })
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
  global VV0GEW, VVNHHG, VVbP73
  VV0GEW = VVNHHG = False
  VVbP73 = True
 def VVnIt0(self):
  self.VVUurL(self["myMenu"].l.getCurrentSelection()[1])
 def VVUurL(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVYUMo
   VVYUMo = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVRSQg()
   elif item == "fMan"  : self.session.open(CC5iId)
   elif item == "iptv"  : self.session.open(CCnYqq)
   elif item == "movie" : FFn5td(self, BF(CCxhEJ.VVGTXv, self))
   elif item == "chan"  : self.session.open(CC8mGp)
   elif item == "bouq"  : self.session.open(CCG0xP)
   elif item == "picon" : self.VVlYak()
   elif item == "epg"  : self.session.open(CCNVQf)
   elif item == "term"  : self.session.open(CCPRQ8)
   elif item == "soft"  : self.session.open(CCyO3o)
   elif item == "plug"  : self.session.open(CCIU8A)
   elif item == "bakup" : self.session.open(CCZWLw)
   elif item == "date"  : self.session.open(CCXBmT)
   elif item == "net"  : self.session.open(CCgiFE)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
  FFRet2(self)
  FFD5nM(self)
  VVHk5b, VVO8t3, VVLBqb, VVvxeY, VVap1e, oldMovieDownloadPath = FFCdSV()
  if VVHk5b or VVO8t3 or VVLBqb or VVvxeY or VVap1e or oldMovieDownloadPath:
   VVIsuR = lambda path, subj: "%s:\n%s\n\n" % (subj, FFxrb0(path, VVD46d)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVIsuR(VVHk5b   , "Backup/Restore Path"    )
   txt += VVIsuR(VVO8t3  , "Created Package Files (IPK/DEB)" )
   txt += VVIsuR(VVLBqb  , "Download Packages (from feeds)" )
   txt += VVIsuR(VVvxeY , "Exported Tables"     )
   txt += VVIsuR(VVap1e , "Exported PIcons"     )
   txt += VVIsuR(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FFVBx2(self, txt, title="Settings Paths")
  self.VVBX1n()
  if (EASY_MODE or VVXTsW or TEST_FUNCTION):
   FFwVrd(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FFrBcM(self, "Welcome", 300)
  FFb5Nn(self.VV3uRW)
 def VV3uRW(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CChKAm.VVqYN6()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFkQDN("rm -f /tmp/ajp_*")
  global VV0GEW, VVNHHG
  VV0GEW = VVNHHG = False
  FFNb6h("VVbP73")
 def VVA402(self, digit):
  self.VVVI88 += str(digit)
  ln = len(self.VVVI88)
  global VV0GEW
  if ln == 4:
   if self.VVVI88 == "0" * ln:
    VV0GEW = True
    FFwVrd(self["myTitle"], "#11805040")
   else:
    self.VVVI88 = "x"
 def VVYuZM(self):
  self.VVVI88 += "t"
  if self.VVVI88 == "0" * 4 + "t" * 2:
   global VVNHHG
   VVNHHG = True
   FFwVrd(self["myTitle"], "#dd5588")
 def VVlYak(self):
  found = False
  pPath = CCjCYH.VVzyVV()
  if pathExists(pPath):
   for fName, fType in CCjCYH.VVBQXo(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCjCYH)
  else:
   VVtZf8 = []
   VVtZf8.append(("PIcons Tools" , "CCjCYH" ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(CCjCYH.VV3lz6())
   VVtZf8.append(VVh3VV)
   VVtZf8 += CCjCYH.VV1qZ7()
   FFd7BR(self, self.VVn39g, VVtZf8=VVtZf8)
 def VVn39g(self, item=None):
  if item:
   if   item == "CCjCYH"   : self.session.open(CCjCYH)
   elif item == "VVo4uj"  : CCjCYH.VVo4uj(self)
   elif item == "VVz7Fg"  : CCjCYH.VVz7Fg(self)
   elif item == "findPiconBrokenSymLinks" : CCjCYH.VV1Jui(self, True)
   elif item == "FindAllBrokenSymLinks" : CCjCYH.VV1Jui(self, False)
 def VVs0pm(self):
  changeLogFile = VVG8hM + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFMy5k(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFxrb0("\n%s\n%s\n%s" % (SEP, line, SEP), VV0V0q, VVDysW)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFxrb0(line, VVUpvF, VVDysW)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FFVBx2(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVDJVr, PLUGIN_DESCRIPTION), VVJgEp=28, width=1600, height=1000, VV84wP="#11000011")
 def VVTn7x(self):
  VVtZf8 = []
  VVtZf8.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Keys Help"     , "hlp" ))
  FFd7BR(self, self.VVVQ8L, VVtZf8=VVtZf8, width=650, title="Options")
 def VVVQ8L(self, item=None):
  if item:
   if   item == "libr" : FFn5td(self, BF(self.VV1czH))
   elif item == "hlp" : FF4fCC(self, "_help_main", "Main Page (Keys Help)")
 def VVdkKr(self) : self.session.open(CChKAm)
 def VV4vUP(self) : self.session.open(CCY0Fb)
 def VVP9DG(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVs7I8, VVD46d, VVwwau, VVOICC
  VVtZf8 = []
  VVtZf8.append((c1 + "Change Title Colors"   , "title"  ))
  VVtZf8.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVtZf8.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVtZf8.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVtZf8.append((c2 + "Reset Colors"    , "resetColor" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVtZf8.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c4 + "Change System Font"    , "sysFont"  ))
  FFd7BR(self, BF(self.VVrzoq, title), VVtZf8=VVtZf8, width=600, title=title)
 def VVrzoq(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VViGK4()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVqqjU, tDict, item), CCPUUw, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFEN35(self, self.VVZAv9, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVU8LD(VV2uAD  )
   elif item == "termFont"  : self.VVU8LD(VVVJVw)
   elif item == "sysFont"  : self.VVU8LD(VVZKiY  )
 def VV1czH(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVaKg1, pkgs = self.VVv2Qu()
  VVIZTW = ("Install", BF(self.VVfvsD, title, pkgs)  , [])
  VV6CVp  = ("Update Sys. Packages", self.VV0tyD , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVGQvW = (LEFT  , CENTER , LEFT  )
  VVzzNZ = FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=28, width=1350, VVIZTW=VVIZTW, VV6CVp=VV6CVp, VVH7qA="#00ffffaa", VVhEUu=1)
 def VVfvsD(self, Title, pkgs, VVzzNZ, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVHwvY, VVzzNZ)
   item = colList[0]
   if   item == "requests" : CC9WBQ.VVC1gJ(self, cbFnc=cbFnc)
   elif item == "Imaging" : CC7MvF.VVIckV(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FFeWwS(self, FFJDAH(), VVBjuq=cbFnc)
   elif item in pkgs  : FFeWwS(self, FFhejV(item, item, item.capitalize()), VVBjuq=cbFnc)
  else:
   FFrBcM(VVzzNZ, "Already installed.", 700, isGrn=True)
 def VV0tyD(self, VVzzNZ, title, txt, colList):
  CCIU8A.VVIc0h(self)
 def VVHwvY(self, VVzzNZ):
  VVaKg1, pkgs = self.VVv2Qu()
  VVzzNZ.VVUkGQ(VVaKg1[VVzzNZ.VVXRaz()])
 def VVv2Qu(self):
  tDict = {}
  path = VVG8hM + "_sup_lib"
  if fileExists(path):
   for line in FFMy5k(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVIsuR(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFxrb0("Installed", VVCKEk), txt)
   else : return (lib, FFxrb0("Not installed", VVKRbh), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVaKg1 = []
  VVaKg1.append(VVIsuR("requests", CC9WBQ.VVC1gJ(self, install=False)))
  VVaKg1.append(VVIsuR("Imaging" , CC7MvF.VVIckV(self, "", False, install=False)))
  VVaKg1.append(VVIsuR("ar"   , FFkQDN("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for item in pkgs: VVaKg1.append(VVIsuR(item, FFtTXa(item)))
  VVaKg1.sort(key=lambda x: x[0].lower())
  return VVaKg1, pkgs
 def VV4CO0(self):
  return VVzbRf + "ajpanel_colors"
 def VViGK4(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VV4CO0()
  if fileExists(p):
   txt = FFl3Sc(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVqqjU(self, tDict, item, fg, bg):
  if fg:
   self.VV4jnN(item, fg)
   self.VVZ3C8(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVILAq(tDict)
 def VVILAq(self, tDict):
   p = self.VV4CO0()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VV4jnN(self, item, fg):
  if   item == "title" : FFBe4X(self["myTitle"], fg)
  elif item == "body"  :
   FFBe4X(self["myMenu"], fg)
   FFBe4X(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFBe4X(self[item], fg)
 def VVZ3C8(self, item, bg):
  if   item == "title" : FFwVrd(self["myTitle"], bg)
  elif item == "body"  :
   FFwVrd(self["myMenu"], bg)
   FFwVrd(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFwVrd(self["myBar"], bg)
 def VVZAv9(self):
  FFkQDN("rm '%s'" % self.VV4CO0())
  self.close()
 def VVBX1n(self):
  tDict = self.VViGK4()
  for item in ("title", "body", "cursor", "bar"):
   self.VV2oqN(tDict, item)
 def VV2oqN(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VV4jnN(name, fg)
  if bg: self.VVZ3C8(name, bg)
 def VVU8LD(self, which):
  if   which == VV2uAD  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVVJVw : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VVZKiY  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CChIXk.VVkZ62(self, "Change %s Font" % title, defFnt, rest, BF(self.VVeh5j, which))
 def VVeh5j(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VV2uAD  : FFSeyu(CFG.fontPathMain, path)
   elif which == VVVJVw: FFSeyu(CFG.fontPathTerm, path)
   elif which == VVZKiY  : FFSeyu(CFG.fontPathSys , path)
   err = Main_Menu.VVggOs(which)
   if err          : FFBsVa(self, err, title=title)
   elif which == VV2uAD   : self.close()
   elif which == VVVJVw  : FFrBcM(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VVZKiY and path: FFrBcM(self, "System font applied", 1500, isGrn=True)
   elif which == VVZKiY   : FFEN35(self, BF(Main_Menu.VVCjpM, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVCjpM(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVggOs(name):
  if   name == VV2uAD : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVVJVw: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VVZKiY : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFGXRt()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VVZKiY:
   nameLst = []
   for nm in FFGXRt():
    if not nm in (VV2uAD, VVVJVw):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFJIrJ(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFGXRt()
  else    : return "Could not add font"
 def VVRSQg(self):
  self.session.open(CCG0xP)
class CCgiFE(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVL2J2, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVzbRf, "ajpanel_network")
  c1, c2 = VVwwau, VVs7I8
  VVtZf8 = []
  VVtZf8.append((c1 + "Network Devices"     , "dev" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Network Scanner (ping)"    , "ping"))
  VVtZf8.append(("Port Scanner (scan for famous ports)" , "port"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c2 + "Check Internet Connection"  , "intr"))
  FFd98D(self, title="Network Tools", VVtZf8=VVtZf8)
  FFd98D(self, VVtZf8=VVtZf8)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFn5td(self, self.VVdAux, title="REading Devices ...")
  elif item == "ping" : FFn5td(self, self.VV8ydm, title="Scanning ...")
  elif item == "port" : CCDTZn.VVzDDn(self, self.VVSkJZ, title="Select host to scan")
  elif item == "intr" : self.session.open(CCgTGS)
 def VVdAux(self, canCencel=False):
  title = "Network Devices"
  VVaKg1 = self.VVGqnP()
  if VVaKg1:
   bg = "#0a223333"
   VVaKg1.sort(key=lambda x: x[0].lower())
   VV0cge = BF(self.VVOitl, canCencel)
   VVTXLQ  = ("Start FTP"   , self.VVf912    , [])
   VVFaAj = ("Entry Options"  , self.VVar1W  , [])
   VV6CVp = ("Scan for Devices" , self.VVsA4g , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVGQvW = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVzzNZ = FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, width=1500, height=900, VV3FCq=widths, VVJgEp=28, VVTXLQ=VVTXLQ, VV0cge=VV0cge, VVFaAj=VVFaAj, VV6CVp=VV6CVp
       , VVRmfT=bg, VVRNJt=bg, VV84wP=bg, VVH7qA="#11ffff00", VVvmBM="#11220000", VVfpy3="#00333333", VViJnU="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVzzNZ.VV8i74(ndx)
  else:
   FFEN35(self, BF(FFn5td, self, BF(self.VV0HMV, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVOitl, canCencel), title=title)
 def VVar1W(self, VVzzNZ, title, txt, colList):
  VVtZf8 = []
  VVtZf8.append(("Change Username"   , "user"))
  VVtZf8.append(("Change Password"   , "pass"))
  VVtZf8.append(("Change Remarks"   , "rem"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Remove Selected Server" , "del"))
  FFd7BR(self, BF(self.VVGPPe, VVzzNZ), VVtZf8=VVtZf8, title="Entry Options")
 def VVGPPe(self, VVzzNZ, item=None):
  if item:
   if   item == "user" : self.VVApCP("u", VVzzNZ)
   elif item == "pass" : self.VVApCP("p", VVzzNZ)
   elif item == "rem" : self.VVApCP("r", VVzzNZ)
   elif item == "del" : FFEN35(self, BF(FFn5td, self, BF(self.VVwDGx, VVzzNZ), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVOitl(self, canCencel, VVzzNZ=None):
  if VVzzNZ: VVzzNZ.cancel()
  if canCencel : self.close()
 def VVf912(self, VVzzNZ, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFSeyu(CFG.lastNetworkDevice, VVzzNZ.VVXRaz())
  self.session.openWithCallback(BF(self.VVcMXg, entry, VVzzNZ), CCqnnf, entry)
 def VVcMXg(self, entry, VVzzNZ, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVNwMP("d", newPath, ip, u, p, path, rem)
    self.VViH31(VVzzNZ)
 def VVsA4g(self, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VV0HMV, mainTableInst=VVzzNZ), title="Scanning Network ...")
 def VV0HMV(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CCDTZn.VVpqPz(CCDTZn.VVxrua)
  if err:
   FFBsVa(self, err, title=title)
   return
  telLst, err = CCDTZn.VVpqPz(CCDTZn.VV3bf0)
  if err:
   FFBsVa(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VVElgI(p1, p2): return FFvHSH(p1[0], p2[0])
   lst.sort(key=FFKuFF(VVElgI))
   bg = "#0a202020"
   VV0cge = BF(self.VVOitl, canCencel)
   VVTXLQ  = ("Add to Devices" , BF(self.VVtUUs, mainTableInst, canCencel), [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVGQvW = (LEFT   , CENTER  , CENTER  )
   FFuI68(self, None, title=title, header=header, VVBQW6=lst, VVGQvW=VVGQvW, VV3FCq=widths, width=1200, VVJgEp=30, VVTXLQ=VVTXLQ, VV0cge=VV0cge, VVhEUu=2
     , VVRmfT=bg, VVRNJt=bg, VV84wP=bg, VVvmBM="#0a225555", VViJnU="#11403040")
  else:
   FFBsVa(self, "No devices found !", title=title)
 def VV8ydm(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CCDTZn.VVpqPz(-1)
  if err:
   FFBsVa(self, err, title=title)
  elif lst:
   def VVElgI(p1, p2): return FFvHSH(p1[0], p2[0])
   lst.sort(key=FFKuFF(VVElgI))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVGQvW = (LEFT   , LEFT   )
   FFuI68(self, None, title=title, header=header, VVBQW6=lst, VVGQvW=VVGQvW, VV3FCq=widths, width=1000, height=700, VVJgEp=30
     , VVRmfT=bg, VVRNJt=bg, VV84wP=bg, VVvmBM="#0a225555", VViJnU="#11403040")
  else:
   FFBsVa(self, "Network scanning failed !", title=title)
 def VVSkJZ(self, ip=None):
  if ip:
   FFn5td(self, BF(self.VVaf7E, ip), title="Scanning %s" % ip)
 def VVaf7E(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CCDTZn.VVjCJ3(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CCDTZn.VVH2Ir(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FFVBx2(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVGqnP(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFl3Sc(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVElgI(p1, p2): return FFvHSH(p1[0], p2[0])
  tLst.sort(key=FFKuFF(VVElgI))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVGqnP(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFl3Sc(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VVElgI(p1, p2): return FFvHSH(p1[0], p2[0])
  tLst.sort(key=FFKuFF(VVElgI))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVtUUs(self, mainTableInst, canCencel, VVzzNZ, title, txt, colList):
  ip, mac, typ = VVzzNZ.VVgdey(VVzzNZ.VVXRaz())
  if "Own" in ip:
   FFrBcM(VVzzNZ, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVGqnP():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FF4xUI(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VVtJhJ(ip, u, p, path, rem))
   if mainTableInst: self.VViH31(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVdAux(canCencel)
   VVzzNZ.cancel()
 def VVtJhJ(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVwDGx(self, VVzzNZ):
  num, ip, u, p, path, rem = VVzzNZ.VVgdey(VVzzNZ.VVXRaz())
  lst = self.VVGqnP()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VVtJhJ(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VViH31(VVzzNZ)
  else:
   VVzzNZ.cancel()
 def VVApCP(self, col, VVzzNZ):
  num, ip, u, p, path, rem = VVzzNZ.VVgdey(VVzzNZ.VVXRaz())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFsCnW(self, BF(self.VVJdfW, col, orig, VVzzNZ, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVJdfW(self, col, orig, VVzzNZ, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FFrBcM(VVzzNZ, "No change", 1500)
   elif not newTxt and col == "u":
    FFrBcM(VVzzNZ, "No user !", 2000)
   else:
    self.VVNwMP(col, newTxt, ip, u, p, path, rem)
    self.VViH31(VVzzNZ)
 def VVNwMP(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVGqnP()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VVtJhJ(ip1, u1, p1, path1, rem1))
 def VViH31(self, VVzzNZ, newEntry=None):
  VVaKg1 = self.VVGqnP()
  if VVaKg1 : VVzzNZ.VV311O(VVaKg1, tableRefreshCB=BF(self.VVt0NQ, newEntry))
  else  : VVzzNZ.cancel()
 def VVt0NQ(self, newEntry, VVzzNZ, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVzzNZ.VVMHVB()):
    if row[1:] == newEntry:
     VVzzNZ.VV8i74(ndx)
 def VVOitl(self, canCencel, VVzzNZ=None):
  if VVzzNZ: VVzzNZ.cancel()
  if canCencel : self.close()
class CCDTZn():
 VVxrua = 21
 VV3bf0 = 23
 def __init__(self):
  self.VVHAnr()
 def VVHAnr(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVehyi(self, ip, User, Pass, timeout=5):
  myIp = CCDTZn.VV5ESv()
  if ip != myIp:
   if CCDTZn.VVH2Ir(ip, CCDTZn.VVxrua):
    self.VVHAnr()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VV1v8g(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVsebW(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VV3N3s(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVsebW()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VV8Zrl(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VVRVHd(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVbpKb(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVpDCc(self):
  try: return self.ftp.pwd()
  except: return ""
 def VVfN9N(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVpDCc()
   if self.VVbpKb(path) : typ = "d"
   else      : typ = "b"
   self.VVbpKb(curDir)
   return typ
 def VVh0VP(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVbpKb(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVNHIz(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVQtIv(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVr1fw(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVJt0B(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVh0VP(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFKqXn(locFile)
   return "", sz, str(e)
 def VV7gJp(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVHAnr()
 @staticmethod
 def VVHvO6():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VV5ESv():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVindH():
  myIp = CCDTZn.VV5ESv()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVOoTG():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FFz86l("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVACIS(port=-1):
  lst = []
  def VVbF8S(ip):
   if port > -1: ok = CCDTZn.VVH2Ir(ip, port)
   else  : ok = CCDTZn.VVjCJ3(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CCDTZn.VVindH()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVbF8S, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VVpqPz(port):
  myIp = CCDTZn.VV5ESv()
  myGw = CCDTZn.VVOoTG()
  tDict = { myIp: CCDTZn.VVHvO6() }
  devLst, err = CCDTZn.VVACIS(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FFHFMV("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVwwau
    elif key == myGw: txt = " %s Gateway" % VVwwau
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVjCJ3(ip):
  return FFkQDN("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVH2Ir(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVay4r(ip="1.1.1.1", timeout=1):
  if CCDTZn.VVH2Ir(ip, 53, timeout):
   return True
  if CCDTZn.VVjCJ3(ip):
   return True
  return FFkQDN("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVzDDn(SELF, okFnc, title):
  baseIp = CCDTZn.VVindH()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFd7BR(SELF, okFnc, VVtZf8=lst, width=600, title=title, VVRmfT="#222222", VVRNJt="#222222")
class CCqnnf(Screen, CCDTZn):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FF98gL(VVL2J2, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVJgEp  = self.skinParam["bodyFontSize"]
  self.VV2u5U  = self.skinParam["bodyLineH"]
  self.VVMAO9  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCYpe9.VVSzzU("fil")
  self.png_dir  = CCYpe9.VVSzzU("dir")
  self.png_dirup  = CCYpe9.VVSzzU("dirup")
  self.png_slwfil  = CCYpe9.VVSzzU("slwfil")
  self.png_slbfil  = CCYpe9.VVSzzU("slbfil")
  self.png_slwdir  = CCYpe9.VVSzzU("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CCDTZn.__init__(self)
  VVtZf8 = [("Item-%d" % x,) for x in range(50)]
  FFd98D(self, title=self.Title, VVtZf8=VVtZf8)
  FF1N71(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVtZf8, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVQgMh, self.VVJgEp))
  self["myMenu"].l.setItemHeight(self.VV2u5U)
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "red" : BF(self.VVBrRb, True) ,
   "ok" : self.VVnIt0    ,
   "cancel": self.VVBrRb    ,
   "menu" : self.VVytzk   ,
   "info" : self.VVDGRA  ,
   "pageUp": self.VVYRli    ,
   "chanUp": self.VVYRli
  })
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVEJPb)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
  FFRet2(self)
  FFD5nM(self)
  FFwVrd(self["keyBlue"], "#11333333")
  FFn5td(self, self.VVb1Vz, title="Connecting ...")
 def VVb1Vz(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVehyi(ip, u, p)
  if err:
   FFBsVa(self, err, title=self.Title)
   FF1N71(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FF1N71(self["keyBlue"], self.ftpIp)
   if not self.VVbpKb(path):
    path = "/"
   self.VVoWYp(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVsebW():
   self.VV7gJp()
 def VVnIt0(self):
  if self.VVOG1z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVoWYp(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVYRli()
    else         : self.VVR0EM(os.path.join(self.curDir, name))
 def VVBrRb(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVYRli()
 def VVOG1z(self):
  if self.VVsebW():
   return True
  else:
   FFBsVa(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVR0EM(self, path):
  cat = self.VVaJRN(path)
  if cat in ("pic"):
   FFn5td(self, BF(self.VVGbqw, path))
  elif cat in ("mov", "mus"):
   if CCnYqq.VVlNfK("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFn5td(self, BF(CC5iId.VV0HP2, self, url, rType=rType), title="Playing Media ...")
 def VVGbqw(self, path):
  locFile, size, err = self.VVJt0B(path)
  if err: FFBsVa(self, err, title="View Picture File")
  else  : CCSQFA.VV9tRL(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFKqXn))
 def VVEJPb(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCYpe9.VVxzrQ else sel[0][0])
  else  : title=  VVKRbh + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVYRli(self):
  if self.VVOG1z():
   lastPart = FFzOGe(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVoWYp(parentDir, lastPart, "d")
 def VVoWYp(self, Dir, moveTo="", moveToType=""):
  FFn5td(self, BF(self.VVx9mt, Dir, moveTo, moveToType))
 def VVx9mt(self, Dir, moveTo, moveToType):
  files, err = self.VVRVHd(Dir, isLong=True)
  self.curDir = self.VVpDCc() or "/"
  self.VV3kdt(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VV3kdt(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVyFLZ(CCYpe9.VVxzrQ, CCYpe9.VVxzrQ, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VVfN9N(target)
    color = VVKRbh if targetState == "b" else VVCKEk
    origName = name + VV0V0q + linkSep + color + " "+ target
   self.list.append(self.VVyFLZ(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVyFLZ(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VVaJRN(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVG8hM, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCYpe9.VVxzrQ: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV2u5U + 10, 0, self.VVMAO9, self.VV2u5U, 0, LEFT | RT_VALIGN_CENTER, origName))
  tableRow.append(CCLGNO.VVZhgD(0, 2, self.VV2u5U-4, self.VV2u5U-4, png))
  return tableRow
 def VVaJRN(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCYpe9.VVtxMu().items():
    if ext in lst:
     return cat
  return ""
 def VVytzk(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCYpe9.VVxzrQ
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVS7eG(titl, ref, chk, color=""):
   if chk: return VVtZf8.append((color + titl, ref))
   else  : return VVtZf8.append((titl, ))
  VVtZf8 = []
  VVS7eG("Properties", "VVDGRA", not isTop)
  c = VVwwau
  VVtZf8.append(VVh3VV)
  VVS7eG("Download Selected File ..."    , "FFjgmpFromServer", isFile, c)
  VVS7eG("Upload a Local File to Remote Server ...", "VV6Iaf" , True  , c)
  VVtZf8.append(VVh3VV)
  VVS7eG("Create new directory", "VVR9KF", True)
  VVS7eG("Rename", "VV1kh6", not isTop)
  VVS7eG("DELETE", "VVD7Am", not isTop, VVmxw7)
  VVtZf8.append(VVh3VV)
  VVS7eG("FTP Server Information", "VVyMh2", True)
  VVtZf8.append(VVh3VV)
  VVS7eG("Refresh File List", "refresh", True)
  FFd7BR(self, self.VVu4aS, VVtZf8=VVtZf8, title="Options")
 def VVu4aS(self, item=None):
  if item:
   if   item == "VVDGRA"     : self.VVDGRA()
   elif item == "FFjgmpFromServer"   : self.FFjgmpFromServer()
   elif item == "VV6Iaf"   : self.VV6Iaf()
   elif item == "VVR9KF"   : self.VVR9KF()
   elif item == "VV1kh6"   : self.VV1kh6()
   elif item == "VVD7Am"   : self.VVD7Am()
   elif item == "VVyMh2"    : self.VVyMh2()
   elif item == "refresh"and self.VVOG1z() : self.VVoWYp(self.curDir)
 def VVDGRA(self):
  if self.VVOG1z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFxrb0("Path", VVwwau), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVh0VP(path)
    if sz > -1: txt += "Size\t: %s" % CC5iId.VVp3Jg(sz)
   else:
    txt = "Nothing selected"
   FFVBx2(self, txt, title="Properties")
 def VVyMh2(self):
  if self.VVOG1z():
   Sys  = self.VV1v8g() or " -"
   txt = "%s\n  %s\n\n" % (FFxrb0("System:", VVwwau), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VV8Zrl() or " -"
   txt += "%s\n" % (FFxrb0("Status:", VVwwau))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FFVBx2(self, txt, title="FTP Server Information")
 def VVR9KF(self, name=""):
  if self.VVOG1z():
   title = "Add New Directory"
   FFsCnW(self, BF(self.VV8V27, title), defaultText=name, title=title, message="Enter Directory name")
 def VV8V27(self, title, name):
  if name and name.strip():
   if self.VVNHIz(name) : self.VVoWYp(self.curDir, name, "d")
   else     : FFBsVa(self, "Failed to create : %s" % name, title)
 def VV1kh6(self):
  if self.VVOG1z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFsCnW(self, BF(self.VVwqCD, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVwqCD(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVr1fw(name, newName.strip()) : self.VVoWYp(self.curDir, newName, flag)
   else          : FFBsVa(self, "Failed to rename to : %s" % newName, title)
 def VVD7Am(self):
  if self.VVOG1z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFEN35(self, BF(FFn5td, self, BF(self.VVVURm, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVVURm(self, name, flag):
  if self.VVQtIv(name, flag) : self.VVoWYp(self.curDir)
  else         : FFBsVa(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFjgmpFromServer(self):
  if self.VVOG1z():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVh0VP(remFile)
    if size == -1:
     FFBsVa(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVzbRf
     self.session.openWithCallback(BF(self.VVf4DB, title, remFile, name, size), BF(CC5iId, mode=CC5iId.VVtux5, VV1w5C="Download here", VV0aja=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVf4DB(self, title, remFile, name, size, locPath):
  if locPath:
   FFSeyu(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVr2Wu, remFile, size, locFile)
       , VVqhY7 = BF(self.VVkCPA, remFile, size, locFile))
 def VVr2Wu(self, remFile, size, locFile, VVomkw):
  VVomkw.VVITUK(size)
  VVomkw.VV6uui = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVY6Yt(data):
     if not VVomkw or VVomkw.isCancelled:
      return
     locFileObj.write(data)
     VVomkw.VVReKT(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVY6Yt)
   except Exception as e:
    VVomkw.VV6uui = str(e)
 def VVkCPA(self, remFile, size, locFile, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VV6uui:
   FFBsVa(self, "%s\n\nftp:/%s" % (VV6uui, remFile), title="Download Error")
   delF = True
  elif not VVuCFf:
   FFBsVa(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFotbw(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FFx4Fl(self, txt, title=title)
   else:
    FFBsVa(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFKqXn(locFile)
 def VV6Iaf(self):
  if self.VVOG1z():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVzbRf
   self.session.openWithCallback(self.VVhLdv, BF(CC5iId, VV1w5C="Upload selected file", VV0aja=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVhLdv(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFSeyu(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFotbw(locFile)
   if size == -1:
    FFBsVa(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVZOwY, locFile, size, remFile)
        , VVqhY7 = BF(self.VVpsyA, locFile, size, remFile))
 def VVZOwY(self, locFile, size, remFile, VVomkw):
  VVomkw.VVITUK(size)
  VVomkw.VV6uui = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVutXn(data):
     if not VVomkw or VVomkw.isCancelled:
      VVomkw.VV6uui = "Upload cancelled"
      locFileObj.close()
      return
     VVomkw.VVReKT(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVutXn)
   except Exception as e:
    VVomkw.VV6uui = VVomkw.VV6uui or str(e)
 def VVpsyA(self, locFile, size, remFile, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVuCFf:
   if size == FFotbw(locFile) : FFx4Fl(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VV6uui : err = "%s\n\n%s" % (VV6uui, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFBsVa(self, err, title=title)
   self.VV3N3s()
   self.VVQtIv(remFile, "")
  self.VVoWYp(self.curDir)
class CC7MvF():
 VVxskn  = "all"
 VVvdB1 = "vid"
 VVMOSi  = "osd"
 @staticmethod
 def VVKOw2(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFtTXa("grab"):
    winShown = session.current_dialog.shown
    if k == CC7MvF.VVvdB1 and winShown: session.current_dialog.hide()
    FFb5Nn(BF(CC7MvF.VVUgis, title, session, k, winShown))
   else:
    FFT9sG(session, "No Grab command !", title=title)
 @staticmethod
 def VVUgis(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CC7MvF.VVMOSi:
   if not winShown:
    FFT9sG(session, "No Window to capture !", title=title)
    return
   if not CC7MvF.VVIckV(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CC7MvF.VVu8pe(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFT9sG(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FF9GYH(CFG.exportedPIconsPath.getValue()), fTitle, FF0Isj(), ext)
  ok = FFnedc("grab -q -s %s > '%s'" % (typ, path))
  if k == CC7MvF.VVvdB1 and winShown:
   session.current_dialog.show()
  elif k == CC7MvF.VVMOSi:
   ok = CC7MvF.VVysMt(path, x, y, w, h)
   if not ok:
    FFKqXn(path)
    FFT9sG(session, "Error while cropping image file !", title=title)
    return
  if ok and fileExists(path) : session.open(BF(CCSQFA, title=path, VVukle=path))
  else      : FFT9sG(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVIckV(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFEN35(SELF, BF(CC7MvF.VV4QD5, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VV4QD5(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFxH1w, VVBjuq=cbFnc)
  else    : fnc = BF(FFeWwS , VVBjuq=cbFnc)
  fnc(SELF, FFgOTM(VV6ESW, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVu8pe(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVysMt(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FF3tfX()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FFUY5i(x , 0, scrW, 0, w)
     y  = FFUY5i(y , 0, scrH, 0, h)
     x1 = FFUY5i(x1, 0, scrW, 0, w)
     y1 = FFUY5i(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVWQP2(path):
  size = FFotbw(path)
  sizeTxt = CC5iId.VVp3Jg(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CChIXk(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FF98gL(VVL2J2, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFxrb0(" (Requires GUI Restart)", VVOICC) if withRestart else ""
  VVtZf8 = []
  for path in self.fontsList:
   VVtZf8.append((os.path.splitext(os.path.basename(path))[0], path))
  VVtZf8.sort(key=lambda x: x[0].lower())
  VVtZf8.insert(0, VVh3VV)
  VVtZf8.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVtZf8):
    if len(item) == 2 and item[1] == self.defFnt:
     VVtZf8[ndx] = (VVCKEk + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVtZf8[curIndex] = (VVCKEk + VVtZf8[curIndex][0], VVtZf8[curIndex][1])
  FFd98D(self, VVtZf8=VVtZf8, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
  self["myBar"].setText(self.VVigOZ())
  self["myBar"].instance.setHAlign(1)
  self["myMenu"].onSelectionChanged.append(self.VVnP6T)
  self.VVnP6T()
 def VVnIt0(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVnP6T(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFJIrJ(path, fnt, isRepl=1)
  else:
   fnt = VVTiT1
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVigOZ(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVkZ62(SELF, title, defFnt, rest, VVqhY7):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FF8hHp(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVqhY7, CChIXk, title, fontsList, defFnt, rest)
  else  : FFBsVa(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCYqSs(Screen):
 def __init__(self, session, path, VVtZf8, title):
  self.skin, self.skinParam = FF98gL(VVL2J2, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFd98D(self, VVtZf8=VVtZf8, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok"  : self.VVnIt0   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVvZaA,
   "chanUp" : self.VVvZaA,
   "pageDown" : self.VVA4m7 ,
   "chanDown" : self.VVA4m7 ,
  }, -1)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
  FFwVrd(self["myLabelFrm"], "#11110000")
  FFwVrd(self["myLabelTit"], "#11663322")
  FFwVrd(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVM6KG)
  self.VVM6KG()
 def VVM6KG(self):
  if fileExists(self.path): txt = FFl3Sc(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVnIt0(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVvZaA(self) : self["myMenu"].moveToIndex(0)
 def VVA4m7(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCiVik():
 @staticmethod
 def VVAo1j():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVLoxE(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FFuI68(SELF, None, VVBQW6=lst, VVJgEp=30, VVhEUu=1)
 @staticmethod
 def VV4IR5(path, SELF=None):
  for enc in CCiVik.VVAo1j():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFBsVa(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VViPTu(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VV2psM(SELF, path, cbFnc, curEnc=VVsrqw, title="Select Encoding"):
  lst = CCiVik.VVjYp5(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCYqSs, path, lst, title)
 @staticmethod
 def VVNSH8(SELF, cbFnc, curEnc=VVsrqw, title="Select Encoding"):
  lst = CCiVik.VVjYp5(SELF, "", "")
  if lst:
   FFd7BR(SELF, cbFnc, title=title, VVtZf8=lst, width=1000, height=1000, VVRmfT="#22220000", VVRNJt="#22220000", VVkmYm=True)
 @staticmethod
 def VVjYp5(SELF, path, curEnc):
  lst = CCiVik.VVra1N(path)
  if lst:
   VVtZf8 = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVCKEk
    elif enc == VVsrqw: c = VV0V0q
    else      : c = ""
    VVtZf8.append((c + txt, enc))
   return VVtZf8
  else:
   FFQAm4(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVra1N(path=""):
  encLst = []
  cPath = VVG8hM + "_sup_codecs"
  if fileExists(cPath):
   lines = FFMy5k(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCiVik.VVAo1j())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCY0Fb(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVL2J2, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVtZf8 = []
  VVtZf8.append(("Settings File"   , "SettingsFile"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Box Info"     , "VVedHb"   ))
  VVtZf8.append(("Tuners Info"    , "VViXec"  ))
  VVtZf8.append(("Python Version"   , "VVkHo7"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Screen Size"    , "ScreenSize"   ))
  VVtZf8.append(("Language/Locale"   , "Locale"    ))
  VVtZf8.append(("Processor"    , "Processor"   ))
  VVtZf8.append(("Operating System"   , "OperatingSystem"  ))
  VVtZf8.append(("Drivers"     , "drivers"    ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("System Users"    , "SystemUsers"   ))
  VVtZf8.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVtZf8.append(("Uptime"     , "Uptime"    ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Host Name"    , "HostName"   ))
  VVtZf8.append(("MAC Address"    , "MACAddress"   ))
  VVtZf8.append(("Network Configuration" , "NetworkConfiguration"))
  VVtZf8.append(("Network Status"   , "NetworkStatus"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Disk Usage"    , "VVYRMe"   ))
  VVtZf8.append(("Mount Points"    , "MountPoints"   ))
  VVtZf8.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVtZf8.append(("USB Devices"    , "USB_Devices"   ))
  VVtZf8.append(("List Block-Devices"  , "listBlockDevices" ))
  VVtZf8.append(("Directory Size"   , "DirectorySize"  ))
  VVtZf8.append(("Memory"     , "Memory"    ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVtZf8.append(("Running Processes"  , "RunningProcesses" ))
  VVtZf8.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFd98D(self, VVtZf8=VVtZf8, title="Device Information")
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCJSvF)
   elif item == "VVedHb"   : self.VVedHb()
   elif item == "VViXec"  : self.VViXec()
   elif item == "VVkHo7"  : self.VVkHo7()
   elif item == "ScreenSize"   : FFVBx2(self, "Width\t: %s\nHeight\t: %s" % (FF3tfX()[0], FF3tfX()[1]))
   elif item == "Locale"    : CCiVik.VVLoxE(self)
   elif item == "Processor"   : self.VVDiGP()
   elif item == "OperatingSystem"  : FFlHGt(self, "uname -a")
   elif item == "drivers"    : self.VVZwF7()
   elif item == "SystemUsers"   : FFlHGt(self, "id")
   elif item == "LoggedInUsers"  : FFlHGt(self, "who -a", consFont=True)
   elif item == "Uptime"    : FFlHGt(self, "uptime")
   elif item == "HostName"    : FFlHGt(self, "hostname")
   elif item == "MACAddress"   : self.VVKMKc()
   elif item == "NetworkConfiguration" : FFlHGt(self, "ifconfig %s %s" % (FFPk5q("HWaddr", VVDF46), FFPk5q("addr:", VV0V0q)))
   elif item == "NetworkStatus"  : FFlHGt(self, "netstat -tulpn", VVJgEp=24, consFont=True)
   elif item == "VVYRMe"   : self.VVYRMe()
   elif item == "MountPoints"   : FFlHGt(self, "mount %s" % (FFPk5q(" on ", VV0V0q)))
   elif item == "FileSystemTable"  : FFlHGt(self, "cat /etc/fstab", VVJgEp=24, consFont=True)
   elif item == "USB_Devices"   : FFlHGt(self, "lsusb")
   elif item == "listBlockDevices"  : FFlHGt(self, "blkid")
   elif item == "DirectorySize"  : FFlHGt(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVq7WU="Reading size ...")
   elif item == "Memory"    : FFlHGt(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVLUAN()
   elif item == "RunningProcesses"  : FFlHGt(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FFlHGt(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVwi9q()
   else        : self.close()
 def VVKMKc(self):
  res = FFHFMV("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FFVBx2(self, txt)
  else:
   FFlHGt(self, "ip link")
 def VVxnGe(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFIM7p(cmd)
  return lines
 def VVxSGi(self, lines, headerRepl, widths, VVGQvW):
  VVaKg1 = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVaKg1.append(parts)
  if VVaKg1 and len(header) == len(widths):
   VVaKg1.sort(key=lambda x: x[0].lower())
   FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=28, VVhEUu=1)
   return True
  else:
   return False
 def VVYRMe(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FFHFMV(cmd)
  if not "invalid option" in txt:
   lines  = self.VVxnGe(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVGQvW = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVxSGi(lines, headerRepl, widths, VVGQvW)
  else:
   cmd = "df -h"
   lines  = self.VVxnGe(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVGQvW = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVxSGi(lines, headerRepl, widths, VVGQvW)
  if not allOK:
   lines = FFIM7p(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FF3NDk(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVCKEk:
     note = "\n%s" % FFxrb0("Green = Mounted Partitions", VVCKEk)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VV0V0q
     elif line.endswith(mountList) : color = VVCKEk
     else       : color = VVUpvF
     txt += FFxrb0(line, color) + "\n"
    FFVBx2(self, txt + note)
   else:
    FFBsVa(self, "Not data from system !")
 def VVLUAN(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVxnGe(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVGQvW = (LEFT , CENTER, LEFT )
  allOK = self.VVxSGi(lines, headerRepl, widths, VVGQvW)
  if not allOK:
   FFlHGt(self, cmd)
 def VVZwF7(self):
  cmd = FFYH4A(VV5oWt, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FFlHGt(self, cmd)
  else : FF5yx0(self)
 def VVDiGP(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FFlHGt(self, cmd)
 def VVwi9q(self):
  cmd = FFYH4A(VVFU7m, "| grep secondstage")
  if cmd : FFlHGt(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FF5yx0(self)
 def VVedHb(self):
  c = VVCKEk
  VVBQW6 = []
  VVBQW6.append((FFxrb0("Box Type"  , c), FFxrb0(self.VVpdFf("boxtype").upper(), c)))
  VVBQW6.append((FFxrb0("Board Version", c), FFxrb0(self.VVpdFf("board_revision") , c)))
  VVBQW6.append((FFxrb0("Chipset"  , c), FFxrb0(self.VVpdFf("chipset")  , c)))
  VVBQW6.append((FFxrb0("S/N"   , c), FFxrb0(self.VVpdFf("sn")    , c)))
  VVBQW6.append((FFxrb0("Version"  , c), FFxrb0(self.VVpdFf("version")  , c)))
  VVPgXw   = []
  VVQABl = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VVQABl = SystemInfo[key]
     else:
      VVPgXw.append((FFxrb0(str(key), VVTVZG), FFxrb0(str(SystemInfo[key]), VVTVZG)))
  except:
   pass
  if VVQABl:
   VVIEJ9 = self.VVdGfm(VVQABl)
   if VVIEJ9:
    VVIEJ9.sort(key=lambda x: x[0].lower())
    VVBQW6 += VVIEJ9
  if VVPgXw:
   VVPgXw.sort(key=lambda x: x[0].lower())
   VVBQW6 += VVPgXw
  if VVBQW6:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FFuI68(self, None, header=header, VVBQW6=VVBQW6, VV3FCq=widths, VVJgEp=28, VVhEUu=1)
  else:
   FFVBx2(self, "Could not read info!")
 def VVpdFf(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFMy5k(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVdGfm(self, mbDict):
  try:
   mbList = list(mbDict)
   VVBQW6 = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVBQW6.append((FFxrb0(subject, VV0V0q), FFxrb0(value, VV0V0q)))
  except:
   pass
  return VVBQW6
 def VViXec(self):
  txt = self.VVAVxM("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVAVxM("/proc/bus/nim_sockets")
  if not txt: txt = self.VVaQ6O()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FFVBx2(self, txt)
 def VVaQ6O(self):
  txt = ""
  VVIsuR = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVIsuR("Slot Name" , slot.getSlotName())
     txt += FFxrb0(slotName, VV0V0q)
     txt += VVIsuR("Description"  , slot.getFullDescription())
     txt += VVIsuR("Frontend ID"  , slot.frontend_id)
     txt += VVIsuR("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVAVxM(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFMy5k(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFxrb0(line, VV0V0q)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVkHo7(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FFVBx2(self, txt)
 @staticmethod
 def VVSYLB():
  def VVIsuR(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVIsuR(v,0), "/etc/issue.net": VVIsuR(v,1), "/etc/image-version": VVIsuR(v,2)}
  for p1, d in v.items():
   img = CCY0Fb.VV1E6c(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVIsuR(v,0), p + "Plugins/": VVIsuR(v,1), VVU7z8: VVIsuR(v,2), VVJT98: VVIsuR(v,3)}
  for p1, d in v.items():
   img = CCY0Fb.VVrqOS(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VV1E6c(path, d):
  if fileExists(path):
   txt = FFl3Sc(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVrqOS(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCJSvF(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVL2J2, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVtZf8 = []
  VVtZf8.append(("Settings (All)"   , "Settings_All"   ))
  VVtZf8.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVtZf8.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVtZf8.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVtZf8.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVtZf8.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVtZf8.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VVNHHG:
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVtZf8.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFd98D(self, VVtZf8=VVtZf8)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VV7aeL
   grep = " | grep "
   if   item == "Settings_All"   : FFlHGt(self, cmd)
   elif item == "Settings_HotKeys"  : FFlHGt(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FFlHGt(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FFlHGt(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FFlHGt(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FFlHGt(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FFlHGt(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FFlHGt(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FFlHGt(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCyO3o(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVL2J2, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVX42X, VVmawr, VVH7Ta, camCommand = CCyO3o.VVwxW3()
  self.VVmawr = VVmawr
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVmawr:
   c = VVs7I8 if VVH7Ta else VVquhO
   if   "oscam" in VVmawr : camName, oC = "OSCam", c
   elif "ncam"  in VVmawr : camName, nC = "NCam" , c
  VVtZf8 = []
  VVtZf8.append(("OSCam Files" , "OSCamFiles" ))
  VVtZf8.append(("NCam Files" , "NCamFiles" ))
  VVtZf8.append(("CCcam Files" , "CCcamFiles" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((VVwwau + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVORlx" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVtZf8.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVtZf8.append(VVh3VV)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVtZf8.append(FFTjqa(txt, "camInfo", VVmawr, c))
  VVtZf8.append(VVh3VV)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVmawr:
   for item in camLst: VVtZf8.append(item)
  else:
   for item in camLst: VVtZf8.append((item[0], ))
  FFd98D(self, VVtZf8=VVtZf8)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCRMxO, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCRMxO, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCRMxO, "cccam"))
   elif item == "VVORlx" : self.VVORlx()
   elif item == "OSCamReaders"  : self.VVUatJ("os")
   elif item == "NSCamReaders"  : self.VVUatJ("n")
   elif item == "camInfo"   : FFvd5Q(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCyO3o.VVuzhf(self.session, CCuIoz.VVqaBu)
   elif item == "camLiveReaders" : CCyO3o.VVuzhf(self.session, CCuIoz.VVH6M9)
   elif item == "camLiveLog"  : CCyO3o.VVuzhf(self.session, CCuIoz.VVD2Vj)
   else       : self.close()
 def VVORlx(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVzbRf, FF0Isj())
  if fileExists(path):
   lines = FFMy5k("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVIsuR = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVIsuR("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVIsuR("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVIsuR("protocol"   , "cccam"))
      f.write(VVIsuR("device"    , "%s,%s" % (host, port)))
      f.write(VVIsuR("user"    , User))
      f.write(VVIsuR("password"   , Pass))
      f.write(VVIsuR("fallback"   , "1"))
      f.write(VVIsuR("group"    , "64"))
      f.write(VVIsuR("cccversion"   , "2.3.2"))
      f.write(VVIsuR("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FFx4Fl(self, "Output = %d Reader%s in:\n\n%s" % (tot, FFAHjU(tot), outFile))
   else:
    FFrBcM(self, "No valid CCcam lines", 1500)
  else:
   FFrBcM(self, "%s not found" % path, 1500)
 def VVUatJ(self, camPrefix):
  VVaKg1 = self.VVdgjf(camPrefix)
  if VVaKg1:
   VVaKg1.sort(key=lambda x: int(x[0]))
   if self.VVmawr and self.VVmawr.startswith(camPrefix):
    VVIZTW = ("Toggle State", self.VVABAZ, [camPrefix], "Changing State ...")
   else:
    VVIZTW = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVGQvW  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVIZTW=VVIZTW, VV3cto=True)
 def VVdgjf(self, camPrefix):
  readersFile = self.VVX42X + camPrefix + "cam.server"
  VVaKg1 = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFMy5k(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVaKg1.append((str(len(VVaKg1) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVaKg1:
    FFBsVa(self, "No readers found !")
  else:
   FFPQyp(self, readersFile)
  return VVaKg1
 def VVABAZ(self, VVzzNZ, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVX42X, camPrefix)
  readerState  = VVzzNZ.VVOEiT(1)
  readerLabel  = VVzzNZ.VVOEiT(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCyO3o.VVWPTA(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVzzNZ.VVD7du()
    FFBsVa(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVaKg1 = self.VVdgjf(camPrefix)
   if VVaKg1:
    VVzzNZ.VV311O(VVaKg1)
  else:
   VVzzNZ.VVD7du()
 @staticmethod
 def VVWPTA(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFMy5k(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFBsVa(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFBsVa(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFPQyp(SELF, confFile)
   return None
  if not iRequest:
   FFBsVa(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCyO3o.VVG6c7(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFBsVa(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVG6c7(SELF):
  if iElem:
   return True
  else:
   FFBsVa(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVuzhf(session, VVDoUN):
  VVX42X, VVmawr, VVH7Ta, camCommand = CCyO3o.VVwxW3()
  if VVmawr:
   runLog = False
   if   VVDoUN == CCuIoz.VVqaBu : runLog = True
   elif VVDoUN == CCuIoz.VVH6M9 : runLog = True
   elif not VVH7Ta          : FFT9sG(session, message="SoftCam not started yet!")
   elif fileExists(VVH7Ta)        : runLog = True
   else             : FFT9sG(session, message="File not found !\n\n%s" % VVH7Ta)
   if runLog:
    session.open(BF(CCuIoz, VVX42X=VVX42X, VVmawr=VVmawr, VVH7Ta=VVH7Ta, VVDoUN=VVDoUN))
  else:
   FFT9sG(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVwxW3():
  VVX42X = "/etc/tuxbox/config/"
  VVmawr = None
  VVH7Ta  = None
  camCommand = FFz86l("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVmawr = "oscam"
   elif camCmd.startswith("ncam") : VVmawr = "ncam"
  if VVmawr:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFl3Sc(path), IGNORECASE)
     if span:
      VVX42X = FF9GYH(span.group(1))
      break
   else:
    path = FFz86l(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FF9GYH(path)
    if pathExists(path):
     VVX42X = path
   tFile = FF9GYH(VVX42X) + VVmawr + ".conf"
   tFile = FFz86l("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VVH7Ta = tFile
  return VVX42X, VVmawr, VVH7Ta, camCommand
class CCRMxO(Screen):
 def __init__(self, VVEbrE, session, args=0):
  self.skin, self.skinParam = FF98gL(VVL2J2, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVX42X, VVmawr, VVH7Ta, camCommand = CCyO3o.VVwxW3()
  if   VVEbrE == "ncam" : self.prefix = "n"
  elif VVEbrE == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVtZf8 = []
  if self.prefix == "":
   VVtZf8.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVtZf8.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVtZf8.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVtZf8.append(("constant.cw"         , "x_constant_cw" ))
   VVtZf8.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVtZf8.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVtZf8.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVtZf8.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVtZf8.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVtZf8.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVtZf8.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVtZf8.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVtZf8.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVtZf8.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVtZf8.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFd98D(self, VVtZf8=VVtZf8)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FF5vJp(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FF5vJp(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FF5vJp(self, self.VVX42X + "AutoRoll.Key")
   elif item == "x_constant_cw" : FF5vJp(self, self.VVX42X + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVKMqY("cam.ccache")
   elif item == "x_cam_conf"  : self.VVKMqY("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVKMqY("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVKMqY("cam.provid")
   elif item == "x_cam_server"  : self.VVKMqY("cam.server")
   elif item == "x_cam_services" : self.VVKMqY("cam.services")
   elif item == "x_cam_srvid2"  : self.VVKMqY("cam.srvid2")
   elif item == "x_cam_user"  : self.VVKMqY("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVSNTW()
   elif item == "x_CCcam_cfg"  : FF5vJp(self, self.VVX42X + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FF5vJp(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FF5vJp(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FF5vJp(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVKMqY(self, fileName):
  FF5vJp(self, self.VVX42X + self.prefix + fileName)
 def VVSNTW(self):
  path = self.VVX42X + "SoftCam.Key"
  if fileExists(path) : FF5vJp(self, path)
  else    : FF5vJp(self, path.replace(".Key", ".key"))
class CCuIoz(Screen):
 VVqaBu  = 0
 VVH6M9 = 1
 VVD2Vj = 2
 def __init__(self, session, VVX42X="", VVmawr="", VVH7Ta="", VVDoUN=VVqaBu):
  self.skin, self.skinParam = FF98gL(VV3Zke, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VVH7Ta   = VVH7Ta
  self.VVDoUN  = VVDoUN
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVX42X + VVmawr + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVmawr : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVX42X, self.camPrefix)
  if self.VVDoUN == self.VVqaBu:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVDoUN == self.VVH6M9:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFd98D(self, self.Title, addScrollLabel=True)
  FF1N71(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVH8zE
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self["myLabel"].VVc45w(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFRet2(self)
  self.VVH8zE()
 def onExit(self):
  self.timer.stop()
 def VVzW97(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVX0GS)
  except:
   self.timer.callback.append(self.VVX0GS)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FFrBcM(self, "Started", 1000)
 def VVxouF(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VVX0GS)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FFrBcM(self, "Stopped", 1000)
 def VVH8zE(self):
  if self.timerRunning:
   self.VVxouF()
  else:
   self.VVzW97()
   if self.VVDoUN == self.VVqaBu or self.VVDoUN == self.VVH6M9:
    if self.VVDoUN == self.VVqaBu : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCyO3o.VVWPTA(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFb5Nn(self.VVicGl)
    else:
     self.close()
   else:
    self.VVzGQY()
 def VVX0GS(self):
  if self.timerRunning:
   if   self.VVDoUN == self.VVqaBu : self.VVwONR()
   elif self.VVDoUN == self.VVH6M9 : self.VVwONR()
   else            : self.VVzGQY()
 def VVzGQY(self):
  if fileExists(self.VVH7Ta):
   fTime = FF2ADr(os.path.getmtime(self.VVH7Ta))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVKnWh(), VVeLJi=VVEkFU)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VVH7Ta)
 def VVicGl(self):
  self.VVwONR()
 def VVwONR(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFxrb0("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVmxw7))
   self.camWebIfErrorFound = True
   self.VVxouF()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVDoUN == self.VVqaBu : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFxrb0("Error while parsing data elements !\n\nError = %s" % str(e), VVKRbh)
   self.camWebIfErrorFound = True
   self.VVxouF()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVJzHx(root)
  self["myLabel"].setText(txt, VVeLJi=VVEkFU)
  self["myBar"].setText("Last Update : %s" % FFByGk())
 def VVJzHx(self, rootElement):
  def VVIsuR(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVDoUN == self.VVqaBu:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFxrb0(status, VVCKEk)
    else          : status = FFxrb0(status, VVKRbh)
    txt += SEP + "\n"
    txt += VVIsuR("Name"  , name)
    txt += VVIsuR("Description" , desc)
    txt += VVIsuR("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVIsuR("Protocol" , protocol)
    txt += VVIsuR("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFxrb0("Yes", VVCKEk)
    else    : enabTxt = FFxrb0("No", VVKRbh)
    txt += SEP + "\n"
    txt += VVIsuR("Label"  , label)
    txt += VVIsuR("Protocol" , protocol)
    txt += VVIsuR("Enabled" , enabTxt)
  return txt
 def VVKnWh(self):
  lines = FFIM7p("tail -n %d %s" % (100, self.VVH7Ta))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVOICC + line[:19] + VVUpvF + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVOIiN + "WebIf" + VVUpvF)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVTVZG + h1 + h2 + VVUpvF + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVCKEk + span.group(2) + VVwwau + span.group(3) + VVUpvF + span.group(4)
    line = self.VVtueB(line, VVwwau, ("(webif)", ))
    line = self.VVtueB(line, VVwwau, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVtueB(line, VVCKEk, ("OSCam", "NCam", "log switched"))
    line = self.VVtueB(line, VVD46d, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VV0V0q + line[ndx + 3:] + VVUpvF
   elif line.startswith("----") or ">>" in line:
    line = FFxrb0(line, VVDysW)
   txt += line + "\n"
  return txt
 def VVtueB(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVUpvF + t3
  return line
class CCZWLw(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVL2J2, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVtZf8 = []
  VVtZf8.append(("Backup Channels"    , "VVkbBh"   ))
  VVtZf8.append(("Restore Channels"    , "Restore_Channels"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Backup SoftCAM Files"   , "VVjrdq" ))
  VVtZf8.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVtZf8.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVtZf8.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Backup Network Settings"  , "VVF7bd"   ))
  VVtZf8.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VVNHHG:
   VVtZf8.append(VVh3VV)
   VVtZf8.append((VVmxw7 + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVwHQY"   ))
   VVtZf8.append((VVCKEk + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVKetr), "createMyIpk"   ))
   VVtZf8.append((VVCKEk + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVKetr), "createMyDeb"   ))
   VVtZf8.append((VVTVZG + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVtZf8.append((VVTVZG + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVAFrE" ))
   VVtZf8.append((VVTVZG + "Show Windows Stats"           , "VVjaiy" ))
  FFd98D(self, VVtZf8=VVtZf8)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVkbBh"    : self.VVkbBh()
   elif item == "Restore_Channels"    : self.VVVrcW("channels_backup*.tar.gz", self.VVMKVs, isChan=True)
   elif item == "VVjrdq"   : self.VVjrdq()
   elif item == "Restore_SoftCAM_Files"  : self.VVVrcW("softcam_backup*.tar.gz", self.VV2f3R)
   elif item == "Backup_TunerDiSEqC"   : self.VVDX2I("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVVrcW("tuner_backup*.backup", BF(self.VVd6uH, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVDX2I("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVVrcW("hotkey_*backup*.backup", BF(self.VVd6uH, "misc"))
   elif item == "VVF7bd"    : self.VVF7bd()
   elif item == "Restore_Network"    : self.VVVrcW("network_backup*.tar.gz", self.VVX6G1)
   elif item == "VVwHQY"     : FFEN35(self, BF(FFn5td, self, BF(CCZWLw.VVwHQY, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVZSyu(False)
   elif item == "createMyDeb"     : self.VVZSyu(True)
   elif item == "createMyTar"     : self.VVfiPX()
   elif item == "VVAFrE"   : self.VVAFrE()
   elif item == "VVjaiy"    : CCZWLw.VVjaiy(self)
 @staticmethod
 def VVgRKP(SELF):
  OBF_Path = VV1fMY + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFPQyp(SELF, OBF_Path)
   return None
 @staticmethod
 def VVjaiy(SELF):
  obf = CCZWLw.VVgRKP(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FFVBx2(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVwHQY(SELF):
  obf = CCZWLw.VVgRKP(SELF)
  if obf:
   txt, err = obf.fixCode(VV1fMY, VVDJVr, VVKetr)
   if err : FFBsVa(SELF, err)
   else : FFVBx2(SELF, txt)
 def VVZSyu(self, VVITRg):
  OBF_Path = VV1fMY + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFBsVa(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFkQDN("rm -f %s__pycache__/" % VV1fMY)
  FFkQDN("mv -f '%smain.py' '%s'" % (VV1fMY, OBF_Path))
  FFkQDN("mv -f '%splugin.py' '%s'" % (VV1fMY, OBF_Path))
  FFkQDN("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VV1fMY))
  self.session.openWithCallback(self.VVwlAy, BF(CCMlOB, path=VV1fMY, VVITRg=VVITRg))
 def VVwlAy(self):
  FFkQDN("mv -f %s %s" % (VV1fMY + "OBF/main.py" , VV1fMY))
  FFkQDN("mv -f %s %s" % (VV1fMY + "OBF/plugin.py", VV1fMY))
 def VVAFrE(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFBsVa(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFBsVa(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VVEiuJ("%s*.list" % path)
  if err:
   FFPQyp(self, path + "*.list")
   return
  srcF, err = self.VVEiuJ("%s*main_final.py" % path)
  if err:
   FFPQyp(self, path + "*.final.py")
   return
  VVBQW6 = []
  for f in files:
   f = os.path.basename(f)
   VVBQW6.append((f, f))
  FFd7BR(self, BF(self.VVWu7Y, path, codF, srcF), VVtZf8=VVBQW6)
 def VVWu7Y(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFPQyp(self, logF)
   else     : FFn5td(self, BF(self.VV5fik, logF, codF, srcF))
 def VV5fik(self, logF, codF, srcF):
  lst  = []
  lines = FFMy5k(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFBsVa(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVDx6W(lst, logF, newLogF)
  totSrc  = self.VVDx6W(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FFVBx2(self, txt)
 def VVEiuJ(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVDx6W(self, lst, f1, f2):
  txt = FFl3Sc(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVfiPX(self):
  VVBQW6 = []
  VVBQW6.append("%s%s" % (VV1fMY, "*.py"))
  VVBQW6.append("%s%s" % (VV1fMY, "*.png"))
  VVBQW6.append("%s%s" % (VV1fMY, "*.xml"))
  VVBQW6.append("%s"  % (VVG8hM))
  FFStK7(self, VVBQW6, "%s_%s" % (PLUGIN_NAME, VVDJVr), addTimeStamp=False)
 def VVkbBh(self):
  path1 = VV7aeL
  path2 = "/etc/tuxbox/"
  VVBQW6 = []
  VVBQW6.append("%s%s" % (path1, "*.tv"))
  VVBQW6.append("%s%s" % (path1, "*.radio"))
  VVBQW6.append("%s%s" % (path1, "*list"))
  VVBQW6.append("%s%s" % (path1, "lamedb*"))
  VVBQW6.append("%s%s" % (path2, "*.xml"))
  FFStK7(self, VVBQW6, self.VVRxkI("channels_backup"), addTimeStamp=True)
 def VVjrdq(self):
  VVBQW6 = []
  VVBQW6.append("/etc/tuxbox/config/")
  VVBQW6.append("/usr/keys/")
  VVBQW6.append("/usr/scam/")
  VVBQW6.append("/etc/CCcam.cfg")
  FFStK7(self, VVBQW6, self.VVRxkI("softcam_backup"), addTimeStamp=True)
 def VVF7bd(self):
  VVBQW6 = []
  VVBQW6.append("/etc/hostname")
  VVBQW6.append("/etc/default_gw")
  VVBQW6.append("/etc/resolv.conf")
  VVBQW6.append("/etc/wpa_supplicant*.conf")
  VVBQW6.append("/etc/network/interfaces")
  VVBQW6.append("%snameserversdns.conf" % VV7aeL)
  FFStK7(self, VVBQW6, self.VVRxkI("network_backup"), addTimeStamp=True)
 def VVRxkI(self, fName):
  img = CCY0Fb.VVSYLB()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVMKVs(self, fileName=None):
  if fileName:
   FFEN35(self, BF(FFn5td, self, BF(self.VVRisW, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVRisW(self, fileName):
  path = "%s%s" % (VVzbRf, fileName)
  if fileExists(path):
   if CC5iId.VVgNvP(path):
    VVVGll , VV7GKC = CC8mGp.VVwWsx()
    VVzRji, VVWNRA = CC8mGp.VVSXp8()
    cmd  = FFaBql("cd %s" % VV7aeL)
    cmd += FFaBql("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VV7GKC, VVWNRA))
    cmd += "tar -xzf '%s' -C /" % path
    ok = FFkQDN(cmd)
    FFOnqc()
    if ok: FFx4Fl(self, "Channels Restored.")
    else : FFBsVa(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFBsVa(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFPQyp(self, path)
 def VV2f3R(self, fileName=None):
  if fileName:
   FFEN35(self, BF(self.VVPP8P, fileName), "Overwrite SoftCAM files ?")
 def VVPP8P(self, fileName):
  fileName = "%s%s" % (VVzbRf, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FFQwGu(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFPk5q(note, VV0V0q), sep))
  else:
   FFPQyp(self, fileName)
 def VVX6G1(self, fileName=None):
  if fileName:
   FFEN35(self, BF(self.VV9ksu, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV9ksu(self, fileName):
  fileName = "%s%s" % (VVzbRf, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FFeWwS(self,  cmd)
  else:
   FFPQyp(self, fileName)
 def VVVrcW(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFwW71()
  if pathExists(VVzbRf):
   myFiles = FF8hHp(VVzbRf, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVBQW6 = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVBQW6.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVA2fW = ("Sat. List", self.VVVl6K)
    elif isChan and iTar: VVA2fW = ("Bouquets Importer", CCAniX.VV56F9)
    else    : VVA2fW = None
    FFd7BR(self, callBackFunction, title=title, width=1200, VVtZf8=VVBQW6, VVA2fW=VVA2fW, VVK9oq=VVzbRf)
   else:
    FFBsVa(self, "No files found in:\n\n%s" % VVzbRf, title)
  else:
   FFBsVa(self, "Path not found:\n\n%s" % VVzbRf, title)
 def VVDX2I(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VV7aeL
  tCons = CC6Ith()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVWa6f, filePrefix))
 def VVWa6f(self, filePrefix, result, retval):
  title = FFwW71()
  if pathExists(VVzbRf):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFBsVa(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVzbRf, filePrefix, self.VVRxkI(""), FF0Isj())
    try:
     VVBQW6 = str(result.strip()).split()
     if VVBQW6:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVBQW6:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FFxrb0(fName, VV0V0q), SEP)
       FFVBx2(self, txt, title=title, VVeLJi=VVEkFU)
      else:
       FFBsVa(self, "File creation failed!", title)
     else:
      FFBsVa(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFkQDN("rm %s" % fName)
     FFBsVa(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFkQDN("rm %s" % fName)
     FFBsVa(self, "Error while writing file.")
  else:
   FFBsVa(self, "Path not found:\n\n%s" % VVzbRf, title)
 def VVd6uH(self, mode, path=None):
  if path:
   path = "%s%s" % (VVzbRf, path)
   if fileExists(path):
    lines = FFMy5k(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFEN35(self, BF(self.VVqxjO, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF0v65(self, path, title=FFwW71())
   else:
    FFPQyp(self, path)
 def VVqxjO(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVaRoH = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVaRoH.append("echo -e 'Reading current settings ...'")
  VVaRoH.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVaRoH.append("echo -e 'Preparing new settings ...'")
  VVaRoH.append(settingsLines)
  VVaRoH.append("echo -e 'Applying new settings ...'")
  VVaRoH.append("mv -f %s %s" % (tFile, sFile))
  FFvqDM(self, VVaRoH)
 def VVVl6K(self, selectionObj, path):
  if not path:
   return
  path = VVzbRf + path
  if not fileExists(path):
   FFPQyp(self, path)
   return
  txt = FFl3Sc(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFM86X(item[1]))
   FFVBx2(self, txt, title="Satellites List")
  else:
   FFBsVa(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCAniX():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VV56F9(SELF, fName):
  bi = CCAniX(SELF)
  bi.instance = bi
  bi.VVP6oi(SELF, fName)
 @staticmethod
 def VVuPS5(SELF):
  bi = CCAniX(SELF)
  bi.instance = bi
  bi.VVSors()
 def VVP6oi(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVzbRf + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFn5td(waitObg, self.VViXPR, title="Reading bouquets ...")
  else      : self.VV3dB9(self.filePath)
 def VVwnxh(self, txt) : FFBsVa(self.SELF, txt, title=self.Title)
 def VVg3ap(self, txt)  : FFrBcM(self, txt, 1500)
 def VV3dB9(self, path) : FFPQyp(self.SELF, path, title=self.Title)
 def VVSors(self):
  if pathExists(VVzbRf):
   lst = FF8hHp(VVzbRf, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VVax8h())
   if len(lst) > 0:
    VVtZf8 = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFxrb0(item, VVwwau) if item.endswith(".zip") else item
     VVtZf8.append((txt, item))
    VVtZf8.sort(key=lambda x: x[1].lower())
    VVoeva = self.VVauTS
    FFd7BR(self.SELF, self.VVG3pi, minRows=3, title=self.Title, width=1200, VVtZf8=VVtZf8, VVoeva=VVoeva, VVK9oq=VVzbRf, VVRmfT="#22111111", VVRNJt="#22111111")
   else:
    self.VVwnxh("No valid backup files found in:\n\n%s" % VVzbRf)
  else:
   self.VVwnxh("Backup Directory not found:\n\n%s" % VVzbRf)
 def VVauTS(self, item=None):
  if item:
   VVlE2Q, txt, fName, ndx = item
   self.VVP6oi(VVlE2Q, fName)
 def VVG3pi(self, item=None):
  if not item and self.instance:
   del self.instance
 def VVax8h(self):
  files = FF8hHp(VVzbRf, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VViXPR(self):
  lines, err = CCAniX.VVECz7(self.filePath, "bouquets.tv")
  if err:
   self.VVwnxh(err)
   return
  bTvSortLst  = self.VVXToC(lines)
  lines, err = CCAniX.VVECz7(self.filePath, "bouquets.radio")
  if err:
   self.VVwnxh(err)
   return
  bRadSortLst = self.VVXToC(lines)
  VVaKg1 = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVtNdd(f, mode, len(VVaKg1), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVaKg1.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVtNdd(f, mode, len(VVaKg1), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVtNdd(f, mode, len(VVaKg1), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVaKg1.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVtNdd(f, mode, len(VVaKg1), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVaKg1:
   VVaKg1.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVaKg1): VVaKg1[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVaKg1):
     if key == os.path.basename(row[9]):
      VVaKg1 = VVaKg1[:ndx+1] + lst + VVaKg1[ndx+1:]
      break
   for ndx, item in enumerate(VVaKg1): VVaKg1[ndx][0] = str(ndx + 1)
   VV84wP = "#11000600"
   VVTXLQ  = ("Show Services" , self.VVA3xL  , [], "Reading ..." )
   VVZRP4 = (""    , self.VVA6bO, [])
   VVFaAj = ("Options"  , self.VVISNf, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVGQvW  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FFuI68(self.SELF, None, title=self.Title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=24, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VVFaAj=VVFaAj, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVRmfT=VV84wP, VVRNJt=VV84wP, VV84wP=VV84wP, VVvmBM="#00004455", VVfpy3="#0a282828")
  else:
   self.VVwnxh("No valid bouquets in:\n\n%s" % self.filePath)
 def VVXToC(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVA6bO(self, VVzzNZ, title, txt, colList):
  FFVBx2(self.SELF, FFpnOy(txt), title=title)
 def VVISNf(self, VVzzNZ, title, txt, colList):
  mSel = CC7G9K(self.SELF, VVzzNZ)
  if VVzzNZ.VVoCEo:
   totSel = VVzzNZ.VVRFlF()
   if totSel: VVtZf8 = [("Import %s Bouquet%s" % (FFxrb0(str(totSel), VVCKEk), FFAHjU(totSel)), "imp")]
   else  : VVtZf8 = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFxrb0(bName, VVCKEk)
   VVtZf8 = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFn5td, VVzzNZ, BF(CCAniX.VVNstl, self.SELF, VVzzNZ, self.filePath))}
  mSel.VVaknP(VVtZf8, cbFncDict)
 def VVA3xL(self, VVzzNZ, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCAniX.VVECz7(self.filePath, "lamedb")
   if err:
    self.VVwnxh(err)
    return
   dbServLst = CC8mGp.VV9IFu(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVzzNZ.VVQ0F0()
   lines, err = CCAniX.VVECz7(self.filePath, os.path.basename(fName))
   if err:
    self.VVwnxh(err)
    return
   VVaKg1 = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVaKg1.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVaKg1.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVaKg1.append((span.group(1).strip() or "-", "Stream Relay" if FFpPAo(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVaKg1.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVaKg1.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CC8mGp.VVBJAF(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVaKg1.append((name.strip() or "-", FFYMB2(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVaKg1):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCAniX.VVECz7(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVaKg1[ndx] = (bName, descr)
   if VVaKg1:
    VV84wP = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVGQvW = (LEFT  , CENTER)
    FFuI68(self.SELF, None, title="Services in : %s" % bName, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=28, VVRmfT=VV84wP, VVRNJt=VV84wP, VV84wP=VV84wP, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FFrBcM(VVzzNZ, err, 1500)
  else : VVzzNZ.VVD7du()
 def VVtNdd(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVwnxh("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFpPAo(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVdl9w(var):
   return str(var) if var else VVi96Z + str(var)
  totItem = VV0V0q + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVmxw7   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVwwau, "Sub-B."
  else  : bColor, totBnb = ""      , VVdl9w(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVdl9w(totDVB), VVdl9w(totIptv), VVdl9w(totSRelay), VVdl9w(totLoc), VVdl9w(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVNstl(SELF, VVzzNZ, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VV7aeL + "bouquets.tv"
  radBouquetFile = VV7aeL + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFPQyp(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFPQyp(SELF, radBouquetFile, title=title)
   return
  isMulti = VVzzNZ.VVoCEo
  if isMulti : rows = VVzzNZ.VVFveQ()
  else  : rows = [VVzzNZ.VVQ0F0()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFBsVa(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFpnOy(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFpnOy(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VV7aeL + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VV7aeL + newFile
    CCAniX.VV6jeq(archPath, fName, VV7aeL, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FF4xUI(tvBouquetFile)
   FF4xUI(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCAniX.VVcEkX(SELF, archPath, bList)
   FFOnqc()
  txt  = FFxrb0("Added:\n", VVwwau)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFxrb0("Imported to lamedab:\n", VVwwau)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFxrb0("Missing from archived lamedb:\n", VVmxw7)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FFVBx2(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVcEkX(SELF, archPath, bList):
  VVVGll, err = CC8mGp.VVZ5Jg(SELF, VVO4lq=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CC8mGp.VV4AsU(VVVGll, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFMy5k(VV7aeL + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CC8mGp.VVBJAF(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CC8mGp.VVpmKT(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCAniX.VVi1XM(archPath, dbName)
   CCAniX.VV6jeq(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CC8mGp.VV4AsU(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CC8mGp.VV4AsU(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CC8mGp.VV4AsU(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CC8mGp.VV4AsU(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFKqXn(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVVGll + ".tmp"
   lines   = FFMy5k(VVVGll)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFkQDN("mv -f '%s' '%s'" % (tmpDbFile, VVVGll))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VVhiTD(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVi1XM(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VV6jeq(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVECz7(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CC2rP2():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VV9a0n()
 def VV9a0n(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVmQjB(self):
  FFn5td(self, self.VVQifx)
 def VVQifx(self):
  if pathExists(self.projMainPath):
   lst = FFmn2G(self.projMainPath)
   VVtZf8 = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVtZf8.append((prName, prName))
   if VVtZf8:
    VVtZf8.sort(key=lambda x: x[1].lower())
    VVoeva = self.VVFsHs
    VVA2fW = ("Add new project", self.VV0wqQ)
    VVJlf7= ("Delete Project" , self.VVLViA)
    self.projMenu = FFd7BR(self, None, VVtZf8=VVtZf8, width=1100, VVoeva=VVoeva, VVA2fW=VVA2fW, VVJlf7=VVJlf7, minRows=5, VVRmfT="#22111133", VVRNJt="#22111133")
   else:
    FFEN35(self, self.VVt7bj, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VVgSFq("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVt7bj(self)    : FFn5td(self, BF(self.VVfHqp))
 def VV0wqQ(self, VVlE2Q, item) : FFn5td(self.projMenu, BF(self.VVfHqp))
 def VVfHqp(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVaxHa(name)
 def VVaxHa(self, name, cbFnc=None):
  FFsCnW(self, cbFnc or self.VVtVP4, defaultText=name, title="New Project Name", message="Enter project name")
 def VVtVP4(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFEN35(self, BF(self.VVaxHa, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FF4Qy8(path)
    if err:
     self.VVgSFq("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVBwiX((item, item), isSort=True)
     else   : self.VVmQjB()
 def VVLViA(self, VVlE2Q, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FFFX6Q(path)
    FFEN35(self, BF(self.VVd46Z, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VVd46Z(self, path):
  if FFkQDN("rm -rf '%s'" % path):
   self.projMenu.VV9YzJ()
 def VVFsHs(self, item=None):
  if item:
   VVlE2Q, txt, Dir, ndx = item
   self.VV9a0n()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VVG8hM
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FFMy5k(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFByGk()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVynNQ()
   else      : self.VVgSFq("Cannot create project file:\n\n%s" % self.projFile)
 def VVynNQ(self, VVlE2Q=None, jmpDict=None):
  FFn5td(VVlE2Q or self.projTable or self, BF(self.VViMkV, jmpDict))
 def VViMkV(self, jmpDict):
  self.VV9a0n()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FFMy5k(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VVgGP5(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VVgSFq('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFotbw(path)
    if sz > -1: size = CC5iId.VVp3Jg(sz, mode=4)
    else   : size = FFxrb0("Size error", VVmxw7)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FFMy5k(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVuqs4(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVfLjn(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FFxrb0("Unknown value", VVmxw7), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FFxrb0(rem, VVmxw7), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVaKg1 = pkgRows
  VVaKg1.extend(actnRows)
  VVaKg1.extend(ctrlRows)
  VVaKg1.extend(fileRows)
  VVaKg1.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVaKg1):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FFxrb0("Valid", VVCKEk), " ... " + Remarks if Remarks else "")
    VVaKg1[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VV311O(VVaKg1, tableRefreshCB=BF(self.VV6J8k, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVZRP4 = (""     , self.VVy4gm   , [])
   menuButtonFnc = (""     , self.VVaLHj   , [])
   VVXfC8 = ("Create Package"  , self.VVKIvq , [])
   VVFaAj = ("Post Install Action", self.VVxSRs, [])
   VV6CVp = ("Edit File"   , self.VVILN0  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVGQvW = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, width=1850, height=1040, VVJgEp=26, VVZRP4=VVZRP4, menuButtonFnc=menuButtonFnc, VVXfC8=VVXfC8, VVFaAj=VVFaAj, VV6CVp=VV6CVp, searchCol=2
         , VVRmfT=bg, VVRNJt=bg, VV84wP=bg, VVvmBM="#00664411", VVfpy3="#00444444", VViJnU="#08442211")
   self.projTable.VVLx7i(self.VVVqV7, True)
 def VV6J8k(self, jmpDict, VVzzNZ, title, txt, colList):
  self.projTable.VVGQiM(jmpDict)
 def VVVqV7(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVQ0F0()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VVgGP5(self, line):
  def VVbF8S(patt, val, Len):
   if len(val) < Len   : return FFxrb0("Length error" , VVmxw7)
   elif not iMatch(patt, val) : return FFxrb0("Invalid format" , VVmxw7)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVbF8S(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVbF8S(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVuqs4(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFvYBl(path)
  path = FF3NDk(path)
  c = VVmxw7
  if   typ == "Mount" : rem = FFxrb0("Not allowed", c)
  elif not typ  : rem = FFxrb0("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FFxrb0("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFQzS1(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFvYBl(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FFxrb0("Not allowed", c)
     elif targetType == "Directory" : sz = FFQzS1(targetPath)
     elif targetType == "File"  : sz = FFotbw(targetPath)
     else       : sz, rem = FFotbw(path), FFxrb0("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFotbw(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CC5iId.VVp3Jg(sz, mode=4)
     else:
      size = FFxrb0("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVfLjn(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVILN0(self, VVzzNZ, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCteri(self, path, VVqhY7=self.VVtYS8, curRowNum=lineNdx)
  else    : FFPQyp(self, path)
 def VVtYS8(self, fileChanged):
  if fileChanged:
   self.VVynNQ()
 def VVgSFq(self, txt):
  FFBsVa(self, txt, title=self.projTitle)
 def VVy4gm(self, VVzzNZ, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVwwau
  s  = FFElFp("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFElFp("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CC5iId.VVp3Jg(self.projFilesSize))
  FFVBx2(self, s, title="Project Info", width=1600)
 def VVaLHj(self, VVzzNZ, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVs7I8, VVquhO, VVwwau
  VVtZf8 = []
  VVtZf8.append((c1 + "Add Resource File"  , "addFile" ))
  VVtZf8.append((c1 + "Add Resource Directory" , "addDir" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Change Package Name"   , "pkgNam" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c2 + "Add Dependency"   , "addDep" ))
  VVtZf8.append((c2 + "Remove Dependency"  , "delDep" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVtZf8.append(FFTjqa('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(FFTjqa("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVmxw7))
  FFd7BR(self, self.VV4Sbr, VVtZf8=VVtZf8, width=1050, title="Options", VVRmfT="#11001122", VVRNJt="#11001122")
 def VV4Sbr(self, item=None):
  if item:
   if   item == "addFile" : self.VVSTEC(False)
   elif item == "addDir" : self.VVSTEC(True)
   elif item == "pkgNam" : self.VV3OUt()
   elif item == "addDep" : FFn5td(self.projTable, self.VVgIgy)
   elif item == "delDep" : self.VVoedt()
   elif item == "ctrlFMan" : self.VVdFpH()
   elif item == "ctrlImprt": FFn5td(self.projTable, self.VV5PPK)
   elif item == "ctrlUndo" : self.VVRVoG()
   elif item == "delRow" : self.VVOEKm()
 def VVSTEC(self, isDir):
  Dir = FFghFX(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVp0kE, BF(CC5iId, mode=CC5iId.VVtux5, VV0aja=Dir))
  else : self.session.openWithCallback(self.VVp0kE, BF(CC5iId, patternMode="all", VV0aja=Dir))
 def VVp0kE(self, path):
  if path:
   FFSeyu(CFG.lastPkgProjDir, path)
   self.VVfne8(path, 2)
 def VVdFpH(self):
  Dir = FFghFX(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVabXw, BF(CC5iId, patternMode="pkgCtrl", VV0aja=Dir))
 def VVabXw(self, path):
  if path:
   FFSeyu(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFkQDN("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVynNQ()
    self.projTable.VVGQiM({1:"Script", 2:fName})
 def VV5PPK(self):
  cmd = FFYH4A(VV5oWt, "")
  if not cmd:
   FF5yx0(self)
   return
  lst = FFIM7p(cmd)
  if lst:
   err = CC5iId.VVuDDL(lst, fromFind=False)
   if err:
    self.VVgSFq(err)
    return
   lst.sort()
   VVaKg1 = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVaKg1.append(("", span.group(1), span.group(2)))
   if VVaKg1:
    VVIZTW = ("Import 'control' data", self.VVImrn, [])
    VVFaAj = ("Package Info.", self.VVMvss     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FFuI68(self, None, header=header, VVBQW6=VVaKg1, VV3FCq=widths, VVJgEp=30, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VVtrG6=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVRmfT="#22110011", VVRNJt="#22191111", VV84wP="#22191111", VVvmBM="#00003030", VVfpy3="#00333333")
   else:
    self.VVgSFq("Cannot process installed packages !")
  else:
   self.VVgSFq("Cannot read installed packages !")
 def VVRVoG(self):
  if FFkQDN("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVynNQ(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VVgSFq("Process Failed !")
 def VVImrn(self, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VVsETM, VVzzNZ, colList[1]))
 def VVsETM(self, VVzzNZ, pkg):
  lines = []
  for line in FFIM7p(FFgOTM(VVl8YC, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFEN35(self, BF(self.VVUqh4, VVzzNZ, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VVgSFq("Cannot import from this package:\n\n%s" % pkg)
 def VVUqh4(self, VVzzNZ, lines):
  VVzzNZ.cancel()
  FFmO9U(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVynNQ(jmpDict={1:"Control", 2:"Package"})
 def VVOEKm(self):
  lineNum = int(self.projTable.VVQ0F0()[0]) + 1
  FFkQDN("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVynNQ()
 def VVfne8(self, line, jmp):
  if fileExists(self.projFile):
   FFmO9U(self.projFile)
   FF4xUI(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVynNQ(jmpDict=jmpDict)
  else:
   FFPQyp(self, self.projFile, title=self.projTitle)
 def VVxSRs(self, VVzzNZ, title, txt, colList):
  VVtZf8 = []
  VVtZf8.append(FFTjqa("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVtZf8.append(FFTjqa("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVtZf8.append(FFTjqa("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(FFTjqa("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVtZf8.append(FFTjqa("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVtZf8.append(FFTjqa("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFd7BR(self, self.VV8s2M, VVtZf8=VVtZf8, title="Action (after the package is installed/removed)")
 def VV8s2M(self, item=None):
  if item:
   if   item == "instNon" : self.VVAl1D("postinst", 0)
   elif item == "instRes" : self.VVAl1D("postinst", 1)
   elif item == "instReb" : self.VVAl1D("postinst", 2)
   elif item == "rmNon" : self.VVAl1D("postrm", 0)
   elif item == "rmRes" : self.VVAl1D("postrm", 1)
   elif item == "rmReb" : self.VVAl1D("postrm", 2)
 def VVAl1D(self, subj, val):
  if fileExists(self.projFile):
   lines = FFMy5k(self.projFile)
   FFmO9U(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VVfne8("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVynNQ()
 def VV3OUt(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVtZf8 = []
  VVtZf8.append((pkg, pkg))
  VVtZf8.append(VVh3VV)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVwwau if name == self.projPkg else ""
    VVtZf8.append((c + name, name))
   else:
    VVtZf8.append(VVh3VV)
  FFd7BR(self, self.VVd7k6, VVtZf8=VVtZf8, title="Package Name")
 def VVd7k6(self, item=None):
  if item:
   self.VVlPKb("Package", item)
 def VVgIgy(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVtZf8 = []
   for item in lst: VVtZf8.append((item, item))
   VVtZf8.sort(key=lambda x: x[0].lower())
   VVlE2Q = FFd7BR(self, self.VV9XBm, VVtZf8=VVtZf8, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VVlE2Q.VV7hwP(self.projLastDepends)
  else:
   self.VVgSFq("Cannot read dependencies list !")
 def VV9XBm(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FFMy5k(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVlPKb("Depends", ", ".join(lst))
   else:
    FFrBcM(self.projTable, "Already added", 1500)
    self.projTable.VVGQiM({1:"Control", 2:"Depends"})
 def VVoedt(self):
  lst = []
  for row in self.projTable.VVMHVB():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVtZf8 = []
   for item in lst: VVtZf8.append((item, item))
   FFd7BR(self, BF(self.VV7wY5, lst), VVtZf8=VVtZf8, title="Remove Dependency")
  else:
   self.VVgSFq("No dependencies to remove !")
 def VV7wY5(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVlPKb("Depends", ", ".join(lst))
   else:
    FFkQDN("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVynNQ()
 def VVlPKb(self, subj, val):
  lines = FFMy5k(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVynNQ(jmpDict={1:"Control", 2:subj})
 def VVKIvq(self, VVzzNZ, title, txt, colList):
  VVtZf8 = []
  VVtZf8.append(("Create .ipk"  , "ipk"))
  VVtZf8.append(("Create .deb"  , "deb"))
  VVtZf8.append(("Create .tar.gz" , "tar"))
  FFd7BR(self, self.VVJ6kM, VVtZf8=VVtZf8, width=500, title=self.projTitle)
 def VVJ6kM(self, item=None):
  if item:
   FFn5td(self.projTable, BF(self.VVPV2B, item))
 def VVPV2B(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VVgSFq("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVITRg, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVITRg, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VVgSFq(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFaBql("rm -rf '%s'" % projDir)
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFPk5q(result  , VVCKEk))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFPk5q(failed, VVKRbh))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFaBql("rm -f '%s'" % pkgFile)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVMHVB()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FFeWwS(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFkQDN(cmd) or not pathExists(ctrlDir):
   VVgSFq(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVbF8S(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFkQDN("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVbF8S(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FF4xUI(dstF)
   FFkQDN("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFJDAH()
  if VVITRg:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFhejV("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FFeWwS(self, cmd)
class CCIU8A(Screen, CC2rP2):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVL2J2, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CC2rP2.__init__(self)
  c1, c2, c3, c4 = VVs7I8, VVquhO, VVOICC, VVwwau
  VVtZf8 = []
  VVtZf8.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c3 + "Remove Packages (show all)"     , "VVENAMsAll"  ))
  VVtZf8.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c2 + "Update Packages List from Feed"    , "VVIc0h"  ))
  VVtZf8.append((c2 + "Upgradable Packages"       , "VV0H5O" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Packaging Tool"         , "VVt0D9"   ))
  VVtZf8.append(("Active Feeds"          , "VVdKpB"   ))
  FFd98D(self, VVtZf8=VVtZf8)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCQiTA.VVlMvE(self)
   elif item == "downloadInstallPackages"  : FFn5td(self, BF(self.VVYOei, 0, ""))
   elif item == "VVENAMsAll"   : FFn5td(self, BF(self.VVYOei, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFn5td(self, BF(self.VVYOei, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVIc0h"   : CCIU8A.VVIc0h(self)
   elif item == "VV0H5O"  : FFn5td(self, self.VV0H5O)
   elif item == "packageCreator"    : self.VVmQjB()
   elif item == "VVt0D9"    : self.VVt0D9()
   elif item == "VVdKpB"    : FFn5td(self, self.VVdKpB)
   else          : self.close()
 def VVdKpB(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVaKg1 = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVaKg1.append((os.path.basename(path), str(tot)))
  if VVaKg1:
   VVaKg1.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVGQvW = (LEFT  , CENTER )
   FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, width=1000, VVJgEp=26, VVhEUu=2)
  else:
   self.VVgSFq("Cannot read packages list !")
 def VV0H5O(self, VVzzNZ=None):
  lst = FFIM7p(FFYH4A(VVbOZm, ""))
  VVaKg1 = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVaKg1.append((str(len(VVaKg1) + 1), pkg, curV, newVer))
   if VVaKg1:
    if VVzzNZ:
     VVzzNZ.VV311O(VVaKg1, VV3PMMMsg=True)
    else:
     bg = "#00221111"
     VVIZTW = ("Upgrade", self.VVwz3X   , [])
     VVFaAj = ("Package Info.", self.VVMvss , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVGQvW = (CENTER , LEFT  , LEFT  , LEFT   )
     FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, width=1700, VVJgEp=26, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV3cto=True, VVFsq0=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVRmfT=bg, VVRNJt=bg, VV84wP=bg, VVH7qA="#00ffff55", VVvmBM="#00003040")
  if not VVaKg1:
   FFQAm4(self, "Nothing to upgrade", 1500)
   if VVzzNZ: VVzzNZ.cancel()
 def VVwz3X(self, VVzzNZ, title, txt, colList):
  pkg = colList[1]
  cmd = FFgOTM(VV6ESW, pkg)
  if cmd : FFeWwS(self, cmd, title="Installing : %s" % pkg, VVBjuq=BF(self.VV0H5O, VVzzNZ))
  else : FF5yx0(SELF)
 def VVt0D9(self):
  pkg = FFNDlH()
  aptT = "apt - Advanced Package Tool" if FFtTXa("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FFx4Fl(self, txt or "No packaging tools found!")
 def VVYOei(self, mode, grep, VVzzNZ=None, title=""):
  if   mode == 0: cmd = FFYH4A(VVFU7m    , grep)
  elif mode == 1: cmd = FFYH4A(VV5oWt , grep)
  elif mode == 2: cmd = FFYH4A(VV5oWt , grep)
  if not cmd:
   FF5yx0(self)
   return
  VVaKg1 = FFIM7p(cmd)
  if VVaKg1:
   err = CC5iId.VVuDDL(VVaKg1, fromFind=False)
   if err:
    FFBsVa(self, err)
    return
  else:
   if VVzzNZ: VVzzNZ.VVD7du()
   FFBsVa(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVBQW6  = []
  for item in VVaKg1:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVBQW6.append((name, package, version))
  if mode > 0:
   extensions = FFIM7p("ls %s -l | grep '^d' | awk '{print $9}'" % VVJT98)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVBQW6:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VV9Vh8: name += "el"
      VVBQW6.append((name, VVJT98 + item, "-"))
   systemPlugins = FFIM7p("ls %s -l | grep '^d' | awk '{print $9}'" % VVU7z8)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVBQW6:
      if item.lower() == row[0].lower():
       break
     else:
      VVBQW6.append((item, VVU7z8 + item, "-"))
  if not VVBQW6:
   FFBsVa(self, "No packages found!")
   return
  if VVzzNZ:
   VVBQW6.sort(key=lambda x: x[0].lower())
   VVzzNZ.VV311O(VVBQW6, title)
  else:
   widths = (20, 50, 30)
   VVIZTW = None
   VV6CVp = None
   if mode == 0:
    VVXfC8 = ("Install" , self.VV6kKm   , [])
    VVIZTW = ("Download" , self.VV2Mwk   , [])
    VV6CVp = ("Filter"  , self.VV64Ra , [])
   elif mode == 1:
    VVXfC8 = ("Uninstall", self.VVENAM, [])
   elif mode == 2:
    VVXfC8 = ("Uninstall", self.VVENAM, [])
    widths= (18, 57, 25)
   VVBQW6.sort(key=lambda x: x[0].lower())
   VVFaAj = ("Package Info.", self.VVMvss, [])
   header   = ("Name" ,"Package" , "Version" )
   FFuI68(self, None, header=header, VVBQW6=VVBQW6, VV3FCq=widths, VVJgEp=28, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VVtrG6=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVRmfT="#22110011", VVRNJt="#22191111", VV84wP="#22191111", VVvmBM="#00003030", VVfpy3="#00333333")
 def VVMvss(self, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VV7NSd, VVzzNZ, colList[1]))
 def VV7NSd(self, VVzzNZ, pkg):
  if pathExists(pkg):
   pkg, err = CCIU8A.VVQ68o(pkg)
   if err:
    FFQAm4(VVzzNZ, err, 1000)
    return
  CCIU8A.VVEpSl(self, pkg)
 def VV64Ra(self, VVzzNZ, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVtZf8 = []
  VVtZf8.append(("All Packages", "all"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVtZf8.append(VVh3VV)
  for word in words:
   VVtZf8.append((word, word))
  FFd7BR(self, BF(self.VVYcl4, VVzzNZ), VVtZf8=VVtZf8, title="Select Filter")
 def VVYcl4(self, VVzzNZ, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFn5td(VVzzNZ, BF(self.VVYOei, 0, grep, VVzzNZ, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVENAM(self, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VV2Bxs, VVzzNZ, colList[1]))
 def VV2Bxs(self, VVzzNZ, package):
  if pathExists(package):
   pkg, err = CCIU8A.VVQ68o(package)
   if pkg:
    package = pkg
  if package.startswith((VVJT98, VVU7z8)):
   FFEN35(self, BF(self.VVYgid, VVzzNZ, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVtZf8 = []
   VVtZf8.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVtZf8.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVtZf8.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFd7BR(self, BF(self.VVGdfQ, VVzzNZ, package), VVtZf8=VVtZf8)
 def VVYgid(self, VVzzNZ, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VV6Dap)
  FFeWwS(self, cmd, VVBjuq=BF(self.VVegR3, VVzzNZ))
 def VVGdfQ(self, VVzzNZ, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VV2r4e
   elif item == "remove_ForceRemove"  : cmdOpt = VVyJXQ
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV2nyt
   FFEN35(self, BF(self.VVBlwq, VVzzNZ, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVBlwq(self, VVzzNZ, package, cmdOpt):
  self.lastSelectedRow = VVzzNZ.VVXRaz()
  cmd = FFgOTM(cmdOpt, package)
  if cmd : FFeWwS(self, cmd, VVBjuq=BF(self.VVegR3, VVzzNZ))
  else : FF5yx0(self)
 def VVegR3(self, VVzzNZ):
  VVzzNZ.cancel()
  FFbfAi()
 def VV6kKm(self, VVzzNZ, title, txt, colList):
  package  = colList[1]
  VVtZf8 = []
  VVtZf8.append(("Install Package"        , "install_CheckVersion" ))
  VVtZf8.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVtZf8.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVtZf8.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVtZf8.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFd7BR(self, BF(self.VV8VEa, package), VVtZf8=VVtZf8)
 def VV8VEa(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VV6ESW
   elif item == "install_ForceReinstall" : cmdOpt = VVJxPG
   elif item == "install_ForceOverwrite" : cmdOpt = VVhXh6
   elif item == "install_ForceDowngrade" : cmdOpt = VVQjjG
   elif item == "install_IgnoreDepends" : cmdOpt = VVlHps
   FFEN35(self, BF(self.VVr31P, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVr31P(self, package, cmdOpt):
  cmd = FFgOTM(cmdOpt, package)
  if cmd : FFeWwS(self, cmd, VVBjuq=FFbfAi, checkNetAccess=True)
  else : FF5yx0(self)
 def VV2Mwk(self, VVzzNZ, title, txt, colList):
  package  = colList[1]
  FFEN35(self, BF(self.VVTDhv, package), "Download Package ?\n\n%s" % package)
 def VVTDhv(self, package):
  if CCDTZn.VVay4r():
   cmd = FFgOTM(VVm1XS, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFPk5q(success, VVCKEk))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFPk5q(fail, VVKRbh))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FFeWwS(self, cmd, VVVk0m=[VVKRbh, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FF5yx0(self)
  else:
   FFBsVa(self, "No internet connection !")
 @staticmethod
 def VVIc0h(SELF):
  cmd = FFYH4A(VV63qG, "")
  if cmd : FFeWwS(SELF, cmd, checkNetAccess=True)
  else : FF5yx0(SELF)
 @staticmethod
 def VVQ68o(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFIM7p(FFgOTM(VVCyBl, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVEpSl(SELF, package, title=""):
  title = title or package
  infoCmd  = FFgOTM(VVl8YC, package)
  filesCmd = FFgOTM(VVDid1, package)
  listInstCmd = FFYH4A(VV5oWt, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFdk7R(VV0V0q)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFPk5q(notInst, VVmxw7))
   cmd += "else "
   cmd +=   FF9OqO("System Info", VV0V0q)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FF9OqO("Related Files", VV0V0q)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFxN9O(SELF, cmd, title=title)
  else:
   FF5yx0(SELF, title=title)
class CCdfMN():
 def VVcwDK(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVtwXj()
 def VVtwXj(self):
  files = FF8hHp(VVzbRf, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVtZf8 = []
   for fil in files:
    VVtZf8.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVRmfT, VVRNJt = "#22221133", "#22221133"
   else    : VVRmfT, VVRNJt = "#22003344", "#22002233"
   VVA2fW  = ("Add new File", self.VVO71B)
   FFd7BR(self, self.VVQJGg, VVtZf8=VVtZf8, width=1100, VVA2fW=VVA2fW, VVK9oq="", minRows=4, VVRmfT=VVRmfT, VVRNJt=VVRNJt)
  else:
   FFEN35(self, self.VVDZzW, "No files found.\n\nCreate a new file ?")
 def VVDZzW(self):
  path = self.VVJVQt()
  if fileExists(path) : self.VVtwXj()
  else    : FFrBcM(self, "Cannot create file", 1500)
 def VVO71B(self, VVlE2Q, path):
  path = self.VVJVQt()
  VVlE2Q.VVBwiX((os.path.basename(path), path), isSort=True)
 def VVJVQt(self):
  path = "%s%s%s.xml" % (VVzbRf, self.shareFilePrefix, FF0Isj())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVQJGg(self, path=None):
  if path:
   FFn5td(self, BF(self.VV8FS0, path))
 def VV8FS0(self, path):
  if not fileExists(path):
   FFPQyp(self, path)
   return
  elif not CC5iId.VVHX4f(self, path, FFwW71()):
   return
  else:
   self.shareFilePath = path
  if not CCyO3o.VVG6c7(self):
   return
  tree = CC8mGp.VV5F3o(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCQq9Y.VVFMme()
  def VVIsuR(refCode):
   if   FFoesm(refCode): return FFxrb0("DVB", VVs7I8)
   elif refCode in refLst     : return FFxrb0("IPTV", VVs7I8)
   else         : return ""
  VVaKg1= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVdopA(ch)
   if ok:
    srcTxt = VVIsuR(srcRef)
    dstTxt = VVIsuR(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVaKg1:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVaKg1.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVaKg1:
   if self.shareIsRef : VVRmfT, VVRNJt, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVRmfT, VVRNJt, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVeJ6x = (""    , BF(self.VVmjBL, dupl), [])
   VVZRP4 = (""    , self.VVN0wT    , [])
   VVXfC8 = ("Delete Entry" , self.VVjdxf   , [])
   VVIZTW = ("Add Entry"  , self.VVxRnM   , [])
   VVFaAj = (optTxt   , self.VVx99T  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVGQvW = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVzzNZ = FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=24, VVeJ6x=VVeJ6x, VVZRP4=VVZRP4, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV3cto=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVRmfT=VVRmfT, VVRNJt=VVRNJt, VV84wP=VVRNJt, VVvmBM="#0a000000")
  else:
   FFBsVa(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VVmjBL(self, dupl, VVzzNZ, title, txt, colList):
  if dupl:
   VVzzNZ.VVNLt2("Skipped %d duplicate%s" % (dupl, FFAHjU(dupl)), 2000)
 def VVN0wT(self, VVzzNZ, title, txt, colList):
  def VVIsuR(key, val): return "%s\t: %s\n" % (key, val or FFxrb0("?", VVD46d))
  Keys = VVzzNZ.VV4x5I()
  Vals = VVzzNZ.VVQ0F0()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVIsuR(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVCKEk, VVD46d
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FFVBx2(self, txt + txt1, title=title)
 def VVdopA(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVjdxf(self, VVzzNZ, title, txt, colList):
  if VVzzNZ.VVXRaz() == 0 and VVzzNZ.VVdO40() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFEN35(self, BF(self.VVzyvX, isLast, VVzzNZ), ques)
 def VVzyvX(self, isLast, VVzzNZ):
  if isLast:
   FFKqXn(self.shareFilePath)
   VVzzNZ.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVzzNZ.VVQ0F0()
   if self.VVwega(srcName, srcRef, dstName, dstRef):
    VVzzNZ.VVJZ26()
    VVzzNZ.VVpdwW()
    FFrBcM(VVzzNZ, "Deleted", 500, isGrn=True)
   else:
    FFrBcM(VVzzNZ, "Cannot delete from file", 2000)
 def VVxRnM(self, VVzzNZ, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VV0U7Z(VVzzNZ, isDvb=True)
  else    : self.VVbygX(VVzzNZ, "Source Channel", "#22003344", "#22002233")
 def VVbygX(self, mainTableInst, title, VVRmfT, VVRNJt):
  FFd7BR(self, BF(self.VVORcn, mainTableInst, title), VVtZf8=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVRmfT=VVRmfT, VVRNJt=VVRNJt)
 def VVORcn(self, mainTableInst, title, item=None):
  if item:
   FFn5td(mainTableInst, BF(self.VVBTL7, mainTableInst, title, item), clearMsg=False)
 def VVBTL7(self, mainTableInst, title, item):
  FFrBcM(mainTableInst)
  if item == "DVB": self.VV0U7Z(mainTableInst, isDvb=True)
  else   : self.VV0U7Z(mainTableInst, isDvb=False)
 def VV5O8h(self, mainTableInst, chType, VVzzNZ, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVzzNZ.VVXRaz()
  if   chType == "DVB" : FFSeyu(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFSeyu(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVMHVB()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFBsVa(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVZhZ0(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVPCFQ((str(mainTableInst.VVdO40() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FFrBcM(mainTableInst, "Added", 500, isGrn=True)
     else:
      FFrBcM(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FFrBcM(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VV0U7Z(mainTableInst, isDvb=False)
   else    : FFb5Nn(BF(self.VVbygX, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVzzNZ.cancel()
 def VVPIXk(self, item, VVzzNZ, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVzzNZ.VV8i74(ndx)
 def VV0U7Z(self, VVzzNZ, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VV5O8h, VVzzNZ, typ)
  doneFnc = BF(self.VVPIXk, typ)
  if isDvb: CCdfMN.VVxYCB(VVzzNZ , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCdfMN.VVVWx2(VVzzNZ, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVxYCB(SELF, title, okFnc, doneFnc=None):
  FFn5td(SELF, BF(CCdfMN.VVxoCj, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVxoCj(SELF, title, okFnc, doneFnc=None):
  VVaKg1, err = CC8mGp.VV8K3y(SELF, CC8mGp.VVkDvA)
  if VVaKg1:
   color = "#0a000022"
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVTXLQ = ("Select" , okFnc, [])
   VVeJ6x= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVGQvW = (LEFT  , LEFT  , CENTER, LEFT    )
   FFuI68(SELF, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVRmfT=color, VVRNJt=color, VV84wP=color, VVTXLQ=VVTXLQ, VVeJ6x=VVeJ6x, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFBsVa(SELF, "No DVB Services !")
 @staticmethod
 def VVVWx2(SELF, title, okFnc, doneFnc=None):
  FFn5td(SELF, BF(CCdfMN.VVpIsR, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVpIsR(SELF, title, okFnc, doneFnc=None):
  VVaKg1 = CCdfMN.VVilZ0()
  if VVaKg1:
   color = "#0a112211"
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVTXLQ = ("Select" , okFnc, [])
   VVeJ6x= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FFuI68(SELF, None, title=title, header=header, VVBQW6=VVaKg1, VV3FCq=widths, VVJgEp=26, VVRmfT=color, VVRNJt=color, VV84wP=color, VVTXLQ=VVTXLQ, VVeJ6x=VVeJ6x, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFBsVa(SELF, "No IPTV Services !")
 @staticmethod
 def VVilZ0():
  VVaKg1 = []
  files  = CCnYqq.VVQk0n()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFl3Sc(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVe0gr = span.group(1)
    else : VVe0gr = ""
    VVe0gr_lCase = VVe0gr.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVaKg1.append((chName, VVe0gr, url, refCode))
  return VVaKg1
 def VVZhZ0(self, srcName, srcRef, dstName, dstRef):
  tree = CC8mGp.VV5F3o(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VVNIJW(tree, root)
  return True
 def VVwega(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CC8mGp.VV5F3o(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVdopA(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VVNIJW(tree, root)
  return found
 def VVNIJW(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CC8mGp.VVMxlt(xmlTxt)
  parser = CC8mGp.CCSbC5()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVx99T(self, VVzzNZ, title, txt, colList):
  if self.onlyEpg:
   self.VVbE7C(VVzzNZ, "epg")
  else:
   if self.shareIsRef:
    FFEN35(self, BF(FFn5td, VVzzNZ, BF(self.VVn3XG, VVzzNZ)), "Copy all References from Source to Destination ?")
   else:
    VVtZf8 = []
    VVtZf8.append(("Copy EPG\t (All List)" , "epg"  ))
    VVtZf8.append(("Copy Picons\t (All List)" , "picon" ))
    FFd7BR(self, BF(self.VVbE7C, VVzzNZ), VVtZf8=VVtZf8, width=1000)
 def VVbE7C(self, VVzzNZ, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVlikP  , "EPG"
   elif item == "picon": fnc, txt = self.VVGfyH , "PIcons"
   title = "Copy %s" % txt
   tot   = VVzzNZ.VVdO40()
   FFEN35(self, BF(FFn5td, VVzzNZ, BF(fnc, VVzzNZ, title)), "Overwrite %s for %d Service%s ?" % (FFxrb0(txt, VV0V0q), tot, FFAHjU(tot)), title=title)
 def VVn3XG(self, VVzzNZ):
  files = CCnYqq.VVQk0n()
  totChange = 0
  if files:
   for path in files:
    txt = FFl3Sc(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVzzNZ.VVMHVB():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFOnqc()
  tot = VVzzNZ.VVdO40()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FFVBx2(self, txt)
 def VVGfyH(self, VVzzNZ, title):
  if not iCopyfile:
   FFBsVa(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCjCYH.VVzyVV()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVzzNZ.VVMHVB():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVzzNZ.VVdO40()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FFVBx2(self, txt, title=title)
 def VVlikP(self, VVzzNZ, title):
  txt, err = CCNVQf.VVMXMf(VVzzNZ, title)
  if err : FFBsVa(self, err, title=title)
  else : FFVBx2(self, txt, title=title)
 class CCSbC5(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VV5F3o(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CC8mGp.CCSbC5())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFxrb0("XML Parse Error in:", VVD46d), path)
   txt += "%s\n%s\n\n" % (FFxrb0("Error:", VVD46d), str(e))
   FFVBx2(SELF, txt, VV84wP="#11220000", title=title)
   return None
 @staticmethod
 def VVMxlt(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCNVQf(Screen, CCdfMN):
 VVhA9R  = "BDTSE"
 VV9q9A   = "save"
 VVXi09   = "load"
 VVJ1Q4  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FF98gL(VVL2J2, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCNVQf.VVGCwz()
  qUrl, iptvRef = CCnYqq.VV5Dwl(self)
  VVtZf8 = []
  VVtZf8.append((VVs7I8 + "Cache File Info." , "inf"))
  VVtZf8.append(VVh3VV)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVtZf8.append(FFTjqa("Save EPG to File%s" % fTxt , self.VV9q9A, valid))
  VVtZf8.append(FFTjqa("Load EPG from File%s" % fTxt , self.VVXi09, valid))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((VVmxw7 + "Delete EPG (from RAM only)", self.VVJ1Q4))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(FFTjqa("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVtZf8.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Translate Current Channel EPG %s(Experimental)" % VVmxw7, "VVePfC"))
  FFd98D(self, VVtZf8=VVtZf8)
  self.onShown.append(self.VV583n)
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VVZMYK()
   elif item in (self.VV9q9A, self.VVXi09, self.VVJ1Q4):
    reset = item == self.VVXi09
    FFEN35(self, BF(FFn5td, self, BF(self.VVBAbG, item, reset)), VVub3W="Continue ?")
   elif item == "refreshIptvEPG"  : CCnYqq.VVQrbx(self)
   elif item == "VVePfC" : self.VVePfC()
   elif item == "copyEpg"    : self.VVcwDK(False, onlyEpg=True)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVBAbG(self, act, reset=False):
  ok = CCNVQf.VVPa6x(act)
  if ok:
   if reset:
    CCNVQf.VV9o8G(self)
   FFx4Fl(self, "Done")
  else:
   FFx4Fl(self, "Failed!")
 def VVZMYK(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCNVQf.VVGCwz()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFxrb0("File not found (check System EPG settings).", VVmxw7))
   FFVBx2(self, txt, title=title)
  else:
   FFBsVa(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VV0I8h():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VVePfC(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVTXLQ  = (""  , BF(self.VVj2pz, title, True) , [])
  VVIZTW = ("Start" , BF(self.VVj2pz, title, False), [])
  VV6CVp = ("Change Language", self.VVb45Y      , [])
  widths  = (70 , 30)
  VVGQvW = (LEFT , CENTER)
  FFuI68(self, None, title=title, VVBQW6=self.VVm9xk(), VVGQvW=VVGQvW, VV3FCq=widths, width=1200, vMargin=20, VVJgEp=30, VVTXLQ=VVTXLQ, VVIZTW=VVIZTW, VV6CVp=VV6CVp, VVhEUu=2
    , VVRmfT="#11201010", VVRNJt=bg, VV84wP=bg, VVvmBM="#00004455", VVfpy3=bg)
 def VVm9xk(self):
  Def, ch = "DISABLED", dict(CCNVQf.VV0I8h())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVBQW6 = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVBQW6
 def VVb45Y(self, VVzzNZ, title, txt, colList):
  ndx = VVzzNZ.VVXRaz()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CChKAm.VVOmhN(self, confItem, title, lst=CCNVQf.VV0I8h(), cbFnc=BF(self.VV8Met, VVzzNZ), isSave=True)
 def VV8Met(self, VVzzNZ):
  for ndx, row in enumerate(self.VVm9xk()):
   VVzzNZ.VVNshL(ndx, row)
 def VVj2pz(self, Title, isAsk, VVzzNZ, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FFrBcM(VVzzNZ, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
   refCode, evList, err = CCNVQf.VV8hF8(refCode)
   fnc = BF(self.VVfjnQ, Title, refCode, evList, VVzzNZ)
   if   err : FFBsVa(self, err, title=Title)
   elif isAsk : FFEN35(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVfjnQ(self, title, refCode, evList, VVzzNZ):
  self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVWV4N, evList)
      , VVqhY7 = BF(self.VVZfKX, title, refCode))
  VVzzNZ.cancel()
 def VVWV4N(self, evList, VVomkw):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVomkw.VVITUK(totEv)
  VVomkw.VV6uui = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCNVQf.VV5F8P(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVomkw or VVomkw.isCancelled:
    return
   VVomkw.VVReKT(1)
   VVomkw.VVscn9(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVomkw.VV6uui = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVZfKX(self, title, refCode, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VV6uui
  if newLst: totEv, totOK = CCNVQf.VVu3iK(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCNVQf.VVfCMo()
   CCNVQf.VV9o8G(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FFVBx2(self, txt, title=title)
 @staticmethod
 def VV5F8P(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVIsuR(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCNVQf.VV5Zdo(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVIsuR, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VV5Zdo(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FF7xTp(txt))
   txt, err = CCnYqq.VVHdcN(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFXKeJ(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCNVQf.VVnTY0(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVGCwz():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFotbw(path)
   szTxt = CC5iId.VVp3Jg(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVkIG6():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVfCMo(): CCNVQf.VVPa6x(CCNVQf.VV9q9A)
 @staticmethod
 def VVPa6x(act):
  ec, inst = CCNVQf.VVkIG6()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VV9o8G(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VV8hF8(refCode):
  ec, inst = CCNVQf.VVkIG6()
  if inst:
   try:
    evList = inst.lookupEvent([CCNVQf.VVhA9R, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VVu3iK(refCode, events, longDescDays=0):
  ec, inst = CCNVQf.VVkIG6()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VV8rAN(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCNVQf.VVkIG6()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCNVQf.VVDrt7(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCFLza.CCNVQf(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVDrt7(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCNVQf.VVDJ9h(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VV2bd1(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCNVQf.VVkIG6()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCNVQf.VVDrt7(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FF2ADr(evTime)
       evEndTxt  = FF2ADr(evEnd)
       evDurTxt  = FFNguX(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FFNguX(evPos)
        evRem = evEnd - now
        evRemTxt = FFNguX(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FFNguX(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVDJ9h(event):
  genre = PR = ""
  try:
   genre  = CCNVQf.VVTU1f(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCNVQf.VVZEAw(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVZEAw(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVTU1f(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCNVQf.VVVpXu()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVVpXu():
  path = VVG8hM + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFl3Sc(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFl3Sc(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVMXMf(VVzzNZ, title):
  ec, inst = CCNVQf.VVkIG6()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVzzNZ.VVMHVB():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCNVQf.VVhA9R, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCNVQf.VVu3iK(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCNVQf.VVfCMo()
  txt  = "Services\t: %d\n"  % VVzzNZ.VVdO40()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVJF4r(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCNVQf.VVRuWs(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCNVQf.VVRuWs(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCNVQf.VVRuWs(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VVRuWs(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCNVQf.VVDrt7(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCNVQf.VV5F8P(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFxrb0(evName, VVwwau)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFxrb0(evNameTransl, VVwwau))
    if evTime           : txt += "Start Time\t: %s\n" % FF2ADr(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FF2ADr(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FFNguX(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FFNguX(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FFNguX(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFxrb0(evShort, VVquhO)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFxrb0(evDesc , VVquhO)
    if txt:
     txt = FFxrb0("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVwwau) + txt
  return txt
 @staticmethod
 def VVnTY0(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CC8mGp(Screen, CCdfMN):
 VVZZ5x  = 0
 VVsWyN = 1
 VVaMh8  = 2
 VVIOXe  = 3
 VVwIZF = 4
 VVGe9h = 5
 VVnd9W = 6
 VVkDvA   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FF98gL(VVL2J2, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVWk24 = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVtZf8 = self.VVh8Md()
  FFd98D(self, VVtZf8=VVtZf8, title="Services/Channels")
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self["myMenu"].setList(self.VVh8Md())
  FFzlUl(self["myMenu"])
  FFzxez(self)
 def VVh8Md(self):
  VVtZf8 = []
  c = VVs7I8
  VVtZf8.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVtZf8.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVtZf8.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVtZf8.append(VVh3VV)
  c = VVwwau
  VVtZf8.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVtZf8.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVtZf8.append((VVD46d + "More tables ..."     , "VVuAdD"    ))
  c = VVquhO
  VVtZf8.append(VVh3VV)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVtZf8.append((c + txt          , "VVuPS5"  ))
  else : VVtZf8.append((txt           ,          ))
  VVtZf8.append((c + 'Export Services to "channels.xml"'    , "VV3l5D"      ))
  VVtZf8.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVOICC
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVtZf8.append((c + "Invalid Services Cleaner"       , "VVDE1i"    ))
  c = VVOICC
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c + "Delete Channels with no names"     , "VVYSke"    ))
  VVtZf8.append((c + "Delete Empty Bouquets"       , "VVg1un"     ))
  VVtZf8.append(VVh3VV)
  VVVGll, VV7GKC = CC8mGp.VVwWsx()
  if fileExists(VVVGll):
   enab = fileExists(VV7GKC)
   if enab: VVtZf8.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVtZf8.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVtZf8.append(("Reset Parental Control Settings"      , "VVcwtr"    ))
  VVtZf8.append(("Reload Channels and Bouquets"       , "VVwjHt"      ))
  return VVtZf8
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCQFZI.VVbh0Z(self.session)
   elif item == "openSignal"       : FF1dfA(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFqy2T(self, fncMode=CCFLza.VVO8n6)
   elif item == "lameDB_allChannels_with_refCode"  : FFn5td(self, self.VVkLwD)
   elif item == "lameDB_allChannels_with_tranaponder" : FFn5td(self, self.VVNc8z)
   elif item == "VVuAdD"     : self.VVuAdD()
   elif item == "VVuPS5"  : CCAniX.VVuPS5(self)
   elif item == "VV3l5D"      : self.VV3l5D()
   elif item == "copyEpgPicons"      : self.VVcwDK(False)
   elif item == "SatellitesCleaner"     : FFn5td(self, self.FFn5td_SatellitesCleaner)
   elif item == "VVDE1i"    : FFn5td(self, BF(self.VVDE1i))
   elif item == "VVYSke"    : FFn5td(self, self.VVYSke)
   elif item == "VVg1un"     : self.VVg1un(self)
   elif item == "enableHiddenChannels"     : self.VVFUhS(True)
   elif item == "disableHiddenChannels"    : self.VVFUhS(False)
   elif item == "VVcwtr"    : FFEN35(self, self.VVcwtr, "Reset and Restart ?")
   elif item == "VVwjHt"      : FFn5td(self, BF(CC8mGp.VVwjHt, self))
 def VVuAdD(self):
  VVtZf8 = []
  VVtZf8.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVtZf8.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVtZf8.append(("Services with PIcons for the System"  , "VVzvAB"    ))
  VVtZf8.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVtZf8.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFd7BR(self, self.VVRD3e, VVtZf8=VVtZf8, title="Service Information", VVkmYm=True)
 def VVRD3e(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFn5td(self, BF(self.VV5uo6, title))
   elif ref == "parentalControlChannels"   : FFn5td(self, BF(self.VV8WPZ, title))
   elif ref == "showHiddenChannels"    : FFn5td(self, BF(self.VVogfT, title))
   elif ref == "VVzvAB"    : FFn5td(self, BF(self.VV3kqZ, title))
   elif ref == "servicesWithMissingPIcons"   : FFn5td(self, BF(self.VVKXrt, title))
   elif ref == "TranspondersStats"     : FFn5td(self, BF(self.VVFknc, title))
   elif ref == "SatellitesXmlStats"    : FFn5td(self, BF(self.VVK4Cp, title))
 def VV3l5D(self):
  VVtZf8 = []
  VVtZf8.append(("All DVB-S/C/T Services", "all"))
  VVtZf8.extend(CCQq9Y.VVVLD3())
  FFd7BR(self, self.VVbJlh, VVtZf8=VVtZf8, title="", VVkmYm=True)
 def VVbJlh(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CC8mGp.VVeyFv("1:7:")
   else   : lst = FFemXY(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFYMB2(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFpPAo(r)  : sat = "Stream Relay"
       elif FFAXDs(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FF9GYH(CFG.exportedTablesPath.getValue()), FF0Isj())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FFx4Fl(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FFrBcM(self, "No Services found !", 1500)
 @staticmethod
 def VVwjHt(SELF):
  FFOnqc()
  FFx4Fl(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVkLwD(self):
  self.VVWk24 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCmB9U(self)
  VVaKg1, err = CC8mGp.VV8K3y(self, self.VVZZ5x)
  if VVaKg1:
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVTXLQ  = ("Zap"   , self.VVQl7s     , [])
   VVZRP4 = (""    , self.VVHkvX   , [])
   VVFaAj = ("Options"  , self.VVo4Vy , [])
   VVIZTW = ("Current Service", self.VV1Apk , [])
   VV6CVp = ("Filter"   , self.VVUOIX  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVGQvW  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindServices)
 def VVNc8z(self):
  self.VVWk24 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCmB9U(self)
  VVaKg1, err = CC8mGp.VV8K3y(self, self.VVsWyN)
  if VVaKg1:
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVTXLQ  = ("Zap"   , self.VVQl7s      , [])
   VVZRP4 = (""    , self.VVHkvX    , [])
   VVIZTW = ("Current Service", self.VV1Apk  , [])
   VVFaAj = ("Options"  , self.VVznZF , [])
   VV6CVp = ("Filter"   , self.VVBusG  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVGQvW  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindServices)
 def VVo4Vy(self, VVzzNZ, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CC7G9K(self, VVzzNZ)
  VVtZf8 = []
  isMulti = VVzzNZ.VVoCEo
  if isMulti:
   refCodeList = VVzzNZ.VVXAfG(3)
   if refCodeList:
    VVtZf8.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVtZf8.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVtZf8.append(VVh3VV)
    VVtZf8.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVtZf8.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVtZf8.append(VVh3VV)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVtZf8.append((txt1, "parentalControl_add" ))
    VVtZf8.append((txt2,        ))
   else:
    VVtZf8.append((txt1,       ))
    VVtZf8.append((txt2, "parentalControl_remove" ))
   VVtZf8.append(VVh3VV)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVtZf8.append((txt1, "hiddenServices_add"  ))
    VVtZf8.append((txt2,       ))
   else:
    VVtZf8.append((txt1,        ))
    VVtZf8.append((txt2, "hiddenServices_remove" ))
   VVtZf8.append(VVh3VV)
  cbFncDict = { "parentalControl_add"   : BF(self.VVPsee, VVzzNZ, refCode, True)
     , "parentalControl_remove"  : BF(self.VVPsee, VVzzNZ, refCode, False)
     , "hiddenServices_add"   : BF(self.VVvcBW, VVzzNZ, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVvcBW, VVzzNZ, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVdMy6, VVzzNZ, True)
     , "parentalControl_sel_remove" : BF(self.VVdMy6, VVzzNZ, False)
     , "hiddenServices_sel_add"  : BF(self.VVkms6, VVzzNZ, True)
     , "hiddenServices_sel_remove" : BF(self.VVkms6, VVzzNZ, False)
     }
  VVtZf81, cbFncDict1 = CC8mGp.VVvkl5(self, VVzzNZ, servName, 3)
  VVtZf8.extend(VVtZf81)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVaknP(VVtZf8, cbFncDict)
 def VVznZF(self, VVzzNZ, title, txt, colList):
  servName = colList[0]
  mSel = CC7G9K(self, VVzzNZ)
  VVtZf8, cbFncDict = CC8mGp.VVvkl5(self, VVzzNZ, servName, 3)
  mSel.VVaknP(VVtZf8, cbFncDict)
 @staticmethod
 def VVvkl5(SELF, VVzzNZ, servName, refCodeCol):
  tot = VVzzNZ.VVRFlF()
  if tot > 0:
   sTxt = FFxrb0("%d Service%s" % (tot, FFAHjU(tot)), VVwwau)
   VVtZf8 = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFpnOy(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFxrb0(servName, VVwwau)
   VVtZf8 = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CC8mGp.VVRCHt, SELF, VVzzNZ, refCodeCol, True)
     , "addToBouquet_one" : BF(CC8mGp.VVRCHt, SELF, VVzzNZ, refCodeCol, False)
     }
  return VVtZf8, cbFncDict
 @staticmethod
 def VVRCHt(SELF, VVzzNZ, refCodeCol, isMulti):
  picker = CCQq9Y(SELF, VVzzNZ, "Add to Bouquet", BF(CC8mGp.VVw8vw, VVzzNZ, refCodeCol, isMulti))
 @staticmethod
 def VVw8vw(VVzzNZ, refCodeCol, isMulti):
  if isMulti : refCodeList = VVzzNZ.VVXAfG(refCodeCol)
  else  : refCodeList = [VVzzNZ.VVQ0F0()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVPsee(self, VVzzNZ, refCode, isAddToBlackList):
  VVzzNZ.VVM1y5("Processing ...")
  FFb5Nn(BF(self.VVu9YR, VVzzNZ, [refCode], isAddToBlackList))
 def VVdMy6(self, VVzzNZ, isAddToBlackList):
  refCodeList = VVzzNZ.VVXAfG(3)
  if not refCodeList:
   FFBsVa(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVzzNZ.VVM1y5("Processing ...")
  FFb5Nn(BF(self.VVu9YR, VVzzNZ, refCodeList, isAddToBlackList))
 def VVu9YR(self, VVzzNZ, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VVhrYS, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VVhrYS):
   lines = FFMy5k(VVhrYS)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VVhrYS, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVzzNZ.VVoCEo
   if isMulti:
    self.VV0zfl(VVzzNZ, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VVi5S1(VVzzNZ, refCode)
    VVzzNZ.VVD7du()
  else:
   VVzzNZ.VVNLt2("No changes")
 def VVvcBW(self, VVzzNZ, refCode, isHide):
  title = "Change Hidden State"
  if FFoesm(refCode):
   VVzzNZ.VVM1y5("Processing ...")
   ret = FFsuwf(refCode, isHide)
   if ret : FFn5td(self, BF(self.VVi5S1, VVzzNZ, refCode))
   else : FFBsVa(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFBsVa(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VVi5S1(self, VVzzNZ, refCode):
  VVaKg1, err = CC8mGp.VV8K3y(self, self.VVZZ5x, VVbT55=[3, [refCode], False])
  done = False
  if VVaKg1:
   data = VVaKg1[0]
   if data[3] == refCode:
    done = VVzzNZ.VVUkGQ(data)
  if not done:
   self.VVyTYa(VVzzNZ, VVzzNZ.VVYGKg(), self.VVZZ5x)
  VVzzNZ.VVD7du()
 def VV0zfl(self, VVzzNZ, totRefCodes):
  VVaKg1, err = CC8mGp.VV8K3y(self, self.VVZZ5x, VVbT55=self.VVWk24)
  VVzzNZ.VV311O(VVaKg1)
  VVzzNZ.VVPvaS(False)
  VVzzNZ.VVNLt2("%d Processed" % totRefCodes)
 def VVkms6(self, VVzzNZ, isHide):
  refCodeList = VVzzNZ.VVXAfG(3)
  if not refCodeList:
   FFBsVa(self, "Nothing selected", title="Change Hidden State")
   return
  VVzzNZ.VVM1y5("Processing ...")
  FFb5Nn(BF(self.VVz0mw, VVzzNZ, refCodeList, isHide))
 def VVz0mw(self, VVzzNZ, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFsuwf(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFOnqc(True)
   self.VV0zfl(VVzzNZ, len(refCodeList))
  else:
   VVzzNZ.VVNLt2("No changes")
 def VVUOIX(self, VVzzNZ, title, txt, colList):
  inFilterFnc = BF(self.VV99sx, VVzzNZ) if self.VVWk24 else None
  self.filterObj.VVSuBu(1, VVzzNZ, 2, BF(self.VVIokz, VVzzNZ), inFilterFnc=inFilterFnc)
 def VVIokz(self, VVzzNZ, item):
  self.VVa61L(VVzzNZ, False, item, 2, self.VVZZ5x)
 def VV99sx(self, VVzzNZ, VVlE2Q, item):
  self.VVa61L(VVzzNZ, True, item, 2, self.VVZZ5x)
 def VVBusG(self, VVzzNZ, title, txt, colList):
  inFilterFnc = BF(self.VV5Yuu, VVzzNZ) if self.VVWk24 else None
  self.filterObj.VVSuBu(2, VVzzNZ, 4, BF(self.VV84TU, VVzzNZ), inFilterFnc=inFilterFnc)
 def VV84TU(self, VVzzNZ, item):
  self.VVa61L(VVzzNZ, False, item, 4, self.VVsWyN)
 def VV5Yuu(self, VVzzNZ, VVlE2Q, item):
  self.VVa61L(VVzzNZ, True, item, 4, self.VVsWyN)
 def VVqFAQ(self, VVzzNZ, title, txt, colList):
  inFilterFnc = BF(self.VVSRsa, VVzzNZ) if self.VVWk24 else None
  self.filterObj.VVSuBu(0, VVzzNZ, 4, BF(self.VVejXH, VVzzNZ), inFilterFnc=inFilterFnc)
 def VVejXH(self, VVzzNZ, item):
  self.VVa61L(VVzzNZ, False, item, 4, self.VVaMh8)
 def VVSRsa(self, VVzzNZ, VVlE2Q, item):
  self.VVa61L(VVzzNZ, True, item, 4, self.VVaMh8)
 def VVa61L(self, VVzzNZ, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVzzNZ.VVOEiT(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVWk24 = None
  else:
   words, asPrefix = CCmB9U.VVbRSg(words)
   self.VVWk24 = [col, words, asPrefix]
  if words: FFn5td(VVzzNZ, BF(self.VVyTYa, VVzzNZ, title, mode), clearMsg=False)
  else : FFrBcM(VVzzNZ, "Incorrect filter", 2000)
 def VVyTYa(self, VVzzNZ, title, mode):
  VVaKg1, err = CC8mGp.VV8K3y(self, mode, VVbT55=self.VVWk24, VV0VUr=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVzzNZ.VVMHVB():
    try:
     ndx = VVaKg1.index(tuple(list(map(str.strip, row))))
     lst.append(VVaKg1[ndx])
    except:
     pass
   VVaKg1 = lst
  if VVaKg1:
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVzzNZ.VV311O(VVaKg1, title, VV3PMMMsg=True)
  else:
   FFrBcM(VVzzNZ, "Not found!", 1500)
 def VVLNv4(self, title, VVBQW6, VVTXLQ=None, VVZRP4=None, VVXfC8=None, VVIZTW=None, VVFaAj=None, VV6CVp=None):
  VVIZTW = ("Current Service", self.VV1Apk, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVGQvW = (LEFT  , LEFT  , CENTER, LEFT    )
  FFuI68(self, None, title=title, header=header, VVBQW6=VVBQW6, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindServices)
 def VV1Apk(self, VVzzNZ, title, txt, colList):
  self.VVWibO(VVzzNZ)
 def VVuJuF(self, VVzzNZ, title, txt, colList):
  self.VVWibO(VVzzNZ, True)
 def VVWibO(self, VVzzNZ, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVzzNZ.VVGQiM(colDict, VVg3ap=True)
   else:
    VVzzNZ.VV2bC1(3, refCode, True)
   return
  FFBsVa(self, "Cannot read current Reference Code !")
 def VV5uo6(self, title):
  self.VVWk24 = None
  self.lastfilterUsed  = None
  self.filterObj   = CCmB9U(self)
  VVaKg1, err = CC8mGp.VV8K3y(self, self.VVaMh8)
  if VVaKg1:
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVZRP4 = (""    , self.VVy61E , []      )
   VVIZTW = ("Current Service", self.VVuJuF  , []      )
   VV6CVp = ("Filter"   , self.VVqFAQ   , [], "Loading Filters ..." )
   VVTXLQ  = ("Zap"   , self.VVAbBo      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVGQvW  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VVIZTW=VVIZTW, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindServices)
 def VVy61E(self, VVzzNZ, title, txt, colList):
  refCode  = self.VVNMeS(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFqy2T(self, fncMode=CCFLza.VVB67g, refCode=refCode, chName=chName, text=txt)
 def VVAbBo(self, VVzzNZ, title, txt, colList):
  refCode = self.VVNMeS(colList)
  FFYeVI(self, refCode)
 def VVQl7s(self, VVzzNZ, title, txt, colList):
  FFYeVI(self, colList[3])
 def VVNMeS(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VV4AsU(VVVGll, mode=0):
  lines = FFMy5k(VVVGll, encLst=["UTF-8"])
  return CC8mGp.VV9IFu(lines, mode)
 @staticmethod
 def VV9IFu(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VV8K3y(SELF, mode, VVbT55=None, VV0VUr=True, VVO4lq=True):
  VVVGll, err = CC8mGp.VVZ5Jg(SELF, VVO4lq)
  if err:
   return None, err
  asPrefix = False
  if VVbT55:
   filterCol = VVbT55[0]
   filterWords = VVbT55[1]
   asPrefix = VVbT55[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CC8mGp.VVZZ5x:
   blackList = None
   if fileExists(VVhrYS):
    blackList = FFMy5k(VVhrYS)
    if blackList:
     blackList = set(blackList)
  elif mode == CC8mGp.VVsWyN:
   tp = CCTy0v()
  VVTvZo, VVNQex = FFD3Ic()
  if mode in (CC8mGp.VVGe9h, CC8mGp.VVnd9W):
   VVaKg1 = {}
  else:
   VVaKg1 = []
  tagFound = False
  with ioOpen(VVVGll, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFxluq(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CC8mGp.VVaMh8:
       if sTypeInt in VVTvZo:
        STYPE = VVNQex[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVaKg1.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVaKg1.append(tRow)
       else:
        VVaKg1.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CC8mGp.VVkDvA:
        VVaKg1.append((chName, chProv, sat, refCode))
       elif mode == CC8mGp.VVGe9h:
        VVaKg1[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CC8mGp.VVnd9W:
        VVaKg1[chName] = refCode
       elif mode == CC8mGp.VVZZ5x:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVaKg1.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVaKg1.append(tRow)
        else:
         VVaKg1.append(tRow)
       elif mode == CC8mGp.VVsWyN:
        if sTypeInt in VVTvZo:
         STYPE = VVNQex[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVXqWF(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVaKg1.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVaKg1.append(tRow)
        else:
         VVaKg1.append(tRow)
       elif mode == CC8mGp.VVIOXe:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVaKg1.append((chName, chProv, sat, refCode))
       elif mode == CC8mGp.VVwIZF:
        VVaKg1.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVaKg1 and VV0VUr:
   FFBsVa(SELF, "No services found!")
  return VVaKg1, ""
 def VV8WPZ(self, title):
  if fileExists(VVhrYS):
   lines = FFMy5k(VVhrYS)
   if lines:
    newRows = []
    VVaKg1, err = CC8mGp.VV8K3y(self, self.VVwIZF)
    if VVaKg1:
     lines = set(lines)
     for item in VVaKg1:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVaKg1 = newRows
      VVaKg1.sort(key=lambda x: x[0].lower())
      VVZRP4 = ("", self.VVHkvX, [])
      VVTXLQ = ("Zap", self.VVQl7s, [])
      self.VVLNv4(title, VVaKg1, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4)
     else:
      FFVBx2(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVaKg1)))
   else:
    FFx4Fl(self, "No active Parental Control services.", FFwW71())
  else:
   FFPQyp(self, VVhrYS)
 def VVogfT(self, title):
  VVaKg1, err = CC8mGp.VV8K3y(self, self.VVIOXe)
  if VVaKg1:
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVZRP4 = ("" , self.VVHkvX, [])
   VVTXLQ  = ("Zap", self.VVQl7s, [])
   self.VVLNv4(title, VVaKg1, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4)
  elif err:
   pass
  else:
   FFx4Fl(self, "No hidden services.", FFwW71())
 def VVDE1i(self):
  title = "Services unused in Tuner Configuration"
  VVVGll, err = CC8mGp.VVZ5Jg(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CC8mGp.VVxr7P()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVJAoF(str(item[0]))
    nsLst.add(ns)
  sysLst = CC8mGp.VVeyFv("1:7:")
  tpLst  = CC8mGp.VV4AsU(VVVGll, mode=1)
  VVaKg1 = []
  for refCode, chName in sysLst:
   servID = CC8mGp.VVBJAF(refCode)
   tpID = CC8mGp.VVpmKT(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVaKg1.append((chName, FFYMB2(refCode, False), refCode, servID))
  if VVaKg1:
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVFaAj = ("Options"   , BF(self.VVo4TK, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVGQvW  = (LEFT  , CENTER , LEFT   , CENTER   )
   FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVFaAj=VVFaAj, VVRmfT="#0a001122", VVRNJt="#0a001122", VV84wP="#0a001122", VVvmBM="#00004455", VVfpy3="#0a333333", VViJnU="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FFx4Fl(self, "No invalid service found !", title=title)
 def VVo4TK(self, Title, VVzzNZ, title, txt, colList):
  mSel = CC7G9K(self, VVzzNZ)
  isMulti = VVzzNZ.VVoCEo
  if isMulti : txt = "Remove %s Services" % FFxrb0(str(VVzzNZ.VVRFlF()), VVD46d)
  else  : txt = "Remove : %s" % FFxrb0(VVzzNZ.VVQ0F0()[0], VVD46d)
  VVtZf8 = [(txt, "del")]
  cbFncDict = {"del": BF(FFn5td, VVzzNZ, BF(self.VV5dk3, VVzzNZ, Title))}
  mSel.VVaknP(VVtZf8, cbFncDict)
 def VV5dk3(self, VVzzNZ, title):
  VVVGll, err = CC8mGp.VVZ5Jg(self, title=title)
  if err:
   return
  isMulti = VVzzNZ.VVoCEo
  skipLst = []
  if isMulti : skipLst = VVzzNZ.VVXAfG(3)
  else  : skipLst = [VVzzNZ.VVQ0F0()[3]]
  tpLst = CC8mGp.VV4AsU(VVVGll, mode=0)
  servLst = CC8mGp.VV4AsU(VVVGll, mode=10)
  tmpDbFile = VVVGll + ".tmp"
  lines   = FFMy5k(VVVGll)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFkQDN("mv -f '%s' '%s'" % (tmpDbFile, VVVGll))
  VVaKg1 = []
  for row in VVzzNZ.VVMHVB():
   if not row[3] in skipLst:
    VVaKg1.append(row)
  FFOnqc()
  FFVBx2(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVaKg1:
   VVzzNZ.VV311O(VVaKg1, title)
   VVzzNZ.VVPvaS(False)
  else:
   VVzzNZ.cancel()
 def VVFknc(self, title):
  VVVGll, err = CC8mGp.VVZ5Jg(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVQF78(VVVGll)
  txt = FFxrb0("Total Transponders:\n\n", VVTVZG)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFxrb0("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVTVZG)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFUL86(item), satList.count(item))
  FFVBx2(self, txt, title)
 def VVQF78(self, VVVGll):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVVGll, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVK4Cp(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFPQyp(self, path, title=title)
   return
  elif not CC5iId.VVHX4f(self, path, title):
   return
  if not CCyO3o.VVG6c7(self):
   return
  tree = CC8mGp.VV5F3o(self, path, title=title)
  if not tree:
   return
  VVaKg1 = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFxluq(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVaKg1.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVaKg1:
   VVaKg1.sort(key=lambda x: int(x[1]))
   VVIZTW = ("Current Satellite", BF(self.VV9KAp, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVGQvW  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=25, VVFsq0=1, VVIZTW=VVIZTW, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFBsVa(self, "No data found !", title=title)
 def VV9KAp(self, satCol, VVzzNZ, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  sat = FFYMB2(refCode, False)
  for ndx, row in enumerate(VVzzNZ.VVMHVB()):
   if sat == row[satCol].strip():
    VVzzNZ.VV8i74(ndx)
    break
  else:
   FFrBcM(VVzzNZ, "No listed !", 1500)
 def FFn5td_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFBsVa(self, "No Satellites found !")
   return
  usedSats = CC8mGp.VVxr7P()
  VVaKg1 = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVaKg1.append((sat[1], posTxt, FFxluq(sat[0]), tuners, str(posVal)))
  if VVaKg1:
   VV84wP = "#11222222"
   VVaKg1.sort(key=lambda x: int(x[1]))
   VVIZTW = ("Current Satellite" , BF(self.VV9KAp, 2) , [])
   VVFaAj = ("Options"   , self.VVmlsn  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVGQvW  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=28, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VVRmfT=VV84wP, VVRNJt=VV84wP, VV84wP=VV84wP, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFBsVa(self, "No data found !")
 def VVmlsn(self, VVzzNZ, title, txt, colList):
  mSel = CC7G9K(self, VVzzNZ)
  isMulti = VVzzNZ.VVoCEo
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFxrb0(str(VVzzNZ.VVRFlF()), VVD46d)
  else  : txt = "Remove ALL Services on : %s" % FFxrb0(VVzzNZ.VVQ0F0()[0], VVD46d)
  VVtZf8 = []
  VVtZf8.append((txt, "deleteSat"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Delete Empty Bouquets", "VVg1un"))
  cbFncDict = { "deleteSat"   : BF(FFn5td, VVzzNZ, BF(self.VVzRll, VVzzNZ))
     , "VVg1un" : BF(self.VVg1un, VVzzNZ)
     }
  mSel.VVaknP(VVtZf8, cbFncDict)
 def VVzRll(self, VVzzNZ):
  posLst = []
  isMulti = VVzzNZ.VVoCEo
  posLst = []
  if isMulti : posLst = VVzzNZ.VVXAfG(4)
  else  : posLst = [VVzzNZ.VVQ0F0()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVJAoF(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VVWtO0(nsLst)
  FFOnqc(True)
  FFVBx2(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVg1un(self, winObj):
  title = "Delete Empty Bouquets"
  FFEN35(self, BF(FFn5td, winObj, BF(self.VVt2cO, title)), "Delete bouquets with no services ?", title=title)
 def VVt2cO(self, title):
  bList = CCQq9Y.VV67bC()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCQq9Y.VV9zDX(bRef)
    bPath = VV7aeL + bFile
    FFKqXn(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VV7aeL + fil
     if fileExists(path):
      lines = FFMy5k(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFOnqc(True)
  if bNames: txt = "%s\n\n%s" % (FFxrb0("Deleted Bouquets:", VVwwau), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FFVBx2(self, txt, title=title)
 def VVJAoF(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VVWtO0(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VV7aeL)
  for srcF in files:
   if fileExists(srcF):
    lines = FFMy5k(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFvzBx(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VV3kqZ(self, title)   : self.VVzvAB(title, True)
 def VVKXrt(self, title) : self.VVzvAB(title, False)
 def VVzvAB(self, title, isWithPIcons):
  piconsPath = CCjCYH.VVzyVV()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCjCYH.VVBQXo(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVaKg1, err = CC8mGp.VV8K3y(self, self.VVwIZF)
    if VVaKg1:
     channels = []
     for (chName, chProv, sat, refCode) in VVaKg1:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFt544(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVaKg1)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVIsuR(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVIsuR("PIcons Path"  , piconsPath)
     txt += VVIsuR("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVIsuR("Total services" , totalServices)
     txt += VVIsuR("With PIcons"  , totalWithPIcons)
     txt += VVIsuR("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FFVBx2(self, txt)
     else:
      VVZRP4     = (""      , self.VVHkvX , [])
      if isWithPIcons : VV6CVp = ("Export Current PIcon", self.VVsECN  , [])
      else   : VV6CVp = None
      VVFaAj     = ("Statistics", FFVBx2, [txt])
      VVTXLQ      = ("Zap", self.VVQl7s, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVLNv4(title, channels, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VVFaAj=VVFaAj, VV6CVp=VV6CVp)
   else:
    FFBsVa(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFBsVa(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVHkvX(self, VVzzNZ, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFqy2T(self, fncMode=CCFLza.VVB67g, refCode=refCode, chName=chName, text=txt)
 def VVsECN(self, VVzzNZ, title, txt, colList):
  png, path = CCjCYH.VVGM2o(colList[3], colList[0])
  if path:
   CCjCYH.VV1LRy(self, png, path)
 @staticmethod
 def VVwWsx():
  VVVGll  = "%slamedb" % VV7aeL
  VV7GKC = "%slamedb.disabled" % VV7aeL
  return VVVGll, VV7GKC
 @staticmethod
 def VVSXp8():
  VVzRji  = "%slamedb5" % VV7aeL
  VVWNRA = "%slamedb5.disabled" % VV7aeL
  return VVzRji, VVWNRA
 def VVFUhS(self, isEnable):
  VVVGll, VV7GKC = CC8mGp.VVwWsx()
  if isEnable and not fileExists(VV7GKC):
   FFx4Fl(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVVGll):
   FFBsVa(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFEN35(self, BF(self.VVUCaC, isEnable), "%s Hidden Channels ?" % word)
 def VVUCaC(self, isEnable):
  VVVGll , VV7GKC = CC8mGp.VVwWsx()
  VVzRji, VVWNRA = CC8mGp.VVSXp8()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VV7GKC, VV7GKC, VVVGll)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVWNRA, VVWNRA, VVzRji)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVVGll  , VVVGll , VV7GKC)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVzRji , VVzRji, VVWNRA)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VV7GKC, VVVGll )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVWNRA, VVzRji)
  ok = FFkQDN(cmd)
  FFOnqc()
  if ok: FFx4Fl(self, "Hidden List %s" % word)
  else : FFBsVa(self, "Error while restoring:\n\n%s" % fileName)
 def VVcwtr(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VV7aeL
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VV7aeL
  FFvqDM(self, cmd)
 def VVYSke(self):
  VVVGll, err = CC8mGp.VVZ5Jg(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFKqXn(tmpFile)
  totChan = totRemoved = 0
  lines = FFMy5k(VVVGll, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFEN35(self, BF(FFn5td, self, BF(self.VV5W5W, tmpFile, VVVGll, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FFAHjU(totRemoved), totChan, FFAHjU(totChan))
      , callBack_No=BF(self.VVKuGK, tmpFile))
  else:
   FFVBx2(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VV5W5W(self, tmpFile, VVVGll, totRemoved, totChan):
  FFkQDN("mv -f '%s' '%s'" % (tmpFile, VVVGll))
  FFOnqc()
  FFVBx2(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVKuGK(self, tmpFile):
  FFKqXn(tmpFile)
 @staticmethod
 def VVZ5Jg(SELF, VVO4lq=True, title=""):
  VVVGll, VV7GKC = CC8mGp.VVwWsx()
  if   not fileExists(VVVGll)       : err = "File not found !\n\n%s" % VVVGll
  elif not CC5iId.VVHX4f(SELF, VVVGll) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVO4lq:
   FFBsVa(SELF, err, title=title)
  return VVVGll, err
 @staticmethod
 def VVpmKT(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVBJAF(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVeyFv(servTypes):
  VVntaB  = eServiceCenter.getInstance()
  VVd3Iz   = '%s ORDER BY name' % servTypes
  VVXOur   = eServiceReference(VVd3Iz)
  VVc7ZD = VVntaB.list(VVXOur)
  if VVc7ZD: return VVc7ZD.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVxr7P():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCFLza(Screen):
 VVO8n6  = 0
 VVUyQo   = 1
 VV6QPG   = 2
 VVB67g    = 3
 VVxKse    = 4
 VVz4tD   = 5
 VV4oHx   = 6
 VVbHvZ    = 7
 VV34t7   = 8
 VVGhyR   = 9
 VVPIUt   = 10
 VVqghU   = 11
 EPG_MODE_BOUQUET_EDITOR   = 12
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FF98gL(VV3Zke, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VVO8n6)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FFxrb0("%s\n", VVi96Z) % SEP
  self.picViewer  = None
  FFd98D(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VV13Iz })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self["myLabel"].VVc45w(outputFileToSave="chann_info")
  if   self.fncMode == self.VVO8n6 : fnc = self.VVotZo
  elif self.fncMode == self.VVUyQo  : fnc = self.VVotZo
  elif self.fncMode == self.VV6QPG  : fnc = self.VVotZo
  elif self.fncMode == self.VVB67g  : fnc = self.VVFD9N
  elif self.fncMode == self.VVxKse  : fnc = self.VVcdCG
  elif self.fncMode == self.VVz4tD  : fnc = self.VVwUov
  elif self.fncMode == self.VV4oHx  : fnc = self.VVAeBQ
  elif self.fncMode == self.VVbHvZ  : fnc = self.VVa4AI
  elif self.fncMode == self.VV34t7  : fnc = self.VVdPzm
  elif self.fncMode == self.VVGhyR : fnc = self.VVaPNF
  elif self.fncMode == self.VVPIUt  : fnc = self.VVhiTv
  elif self.fncMode == self.VVqghU : fnc = self.VVXlYQ
  elif self.fncMode == self.EPG_MODE_BOUQUET_EDITOR : fnc = self.VV7HRG
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVK7a0()
  FFb5Nn(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVO4Ch()
 def VVC0f9(self, err):
  self["myLabel"].setText(err)
  FFwVrd(self["myTitle"], "#22200000")
  FFwVrd(self["myBody"], "#22200000")
  self["myLabel"].VVXDge("#22200000")
  self["myLabel"].VVK7a0()
 def VVotZo(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  self.refCode = refCode
  self.VVRBeR(chName)
 def VVFD9N(self):
  self.VVRBeR(self.chName)
 def VVcdCG(self):
  self.VVRBeR(self.chName)
 def VVwUov(self):
  self.VVRBeR(self.chName)
 def VVAeBQ(self):
  self.VVRBeR("Picon Info")
 def VVa4AI(self):
  self.VVRBeR(self.chName)
 def VVdPzm(self):
  self.VVRBeR(self.chName)
 def VVaPNF(self):
  self.VVRBeR(self.chName)
 def VVhiTv(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFyEub(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVHaoC(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVRBeR(self.chName)
 def VVXlYQ(self):
  self.VVRBeR(self.chName)
 def VV7HRG(self):
  self.VVKSzx(self.picPath)
  self.VVGif3()
 def VVRBeR(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFMcRT(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVKEd3(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    self.text = self.text.rstrip() + "\n\nURL:\n%s\n" % FFxrb0(self.VVSqp2(tUrl), VVUpvF)
  if not self.epg:
   epg = CCNVQf.VVJF4r(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVKSzx(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCjCYH.VVGM2o(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVKSzx(path)
  self.VVrath()
  self.VVU47z(decodedUrl)
  self.VVGif3()
 def VVGif3(self):
  self["myLabel"].setText(self.text or "   No active service", VVeLJi=VV8sAj)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVK7a0(minHeight=minH)
 def VVU47z(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FFAXDs(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVGzVb(FFXKeJ(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCUYQq.VV4Nt1(self.portalEpgUrl, refCode=self.refCode)
   else    : epg, err = CCUYQq.VV4Nt1(decodedUrl, refCode=self.refCode)
  if epg:
   self.text += "\n" + FFElFp("EPG:", VVwwau) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VVrath()
 def VVrath(self):
  if not self.piconShown and self.picUrl:
   path, err = FFjgmp(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVKSzx(path)
    if self.piconShown and self.refCode:
     self.VVXxYB(path, self.refCode)
 def VVXxYB(self, path, refCode):
  if path and fileExists(path) and FFtTXa("ffmpeg"):
   pPath = CCjCYH.VVzyVV()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCFLza.VVPCa2(path)
    cmd += FFaBql("mv -f '%s' '%s%s'" % (path, pPath, picon))
    FFkQDN(cmd)
 def VVKSzx(self, path):
  if path and fileExists(path):
   err, w, h = self.VVGBkE(path)
   if not err:
    if h > w:
     self.VVg7jr(self["myPicF"], w, h, True)
     self.VVg7jr(self["myPicB"], w, h, False)
     self.VVg7jr(self["myPic"] , w, h, False)
   self.picViewer = CCmJoX.VVlbww(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VVg7jr(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVGBkE(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FFz86l(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVKEd3(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFxrb0(chName, VVwwau)
  txt += self.VVIsuR(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFxrb0(state, VVmxw7)
   txt += "State\t: %s\n" % state
  w = FFlSvn(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFlSvn(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VV5brb(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVIsuR(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVIsuR(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVIsuR(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVewds()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVV7XO()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCFLza.VVFSSe(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFxrb0("Stream-Relay" if FFpPAo(decodedUrl) else "IPTV", VVTVZG)
   txt += self.VVBifU(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVDSGi(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCTy0v()
    tpTxt, namespace = tp.VVD3pj(refCode)
    if tpTxt:
     txt += FFxrb0("Tuner:\n", VVwwau)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFxrb0("Codes:\n", VVwwau)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVIsuR(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVIsuR(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVIsuR(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVIsuR(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVIsuR(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVIsuR(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVIsuR(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVIsuR(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVIsuR(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VV5brb(info):
  if info:
   aspect = FFlSvn(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVIsuR(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFlSvn(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VVqv4h(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VVqv4h(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVewds(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVV7XO(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVDSGi(self, refCode, iptvRef, chName):
  refCode = FFwFIz(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFl3Sc(VV7aeL + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFl3Sc(VV7aeL + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVBQW6 = []
  tmpRefCode = FFXKeJ(refCode)
  for item in fList:
   path = VV7aeL + item
   if fileExists(path):
    txt = FFl3Sc(path)
    if tmpRefCode in FFXKeJ(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVBQW6.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVBQW6:
   if len(VVBQW6) == 1:
    txt += "%s\t: %s%s\n" % (FFxrb0("Bouquet", VVwwau), VVBQW6[0][0], " (%s)" % VVBQW6[0][1] if VV0GEW else "")
   else:
    txt += FFxrb0("Bouquets:\n", VVwwau)
    for ndx, item in enumerate(VVBQW6):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VV0GEW else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVBifU(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFR5dT(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCUYQq()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVP070(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFxrb0("URL:", VVTVZG) + "\n%s\n" % self.VVSqp2(decodedUrl)
  else:
   txt = "\n"
   txt += FFxrb0("Reference:", VVTVZG) + "\n%s\n" % refCode
  return txt
 def VVSqp2(self, url):
  if not FFpPAo(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VVNHHG:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFXKeJ(url)
 def VVGzVb(self, decodedUrl):
  if not CCDTZn.VVay4r():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CCnYqq.VVG1o6(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CCnYqq.VVHdcN(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VVkaiV(tDict)
   elif uType == "movie" : epg, picUrl = CCFLza.VVTODE(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VVkaiV(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CCnYqq.VVXW81(item, "title"    , is_base64=True )
     lang    = CCnYqq.VVXW81(item, "lang"         ).upper()
     description   = CCnYqq.VVXW81(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CCnYqq.VVXW81(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CCnYqq.VVXW81(item, "start_timestamp"      )
     stop_timestamp  = CCnYqq.VVXW81(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CCnYqq.VVXW81(item, "stop_timestamp"       )
     now_playing   = CCnYqq.VVXW81(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVDysW, ""
      else     : color, txt = VVmxw7 , "    (CURRENT EVENT)"
      epg += FFxrb0("_" * 32 + "\n", VVi96Z)
      epg += FFxrb0("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFxrb0(description, VVUpvF)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCNVQf.VVu3iK(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVTODE(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CCnYqq.VVXW81(item, "movie_image" )
    genre  = CCnYqq.VVXW81(item, "genre"   ) or "-"
    plot  = CCnYqq.VVXW81(item, "plot"   ) or "-"
    country  = CCnYqq.VVXW81(item, "country"  ) or "-"
    actors  = CCnYqq.VVXW81(item, "actors"   ) or "-"
    cast  = CCnYqq.VVXW81(item, "cast"   ) or "-"
    rating  = CCnYqq.VVXW81(item, "rating"   ) or "-"
    director = CCnYqq.VVXW81(item, "director"  ) or "-"
    releasedate = CCnYqq.VVXW81(item, "releasedate" ) or "-"
    duration = CCnYqq.VVXW81(item, "duration"  ) or "-"
    try:
     lang = CCnYqq.VVXW81(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFxrb0(cast if cast != "-" else actors, VVUpvF)
    epg += "Plot:\n%s"    % FFxrb0(plot, VVUpvF)
   except:
    pass
  return epg, movie_image
 def VV13Iz(self):
  if VVNHHG:
   def VVIsuR(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVIsuR(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCUYQq()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVP070(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVIsuR(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FFrBcM(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVbbSJ(SELF):
  if not CC9WBQ.VVC1gJ(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(SELF)
  err = url =  fSize = resumable = ""
  if FFbuxP(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCUYQq.VVe6L6(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCUYQq.VVsU6U(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFBsVa(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CC5iId.VVp3Jg(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFxrb0(" (M3U/M3U8 File)", VVUpvF)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCPYn3.VVNkFE(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVdl9w(subj, val):
   return "%s\n%s\n\n" % (FFxrb0("%s:" % subj, VVwwau), val)
  title = "File Size"
  txt  = VVdl9w(title , fSize or "?")
  txt += VVdl9w("Name" , chName)
  txt += VVdl9w("URL" , url)
  if resumable: txt += VVdl9w("Supports Download-Resume", resumable)
  if err  : txt += FFxrb0("Error:\n", VVmxw7) + err
  FFVBx2(SELF, txt, title=title)
 @staticmethod
 def VVFSSe(SELF):
  fPath, fDir, fName = CC5iId.VVOhYP(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VVPCa2(path):
  return FFaBql("ffmpeg -y -i '%s' -vf scale=-1:132 '%s'" % (path, path))
 @staticmethod
 def VV5Cfc(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCjCYH.VVzyVV() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VVrN9T(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FFAXDs(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFvzBx(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCUYQq():
 def __init__(self):
  self.VVe1HX()
  self.VVPWxG    = ""
  self.VV03jz   = "#f#11ffffaa#User"
  self.VVIXLD   = "#f#11aaffff#Server"
 def VVe1HX(self):
  self.VVsWL3   = ""
  self.VVWinM    = ""
  self.VVOZ70   = ""
  self.VVURcr = ""
  self.VVX10T  = ""
  self.VVDcHB = 0
 def VVi3lr(self, url, mac, ph1="", VVg3ap=True):
  self.VVe1HX()
  self.VVPWxG = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVPT8M(url)
  if not host:
   if VVg3ap:
    self.VVwnxh("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVx9Vg(mac)
  if not host:
   if VVg3ap:
    self.VVwnxh("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VVsWL3 = host
  self.VVWinM  = mac
  return True
 def VVeMNU(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVPWxG, "")
 def VVPT8M(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVx9Vg(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VV5hfj(self):
  res, err = self.VVhwBY(self.VVJw2h())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VVsWL3.endswith("/c"):
    self.VVsWL3 = self.VVsWL3[:-2]
    res, err = self.VVhwBY(self.VVJw2h())
   elif self.VVsWL3.endswith("/stalker_portal"):
    self.VVsWL3 = self.VVsWL3[:-15]
    res, err = self.VVhwBY(self.VVJw2h())
   else:
    self.VVsWL3 += "/c"
    res, err = self.VVhwBY(self.VVJw2h())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CCnYqq.VVXW81(tDict["js"], "token")
    rand  = CCnYqq.VVXW81(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVJQEL(self, VVg3ap=True):
  if not self.VVPWxG:
   self.VVV0fe()
  err = blkMsg = FFx4FlTxt = ""
  try:
   token, rand, err = self.VV5hfj()
   if token:
    self.VVOZ70 = token
    self.VVURcr = rand
    if rand:
     self.VVDcHB = 2
    prof, retTxt = self.VVTNXl(True)
    if prof:
     self.VVX10T = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVDcHB = 3
      prof, retTxt = self.VVTNXl(False)
      if retTxt:
       self.VVX10T = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FFx4FlTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FFx4FlTxt: tErr += "\n%s" % FFx4FlTxt
  if VVg3ap:
   self.VVwnxh(tErr)
  return "", "", tErr
 def VVV0fe(self):
  try:
   import requests
   url = self.VV6H53()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCUYQq.VVsU6U(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCUYQq.VVsU6U(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VVsWL3 = url
       self.VVPWxG = span.group(1)
       return
  except:
   pass
  self.VVPWxG = "/server/load.php"
 def VV6H53(self):
  url = self.VVsWL3.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVhzNx(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVhwBY("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVhwBY("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVTNXl(self, capMac):
  res, err = self.VVhwBY(self.VVcoqb(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CCnYqq.VVXW81(tDict["js"], "block_%s" % word)
    FFx4FlTxt = CCnYqq.VVXW81(tDict["js"], word)
    return tDict, FFx4FlTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVcoqb(self, capMac):
  param = ""
  if self.VVX10T or self.VVURcr:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVWinM.upper() if capMac else self.VVWinM.lower(), self.VVURcr))
  return self.VVCRxC() + "type=stb&action=get_profile" + param
 exec(FFyEub("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVfjnx(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VVNBd0()
  if len(rows) < 10:
   rows = self.VV4B96()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VVsWL3 ))
   rows.append(("MAC (from URL)" , self.VVWinM ))
   rows.append(("Token"   , self.VVOZ70 ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VV03jz  , "MAC" , self.VVWinM ))
   rows.append(("2", self.VVIXLD, "Host" , self.VVsWL3 ))
   rows.append(("2", self.VVIXLD, "Token" , self.VVOZ70 ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VVHD5g(self, isPhp=True, VVg3ap=False):
  token, profile, tErr = self.VVJQEL(VVg3ap)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVS8VU()
  res, err = self.VVhwBY(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CCnYqq.VVXW81(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FF7xTp(span.group(2))
     pass1 = FF7xTp(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VVNBd0(self):
  m3u_Url, host, user1, pass1, err = self.VVHD5g()
  rows = []
  if m3u_Url:
   res, err = self.VVhwBY(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FF2ADr(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VV03jz, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FF2ADr(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVIXLD, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VV4B96(self):
  token, profile, tErr = self.VVJQEL()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFa5RN(val): val = FFyEub(val.decode("UTF-8"))
     else     : val = self.VVWinM
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FF2ADr(int(parts[1]))
      if parts[2] : ends = FF2ADr(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FF2ADr(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVHaoC(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVJQEL(VVg3ap=False)
  if not token:
   return ""
  crLinkUrl = self.VVs2rM(mode, chCm, epNum, epId)
  res, err = self.VVhwBY(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CCnYqq.VVXW81(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVCRxC(self):
  return self.VVsWL3 + self.VVPWxG + "?"
 def VVJw2h(self):
  return self.VVCRxC() + "type=stb&action=handshake&token=&mac=%s" % self.VVWinM
 def VVG7dG(self, mode):
  url = self.VVCRxC() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVpG57(self, catID):
  return self.VVCRxC() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VV3Fai(self, mode, catID, page):
  url = self.VVCRxC() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVRZ9t(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVCRxC() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVs0rt(self, stID):
  return self.VVCRxC() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVs2rM(self, mode, chCm, serCode, serId):
  url = self.VVCRxC() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVS8VU(self):
  return self.VVCRxC() + "type=itv&action=create_link"
 def VVb5Mj(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VV4WFf(catID, stID, chNum)
  query = self.VVKuwo(mode, self.VVeMNU(), FF7iOc(host), FF7iOc(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVKuwo(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVP070(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVKuwo(mode, ph1, host, mac, epNum, epId, FF7xTp(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFyEub(host)
  mac   = FFyEub(mac)
  valid = False
  if self.VVPT8M(playHost) and self.VVPT8M(host) and self.VVPT8M(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVhwBY(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCUYQq.VVsU6U()
   if self.VVOZ70:
    headers["Authorization"] = "Bearer %s" % self.VVOZ70
   if useCookies : cookies = {"mac": self.VVWinM, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VVmVts(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCUYQq.VVsU6U(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVsU6U():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVwnxh(self, err, title="Portal Browser"):
  FFBsVa(self, str(err), title=title)
 def VVejWL(self, mode):
  if   mode in ("itv"  , CCnYqq.VVqGrn , CCnYqq.VVW8Vb)  : return "Live"
  elif mode in ("vod"  , CCnYqq.VVGCKP , CCnYqq.VV9Nco)  : return "VOD"
  elif mode in ("series" , CCnYqq.VV7WvI , CCnYqq.VVKaiR) : return "Series"
  else                          : return "IPTV"
 def VVLH8l(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVejWL(mode), FFxrb0(searchName, VVUpvF))
 def VVnP5H(self, catchup=False):
  VVtZf8 = []
  VVtZf8.append(("Live"    , "live"  ))
  VVtZf8.append(("VOD"    , "vod"   ))
  VVtZf8.append(("Series"   , "series"  ))
  if catchup:
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Catch-up TV" , "catchup"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Account Info." , "accountInfo" ))
  return VVtZf8
 @staticmethod
 def VVrOto(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCUYQq()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVP070(decodedUrl)
  if valid:
   ok = p.VVi3lr(host, mac, ph1, VVg3ap=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VVHD5g(isPhp=False, VVg3ap=False)
    streamId = CCUYQq.VVvIpR(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVvIpR(decodedUrl):
  p = CCUYQq()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVP070(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFyEub(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVe6L6(decodedUrl):
  p = CCUYQq()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVP070(decodedUrl)
  if valid:
   if CCUYQq.VVlTwJ(chCm):
    return FFXKeJ(chCm)
   else:
    ok = p.VVi3lr(host, mac, ph1, VVg3ap=False)
    if ok:
     try:
      chUrl = p.VVHaoC(mode, chCm, epNum, epId)
      return FFXKeJ(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVlTwJ(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VV4Nt1(decodedUrl, retLst=False, refCode=""):
  epg = err = ""
  if "mode=itv" in decodedUrl:
   p = CCUYQq()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVP070(decodedUrl)
   if valid:
    if not stID:
     stID = CCUYQq.VVvIpR(decodedUrl)
    if stID:
     if p.VVi3lr(host, mac, ph1, VVg3ap=False):
      token, profile, tErr = p.VVJQEL(VVg3ap=False)
      if token:
       res, err = p.VVhwBY(p.VVs0rt(stID))
       if res:
        epg, err = CCUYQq.VVwmpj(res.text, retLst)
        if not retLst and epg and refCode:
         pList, err = CCUYQq.VVwmpj(res.text, retLst=True)
         if pList:
          totEv, totOK = CCNVQf.VVu3iK(refCode, pList)
  return epg, err
 @staticmethod
 def VVwmpj(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CCnYqq.VVXW81(item, "actor"       )
    category   = CCnYqq.VVXW81(item, "category"      )
    descr    = CCnYqq.VVXW81(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CCnYqq.VVXW81(item, "director"      )
    name    = CCnYqq.VVXW81(item, "name"   , is_base64=True)
    start_timestamp  = CCnYqq.VVXW81(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CCnYqq.VVXW81(item, "start_timestamp"    )
    stop_timestamp  = CCnYqq.VVXW81(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CCnYqq.VVXW81(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FFxrb0("    (CURRENT EVENT)", VVs7I8)
     except:
      pass
     if not skip:
      epg += FFxrb0("_" * 32 + "\n", VVi96Z)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FFxrb0(name, VVwwau)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FFxrb0(descr , VVUpvF) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FFxrb0(category, VVUpvF) if category else ""
      epg += "Actors:\n%s\n"  % FFxrb0(actor , VVUpvF) if actor else ""
      epg += "Director:\n%s\n" % FFxrb0(director, VVUpvF) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCRdJH(CCUYQq):
 def __init__(self):
  CCUYQq.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVIvWO(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVP070(decodedUrl)
  if valid:
   if self.VVi3lr(host, mac, ph1, VVg3ap=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VV7Ph5(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  if self.chCm.startswith("Zz1"):
   self.chCm = FFyEub(self.chCm[3:])
  else:
   try:
    chUrl = self.VVHaoC(self.mode, self.chCm, self.epNum, self.epId)
   except:
    return False
  isDirect = False
  if CCUYQq.VVlTwJ(self.chCm):
   chUrl = FFXKeJ(self.chCm)
   chUrl = FF7xTp(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVamW4(chUrl)
  bPath = CCQq9Y.VVK5Cl()
  if newIptvRef:
   if passedSELF:
    FFYeVI(passedSELF, newIptvRef, VVY16B=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFYeVI(self, newIptvRef, VVY16B=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VV4m5g(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVamW4(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VV4m5g(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("ph1", "cId", "sId")
   for par in params:
    newPar = iSub(r"&%s=.*?&" % par, "&", newPar)
   lines = FFMy5k(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for par in params:
       filePar = iSub(r"&%s=.*?&" % par, "&", filePar)
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFOnqc()
class CCZJL4(CCRdJH):
 def __init__(self, passedSession):
  CCRdJH.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVggOs(VV2uAD  )
  Main_Menu.VVggOs(VVVJVw)
  Main_Menu.VVggOs(VVZKiY  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVRdBM, iPlayableService.evEOF: self.VVqL1d, iPlayableService.evEnd: self.VVMQkt})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVCuLu)
  except:
   self.timer2.callback.append(self.VVCuLu)
  self.timer2.start(3000, False)
  self.VVCuLu()
 def VVCuLu(self):
  if not CFG.downloadMonitor.getValue():
   self.VVhDfg()
   return
  lst = CCPYn3.VVcE5p()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFotbw(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCPYn3.VVTiyR(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CC2Wqe.VVjBB1(self.passedSession, txt, 30)
   else    : CC2Wqe.VVso35(self.dnldWin, txt)
  elif self.dnldWin:
   self.VVhDfg()
 def VVhDfg(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVRdBM(self):
  self.startTime = iTime()
 def VVqL1d(self):
  global VVxqvp
  VVxqvp = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFbuxP(decodedUrl):
     self.isFromEOF = True
     CC2Wqe(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVMQkt(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVkyc6)
  except:
   self.timer1.callback.append(self.VVkyc6)
  self.timer1.start(100, True)
 def VVkyc6(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVIvWO(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCQFZI.VVU617:
       self.isFromEOF = False
       self.VV7Ph5(self.passedSession, isFromSession=True)
class CCSaYR():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F]{,3}\ (.+)")
  self.prefixRemoveList = self.VVf5WH(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVf5WH(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVf5WH(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VVG8hM, VVzbRf):
    path += fName
    if fileExists(path):
     for line in FFMy5k(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVtFW5(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CCnYqq.VVOJvx(name):
   return CCnYqq.VVgUNG(name)
  return self.VVo7vX(name)
 def VVo7vX(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VVuSnO(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVo7vX(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VVbRa0(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVfbTY(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVm2Rv(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CC9WBQ(CCUYQq):
 def __init__(self):
  self.curPortalCatId = ""
  CCUYQq.__init__(self)
 def VVHj8Z(self):
  if CC9WBQ.VVC1gJ(self):
   FFn5td(self, BF(self.VVvCO2, 2), title="Searching ...")
 def VVCX5x(self, winSession, url, mac):
  self.curUrl = url
  if CC9WBQ.VVC1gJ(self):
   if self.VVi3lr(url, mac):
    FFn5td(winSession, self.VVCOyL, title="Checking Server ...")
   else:
    FFBsVa(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VV4bfu(self, item=None):
  if item:
   VVlE2Q, txt, path, ndx = item
   enc = CCiVik.VV4IR5(path, self)
   if enc == -1:
    return
   self.session.open(CCIpg5, barTheme=CCIpg5.VVipyP
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVkuFR, path, enc)
       , VVqhY7 = BF(self.VVUOqA, VVlE2Q, path))
 def VVkuFR(self, path, enc, VVomkw):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVomkw.VVITUK(totLines)
  VVomkw.VV6uui = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVomkw or VVomkw.isCancelled:
     return
    VVomkw.VVReKT(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVPT8M(url)
     mac  = self.VVx9Vg(mac)
     if host and mac and VVomkw:
      VVomkw.VV6uui.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVPT8M(url)
      mac  = self.VVx9Vg(mac)
      if host and mac and not mac.startswith("AC") and VVomkw:
       VVomkw.VV6uui.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VVUOqA(self, VVlE2Q, path, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VV6uui:
   VVXfC8  = ("Home Menu"  , FFarAp            , [])
   VVFaAj = ("Edit File"  , BF(self.VVkZaP, path)       , [])
   VVIZTW = ("M3U Options" , self.VV9wZw         , [])
   VV6CVp = ("Check & Filter" , BF(self.VVF0eg, VVlE2Q, path), [])
   VVTXLQ  = ("Select"   , self.VVgtVB      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVGQvW  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVzzNZ = FFuI68(self, None, title=title, header=header, VVBQW6=VV6uui, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VVRmfT="#0a001122", VVRNJt="#0a001122", VV84wP="#0a001122", VVvmBM="#00004455", VVfpy3="#0a333333", VViJnU="#11331100", VV3cto=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVuCFf:
    FFrBcM(VVzzNZ, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVuCFf:
    FFBsVa(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VV9wZw(self, VVzzNZ, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVtZf8 = []
  VVtZf8.append(("Browse as M3U"  , "browse"))
  VVtZf8.append(("Download M3U File" , "downld"))
  FFd7BR(self, BF(self.VV3IaZ, VVzzNZ, host, mac), title=title, VVtZf8=VVtZf8, width=600, VVkmYm=True)
 def VV3IaZ(self, VVzzNZ, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFn5td(VVzzNZ, BF(self.VVZIcj, VVzzNZ, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFEN35(self, BF(FFn5td, VVzzNZ, BF(self.VVZIcj, VVzzNZ, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVZIcj(self, VVzzNZ, title, host, mac, item):
  p = CCUYQq()
  m3u_Url = ""
  ok = p.VVi3lr(host, mac, VVg3ap=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VVHD5g(VVg3ap=False)
  if m3u_Url:
   if   item == "browse": self.VVSxcn(title, m3u_Url)
   elif item == "downld": self.VV9Wly(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFBsVa(self, err or "No response from Server !", title=title)
 def VVgtVB(self, VVzzNZ, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VVCX5x(VVzzNZ, url, mac)
 def VVkZaP(self, path, VVzzNZ, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCteri(self, path, VVqhY7=BF(self.VV990V, VVzzNZ), curRowNum=rowNum)
  else    : FFPQyp(self, path)
 def VVF0eg(self, VVlE2Q, path, VVzzNZ, title, txt, colList):
  self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VV4GGE, VVzzNZ)
      , VVqhY7 = BF(self.VV0wDi, VVlE2Q, VVzzNZ, path))
 def VV4GGE(self, VVzzNZ, VVomkw):
  VVomkw.VV6uui = []
  VVomkw.VVITUK(VVzzNZ.VVdO40())
  for row in VVzzNZ.VVMHVB():
   if not VVomkw or VVomkw.isCancelled:
    return
   VVomkw.VVReKT(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVi3lr(host, mac, VVg3ap=False):
    token, profile, tErr = self.VVJQEL(VVg3ap=False)
    if token and VVomkw and not VVomkw.isCancelled:
     res, err = self.VVhwBY(self.VVG7dG("itv"))
     if res and VVomkw and not VVomkw.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVomkw.VVReKT(0, showFound=True)
       VVomkw.VV6uui.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVomkw:
    return
 def VV0wDi(self, VVlE2Q, VVzzNZ, path, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  if VV6uui:
   VVzzNZ.close()
   VVlE2Q.close()
   newPath = "%s_OK_%s.txt" % (path, FF0Isj())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VV6uui:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFxrb0(str(threadCounter), VVmxw7)
    skipped = FFxrb0(str(threadTotal - threadCounter), VVmxw7)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VV6uui)
   txt += "%s\n\n%s"    %  (FFxrb0("Result File:", VVwwau), newPath)
   FFVBx2(self, txt, title="Accessible Portals")
  elif VVuCFf:
   FFBsVa(self, "No portal access found !", title="Accessible Portals")
 def VV5kUi(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFyEub(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVCOyL(self):
  token, profile, tErr = self.VVJQEL()
  if token:
   dots = "." * self.VVDcHB
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VVeMNU(), "")
   dots += "*" if not self.VVsWL3 == self.curUrl else ""
   VVtZf8  = self.VVnP5H()
   VVoeva = self.VVSHvr
   VVlTMa = self.VVQbL1
   VV8QNc = ("Home Menu", FFarAp)
   VVJlf7= ("Add to Menu", BF(CCnYqq.VVDaJf, self, True, self.VVsWL3 + "\t" + self.VVWinM))
   VVR5O9 = ("Bookmark Server", BF(CCnYqq.VVEusf, self, True, self.VVsWL3 + "\t" + self.VVWinM))
   VVlE2Q = FFd7BR(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVWinM, dots), VVtZf8=VVtZf8, VVoeva=VVoeva, VVlTMa=VVlTMa, VV8QNc=VV8QNc, VVJlf7=VVJlf7, VVR5O9=VVR5O9)
   self.VVc6vM(VVlE2Q)
 def VVSHvr(self, item=None):
  if item:
   VVlE2Q, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFn5td(VVlE2Q, BF(self.VVrn1N, mode), title="Reading Categories ...")
   else : FFn5td(VVlE2Q, BF(self.VVe634, VVlE2Q, title), title="Reading Account ...")
 def VVe634(self, VVlE2Q, title, forceMoreInfo=False):
  rows, totCols = self.VVfjnx(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVWinM)
  VVXfC8  = ("Home Menu" , FFarAp           , [])
  VVIZTW  = None
  if VVNHHG:
   VVIZTW = ("Get JS"  , BF(self.VV6eL6, self.VV6H53()) , [])
  if totCols == 2:
   VV6CVp = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VV6CVp = ("More Info.", BF(self.VVuUMg, VVlE2Q)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FFuI68(self, None, title=title, width=1200, header=header, VVBQW6=rows, VV3FCq=widths, VVJgEp=26, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VV6CVp=VV6CVp, VVRmfT="#0a00292B", VVRNJt="#0a002126", VV84wP="#0a002126", VVvmBM="#00000000", searchCol=searchCol)
 def VV6eL6(self, url, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VVmidE, url), title="Getting JS ...")
 def VVmidE(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVWinM)
  ver, err = self.VVhzNx(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVhzNx(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FFVBx2(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVuUMg(self, VVlE2Q, VVzzNZ, title, txt, colList):
  VVzzNZ.cancel()
  FFn5td(VVlE2Q, BF(self.VVe634, VVlE2Q, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVrn1N(self, mode):
  token, profile, tErr = self.VVJQEL()
  if not token:
   return
  res, err = self.VVhwBY(self.VVG7dG(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CCnYqq.VVXW81(item, "id"       )
      Title  = CCnYqq.VVXW81(item, "title"      )
      censored = CCnYqq.VVXW81(item, "censored"     )
      Title = self.VVbRa0(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VV0GEW:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVejWL(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVRmfT, VVRNJt, VV84wP, VVvmBM = self.VVGBhy(mode)
   mName = self.VVejWL(mode)
   VVeJ6x  = (""     , BF(self.VVIJtB, mode), [])
   VVTXLQ   = ("Show List"   , BF(self.VVgMBh, mode)   , [])
   VVXfC8  = ("Home Menu"   , FFarAp        , [])
   if mode in ("vod", "series"):
    VVFaAj = ("Find in %s" % mName , BF(self.VVDqGN, mode, False), [])
    VV6CVp = ("Find in Selected" , BF(self.VVDqGN, mode, True) , [])
   else:
    VVFaAj = None
    VV6CVp = None
   header   = None
   widths   = (100   , 0  )
   FFuI68(self, None, title=title, width=1200, header=header, VVBQW6=list, VV3FCq=widths, VVJgEp=30, VVXfC8=VVXfC8, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VVeJ6x=VVeJ6x, VVTXLQ=VVTXLQ, VVRmfT=VVRmfT, VVRNJt=VVRNJt, VV84wP=VV84wP, VVvmBM=VVvmBM, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VVX10T:
     txt += "\n\n( %s )" % self.VVX10T
   else:
    txt = "Could not get Categories from server!"
   FFBsVa(self, txt, title=title)
 def VVG4zE(self, mode, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VVlRot, mode, VVzzNZ, title, txt, colList), title="Downloading ...")
 def VVlRot(self, mode, VVzzNZ, title, txt, colList):
  token, profile, tErr = self.VVJQEL()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVhwBY(self.VVpG57(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]['data']
     for item in chList:
      Id    = CCnYqq.VVXW81(item, "id"    )
      actors   = CCnYqq.VVXW81(item, "actors"   )
      added   = CCnYqq.VVXW81(item, "added"   )
      age    = CCnYqq.VVXW81(item, "age"   )
      category_id  = CCnYqq.VVXW81(item, "category_id" )
      description  = CCnYqq.VVXW81(item, "description" )
      director  = CCnYqq.VVXW81(item, "director"  )
      genres_str  = CCnYqq.VVXW81(item, "genres_str"  )
      name   = CCnYqq.VVXW81(item, "name"   )
      path   = CCnYqq.VVXW81(item, "path"   )
      screenshot_uri = CCnYqq.VVXW81(item, "screenshot_uri" )
      series   = CCnYqq.VVXW81(item, "series"   )
      cmd    = CCnYqq.VVXW81(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVeJ6x = (""     , BF(self.VVdOXP, mode, True)  , [])
   VVTXLQ  = ("Play"    , BF(self.VV0qiO, mode)       , [])
   VVZRP4 = (""     , BF(self.VVY6wo, mode)     , [])
   VVXfC8 = ("Home Menu"   , FFarAp            , [])
   VVIZTW = ("Download Options" , BF(self.VVi4qs, mode, "sp", seriesName) , [])
   VVFaAj = ("Options"   , BF(self.VVAGKZ, "pEp", mode, seriesName) , [])
   VV6CVp = ("Posters Mode"  , BF(self.VVh0c7, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVGQvW  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FFuI68(self, None, title=seriesName, width=1200, header=header, VVBQW6=list, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVeJ6x=VVeJ6x, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindIptv, VVRmfT="#0a00292B", VVRNJt="#0a002126", VV84wP="#0a002126", VVvmBM="#00000000")
  else:
   FFBsVa(self, "Could not get Episodes from server!", title=seriesName)
 def VVDqGN(self, mode, searchInCat, VVzzNZ, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVtZf8 = []
  VVtZf8.append(("Keyboard"  , "manualEntry"))
  VVtZf8.append(("From Filter" , "fromFilter"))
  FFd7BR(self, BF(self.VV2yvk, VVzzNZ, mode, searchCatId), title="Input Type", VVtZf8=VVtZf8, width=400)
 def VV2yvk(self, VVzzNZ, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFsCnW(self, BF(self.VVTssf, VVzzNZ, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCmB9U(self)
    filterObj.VVoqZE(BF(self.VVTssf, VVzzNZ, mode, searchCatId))
 def VVTssf(self, VVzzNZ, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFSeyu(CFG.lastFindIptv, searchName)
   title = self.VVLH8l(mode, searchName)
   if "," in searchName : FFBsVa(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFBsVa(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVfbTY([searchName]):
     FFBsVa(self, self.VVm2Rv(), title=title)
    else:
     self.VVsb8h(mode, searchName, "", searchName, searchCatId)
 def VVgMBh(self, mode, VVzzNZ, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.curPortalCatId = catID
  self.VVsb8h(mode, bName, catID, "", "")
 def VVsb8h(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCIpg5, barTheme=CCIpg5.VVipyP
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VVTzor, mode, bName, catID, searchName, searchCatId)
      , VVqhY7 = BF(self.VVdnQw, mode, bName, catID, searchName, searchCatId))
 def VVdnQw(self, mode, bName, catID, searchName, searchCatId, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVLH8l(mode, searchName)
  else   : title = "%s : %s" % (self.VVejWL(mode), bName)
  if VV6uui:
   VVIZTW = None
   VVFaAj = None
   if mode == "series":
    VVRmfT, VVRNJt, VV84wP, VVvmBM = self.VVGBhy("series2")
    VVTXLQ  = ("Episodes"   , BF(self.VVG4zE, mode)           , [])
   else:
    VVRmfT, VVRNJt, VV84wP, VVvmBM = self.VVGBhy("")
    VVTXLQ  = ("Play"    , BF(self.VV0qiO, mode)           , [])
    VVIZTW = ("Download Options" , BF(self.VVi4qs, mode, "vp" if mode == "vod" else "", "") , [])
    VVFaAj = ("Options"   , BF(self.VVAGKZ, "pCh", mode, bName)      , [])
   VVeJ6x = (""      , BF(self.VVdOXP, mode, False)      , [])
   VVZRP4 = (""      , BF(self.VV7oFB, mode)         , [])
   VVXfC8 = ("Home Menu"    , FFarAp                , [])
   VV6CVp = ("Posters Mode"   , BF(self.VVh0c7, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVGQvW  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVzzNZ = FFuI68(self, None, title=title, header=header, VVBQW6=VV6uui, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindIptv, VVTXLQ=VVTXLQ, VVeJ6x=VVeJ6x, VVZRP4=VVZRP4, VVRmfT=VVRmfT, VVRNJt=VVRNJt, VV84wP=VV84wP, VVvmBM=VVvmBM, VV3cto=True, searchCol=1)
   if not VVuCFf:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVzzNZ.VVs7rs(VVzzNZ.VVYGKg() + tot)
    if threadErr: FFrBcM(VVzzNZ, "Error while reading !", 2000)
    else  : FFrBcM(VVzzNZ, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFBsVa(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFBsVa(self, "Could not get list from server !", title=title)
 def VV7oFB(self, mode, VVzzNZ, title, txt, colList):
  ttl = lambda x, y: "%s:\n%s\n\n" % (FFxrb0(x, VVwwau), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFqy2T(self, fncMode=CCFLza.VVqghU, portalHost=self.VVsWL3, portalMac=self.VVWinM, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVftUo(mode, VVzzNZ, title, txt, colList)
 def VVY6wo(self, mode, VVzzNZ, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFxrb0(colList[10], VVUpvF)
  txt += "Description:\n%s" % FFxrb0(colList[11], VVUpvF)
  self.VVftUo(mode, VVzzNZ, title, txt, colList)
 def VVftUo(self, mode, VVzzNZ, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVN36o(mode, colList)
  refCode, chUrl = self.VVb5Mj(self.VVsWL3, self.VVWinM, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFqy2T(self, fncMode=CCFLza.VVPIUt, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VVTzor(self, mode, bName, catID, searchName, searchCatId, VVomkw):
  try:
   token, profile, tErr = self.VVJQEL()
   if not token:
    return
   if VVomkw.isCancelled:
    return
   VVomkw.VV6uui, total_items, max_page_items, err = self.VVy0Ll(mode, catID, 1, 1, searchName, searchCatId)
   if VVomkw.isCancelled:
    return
   if VVomkw.VV6uui and total_items > -1 and max_page_items > -1:
    VVomkw.VVITUK(total_items)
    VVomkw.VVReKT(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVomkw.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVy0Ll(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVomkw.VV41tC()
     if VVomkw.isCancelled:
      return
     if list:
      VVomkw.VV6uui += list
      VVomkw.VVReKT(len(list), True)
  except:
   pass
 def VVy0Ll(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVRZ9t(mode, searchName, searchCatId, page)
  else   : url = self.VV3Fai(mode, catID, page)
  res, err = self.VVhwBY(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VVdO6Q(CCnYqq.VVXW81(item, "total_items" ))
     max_page_items = self.VVdO6Q(CCnYqq.VVXW81(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CCnYqq.VVXW81(item, "id"    )
      name   = CCnYqq.VVXW81(item, "name"   )
      o_name   = CCnYqq.VVXW81(item, "o_name"   )
      category_id  = CCnYqq.VVXW81(item, "category_id" )
      tv_genre_id  = CCnYqq.VVXW81(item, "tv_genre_id" )
      number   = CCnYqq.VVXW81(item, "number"   ) or str(counter)
      logo   = CCnYqq.VVXW81(item, "logo"   )
      screenshot_uri = CCnYqq.VVXW81(item, "screenshot_uri" )
      pic    = CCnYqq.VVXW81(item, "pic"   )
      cmd    = CCnYqq.VVXW81(item, "cmd"   )
      censored  = CCnYqq.VVXW81(item, "censored"  )
      genres_str  = CCnYqq.VVXW81(item, "genres_str"  )
      curPlay   = CCnYqq.VVXW81(item, "cur_playing" )
      actors   = CCnYqq.VVXW81(item, "actors"   )
      descr   = CCnYqq.VVXW81(item, "description" )
      director  = CCnYqq.VVXW81(item, "director"  )
      catID   = category_id or tv_genre_id
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FF7iOc(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VVsWL3 + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVtFW5(name, censored)
      if name:
       list.append((number, name, Id, catID, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VVdO6Q(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VV0qiO(self, mode, VVzzNZ, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVN36o(mode, colList)
  refCode, chUrl = self.VVb5Mj(self.VVsWL3, self.VVWinM, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVOJvx(chName):
   FFrBcM(VVzzNZ, "This is a marker!", 300)
  else:
   FFn5td(VVzzNZ, BF(self.VVv1mP, mode, VVzzNZ, chUrl), title="Playing ...")
 def VVv1mP(self, mode, VVzzNZ, chUrl):
  FFYeVI(self, chUrl, VVY16B=False)
  CCQFZI.VVbh0Z(self.session, iptvTableParams=(self, VVzzNZ, mode))
 def VV4uFi(self, mode, VVzzNZ, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVN36o(mode, colList)
  refCode, chUrl = self.VVb5Mj(self.VVsWL3, self.VVWinM, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVN36o(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "_")
  else:
   chNum = colList[0]
   chName = colList[1]
   stID = colList[2]
   catID = colList[3]
   picUrl = colList[4]
   chCm = colList[5]
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VVC1gJ(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVtZf8 = []
    VVtZf8.append((title        , "inst" ))
    VVtZf8.append(("Update Packages then %s" % title , "updInst" ))
    FFd7BR(SELF, BF(CC9WBQ.VVOb0V, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVtZf8=VVtZf8)
   return False
 @staticmethod
 def VVOb0V(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FFYH4A(VV63qG, "")
   if cmdUpd:
    cmdInst = FFgOTM(VV6ESW, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FFeWwS(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVBjuq=cbFnc)
   else:
    FF5yx0(SELF)
 def VVjSrG(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVP070(decodedUrl)
  return mode, host, catID, stID, epNum.replace("%3a", ":"), epId.replace("%3a", ":")
 def VVc6vM(self, VVlE2Q):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVjSrG()
  if all((curMode, curHost, curCat)) and curHost == self.VVsWL3:
   VVlE2Q.VVIgUV({"itv": 0, "vod": 1, "series": 2}.get(curMode, 0))
 def VVIJtB(self, mode, VVzzNZ, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVjSrG()
  if all((curMode, curHost, curCat)) and curMode == mode and curHost == self.VVsWL3:
   VVzzNZ.VVGQiM({1:curCat})
 def VVdOXP(self, mode, isEp, VVzzNZ, title, txt, colList):
  curMode, curHost, curCat, curStID, curEpNum, curEpId = self.VVjSrG()
  if all((curMode, curHost, curCat)) and curCat == self.curPortalCatId and curMode == mode and curHost == self.VVsWL3:
   if mode in ("itv", "vod"):
    VVzzNZ.VVGQiM({2:curStID})
   else: #series
    if isEp:
     VVzzNZ.VVGQiM({2:curEpNum, 4:curEpId})
    elif mode == "series":
     ser1 = curEpId.split(":")[0]
     ser2 = "%s:%s" % (ser1, ser1)
     ok = VVzzNZ.VVGQiM({2:ser2})
     if not ok: VVzzNZ.VVGQiM({2:ser1})
class CCnYqq(Screen, CC9WBQ, CCSaYR, CCdfMN):
 VVeJmB    = 0
 VVLDjK    = 1
 VV6DN5    = 2
 VVWvOq    = 3
 VV87GT     = 4
 VVo0AP     = 5
 VVelVP     = 6
 VVXF8Y     = 7
 VVFn2A     = 8
 VVIbzA     = 9
 VVL9c0      = 10
 VVFzCH     = 11
 VVhr95     = 12
 VVJ9Hh     = 13
 VVdT0p     = 14
 VVkcpU      = 15
 VVuJd0      = 16
 VVTz0d      = 17
 VVUp4u      = 18
 VV4R6m      = 19
 VVh5cB    = 0
 VVqGrn   = 1
 VVGCKP   = 2
 VV7WvI   = 3
 VVAzCq  = 4
 VVk0RO  = 5
 VVW8Vb   = 6
 VV9Nco   = 7
 VVKaiR  = 8
 VV8mZW  = 9
 VVeucf  = 10
 VVrloX = 0
 VVPuJg = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FF98gL(VVL2J2, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVzzNZ    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVrqmtData    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CCnYqq.VVQk0n(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CC9WBQ.__init__(self)
  CCSaYR.__init__(self)
  VVtZf8 = self.VVh8Md()
  FFd98D(self, title="IPTV", VVtZf8=VVtZf8)
  self["myActionMap"].actions.update({
   "menu" : self.VVX84V
  })
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV5BRl)
  global VVts4W
  VVts4W = True
 def VV583n(self):
  self["myMenu"].setList(self.VVh8Md())
  FFzxez(self)
  FFD5nM(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFzlUl(self["myMenu"])
   FF5mrw(self)
   if self.m3uOrM3u8File:
    self.VVRlxw(self.m3uOrM3u8File)
   else:
    self.VVaQFV()
 def VVaQFV(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  if "chCode" in decodedUrl:
   for ndx, item in enumerate(self["myMenu"].list):
    if item[0] == "IPTV Server Browser (from Current Channel)" and len(item) > 1:
     self["myMenu"].moveToIndex(ndx)
     break
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  FFNb6h("VVts4W")
 def VV5BRl(self):
  if self["myMenu"].getCurrent()[1] in ("VVFw7d", "VV3g3vPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVX84V(self):
  if self["myMenu"].getVisible():
   title, item = self["myMenu"].getCurrent()
   if   item == "VV3g3vPortal" : confItem = CFG.favServerPortal
   elif item == "VVFw7d" : confItem = CFG.favServerPlaylist
   else         : return
   FFEN35(self, BF(self.VVz7D2, confItem), 'Remove from menu ?', title=title)
 def VVz7D2(self, confItem):
  FFSeyu(confItem, "")
  self.VV583n()
 def VVh8Md(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVOICC
  VVtZf8 = []
  if isFav1: VVtZf8.append((c +  "Favourite Playlist Server"   , "VVFw7d" ))
  if isFav2: VVtZf8.append((c +  "Favourite Portal Server"    , "VV3g3vPortal" ))
  VVtZf8.append(("IPTV Server Browser (from Playlists)"     , "VVrqmt_fromPlayList" ))
  VVtZf8.append(("IPTV Server Browser (from Portal List)"    , "VVrqmt_fromMac"  ))
  VVtZf8.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVrqmt_fromM3u"  ))
  qUrl, iptvRef = CCnYqq.VV5Dwl(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVtZf8.append(FFTjqa("IPTV Server Browser (from Current Channel)", "VVrqmt_fromCurrChan", fromCurCond))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("M3U/M3U8 File Browser"        , "VVzYQv"   ))
  if self.iptvFileAvailable:
   VVtZf8.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(FFTjqa("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVtZf8.append(FFTjqa("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVtZf8.append(VVh3VV)
   c1, c2 = VVquhO, VVwwau
   t1 = FFxrb0("auto-match names", VVOICC)
   t2 = FFxrb0("from xml file"  , VVOICC)
   VVtZf8.append((c1 + "Count Available IPTV Channels"    , "VVJ5Z3"    ))
   VVtZf8.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVtZf8.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVmIG1" ))
   VVtZf8.append((VVD46d + "More Reference Tools ..."  , "VVhCTK"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Reload Channels and Bouquets"       , "VVwjHt"   ))
  VVtZf8.append(VVh3VV)
  if not CCPYn3.VVCizW():
   VVtZf8.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVtZf8.append(("Download Manager ... No downloads"    ,       ))
  return VVtZf8
 def VVUurL(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVNXWd"   : self.VVNXWd()
   elif item == "VVoeAs" : FFEN35(self, self.VVoeAs, "Change Current List References to Unique Codes ?")
   elif item == "VVu0Xl_rows" : FFEN35(self, BF(FFn5td, self.VVzzNZ, self.VVu0Xl), "Change Current List References to Identical Codes ?")
   elif item == "VVGX1d"   : self.VVGX1d(tTitle)
   elif item == "VVBvIo"   : self.VVBvIo(tTitle)
   elif item == "VVFw7d" : self.VV3g3v(False)
   elif item == "VV3g3vPortal" : self.VV3g3v(True)
   elif item == "VVrqmt_fromPlayList" : FFn5td(self, BF(self.VVvCO2, 1), title=title)
   elif item == "VVrqmt_fromM3u"  : FFn5td(self, BF(self.VVzFt1, CCnYqq.VVrloX), title=title)
   elif item == "VVrqmt_fromMac"  : self.VVHj8Z()
   elif item == "VVrqmt_fromCurrChan" : self.VV9BuH()
   elif item == "VVzYQv"   : self.VVzYQv()
   elif item == "iptvTable_all"   : FFn5td(self, BF(self.VVWcwJ, self.VVeJmB), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CCnYqq.VVQrbx(self)
   elif item == "refreshIptvPicons"  : self.VVzrYy()
   elif item == "VVJ5Z3"    : FFn5td(self, self.VVJ5Z3)
   elif item == "copyEpgPicons"   : self.VVcwDK(False)
   elif item == "renumIptvRef_fromFile" : self.VVcwDK(True)
   elif item == "VVmIG1" : FFEN35(self, BF(FFn5td, self, self.VVmIG1), VVub3W="Continue ?")
   elif item == "VVhCTK"    : self.VVhCTK()
   elif item == "VVwjHt"   : FFn5td(self, BF(CC8mGp.VVwjHt, self))
   elif item == "dload_stat"    : CCPYn3.VVYez0(self)
 def VVzYQv(self):
  if CC9WBQ.VVC1gJ(self):
   FFn5td(self, BF(self.VVzFt1, CCnYqq.VVPuJg), title="Searching ...")
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVUurL(item)
 def VVWcwJ(self, mode):
  VVaKg1 = self.VVEPjw(mode)
  if VVaKg1:
   VVIZTW = ("Current Service", self.VVfKR6 , [])
   VVFaAj = ("Options"  , self.VV9f2y   , [])
   VV6CVp = ("Filter"   , self.VVv6PS   , [])
   VVTXLQ  = ("Play"   , BF(self.VVW8go)  , [])
   VVZRP4 = (""    , self.VVgV8V    , [])
   VVeJ6x = (""    , self.VVnwo5     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVGQvW  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FFuI68(self, None, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26
     , VVTXLQ=VVTXLQ, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VVZRP4=VVZRP4, VVeJ6x=VVeJ6x
     , VVRmfT="#0a00292B", VVRNJt="#0a002126", VV84wP="#0a002126", VVvmBM="#00000000", VV3cto=True, searchCol=1)
  else:
   if mode == self.VVIbzA: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFBsVa(self, err)
 def VVnwo5(self, VVzzNZ, title, txt, colList):
  self.VVzzNZ = VVzzNZ
 def VV9f2y(self, VVzzNZ, title, txt, colList):
  VVtZf8 = []
  VVtZf8.append(("Add Current List to a New Bouquet"    , "VVNXWd"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Change Current List References to Unique Codes" , "VVoeAs"))
  VVtZf8.append(("Change Current List References to Identical Codes", "VVu0Xl_rows" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Share Reference with DVB Service (manual entry)" , "VVGX1d"   ))
  VVtZf8.append(("Share Reference with DVB Service (auto-find)"  , "VVBvIo"   ))
  FFd7BR(self, self.VVUurL, title="IPTV Tools", VVtZf8=VVtZf8)
 def VVv6PS(self, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VVFXfR, VVzzNZ))
 def VVFXfR(self, VVzzNZ):
  VVtZf8 = []
  VVtZf8.append(("All"         , "all"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Prefix of Selected Channel"   , "sameName" ))
  VVtZf8.append(("Suggest Words from Selected Channel" , "partName" ))
  VVtZf8.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVtZf8.append(("Duplicate References"     , "depRef"  ))
  VVtZf8.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVtZf8.append(("Stream Relay"       , "SRelay"  ))
  VVtZf8.append(FFbAzs("Category"))
  VVtZf8.append(("Live TV"        , "live"  ))
  VVtZf8.append(("VOD"         , "vod"   ))
  VVtZf8.append(("Series"        , "series"  ))
  VVtZf8.append(("Uncategorised"      , "uncat"  ))
  VVtZf8.append(FFbAzs("Media"))
  VVtZf8.append(("Video"        , "video"  ))
  VVtZf8.append(("Audio"        , "audio"  ))
  VVtZf8.append(FFbAzs("File Type"))
  VVtZf8.append(("MKV"         , "MKV"   ))
  VVtZf8.append(("MP4"         , "MP4"   ))
  VVtZf8.append(("MP3"         , "MP3"   ))
  VVtZf8.append(("AVI"         , "AVI"   ))
  VVtZf8.append(("FLV"         , "FLV"   ))
  VVtZf8.extend(CCQq9Y.VVVLD3(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VVglTY, VVzzNZ) if VVzzNZ.VVYGKg().startswith("IPTV Filter ") else None
  filterObj = CCmB9U(self)
  filterObj.VVR4AM(VVtZf8, VVtZf8, BF(self.VVv8vJ, VVzzNZ, False), inFilterFnc=inFilterFnc)
 def VVglTY(self, VVzzNZ, VVlE2Q, item):
  self.VVv8vJ(VVzzNZ, True, item)
 def VVv8vJ(self, VVzzNZ, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVzzNZ.VVOEiT(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVeJmB , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVLDjK , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VV6DN5 , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVWvOq , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVelVP  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VVXF8Y  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VVFn2A  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVIbzA  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVL9c0   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVFzCH  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVhr95  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VVJ9Hh  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVdT0p  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVkcpU   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVuJd0   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVTz0d   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVUp4u   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VV4R6m   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VV87GT  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVo0AP  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VV6DN5:
   VVtZf8 = []
   chName = VVzzNZ.VVOEiT(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVtZf8.append((item, item))
    if not VVtZf8 and chName:
     VVtZf8.append((chName, chName))
    FFd7BR(self, BF(self.VVMSGQ, title), title="Words from Current Selection", VVtZf8=VVtZf8)
   else:
    VVzzNZ.VVNLt2("Invalid Channel Name")
  else:
   words, asPrefix = CCmB9U.VVbRSg(words)
   if not words and mode in (self.VV87GT, self.VVo0AP):
    FFrBcM(self.VVzzNZ, "Incorrect filter", 2000)
   else:
    FFn5td(self.VVzzNZ, BF(self.VVZSbz, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVMSGQ(self, title, word=None):
  if word:
   words = [word.lower()]
   FFn5td(self.VVzzNZ, BF(self.VVZSbz, self.VV6DN5, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVgUNG(txt):
  return "#f#11ffff00#" + txt
 def VVZSbz(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVaKg1 = self.VVMz7m(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVaKg1 = self.VVEPjw(mode=mode, words=words, asPrefix=asPrefix)
  if VVaKg1 : self.VVzzNZ.VV311O(VVaKg1, title)
  else  : self.VVzzNZ.VVNLt2("Not found")
 def VVMz7m(self, mode=0, words=None, asPrefix=False):
  VVaKg1 = []
  for row in self.VVzzNZ.VVMHVB():
   row = list(map(str.strip, row))
   chNum, chName, VVe0gr, chType, refCode, url = row
   if self.VVgqIi(mode, refCode, FFXKeJ(url).lower(), chName, words, VVe0gr.lower(), asPrefix):
    VVaKg1.append(row)
  VVaKg1 = self.VV802b(mode, VVaKg1)
  return VVaKg1
 def VVEPjw(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVaKg1 = []
  files = CCnYqq.VVQk0n()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFl3Sc(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VVe0gr = span.group(1)
    else : VVe0gr = ""
    VVe0gr_lCase = VVe0gr.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVOJvx(chName): chNameMod = self.VVgUNG(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VVe0gr, chType + (" SRel" if FFpPAo(url) else ""), refCode, url)
     if self.VVgqIi(mode, refCode, FFXKeJ(url).lower(), chName, words, VVe0gr_lCase, asPrefix):
      VVaKg1.append(row)
      chNum += 1
  VVaKg1 = self.VV802b(mode, VVaKg1)
  return VVaKg1
 def VV802b(self, mode, VVaKg1):
  newRows = []
  if VVaKg1 and mode == self.VVelVP:
   counted  = iCounter(elem[4] for elem in VVaKg1)
   for item in VVaKg1:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVaKg1
 def VVgqIi(self, mode, refCode, tUrl, chName, words, VVe0gr_lCase, asPrefix):
  if   mode == self.VVeJmB : return True
  elif mode == self.VVelVP : return True
  elif mode == self.VVXF8Y  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VVFn2A : return FFpPAo(tUrl)
  elif mode == self.VVJ9Hh  : return CCnYqq.VVG1o6(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVdT0p  : return CCnYqq.VVG1o6(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVIbzA  : return CCnYqq.VVG1o6(tUrl, compareType="live")
  elif mode == self.VVL9c0  : return CCnYqq.VVG1o6(tUrl, compareType="movie")
  elif mode == self.VVFzCH : return CCnYqq.VVG1o6(tUrl, compareType="series")
  elif mode == self.VVhr95  : return CCnYqq.VVG1o6(tUrl, compareType="")
  elif mode == self.VVkcpU  : return CCnYqq.VVG1o6(tUrl, compareExt="mkv")
  elif mode == self.VVuJd0  : return CCnYqq.VVG1o6(tUrl, compareExt="mp4")
  elif mode == self.VVTz0d  : return CCnYqq.VVG1o6(tUrl, compareExt="mp3")
  elif mode == self.VVUp4u  : return CCnYqq.VVG1o6(tUrl, compareExt="avi")
  elif mode == self.VV4R6m  : return CCnYqq.VVG1o6(tUrl, compareExt="flv")
  elif mode == self.VVLDjK: return chName.lower().startswith(words[0])
  elif mode == self.VV6DN5: return words[0] in chName.lower()
  elif mode == self.VVWvOq: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VV87GT : return words[0] == VVe0gr_lCase
  elif mode == self.VVo0AP :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVNXWd(self):
  picker = CCQq9Y(self, self.VVzzNZ, "Add to Bouquet", self.VVq4XC)
 def VVq4XC(self):
  chUrlLst = []
  for row in self.VVzzNZ.VVMHVB():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVhCTK(self):
  t1 = FFxrb0("Bouquet" , VVwwau)
  t2 = FFxrb0("ALL"  , VVD46d)
  t3 = FFxrb0("Unique"  , VVquhO)
  t4 = FFxrb0("Identical" , VVOICC)
  VVtZf8 = []
  VVtZf8.append((VVs7I8 + "Check System Acceptable Reference Types", "VVmn2O"))
  VVtZf8.append(FFTjqa("Check Reference Codes Format", "VV1A1L", self.iptvFileAvailable, VVs7I8))
  VVtZf8.append(VVh3VV)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVtZf8.append((txt % t1, "VVd2pb" ))
  VVtZf8.append((txt % t2, "VVPumh_all"  ))
  VVtZf8.append(VVh3VV)
  txt = "Change %s References to %s Codes .."
  VVtZf8.append((txt % (t1, t3), "VV3lFZ" ))
  VVtZf8.append((txt % (t2, t3), "VV1T3q"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Change %s References to %s Codes" % (t2, t4) , "VVu0Xl_all"))
  VVoeva = self.VVzDYq
  FFd7BR(self, None, width=1150, title="IPTV Reference Tools", VVtZf8=VVtZf8, VVoeva=VVoeva, VVRmfT="#22002233", VVRNJt="#22001122")
 def VVzDYq(self, item=None):
  if item:
   ques = "Continue ?"
   VVlE2Q, txt, item, ndx = item
   if   item == "VVmn2O"    : FFn5td(VVlE2Q, self.VVmn2O)
   elif item == "VV1A1L"     : FFn5td(VVlE2Q, self.VV1A1L)
   elif item == "VVd2pb" : self.VVH6Pz(VVlE2Q, self.VVLy97)
   elif item == "VVPumh_all"  : self.VVLy97(VVlE2Q, None, None)
   elif item == "VV3lFZ" : self.VV3lFZ(VVlE2Q, txt)
   elif item == "VV1T3q"  : FFEN35(self, BF(self.VV1T3q , VVlE2Q, txt), title=txt, VVub3W=ques)
   elif item == "VVu0Xl_all"  : FFEN35(self, BF(FFn5td, VVlE2Q, self.VVu0Xl), title=txt, VVub3W=ques)
 def VVLy97(self, VVlE2Q, bName, bPath):
  VVtZf8 = []
  for rt in CCnYqq.VVBUYw():
   VVtZf8.append(("%s\t ... %s" % (rt, CCnYqq.VVC7wL(rt)), rt))
  FFd7BR(self, BF(self.VV8GTX, VVlE2Q, bName, bPath), VVtZf8=VVtZf8, width=800, title="Change Reference Types to:")
 def VV8GTX(self, VVlE2Q, bName, bPath, rType=None):
  if rType:
   self.VVOdY6(VVlE2Q, bName, bPath, rType)
 def VVH6Pz(self, VVlE2Q, fnc):
  VVtZf8 = CCQq9Y.VVVLD3()
  if VVtZf8:
   FFd7BR(self, BF(self.VVgUTj, VVlE2Q, fnc), VVtZf8=VVtZf8, title="IPTV Bouquets", VVkmYm=True)
  else:
   FFrBcM(VVlE2Q, "No bouquets Found !", 1500)
 def VVgUTj(self, VVlE2Q, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VV7aeL + span.group(1)
    if fileExists(bPath): fnc(VVlE2Q, bName, bPath)
    else    : FFrBcM(VVlE2Q, "Bouquet file not found!", 2000)
   else:
    FFrBcM(VVlE2Q, "Cannot process bouquet !", 2000)
 def VVOdY6(self, VVlE2Q, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFxrb0(bName, VV0V0q)
  else : title = "Change for %s" % FFxrb0("All IPTV Services", VV0V0q)
  FFEN35(self, BF(FFn5td, VVlE2Q, BF(self.VV0iFT, VVlE2Q, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFxrb0(rType, VV0V0q), title=title)
 def VV0iFT(self, VVlE2Q, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CCnYqq.VVQk0n()
  if files:
   newRType = rType + ":"
   piconPath = CCjCYH.VVzyVV()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CC5iId.VVHX4f(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFBsVa(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFkQDN("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFkQDN(cmd)
  self.VVOykJ(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVJ5Z3(self):
  totFiles = 0
  files  = CCnYqq.VVQk0n()
  if files:
   totFiles = len(files)
  totChans = 0
  VVaKg1 = self.VVEPjw()
  if VVaKg1:
   totChans = len(VVaKg1)
  FFVBx2(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VV1A1L(self):
  files = CCnYqq.VVQk0n()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFl3Sc(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVCKEk
   else    : color = VVmxw7
   totInvalid = FFxrb0(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFxrb0("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FFVBx2(self, txt, title="Check IPTV References")
 def VVmn2O(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CCnYqq.VVBUYw()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCQq9Y.VVFFSs(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVc12d = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVc12d:
   VVK7WR = FFemXY(VVc12d)
   if VVK7WR:
    for service in VVK7WR:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VV7aeL + userBName
  bFile = VV7aeL + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFaBql("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += FFaBql("rm -f '%s'" % path)
  FFkQDN(cmd)
  FFOnqc()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVCKEk
    else     : res, color = "No" , VVmxw7
    pl = CCnYqq.VVC7wL(item)
    txt += "    %s\t: %s%s\n" % (item, FFxrb0(res, color), FFxrb0("\t... %s" % pl, VVUpvF) if pl else "")
   FFVBx2(self, txt, title=title)
  else:
   txt = FFBsVa(self, "Could not complete the test on your system!", title=title)
 def VVmIG1(self):
  VVmC3N, err = CC8mGp.VV8K3y(self, CC8mGp.VVnd9W)
  if VVmC3N:
   totChannels = 0
   totChange = 0
   for path in CCnYqq.VVQk0n():
    toSave = False
    txt = FFl3Sc(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVmC3N.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVOykJ(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFBsVa(self, 'No channels in "lamedb" !')
 def VV1T3q(self, VVlE2Q, title):
  bFiles = CCnYqq.VVQk0n()
  if bFiles: self.VVIn0c(bFiles, title)
  else  : FFrBcM(VVlE2Q, "No bouquets files !", 1500)
 def VV3lFZ(self, VVlE2Q, title):
  self.VVH6Pz(VVlE2Q, BF(self.VVyGcS, title))
 def VVyGcS(self, title, VVlE2Q, bName, bPath):
  self.VVIn0c([bPath], title)
 def VVIn0c(self, bFiles, title):
  self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VV1VOs, bFiles)
      , VVqhY7 = BF(self.VVXDoD, title))
 def VV1VOs(self, bFiles, VVomkw):
  VVomkw.VV6uui = ""
  VVomkw.VVttgG("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFMy5k(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVomkw or VVomkw.isCancelled:
   return
  elif not totLines:
   VVomkw.VV6uui = "No IPTV Services !"
   return
  else:
   VVomkw.VVITUK(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVomkw or VVomkw.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFMy5k(path)
    for ndx, line in enumerate(lines):
     if not VVomkw or VVomkw.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVomkw:
       VVomkw.VVttgG("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVomkw:
       VVomkw.VVReKT(1)
      refCode, startId, startNS = CCQq9Y.VVh5up(rType, CCQq9Y.VVMzWC, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVomkw:
        VVomkw.VV6uui = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVXDoD(self, title, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VV6uui:
   txt += "\n\n%s\n%s" % (FFxrb0("Ended with Error:", VVmxw7), VV6uui)
  self.VVOykJ(True, title, txt)
 def VVoeAs(self):
  bFiles = CCnYqq.VVQk0n()
  if not bFiles:
   FFrBcM(self.VVzzNZ, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVzzNZ.VVMHVB():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FFrBcM(self.VVzzNZ, "Cannot read list", 1500)
   return
  self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVBeal, bFiles, tableRefList)
      , VVqhY7 = BF(self.VVXDoD, "Change Current List References to Unique Codes"))
 def VVBeal(self, bFiles, tableRefList, VVomkw):
  VVomkw.VV6uui = ""
  VVomkw.VVttgG("Reading System References ...")
  refLst = CCQq9Y.VV6ShY(CCQq9Y.VVMzWC, stripRType=True)
  if not VVomkw or VVomkw.isCancelled:
   return
  VVomkw.VVITUK(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVomkw or VVomkw.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFl3Sc(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVomkw or VVomkw.isCancelled:
     return
    VVomkw.VVttgG("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVomkw or VVomkw.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVomkw.VVReKT(1)
      refCode, startId, startNS = CCQq9Y.VVh5up(rType, CCQq9Y.VVMzWC, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVomkw:
        VVomkw.VV6uui = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVu0Xl(self):
  list = None
  if self.VVzzNZ:
   list = []
   for row in self.VVzzNZ.VVMHVB():
    list.append(row[4] + row[5])
  files = CCnYqq.VVQk0n()
  totChange = 0
  if files:
   for path in files:
    lines = FFMy5k(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVOykJ(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVOykJ(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFOnqc()
   if refreshTable and self.VVzzNZ:
    VVaKg1 = self.VVEPjw()
    if VVaKg1 and self.VVzzNZ:
     self.VVzzNZ.VV311O(VVaKg1, self.tableTitle)
     self.VVzzNZ.VVNLt2(txt)
   FFVBx2(self, txt, title=title)
  else:
   FFx4Fl(self, "No changes.")
 @staticmethod
 def VVQk0n(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VV7aeL + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFl3Sc(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VVgV8V(self, VVzzNZ, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFXKeJ(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFqy2T(self, fncMode=CCFLza.VVbHvZ, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVcWQE(self, VVzzNZ, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVW8go(self, VVzzNZ, title, txt, colList):
  chName, chUrl = self.VVcWQE(VVzzNZ, colList)
  self.VVbzoI(VVzzNZ, chName, chUrl, "localIptv")
 def VVNaQX(self, mode, VVzzNZ, colList):
  chName, chUrl, picUrl, refCode = self.VVreGJ(mode, colList)
  return chName, chUrl
 def VVDHIJ(self, mode, VVzzNZ, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVreGJ(mode, colList)
  self.VVbzoI(VVzzNZ, chName, chUrl, mode)
 def VVbzoI(self, VVzzNZ, chName, chUrl, playerFlag):
  chName = FFpnOy(chName)
  if self.VVOJvx(chName):
   FFrBcM(VVzzNZ, "This is a marker!", 300)
  else:
   FFn5td(VVzzNZ, BF(self.VV1Zfu, VVzzNZ, chUrl, playerFlag), title="Playing ...")
 def VV1Zfu(self, VVzzNZ, chUrl, playerFlag):
  FFYeVI(self, chUrl, VVY16B=False)
  CCQFZI.VVbh0Z(self.session, iptvTableParams=(self, VVzzNZ, playerFlag))
 @staticmethod
 def VVOJvx(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VVfKR6(self, VVzzNZ, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  if refCode:
   url1 = FFXKeJ(origUrl.strip())
   for ndx, row in enumerate(VVzzNZ.VVMHVB()):
    if refCode in row[4]:
     tableRow = FFXKeJ(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVzzNZ.VV8i74(ndx)
      break
   else:
    FFrBcM(VVzzNZ, "No found", 1000)
 def VVzFt1(self, m3uMode):
  lines = self.VVpROv(3)
  if lines:
   lines.sort()
   VVtZf8 = []
   for line in lines:
    VVtZf8.append((line, line))
   if m3uMode == CCnYqq.VVrloX:
    title = "Browse Server from M3U URLs"
    VVR5O9 = ("All to Playlist", self.VViM9U)
   else:
    title = "M3U/M3U8 File Browser"
    VVR5O9 = None
   VVoeva = BF(self.VVE96C, m3uMode, title)
   VVlTMa = self.VVCsdS
   FFd7BR(self, None, title=title, VVtZf8=VVtZf8, width=1200, VVoeva=VVoeva, VVlTMa=VVlTMa, VVK9oq="", VVR5O9=VVR5O9, VVRmfT="#11221122", VVRNJt="#11221122")
 def VVE96C(self, m3uMode, title, item=None):
  if item:
   VVlE2Q, txt, path, ndx = item
   if m3uMode == CCnYqq.VVrloX:
    FFn5td(VVlE2Q, BF(self.VVr6kQ, title, path))
   else:
    FFn5td(VVlE2Q, BF(self.VVRlxw, path))
 def VVRlxw(self, path, m3uFilterParam=None, VVzzNZ=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFl3Sc(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVEJNh(propLine, "group-title") or "-"
   if not group == "-" and self.VVbRa0(group):
    if not chName or self.VVtFW5(chName):
     if self.VVgqIi(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVaKg1 = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVaKg1.append((name, str(tot), name))
    totAll += tot
   VVaKg1.sort(key=lambda x: x[0].lower())
   VVaKg1.insert(0, ("ALL", str(totAll), ""))
  if VVaKg1:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVzzNZ:
    VVzzNZ.VV311O(VVaKg1, newTitle=title, VV3PMMMsg=True)
   else:
    VV0cge = self.VVXrLp
    VVTXLQ  = ("Select" , BF(self.VViasF, path, m3uFilterParam)  , [])
    VV6CVp = ("Filter" , BF(self.VVUg0a, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVGQvW  = (LEFT  , CENTER , LEFT )
    FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, width= 1400, height= 1000, VVJgEp=28, VVTXLQ=VVTXLQ, VV6CVp=VV6CVp, VV0cge=VV0cge, lastFindConfigObj=CFG.lastFindIptv
      , VVRmfT="#11110022", VVRNJt="#11110022", VV84wP="#11110022", VVvmBM="#00444400")
  elif VVzzNZ:
   FFQAm4(VVzzNZ, "Not found !", 1500)
  else:
   self.VV34Aj(FFl3Sc(path), "", m3uFilterParam)
 def VViasF(self, path, m3uFilterParam, VVzzNZ, title, txt, colList):
  self.VV34Aj(FFl3Sc(path), colList[2], m3uFilterParam)
 def VVUg0a(self, path, m3uFilterParam, VVzzNZ, title, txt, colList):
  VVtZf8 = []
  VVtZf8.append(("All"      , "all"  ))
  VVtZf8.append(FFbAzs("Category"))
  VVtZf8.append(("Live TV"     , "live" ))
  VVtZf8.append(("VOD"      , "vod"  ))
  VVtZf8.append(("Series"     , "series" ))
  VVtZf8.append(("Uncategorised"   , "uncat" ))
  VVtZf8.append(FFbAzs("Media"))
  VVtZf8.append(("Video"     , "video" ))
  VVtZf8.append(("Audio"     , "audio" ))
  VVtZf8.append(FFbAzs("File Type"))
  VVtZf8.append(("MKV"      , "MKV"  ))
  VVtZf8.append(("MP4"      , "MP4"  ))
  VVtZf8.append(("MP3"      , "MP3"  ))
  VVtZf8.append(("AVI"      , "AVI"  ))
  VVtZf8.append(("FLV"      , "FLV"  ))
  filterObj = CCmB9U(self, VVRmfT="#11332244", VVRNJt="#11222244")
  filterObj.VVR4AM(VVtZf8, [], BF(self.VV3ewF, VVzzNZ, path), inFilterFnc=None)
 def VV3ewF(self, VVzzNZ, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVeJmB , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVIbzA  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVL9c0  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVFzCH  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVhr95  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VVJ9Hh  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVdT0p  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVkcpU  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVuJd0  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVTz0d  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVUp4u  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VV4R6m  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVo0AP  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCmB9U.VVbRSg(words)
   if not mode == self.VVeJmB:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFxrb0(fTitle, VVUpvF)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFn5td(VVzzNZ, BF(self.VVRlxw, path, m3uFilterParam, VVzzNZ), title="Filtering ...")
 def VV34Aj(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCIpg5, barTheme=CCIpg5.VVipyP
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVq8Ok, lst, filterGroup, m3uFilterParam)
       , VVqhY7 = BF(self.VVcXpL, title, bName))
  else:
   self.VVxsfH("No valid lines found !", title)
 def VVq8Ok(self, lst, filterGroup, m3uFilterParam, VVomkw):
  VVomkw.VV6uui = []
  VVomkw.VVITUK(len(lst))
  num = 0
  for cols in lst:
   if not VVomkw or VVomkw.isCancelled:
    return
   VVomkw.VVReKT(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVEJNh(propLine, "group-title") or "-"
   picon = self.VVEJNh(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VVbRa0(group) : skip = True
    elif chName and not self.VVtFW5(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVgqIi(mode, "", FFXKeJ(url).lower(), chName, words, "", asPrefix)
    if not skip and VVomkw:
     num += 1
     VVomkw.VV6uui.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VVcXpL(self, title, bName, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  if VV6uui:
   VV0cge = self.VVXrLp
   VVTXLQ  = ("Select"   , BF(self.VV043C, title)   , [])
   VVZRP4 = (""    , self.VVw5ht        , [])
   VVIZTW = ("Download PIcons", self.VVnO3k       , [])
   VVFaAj = ("Options"  , BF(self.VVAGKZ, "m3Ch", "", bName) , [])
   VV6CVp = ("Posters Mode" , BF(self.VVh0c7, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVGQvW  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FFuI68(self, None, title=title, header=header, VVBQW6=VV6uui, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=28, VVTXLQ=VVTXLQ, VV0cge=VV0cge, VVZRP4=VVZRP4, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindIptv, VV3cto=True, searchCol=1
     , VVRmfT="#0a00192B", VVRNJt="#0a00192B", VV84wP="#0a00192B", VVvmBM="#00000000")
  else:
   self.VVxsfH("Not found !", title)
 def VVnO3k(self, VVzzNZ, title, txt, colList):
  self.VVCRp7(VVzzNZ, "m3u/m3u8")
 def VVHjW0(self, rowNum, url, chName):
  refCode = self.VVCh60(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FF7xTp(url), chName)
  return chUrl
 def VVCh60(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VV4WFf(catID, stID, chNum)
  return refCode
 def VVEJNh(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VV043C(self, Title, VVzzNZ, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFn5td(VVzzNZ, BF(self.VVKE06, Title, VVzzNZ, colList), title="Checking Server ...")
  else:
   self.VVDAfV(VVzzNZ, url, chName)
 def VVKE06(self, title, VVzzNZ, colList):
  if not CC9WBQ.VVC1gJ(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCUYQq.VVmVts(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVtZf8 = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CCnYqq.VVP1Xe(url, fPath)
     VVtZf8.append((resol, fullUrl))
    if VVtZf8:
     if len(VVtZf8) > 1:
      FFd7BR(self, BF(self.VVrH3S, VVzzNZ, chName), VVtZf8=VVtZf8, title="Resolution", VVkmYm=True, VVh2Zj=True)
     else:
      self.VVDAfV(VVzzNZ, VVtZf8[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVDAfV(VVzzNZ, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CCnYqq.VVP1Xe(url, span.group(1))
       self.VVDAfV(VVzzNZ, fullUrl, chName)
      else:
       self.VVwnxh("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VV34Aj(txt, filterGroup="")
      return
    self.VVDAfV(VVzzNZ, url, chName)
   else:
    self.VVxsfH("Cannot process this channel !", title)
  else:
   self.VVxsfH(err, title)
 def VVrH3S(self, VVzzNZ, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVDAfV(VVzzNZ, resolUrl, chName)
 def VVDAfV(self, VVzzNZ, url, chName):
  FFn5td(VVzzNZ, BF(self.VVKVa2, VVzzNZ, url, chName), title="Playing ...")
 def VVKVa2(self, VVzzNZ, url, chName):
  chUrl = self.VVHjW0(VVzzNZ.VVXRaz(), url, chName)
  FFYeVI(self, chUrl, VVY16B=False)
  CCQFZI.VVbh0Z(self.session, iptvTableParams=(self, VVzzNZ, "m3u/m3u8"))
 def VV70uW(self, VVzzNZ, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVHjW0(VVzzNZ.VVXRaz(), url, chName)
  return chName, chUrl
 def VVw5ht(self, VVzzNZ, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFqy2T(self, fncMode=CCFLza.VVbHvZ, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVxsfH(self, err, title):
  FFBsVa(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VVXrLp(self, VVzzNZ):
  if self.m3uOrM3u8File:
   self.close()
  VVzzNZ.cancel()
 def VViM9U(self, selectionObj, item=None):
  FFn5td(selectionObj, BF(self.VVddog, selectionObj, item))
 def VVddog(self, selectionObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(selectionObj.VVtZf8):
    path = item[1]
    if fileExists(path):
     enc = CCiVik.VV4IR5(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CCnYqq.VVbGCt(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CCnYqq.VVPZOj()
    pListF = "%sPlaylist_%s.txt" % (path, FF0Isj())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(selectionObj.VVtZf8)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FFVBx2(self, txt, title=title)
   else:
    FFBsVa(self, "Could not obtain URLs from this file list !", title=title)
 def VVvCO2(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVn2JT
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VV4bfu
  lines = self.VVpROv(mode)
  if lines:
   lines.sort()
   VVtZf8 = []
   for line in lines:
    VVtZf8.append((FFxrb0(line, VVwwau) if "Bookmarks" in line else line, line))
   VVlTMa = self.VVCsdS
   FFd7BR(self, None, title=title, VVtZf8=VVtZf8, width=1200, VVoeva=okFnc, VVlTMa=VVlTMa, VVK9oq="")
 def VVCsdS(self, VVlE2Q, txt, ref, ndx):
  txt = ref
  sz = FFotbw(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CC5iId.VVp3Jg(sz)
  FFVBx2(self, txt, title="File Path")
 def VVn2JT(self, item=None):
  if item:
   VVlE2Q, txt, path, ndx = item
   FFn5td(VVlE2Q, BF(self.VVJRnL, VVlE2Q, path), title="Processing File ...")
 def VVJRnL(self, VVJun4, path):
  enc = CCiVik.VV4IR5(path, self)
  if enc == -1:
   return
  VVaKg1 = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF9GYH(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCnYqq.VVzVBV(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVaKg1:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVaKg1.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVaKg1:
   title = "Playlist File : %s" % os.path.basename(path)
   VVTXLQ  = ("Start"    , BF(self.VVfRAM, "Playlist File")      , [])
   VVXfC8 = ("Home Menu"   , FFarAp             , [])
   VVIZTW = ("Download M3U File" , self.VVunAG         , [])
   VVFaAj = ("Edit File"   , BF(self.VV6biK, path)        , [])
   VV6CVp = ("Check & Filter"  , BF(self.VV3qdw, VVJun4, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVGQvW  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVXfC8=VVXfC8, VV6CVp=VV6CVp, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VVRmfT="#11001116", VVRNJt="#11001116", VV84wP="#11001116", VVvmBM="#00003635", VVfpy3="#0a333333", VViJnU="#11331100", VV3cto=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFBsVa(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVunAG(self, VVzzNZ, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFEN35(self, BF(FFn5td, VVzzNZ, BF(self.VV9Wly, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VV9Wly(self, title, url):
  path, err = FFjgmp(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFBsVa(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFl3Sc(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFKqXn(path)
    FFBsVa(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFKqXn(path)
    FFBsVa(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CCnYqq.VVPZOj() + fName
    FFkQDN("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FFx4Fl(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFBsVa(self, "Could not download the M3U file!", title=errTitle)
 def VVfRAM(self, Title, VVzzNZ, title, txt, colList):
  url = colList[6]
  FFn5td(VVzzNZ, BF(self.VVSxcn, Title, url), title="Checking Server ...")
 def VV6biK(self, path, VVzzNZ, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCteri(self, path, VVqhY7=BF(self.VV990V, VVzzNZ), curRowNum=rowNum)
  else    : FFPQyp(self, path)
 def VV990V(self, VVzzNZ, fileChanged):
  if fileChanged:
   VVzzNZ.cancel()
 def VVGX1d(self, title):
  curChName = self.VVzzNZ.VVOEiT(1)
  FFsCnW(self, BF(self.VVIJI2, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVIJI2(self, title, name):
  if name:
   VVmC3N, err = CC8mGp.VV8K3y(self, CC8mGp.VVwIZF, VV0VUr=False, VVO4lq=False)
   list = []
   if VVmC3N:
    name = self.VVuSnO(name)
    ratio = "1"
    for item in VVmC3N:
     if name in item[0].lower():
      list.append((item[0], FF9eBo(item[2]), item[3], ratio))
   if list : self.VVUWWN(list, title)
   else : FFBsVa(self, "Not found:\n\n%s" % name, title=title)
 def VVBvIo(self, title):
  curChName = self.VVzzNZ.VVOEiT(1)
  self.session.open(CCIpg5, barTheme=CCIpg5.VVipyP
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVPnbU
      , VVqhY7 = BF(self.VVz2C9, title, curChName))
 def VVPnbU(self, VVomkw):
  curChName = self.VVzzNZ.VVOEiT(1)
  VVmC3N, err = CC8mGp.VV8K3y(self, CC8mGp.VVGe9h, VV0VUr=False, VVO4lq=False)
  if not VVmC3N or not VVomkw or VVomkw.isCancelled:
   return
  VVomkw.VV6uui = []
  VVomkw.VVITUK(len(VVmC3N))
  curCh = self.VVuSnO(curChName)
  for refCode in VVmC3N:
   chName, sat, inDB = VVmC3N.get(refCode, ("", "", 0))
   ratio = CCjCYH.VVIgwL(chName.lower(), curCh)
   if not VVomkw or VVomkw.isCancelled:
    return
   VVomkw.VVReKT(1, True)
   if VVomkw and ratio > 50:
    VVomkw.VV6uui.append((chName, FF9eBo(sat), refCode.replace("_", ":"), str(ratio)))
 def VVz2C9(self, title, curChName, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  if VV6uui: self.VVUWWN(VV6uui, title)
  elif VVuCFf: FFBsVa(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVUWWN(self, VVaKg1, title):
  curChName = self.VVzzNZ.VVOEiT(1)
  VVipUk = self.VVzzNZ.VVOEiT(4)
  curUrl  = self.VVzzNZ.VVOEiT(5)
  VVaKg1.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVTXLQ  = ("Share Sat/C/T Ref.", BF(self.VV2C4e, title, curChName, VVipUk, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVRmfT="#0a00112B", VVRNJt="#0a001126", VV84wP="#0a001126", VVvmBM="#00000000")
 def VV2C4e(self, newtitle, curChName, VVipUk, curUrl, VVzzNZ, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVipUk, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFEN35(self.VVzzNZ, BF(FFn5td, self.VVzzNZ, BF(self.VVssTr, VVzzNZ, data)), ques, title=newtitle, VV00ww=True)
 def VVssTr(self, VVzzNZ, data):
  VVzzNZ.cancel()
  title, curChName, VVipUk, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVipUk = VVipUk.strip()
  newRefCode = newRefCode.strip()
  if not VVipUk.endswith(":") : VVipUk += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVipUk, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVipUk + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CCnYqq.VVQk0n():
    txt = FFl3Sc(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFOnqc()
    newRow = []
    for i in range(6):
     newRow.append(self.VVzzNZ.VVOEiT(i))
    newRow[4] = newRefCode
    done = self.VVzzNZ.VVUkGQ(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFb5Nn(BF(FFx4Fl , self, resTxt, title=title))
  elif resErr: FFb5Nn(BF(FFBsVa, self, resErr, title=title))
 def VV3qdw(self, VVJun4, path, VVzzNZ, title, txt, colList):
  self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VV4cCX, VVzzNZ)
      , VVqhY7 = BF(self.VVyxxm, VVJun4, path, VVzzNZ))
 def VV4cCX(self, VVzzNZ, VVomkw):
  VVomkw.VVITUK(VVzzNZ.VVI5RC())
  VVomkw.VV6uui = []
  for row in VVzzNZ.VVMHVB():
   if not VVomkw or VVomkw.isCancelled:
    return
   VVomkw.VVReKT(1, True)
   qUrl = self.VVMjr9(self.VVh5cB, row[6])
   txt, err = self.VVHdcN(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVXW81(item, "auth") == "0":
       VVomkw.VV6uui.append(qUrl)
    except:
     pass
 def VVyxxm(self, VVJun4, path, VVzzNZ, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  if VVuCFf:
   list = VV6uui
   title = "Authorized Servers"
   if list:
    totChk = VVzzNZ.VVI5RC()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FF0Isj()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVvCO2(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFxrb0(str(totAuth), VVCKEk)
     txt += "%s\n\n%s"    %  (FFxrb0("Result File:", VVwwau), newPath)
     FFVBx2(self, txt, title=title)
     VVzzNZ.close()
     VVJun4.close()
    else:
     FFx4Fl(self, "All URLs are authorized.", title=title)
   else:
    FFBsVa(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVHdcN(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVzVBV(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVG1o6(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCYpe9.VVtxMu()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVufCo(decodedUrl):
  return CCnYqq.VVG1o6(decodedUrl, justRetDotExt=True)
 def VVMjr9(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVzVBV(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVh5cB   : return "%s"            % url
  elif mode == self.VVqGrn   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVGCKP   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VV7WvI  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVAzCq  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVk0RO : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVW8Vb   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VV9Nco    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVKaiR  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VVeucf : return "%s&action=get_live_streams"      % url
  elif mode == self.VV8mZW  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVXW81(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FF2ADr(int(val))
    elif is_base64 : val = FFyEub(val)
    elif isToHHMMSS : val = FFNguX(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVr6kQ(self, title, path):
  if fileExists(path):
   enc = CCiVik.VV4IR5(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CCnYqq.VVbGCt(line)
     if qUrl:
      break
   if qUrl : self.VVSxcn(title, qUrl)
   else : FFBsVa(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFBsVa(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV9BuH(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CCnYqq.VV5Dwl(self)
  if qUrl or "chCode" in iptvRef:
   p = CCUYQq()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVP070(iptvRef)
   if valid:
    self.VVCX5x(self, host, mac)
    return
   elif qUrl:
    FFn5td(self, BF(self.VVSxcn, title, qUrl), title="Checking Server ...")
    return
  FFBsVa(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VV5Dwl(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(SELF)
  qUrl = CCnYqq.VVbGCt(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVbGCt(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVSxcn(self, title, url):
  self.curUrl = url
  self.VVrqmtData = {}
  qUrl = self.VVMjr9(self.VVh5cB, url)
  txt, err = self.VVHdcN(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVrqmtData = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVrqmtData["username"    ] = self.VVXW81(item, "username"        )
    self.VVrqmtData["password"    ] = self.VVXW81(item, "password"        )
    self.VVrqmtData["message"    ] = self.VVXW81(item, "message"        )
    self.VVrqmtData["auth"     ] = self.VVXW81(item, "auth"         )
    self.VVrqmtData["status"    ] = self.VVXW81(item, "status"        )
    self.VVrqmtData["exp_date"    ] = self.VVXW81(item, "exp_date"    , isDate=True )
    self.VVrqmtData["is_trial"    ] = self.VVXW81(item, "is_trial"        )
    self.VVrqmtData["active_cons"   ] = self.VVXW81(item, "active_cons"       )
    self.VVrqmtData["created_at"   ] = self.VVXW81(item, "created_at"   , isDate=True )
    self.VVrqmtData["max_connections"  ] = self.VVXW81(item, "max_connections"      )
    self.VVrqmtData["allowed_output_formats"] = self.VVXW81(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVrqmtData[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVrqmtData["url"    ] = self.VVXW81(item, "url"        )
    self.VVrqmtData["port"    ] = self.VVXW81(item, "port"        )
    self.VVrqmtData["https_port"  ] = self.VVXW81(item, "https_port"      )
    self.VVrqmtData["server_protocol" ] = self.VVXW81(item, "server_protocol"     )
    self.VVrqmtData["rtmp_port"   ] = self.VVXW81(item, "rtmp_port"       )
    self.VVrqmtData["timezone"   ] = self.VVXW81(item, "timezone"       )
    self.VVrqmtData["timestamp_now"  ] = self.VVXW81(item, "timestamp_now"  , isDate=True )
    self.VVrqmtData["time_now"   ] = self.VVXW81(item, "time_now"       )
    VVtZf8  = self.VVnP5H(True)
    VVoeva = self.VVIgek
    VVlTMa = self.VVQbL1
    VV8QNc = ("Home Menu", FFarAp)
    VVJlf7= ("Add to Menu", BF(CCnYqq.VVDaJf, self, False, self.VVrqmtData["playListURL"]))
    VVR5O9 = ("Bookmark Server", BF(CCnYqq.VVEusf, self, False, self.VVrqmtData["playListURL"]))
    FFd7BR(self, None, title="IPTV Server Resources", VVtZf8=VVtZf8, VVoeva=VVoeva, VVlTMa=VVlTMa, VV8QNc=VV8QNc, VVJlf7=VVJlf7, VVR5O9=VVR5O9)
   else:
    err = "Could not get data from server !"
  if err:
   FFBsVa(self, err, title=title)
  FFrBcM(self)
 def VVIgek(self, item=None):
  if item:
   VVlE2Q, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFn5td(VVlE2Q, BF(self.VVAIC7, self.VVqGrn  , title=title), title=wTxt)
   elif ref == "vod"   : FFn5td(VVlE2Q, BF(self.VVAIC7, self.VVGCKP  , title=title), title=wTxt)
   elif ref == "series"  : FFn5td(VVlE2Q, BF(self.VVAIC7, self.VV7WvI , title=title), title=wTxt)
   elif ref == "catchup"  : FFn5td(VVlE2Q, BF(self.VVAIC7, self.VVAzCq , title=title), title=wTxt)
   elif ref == "accountInfo" : FFn5td(VVlE2Q, BF(self.VVZPCo           , title=title), title=wTxt)
 def VVQbL1(self, VVlE2Q, txt, ref, ndx):
  FFn5td(VVlE2Q, self.VVqpAU)
 def VVqpAU(self):
  txt = self.curUrl
  if VVNHHG:
   ver, err = self.VVhzNx(self.VV6H53())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VVsWL3
   txt += "PHP\t: %s\n"  % self.VVPWxG
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVDcHB, "-")
   txt += "Version\t: %s"  % (ver or err)
  FFVBx2(self, txt, title="Current Server URL")
 def VVZPCo(self, title):
  rows = []
  for key, val in self.VVrqmtData.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVIXLD
   else:
    num, part = "1", self.VV03jz
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVXfC8  = ("Home Menu", FFarAp, [])
  VVIZTW  = None
  if VVNHHG:
   VVIZTW = ("Get JS" , BF(self.VV6eL6, "/".join(self.VVrqmtData["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FFuI68(self, None, title=title, width=1200, header=header, VVBQW6=rows, VV3FCq=widths, VVJgEp=26, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVRmfT="#0a00292B", VVRNJt="#0a002126", VV84wP="#0a002126", VVvmBM="#00000000", searchCol=2)
 def VVDObi(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVW8Vb, self.VV8mZW):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVXW81(item, "num"         )
      name     = self.VVXW81(item, "name"        )
      stream_id    = self.VVXW81(item, "stream_id"       )
      stream_icon    = self.VVXW81(item, "stream_icon"       )
      epg_channel_id   = self.VVXW81(item, "epg_channel_id"      )
      added     = self.VVXW81(item, "added"    , isDate=True )
      is_adult    = self.VVXW81(item, "is_adult"       )
      category_id    = self.VVXW81(item, "category_id"       )
      tv_archive    = self.VVXW81(item, "tv_archive"       )
      direct_source   = self.VVXW81(item, "direct_source"      )
      tv_archive_duration  = self.VVXW81(item, "tv_archive_duration"     )
      name = self.VVtFW5(name, is_adult)
      if name:
       if mode == self.VVW8Vb or mode == self.VV8mZW and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VV9Nco:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVXW81(item, "num"         )
      name    = self.VVXW81(item, "name"        )
      stream_id   = self.VVXW81(item, "stream_id"       )
      stream_icon   = self.VVXW81(item, "stream_icon"       )
      added    = self.VVXW81(item, "added"    , isDate=True )
      is_adult   = self.VVXW81(item, "is_adult"       )
      category_id   = self.VVXW81(item, "category_id"       )
      container_extension = self.VVXW81(item, "container_extension"     ) or "mp4"
      name = self.VVtFW5(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVKaiR:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVXW81(item, "num"        )
      name    = self.VVXW81(item, "name"       )
      series_id   = self.VVXW81(item, "series_id"      )
      cover    = self.VVXW81(item, "cover"       )
      genre    = self.VVXW81(item, "genre"       )
      episode_run_time = self.VVXW81(item, "episode_run_time"    )
      category_id   = self.VVXW81(item, "category_id"      )
      container_extension = self.VVXW81(item, "container_extension"    ) or "mp4"
      name = self.VVtFW5(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VVAIC7(self, mode, title):
  cList, err = self.VVn6pO(mode)
  if cList and mode == self.VVAzCq:
   cList = self.VVAWwt(cList)
  if err:
   FFBsVa(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVRmfT, VVRNJt, VV84wP, VVvmBM = self.VVGBhy(mode)
   mName = self.VVejWL(mode)
   if   mode == self.VVqGrn  : fMode = self.VVW8Vb
   elif mode == self.VVGCKP  : fMode = self.VV9Nco
   elif mode == self.VV7WvI : fMode = self.VVKaiR
   elif mode == self.VVAzCq : fMode = self.VV8mZW
   if mode == self.VVAzCq:
    VVFaAj = None
    VV6CVp = None
   else:
    VVFaAj = ("Find in %s" % mName , BF(self.VVPVBQ, fMode, True) , [])
    VV6CVp = ("Find in Selected" , BF(self.VVPVBQ, fMode, False) , [])
   VVTXLQ   = ("Show List"   , BF(self.VVqe4Q, mode)  , [])
   VVXfC8  = ("Home Menu"   , FFarAp         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FFuI68(self, None, title=title, width=1200, header=header, VVBQW6=cList, VV3FCq=widths, VVJgEp=30, VVXfC8=VVXfC8, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VVTXLQ=VVTXLQ, VVRmfT=VVRmfT, VVRNJt=VVRNJt, VV84wP=VV84wP, VVvmBM=VVvmBM, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFBsVa(self, "No list from server !", title=title)
  FFrBcM(self)
 def VVn6pO(self, mode):
  qUrl  = self.VVMjr9(mode, self.VVrqmtData["playListURL"])
  txt, err = self.VVHdcN(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVXW81(item, "category_id"  )
     category_name = self.VVXW81(item, "category_name" )
     parent_id  = self.VVXW81(item, "parent_id"  )
     category_name = self.VVbRa0(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVAWwt(self, catList):
  mode  = self.VV8mZW
  qUrl  = self.VVMjr9(mode, self.VVrqmtData["playListURL"])
  txt, err = self.VVHdcN(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVDObi(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVqe4Q(self, mode, VVzzNZ, title, txt, colList):
  title = colList[1]
  FFn5td(VVzzNZ, BF(self.VVW1G8, mode, VVzzNZ, title, txt, colList), title="Downloading ...")
 def VVW1G8(self, mode, VVzzNZ, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVejWL(mode) + " : "+ bName
  if   mode == self.VVqGrn  : mode = self.VVW8Vb
  elif mode == self.VVGCKP  : mode = self.VV9Nco
  elif mode == self.VV7WvI : mode = self.VVKaiR
  elif mode == self.VVAzCq : mode = self.VV8mZW
  qUrl  = self.VVMjr9(mode, self.VVrqmtData["playListURL"], catID)
  txt, err = self.VVHdcN(qUrl)
  list  = []
  if not err and mode in (self.VVW8Vb, self.VV9Nco, self.VVKaiR, self.VV8mZW):
   list, err = self.VVDObi(mode, txt)
  if err:
   FFBsVa(self, err, title=title)
  elif list:
   VVXfC8  = ("Home Menu"   , FFarAp            , [])
   if mode in (self.VVW8Vb, self.VV8mZW):
    VVRmfT, VVRNJt, VV84wP, VVvmBM = self.VVGBhy(mode)
    VVZRP4 = (""     , BF(self.VVnRLi, mode)      , [])
    VVIZTW = ("Download Options" , BF(self.VVi4qs, mode, "", "")   , [])
    VVFaAj = ("Options"   , BF(self.VVAGKZ, "lv", mode, bName)   , [])
    VV6CVp = ("Posters Mode"  , BF(self.VVh0c7, mode, False)     , [])
    if mode == self.VVW8Vb:
     VVTXLQ = ("Play"    , BF(self.VVDHIJ, mode)       , [])
    else:
     VVTXLQ = ("Programs"   , BF(self.VVF0DB, mode, bName) , [])
   elif mode == self.VV9Nco:
    VVRmfT, VVRNJt, VV84wP, VVvmBM = self.VVGBhy(mode)
    VVTXLQ  = ("Play"    , BF(self.VVDHIJ, mode)       , [])
    VVZRP4 = (""     , BF(self.VVnRLi, mode)      , [])
    VVIZTW = ("Download Options" , BF(self.VVi4qs, mode, "v", "")   , [])
    VVFaAj = ("Options"   , BF(self.VVAGKZ, "v", mode, bName)   , [])
    VV6CVp = ("Posters Mode"  , BF(self.VVh0c7, mode, False)     , [])
   elif mode == self.VVKaiR:
    VVRmfT, VVRNJt, VV84wP, VVvmBM = self.VVGBhy("series2")
    VVTXLQ  = ("Show Seasons"  , BF(self.VVjOme, mode)       , [])
    VVZRP4 = (""     , BF(self.VVpRpu, mode)     , [])
    VVIZTW = None
    VVFaAj = None
    VV6CVp = ("Posters Mode"  , BF(self.VVh0c7, mode, True)      , [])
   header, widths, VVGQvW = self.VVNfwc(mode)
   FFuI68(self, None, title=title, header=header, VVBQW6=list, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindIptv, VVZRP4=VVZRP4, VVRmfT=VVRmfT, VVRNJt=VVRNJt, VV84wP=VV84wP, VVvmBM=VVvmBM, VV3cto=True, searchCol=1)
  else:
   FFBsVa(self, "No Channels found !", title=title)
  FFrBcM(self)
 def VVNfwc(self, mode):
  if mode in (self.VVW8Vb, self.VV8mZW):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVGQvW  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VV9Nco:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVGQvW  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVKaiR:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVGQvW  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVGQvW
 def VVF0DB(self, mode, bName, VVzzNZ, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVrqmtData["playListURL"]
  ok_fnc  = BF(self.VVTC7N, hostUrl, chName, catId, streamId)
  FFn5td(VVzzNZ, BF(CCnYqq.VViIN3, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVTC7N(self, chUrl, chName, catId, streamId, VVzzNZ, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCnYqq.VVzVBV(chUrl)
   chNum = "333"
   refCode = CCnYqq.VV4WFf(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFYeVI(self, chUrl, VVY16B=False)
   CCQFZI.VVbh0Z(self.session)
  else:
   FFBsVa(self, "Incorrect Timestamp", pTitle)
 def VVjOme(self, mode, VVzzNZ, title, txt, colList):
  title = colList[1]
  FFn5td(VVzzNZ, BF(self.VVpusH, mode, VVzzNZ, title, txt, colList), title="Downloading ...")
 def VVpusH(self, mode, VVzzNZ, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVMjr9(self.VVk0RO, self.VVrqmtData["playListURL"], series_id)
  txt, err = self.VVHdcN(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVXW81(tDict["info"], "name"   )
      category_id = self.VVXW81(tDict["info"], "category_id" )
      icon  = self.VVXW81(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVXW81(EP, "id"     )
        episode_num   = self.VVXW81(EP, "episode_num"   )
        epTitle    = self.VVXW81(EP, "title"     )
        container_extension = self.VVXW81(EP, "container_extension" )
        seasonNum   = self.VVXW81(EP, "season"    )
        epTitle = self.VVtFW5(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFBsVa(self, err, title=title)
  elif list:
   VVXfC8 = ("Home Menu"   , FFarAp          , [])
   VVIZTW = ("Download Options" , BF(self.VVi4qs, mode, "s", title), [])
   VVFaAj = ("Options"   , BF(self.VVAGKZ, "s", mode, title) , [])
   VV6CVp = ("Posters Mode"  , BF(self.VVh0c7, mode, False)   , [])
   VVZRP4 = (""     , BF(self.VVnRLi, mode)    , [])
   VVTXLQ  = ("Play"    , BF(self.VVDHIJ, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVGQvW  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FFuI68(self, None, title=title, header=header, VVBQW6=list, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VVFaAj=VVFaAj, VV6CVp=VV6CVp, lastFindConfigObj=CFG.lastFindIptv, VVRmfT="#0a00292B", VVRNJt="#0a002126", VV84wP="#0a002126", VVvmBM="#00000000")
  else:
   FFBsVa(self, "No Channels found !", title=title)
  FFrBcM(self)
 def VVPVBQ(self, mode, isAll, VVzzNZ, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVtZf8 = []
  VVtZf8.append(("Keyboard"  , "manualEntry"))
  VVtZf8.append(("From Filter" , "fromFilter"))
  FFd7BR(self, BF(self.VVXUbr, VVzzNZ, mode, onlyCatID), title="Input Type", VVtZf8=VVtZf8, width=400)
 def VVXUbr(self, VVzzNZ, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFsCnW(self, BF(self.VVMsTV, VVzzNZ, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCmB9U(self)
    filterObj.VVoqZE(BF(self.VVMsTV, VVzzNZ, mode, onlyCatID))
 def VVMsTV(self, VVzzNZ, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFSeyu(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCmB9U.VVbRSg(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFBsVa(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFBsVa(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVfbTY(words):
      FFBsVa(self, self.VVm2Rv(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCIpg5, barTheme=CCIpg5.VVipyP
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVXgWj, VVzzNZ, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVqhY7 = BF(self.VVit9n, mode, toFind, title))
   if not words:
    FFrBcM(VVzzNZ, "Nothing to find !", 1500)
 def VVXgWj(self, VVzzNZ, mode, onlyCatID, title, words, toFind, asPrefix, VVomkw):
  VVomkw.VVITUK(VVzzNZ.VVdO40() if onlyCatID is None else 1)
  VVomkw.VV6uui = []
  for row in VVzzNZ.VVMHVB():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVomkw or VVomkw.isCancelled:
    return
   VVomkw.VVReKT(1)
   VVomkw.VVw3Fg(catName)
   qUrl  = self.VVMjr9(mode, self.VVrqmtData["playListURL"], catID)
   txt, err = self.VVHdcN(qUrl)
   if not err:
    tList, err = self.VVDObi(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVtFW5(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVomkw or VVomkw.isCancelled:
        return
       VVomkw.VV6uui.append(item)
       VVomkw.VVw3Fg(catName)
 def VVit9n(self, mode, toFind, title, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  if VV6uui:
   title = self.VVLH8l(mode, toFind)
   if mode == self.VVW8Vb or mode == self.VV9Nco:
    if mode == self.VV9Nco : typ = "v"
    else          : typ = ""
    bName   = CCnYqq.VVwgy6(toFind)
    VVTXLQ  = ("Play"     , BF(self.VVDHIJ, mode)     , [])
    VVIZTW = ("Download Options" , BF(self.VVi4qs, mode, typ, "") , [])
    VVFaAj = ("Options"   , BF(self.VVAGKZ, "fnd", mode, bName), [])
    VV6CVp = ("Posters Mode"  , BF(self.VVh0c7, mode, False)   , [])
    VVZRP4 = (""     , BF(self.VVnRLi, mode)    , [])
   elif mode == self.VVKaiR:
    VVTXLQ  = ("Show Seasons"  , BF(self.VVjOme, mode)     , [])
    VVFaAj = None
    VVIZTW = None
    VV6CVp = ("Posters Mode"  , BF(self.VVh0c7, mode, True)    , [])
    VVZRP4 = (""     , BF(self.VVpRpu, mode)   , [])
   VVXfC8  = ("Home Menu"   , FFarAp          , [])
   header, widths, VVGQvW = self.VVNfwc(mode)
   VVzzNZ = FFuI68(self, None, title=title, header=header, VVBQW6=VV6uui, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VVZRP4=VVZRP4, VVRmfT="#0a00292B", VVRNJt="#0a002126", VV84wP="#0a002126", VVvmBM="#00000000", VV3cto=True, searchCol=1)
   if not VVuCFf:
    FFrBcM(VVzzNZ, "Stopped" , 1000)
  else:
   if VVuCFf:
    FFBsVa(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVreGJ(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVW8Vb, self.VV8mZW):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VV9Nco:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFpnOy(chName)
  url = self.VVrqmtData["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVzVBV(url)
  refCode = self.VV4WFf(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVnRLi(self, mode, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VVmcxw, mode, VVzzNZ, title, txt, colList))
 def VVmcxw(self, mode, VVzzNZ, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVreGJ(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFqy2T(self, fncMode=CCFLza.VV34t7, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVpRpu(self, mode, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VVPlDv, mode, VVzzNZ, title, txt, colList))
 def VVPlDv(self, mode, VVzzNZ, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFqy2T(self, fncMode=CCFLza.VVGhyR, chName=name, text=txt, picUrl=Cover)
 def VVh0c7(self, mode, isSerNames, VVzzNZ, title, txt, colList):
  if   mode in ("itv"  , CCnYqq.VVW8Vb, CCnYqq.VV8mZW): category = "live"
  elif mode in ("vod"  , CCnYqq.VV9Nco )          : category = "vod"
  elif mode in ("series" , CCnYqq.VVKaiR)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVW8Vb : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV8mZW : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VV9Nco  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVKaiR : picCol, descCol, descTxt = 5, 0, "Season"
  FFn5td(VVzzNZ, BF(self.session.open, CCdMNE, VVzzNZ, category, nameCol, picCol, descCol, descTxt))
 def VVi4qs(self, mode, typ, seriesName, VVzzNZ, title, txt, colList):
  VVtZf8 = []
  isMulti = VVzzNZ.VVoCEo
  tot  = VVzzNZ.VVRFlF()
  if isMulti:
   if tot < 1:
    FFrBcM(VVzzNZ, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVtZf8.append(("Download %s PIcon%s" % (name, FFAHjU(tot)), "dnldPicons" ))
  if typ:
   VVtZf8.append(VVh3VV)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVtZf8.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVtZf8.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVtZf8.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCPYn3.VVCizW():
    VVtZf8.append(VVh3VV)
    VVtZf8.append(("Download Manager"      , "dload_stat" ))
  FFd7BR(self, BF(self.VVQoMn, VVzzNZ, mode, typ, seriesName, colList), title="Download Options", VVtZf8=VVtZf8)
 def VVQoMn(self, VVzzNZ, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVCRp7(VVzzNZ, mode)
   elif item == "dnldSel"  : self.VVHqyQ(VVzzNZ, mode, typ, colList, True)
   elif item == "addSel"  : self.VVHqyQ(VVzzNZ, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VV0RXd(VVzzNZ, mode, typ, seriesName)
   elif item == "dload_stat" : CCPYn3.VVYez0(self, VVzzNZ)
 def VVHqyQ(self, VVzzNZ, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VViGkC(mode, typ, colList)
  if startDnld:
   CCPYn3.VV6KOI(self, decodedUrl)
  else:
   self.VVBpqz(VVzzNZ, "Add to Download list", chName, [decodedUrl], startDnld)
 def VV0RXd(self, VVzzNZ, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVzzNZ.VVMHVB():
   chName, decodedUrl = self.VViGkC(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVBpqz(VVzzNZ, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVBpqz(self, VVzzNZ, title, chName, decodedUrl_list, startDnld):
  FFEN35(self, BF(self.VV9jzn, VVzzNZ, decodedUrl_list, startDnld), chName, title=title)
 def VV9jzn(self, VVzzNZ, decodedUrl_list, startDnld):
  added, skipped = CCPYn3.VVyPEm(decodedUrl_list)
  FFrBcM(VVzzNZ, "Added", 1000)
 def VViGkC(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVreGJ(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVN36o(mode, colList)
   refCode, chUrl = self.VVb5Mj(self.VVsWL3, self.VVWinM, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFR5dT(chUrl)
  return chName, decodedUrl
 def VVCRp7(self, VVzzNZ, mode):
  if FFtTXa("ffmpeg"):
   self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVLlBv, VVzzNZ, mode)
       , VVqhY7 = self.VVqiuu)
  else:
   FFEN35(self, BF(CCnYqq.VVwckU, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VVqiuu(self, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VV6uui["proces"], VV6uui["total"])
  txt += "Download Success\t: %d of %s\n"  % (VV6uui["ok"], VV6uui["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VV6uui["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VV6uui["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VV6uui["badURL"]
  txt += "Download Failure\t: %d\n"   % VV6uui["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VV6uui["path"]
  if not VVuCFf  : color = "#11402000"
  elif VV6uui["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VV6uui["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VV6uui["err"], txt)
  title = "PIcons Download Result"
  if not VVuCFf:
   title += "  (cancelled)"
  FFVBx2(self, txt, title=title, VV84wP=color)
 def VVLlBv(self, VVzzNZ, mode, VVomkw):
  isMulti = VVzzNZ.VVoCEo
  if isMulti : totRows = VVzzNZ.VVRFlF()
  else  : totRows = VVzzNZ.VVdO40()
  VVomkw.VVITUK(totRows)
  VVomkw.VVVKhZ(0)
  counter     = VVomkw.counter
  maxValue    = VVomkw.maxValue
  pPath     = CCjCYH.VVzyVV()
  VVomkw.VV6uui = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVzzNZ.VVMHVB()):
    if VVomkw.isCancelled:
     break
    if not isMulti or VVzzNZ.VVvrS0(rowNum):
     VVomkw.VV6uui["proces"] += 1
     VVomkw.VVReKT(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVN36o(mode, row)
      refCode = CCnYqq.VV4WFf(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVCh60(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVreGJ(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVomkw.VV6uui["attempt"] += 1
       path, err = FFjgmp(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVomkw:
         VVomkw.VV6uui["ok"] += 1
         VVomkw.VVVKhZ(VVomkw.VV6uui["ok"])
        if FFotbw(path) > 0:
         cmd = CCFLza.VVPCa2(path)
         cmd += FFaBql("mv -f '%s' '%s'" % (path, pPath))
         FFkQDN(cmd)
        else:
         if VVomkw:
          VVomkw.VV6uui["size0"] += 1
         FFKqXn(path)
       elif err:
        if VVomkw:
         VVomkw.VV6uui["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVomkw:
          VVomkw.VV6uui["err"] = err.title()
         break
      else:
       if VVomkw:
        VVomkw.VV6uui["exist"] += 1
     else:
      if VVomkw:
       VVomkw.VV6uui["badURL"] += 1
  except:
   pass
 def VVzrYy(self):
  title = "Download PIcons for Current Bouquet"
  if FFtTXa("ffmpeg"):
   self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2
       , titlePrefix = ""
       , fncToRun  = self.VV57u7
       , VVqhY7 = BF(self.VVYycV, title))
  else:
   FFEN35(self, BF(CCnYqq.VVwckU, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VV57u7(self, VVomkw):
  bName = CCQq9Y.VVzYiQ()
  pPath = CCjCYH.VVzyVV()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVomkw.VV6uui = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCQq9Y.VVXEX3()
  if not VVomkw or VVomkw.isCancelled:
   return
  if not services or len(services) == 0:
   VVomkw.VV6uui = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVomkw.VVITUK(totCh)
  VVomkw.VVVKhZ(0)
  for serv in services:
   if not VVomkw or VVomkw.isCancelled:
    return
   VVomkw.VV6uui = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVomkw.VVReKT(1)
   VVomkw.VVVKhZ(totPic)
   fullRef  = serv[0]
   if FFAXDs(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFR5dT(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCUYQq.VVrOto(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CCnYqq.VVG1o6(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCnYqq.VVHdcN(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCFLza.VVTODE(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFjgmp(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVomkw:
     VVomkw.VVVKhZ(totPic)
    if FFotbw(path) > 0:
     cmd = CCFLza.VVPCa2(path)
     cmd += FFaBql("mv -f '%s' '%s'" % (path, pPath))
     FFkQDN(cmd)
     totPicOK += 1
    else:
     totSize0
     FFKqXn(path)
  if VVomkw:
   VVomkw.VV6uui = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVYycV(self, title, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VV6uui
  if err:
   FFBsVa(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFxrb0(str(totExist)  , VVmxw7)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFxrb0(str(totNotIptv)  , VVmxw7)
    if totServErr : txt += "Server Errors\t: %s\n" % FFxrb0(str(totServErr) + t1, VVmxw7)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFxrb0(str(totParseErr) , VVmxw7)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFxrb0(str(totInvServ)  , VVmxw7)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFxrb0(str(totInvPicUrl) , VVmxw7)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFxrb0(str(totSize0)  , VVmxw7)
   if not VVuCFf:
    title += "  (stopped)"
   FFVBx2(self, txt, title=title)
 @staticmethod
 def VVwckU(SELF):
  cmd = FFgOTM(VV6ESW, "ffmpeg")
  if cmd : FFeWwS(SELF, cmd, title="Installing FFmpeg")
  else : FF5yx0(SELF)
 @staticmethod
 def VVQrbx(SELF):
  SELF.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2
      , titlePrefix = ""
      , fncToRun  = CCnYqq.VVFXmq
      , VVqhY7 = BF(CCnYqq.VVTGRQ, SELF))
 @staticmethod
 def VVFXmq(VVomkw):
  bName = CCQq9Y.VVzYiQ()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVomkw.VV6uui = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCQq9Y.VVXEX3()
  if not VVomkw or VVomkw.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVomkw.VVITUK(totCh)
   for serv in services:
    if not VVomkw or VVomkw.isCancelled:
     return
    VVomkw.VVReKT(1)
    fullRef = serv[0]
    if FFAXDs(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFR5dT(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCUYQq.VV4Nt1(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CCnYqq.VVG1o6(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CCnYqq.VVo8Wo(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVomkw:
      VVomkw.VVkjQn(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCNVQf.VVu3iK(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVomkw:
     VVomkw.VV6uui = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVomkw.VV6uui = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVTGRQ(SELF, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VV6uui
  title = "IPTV EPG Import"
  if err:
   FFBsVa(SELF, err, title=title)
  else:
   if VVuCFf and totEpgOK > 0:
    CCNVQf.VVfCMo()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFxrb0(str(totNotIptv), VVmxw7)
    if totServErr : txt += "Server Errors\t: %s\n" % FFxrb0(str(totServErr) + t1, VVmxw7)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFxrb0(str(totInv), VVmxw7)
   if not VVuCFf:
    title += "  (stopped)"
   FFVBx2(SELF, txt, title=title)
 @staticmethod
 def VVo8Wo(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CCnYqq.VVzVBV(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CCnYqq.VVHdcN(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CCnYqq.VVXW81(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CCnYqq.VVXW81(item, "lang"        ).upper()
    now_playing   = CCnYqq.VVXW81(item, "now_playing"      )
    start    = CCnYqq.VVXW81(item, "start"        )
    start_timestamp  = CCnYqq.VVXW81(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CCnYqq.VVXW81(item, "start_timestamp"     )
    stop_timestamp  = CCnYqq.VVXW81(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CCnYqq.VVXW81(item, "stop_timestamp"      )
    tTitle    = CCnYqq.VVXW81(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VV4WFf(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CCnYqq.VVKQ15(catID, MAX_4b)
  TSID = CCnYqq.VVKQ15(chNum, MAX_4b)
  ONID = CCnYqq.VVKQ15(chNum, MAX_4b)
  NS  = CCnYqq.VVKQ15(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVKQ15(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVwgy6(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVGBhy(mode):
  if   mode in ("itv"  , CCnYqq.VVqGrn)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CCnYqq.VVGCKP)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CCnYqq.VV7WvI) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CCnYqq.VVAzCq) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CCnYqq.VV8mZW    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VVpROv(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVikmx:
   excl = FFwS2p(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFBsVa(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFIM7p('find %s %s %s' % (path, excl, par))
  if files:
   err = CC5iId.VVuDDL(files)
   if err : FFBsVa(self, err + FFxrb0('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVwwau))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFBsVa(self, err)
  return []
 @staticmethod
 def VVPZOj():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FF9GYH(path)
  return "/"
 @staticmethod
 def VViIN3(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CCnYqq.VVo8Wo(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFBsVa(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVRmfT, VVRNJt, VV84wP, VVvmBM = CCnYqq.VVGBhy("")
   VVXfC8 = ("Home Menu" , FFarAp, [])
   VVTXLQ  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVGQvW  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FFuI68(SELF, None, title="Programs for : " + chName, header=header, VVBQW6=pList, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=24, VVTXLQ=VVTXLQ, VVXfC8=VVXfC8, VVRmfT=VVRmfT, VVRNJt=VVRNJt, VV84wP=VV84wP, VVvmBM=VVvmBM)
  else:
   FFBsVa(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVP1Xe(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VVDaJf(self, isPortal, line, selectionObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFEN35(self, BF(self.VVrNs0, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFSeyu(confItem, line)
   FFx4Fl(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VVrNs0(self, title, confItem):
  FFSeyu(confItem, "")
  FFx4Fl(self, "Removed from IPTV Menu.", title=title)
 def VV3g3v(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VVCX5x(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFn5td(self, BF(self.VVSxcn, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFBsVa(self, "Incorrect server data !")
 @staticmethod
 def VVEusf(SELF, isPortal, line, selectionObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CCnYqq.VVPZOj()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFBsVa(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FFx4Fl(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFBsVa(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVAGKZ(self, source, mode, curBName, VVzzNZ, title, txt, colList):
  isMulti = VVzzNZ.VVoCEo
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVzzNZ.VVRFlF()
   totTxt = "%d Service%s" % (tot, FFAHjU(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFxrb0(totTxt, VVwwau)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CC7G9K(self, VVzzNZ, addSep=False)
  thTxt = "Adding Services ..."
  VVtZf8, cbFncDict = [], None
  VVtZf8.append(VVh3VV)
  if itemsOK:
   VVtZf8.append(("Add %s to New Bouquet : %s"    % (totTxt, FFxrb0(curBName , VVCKEk)), "addToCur1"))
   if curBName2: VVtZf8.append(("Add %s to New Bouquet : %s" % (totTxt, FFxrb0(curBName2, VVTVZG)) , "addToCur2"))
   VVtZf8.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFn5td, mSel.VVzzNZ, BF(self.VVHOU7,source, mode, curBName , VVzzNZ, title), title=thTxt)
      , "addToCur2": BF(FFn5td, mSel.VVzzNZ, BF(self.VVHOU7,source, mode, curBName2, VVzzNZ, title), title=thTxt)
      , "addToNew" : BF(self.VVgTwH, source, mode, curBName, VVzzNZ, title)
      }
  else:
   VVtZf8.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVaknP(VVtZf8, cbFncDict, width=1400)
 def VVHOU7(self, source, mode, curBName, VVzzNZ, Title):
  chUrlLst = self.VVZL51(source, mode, VVzzNZ)
  CCQq9Y.VVFFSs(self, Title, curBName, "", chUrlLst)
 def VVgTwH(self, source, mode, curBName, VVzzNZ, Title):
  picker = CCQq9Y(self, VVzzNZ, Title, BF(self.VVZL51, source, mode, VVzzNZ), defBName=curBName)
 def VVZL51(self, source, mode, VVzzNZ):
  totChange = 0
  isMulti = VVzzNZ.VVoCEo
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVzzNZ.VVMHVB()):
   if not isMulti or VVzzNZ.VVvrS0(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVN36o(mode, row)
     refCode, chUrl = self.VVb5Mj(self.VVsWL3, self.VVWinM, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVHjW0(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVreGJ(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVLwQz():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVBUYw():
  return sorted(tuple(CCnYqq.VVLwQz()))
 @staticmethod
 def VVC7wL(rt):
  return CCnYqq.VVLwQz().get(str(rt), "")
 @staticmethod
 def VV1wlX(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CCnYqq.VVC7wL(span.group(1)) if span else ""
 @staticmethod
 def VVlNfK(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVJ1iq():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVtZf8 = []
  for ndx, rt in enumerate(CCnYqq.VVBUYw()):
   VVtZf8.append(FFTjqa("%s\t... %s" % (CCnYqq.VVC7wL(rt), rt), rt, CCnYqq.VVlNfK(rt), VVs7I8 if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVtZf8.append(VVh3VV)
  return VVtZf8
class CCl0Tb(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VVcPcu(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFwVrd(self.frm, frmColor)
  FFwVrd(self.bak, bakColor)
  FFwVrd(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVJwJj(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FFUY5i(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCmFCu(CCl0Tb):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCl0Tb.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VVdwYU()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(VVO7iZ,
  {
   "up" : self.VVSK0n   ,
   "down" : self.VVvWX5  ,
   "left" : self.VV3UwQ  ,
   "right" : self.VVWKwc  ,
   "next" : self.VVjNpQ ,
   "last" : self.VV4BB5
  }, -1)
 def VVzf0v(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VVcPcu(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VVYchJ()
  self["myPiconPtr"].hide()
 def VVjTji(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VVSK0n(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVagdB()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVH3D8()
 def VVvWX5(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVEln9()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVH3D8()
 def VV3UwQ(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVagdB()
  else:
   self.curCol -= 1
   self.VVH3D8()
 def VVWKwc(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVEln9()
  else:
   self.curCol += 1
   self.VVH3D8()
 def VV4BB5(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVH3D8(oldPage != self.curPage)
 def VVjNpQ(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVH3D8(oldPage != self.curPage)
 def VVEln9(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVH3D8(force)
 def VVagdB(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVH3D8(force)
 def VVH3D8(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVHwMO = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVHwMO: self.curPage = VVHwMO
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVpc7H()
  self["myPiconPtr"].hide()
  self.VVJwJj(self.curPage + 1, self.totalPages)
  FFb5Nn(BF(self.VVd9ON, force or not oldPage == self.curPage, VVHwMO))
 def VVd9ON(self, force, VVHwMO):
  try:
   if force:
    self.VVreOC()
   if self.curPage == VVHwMO:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVpc7H()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
  except:
   pass
  self["myPiconPtr"].show()
 def VVOdcZ(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVH3D8(False if oldPage == self.curPage else True)
  else:
   FFrBcM(self, "Not found", 1000)
 def VVncHi(self):
  self.VVOdcZ(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVdwYU(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVI8JL(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVANIj, CCPUUw, defFG=fg, defBG=bg, onlyBG=True)
 def VVANIj(self, fg, bg):
  if self.colorCfg and bg:
   FFSeyu(self.colorCfg, bg)
   self.VVYchJ()
 def VVYchJ(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFwVrd(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVlyyY(self, lbl, txt, color=""):
  CCmFCu.VVECPN(lbl, txt, color)
 @staticmethod
 def VVECPN(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVdN0z(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCdMNE(Screen, CCmFCu):
 def __init__(self, session, VVzzNZ, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FF98gL(VVjv67, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVzzNZ  = VVzzNZ
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVBQW6    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFd98D(self, self.Title)
  CCmFCu.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVzbRf, subPath)
  if not pathExists(self.pPath):
   FFkQDN("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVnIt0    ,
   "cancel": self.close    ,
   "menu" : self.VVrSUw ,
   "info" : self.VV6PDB  ,
   "0"  : self.VVncHi
  })
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFD5nM(self)
  FFRet2(self)
  self.VVzf0v()
  self.VVYkQu()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVrSUw(self):
  chName, subj, desc, fName, picUrl = self.VVBQW6[self.curIndex]
  VVtZf8 = []
  VVtZf8.append(FFTjqa("Show Selected Picture"        , "VVSzcM"  , fName))
  VVtZf8.append(FFTjqa("Copy Selected Picture to Export-Directory"   , "VVQ8RZ" , fName))
  VVtZf8.append(FFTjqa("Set Selected Picture as a Poster for a Local Media" , "VVinNw", fName))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Cache details"       , "VVZapc"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Change Poster/Picon Transparency Color" , "VVI8JL" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Help (Keys)"        , "help"     ))
  FFd7BR(self, self.VVGfhJ, title=self.Title, VVtZf8=VVtZf8)
 def VVGfhJ(self, item=None):
  if item is not None:
   if   item == "VVSzcM"   : self.VVSzcM()
   elif item == "VVQ8RZ"   : self.VVQ8RZ()
   elif item == "VVinNw"  : self.VVinNw()
   elif item == "VVZapc"  : FFn5td(self, self.VVZapc, title="Calculating ...")
   elif item == "VVI8JL": self.VVI8JL()
   elif item == "help"     : FF4fCC(self, "_help_servBr", "Server Browser (Keys)")
 def VVnIt0(self):
  self.VVzzNZ.VV8i74(self.curIndex)
  self.VVzzNZ.VVA0L4()
 def VV6PDB(self):
  self.VVzzNZ.VV8i74(self.curIndex)
  self.VVzzNZ.VVjHhQ()
 def VVYkQu(self):
  for colList in self.VVzzNZ.VVMHVB():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVBQW6.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVBQW6)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVzzNZ.VVXRaz()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVH3D8(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVGA5t)
  except:
   self.timer.callback.append(self.VVGA5t)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VV5ivC)
  self.myThread.start()
 def VV5ivC(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVBQW6):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFjgmp(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFkQDN("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVBQW6[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VVGA5t(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVKRbh + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVBQW6[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVBQW6[ndx] = (chName, subj, desc, fName, "")
     CCmFCu.VVdN0z(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVreOC(self):
  self.VVdwYU()
  f1, f2 = self.VVjTji()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVBQW6[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVlyyY(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVG8hM + "iptv.png"
   CCmFCu.VVdN0z(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVpc7H(self):
  chName, subj, desc, fName, picUrl = self.VVBQW6[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVSzcM(self):
  chName, subj, desc, fName, picUrl = self.VVBQW6[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCSQFA.VV9tRL(self, self.pPath + fName)
  else          : FFrBcM(self, "File not found", 1500)
 def VVQ8RZ(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVBQW6[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFkQDN("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FFx4Fl(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFBsVa(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFBsVa(self, "No Poster/PIcon found", title=title)
 def VVinNw(self):
  self.session.openWithCallback(self.VVpQWq, BF(CC5iId, patternMode="movies", VV0aja=CFG.MovieDownloadPath.getValue()))
 def VVpQWq(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVBQW6[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFkQDN("cp -f '%s' '%s'" % (srcF, dstF)):
     FFx4Fl(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFBsVa(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCxhEJ.VVyBaZ(dstF)
   else:
    FFBsVa(self, "No Poster/PIcon found", title=title)
 def VVZapc(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVzbRf, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FFz86l("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CC5iId.VVp3Jg(size)
   txt += "%s\n    %s\n\n" % (FFxrb0(path, VVwwau), size)
  mainPath = "%sPosters" % VVzbRf
  totFiles = FFz86l("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FFAHjU(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFxrb0("Total space used by Posters/PIcons%s:" % totFTxt, VV0V0q), CC5iId.VVp3Jg(totSize))
  mountPath = CC5iId.VVg6qp(mainPath)
  if pathExists(mountPath):
   totSize  = CC5iId.VVPQRH(mountPath)
   freeSize = CC5iId.VVpbj4(mountPath)
   usedSize = CC5iId.VVp3Jg(totSize - freeSize)
   totSize  = CC5iId.VVp3Jg(totSize)
   freeSize = CC5iId.VVp3Jg(freeSize)
   txt += "%s\n" % SEP
   txt += FFxrb0("Media Space:\n", VVOICC)
   txt += "    Media Path\t: %s\n" % FFxrb0(mountPath, VVquhO)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FFVBx2(self, txt, title="Cache Used Size", height=1000)
class CCxhEJ(Screen, CCmFCu):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FF98gL(VVyzUX, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVBQW6    = lst
  FFd98D(self, self.Title)
  CCmFCu.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVnIt0    ,
   "cancel": self.close    ,
   "menu" : self.VVhoSD ,
   "info" : self.VVVLEV  ,
   "0"  : self.VVncHi
  })
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFD5nM(self)
  FFRet2(self)
  self.VVzf0v()
  self.totalItems = len(self.VVBQW6)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVH3D8(True)
 def VVreOC(self):
  self.VVdwYU()
  f1, f2 = self.VVjTji()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVBQW6[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVG8hM + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVlyyY(lbl, os.path.splitext(os.path.basename(path))[0])
   CCmFCu.VVdN0z(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV7t5x(self):
  path, movie, poster = self.VVBQW6[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVpc7H(self):
  path, poster = self.VV7t5x()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVhoSD(self):
  path, poster = self.VV7t5x()
  VVtZf8 = []
  VVtZf8.append(("Go to movie ...", "VVES8p"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(FFTjqa("Show Poster"      , "VVSzcM" , poster))
  VVtZf8.append(FFTjqa("Copy Poster to Export-Directory" , "VVQ8RZ", poster))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Change Poster/Picon Transparency Color"  , "VVI8JL" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Change Poster (from current movie path) ..." , "VV1wwa1"  ))
  VVtZf8.append(("Change Poster (locate manually) ..."   , "VV1wwa2"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Help (Keys)"         , "help"     ))
  FFd7BR(self, self.VV4xqq, title=self.Title, VVtZf8=VVtZf8)
 def VV4xqq(self, item=None):
  if item is not None:
   if   item == "VVES8p"    : self.VVES8p()
   elif item == "VVQ8RZ"    : self.VVQ8RZ()
   elif item == "VVSzcM"    : self.VVSzcM()
   elif item == "VVI8JL" : self.VVI8JL()
   elif item == "VV1wwa1"  : self.VV1wwa()
   elif item == "VV1wwa2"  : self.VV1wwa(True)
   elif item == "help"      : FF4fCC(self, "_help_movBr", "Movies Browser (Keys)")
 def VVES8p(self):
  VVaKg1 = []
  for ndx, item in enumerate(self.VVBQW6):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVaKg1.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVaKg1.sort(key=lambda x: x[0].lower())
  VVTXLQ = ("Select" , self.VVRYpA, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FFuI68(self, None, title="Select Movie", width=1800, height=1000, header=header, VVBQW6=VVaKg1, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, lastFindConfigObj=CFG.lastFindMovie)
 def VVRYpA(self, VVzzNZ, title, txt, colList):
  self.VVOdcZ(int(colList[2].strip()))
  VVzzNZ.cancel()
 def VVnIt0(self):
  path, poster = self.VV7t5x()
  FFn5td(self, BF(CC5iId.VV0HP2, self, path), title="Playing Media ...")
 def VVVLEV(self):
  path, poster = self.VV7t5x()
  txt = "%s:\n%s\n\n" % (FFxrb0("Path", VVwwau), path)
  size = FFotbw(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFxrb0("File Size", VVwwau), CC5iId.VVp3Jg(size))
  if poster:
   txt += "%s:\n%s" % (FFxrb0("Poster", VVwwau), poster)
  FFVBx2(self, txt, title="Media File Information")
 def VVSzcM(self):
  path, poster = self.VV7t5x()
  if fileExists(poster): CCSQFA.VV9tRL(self, poster)
  else     : FFrBcM(self, "No Poster", 1500)
 def VVQ8RZ(self):
  title = "Copy Poster"
  path, poster = self.VV7t5x()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFkQDN("cp -f '%s' '%s'" % (poster, dstF)):
    FFx4Fl(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFBsVa(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FFrBcM(self, "No Poster", 1500)
 def VV1wwa(self, isManual=False):
  path, poster = self.VV7t5x()
  sDir = FF9GYH(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VVPrFb, sDir, path), BF(CC5iId, patternMode="poster", VV0aja=sDir))
  else:
   VVtZf8 = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVtZf8.append((os.path.basename(item), sDir + item))
   if VVtZf8:
    VVtZf8.sort(key=lambda x: x[0].lower())
    VVlTMa = self.VVk91l
    FFd7BR(self, BF(self.VVPrFb, sDir, path), VVtZf8=VVtZf8, title="Posters", VVlTMa=VVlTMa, VVK9oq=sDir)
   else:
    FFrBcM(self, "No jpg/png in current dir", 1500)
 def VVk91l(self, VVlE2Q, txt, ref, ndx):
  CCSQFA.VV9tRL(self, VVukle=ref)
 def VVPrFb(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFkQDN("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVBQW6[self.curIndex] = (self.VVBQW6[self.curIndex][0], self.VVBQW6[self.curIndex][1], os.path.basename(newPath))
    FFn5td(self, self.VVreOC)
    CCxhEJ.VVyBaZ(newPath)
   else:
    FFrBcM(self, "Cannot copy file", 1000)
 @staticmethod
 def VVyBaZ(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFkQDN("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVGTXv(SELF):
  eLst = CCYpe9.VVtxMu()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCxhEJ, title, lst)
  else  : FFBsVa(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CCg2Sr(Screen, CCmFCu):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FF98gL(VVAbQS, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVBQW6    = lst
  self.pPath    = CCjCYH.VVzyVV()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFd98D(self, self.Title)
  FF1N71(self["keyRed"] , "OK = Zap (Review)")
  FF1N71(self["keyGreen"] , "Zap & Exit")
  FF1N71(self["keyYellow"], "Find Current Service")
  CCmFCu.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VV5MpZ, False),
   "cancel" : self.VVBrRb      ,
   "menu"  : self.VVsg1D   ,
   "red"  : self.VVBrRb      ,
   "green"  : BF(self.VV5MpZ, True) ,
   "yellow" : BF(self.VVpvgY, True)  ,
   "0"   : self.VVncHi
  })
  self.onShown.append(self.VV583n)
 def VV583n(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFD5nM(self)
   FFRet2(self)
   FFwVrd(self["keyRed"], "#0a333333")
   self.VVzf0v()
  else:
   pName, srvLst = CCg2Sr.VVmVGp()
   if srvLst and not srvLst == self.VVBQW6:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVBQW6 = srvLst
   else:
    force = False
  self.totalItems = len(self.VVBQW6)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVH3D8(force)
  self.VVpvgY()
 def VVsg1D(self):
  VVtZf8 = []
  VVtZf8.append(("Find Name (sorted list)" , "findSrt"  ))
  VVtZf8.append(("Find Name (as listed)" , "findNoSrt"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Change Background Color" , "VVI8JL"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Help (Keys)", "help"))
  FFd7BR(self, self.VVEgxs, title="Options", VVtZf8=VVtZf8)
 def VVEgxs(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVZOeN(True)
   elif item == "findNoSrt"   : self.VVZOeN(False)
   elif item == "VVI8JL": self.VVI8JL()
   elif item == "help"     : FF4fCC(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVZOeN(self, isSort):
  VVtZf8 = []
  for ndx, item in enumerate(self.VVBQW6):
   VVtZf8.append((item[1], ndx))
  if isSort:
   VVtZf8.sort(key=lambda x: x[0].lower())
  FFd7BR(self, self.VVsbCp, title="Find Name", VVtZf8=VVtZf8, width=1300)
 def VVsbCp(self, ndx=None):
  if ndx is not None:
   self.VVOdcZ(ndx)
 def VVBrRb(self):
  if self.shown: self.close()
  else   : self.show()
 def VV5MpZ(self, isExit):
  FFn5td(self, BF(self.VVFzfH, isExit), title="Starting ...")
 def VVFzfH(self, isExit):
  try:
   if self.shown:
    FFYeVI(self, self.VVBQW6[self.curIndex][0], VVY16B=False)
    if isExit: self.close()
    else  : CCQFZI.VVbh0Z(self.session)
   else:
    self.show()
  except:
   pass
 def VVpvgY(self, VVg3ap=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVBQW6):
    if curRef == item[0]:
     self.VVOdcZ(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VVg3ap and err:
   FFrBcM(self, err, 500)
  return -1
 def VVreOC(self):
  self.VVdwYU()
  f1, f2 = self.VVjTji()
  row = col = 0
  noPos = VVG8hM + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVBQW6[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVlyyY(lbl, name)
   path = CCjCYH.VVoKkZ(self.pPath, ref, name) or noPos
   CCmFCu.VVdN0z(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVpc7H(self):
  ref, name = self.VVBQW6[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VV6uob():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVjKXg = InfoBar.instance
  if VVjKXg:
   csel = VVjKXg.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FF4x0v(rootRef)
    refName  = FF4x0v(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVmVGp(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CCg2Sr.VV6uob()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFemXY(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCQq9Y.VVXEX3()
   pName  = CCQq9Y.VVzYiQ() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VV1sxQ(SELF):
  pName, srvLst = CCg2Sr.VVmVGp()
  if srvLst: SELF.session.open(CCg2Sr, pName, srvLst)
  else  : FFBsVa(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCQiTA(Screen, CCmFCu):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FF98gL(VVOhtp, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVBQW6    = CCQiTA.VVbv0E(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FFd98D(self, self.Title)
  FF1N71(self["keyRed"] , "OK = Start Plugin")
  FF1N71(self["keyYellow"], "Package Info.")
  FF1N71(self["keyBlue"] , "Plugins Group")
  CCmFCu.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VV3TBh   ,
   "cancel" : self.VVBrRb    ,
   "menu"  : self.VVSAxe ,
   "info"  : self.VVCn0P  ,
   "red"  : self.VVBrRb    ,
   "yellow" : BF(FFn5td, self, self.VVwqvl),
   "blue"  : self.VVWkz1  ,
   "0"   : self.VVncHi
  })
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFD5nM(self)
  FFRet2(self)
  FFwVrd(self["keyRed"], "#0a333333")
  self.VVzf0v()
  self.totalItems = len(self.VVBQW6)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVH3D8(True)
 def VVBrRb(self):
  self.close()
 def VV3TBh(self):
  name, desc = self.VV7Fo2(self.curIndex)
  if name == PLUGIN_NAME:
   FFrBcM(self, "Already running.", 500)
  else:
   try:
    p = self.VVBQW6[self.curIndex]
    p(session=self.session)
   except:
    FFBsVa(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVCn0P(self):
  def VVIsuR(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVBQW6[self.curIndex]
  txt = ""
  try:
   txt += VVIsuR("Path"  , p.path  )
   txt += VVIsuR("Description" , p.description )
   txt += VVIsuR("Icon"  , p.iconstr  )
   txt += VVIsuR("Wakeup Fnc" , p.wakeupfnc )
   txt += VVIsuR("NeedsRestart", p.needsRestart)
   txt += VVIsuR("Internal" , p.internal )
   txt += VVIsuR("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VV7Fo2(self.curIndex)
  if txt : FFVBx2(self, txt, title=name)
  else : FFBsVa(self, "Could not read plugin info.", title=name)
 def VVwqvl(self):
  p = self.VVBQW6[self.curIndex]
  name, desc = self.VV7Fo2(self.curIndex)
  path = p.path
  pkg, err = CCIU8A.VVQ68o(path)
  if pkg : CCIU8A.VVEpSl(self, pkg, name)
  else : FFQAm4(self, err, 1000)
 def VVSAxe(self):
  path = self.VVBQW6[self.curIndex].path
  VVtZf8 = []
  txt = "Open Plugin Path in File Manager"
  VVtZf8.append(FFTjqa("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Use Original Icon Size", "setOrigSize"))
  FFd7BR(self, self.VVrcKK, title="Plugins Group", VVtZf8=VVtZf8)
 def VVrcKK(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CC5iId, mode=CC5iId.VV45t5, VV0aja=self.VVBQW6[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVH3D8(True)
 def VVWkz1(self):
  FFd7BR(self, self.VVZZED, title="Plugins Group", VVtZf8=CCQiTA.VVEQkO(True, True), width=700, VVkmYm=True)
 def VVZZED(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCQiTA.VVgFf7(where)
   if lst:
    self.VVBQW6 = CCQiTA.VVbv0E(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVBQW6)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVH3D8(True)
   else:
    FFBsVa(self, "Not found !", title=self.Title)
 def VVreOC(self):
  self.VVdwYU()
  f1, f2 = self.VVjTji()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VV7Fo2(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVlyyY(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVBQW6[ndx].icon:
    try:
     pngSz = self.VVBQW6[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVBQW6[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVBQW6[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVG8hM + "plugin.png")
    for path in icons:
     pixMap = CCmFCu.VVdN0z(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VV7Fo2(self, ndx):
  name = str(self.VVBQW6[ndx].name).strip()
  desc = str(self.VVBQW6[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FFzOGe(self.VVBQW6[ndx].path)
  return name, desc
 def VVpc7H(self):
  name, desc = self.VV7Fo2(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVEQkO(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCQiTA.VVgFf7(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVUpvF, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVh3VV)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VVgFf7(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVbv0E(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FFzOGe(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVlMvE(SELF):
  title = "Plugins Browser"
  lst = CCQiTA.VVgFf7(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CCQiTA, title, lst)
  else : FFBsVa(SELF, "No plugins found !", title=title)
class CCpbsN(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FF98gL(VVL2J2, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VV2DE5  = 0
  self.VVKrPi = 1
  self.VV4gkE  = 2
  VVtZf8 = []
  VVtZf8.append(("Find in All Service (from filter)" , "VViP9h" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Find in All (Manual Entry)"   , "VVhRzZ"    ))
  VVtZf8.append(("Find in TV"       , "VVEOC0"    ))
  VVtZf8.append(("Find in Radio"      , "VVrpkU"   ))
  if self.VVGqtp():
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Hide Channel: %s" % self.servName , "VVNs2U"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Zap History"       , "VVKPNS"    ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("IPTV Tools"       , "iptv"      ))
  VVtZf8.append(("PIcons Tools"       , "PIconsTools"     ))
  VVtZf8.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVtZf8.append(("EPG Tools"       , "epgTools"     ))
  FFd98D(self, VVtZf8=VVtZf8, title=title)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self)
  if self.isFindMode:
   self.VVpr7l(self.VVUF1b())
 def VVnIt0(self):
  global VVYUMo
  VVYUMo = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVhRzZ"    : self.VVhRzZ()
   elif item == "VViP9h" : self.VViP9h()
   elif item == "VVEOC0"    : self.VVEOC0()
   elif item == "VVrpkU"   : self.VVrpkU()
   elif item == "VVNs2U"   : self.VVNs2U()
   elif item == "VVKPNS"    : self.VVKPNS()
   elif item == "iptv"       : self.session.open(CCnYqq)
   elif item == "PIconsTools"     : self.session.open(CCjCYH)
   elif item == "ChannelsTools"    : self.session.open(CC8mGp)
   elif item == "epgTools"      : self.session.open(CCNVQf)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVEOC0(self) : self.VVpr7l(self.VV2DE5)
 def VVrpkU(self) : self.VVpr7l(self.VVKrPi)
 def VVhRzZ(self) : self.VVpr7l(self.VV4gkE)
 def VVpr7l(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFsCnW(self, BF(self.VVFouj, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VViP9h(self):
  filterObj = CCmB9U(self)
  filterObj.VVoqZE(self.VVlecr)
 def VVlecr(self, item):
  self.VVFouj(self.VV4gkE, item)
 def VVGqtp(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FFAXDs(self.refCode)        : return False
  return True
 def VVFouj(self, mode, VVPkQS):
  FFn5td(self, BF(self.VVAhmb, mode, VVPkQS), title="Searching ...")
 def VVAhmb(self, mode, VVPkQS):
  if VVPkQS:
   VVPkQS = VVPkQS.strip()
  if VVPkQS:
   self.findTxt = VVPkQS
   CFG.lastFindContextFind.setValue(VVPkQS)
   if   mode == self.VV2DE5  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VVKrPi : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVPkQS)
   if len(title) > 55:
    title = title[:55] + ".."
   VVaKg1 = self.VVMVGX(VVPkQS, servTypes)
   if self.isFindMode or mode == self.VV4gkE:
    VVaKg1 += self.VVjLJ9(VVPkQS)
   if VVaKg1:
    VVaKg1.sort(key=lambda x: x[0].lower())
    VV0cge = self.VVK5qL
    VVTXLQ  = ("Zap"   , self.VVDfip    , [])
    VVIZTW = ("Current Service", self.VVch3H , [])
    VVFaAj = ("Options"  , self.VVIouX , [])
    VVZRP4 = (""    , self.VVmJJ2 , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVGQvW  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VV0cge=VV0cge, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VVZRP4=VVZRP4, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVpr7l(self.VVUF1b())
    FFx4Fl(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVMVGX(self, VVPkQS, servTypes):
  VVBQW6 = CC8mGp.VVeyFv(servTypes)
  VVaKg1 = []
  if VVBQW6:
   VVTvZo, VVNQex = FFD3Ic()
   tp = CCTy0v()
   words, asPrefix = CCmB9U.VVbRSg(VVPkQS)
   colorYellow  = CCpGRu.VV97a4(VV0V0q)
   colorWhite  = CCpGRu.VV97a4(VVDysW)
   for s in VVBQW6:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFYMB2(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVTvZo:
        STYPE = VVNQex[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVXqWF(refCode)
       if not "-S" in syst:
        sat = syst
       VVaKg1.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVaKg1
 def VVjLJ9(self, VVPkQS):
  VVPkQS = VVPkQS.lower()
  VVaKg1 = []
  colorYellow  = CCpGRu.VV97a4(VV0V0q)
  colorWhite  = CCpGRu.VV97a4(VVDysW)
  for b in CCQq9Y.VViv0F():
   VVe0gr  = b[0]
   VVIrdf  = b[1].toString()
   VVc12d = eServiceReference(VVIrdf)
   VVK7WR = FFemXY(VVc12d)
   for service in VVK7WR:
    refCode  = service[0]
    if FFAXDs(refCode):
     servName = service[1]
     if VVPkQS in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVPkQS), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVaKg1.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVaKg1
 def VVUF1b(self):
  mode = CCG0xP.VVY2KO(default=-1)
  return self.VV4gkE if mode == -1 else mode
 def VVK5qL(self, VVzzNZ):
  self.close()
  VVzzNZ.cancel()
 def VVDfip(self, VVzzNZ, title, txt, colList):
  FFYeVI(VVzzNZ, colList[2], VVY16B=False, checkParentalControl=True)
 def VVch3H(self, VVzzNZ, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(VVzzNZ)
  if refCode:
   VVzzNZ.VV2bC1(2, FFwFIz(refCode, iptvRef, chName), True)
 def VVIouX(self, VVzzNZ, title, txt, colList):
  servName = colList[0]
  mSel = CC7G9K(self, VVzzNZ)
  VVtZf8, cbFncDict = CC8mGp.VVvkl5(self, VVzzNZ, servName, 2)
  mSel.VVaknP(VVtZf8, cbFncDict)
 def VVmJJ2(self, VVzzNZ, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFqy2T(self, fncMode=CCFLza.VVxKse, refCode=refCode, chName=chName, text=txt)
 def VVNs2U(self):
  FFEN35(self, self.VVmSRw, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVmSRw(self):
  ret = FFsuwf(self.refCode, True)
  if ret:
   self.VVovJy()
   self.close()
  else:
   FFrBcM(self, "Cannot change state" , 1000)
 def VVovJy(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVj3Me()
  except:
   self.VVAhQX()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFgdxP(self, serviceRef)
 def VVj3Me(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVjKXg = InfoBar.instance
   if VVjKXg:
    VVenrc = VVjKXg.servicelist
    if VVenrc:
     hList = VVenrc.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVenrc.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVenrc.history  = newList
       VVenrc.history_pos = pos
 def VVAhQX(self):
  VVjKXg = InfoBar.instance
  if VVjKXg:
   VVenrc = VVjKXg.servicelist
   if VVenrc:
    VVenrc.history  = []
    VVenrc.history_pos = 0
 def VVKPNS(self):
  VVjKXg = InfoBar.instance
  VVaKg1 = []
  if VVjKXg:
   VVenrc = VVjKXg.servicelist
   if VVenrc:
    VVTvZo, VVNQex = FFD3Ic()
    for serv in VVenrc.history:
     refCode = serv[-1].toString()
     chName = FF4x0v(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FFAXDs(refCode)
     isSRel = FFpPAo(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFYMB2(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVTvZo:
       STYPE = VVNQex[sTypeInt]
     VVaKg1.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVaKg1:
   VVTXLQ  = ("Zap"   , self.VVL4VV   , [])
   VVFaAj = ("Clear History" , self.VV9LyM   , [])
   VVZRP4 = (""    , self.VVrSnl , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVGQvW  = (LEFT    , LEFT   , CENTER , LEFT   )
   FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=28, VVTXLQ=VVTXLQ, VVFaAj=VVFaAj, VVZRP4=VVZRP4)
  else:
   FFx4Fl(self, "History is empty.", title=title)
 def VVL4VV(self, VVzzNZ, title, txt, colList):
  FFYeVI(VVzzNZ, colList[3], VVY16B=False, checkParentalControl=True)
 def VV9LyM(self, VVzzNZ, title, txt, colList):
  FFEN35(self, BF(self.VVVHOZ, VVzzNZ), "Clear Zap History ?")
 def VVVHOZ(self, VVzzNZ):
  self.VVAhQX()
  VVzzNZ.cancel()
 def VVrSnl(self, VVzzNZ, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFqy2T(self, fncMode=CCFLza.VVz4tD, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVU4O9():
  try:
   global VV5BEv
   if VV5BEv is None:
    VV5BEv    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CCpbsN.VVyBK2
   ChannelContextMenu.VVkYCc = CCpbsN.VVkYCc
  except:
   pass
 @staticmethod
 def VVyBK2(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VV5BEv(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   for ndx, title in enumerate(("Channels Browser", "Find", "Bouquet Editor", "Channels Tools")):
    title = "%s - %s" % (PLUGIN_NAME, title)
    SELF["menu"].list.insert(ndx, ChoiceEntryComponent(key=" ", text=(title , BF(SELF.VVkYCc, csel, ndx, title))))
 @staticmethod
 def VVkYCc(SELF, csel, mode, title):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FF4x0v(refCode)
  except:
   refCode = refName = ""
  if   mode == 0: CCg2Sr.VV1sxQ(SELF)
  elif mode == 2: SELF.session.open(CCG0xP)
  else    : SELF.session.open(CCpbsN, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False)
  SELF.close()
class CCG0xP(Screen):
 def __init__(self, session, refCode="", servName=""):
  self.skin, self.skinParam = FF98gL(VVEosT, 10, 10, 30, 0, 0, "#ff000000", "#ff000000", 30)
  self.session = session
  self.Title  = "Bouquet Editor"
  self.pPath  = CCjCYH.VVzyVV()
  self.bTables = []
  FFd98D(self)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self.VVJqLZ()
 def VVcCSC(self, tbl, bName, bRef):
  self.bTables.append(tbl)
  tbl.bouqName = bName
  tbl.bouqRef  = bRef
 def VVJqLZ(self):
  rootStr = CCG0xP.VVFkOI()
  rows = self.VVgZyH(rootStr)
  if rows :
   self.VVUr38(self, "Main Bouquets List", rootStr, rows)
   refCode, refName, rootRef, rootName, inBouquet = CCg2Sr.VV6uob()
   if not self.bTables[-1].VVGQiM({3:refCode}):
    self.bTables[-1].VVGQiM({3:rootRef})
  else:
   FFBsVa(self, "No bouquets Found !", title=self.Title)
   self.close()
 def VVWGck(self):
  self.bTables[-1].cancel()
  if len(self.bTables) > 0: del self.bTables[-1]
  if not len(self.bTables): self.close()
 def VVgZyH(self, bRef=None):
  blkLst = CCG0xP.VVDCj8()
  rows = []
  for ndx, row in enumerate(FFemXY(eServiceReference(bRef), mode=1), start=1):
   ref, name, flags = row
   fTxt, fColor = CCG0xP.VVhVVs(flags)
   lck = "1" if CCG0xP.VVxOZI(ref, blkLst) > -1 else ""
   rows.append((str(ndx), "", fColor + name, ref, fTxt, str(flags), lck))
  return rows
 def VVUr38(self, selfObj, bName, bRef, rows):
  totTbl = len(self.bTables)
  title = {0:"Main Bouquets List", 1:"%s %s" % (FFxrb0("Fav: ", VVUpvF), bName), 2:"%s %s" % (FFxrb0("Sub: ", VVUpvF), bName)}.get(totTbl, bName)
  bg  = {0:"#11002233", 1:"#0a112222"}.get(totTbl, "#0a131111")
  VV0cge = self.VVdK9o
  VVZRP4 = (""    , self.VVaoGB  , [])
  VVTXLQ  = ("Enter Bouquet" , self.VVFFW8 , [])
  VVXfC8 = ("Delete"   , self.VVfXih , [])
  VVFaAj = ("Options"  , self.VVtnAF , [])
  VV6CVp = ("Move Here"  , self.VVmYUe , [])
  picParams  = (1, self.VV5JJP, None)
  widths  = (12   , 7   , 81 , 0  , 0   , 0   , 0   )
  VVGQvW = (CENTER  , CENTER , LEFT , LEFT , LEFT  , CENTER , CENTER )
  tbl = FFuI68(self, None, title=title, VVBQW6=rows, VVGQvW=VVGQvW, width=1500, height=1000, VV3FCq=widths, VVJgEp=28, addSort=False, VVZRP4=VVZRP4, VVTXLQ=VVTXLQ, VV0cge=VV0cge, VVXfC8=VVXfC8, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VV3cto=True, searchCol=1, picParams=picParams, lastFindConfigObj=CFG.lastFindServices
     , VVRmfT=bg, VVRNJt=bg, VV84wP=bg, VVvmBM="#0a442200", borderWidth=0, VViJnU="#11330000")
  tbl.VVLx7i(BF(self.VVnXqM, tbl), True)
  self.VVcCSC(tbl, bName, bRef)
 def VV2HRA(self, VVzzNZ, mutableList, tot, jumpDict=None):
  if tot:
   if mutableList:
    mutableList.flushChanges()
   FFOnqc()
   rows = self.VVgZyH(VVzzNZ.bouqRef)
   if rows:
    VVzzNZ.VVPvaS(False)
    VVzzNZ.VV311O(rows, VV3PMMMsg=True, isSort=False, tableRefreshCB=BF(self.VVpT0t, jumpDict))
   else:
    self.VVWGck()
    totTbl = len(self.bTables)
    FFrBcM(self.bTables[-1] if totTbl > 0 else self, "Empty List !", 1500)
  else:
   FFQAm4(VVzzNZ, "No change !", 1500)
 def VVpT0t(self, jumpDict, VVzzNZ, title, txt, colList):
  if jumpDict:
   VVzzNZ.VVGQiM(jumpDict)
 def VVnXqM(self, VVzzNZ):
  VVzzNZ["keyRed"].hide()
  VVzzNZ["keyBlue"].hide()
  if VVzzNZ.VVoCEo:
   if VVzzNZ.VVRFlF() > 0:
    VVzzNZ["keyRed"].show()
    VVzzNZ["keyBlue"].show()
  else:
   VVzzNZ["keyRed"].show()
 def VVaoGB(self, VVzzNZ, title, txt, colList):
  c1, c2, c3 = VV0V0q, VVTVZG, VVmxw7
  ttl = lambda x, y, color=c1: "%s:\n%s\n\n" % (FFxrb0(x, color), y) if y else ""
  num, picon, name, ref, rem, flags, lck = colList
  path = CCG0xP.VVoHJp(ref, mode=1)
  txt  = ttl("Name"    , name)
  txt += ttl("Bouquet File"  , path if path.startswith("/") else "")
  txt += ttl("Parent Bouquet"  , VVzzNZ.bouqName, c2)
  txt += ttl("Parent Bouquet File", CCG0xP.VVoHJp(VVzzNZ.bouqRef, mode=1), c2)
  txt += ttl("Ref."    , ref, c3) if VVNHHG else ""
  txt += ttl("Remarks"   , rem, c3) if VVNHHG else ""
  path = CCjCYH.VVoKkZ(self.pPath, ref, name)
  FFqy2T(self, fncMode=CCFLza.EPG_MODE_BOUQUET_EDITOR, text=txt, picPath=path)
 def VVFFW8(self, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VVZe1y, VVzzNZ, colList) )
 def VVZe1y(self, VVzzNZ, colList):
  maxLev = 2
  num, picon, name, ref, rem, flags, lck = colList
  if "FROM BOUQUET " in ref:
   if len(self.bTables) <= maxLev:
    rows = self.VVgZyH(ref)
    if rows : self.VVUr38(VVzzNZ, name, ref, rows)
    else : FFQAm4(VVzzNZ, "Empty list !", 1500)
   else:
    FFBsVa(self, "Maximum Level of Recursive Bouquets (%d) !" % maxLev, title=self.Title)
  elif CCG0xP.VVatVM(ref) == 0:
   FFYeVI(self, ref, VVY16B=False)
   FFZMMj(self, "Cancel to go back to table")
  else:
   FFrBcM(VVzzNZ, "No action", 300)
 def VVdK9o(self, VVzzNZ):
  if VVzzNZ.VVoCEo:
   VVzzNZ.VVPvaS(False)
   self.VVnXqM(VVzzNZ)
  else:
   self.VVWGck()
 def VVtnAF(self, VVzzNZ, title, txt, colList):
  VVtZf8 = []
  iMulSel = VVzzNZ.VVFPwr()
  sortItem = ("Sort", )
  if iMulSel:
   tot = VVzzNZ.VVRFlF()
   if tot > 1: sortItem = ("Sort", "sort")
   isSel = tot > 0
   bTxt = "Bouquet%s" % FFAHjU(tot)
  else:
   isSel = True
   bTxt = "Bouquet"
  inMain = len(self.bTables) == 1
  VVtZf8.append(FFTjqa("Rename"   , "renm" , not iMulSel))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(FFTjqa("Add Marker"  , "mrkr" , not iMulSel))
  VVtZf8.append(FFTjqa("Add Empty Bouquet", "addBouq" , not iMulSel and inMain))
  if inMain:
   VVtZf8.append(VVh3VV)
   VVtZf8.append(FFTjqa("Hide %s" % bTxt , "hidOn" , isSel))
   VVtZf8.append(FFTjqa("Unhide %s" % bTxt , "hidOff" , isSel))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(FFTjqa("Protect %s" % bTxt , "lckOn" , isSel))
   VVtZf8.append(FFTjqa("Unprotect %s" % bTxt , "lckOff" , isSel))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(sortItem)
  VVtZf8.append(FFTjqa("Copy to Bouquet" , "toBouq" , isSel))
  cbFncDict = { "renm" : BF(self.VVzOie  , VVzzNZ)
     , "mrkr" : BF(self.VVX6Ux , VVzzNZ)
     , "addBouq" : BF(self.VVnaA7, VVzzNZ)
     , "hidOn" : BF(self.VVOj6J  , VVzzNZ, True)
     , "hidOff" : BF(self.VVOj6J  , VVzzNZ, False)
     , "lckOn" : BF(self.VV4iDH  , VVzzNZ, True)
     , "lckOff" : BF(self.VV4iDH  , VVzzNZ, False)
     , "sort" : BF(self.VVPbrA  , VVzzNZ)
     , "toBouq" : BF(self.VVoCPG , VVzzNZ) }
  fnc = BF(self.VVnXqM, VVzzNZ)
  mSel = CC7G9K(self, VVzzNZ)
  mSel.VVaknP(VVtZf8, cbFncDict, okFnc=fnc, onMultiSelFnc=fnc)
 def VVfXih(self, VVzzNZ, title, txt, colList):
  txt, totSel = "", 0
  if VVzzNZ.VVFPwr():
   totSel = VVzzNZ.VVRFlF()
   if totSel:
    txt = "Delete %s item%s" % (FFxrb0(str(totSel), VV0V0q), FFAHjU(totSel))
  else:
   num, picon, name, ref, rem, flags, lck = colList
   txt = "Delete : %s" % FFxrb0(name, VV0V0q)
  if txt:
   FFEN35(self, BF(self.VVjfxC, VVzzNZ), "%s\n\nContinue ?" % txt, title=self.Title)
 def VVjfxC(self, VVzzNZ):
  FFn5td(VVzzNZ, BF(self.VV3QUp, VVzzNZ))
 def VV3QUp(self, VVzzNZ):
  lst, mutableList, csel, bServ = self.VV9GWr(VVzzNZ)
  if mutableList is not None:
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.removeService(serv):
     tot += 1
     bFile = CCQq9Y.VV9zDX(ref)
     if "userSubBouquet" in bFile:
      bFile = VV7aeL + bFile
      FFkQDN("rm -f '%s' '%s.del'" % (bFile, bFile))
   self.VV2HRA(VVzzNZ, mutableList, tot)
 def VVmYUe(self, VVzzNZ, title, txt, colList):
  FFn5td(VVzzNZ, BF(self.VVU4h8, VVzzNZ))
 def VVU4h8(self, VVzzNZ):
  lst, mutableList, csel, bServ = self.VV9GWr(VVzzNZ)
  if mutableList is not None:
   curNdx = VVzzNZ.VVXRaz()
   if curNdx <= VVzzNZ.VVJlmL(): lst = reversed(lst)
   else             : curNdx -= 1
   tot = 0
   for ref in lst:
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VV2HRA(VVzzNZ, mutableList, tot)
 def VVPbrA(self, VVzzNZ):
  FFn5td(VVzzNZ, BF(self.VVTp5p, VVzzNZ))
 def VVTp5p(self, VVzzNZ):
  lst, mutableList, csel, bServ = self.VV9GWr(VVzzNZ)
  if mutableList is not None:
   nmlst = VVzzNZ.VVXAfG(2)
   lst = list(zip(nmlst, lst))
   lst.sort(key=lambda x: x[0].lower())
   curNdx = VVzzNZ.VVJlmL()
   tot = 0
   for name, ref in reversed(lst):
    serv = eServiceReference(ref)
    if serv.valid() and not mutableList.moveService(serv, curNdx):
     tot += 1
   self.VV2HRA(VVzzNZ, mutableList, tot)
 def VVzOie(self, VVzzNZ, item=None):
  name = VVzzNZ.VVQ0F0()[2]
  FFsCnW(self, BF(self.VV4yPf, VVzzNZ), defaultText=name, title="Rename", message="Enter new name")
 def VV4yPf(self, VVzzNZ, name):
  lst, mutableList, csel, bServ = self.VV9GWr(VVzzNZ)
  if name and csel and mutableList:
   name = name.strip()
   if name:
    ref = VVzzNZ.VVQ0F0()[3]
    if "FROM BOUQUET " in ref:
     CCQq9Y.VV2YUz(ref, name)
    else:
     serv = eServiceReference(ref)
     if serv.valid():
      serv.setName(name)
      mutableList.removeService(serv)
      mutableList.addService(serv)
      mutableList.moveService(serv, VVzzNZ.VVXRaz())
    self.VV2HRA(VVzzNZ, mutableList, 1)
 def VVX6Ux(self, VVzzNZ):
  name = "%s Marker %s" % ("=" * 7, "=" * 7)
  FFn5td(VVzzNZ, BF(self.VVPFIB, VVzzNZ, name))
 def VVPFIB(self, VVzzNZ, name):
  lst, mutableList, csel, bServ = self.VV9GWr(VVzzNZ)
  if mutableList is not None:
   curServ = eServiceReference(VVzzNZ.VVQ0F0()[3])
   cnt = tot = 0
   while mutableList:
    serv = eServiceReference("1:64:%d:0:0:0:0:0:0:0::%s" % (cnt, name))
    if curServ and curServ.valid():
     if not mutableList.addService(serv, curServ):
      csel.servicelist.addService(serv, True)
      tot += 1
      break
    elif not mutableList.addService(serv):
     csel.servicelist.addService(serv, True)
     tot += 1
     break
    cnt += 1
   self.VV2HRA(VVzzNZ, mutableList, tot)
 def VVnaA7(self, VVzzNZ):
  names = VVzzNZ.VVtIX5(2)
  name = "Bouquet-1"
  num = 0
  while name in names:
   num += 1
   name = "Bouquet-%s" % num
  FFsCnW(self, BF(self.VVxKg6, VVzzNZ), defaultText=name, title="New Bouquet", message="Enter Bouquet name")
 def VVxKg6(self, VVzzNZ, name=None):
  if name and name.strip():
   FFn5td(VVzzNZ, BF(self.VVsppk, VVzzNZ, name.strip()))
 def VVsppk(self, VVzzNZ, bName):
  CCQq9Y.VVYjPl(bName)
  self.VV2HRA(VVzzNZ, None, 1, jumpDict={2:bName})
 def VVoCPG(self, VVzzNZ):
  bRows = CCQq9Y.VVplok()
  if VVzzNZ.VVoCEo : lst = VVzzNZ.VVXAfG(3)
  else        : lst = [VVzzNZ.VVQ0F0()[3]]
  VVtZf8 = []
  for name, ref in bRows:
   if not ref in lst:
    VVtZf8.append((name, ref))
  if VVtZf8 : FFd7BR(self,  BF(self.VVyMpW, VVzzNZ), VVtZf8=VVtZf8, width=1100, height=900, VVRmfT="#22220000", VVRNJt="#22110000", title="Destination Bouquet", VVkmYm=True)
  else  : FFrBcM(VVzzNZ, "No bouquets left !", 1000)
 def VVyMpW(self, VVzzNZ, item=None):
  if item:
   bName, bRef, ndx = item
   FFn5td(VVzzNZ, BF(self.VVWs3T, VVzzNZ, bName, bRef))
 def VVWs3T(self, VVzzNZ, bName, bRef):
  if VVzzNZ.VVoCEo : lst = VVzzNZ.VVXAfG(3)
  else        : lst = [VVzzNZ.VVQ0F0()[3]]
  dstFile = CCQq9Y.VV9zDX(bRef)
  tot = 0
  for ref in lst:
   ok = CCQq9Y.VVQbIy(ref, dstFile)
   if ok:
    tot += 1
  self.VV2HRA(VVzzNZ, None, tot)
  ttl = lambda x, y: "%s:\n%s\n\n" % (FFxrb0(x, VVwwau), y)
  txt  = ttl("Source Bouquet"  , VVzzNZ.bouqName)
  txt += ttl("Destination Bouquet", bName)
  txt += ttl("Copied Services" , tot)
  FFVBx2(VVzzNZ, txt, title="Copy Services")
 def VVOj6J(self, VVzzNZ, isHide):
  FFn5td(VVzzNZ, BF(self.VVk5aw, VVzzNZ, isHide))
 def VVk5aw(self, VVzzNZ, isHide):
  lst, mutableList, csel, bServ = self.VV9GWr(VVzzNZ)
  mode = CCG0xP.VVY2KO()
  path = VV7aeL + "bouquets.%s" % ("tv" if mode==0 else "radio")
  if fileExists(path):
   tot = 0
   lines = list(map(str.strip, FFMy5k(path)))
   for ref in lst:
    if "FROM BOUQUET " in ref:
     ref = "#SERVICE " + ref
     nrm = ref.replace("1:519:", "1:7:")
     hid = ref.replace("1:7:"  , "1:519:")
     if isHide: r1, r2 = nrm, hid
     else  : r1, r2 = hid, nrm
     if r1 in lines:
      ndx = lines.index(r1)
      lines[ndx] = r2
      tot += 1
   if tot:
    with open(path, "w") as f:
     for line in lines:
      f.write("%s\n" % line)
    self.VV2HRA(VVzzNZ, None, tot)
 def VV4iDH(self, VVzzNZ, isLck):
  FFn5td(VVzzNZ, BF(self.VV2jQv, VVzzNZ, isLck))
 def VV2jQv(self, VVzzNZ, isLck):
  lst, mutableList, csel, bServ = self.VV9GWr(VVzzNZ)
  blkLst = CCG0xP.VVDCj8()
  tot = 0
  for ref in lst:
   if "FROM BOUQUET " in ref:
    ndx = CCG0xP.VVxOZI(ref, blkLst)
    if isLck:
     if ndx == -1:
      ref = ref.replace("1:519:", "1:0:").replace("1:7:", "1:0:")
      blkLst.append(ref)
      tot += 1
    else:
     if ndx > -1:
      blkLst[ndx] = ""
      tot += 1
  if tot:
   with open(VVhrYS, "w") as f:
    for line in blkLst:
     if line.strip():
      f.write("%s\n" % line)
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   self.VV2HRA(VVzzNZ, None, tot)
 def VV9GWr(self, VVzzNZ, bServ=None):
  if VVzzNZ.VVoCEo : lst = VVzzNZ.VVXAfG(3)
  else        : lst = [VVzzNZ.VVQ0F0()[3]]
  mutableList = csel = None
  VVjKXg = InfoBar.instance
  if VVjKXg:
   csel = VVjKXg.servicelist
   if csel:
    if not bServ:
     bServ = eServiceReference(VVzzNZ.bouqRef)
    if bServ.valid():
     mutableList = csel.getMutableList(bServ)
  return lst,  mutableList, csel, bServ
 def VV5JJP(self, colList):
  num, picon, name, ref, rem, flags, lck = colList
  png = lambda x: "%s%s.png" % (VVG8hM, x)
  if   rem == "Marker"   : return png("mrk1")
  elif rem == "Numbered Marker" : return png("mrk2")
  elif rem == "Group"    : return png("grp")
  elif "FROM BOUQUET " in ref:
   if   lck == "1" and rem == "Invisible" : return png("dirLckInvis")
   elif lck == "1"       : return png("dirLck")
   elif rem == "Invisible"     : return png("dirInvis")
   else         : return png("dir1")
  else:
   return CCjCYH.VVoKkZ(self.pPath, ref, name)
 @staticmethod
 def VVhVVs(flag):
  t = c = ""
  try:
   if   flag & eServiceReference.isInvisible  : t, c = "Invisible"  , "#f#00ff7722#"
   elif flag & eServiceReference.FFty8YedMarker : t, c = "Numbered Marker" , "#f#00ffffaa#"
   elif flag & eServiceReference.isGroup   : t, c = "Group"   , "#f#00bbffbb#"
   elif flag & eServiceReference.isMarker   : t, c = "Marker"   , "#f#00ffffaa#"
   elif flag & eServiceReference.isDirectory  : t, c = "Directory"  , ""
  except:
   pass
  return t, c
 @staticmethod
 def VVoHJp(ref, mode=0):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   path = serv.getPath()
   if path and not VVNHHG:
    path = iSub(r"[&?]mode=.+end=", r"", path, flags=IGNORECASE)
   if mode == 1:
    span = iSearch(r'FROM\s+BOUQUET\s+"(.+)"\s+ORDER\s+BY\s+bouquet', path, IGNORECASE)
    if span:
     path = VV7aeL + span.group(1)
  return path
 @staticmethod
 def VVatVM(ref):
  path = ""
  serv = eServiceReference(ref)
  if serv.valid():
   return serv.flags
  return -1
 @staticmethod
 def VVY2KO(default=0):
  VVjKXg = InfoBar.instance
  if VVjKXg:
   csel = VVjKXg.servicelist
   if csel:
    return csel.mode
  return default
 @staticmethod
 def VVFkOI():
  VVjKXg = InfoBar.instance
  if VVjKXg:
   csel = VVjKXg.servicelist
   if csel:
    return csel.bouquet_rootstr
  return ""
 @staticmethod
 def VVDCj8():
  return FFMy5k(VVhrYS) if fileExists(VVhrYS) else []
 @staticmethod
 def VVxOZI(ref, lst=None):
  if not lst:
   lst = CCG0xP.VVDCj8()
  if "FROM BOUQUET " in ref:
   ref1 = ref.replace("1:7:", "1:0:")
   ref2 = ref.replace("1:519:", "1:0:")
   if   ref1 in lst: return lst.index(ref1)
   elif ref2 in lst: return lst.index(ref2)
  return -1
class CCjCYH(Screen, CCmFCu, CCSaYR):
 VVDwje   = 0
 VVM7DQ  = 1
 VVQxrF  = 2
 VVcvFF  = 3
 VVh9In  = 4
 VVJV1Z  = 5
 VV0o8V  = 6
 VV9hVA  = 7
 VVspaD = 8
 VVaru6 = 9
 VVZGOn = 10
 VVEmub = 11
 def __init__(self, session):
  self.skin, self.skinParam = FF98gL(VVAccY, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCjCYH.VVzyVV()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVBQW6    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFd98D(self, self.Title)
  FF1N71(self["keyRed"] , "OK = Zap")
  FF1N71(self["keyGreen"] , "Current Service")
  FF1N71(self["keyYellow"], "Page Options")
  FF1N71(self["keyBlue"] , "Filter")
  CCmFCu.__init__(self, 5, 7, CFG.transpColorPicons)
  CCSaYR.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVCTmK     ,
   "green"  : self.VVu0Uk    ,
   "yellow" : self.VVeG6w     ,
   "blue"  : self.VVcOKe     ,
   "menu"  : self.VVdtU4     ,
   "info"  : self.VVn1XH    ,
   "pageUp" : BF(self.VV1km8, True) ,
   "chanUp" : BF(self.VV1km8, True) ,
   "pageDown" : BF(self.VV1km8, False) ,
   "chanDown" : BF(self.VV1km8, False) ,
   "0"   : self.VVncHi  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFD5nM(self)
  FFRet2(self)
  FFwVrd(self["keyRed"], "#0a333333")
  self.VVzf0v()
  FFn5td(self, BF(self.VV3M85, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVdtU4(self):
  if not self.isBusy:
   VVtZf8 = []
   VVtZf8.append(("Statistics"           , "VVrwgb"    ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Suggest PIcons for Current Channel"     , "VVKiGT"   ))
   VVtZf8.append(("Set to Current Channel (copy file)"     , "VVMAW6_file"  ))
   VVtZf8.append(("Set to Current Channel (as SymLink)"     , "VVMAW6_link"  ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Export Current File Names List"      , "VVkCf5" ))
   VVtZf8.append(CCjCYH.VV3lz6())
   VVtZf8.append(VVh3VV)
   c, cond = VVD46d, self.filterTitle == "PIcons without Channels"
   VVtZf8.append(FFTjqa("Move Unused PIcons to a Directory", "VV0Qi7" , cond, c))
   VVtZf8.append(FFTjqa("DELETE Unused PIcons"    , "VV6JNl" , cond, c))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VVhWCV"  ))
   VVtZf8.append(VVh3VV)
   VVtZf8 += CCjCYH.VV1qZ7()
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Change Poster/Picon Transparency Color"    , "VVI8JL" ))
   VVtZf8.append(("Keys Help"           , "VVmXPH"    ))
   FFd7BR(self, self.VVUurL, width=1100, height=1050, title=self.Title, VVtZf8=VVtZf8)
 def VVUurL(self, item=None):
  if item is not None:
   if   item == "VVrwgb"    : self.VVrwgb()
   elif item == "VVKiGT"   : self.VVKiGT()
   elif item == "VVMAW6_file"  : self.VVMAW6(0)
   elif item == "VVMAW6_link"  : self.VVMAW6(1)
   elif item == "VVkCf5"  : self.VVkCf5()
   elif item == "VVo4uj"  : CCjCYH.VVo4uj(self)
   elif item == "VV0Qi7"   : self.VV0Qi7()
   elif item == "VV6JNl"  : self.VV6JNl()
   elif item == "VVhWCV"  : self.VVhWCV()
   elif item == "VVz7Fg"  : CCjCYH.VVz7Fg(self)
   elif item == "findPiconBrokenSymLinks" : CCjCYH.VV1Jui(self, True)
   elif item == "FindAllBrokenSymLinks" : CCjCYH.VV1Jui(self, False)
   elif item == "VVI8JL" : self.VVI8JL()
   elif item == "VVmXPH"     : FF4fCC(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVeG6w(self):
  if not self.isBusy:
   VVtZf8 = []
   VVtZf8.append(("Go to First PIcon"  , "VVEln9"  ))
   VVtZf8.append(("Go to Last PIcon"   , "VVagdB"  ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Sort by Channel Name"     , "sortByChan" ))
   VVtZf8.append(("Sort by File Name"  , "sortByFile" ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Find from File List .." , "VV0U4z" ))
   FFd7BR(self, self.VVphGA, title=self.Title, VVtZf8=VVtZf8)
 def VVphGA(self, item=None):
  if item is not None:
   if   item == "VVEln9"   : self.VVEln9()
   elif item == "VVagdB"   : self.VVagdB()
   elif item == "sortByChan"  : self.VVn9Dx(2)
   elif item == "sortByFile"  : self.VVn9Dx(0)
   elif item == "VV0U4z"  : self.VV0U4z()
 def VV0U4z(self):
  VVtZf8 = []
  for item in self.VVBQW6:
   VVtZf8.append((item[0], item[0]))
  FFd7BR(self, self.VVdbc4, title='PIcons ".png" Files', VVtZf8=VVtZf8, VVkmYm=True)
 def VVdbc4(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVOdcZ(ndx)
 def VVCTmK(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VV5PHI()
   if refCode:
    FFYeVI(self, refCode)
    self.VVu8r2()
    self.VVpc7H()
 def VV1km8(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVu8r2()
   self.VVpc7H()
  except:
   pass
 def VVu0Uk(self):
  if self["keyGreen"].getVisible():
   self.VVOdcZ(self.curChanIndex)
 def VVn9Dx(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFn5td(self, BF(self.VV3M85, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVMAW6(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VV5PHI()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVtZf8 = []
     VVtZf8.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVtZf8.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFd7BR(self, BF(self.VVvNgd, mode, curChF, selPiconF), VVtZf8=VVtZf8, title="Current Channel PIcon (already exists)")
    else:
     self.VVvNgd(mode, curChF, selPiconF, "overwrite")
   else:
    FFBsVa(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFBsVa(self, "Could not read current channel info. !", title=title)
 def VVvNgd(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFkQDN(cmd)
   FFn5td(self, BF(self.VV3M85, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VV0Qi7(self):
  defDir = FF9GYH(CCjCYH.VVzyVV() + "picons_backup")
  FFkQDN("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VV9Ya0, defDir), BF(CC5iId
         , mode=CC5iId.VVtux5, VV0aja=CCjCYH.VVzyVV()))
 def VV9Ya0(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCjCYH.VVzyVV():
    FFBsVa(self, "Cannot move to same directory !", title=title)
   else:
    if not FF9GYH(path) == FF9GYH(defDir):
     self.VVEMam(defDir)
    FFEN35(self, BF(FFn5td, self, BF(self.VV9kBz, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVBQW6), path), title=title)
  else:
   self.VVEMam(defDir)
 def VV9kBz(self, title, defDir, toPath):
  if not iMove:
   self.VVEMam(defDir)
   FFBsVa(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FF9GYH(toPath)
  pPath = CCjCYH.VVzyVV()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVBQW6:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVBQW6)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FFVBx2(self, txt, title=title, VV84wP="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VVS6Yc("all")
 def VVEMam(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VV6JNl(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVBQW6)
  FFEN35(self, BF(FFn5td, self, BF(self.VVKc4Q, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FFAHjU(tot)), title=title)
 def VVKc4Q(self, title):
  pPath = CCjCYH.VVzyVV()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVBQW6:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVBQW6)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFxrb0(str(totErr), VVmxw7)
  FFVBx2(self, txt, title=title)
 def VVhWCV(self):
  lines = FFIM7p("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFEN35(self, BF(self.VVTghn, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FFAHjU(tot)), VV00ww=True)
  else:
   FFx4Fl(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVTghn(self, fList):
  FFkQDN("find -L '%s' -type l -delete" % self.pPath)
  FFx4Fl(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VVn1XH(self):
  FFn5td(self, self.VVUyxz)
 def VVUyxz(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VV5PHI()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFxrb0("PIcon Directory:\n", VVTVZG)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFpoSU(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFpoSU(path)
   txt += FFxrb0("PIcon File:\n", VVTVZG)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFxrb0("Found %d SymLink%s to this file from:\n" % (tot, FFAHjU(tot)), VVTVZG)
     for fPath in slLst:
      txt += "  %s\n" % FFxrb0(fPath, VVUpvF)
     txt += "\n"
   if chName:
    txt += FFxrb0("Channel:\n", VVTVZG)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFxrb0(chName, VVCKEk)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFxrb0("Remarks:\n", VVTVZG)
    txt += "  %s\n" % FFxrb0("Unused", VVmxw7)
  else:
   txt = "No info found"
  FFqy2T(self, fncMode=CCFLza.VV4oHx, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VV5PHI(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVBQW6[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FF9eBo(sat)
  return fName, refCode, chName, sat, inDB
 def VVu8r2(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVBQW6):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVpc7H(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VV5PHI()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFxrb0("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVTVZG))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VV5PHI()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFpPAo(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFxrb0(self.curChanName, VV0V0q)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VV5PHI()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVrwgb(self):
  VVTvZo, VVNQex = FFD3Ic()
  sTypeNameDict = {}
  for key, val in VVNQex.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVBQW6:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVNQex: sTypeDict[VVNQex[stNum]] = sTypeDict.get(VVNQex[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FFz86l("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVaKg1 = []
  c = "#b#11003333#"
  VVaKg1.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVaKg1.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVaKg1.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVaKg1.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVaKg1.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVaKg1.append((c + "Satellites"    , str(len(self.nsList))))
  VVaKg1.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVaKg1.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVaKg1.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVaKg1.extend(sTypeRows)
  FFuI68(self, None, title=self.Title, VVBQW6=VVaKg1, VVJgEp=28, VVvmBM="#00003333", VVfpy3="#00222222")
 def VVkCf5(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FF9GYH(CFG.exportedTablesPath.getValue()), txt, FF0Isj())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVBQW6:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FFx4Fl(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVcOKe(self):
  if not self.isBusy:
   VVtZf8 = []
   VVtZf8.append(("All"        , "all"  ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Used by Channels"     , "used" ))
   VVtZf8.append(("Unused PIcons"     , "unused" ))
   VVtZf8.append(("IPTV PIcons"      , "iptv" ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("PIcons Files"      , "pFiles" ))
   VVtZf8.append(("SymLinks to PIcons"    , "pLinks" ))
   VVtZf8.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVtZf8.append(("By Files Date ..."    , "pDate" ))
   VVtZf8.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVtZf8.append(FFbAzs("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFxluq(val)
      VVtZf8.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCmB9U(self)
   filterObj.VVR4AM(VVtZf8, self.nsList, self.VV897Q)
 def VV897Q(self, item=None):
  if item is not None:
   self.VVS6Yc(item)
 def VVS6Yc(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VVDwje   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVM7DQ   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVQxrF  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VV0o8V   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVcvFF  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVh9In  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVJV1Z  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVZGOn , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVEmub , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VV9hVA   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVspaD , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVJV1Z:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFIM7p("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FFzOGe(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FFrBcM(self, "Not found", 1000)
     return
   elif mode == self.VVZGOn:
    self.VVUBPE(mode)
    return
   elif mode == self.VVEmub:
    self.VVxxfm(mode)
    return
   elif mode == self.VVaru6:
    return
   else:
    words, asPrefix = CCmB9U.VVbRSg(words)
   if not words and mode in (self.VV9hVA, self.VVspaD):
    FFrBcM(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFn5td(self, BF(self.VV3M85, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVUBPE(self, mode):
  VVtZf8 = []
  VVtZf8.append(("Today"   , "today" ))
  VVtZf8.append(("Since Yesterday" , "yest" ))
  VVtZf8.append(("Since 7 days"  , "week" ))
  FFd7BR(self, BF(self.VVKTkB, mode), VVtZf8=VVtZf8, title="Filter by Added/Modified Date")
 def VVKTkB(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFFvsp(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFFvsp(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFFvsp(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFn5td(self, BF(self.VV3M85, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVxxfm(self, mode):
  VVTvZo, VVNQex = FFD3Ic()
  lst = set()
  for key, val in VVNQex.items():
   lst.add(val)
  VVtZf8 = []
  for item in lst:
   VVtZf8.append((item, item))
  VVtZf8.sort(key=lambda x: x[0])
  FFd7BR(self, BF(self.VVezKg, mode), VVtZf8=VVtZf8, title="Filter by Service Type")
 def VVezKg(self, mode, item=None):
  if item:
   VVTvZo, VVNQex = FFD3Ic()
   sTypeList = []
   for key, val in VVNQex.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFn5td(self, BF(self.VV3M85, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVKiGT(self):
  self.session.open(CCIpg5, barTheme=CCIpg5.VVipyP
      , titlePrefix = ""
      , fncToRun  = self.VViqqL
      , VVqhY7 = self.VVRLtS)
 def VViqqL(self, VVomkw):
  VVmC3N, err = CC8mGp.VV8K3y(self, CC8mGp.VVGe9h, VV0VUr=False, VVO4lq=False)
  files = []
  words = []
  if not VVomkw or VVomkw.isCancelled:
   return
  VVomkw.VV6uui = []
  VVomkw.VVITUK(len(VVmC3N))
  if VVmC3N:
   curCh = self.VVuSnO(self.curChanName)
   for refCode in VVmC3N:
    if not VVomkw or VVomkw.isCancelled:
     return
    VVomkw.VVReKT(1, True)
    chName, sat, inDB = VVmC3N.get(refCode, ("", "", 0))
    ratio = CCjCYH.VVIgwL(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCjCYH.VVzl1J(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FFzOGe(f)
       fil = f.replace(".png", "")
       if not fil in VVomkw.VV6uui:
        VVomkw.VV6uui.append(fil)
 def VVRLtS(self, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  if VV6uui : FFn5td(self, BF(self.VV3M85, mode=self.VVaru6, words=VV6uui), title="Loading ...")
  else   : FFrBcM(self, "Not found", 2000)
 def VV3M85(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVIDzD(isFirstTime):
   return
  self.isBusy = True
  VVO4lq = True if isFirstTime else False
  VVmC3N, err = CC8mGp.VV8K3y(self, CC8mGp.VVGe9h, VV0VUr=False, VVO4lq=VVO4lq)
  if err:
   self.close()
  iptvRefList = self.VVNrYQ()
  tList = []
  for fName, fType in CCjCYH.VVBQXo(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVmC3N:
    if fName in VVmC3N:
     chName, sat, inDB = VVmC3N.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VVDwje:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVM7DQ  and chName         : isAdd = True
   elif mode == self.VVQxrF and not chName        : isAdd = True
   elif mode == self.VVcvFF  and fType == 0        : isAdd = True
   elif mode == self.VVh9In  and fType == 1        : isAdd = True
   elif mode == self.VVJV1Z  and fName in words       : isAdd = True
   elif mode == self.VVaru6 and fName in words       : isAdd = True
   elif mode == self.VV0o8V  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VV9hVA  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVspaD:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVZGOn:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVEmub:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVBQW6   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FFrBcM(self)
  else:
   self.isBusy = False
   FFrBcM(self, "Not found", 1000)
   return
  self.VVBQW6.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVu8r2()
  self.totalItems = len(self.VVBQW6)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVH3D8(True)
 def VVIDzD(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCjCYH.VVBQXo(self.pPath):
    if fName:
     return True
   if isFirstTime : FFBsVa(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FFrBcM(self, "Not found", 1000)
  else:
   FFBsVa(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVNrYQ(self):
  VVaKg1 = {}
  files  = CCnYqq.VVQk0n()
  if files:
   for path in files:
    txt = FFl3Sc(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVaKg1[refCode] = item[1]
  return VVaKg1
 def VVreOC(self):
  self.VVdwYU()
  f1, f2 = self.VVjTji()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVBQW6[ndx]
   fName = self.VVBQW6[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCmFCu.VVdN0z(pic, path) : color = VVCKEk if inDB else ""
   elif not chName           : color = ""
   else             : color = VVDF46
   self.VVlyyY(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VVIgwL(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV3lz6():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVo4uj")
 @staticmethod
 def VV1qZ7():
  VVtZf8 = []
  VVtZf8.append(("Find SymLinks (to PIcon Directory)"   , "VVz7Fg"  ))
  VVtZf8.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVtZf8.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVtZf8
 @staticmethod
 def VVo4uj(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(SELF)
  png, path = CCjCYH.VVGM2o(refCode)
  if path : CCjCYH.VV1LRy(SELF, png, path)
  else : FFBsVa(SELF, "No PIcon found for current channel in:\n\n%s" % CCjCYH.VVzyVV())
 @staticmethod
 def VVz7Fg(SELF):
  if VV0V0q:
   sed1 = FFPk5q("->", VV0V0q)
   sed2 = FFPk5q("picon", VVmxw7)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VVDF46, VVDysW)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFxN9O(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFwS2p(), grep, sed1, sed2, sed3))
 @staticmethod
 def VV1Jui(SELF, isPIcon):
  sed1 = FFPk5q("->", VVDF46)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFPk5q("picon", VVmxw7)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFxN9O(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFwS2p(), grep, sed1, sed2))
 @staticmethod
 def VV1LRy(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFPk5q("%s%s" % (dest, png), VVCKEk))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFPk5q(errTxt, VVKRbh))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FFlHGt(SELF, cmd)
 @staticmethod
 def VVBQXo(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VVzyVV():
  path = CFG.PIconsPath.getValue()
  return FF9GYH(path)
 @staticmethod
 def VVGM2o(refCode, chName=None):
  if FFAXDs(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFR5dT(refCode)
  allPath, fName, refCodeFile, pList = CCjCYH.VVzl1J(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVoKkZ(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CCnYqq.VVBUYw():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFpnOy(chName)
   chName1 = chName.replace(" ", "")
   for name in (chName, chName.lower(), chName.upper(), chName1.lower(), chName1.upper()):
    for ext in exts:
     path = "%s%s.%s" % (pPath, name, ext)
     if fileExists(path):
      return path
  return ""
 @staticmethod
 def VVzl1J(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCjCYH.VVzyVV()
   pList = []
   lst = FF8hHp(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFpnOy(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FFzOGe(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CCMOJv():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VVVfva  = None
  self.VV4qjT = ""
  self.VVdLBM  = noService
  self.VVfBck = 0
  self.VVXuH7  = noService
  self.VV3PRJ = 0
  self.VViDBj  = "-"
  self.VVqF9B = 0
  self.VVNH6O  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VV3BKA(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VVVfva = frontEndStatus
     self.VVjyOw()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVjyOw(self):
  if self.VVVfva:
   val = self.VVVfva.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VV4qjT = "%3.02f dB" % (val / 100.0)
   else         : self.VV4qjT = ""
   val = self.VVVfva.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVfBck = int(val)
   self.VVdLBM  = "%d%%" % val
   val = self.VVVfva.get("tuner_signal_power" , 0) * 100 / 65536
   self.VV3PRJ = int(val)
   self.VVXuH7  = "%d%%" % val
   val = self.VVVfva.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VViDBj  = "%d" % val
   val = int(val * 100 / 500)
   self.VVqF9B = min(500, val)
   val = self.VVVfva.get("tuner_locked", 0)
   if val == 1 : self.VVNH6O = "Locked"
   else  : self.VVNH6O = "Not locked"
 def VVlWgX(self)   : return self.VV4qjT
 def VVq2pt(self)   : return self.VVdLBM
 def VVxiKB(self)  : return self.VVfBck
 def VVIkjl(self)   : return self.VVXuH7
 def VVJOCS(self)  : return self.VV3PRJ
 def VV9Anf(self)   : return self.VViDBj
 def VVwSkF(self)  : return self.VVqF9B
 def VVXu2c(self)   : return self.VVNH6O
 def VVrTg2(self) : return self.serviceName
class CCTy0v():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVxZHX(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFvzBx(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VV2OkN(self.ORPOS  , mod=1   )
      self.sat2  = self.VV2OkN(self.ORPOS  , mod=2   )
      self.freq  = self.VV2OkN(self.FREQ  , mod=3   )
      self.sr   = self.VV2OkN(self.SR   , mod=4   )
      self.inv  = self.VV2OkN(self.INV  , self.D_PIL_INV)
      self.pol  = self.VV2OkN(self.POL  , self.D_POL )
      self.fec  = self.VV2OkN(self.FEC  , self.D_FEC )
      self.syst  = self.VV2OkN(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VV2OkN("modulation" , self.D_MOD )
       self.rolof = self.VV2OkN("rolloff"  , self.D_ROLOF )
       self.pil = self.VV2OkN("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VV2OkN("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VV2OkN("pls_code"  )
       self.iStId = self.VV2OkN("is_id"   )
       self.t2PlId = self.VV2OkN("t2mi_plp_id" )
       self.t2PId = self.VV2OkN("t2mi_pid"  )
 def VV2OkN(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFxluq(val)
  elif mod == 2   : return FFM86X(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VVD3pj(self, refCode):
  txt = ""
  self.VVxZHX(refCode)
  if self.data:
   def VVIsuR(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVIsuR("System"   , self.syst)
    txt += VVIsuR("Satellite"  , self.sat2)
    txt += VVIsuR("Frequency"  , self.freq)
    txt += VVIsuR("Inversion"  , self.inv)
    txt += VVIsuR("Symbol Rate"  , self.sr)
    txt += VVIsuR("Polarization" , self.pol)
    txt += VVIsuR("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVIsuR("Modulation" , self.mod)
     txt += VVIsuR("Roll-Off" , self.rolof)
     txt += VVIsuR("Pilot"  , self.pil)
     txt += VVIsuR("Input Stream", self.iStId)
     txt += VVIsuR("T2MI PLP ID" , self.t2PlId)
     txt += VVIsuR("T2MI PID" , self.t2PId)
     txt += VVIsuR("PLS Mode" , self.plsMod)
     txt += VVIsuR("PLS Code" , self.plsCod)
   else:
    txt += VVIsuR("System"   , self.txMedia)
    txt += VVIsuR("Frequency"  , self.freq)
  return txt, self.namespace
 def VVEwnw(self, refCode):
  txt = "Transpoder : ?"
  self.VVxZHX(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVXqWF(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFvzBx(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VV2OkN(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VV2OkN(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VV2OkN(self.SYST, self.D_SYS_S)
     freq = self.VV2OkN(self.FREQ , mod=3  )
     if isSat:
      pol = self.VV2OkN(self.POL , self.D_POL)
      fec = self.VV2OkN(self.FEC , self.D_FEC)
      sr = self.VV2OkN(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVEczv(self, refCode):
  self.data = None
  self.VVxZHX(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCteri():
 def __init__(self, VVoUm6, path, VVqhY7=None, curRowNum=-1):
  self.VVoUm6  = VVoUm6
  self.origFile   = path
  self.Title    = "File Editor: " + FFzOGe(path)
  self.VVqhY7  = VVqhY7
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  self.editorTable  = None
  if FFkQDN("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FFn5td(self.VVoUm6, BF(self.VVJSfc, curRowNum), title="Loading file ...")
  else:
   FFBsVa(self.VVoUm6, "Error while preparing edit!")
 def VVJSfc(self, curRowNum):
  VVaKg1 = self.VV6lb0()
  VVIZTW = ("Save Changes" , self.VV5qTP   , [])
  VVTXLQ  = ("Edit Line"  , self.VVcM6k    , [])
  VVFaAj = ("Options"  , self.VVsYHR  , [])
  VV6CVp = ("Line Options" , self.VVEaCe   , [])
  VVeJ6x = (""    , self.VVBMSX , [])
  VV0cge = self.VVPPXB
  VV8TXR  = self.VVRh1t
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVGQvW  = (CENTER  , LEFT  )
  bg    = "#11001111"
  self.editorTable = FFuI68(self.VVoUm6, None, title=self.Title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, width=1600, height=1000, VVJgEp=26, isEditor=True, VVIZTW=VVIZTW, VVTXLQ=VVTXLQ, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VV0cge=VV0cge, VV8TXR=VV8TXR, VVeJ6x=VVeJ6x, VV3cto=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
        , VVRmfT=bg, VVRNJt=bg, VV84wP=bg, VVvmBM="#05333333", VVfpy3="#00303030", VViJnU="#11331133")
  self.editorTable.VV8i74(curRowNum)
 def VVRh1t(self, VVzzNZ):
  VVzzNZ.VVvlea()
 def VVsYHR(self, VVzzNZ, title, txt, colList):
  VVtZf8 = []
  VVtZf8.append(("Go to Line Num" , "toLine"))
  VVtZf8.append(("Find & Replace" , "repl"))
  FFd7BR(self.VVoUm6, self.VVP3x6, VVtZf8=VVtZf8, width=500, title="Options", VVkmYm=True)
 def VVP3x6(self, item=None):
  if item:
   title, ref, ndx = item
   if   ref == "toLine" : self.VVrZAj()
   elif ref == "repl"  : self.VVou2c(title)
 def VVou2c(self, title):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  lst = [(" Find", fnd, str(len(fnd))), (" Replace with", rpl, str(len(rpl)))]
  bg = "#11101010"
  VVTXLQ  = ("Change" , BF(self.VVCsMl, title, lst) , [])
  VVIZTW = ("Start" , BF(self.VVmNV5, title)  , [])
  header  = (" Subject", " Text" , "Len.")
  widths  = (20   , 70  , 10 )
  VVGQvW = (LEFT   , LEFT  , CENTER)
  FFuI68(self.VVoUm6, None, title=title, VVBQW6=lst, header=header, VVGQvW=VVGQvW, VV3FCq=widths, width=1200, VVJgEp=30, isEditor=True, VVTXLQ=VVTXLQ, VVIZTW=VVIZTW, VVhEUu=2
    , VVRmfT=bg, VVRNJt=bg, VV84wP=bg, VVvmBM="#06224455", VVfpy3="#0a303030")
 def VVCsMl(self, Title, lst, VVzzNZ, title, txt, colList):
  title = VVzzNZ.VVOEiT(0)
  ndx = VVzzNZ.VVXRaz()
  txt = CFG.lastFindRepl_fnd.getValue() if ndx == 0 else CFG.lastFindRepl_rpl.getValue()
  FFsCnW(self.VVoUm6, BF(self.VVy2S3, VVzzNZ, ndx), title=title, defaultText=txt, message="New entry")
 def VVy2S3(self, VVzzNZ, ndx, newTxt=None):
  if newTxt:
   if ndx == 0 : FFSeyu(CFG.lastFindRepl_fnd, newTxt)
   else  : FFSeyu(CFG.lastFindRepl_rpl, newTxt)
   VVzzNZ.VVs007({1:newTxt, 2:len(newTxt)})
 def VVmNV5(self, Title, VVzzNZ, title, txt, colList):
  fnd = CFG.lastFindRepl_fnd.getValue()
  rpl = CFG.lastFindRepl_rpl.getValue()
  if len(fnd) > 0:
   txt = FFl3Sc(self.tmpFile)
   tot = txt.count(fnd)
   if tot > 0:
    FFEN35(self.VVoUm6, BF(FFn5td, VVzzNZ, BF(self.VVmEit, VVzzNZ, fnd, rpl), title="Replacing ..."), "Replace %d occurrences ?" % tot, title=Title)
   else:
    FFrBcM(VVzzNZ, "Not found in file !", 1000)
    VVzzNZ.VV8i74(0)
  else:
   FFrBcM(VVzzNZ, "Nothing to find", 1000)
 def VVmEit(self, VVzzNZ, fnd, rpl):
  txt = FFl3Sc(self.tmpFile)
  txt = txt.replace(fnd, rpl)
  with open(self.tmpFile, "w") as f:
   f.write(txt)
  VVzzNZ.cancel()
  self.fileChanged = True
  self.editorTable.VVfBWZ()
  VVaKg1 = self.VV6lb0()
  self.editorTable.VV311O(VVaKg1)
 def VVrZAj(self):
  totRows = self.editorTable.VVdO40()
  lineNum = self.editorTable.VVXRaz() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFsCnW(self.VVoUm6, BF(self.VV4zAN, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VV4zAN(self, lineNum, totRows, VVudej):
  if VVudej:
   VVudej = VVudej.strip()
   if VVudej.isdigit():
    num = FFMpNv(int(VVudej) - 1, 0, totRows)
    self.editorTable.VV8i74(num)
    self.lastLineNum = num + 1
   else:
    FFrBcM(self.editorTable, "Incorrect number", 1500)
 def VVEaCe(self, VVzzNZ, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVzzNZ.VVI5RC()
  VVtZf8 = []
  VVtZf8.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVtZf8.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVpDjo"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVWcGv:
   VVtZf8.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(  ("Delete Line"         , "deleteLine"   ))
  FFd7BR(self.VVoUm6, BF(self.VVQVGz, lineNum), VVtZf8=VVtZf8, title="Line Options")
 def VVQVGz(self, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVLLxM("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile))
   elif item == "VVpDjo"  : self.VVpDjo(lineNum)
   elif item == "copyToClipboard"  : self.VVWso9(lineNum)
   elif item == "pasteFromClipboard" : self.VVgVoK(lineNum)
   elif item == "deleteLine"   : self.VVLLxM("sed -i '%dd' '%s'" % (lineNum, self.tmpFile))
 def VVBMSX(self, VVzzNZ, title, txt, colList):
  if   self.insertMode == 1: VVzzNZ.VVE6jF()
  elif self.insertMode == 2: VVzzNZ.VVSXho()
  self.insertMode = 0
 def VVpDjo(self, lineNum):
  if lineNum == self.editorTable.VVI5RC():
   self.insertMode = 1
   self.VVLLxM("echo '' >> '%s'" % self.tmpFile)
  else:
   self.insertMode = 2
   self.VVLLxM("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile))
 def VVWso9(self, lineNum):
  global VVWcGv
  VVWcGv = FFz86l("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  self.editorTable.VVNLt2("Copied to clipboard")
 def VV5qTP(self, VVzzNZ, title, txt, colList):
  if self.fileChanged:
   if FFmO9U(self.origFile):
    if FFkQDN("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVzzNZ.VVNLt2("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVzzNZ.VVvlea()
    else:
     FFBsVa(self.VVoUm6, "Cannot save file!")
   else:
    FFBsVa(self.VVoUm6, "Cannot create backup copy of original file!")
 def VVPPXB(self, VVzzNZ):
  if self.fileChanged:
   FFEN35(self.VVoUm6, BF(self.VV0KIa, VVzzNZ), "Cancel changes ?")
  else:
   FFkQDN("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VV0KIa(VVzzNZ)
 def VV0KIa(self, VVzzNZ):
  VVzzNZ.cancel()
  FFKqXn(self.tmpFile)
  if self.VVqhY7:
   self.VVqhY7(self.fileSaved)
 def VVcM6k(self, VVzzNZ, title, txt, colList):
  lineNum = int(VVzzNZ.VVOEiT(0))
  lineTxt = VVzzNZ.VVOEiT(1, isStrip=False)
  message = VVDysW + "ORIGINAL TEXT:\n" + VVUpvF + lineTxt
  FFsCnW(self.VVoUm6, BF(self.VVaZn7, lineNum), title="File Line", defaultText=lineTxt, message=message)
 def VVaZn7(self, lineNum, VVudej):
  if not VVudej is None:
   if self.editorTable.VVI5RC() <= 1:
    self.VVLLxM("echo %s > '%s'" % (VVudej, self.tmpFile))
   else:
    self.VVRal2(lineNum, VVudej)
 def VVgVoK(self, lineNum):
  if lineNum == self.editorTable.VVI5RC() and self.editorTable.VVI5RC() == 1:
   self.VVLLxM("echo %s >> '%s'" % (VVWcGv, self.tmpFile))
  else:
   self.VVRal2(lineNum, VVWcGv)
 def VVRal2(self, lineNum, newTxt):
  self.editorTable.VVM1y5("Saving ...")
  lines = FFMy5k(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  self.editorTable.VVfBWZ()
  VVaKg1 = self.VV6lb0()
  self.editorTable.VV311O(VVaKg1)
 def VVLLxM(self, cmd):
  tCons = CC6Ith()
  tCons.ePopen(cmd, self.VVzHjL)
  self.fileChanged = True
  self.editorTable.VVfBWZ()
 def VVzHjL(self, result, retval):
  VVaKg1 = self.VV6lb0()
  self.editorTable.VV311O(VVaKg1)
 def VV6lb0(self):
  if fileExists(self.tmpFile):
   lines = FFMy5k(self.tmpFile)
   VVaKg1 = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVaKg1.append((str(ndx), line))
   if not VVaKg1:
    VVaKg1.append((str(1), ""))
   return VVaKg1
  else:
   FFPQyp(self.VVoUm6, self.tmpFile)
class CCmB9U():
 def __init__(self, callingSELF, VVRmfT="#22003344", VVRNJt="#22002233"):
  self.callingSELF = callingSELF
  self.VVtZf8  = []
  self.satList  = []
  self.VVRmfT  = VVRmfT
  self.VVRNJt   = VVRNJt
 def VVoqZE(self, VVqhY7):
  self.VVtZf8 = []
  VVtZf8, VVO2lh = CCmB9U.VVLnbC(self.callingSELF, False, True)
  if VVtZf8:
   self.VVtZf8 += VVtZf8
   self.VVjbOi(VVqhY7, VVO2lh)
 def VVSuBu(self, mode, VVzzNZ, satCol, VVqhY7, inFilterFnc=None):
  VVzzNZ.VVM1y5("Loading Filters ...")
  self.VVtZf8 = []
  self.VVtZf8.append(("All Services" , "all"))
  if mode == 1:
   self.VVtZf8.append(VVh3VV)
   self.VVtZf8.append(("Parental Control", "parentalControl" ))
   self.VVtZf8.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVtZf8.append(VVh3VV)
   self.VVtZf8.append(("Selected Transponder"   , "selectedTP" ))
   self.VVtZf8.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VV7Psi(VVzzNZ, satCol)
  VVtZf8, VVO2lh = CCmB9U.VVLnbC(self.callingSELF, True, False)
  if VVtZf8:
   VVtZf8.insert(0, FFbAzs("Custom Words"))
   self.VVtZf8 += VVtZf8
  VVzzNZ.VVD7du()
  self.VVjbOi(VVqhY7, VVO2lh, inFilterFnc)
 def VVR4AM(self, VVtZf8, sats, VVqhY7, inFilterFnc=None):
  self.VVtZf8 = VVtZf8
  VVtZf8, VVO2lh = CCmB9U.VVLnbC(self.callingSELF, True, False)
  if VVtZf8:
   self.VVtZf8.append(FFbAzs("Custom Words"))
   self.VVtZf8 += VVtZf8
  self.VVjbOi(VVqhY7, VVO2lh, inFilterFnc)
 def VVjbOi(self, VVqhY7, VVO2lh, inFilterFnc=None):
  VVA2fW  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VVJlf7 = ("Edit Filter"  , BF(self.VVx199, VVO2lh))
  VVR5O9  = ("Filter Help"  , BF(self.VVuame, VVO2lh))
  FFd7BR(self.callingSELF, BF(self.VVyn5B, VVqhY7), VVtZf8=self.VVtZf8, title="Select Filter", VVA2fW=VVA2fW, VVJlf7=VVJlf7, VVR5O9=VVR5O9, VVh2Zj=True, VVRmfT=self.VVRmfT, VVRNJt=self.VVRNJt)
 def VVyn5B(self, VVqhY7, item):
  if item:
   VVqhY7(item)
 def VVx199(self, VVO2lh, selectionObj, sel):
  if fileExists(VVO2lh) : CCteri(self.callingSELF, VVO2lh, VVqhY7=None)
  else       : FFPQyp(self.callingSELF, VVO2lh)
  selectionObj.cancel()
 def VVuame(self, VVO2lh, selectionObj, sel):
  FF4fCC(self.callingSELF, "_help_service_filter", "Service Filter")
 def VV7Psi(self, VVzzNZ, satColNum):
  if not self.satList:
   satList = VVzzNZ.VVtIX5(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FF9eBo(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFbAzs("Satellites"))
  if self.VVtZf8:
   self.VVtZf8 += self.satList
 @staticmethod
 def VVLnbC(SELF, addTag, VVg3ap):
  FFCdSV()
  fileName  = "ajpanel_services_filter"
  VVO2lh = VVzbRf + fileName
  VVtZf8  = []
  if not fileExists(VVO2lh):
   FFkQDN("cp -f '%s' '%s'" % (VVG8hM + fileName, VVO2lh))
  fileFound = False
  if fileExists(VVO2lh):
   fileFound = True
   lines = FFMy5k(VVO2lh)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVtZf8.append((line, "__w__" + line))
       else  : VVtZf8.append((line, line))
  if VVg3ap:
   if   not fileFound : FFPQyp(SELF, VVO2lh)
   elif not VVtZf8 : FF0v65(SELF, VVO2lh)
  return VVtZf8, VVO2lh
 @staticmethod
 def VVbRSg(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CC7G9K():
 def __init__(self, callingSELF, VVzzNZ, addSep=True):
  self.callingSELF = callingSELF
  self.VVzzNZ = VVzzNZ
  self.VVtZf8 = []
  iMulSel = self.VVzzNZ.VVFPwr()
  if iMulSel : self.VVtZf8.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVtZf8.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVzzNZ.VVRFlF()
  self.VVtZf8.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVtZf8.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVtZf8.append(VVh3VV)
 def VVaknP(self, extraMenu, cbFncDict, width=1000, okFnc=None, onMultiSelFnc=None):
  self.VVzzNZ.onMultiSelFnc = onMultiSelFnc
  if extraMenu:
   self.VVtZf8.extend(extraMenu)
  FFd7BR(self.callingSELF, BF(self.VV3jWx, cbFncDict, okFnc), width=width, title="Options", VVtZf8=self.VVtZf8)
 def VV3jWx(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVzzNZ.VVPvaS(True)
   elif item == "MultSelDisab" : self.VVzzNZ.VVPvaS(False)
   elif item == "selectAll" : self.VVzzNZ.VVABN7()
   elif item == "unselectAll" : self.VVzzNZ.VVnAWu()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCXBmT(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVFLUo, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFd98D(self)
  FF1N71(self["keyRed"]  , "Exit")
  FF1N71(self["keyGreen"]  , "Save")
  FF1N71(self["keyYellow"] , "Refresh")
  FF1N71(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(VVO7iZ,
  {
   "red" : self.VV2oQQ  ,
   "green" : self.VVu65w ,
   "yellow": self.VVkSyu  ,
   "blue" : self.VV9wxN   ,
   "up" : self.VVSK0n    ,
   "down" : self.VVvWX5   ,
   "left" : self.VV3UwQ   ,
   "right" : self.VVWKwc   ,
   "cancel": self.VV2oQQ
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self.VVkSyu()
  self.VVgNjM()
  FFRet2(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVo5uH)
  except:
   self.timer.callback.append(self.VVo5uH)
  self.timer.start(1000, False)
  self.VVo5uH()
 def onExit(self):
  self.timer.stop()
 def VV2oQQ(self) : self.close(True)
 def VVdc56(self) : self.close(False)
 def VV9wxN(self):
  self.session.openWithCallback(self.VVwJv8, BF(CCCOhN))
 def VVwJv8(self, closeAll):
  if closeAll:
   self.close()
 def VVo5uH(self):
  self["curTime"].setText(str(FF2ADr(iTime())))
 def VVSK0n(self):
  self.VVChoC(1)
 def VVvWX5(self):
  self.VVChoC(-1)
 def VV3UwQ(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VVgNjM()
 def VVWKwc(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VVgNjM()
 def VVChoC(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVkflm(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVkflm(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVkflm(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVFA43(year)):
   days += 1
  return days
 def VVFA43(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VVgNjM(self):
  for obj in self.list:
   FFwVrd(obj, "#11404040")
  FFwVrd(self.list[self.index], "#11ff8000")
 def VVkSyu(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVu65w(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC6Ith()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVgvBj)
 def VVgvBj(self, result, retval):
  result = str(result.strip())
  if len(result) == 0 : FFx4Fl(self, "Nothing returned from the system!")
  else    : FFx4Fl(self, str(result))
class CCCOhN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVKs5Q, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFd98D(self, addLabel=True)
  FF1N71(self["keyRed"]  , "Exit")
  FF1N71(self["keyGreen"]  , "Sync")
  FF1N71(self["keyYellow"] , "Refresh")
  FF1N71(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(VVO7iZ,
  {
   "red" : self.VV2oQQ   ,
   "green" : self.VVhHAj  ,
   "yellow": self.VVs5r1 ,
   "blue" : self.VVCrCg  ,
   "cancel": self.VV2oQQ
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VV3PMM()
  self.onShown.append(self.VV583n)
 def VV583n(self):
  FFRet2(self)
  FFb5Nn(self.VV2Osm)
 def VV2Osm(self):
  self.VVLbYW()
  self.VVYeqW(False)
 def VV2oQQ(self)  : self.close(True)
 def VVCrCg(self) : self.close(False)
 def VV3PMM(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VVLbYW(self):
  self.VVZuPI()
  self.VVNG0I()
  self.VVBJY4()
  self.VVXGM1()
 def VVs5r1(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VV3PMM()
   self.VVLbYW()
   FFb5Nn(self.VV2Osm)
 def VVhHAj(self):
  if len(self["keyGreen"].getText()) > 0:
   FFEN35(self, self.VV19X3, "Synchronize with Internet Date/Time ?")
 def VV19X3(self):
  self.VVLbYW()
  FFb5Nn(BF(self.VVYeqW, True))
 def VVZuPI(self)  : self["keyRed"].show()
 def VVV3ME(self)  : self["keyGreen"].show()
 def VVCYsl(self) : self["keyYellow"].show()
 def VVLUJS(self)  : self["keyBlue"].show()
 def VVNG0I(self)  : self["keyGreen"].hide()
 def VVBJY4(self) : self["keyYellow"].hide()
 def VVXGM1(self)  : self["keyBlue"].hide()
 def VVYeqW(self, sync):
  localTime = FFByGk()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVLyFR(server)
   if epoch_time is not None:
    ntpTime = FF2ADr(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC6Ith()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVgvBj, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVCYsl()
  self.VVLUJS()
  if ok:
   self.VVV3ME()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVgvBj(self, syncAgain, result, retval):
  result = str(result.strip())
  if   len(result) == 0  : result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20: result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVYeqW(False)
  except:
   pass
 def VVLyFR(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CCDTZn.VVay4r():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCgTGS(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FF98gL(VVWPLM, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFd98D(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFb5Nn(self.VVll6d)
 def VVll6d(self):
  if CCDTZn.VVay4r() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFwVrd(self["myBody"], color)
   FFwVrd(self["myLabel"], color)
  except:
   pass
class CCRQgm(Screen):
 VVHrDa = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FF3tfX()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FF98gL(VV9X8T, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCebQS(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCebQS(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCebQS(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CCMOJv()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFd98D(self, title="Signal")
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok"  : self.close      ,
   "up"  : self.VVSK0n       ,
   "down"  : self.VVvWX5      ,
   "left"  : self.VV3UwQ      ,
   "right"  : self.VVWKwc      ,
   "info"  : self.VVbdfc     ,
   "epg"  : self.VVbdfc     ,
   "menu"  : self.VVmXPH      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVTQWl, -1)  ,
   "next"  : BF(self.VVTQWl, 1)  ,
   "pageUp" : BF(self.VVNw8H, True) ,
   "chanUp" : BF(self.VVNw8H, True) ,
   "pageDown" : BF(self.VVNw8H, False) ,
   "chanDown" : BF(self.VVNw8H, False) ,
   "0"   : BF(self.VVTQWl, 0)  ,
   "1"   : BF(self.VVbD6N, pos=1) ,
   "2"   : BF(self.VVbD6N, pos=2) ,
   "3"   : BF(self.VVbD6N, pos=3) ,
   "4"   : BF(self.VVbD6N, pos=4) ,
   "5"   : BF(self.VVbD6N, pos=5) ,
   "6"   : BF(self.VVbD6N, pos=6) ,
   "7"   : BF(self.VVbD6N, pos=7) ,
   "8"   : BF(self.VVbD6N, pos=8) ,
   "9"   : BF(self.VVbD6N, pos=9) ,
  }, -1)
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  if not CCRQgm.VVHrDa:
   CCRQgm.VVHrDa = self
  self.sliderSNR.VVFfKb()
  self.sliderAGC.VVFfKb()
  self.sliderBER.VVFfKb(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VVbD6N()
  self.VVKx2o()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVwNI0)
  except:
   self.timer.callback.append(self.VVwNI0)
  self.timer.start(500, False)
 def VVKx2o(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VV3BKA(service)
  serviceName = self.tunerInfo.VVrTg2()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  tp = CCTy0v()
  tpTxt, satTxt = tp.VVEwnw(refCode)
  if tpTxt == "?" :
   tpTxt = FFxrb0("NO SIGNAL", VVD46d)
  self["myTPInfo"].setText(tpTxt + "  " + FFxrb0(satTxt, VVwwau))
 def VVwNI0(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VV3BKA(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVlWgX())
   self["mySNR"].setText(self.tunerInfo.VVq2pt())
   self["myAGC"].setText(self.tunerInfo.VVIkjl())
   self["myBER"].setText(self.tunerInfo.VV9Anf())
   self.sliderSNR.VV4bsj(self.tunerInfo.VVxiKB())
   self.sliderAGC.VV4bsj(self.tunerInfo.VVJOCS())
   self.sliderBER.VV4bsj(self.tunerInfo.VVwSkF())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VV4bsj(0)
   self.sliderAGC.VV4bsj(0)
   self.sliderBER.VV4bsj(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
    if state and not state == "Tuned":
     FFrBcM(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVbdfc(self):
  FFqy2T(self, fncMode=CCFLza.VVUyQo)
 def VVmXPH(self):
  FF4fCC(self, "_help_signal", "Signal Monitor (Keys)")
 def VVSK0n(self)  : self.VVbD6N(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVvWX5(self) : self.VVbD6N(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VV3UwQ(self) : self.VVbD6N(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVWKwc(self) : self.VVbD6N(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VVbD6N(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFSeyu(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVTQWl(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFMpNv(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFSeyu(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCRQgm.VVHrDa = None
 def VVNw8H(self, isUp):
  FFrBcM(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVKx2o()
  except:
   pass
class CCebQS(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVFfKb(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFwVrd(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVG8hM +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFwVrd(self.covObj, self.covColor)
   else:
    FFwVrd(self.covObj, "#00006688")
    self.isColormode = True
  self.VV4bsj(0)
 def VV4bsj(self, val):
  val  = FFMpNv(val, self.minN, self.maxN)
  width = int(FFUY5i(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFMpNv(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCIpg5(Screen):
 VVipyP    = 0
 VV0bv2 = 1
 VVtl8z = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVqhY7=None, barTheme=VVipyP, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VV72LM(barTheme)
  self.skin, self.skinParam = FF98gL(VVxBHE, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVqhY7 = VVqhY7
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VV6uui = None
  self.timer   = eTimer()
  self.myThread  = None
  FFd98D(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(VVO7iZ, { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self.VVrsfk()
  self["myProgBarVal"].setText("0%")
  FFwVrd(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVZlY0()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVZlY0)
  except:
   self.timer.callback.append(self.VVZlY0)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVITUK(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVw3Fg(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VV6uui), self.counter, self.maxValue, catName)
 def VVkjQn(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VVVKhZ(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVscn9(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVEzB2(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVAGgq(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVttgG(self, txt):
  self.newTitle = txt
 def VVReKT(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VV6uui), self.counter, self.maxValue)
  except:
   pass
 def VVh8t9(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVvKWQ(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV41tC(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FFrBcM(self, "Cancelling ...")
  self.isCancelled = True
  self.VVC5XC(False)
 def VVC5XC(self, isDone):
  FFb5Nn(BF(self.VVak9L, isDone))
 def VVak9L(self, isDone):
  if self.VVqhY7:
   self.VVqhY7(isDone, self.VV6uui, self.counter, self.maxValue, self.isError)
  self.close()
 def VVZlY0(self):
  val = FFMpNv(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FFUY5i(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVC5XC(True)
 def VVrsfk(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VV0bv2, self.VVtl8z):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VV72LM(self, barTheme):
  if   barTheme == self.VV0bv2 : return 0.7
  if   barTheme == self.VVtl8z : return 0.5
  else             : return 1
class CC6Ith(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVqhY7 = {}
  self.commandRunning = False
  self.VVITRg  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVqhY7, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVqhY7[name] = VVqhY7
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVITRg:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVjsIi, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVKwa6 , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVjsIi, name))
    self.appContainers[name].appClosed.append(BF(self.VVKwa6 , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVKwa6(name, retval)
  return True
 def VVjsIi(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFxrb0("[UN-DECODED STRING]", VVD46d))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVKwa6(self, name, retval):
  if not self.VVITRg:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVqhY7[name]:
   self.VVqhY7[name](self.appResults[name], retval)
  del self.VVqhY7[name]
 def VVUmvD(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCIYpr(Screen):
 def __init__(self, session, title="", VVaRoH=None, VVSoxh=False, VV9gso=False, VVCjpM=False, VVnFNI=False, VVjU5M=False, VVsjuE=False, VVeLJi=VVDwe9, VVBjuq=None, VVow73=False, VVVk0m=None, VVq7WU="", checkNetAccess=False, VVJgEp=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FF98gL(VV3Zke, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVJgEp, usefixedFont=consFont)
  self.session   = session
  self.VVq7WU = VVq7WU
  FFd98D(self, addScrollLabel=True)
  self.VVSoxh   = VVSoxh
  self.VV9gso   = VV9gso
  self.VVCjpM   = VVCjpM
  self.VVnFNI  = VVnFNI
  self.VVjU5M = VVjU5M
  self.VVsjuE = VVsjuE
  self.VVeLJi   = VVeLJi
  self.VVBjuq = VVBjuq
  self.VVow73  = VVow73
  self.VVVk0m  = VVVk0m
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC6Ith()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFwW71()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVaRoH, str):
   self.VVaRoH = [VVaRoH]
  else:
   self.VVaRoH = VVaRoH
  if self.VVCjpM or self.VVnFNI:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVaRoH.append("echo -e '\n%s\n' %s" % (restartNote, FFPk5q(restartNote, VV0V0q)))
   if self.VVCjpM:
    self.VVaRoH.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVaRoH.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVjU5M:
   FFrBcM(self, "Processing ...")
  self.onLayoutFinish.append(self.VVIlAR)
  self.onClose.append(self.VVE7Km)
 def VVIlAR(self):
  self["myLabel"].VVc45w(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVq7WU or "Processing ..."))
  if self.VVSoxh:
   self["myLabel"].VVK7a0()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV6Sc6()
  else:
   self.VVD5pX()
 def VV6Sc6(self):
  if CCDTZn.VVay4r():
   self["myLabel"].setText("Processing ...")
   self.VVD5pX()
  else:
   self["myLabel"].setText(FFxrb0("\n   No connection to internet!", VVmxw7))
 def VVD5pX(self):
  allOK = self.container.ePopen(self.VVaRoH[0], self.VVBWt0, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVBWt0("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VVsjuE or self.VVCjpM or self.VVnFNI:
    self["myLabel"].setText(FFElFp("STARTED", VV0V0q) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVVk0m:
   colorWhite = CCpGRu.VV97a4(VVDysW)
   color  = CCpGRu.VV97a4(self.VVVk0m[0])
   words  = self.VVVk0m[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VVeLJi=self.VVeLJi)
 def VVBWt0(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVaRoH):
   allOK = self.container.ePopen(self.VVaRoH[self.cmdNum], self.VVBWt0, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVBWt0("Cannot connect to Console!", -1)
  else:
   if self.VVjU5M and FFgLwO(self):
    FFrBcM(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VVsjuE:
    self["myLabel"].appendText("\n" + FFElFp("FINISHED", VV0V0q), self.VVeLJi)
   if self.VVSoxh or self.VV9gso:
    self["myLabel"].VVK7a0()
   if self.VVBjuq is not None:
    self.VVBjuq()
   if not retval and self.VVow73:
    self.VVE7Km()
 def VVE7Km(self):
  if self.container.VVUmvD():
   self.container.killAll()
class CCPRQ8(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF98gL(VV3Zke, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVzbRf + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FFz86l("pwd") or "/home/root"
  self.container   = CC6Ith()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFd98D(self, title="Terminal", addScrollLabel=True)
  FF1N71(self["keyRed"] , self.exitBtnText)
  FF1N71(self["keyGreen"] , "OK = History")
  FF1N71(self["keyYellow"], "Menu = Custom Cmds")
  FF1N71(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VV1foz ,
   "cancel": self.VV09a3  ,
   "menu" : self.VVEZrk ,
   "last" : self.VV9iHe  ,
   "next" : self.VV9iHe  ,
   "1"  : self.VV9iHe  ,
   "2"  : self.VV9iHe  ,
   "3"  : self.VV9iHe  ,
   "4"  : self.VV9iHe  ,
   "5"  : self.VV9iHe  ,
   "6"  : self.VV9iHe  ,
   "7"  : self.VV9iHe  ,
   "8"  : self.VV9iHe  ,
   "9"  : self.VV9iHe  ,
   "0"  : self.VV9iHe
  })
  self.onLayoutFinish.append(self.VV583n)
  self.onClose.append(self.VVATv0)
 def VV583n(self):
  self["myLabel"].VVc45w(isResizable=False, outputFileToSave="terminal")
  FFBe4X(self["keyRed"]  , "#00ff8000")
  FFwVrd(self["keyRed"]  , self.skinParam["titleColor"])
  FFwVrd(self["keyGreen"]  , self.skinParam["titleColor"])
  FFwVrd(self["keyYellow"] , self.skinParam["titleColor"])
  FFwVrd(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVGwJP(FFz86l("date"), 5)
  result = FFz86l("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVQsMc()
  self.VVQ974()
 def VVQ974(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVzbRf + "LinuxCommands.lst"
  templPath = VVG8hM + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   if not FFkQDN("cp -f '%s' '%s'" % (templPath, alterFile)):
    FFnedc("echo -e 'pwd\ncd\ncd /tmp\nls\nls -ls' > '%s'" % alterFile)
   self.customCommandsFile = alterFile
 def VVATv0(self):
  if self.container.VVUmvD():
   self.container.killAll()
   self.VVGwJP("Process killed\n", 4)
   self.VVQsMc()
 def VV09a3(self):
  if self.container.VVUmvD():
   self.VVATv0()
  else:
   FFEN35(self, self.close, "Exit ?", VVls2R=False)
 def VVQsMc(self):
  self.VVGwJP(self.prompt, 1)
  self["keyRed"].hide()
 def VVGwJP(self, txt, mode):
  if   mode == 1 : color = VV0V0q
  elif mode == 2 : color = VVTVZG
  elif mode == 3 : color = VVDysW
  elif mode == 4 : color = VVmxw7
  elif mode == 5 : color = VVUpvF
  elif mode == 6 : color = VVi96Z
  else   : color = VVDysW
  try:
   self["myLabel"].appendText(FFxrb0(txt, color))
  except:
   pass
 def VV1foz(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VV9GaG() == "":
   self.VVug9f("cd /tmp")
   self.VVug9f("ls")
  VVaKg1 = []
  if fileExists(self.commandHistoryFile):
   lines  = FFMy5k(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVaKg1.append((str(c), line, str(lNum)))
   self.VV6xkh(VVaKg1, title, self.commandHistoryFile, isHistory=True)
  else:
   FFPQyp(self, self.commandHistoryFile, title=title)
 def VV9GaG(self):
  lastLine = FFz86l("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVug9f(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VVEZrk(self, VVzzNZ=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FFMy5k(self.customCommandsFile)
   VVaKg1 = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVaKg1.append((str(c), line, str(lNum)))
   if VVzzNZ:
    VVzzNZ.VV311O(VVaKg1)
    VVzzNZ.VV8i74(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VV6xkh(VVaKg1, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFPQyp(self, self.customCommandsFile, title=title)
 def VV6xkh(self, VVaKg1, title, filePath=None, isHistory=False):
  if VVaKg1:
   VVvmBM = "#05333333"
   if isHistory: VVRmfT = VVRNJt = VV84wP = "#11000020"
   else  : VVRmfT = VVRNJt = VV84wP = "#06002020"
   VVTXLQ   = ("Send"   , BF(self.VVbhE8, isHistory)  , [])
   VVIZTW  = ("Modify & Send" , self.VVor8T     , [])
   if isHistory:
    VVFaAj = ("Clear History" , self.VV741X     , [])
    VV6CVp = None
    VVZRP4 = None
   elif filePath:
    VVFaAj = ("Options"  , self.VVILD0      , [])
    VV6CVp = ("Edit File"  , BF(self.VVlOsE, filePath) , [])
    VVZRP4 = (""    , self.VVzeA8     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVGQvW = (CENTER , LEFT   , CENTER )
   VVzzNZ = FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp, VVZRP4=VVZRP4, lastFindConfigObj=CFG.lastFindTerminal, VV3cto=True, searchCol=1
         , VVRmfT=VVRmfT, VVRNJt=VVRNJt, VV84wP=VV84wP, VVvmBM=VVvmBM)
   if not isHistory:
    VVzzNZ.VV8i74(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFEN35(self, BF(self.VVcnDA, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVzeA8(self, VVzzNZ, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FFxrb0("Command:", VVwwau), colList[1])
  txt += "%s\n%s\n\n" % (FFxrb0("Line %s in File:" % colList[2], VVwwau), self.customCommandsFile)
  FFVBx2(self, txt, title=title)
 def VVILD0(self, VVzzNZ, title, txt, colList):
  mSel = CC7G9K(self, VVzzNZ)
  VVtZf8 = []
  txt1 = "Change Custom Commands File"
  if VVzzNZ.VVoCEo:
   VVtZf8.append((txt1, ))
   VVtZf8.append(VVh3VV)
   totSel = VVzzNZ.VVRFlF()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FFxrb0(totTxt, VV0V0q) if totSel else totTxt, FFAHjU(totSel))
   VVtZf8.append((txt2, "send") if totSel else (txt2,))
  else:
   VVtZf8.append((txt1, "newFile"))
   VVtZf8.append(VVh3VV)
   txt2 = "Send current line"
   VVtZf8.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVcnDA, VVzzNZ, txt1)
     , "send" : BF(self.VVbhE8, False, VVzzNZ, title, txt2, colList) }
  mSel.VVaknP(VVtZf8, cbFncDict, okFnc=BF(self.VViKIM, VVzzNZ))
 def VVcnDA(self, VVzzNZ, title):
  VVtZf8 = []
  for fName in os.listdir(VVzbRf):
   path = os.path.join(VVzbRf, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVtZf8.append((fName, path))
  VVtZf8.sort(key=lambda x: x[0].lower())
  if VVtZf8 : FFd7BR(self, BF(self.VVfbSC, VVzzNZ, title), VVtZf8=VVtZf8, title=title, minRows=3, VVRmfT="#11220000", VVRNJt="#11220000")
  else  : FFBsVa(self, "No valid files found in:\n\n%s" % VVzbRf, title=title)
 def VVfbSC(self, VVzzNZ, title, path=None):
  if path:
   if CC5iId.VV45v0(path):
    FFBsVa(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FFMy5k(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFSeyu(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFSeyu(CFG.lastTerminalCustCmdLineNum, 0)
      self.VVEZrk(VVzzNZ)
      break
    else:
     FFBsVa(self, "File is empty:\n\n%s" % path, title=title)
 def VViKIM(self, VVzzNZ):
  if VVzzNZ.VVoCEo : VVzzNZ.VVvlea()
  else        : VVzzNZ.VVfBWZ()
 def VVbhE8(self, isHistory, VVzzNZ, title, txt, colList):
  if VVzzNZ.VVoCEo:
   lst = VVzzNZ.VVXAfG(1)
   curNdx = VVzzNZ.VVJlmL()
  else:
   lst = [colList[1]]
   curNdx = VVzzNZ.VVXRaz()
  if not isHistory:
   FFSeyu(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVzzNZ.cancel()
  FFb5Nn(self.VVGUFw)
 def VVGUFw(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVGwJP("\n%s\n" % cmd, 6)
    self.VVGwJP(self.prompt, 1)
    self.VVGUFw()
   else:
    self.VVv4L1(cmd)
 def VVv4L1(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVGwJP(cmd, 2)
   self.VVGwJP("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVGwJP(ch, 0)
   self.VVGwJP("\nor\n", 4)
   self.VVGwJP("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVQsMc()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFxrb0(parts[0].strip(), VVTVZG)
    right = FFxrb0("#" + parts[1].strip(), VVi96Z)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVGwJP(txt, 2)
   lastLine = self.VV9GaG()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVug9f(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVBWt0, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFBsVa(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVGwJP(data, 3)
 def VVBWt0(self, data, retval):
  if not retval == 0:
   self.VVGwJP("Exit Code : %d\n" % retval, 4)
  self.VVQsMc()
  if self.commandsList:
   self.VVGUFw()
 def VVor8T(self, VVzzNZ, title, txt, colList):
  if VVzzNZ.VVoQzx():
   cmd = colList[1]
   self.VVH4pd(VVzzNZ, cmd)
 def VV741X(self, VVzzNZ, title, txt, colList):
  FFEN35(self, BF(self.VVrpUD, VVzzNZ), "Reset History File ?", title="Command History")
 def VVrpUD(self, VVzzNZ):
  FFnedc("> '%s'" % self.commandHistoryFile)
  VVzzNZ.cancel()
 def VVlOsE(self, filePath, VVzzNZ, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCteri(self, filePath, VVqhY7=BF(self.VVhq45, VVzzNZ), curRowNum=rowNum)
  else     : FFPQyp(self, filePath)
 def VVhq45(self, VVzzNZ, fileChanged):
  if fileChanged:
   VVzzNZ.cancel()
   FFb5Nn(self.VVEZrk)
 def VV9iHe(self):
  self.VVH4pd(None, self.lastCommand)
 def VVH4pd(self, VVzzNZ, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFsCnW(self, BF(self.VV4FYG, VVzzNZ), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VV4FYG(self, VVzzNZ, cmd):
  if cmd and len(cmd) > 0:
   self.VVv4L1(cmd)
   if VVzzNZ:
    VVzzNZ.cancel()
class CCoV76(Screen):
 def __init__(self, session, title="", message="", VVeLJi=VVDwe9, width=1400, height=900, VV8l2N=False, titleBg="#22002020", VV84wP="#22001122", VVJgEp=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FF98gL(VV3Zke, width, height, titleFontSize, 30, 20, titleBg, VV84wP, VVJgEp)
  self.session   = session
  FFd98D(self, title, addScrollLabel=True)
  self.VVeLJi   = VVeLJi
  self.VV8l2N   = VV8l2N
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self["myLabel"].VVc45w(VV8l2N=self.VV8l2N, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VVeLJi)
  self["myLabel"].VVK7a0()
class CCpDJU(Screen):
 def __init__(self, session, txt):
  self.skin, self.skinParam = FF98gL(VVJGdz, 1800, 60, 30, 30, 20, "#55000000", "#ff000000", 30)
  self.session  = session
  self.txt   = txt
  self["myWinTitle"] = Label()
  FFd98D(self, " ", addCloser=True)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  CC2Wqe.VVso35(self, self.txt)
  self.instance.move(ePoint((getDesktop(0).size().width() - self.instance.size().width()) // 2, 20))
class CCzS1c(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FF98gL(VVJrG6, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFd98D(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFBFvR(self["errPic"], "err")
class CC5tYb(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FF98gL(VVJGdz, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFd98D(self, " ", addCloser=True)
class CC2Wqe():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CC2Wqe.VVjBB1(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VV6052)
  except: self.timer.callback.append(self.VV6052)
  self.timer.start(timeout, True)
 def VV6052(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VVjBB1(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CC5tYb, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFL9cN(win["myWinTitle"], shadColor, shadW)
  CC2Wqe.VVso35(win, txt)
  return win
 @staticmethod
 def VVso35(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCPYn3():
 VVpuM7    = 0
 VVu8eC  = 1
 VVmyA8   = ""
 VVdNgs    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVzzNZ   = None
  self.timer     = eTimer()
  self.VVBUry   = 0
  self.VVLZ3S  = 1
  self.VV2jZE  = 2
  self.VVqwEj   = 3
  self.VVAP68   = 4
  VVaKg1 = self.VVBtRJ()
  if VVaKg1:
   self.VVzzNZ = self.VVX5o8(VVaKg1)
  if not VVaKg1 and mode == self.VVpuM7:
   self.VVwnxh("Download list is empty !")
   self.cancel()
  if mode == self.VVu8eC:
   FFn5td(self.VVzzNZ or self.SELF, BF(self.VV9bcG, startDnld, decodedUrl), title="Checking Server ...")
  self.VV5tGE(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV5tGE)
  except:
   self.timer.callback.append(self.VV5tGE)
  self.timer.start(1000, False)
 def VVX5o8(self, VVaKg1):
  VVaKg1.sort(key=lambda x: int(x[0]))
  VV0cge = self.VVyPp8
  VVTXLQ  = ("Play"  , self.VVVXgM , [])
  VVZRP4 = (""   , self.VVM9uu  , [])
  VVXfC8 = ("Stop"  , self.VVJerg  , [])
  VVIZTW = ("Resume"  , self.VVW9CV , [])
  VVFaAj = ("Options" , self.VVdtU4  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVGQvW  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FFuI68(self.SELF, None, title=self.Title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VVTXLQ=VVTXLQ, VVZRP4=VVZRP4, VV0cge=VV0cge, VVXfC8=VVXfC8, VVIZTW=VVIZTW, VVFaAj=VVFaAj, lastFindConfigObj=CFG.lastFindIptv, VVRmfT="#11220022", VVRNJt="#11110011", VV84wP="#11110011", VVvmBM="#00223025", VVfpy3="#0a333333", VViJnU="#0a400040", VV3cto=True, searchCol=1)
 def VVBtRJ(self):
  lines = CCPYn3.VVOzUY()
  VVaKg1 = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VVt717(decodedUrl)
      if fName:
       if   FFimkp(decodedUrl) : sType = "Movie"
       elif FFfMNU(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VVHFre(decodedUrl, fName)
       if size > -1: sizeTxt = CC5iId.VVp3Jg(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVaKg1.append((str(len(VVaKg1) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVaKg1
 def VVuA6N(self):
  VVaKg1 = self.VVBtRJ()
  if VVaKg1:
   if self.VVzzNZ : self.VVzzNZ.VV311O(VVaKg1, VV3PMMMsg=False)
   else     : self.VVzzNZ = self.VVX5o8(VVaKg1)
  else:
   self.cancel()
 def VV5tGE(self, force=False):
  if self.VVzzNZ:
   thrListUrls = self.VVaLnz()
   VVaKg1 = []
   changed = False
   for ndx, row in enumerate(self.VVzzNZ.VVMHVB()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVBUry
    if m3u8Log:
     percent = CCPYn3.VVTiyR(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVqwEj , "%.2f %%" % percent
      else   : flag, progr = self.VVAP68 , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFotbw(mPath)
     if curSize > -1:
      fSize = CC5iId.VVp3Jg(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CC5iId.VVp3Jg(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFotbw(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVqwEj , "%.2f %%" % percent
       else   : flag, progr = self.VVAP68 , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CC5iId.VVp3Jg(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VV2jZE
     if m3u8Log :
      if not speed and not force : flag = self.VVLZ3S
      elif curSize == -1   : self.VVMvH3(False)
    elif flag == self.VVBUry  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVBUry  : color2 = "#f#00555555#"
    elif flag == self.VVLZ3S : color2 = "#f#0000FFFF#"
    elif flag == self.VV2jZE : color2 = "#f#0000FFFF#"
    elif flag == self.VVqwEj  : color2 = "#f#00FF8000#"
    elif flag == self.VVAP68  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VV8aBQ(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVaKg1.append(row)
   if changed or force:
    self.VVzzNZ.VV311O(VVaKg1, VV3PMMMsg=False)
 def VV8aBQ(self, flag):
  tDict = self.VVehru()
  return tDict.get(flag, "?")
 def VVKqOQ(self, state):
  for flag, txt in self.VVehru().items():
   if txt == state:
    return flag
  return -1
 def VVehru(self):
  return { self.VVBUry: "Not started", self.VVLZ3S: "Connecting", self.VV2jZE: "Downloading", self.VVqwEj: "Stopped", self.VVAP68: "Completed" }
 def VVaeyz(self, title):
  colList = self.VVzzNZ.VVQ0F0()
  path = colList[6]
  url  = colList[8]
  if self.VV9wRq() : self.VVwnxh("Cannot delete !\n\nFile is downloading.")
  else      : FFEN35(self.SELF, BF(self.VV1Sra, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV1Sra(self, path, url):
  m3u8Log = self.VVzzNZ.VVQ0F0()[12]
  if m3u8Log : FFkQDN("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFkQDN("rm -rf '%s'" % path)
  self.VVIRZD(False)
  self.VVuA6N()
 def VVIRZD(self, VVg3ap=True):
  if self.VV9wRq():
   FFrBcM(self.VVzzNZ, self.VV8aBQ(self.VV2jZE), 500)
  else:
   colList  = self.VVzzNZ.VVQ0F0()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVKqOQ(state) in (self.VVBUry, self.VVAP68, self.VVqwEj):
    lines = CCPYn3.VVOzUY()
    newLines = []
    found = False
    for line in lines:
     if CCPYn3.VVW0xm(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVpUWA(newLines)
     self.VVuA6N()
     FFrBcM(self.VVzzNZ, "Removed.", 1000)
    else:
     FFrBcM(self.VVzzNZ, "Not found.", 1000)
   elif VVg3ap:
    self.VVwnxh("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVu2AT(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFEN35(self.SELF, BF(self.VVXIN8, flag), ques, title=title)
 def VVXIN8(self, flag):
  list = []
  for ndx, row in enumerate(self.VVzzNZ.VVMHVB()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVKqOQ(state)
   if   flag == flagVal == self.VVAP68: list.append(decodedUrl)
   elif flag == flagVal == self.VVBUry : list.append(decodedUrl)
  lines = CCPYn3.VVOzUY()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVpUWA(newLines)
   self.VVuA6N()
   FFrBcM(self.VVzzNZ, "%d removed." % totRem, 1000)
  else:
   FFrBcM(self.VVzzNZ, "Not found.", 1000)
 def VVTRKM(self):
  colList  = self.VVzzNZ.VVQ0F0()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FFrBcM(self.VVzzNZ, "Poster exists", 1500)
  else    : FFn5td(self.VVzzNZ, BF(self.VVxu9T, decodedUrl, path, png), title="Checking Server ...")
 def VVxu9T(self, decodedUrl, path, png):
  err = self.VVorju(decodedUrl, path, png)
  if err:
   FFBsVa(self.SELF, err, title="Poster Download")
 def VVorju(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCUYQq.VVe6L6(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CCnYqq.VVG1o6(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CCnYqq.VVHdcN(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CCnYqq.VVXW81(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFjgmp(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFkQDN("mv -f '%s' '%s'" % (tPath, png))
   CCSQFA.VV9tRL(self.SELF, VVukle=png, showGrnMsg="Downloaded")
   return ""
 def VVM9uu(self, VVzzNZ, title, txt, colList):
  def VVdl9w(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVIsuR(key, val) : return "\n%s:\n%s\n" % (FFxrb0(key, VVwwau), val.strip())
  heads  = self.VVzzNZ.VV4x5I()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVdl9w(heads[i]  , CC5iId.VVp3Jg(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVdl9w("Downloaded" , CC5iId.VVp3Jg(int(curSize), mode=0))
   else:
    txt += VVdl9w(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVIsuR(heads[i], colList[i])
  FFVBx2(self.SELF, txt, title=title)
 def VVVXgM(self, VVzzNZ, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CC5iId.VV0HP2(self.SELF, path)
  else    : FFrBcM(self.VVzzNZ, "File not found", 1000)
 def VVyPp8(self, VVzzNZ):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVzzNZ:
   self.VVzzNZ.cancel()
  del self
 def VVdtU4(self, VVzzNZ, title, txt, colList):
  c1, c2, c3 = VVOICC, VVmxw7, VVwwau
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVtZf8 = []
  VVtZf8.append((c1 + "Remove current row"       , "VVIRZD" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVtZf8.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c2 + "Delete the file (and remove from list)"  , "VVaeyz"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((resumeTxt + " Auto Resume"       , "VVPbqA" ))
  VVtZf8.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVtZf8.append(VVh3VV)
  cond = FFimkp(decodedUrl)
  VVtZf8.append(FFTjqa("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVTRKM", cond, c3))
  VVtZf8.append(FFTjqa("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFd7BR(self.SELF, BF(self.VVaeKL, VVzzNZ), VVtZf8=VVtZf8, title=self.Title, VVkmYm=True, width=800, VVh2Zj=True, VVRmfT="#1a001122", VVRNJt="#1a001122")
 def VVaeKL(self, VVzzNZ, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVIRZD"  : self.VVIRZD()
   elif ref == "remFinished"   : self.VVu2AT(self.VVAP68, txt)
   elif ref == "remPending"   : self.VVu2AT(self.VVBUry, txt)
   elif ref == "VVaeyz" : self.VVaeyz(txt)
   elif ref == "VVTRKM"  : self.VVTRKM()
   elif ref == "VVPbqA"  : FFSeyu(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFSeyu(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CC5iId, mode=CC5iId.VVL251, jumpToFile=path)
    else    : FFrBcM(VVzzNZ, "Path not found !", 1500)
 def VV9bcG(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCUYQq.VVe6L6(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVwnxh("Could not get download link !\n\nTry again later.")
     return
  for line in CCPYn3.VVOzUY():
   if CCPYn3.VVW0xm(decodedUrl, line):
    if self.VVzzNZ:
     self.VVvBXy(decodedUrl)
     FFb5Nn(BF(FFrBcM, self.VVzzNZ, "Already listed !", 2000))
    break
  else:
   params = self.VVv1hB(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVwnxh(params[0])
   elif len(params) == 2:
    FFEN35(self.SELF, BF(self.VVUnso, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CC5iId.VVp3Jg(fSize)
    FFEN35(self.SELF, BF(self.VVif76, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVif76(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCPYn3.VV1i3O(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVuA6N()
  if self.VVzzNZ:
   self.VVzzNZ.VVSXho()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCPYn3.VVdNgs, path, decodedUrl)
   self.VVXOX9(threadName, url, decodedUrl, path, resp)
 def VVvBXy(self, decodedUrl):
  if self.VVzzNZ:
   for ndx, row in enumerate(self.VVzzNZ.VVMHVB()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVzzNZ:
     self.VVzzNZ.VV8i74(ndx)
     break
 def VVv1hB(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VVt717(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VVHFre(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCUYQq.VVe6L6(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCUYQq.VVsU6U()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCPYn3.VVNkFE(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCPYn3.VVnWpW(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVUnso(self, resp, decodedUrl):
  if not FFtTXa("ffmpeg"):
   FFEN35(self.SELF, BF(CCnYqq.VVwckU, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VVt717(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VV6ymy(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFEN35(self.SELF, BF(self.VV49rV, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VV49rV(rTxt, rUrl)
  else:
   self.VVwnxh("Cannot process m3u8 file !")
 def VV6ymy(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVtZf8 = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CCnYqq.VVP1Xe(rUrl, fPath)
   VVtZf8.append((resol, fullUrl))
  if VVtZf8:
   FFd7BR(self.SELF, self.VVKyvC, VVtZf8=VVtZf8, title="Resolution", VVkmYm=True, VVh2Zj=True)
  else:
   self.VVwnxh("Cannot get Resolutions list from server !")
 def VVKyvC(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFEN35(self.SELF, BF(FFb5Nn, BF(self.VVxtBu, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFb5Nn(BF(self.VVxtBu, resolUrl))
 def VVxtBu(self, resolUrl):
  txt, err = CCUYQq.VVmVts(resolUrl)
  if err : self.VVwnxh(err)
  else : self.VV49rV(txt, resolUrl)
 def VVYjxD(self, logF, decodedUrl):
  found = False
  lines = CCPYn3.VVOzUY()
  with open(CCPYn3.VV1i3O(), "w") as f:
   for line in lines:
    if CCPYn3.VVW0xm(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCPYn3.VV1i3O(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVuA6N()
  if self.VVzzNZ:
   self.VVzzNZ.VVSXho()
 def VV49rV(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CCnYqq.VVP1Xe(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVwnxh("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVYjxD(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFaBql("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCPYn3.VVdNgs, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVTiyR(dnldLog):
  if fileExists(dnldLog):
   dur = CCPYn3.VVXbMf(dnldLog)
   if dur > -1:
    tim = CCPYn3.VVmxNc(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVXbMf(dnldLog):
  lines = FFIM7p("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVmxNc(dnldLog):
  lines = FFIM7p("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VVHFre(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFfMNU(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFkQDN("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVXOX9(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVzzNZ.VVQ0F0()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VV56Ne, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV56Ne(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVmyA8 == path:
       break
     else:
      break
  except:
   return
  if CCPYn3.VVmyA8:
   CCPYn3.VVmyA8 = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFotbw(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVv1hB(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV56Ne(url, decodedUrl, path, resp, totFileSize, True)
 def VVJerg(self, VVzzNZ, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVUyBh() : FFrBcM(self.VVzzNZ, self.VV8aBQ(self.VVAP68), 500)
  elif not self.VV9wRq() : FFrBcM(self.VVzzNZ, self.VV8aBQ(self.VVqwEj), 500)
  elif m3u8Log      : FFEN35(self.SELF, self.VVMvH3, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVaLnz():
    CCPYn3.VVmyA8 = colList[6]
    FFrBcM(self.VVzzNZ, "Stopping ...", 1000)
   else:
    FFrBcM(self.VVzzNZ, "Stopped", 500)
 def VVMvH3(self, withMsg=True):
  if withMsg:
   FFrBcM(self.VVzzNZ, "Stopping ...", 1000)
  FFkQDN("killall -INT ffmpeg")
 def VVW9CV(self, *args):
  if   self.VVUyBh() : FFrBcM(self.VVzzNZ, self.VV8aBQ(self.VVAP68) , 500)
  elif self.VV9wRq() : FFrBcM(self.VVzzNZ, self.VV8aBQ(self.VV2jZE), 500)
  else:
   resume = False
   m3u8Log = self.VVzzNZ.VVQ0F0()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFEN35(self.SELF, BF(self.VVT5v7, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVPGle():
    resume = True
   if resume: FFn5td(self.VVzzNZ, BF(self.VVidHo), title="Checking Server ...")
   else  : FFrBcM(self.VVzzNZ, "Cannot resume !", 500)
 def VVT5v7(self, m3u8Log):
  FFkQDN("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FFn5td(self.VVzzNZ, BF(self.VVidHo), title="Checking Server ...")
 def VVidHo(self):
  colList  = self.VVzzNZ.VVQ0F0()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCUYQq.VVe6L6(decodedUrl)
   if url:
    decodedUrl = self.VVWf0r(decodedUrl, url)
   else:
    self.VVwnxh("Could not get download link !\n\nTry again later.")
    return
  curSize = FFotbw(path)
  params = self.VVv1hB(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVwnxh(params[0])
   return
  elif len(params) == 2:
   self.VVUnso(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVWf0r(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCPYn3.VVdNgs, path, decodedUrl)
  if resumable: self.VVXOX9(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVwnxh("Cannot resume from server !")
 def VVt717(self, decodedUrl):
  fileExt = CCnYqq.VVufCo(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFbuxP(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVwnxh(self, txt):
  FFBsVa(self.SELF, txt, title=self.Title)
 def VVaLnz(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCPYn3.VVdNgs, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VV9wRq(self):
  decodedUrl = self.VVzzNZ.VVQ0F0()[9]
  return decodedUrl in self.VVaLnz()
 def VVUyBh(self):
  colList = self.VVzzNZ.VVQ0F0()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFotbw(path)) == size
 def VVPGle(self):
  colList = self.VVzzNZ.VVQ0F0()
  path = colList[6]
  size = int(colList[7])
  curSize = FFotbw(path)
  if curSize > -1:
   size -= curSize
  err = CCPYn3.VVnWpW(size)
  if err:
   FFBsVa(self.SELF, err, title=self.Title)
   return False
  return True
 def VVpUWA(self, list):
  with open(CCPYn3.VV1i3O(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVWf0r(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCPYn3.VVOzUY()
  url = decodedUrl
  with open(CCPYn3.VV1i3O(), "w") as f:
   for line in lines:
    if CCPYn3.VVW0xm(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVuA6N()
  return url
 @staticmethod
 def VVOzUY():
  list = []
  if fileExists(CCPYn3.VV1i3O()):
   for line in FFMy5k(CCPYn3.VV1i3O()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVW0xm(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVnWpW(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CC5iId.VVpbj4(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CC5iId.VVp3Jg(size), CC5iId.VVp3Jg(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVTxFL(SELF):
  tot = CCPYn3.VVM9Nw()
  if tot:
   FFBsVa(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVM9Nw():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCPYn3.VVdNgs):
    c += 1
  return c
 @staticmethod
 def VVcE5p():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCPYn3.VVdNgs, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVCizW():
  return len(CCPYn3.VVOzUY()) == 0
 @staticmethod
 def VVHSVs():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVe9l4():
  mPoints = CCPYn3.VVHSVs()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFkQDN("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VV1i3O():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVYez0(SELF, waitMsgObj=None):
  FFn5td(waitMsgObj or SELF, BF(CCPYn3.VVdFPg, SELF, CCPYn3.VVpuM7))
 @staticmethod
 def VVIUjC(SELF):
  CCPYn3.VVdFPg(SELF, CCPYn3.VVu8eC, startDnld=True)
 @staticmethod
 def VV6KOI(SELF, url):
  CCPYn3.VVdFPg(SELF, CCPYn3.VVu8eC, startDnld=True, decodedUrl=url)
 @staticmethod
 def VV8UPe(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(SELF)
  added, skipped = CCPYn3.VVyPEm([decodedUrl])
  FFrBcM(SELF, "Added", 1000)
 @staticmethod
 def VVyPEm(list):
  added = skipped = 0
  for line in CCPYn3.VVOzUY():
   for ndx, url in enumerate(list):
    if url and CCPYn3.VVW0xm(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCPYn3.VV1i3O(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVdFPg(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CC9WBQ.VVC1gJ(SELF):
   return
  if mode == CCPYn3.VVpuM7 and CCPYn3.VVCizW():
   FFBsVa(SELF, "Download list is empty !", title=title)
  else:
   inst = CCPYn3(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VVNkFE(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCQFZI(Screen, CCRdJH):
 VVU617 = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FF98gL(VVWBOt, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCRdJH.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFd98D(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVb3bW())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(VVO7iZ,
  {
   "ok"  : self.VVnIt0       ,
   "info"  : self.VVbdfc      ,
   "epg"  : self.VVbdfc      ,
   "menu"  : self.VVcx1n     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVdpJS   ,
   "green"  : self.VV9QTz  ,
   "blue"  : self.VV08w5      ,
   "yellow" : self.VVy0Ri ,
   "left"  : BF(self.VV2KHD, -1)    ,
   "right"  : BF(self.VV2KHD,  1)    ,
   "play"  : self.VVViX0      ,
   "pause"  : self.VVViX0      ,
   "playPause" : self.VVViX0      ,
   "stop"  : self.VVViX0      ,
   "rewind" : self.VV5LBn      ,
   "forward" : self.VVGRWr      ,
   "rewindDm" : self.VV5LBn      ,
   "forwardDm" : self.VVGRWr      ,
   "last"  : self.VVKgrD      ,
   "next"  : self.VVj7f6      ,
   "pageUp" : BF(self.VV6L3p, True)  ,
   "pageDown" : BF(self.VV6L3p, False)  ,
   "chanUp" : BF(self.VV6L3p, True)  ,
   "chanDown" : BF(self.VV6L3p, False)  ,
   "up"  : BF(self.VV6L3p, True)  ,
   "down"  : BF(self.VV6L3p, False)  ,
   "audio"  : BF(self.VVXPAx, True)  ,
   "subtitle" : BF(self.VVXPAx, False)  ,
   "text"  : self.VVi17W  ,
   "0"   : BF(self.VVpjGC , 10)   ,
   "1"   : BF(self.VVpjGC , 1)   ,
   "2"   : BF(self.VVpjGC , 2)   ,
   "3"   : BF(self.VVpjGC , 3)   ,
   "4"   : BF(self.VVpjGC , 4)   ,
   "5"   : BF(self.VVpjGC , 5)   ,
   "6"   : BF(self.VVpjGC , 6)   ,
   "7"   : BF(self.VVpjGC , 7)   ,
   "8"   : BF(self.VVpjGC , 8)   ,
   "9"   : BF(self.VVpjGC , 9)
  }, -1)
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFD5nM(self)
  if not CCQFZI.VVU617:
   CCQFZI.VVU617 = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFBFvR(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFBFvR(self["myPlayRpt"], "rpt")
  self.VVNcWs()
  self.instance.move(ePoint(40, 40))
  self.VVqtYb(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVTxHJ)
  except:
   self.timer.callback.append(self.VVTxHJ)
  self.timer.start(250, False)
  self.VVTxHJ("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVveFq()
 def VV9QTz(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  self.lastSubtitle = CCAayk.VVDyQr()
  if "chCode" in iptvRef:
   if CC9WBQ.VVC1gJ(self):
    self.VVveFq(True)
  else:
   self.VVTxHJ("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVNcWs(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVeHYo()
  chName = FFpnOy(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVD46d + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFwVrd(self["myTitle"], tColor)
  FFwVrd(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFwVrd(self["myPlay%s" % item], tColor)
  picFile = CCFLza.VV5Cfc(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCFLza.VVFSSe(self)
  cl = CCmJoX.VVlbww(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVTxHJ(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCPYn3.VVM9Nw()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVeHYo()
  if evName:
   evName = "    %s    " % FFxrb0(evName, VVUpvF)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VV8JgQ():
   FFBe4X(self["myPlayBlu"], "#00FFFFFF")
   FFwVrd(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFBe4X(self["myPlayBlu"], "#00FFFF88")
   FFwVrd(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CCnYqq.VV1wlX(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VVi96Z + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFwVrd(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFMpNv(percVal, 0, 100)
   width = int(FFUY5i(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFwVrd(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFBe4X(self["myPlayMsg"], "#0000ffff")
   else  : FFBe4X(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFBe4X(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFBe4X(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VVWdsf()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VV1vG4(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CCAayk.VVb8VR(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVKgrD()
  state = self.VVaNz3()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFBe4X(self["myPlayMsg"], "#0000ff00")
  else     : FFBe4X(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVeHYo(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFMcRT(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCQFZI.VVYaVF(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCFLza.VVrN9T(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCTy0v()
   tpTxt, satTxt = tp.VVEwnw(refCode)
   self.satInfo_TP = tpTxt + "  " + FFxrb0(satTxt, VVquhO)
  evName = evNameNext = ""
  evLst = CCNVQf.VV2bd1(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFlSvn(info, iServiceInformation.sVideoWidth) or -1
   h = FFlSvn(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFlSvn(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCFLza.VV5brb(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVYaVF(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FFNguX(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FFNguX(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FFNguX(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VVcx1n(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVeHYo()
  FFimkpSeries = FFbuxP(decodedUrl)
  VVtZf8 = []
  if not "VVbP73" in globals() and not "VVts4W" in globals():
   VVtZf8.append((VVquhO + "IPTV Menu", "iptv"))
   VVtZf8.append(VVh3VV)
  if isIptv and not "&end=" in decodedUrl and not FFimkpSeries:
   uType, uHost, uUser, uPass, uId, uChName = CCnYqq.VVG1o6(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVtZf8.append((VVquhO + "Catchup Programs", "catchup" ))
    VVtZf8.append(VVh3VV)
  if refCode:
   c = VVD46d
   VVtZf8.append((c + "Stop Current Service"  , "stop"  ))
   VVtZf8.append((c + "Restart Current Service" , "restart"  ))
   VVtZf8.append(FFTjqa("Replay with ..." , "replayWith", not isDvb, c))
   VVtZf8.append(VVh3VV)
  if FFimkpSeries:
   VVtZf8.append((VVquhO + "File Size (on server)", "fileSize" ))
   VVtZf8.append(VVh3VV)
  if self.enableDownloadMenu:
   c = VVquhO
   addSep = False
   if isIptv and FFimkpSeries:
    VVtZf8.append((c + "Start Download"  , "dload_cur" ))
    VVtZf8.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCPYn3.VVCizW():
    VVtZf8.append((VVquhO + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVtZf8.append(VVh3VV)
  fPath, fDir, fName = CC5iId.VVOhYP(self)
  if fPath:
   c = VVs7I8
   if not "VVyR2u" in globals():
    VVtZf8.append((c + "Open path in File Manager", "VVNTBv"))
   VVtZf8.append((c + "Add to Bouquet"             , "VVuQwR" ))
   VVtZf8.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VVcvEn"  ))
   VVtZf8.append(VVh3VV)
  elif isFtp:
   VVtZf8.append((VVwwau + "Add FTP Media to Bouquet"     , "VVNJQx"))
  if isDvb:
   VVtZf8.append((VVquhO + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVtZf8.append((VVwwau + "Start Subtitle", "VVprOb"))
   VVtZf8.append(VVh3VV)
  if CFG.playerPos.getValue() : VVtZf8.append(("Move Bar to Bottom" , "botm"))
  else      : VVtZf8.append(("Move Bar to Top" , "top" ))
  VVtZf8.append(("Help", "help"))
  FFd7BR(self, self.VVEFsC, VVtZf8=VVtZf8, width=600, title="Options")
 def VVEFsC(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVy0Ri()
   elif item == "stop"     : self.VVzO8p(0)
   elif item == "restart"    : self.VVzO8p(1)
   elif item == "replayWith"   : self.VVHxWX()
   elif item == "fileSize"    : FFn5td(self, BF(CCFLza.VVbbSJ, self), title="Checking Server")
   elif item == "dload_cur"   : CCPYn3.VVIUjC(self)
   elif item == "addToDload"   : CCPYn3.VV8UPe(self)
   elif item == "dload_stat"   : CCPYn3.VVYez0(self)
   elif item == "VVNTBv" : self.close("close_openInFileMan")
   elif item == "VVuQwR" : self.VVuQwR()
   elif item == "VVNJQx" : self.VVNJQx()
   elif item == "VVprOb"  : self.VVplEc()
   elif item == "VVcvEn"  : self.VVcvEn()
   elif item == "botm"     : self.VVqtYb(0)
   elif item == "top"     : self.VVqtYb(1)
   elif item == "sigMon"    : self.VVdpJS()
   elif item == "help"     : FF4fCC(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCQFZI.VVU617 = None
 def VVzO8p(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVNcWs()
   elif typ == 1:
    self.VVTxHJ("Restarting Service ...")
    FFb5Nn(BF(self.VV8DRU, serv))
 def VV8DRU(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  if "&end=" in decodedUrl: BF(self.VVveFq, True)
  else     : self.session.nav.playService(serv)
 def VVHxWX(self):
  FFd7BR(self, self.VVLkK2, VVtZf8=CCnYqq.VVJ1iq(), width=650, title="Select Player", VVRmfT="#11220000", VVRNJt="#11220000")
 def VVLkK2(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFgdxP(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVTxHJ("No active service !")
 def VVuQwR(self):
  fPath, fDir, fName = CC5iId.VVOhYP(self)
  if fPath: picker = CCQq9Y(self, self, "Add Current Movie to a Bouquet", BF(self.VVwJEh, [fPath]))
  else : FFrBcM(self, "Path not found !", 1500)
 def VVwJEh(self, pathLst):
  return CCQq9Y.VVkpUX(pathLst)
 def VVNJQx(self):
  picker = CCQq9Y(self, self, "Add FTP Media to Bouquet", self.VV2REf)
 def VV2REf(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  return CCQq9Y.VVkpUX([origUrl], rType=refCode.split(":", 1)[0])
 def VVcvEn(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCQFZI.VVYaVF(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVTxHJ(txt, highlight=ok)
 def VVqtYb(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFSeyu(CFG.playerPos, pos)
 def VVdpJS(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCFLza.VVrN9T(serv)
   if isDvb: self.close("close_sig")
   else : self.VVTxHJ("No Signal for Current Service")
 def VVplEc(self):
  self.session.openWithCallback(self.VVMCJ7, BF(CCAayk))
 def VVi17W(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVeHYo()
   if posTxt and durTxt: self.VVplEc()
   else    : self.VVTxHJ("No duration Info. !")
 def VVMCJ7(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VV6L3p(True)
  elif reason == "subtZapDn" : self.VV6L3p(False)
  elif reason == "pause"  : self.VVViX0()
  elif reason == "audio"  : self.VVXPAx(True)
  elif reason == "subtitle" : self.VVXPAx(False)
  elif reason == "rewind"     : self.VV5LBn()
  elif reason == "forward" : self.VVGRWr()
  elif reason == "rewindDm" : self.VV5LBn()
  elif reason == "forwardDm" : self.VVGRWr()
  else      : txt = reason
  if txt:
   FFrBcM(self, txt, 2000)
 def VVnIt0(self):
  if self.isManualSeek:
   self.VVT2SA()
   self.VV1vG4(self.manualSeekPts)
  elif self.shown:
   if CCAayk.VVvjwu(self): self.VVplEc()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVT2SA()
  else    : self.close()
 def VVbdfc(self):
  FFqy2T(self, fncMode=CCFLza.VV6QPG)
 def VVViX0(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVTxHJ("Toggling Play/Pause ...")
 def VVT2SA(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VV2KHD(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCQFZI.VVYaVF(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVjXoE()
   else:
    self.manualSeekSec += direc * self.VVjXoE()
    self.manualSeekSec = FFMpNv(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FFUY5i(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FFNguX(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVpjGC(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVb3bW())
   FFSeyu(CFG.playerJumpMin, self.jumpMinutes)
  self.VVTxHJ("Changed Seek Time to : %d%s" % (val, self.VVQ7ud()))
 def VVb3bW(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VVQ7ud())
 def VVQ7ud(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVuqbS(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVjXoE(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VVWdsf(self):
  if "VVxqvp" in globals():
   global VVxqvp
   if VVxqvp:
    VVxqvp = VVxqvp[1:-1]
    if len(VVxqvp) == 3: VVxqvp = ""
    else     : return VVxqvp
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VV08w5(self):
  cList = self.VV8JgQ()
  if cList:
   VVtZf8 = []
   for pts, what in cList:
    txt = FFNguX(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVtZf8.append((txt, pts))
   FFd7BR(self, self.VV5uft, VVtZf8=VVtZf8, title="Cut List")
  else:
   self.VVTxHJ("No Cut-List for this channel !")
 def VV5uft(self, item=None):
  if item:
   self.VV1vG4(item)
 def VV8JgQ(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVGRWr(self) : self.VVThIe(1)
 def VV5LBn(self) : self.VVThIe(-1)
 def VVThIe(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCQFZI.VVYaVF(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVjXoE() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVuqbS())
    self.VVTxHJ(txt)
  except:
   self.VVTxHJ("Cannot jump")
 def VV1vG4(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVTxHJ("Changing Time ...")
 def VVKgrD(self):
  self.VVzO8p(1)
  self.VVTxHJ("Replaying ...")
  self.VVT2SA()
 def VVj7f6(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCQFZI.VVYaVF(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVTxHJ("Jumping to end ...")
  except:
   pass
 def VVaNz3(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VV6L3p(self, isUp):
  if self.enableZapping:
   self.VVTxHJ("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVT2SA()
   if self.iptvTableParams:
    FFb5Nn(BF(self.VVmlYN, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
    if "/timeshift/" in decodedUrl:
     self.VVTxHJ("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVl3cG()
  else:
   self.VVTxHJ("Zap Disabled !")
 def VVl3cG(self):
  self.lastPlayPos = 0
  self.VVNcWs()
  self.VVveFq()
 def VVmlYN(self, isUp):
  CCnYqq_inatance, VVzzNZ, mode = self.iptvTableParams
  if isUp : VVzzNZ.VVT50f()
  else : VVzzNZ.VV3DuO()
  colList = VVzzNZ.VVQ0F0()
  if mode == "localIptv":
   chName, chUrl = CCnYqq_inatance.VVcWQE(VVzzNZ, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CCnYqq_inatance.VV70uW(VVzzNZ, colList)
  elif isinstance(mode, int):
   chName, chUrl = CCnYqq_inatance.VVNaQX(mode, VVzzNZ, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CCnYqq_inatance.VV4uFi(mode, VVzzNZ, colList)
  else:
   self.VVTxHJ("Cannot Zap")
   return
  FFYeVI(self, chUrl, VVY16B=False)
  self.VVl3cG()
 def VVveFq(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCQFZI.VVYaVF(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
   if not self.VVIvWO(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVTxHJ("Refreshing Portal")
   FFb5Nn(self.VVcdxF)
  except:
   pass
 def VVcdxF(self):
  self.restoreLastPlayPos = self.VV7Ph5()
 def VVy0Ri(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
  if not decodedUrl or FFbuxP(decodedUrl):
   self.VVTxHJ("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CCnYqq.VVG1o6(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVTxHJ("Reading Program List ...")
   ok_fnc = BF(self.VVMC6g, refCode, chName, streamId, uHost, uUser, uPass)
   FFb5Nn(BF(CCnYqq.VViIN3, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVTxHJ("Cannot process this channel")
 def VVMC6g(self, refCode, chName, streamId, uHost, uUser, uPass, VVzzNZ, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVzzNZ.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVTxHJ("Changing Program ...")
   FFb5Nn(BF(self.VVRILV, chUrl))
  else:
   self.VVTxHJ("Incorrect Timestamp !")
 def VVRILV(self, chUrl):
  FFYeVI(self, chUrl, VVY16B=False)
  self.lastPlayPos = 0
  self.VVNcWs()
 def VVXPAx(self, isAudio):
  try:
   VVjKXg = InfoBar.instance
   if VVjKXg:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVjKXg)
    else  : self.session.open(SubtitleSelection, VVjKXg)
  except:
   pass
 @staticmethod
 def VVTaRm(session, mode=None):
  if   mode == "close_sig"   : FF1dfA(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CCnYqq)
  elif mode == "close_openInFileMan" : session.open(CC5iId, gotoMovie=True)
 @staticmethod
 def VVbh0Z(session, **kwargs):
  session.openWithCallback(BF(CCQFZI.VVTaRm, session), CCQFZI, **kwargs)
class CCupAT(Screen):
 def __init__(self, session, title="", VVub3W="Continue?", VVls2R=True, VV00ww=False):
  self.skin, self.skinParam = FF98gL(VVCp4o, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVub3W = VVub3W
  self.VV00ww = VV00ww
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVls2R : VVtZf8 = [no , yes]
  else   : VVtZf8 = [yes, no ]
  FFd98D(self, title, VVtZf8=VVtZf8, addLabel=True)
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok" : self.VVnIt0 ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVub3W)
  if self.VV00ww:
   self["myLabel"].instance.setHAlign(0)
  self.VVsDCm()
  FFzlUl(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFfsUc(self["myMenu"])
  FFrgYT(self, self["myMenu"])
 def VVnIt0(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVsDCm(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCeDmK(Screen):
 def __init__(self, session, title="", VVtZf8=None, width=1000, height=850, VVJgEp=30, barText="", minRows=1, VVoeva=None, VVlTMa=None, VV8QNc=None, VVA2fW=None, VVJlf7=None, VVR5O9=None, VVkmYm=False, VVh2Zj=False, VVK9oq=None, VVbj8e=True, VVRmfT="#22003344", VVRNJt="#22002233"):
  self.skin, self.skinParam = FF98gL(VVL2J2, width, height, 50, 40, 30, VVRmfT, VVRNJt, VVJgEp, barHeight=40, topRightBtns=3 if VVlTMa else 0)
  self.session   = session
  self.VVtZf8   = VVtZf8
  self.barText   = barText
  self.minRows   = minRows
  self.VVoeva   = VVoeva
  self.VVlTMa   = VVlTMa
  self.VV8QNc   = VV8QNc
  self.VVA2fW  = VVA2fW
  self.VVJlf7  = ("Delete File", BF(self.VV5yC8, VVK9oq)) if not VVK9oq is None else VVJlf7
  self.VVR5O9   = VVR5O9
  self.VVkmYm  = VVkmYm
  self.VVh2Zj  = VVh2Zj
  self.Title    = title
  FFd98D(self, title, VVtZf8=VVtZf8)
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok"  : self.VVnIt0    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVryP3   ,
   "red"  : self.VVvAvZ   ,
   "green"  : self.VVCzGJ   ,
   "yellow" : self.VVfbxi   ,
   "blue"  : self.VVsgyo   ,
   "pageUp" : self.VVvZaA ,
   "chanUp" : self.VVvZaA ,
   "pageDown" : self.VVA4m7  ,
   "chanDown" : self.VVA4m7  ,
   "0"   : BF(self.VVz7FF, 0) ,
   "1"   : BF(self.VVz7FF, 1) ,
   "2"   : BF(self.VVz7FF, 2) ,
   "3"   : BF(self.VVz7FF, 3) ,
   "4"   : BF(self.VVz7FF, 4) ,
   "5"   : BF(self.VVz7FF, 5) ,
   "6"   : BF(self.VVz7FF, 6) ,
   "7"   : BF(self.VVz7FF, 7) ,
   "8"   : BF(self.VVz7FF, 8) ,
   "9"   : BF(self.VVz7FF, 9)
  }, -1)
  if VVbj8e:
   FFcKND(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFzlUl(self["myMenu"])
  FFzxez(self, minRows=self.minRows)
  FFD5nM(self)
  self.VVdCRf(self["keyRed"]  , self.VV8QNc )
  self.VVdCRf(self["keyGreen"] , self.VVA2fW )
  self.VVdCRf(self["keyYellow"] , self.VVJlf7 )
  self.VVdCRf(self["keyBlue"]  , self.VVR5O9 )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFRet2(self)
 def VVdCRf(self, btnObj, btnFnc):
  if btnFnc:
   FF1N71(btnObj, btnFnc[0])
 def VVXyYg(self, fnc=None):
  self.VVA2fW = fnc
  if fnc : self.VVdCRf(self["keyGreen"], self.VVA2fW)
  else : self["keyGreen"].hide()
 def VVz7FF(self, digit):
  digit = str(digit)
  VVtZf8 = self["myMenu"].list
  for ndx, item in enumerate(VVtZf8):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFpnOy(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VVIgUV(ndx)
     self.VVnIt0()
     break
 def VVnIt0(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVoeva:
    self.VVoeva((self, txt, ref, ndx))
   else:
    if self.VVkmYm: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVryP3(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVlTMa and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVlTMa(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVvAvZ(self)  : self.VVNCLs(self.VV8QNc)
 def VVCzGJ(self) : self.VVNCLs(self.VVA2fW)
 def VVfbxi(self) : self.VVNCLs(self.VVJlf7)
 def VVsgyo(self) : self.VVNCLs(self.VVR5O9)
 def VVNCLs(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVh2Zj:
    self.cancel()
 def VV9YzJ(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVtZf8 = self["myMenu"].list
  VVtZf8.pop(ndx)
  if len(VVtZf8) > 0: self["myMenu"].setList(VVtZf8)
  else    : self.close()
 def VV5yC8(self, basePath, menuObj, fName):
  FFEN35(self, BF(self.VVLvVf, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVLvVf(self, path):
  FFKqXn(path)
  if fileExists(path) : FFrBcM(self, "Not deleted", 1000)
  else    : self.VV9YzJ()
 def VVKpZT(self, VVtZf8):
  if len(VVtZf8) > 0:
   newList = []
   for item in VVtZf8:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFzxez(self, minRows=self.minRows)
  else:
   self.close("")
 def VVBwiX(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFzxez(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVfuHV(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VVIgUV(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVsNSx(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VVIgUV(ndx)
    break
 def VV7hwP(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VVIgUV(ndx)
    break
 def VVvZaA(self) : self["myMenu"].moveToIndex(0)
 def VVA4m7(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCLGNO(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVBQW6=None, VVGQvW=None, VV3FCq=None, VVJgEp=26, isEditor=False, addSort=True, VV3cto=False, VVFsq0=0, picParams=None, VVTXLQ=None, VVZRP4=None, menuButtonFnc=None, VVXfC8=None, VVIZTW=None, VVFaAj=None, VV6CVp=None, VV8TXR=None, VVeJ6x=None, VV0cge=None, VVtrG6=-1, VVhEUu=0, searchCol=0, lastFindConfigObj=None, VVRmfT="#22003344", VVRNJt="#22002233", VVz8JC="#00dddddd", VV84wP="#11002233", VVH7qA=None, VVvmBM="#11111111", borderWidth=1, VVfpy3="#0a555555", VVslIr="#0affffff", VViJnU="#11552200", VVR5ok="#0055ff55", VVR5okRev="#0000bbff"):
  self.skin, self.skinParam = FF98gL(VVNiyR, width, height, 50, 10, vMargin, VVRmfT, VVRNJt, 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFd98D(self, title)
  self.Title     = title
  self.header     = header
  self.VVBQW6     = VVBQW6
  self.totalCols    = len(VVBQW6[0])
  self.VVFsq0   = VVFsq0
  self.picParams    = picParams
  self.lastSortModeIsReverese = False
  self.VV3cto   = VV3cto
  self.VVK2GJ   = 0.01
  self.VV0RN2   = 0.02
  self.VV00We = 0.03
  self.VVYZjR  = 1
  self.VV3FCq = VV3FCq
  self.colWidthPixels   = []
  self.VVTXLQ   = VVTXLQ
  self.OKButtonObj   = None
  self.VVZRP4   = VVZRP4
  self.VVXfC8   = VVXfC8
  self.VVIZTW   = VVIZTW
  self.VVFaAj  = VVFaAj
  self.VV6CVp   = VV6CVp
  self.VV8TXR    = VV8TXR
  self.VVeJ6x   = VVeJ6x
  self.tableRefreshCB   = None
  self.VV0cge  = VV0cge
  self.menuButtonFnc   = menuButtonFnc
  self.VVtrG6    = VVtrG6
  self.VVhEUu   = VVhEUu
  self.searchCol    = searchCol
  self.VVGQvW    = VVGQvW
  self.keyPressed    = -1
  self.VVJgEp    = FFO4Er(VVJgEp)
  self.isEditor    = isEditor
  self.addSort    = addSort
  self.VV2u5U    = FFMSMB(self.VVJgEp, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVRmfT    = VVRmfT
  self.VVRNJt      = VVRNJt
  self.VVz8JC    = FFV5jv(VVz8JC)
  self.VV84wP    = FFV5jv(VV84wP)
  self.VVH7qA    = VVH7qA
  self.VVvmBM    = FFV5jv(VVvmBM)
  self.borderWidth   = borderWidth
  self.VVfpy3   = FFV5jv(VVfpy3)
  self.VVslIr    = FFV5jv(VVslIr)
  self.VViJnU    = FFV5jv(VViJnU)
  self.VVR5ok   = FFV5jv(VVR5ok)
  self.VVR5okRev  = FFV5jv(VVR5okRev)
  self.VVoCEo  = False
  self.selectedItems   = 0
  self.VVYKoJ   = FFV5jv("#06542132")
  self.onMultiSelFnc   = None
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVhEUu:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVhEUu == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok"  : self.VVA0L4  ,
   "red"  : self.VVojzs  ,
   "green"  : self.VV8cS5 ,
   "yellow" : self.VVzJAv ,
   "blue"  : self.VVHpQb  ,
   "menu"  : self.VVEBap ,
   "info"  : self.VVjHhQ  ,
   "cancel" : self.VVqPQg  ,
   "up"  : self.VV3DuO    ,
   "down"  : self.VVT50f  ,
   "left"  : self.VV4BB5   ,
   "right"  : self.VVjNpQ  ,
   "next"  : self.VVdmDv  ,
   "last"  : self.VVdLpM  ,
   "home"  : self.VVUJE3  ,
   "pageUp" : self.VVUJE3  ,
   "chanUp" : self.VVUJE3  ,
   "end"  : self.VVSXho  ,
   "pageDown" : self.VVSXho  ,
   "chanDown" : self.VVSXho
  }, -1)
  FFcKND(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFD5nM(self)
  try:
   self.VVTgaC()
  except Exception as e:
   FFBsVa(self, str(e), title=self.Title)
   self.close(None)
 def VVTgaC(self):
  FFRet2(self)
  self.VVdCRf(self.VVXfC8 , self["keyRed"])
  self.VVdCRf(self.VVIZTW , self["keyGreen"])
  self.VVdCRf(self.VVFaAj, self["keyYellow"])
  self.VVdCRf(self.VV6CVp , self["keyBlue"])
  if self.VVTXLQ:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVTXLQ[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVTXLQ[0])
    FFwVrd(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VV2u5U)
  self["myTableH"].l.setFont(0, gFont(VVQgMh, self.VVJgEp))
  self["myTable"].l.setItemHeight(self.VV2u5U)
  self["myTable"].l.setFont(0, gFont(VVQgMh, self.VVJgEp))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VV2u5U)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VV2u5U))
   self["myTable"].instance.resize(eSize(*(w, h - self.VV2u5U)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VV2u5U
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VV2u5U * len(self.VVBQW6) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VV3FCq:
   self.VV3FCq = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VV3FCq)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVGQvW:
   self.VVGQvW = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVGQvW
   self.VVGQvW = []
   for item in tmpList:
    self.VVGQvW.append(item | RT_VALIGN_CENTER)
  self.VVIaEV()
  if self.VV8TXR:
   self.VV8TXR(self)
 def VVdCRf(self, btnFnc, btn):
  if btnFnc : FF1N71(btn, btnFnc[0])
  else  : FF1N71(btn, "")
 def VVbHSA(self, waitTxt):
  FFn5td(self, self.VVIaEV, title=waitTxt)
 def VVIaEV(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVR5okRev if self.lastSortModeIsReverese else self.VVR5ok
    self["myTableH"].setList([self.VVq2jJ(0, self.header, self.VVslIr, self.VViJnU, self.VVslIr, self.VViJnU, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVBQW6):
    self["myTable"].list.append(self.VVq2jJ(c, row, self.VVz8JC, self.VV84wP, self.VVH7qA, self.VVvmBM, None))
   self.VVBQW6 = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVtrG6 > -1:
    self["myTable"].moveToIndex(self.VVtrG6 )
   self.VVzpyz()
   if self.VVhEUu:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VV2u5U * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFM0oF(self, width, newH)
   if self.VVeJ6x:
    self.VVNCLs(self.VVeJ6x, None)
   if self.tableRefreshCB:
    self.VVNCLs(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFBsVa(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VVq2jJ(self, keyIndex, columns, VVz8JC, VV84wP, VVH7qA, VVvmBM, VVR5ok):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVR5ok and ndx == self.VVFsq0 : textColor = VVR5ok
   else           : textColor = VVz8JC
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFV5jv(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VV84wP = c
    entry = span.group(3)
   if not self.isEditor and self.VVGQvW[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VV2u5U)
           , font   = 0
           , flags   = self.VVGQvW[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VV84wP
           , color_sel  = VVH7qA or textColor
           , backcolor_sel = VVvmBM
           , border_width = self.borderWidth
           , border_color = self.VVfpy3
           ))
   posX += self.colWidthPixels[ndx]
  if not VVR5ok and self.picParams:
   picPosCol, picFnc, pathCol = self.picParams
   if   picFnc : png = picFnc(columns)
   elif pathCol: png = columns[pathCol].strip()
   else  : png = ""
   if png.startswith("/"):
    try:
     pngX = sum(self.colWidthPixels[:picPosCol])
     row.append(CCLGNO.VVZhgD(pngX+2, picPosCol+2, self.colWidthPixels[picPosCol]-4, self.VV2u5U-4, LoadPixmap(png)))
    except:
     pass
  return row
 def VVjHhQ(self):
  rowData = self.VV8OND()
  if rowData:
   title, txt, colList = rowData
   if self.VVZRP4:
    fnc  = self.VVZRP4[1]
    params = self.VVZRP4[2]
    fnc(self, title, txt, colList)
   else:
    FFVBx2(self, txt, title)
 def VVA0L4(self):
  if   self.VVoCEo : self.VVqQLu(self.VVXRaz(), mode=2)
  elif self.VVTXLQ  : self.VVNCLs(self.VVTXLQ, None)
  else      : self.VVjHhQ()
 def VVojzs(self) : self.VVNCLs(self.VVXfC8 , self["keyRed"])
 def VV8cS5(self) : self.VVNCLs(self.VVIZTW , self["keyGreen"])
 def VVzJAv(self): self.VVNCLs(self.VVFaAj , self["keyYellow"])
 def VVHpQb(self) : self.VVNCLs(self.VV6CVp , self["keyBlue"])
 def VVNCLs(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FFrBcM(self, buttonFnc[3])
    FFb5Nn(BF(self.VVOMPm, buttonFnc))
   else:
    self.VVOMPm(buttonFnc)
 def VVOMPm(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VV8OND()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVqQLu(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][10] == self.VVYKoJ
   if mode == 0 or (mode == 2 and isSelected):
    bg = self.VV84wP
    if isSelected:
     self.selectedItems -= 1
   else:
    bg = self.VVYKoJ
    if not isSelected:
     self.selectedItems += 1
   for col in range(1, len(row)):
    cols = list(row[col])
    if cols[0] == 0:
     cols[10] = bg
    row[col] = tuple(cols)
   self["myTable"].l.invalidate()
   if self.VVXRaz() < len(self["myTable"].list) - 1 : self.VVT50f()
   else              : self.VVzpyz()
   if self.onMultiSelFnc:
    self.onMultiSelFnc()
 def VVABN7(self)  : FFn5td(self, BF(self.VVzGv7, True ), title="Selecting all ..."  )
 def VVnAWu(self) : FFn5td(self, BF(self.VVzGv7, False), title="Unselecting all ...")
 def VVzGv7(self, isSel=True):
  if isSel:
   bg = self.VVYKoJ
   self.selectedItems = len(self["myTable"].list)
   self.VVPvaS(True)
  else:
   bg = self.VV84wP
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][10] == self.VVYKoJ
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     cols = list(self["myTable"].list[ndx][col])
     if cols[0] == 0:
      cols[10] = bg
     self["myTable"].list[ndx][col] = tuple(cols)
  self["myTable"].l.invalidate()
 def VV8OND(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VV3FCq[i] > 1 or self.VV3FCq[i] == self.VVK2GJ or self.VV3FCq[i] == self.VV00We:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVqPQg(self):
  self["myTable"].onSelectionChanged = []
  if self.VV0cge : self.VV0cge(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVYGKg(self):
  return self["myTitle"].getText().strip()
 def VV4x5I(self):
  return self.header
 def VVs7rs(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVvMMQ(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFBe4X(self["myBar"], color)
 def VVM1y5(self, txt):
  FFrBcM(self, txt)
 def VVNLt2(self, txt, Time=1000):
  FFrBcM(self, txt, Time)
 def VVfBWZ(self): self["keyGreen"].show()
 def VVvlea(self): self["keyGreen"].hide()
 def VVoQzx(self): return self["keyGreen"].visible
 def VVD7du(self):
  FFrBcM(self)
 def VVLx7i(self, fnc, callFnc=False):
  self["myTable"].onSelectionChanged.append(fnc)
  if callFnc:
   fnc()
 def VVI5RC(self):
  return len(self["myTable"].list)
 def VVXRaz(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVdO40(self):
  return len(self["myTable"].list)
 def VVPvaS(self, isOn):
  self.VVoCEo = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VV6CVp: self["keyBlue"].hide()
   if self.VVTXLQ and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.VVRmfT
   self["keyMenu"].show()
   if self.VV6CVp: self["keyBlue"].show()
   if self.VVTXLQ and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVTXLQ[0])
   self.VVnAWu()
  FFwVrd(self["myTitle"], color)
  FFwVrd(self["myBar"]  , color)
 def VVFPwr(self):
  return self.VVoCEo
 def VVRFlF(self):
  return self.selectedItems
 def VVE6jF(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVzpyz()
 def VVnYLk(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVZiI3(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVI5RC()
  txt += FFElFp("Total Unique Items", VVmxw7)
  for i in range(self.totalCols):
   if self.VV3FCq[i - 1] > 1 or self.VV3FCq[i - 1] == self.VVK2GJ or self.VV3FCq[i - 1] == self.VV00We:
    name, tot = self.VVnYLk(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FFVBx2(self, txt)
 def VVOEiT(self, colNum, isStrip=True):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip() if isStrip else item[colNum + 1][7]
  else : return None
 def VVQ0F0(self):
  return self.VVgdey(self["myTable"].l.getCurrentSelectionIndex())
 def VVgdey(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VV311O(self, newList, newTitle="", VV3PMMMsg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVs7rs(newTitle)
  if newList:
   self.VVBQW6 = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VV3cto and self.VVFsq0 == 0:
    isNum = True
   else:
    for cols in self.VVBQW6:
     if not FFty8Y(cols[self.VVFsq0]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVBQW6.sort(key=lambda x: int(x[self.VVFsq0])  , reverse=self.lastSortModeIsReverese)
    else : self.VVBQW6.sort(key=lambda x: x[self.VVFsq0].lower() , reverse=self.lastSortModeIsReverese)
   if VV3PMMMsg : self.VVbHSA("Refreshing ...")
   else   : self.VVIaEV()
  else:
   FFBsVa(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVPCFQ(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VVq2jJ(self.VVdO40(), row, self.VVz8JC, self.VV84wP, self.VVH7qA, self.VVvmBM, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VVSXho()
 def VVJZ26(self):
  self["myTable"].list.pop(self.VVXRaz())
  self["myTable"].l.setList(self["myTable"].list)
 def VVUkGQ(self, data):
  ndx = self.VVXRaz()
  newRow = self.VVq2jJ(ndx, data, self.VVz8JC, self.VV84wP, self.VVH7qA, self.VVvmBM, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVzpyz()
   return True
  else:
   return False
 def VVs007(self, tDict):
  ndx = self.VVXRaz()
  for colNum, val in tDict.items():
   txt = str(val)
   if not self.isEditor and self.VVGQvW[ndx] & LEFT:
    txt = " %s " % txt.strip()
   col = list(self["myTable"].list[ndx][colNum + 1])
   col[7] = txt
   self["myTable"].list[ndx][colNum + 1] = tuple(col)
  self.VVsJyf()
 def VVNshL(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VVq2jJ(ndx, data, self.VVz8JC, self.VV84wP, self.VVH7qA, self.VVvmBM, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVsJyf()
 def VVsJyf(self):
  self["myTable"].l.setList(self["myTable"].list)
  self.VVzpyz()
 def VVpdwW(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VV2bC1(self, colNum, textToFind, VVg3ap=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVzpyz()
    break
  else:
   if VVg3ap:
    FFrBcM(self, "Not found", 1000)
 def VVGQiM(self, colDict, VVg3ap=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVzpyz()
    return
  if VVg3ap:
   FFrBcM(self, "Not found", 1000)
  return False
 def VVtIX5(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VV0hxT(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFty8Y(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVXAfG(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVYKoJ:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVJlmL(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][10] == self.VVYKoJ:
     return ndx
  return -1
 def VVFveQ(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][10] == self.VVYKoJ:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVvrS0(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][10] == self.VVYKoJ : return True
  else        : return False
 def VVMHVB(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVEBap(self):
  if self.menuButtonFnc:
   self.VVOMPm(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVhEUu:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVXRaz()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVtZf81, VVO2lh = CCmB9U.VVLnbC(self, False, False)
  VVtZf8 = []
  VVtZf8.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVtZf8.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVtZf8.append(("Find ...\t\t%s" % (FFxrb0(txt, VVTVZG) if txt else ""), "findNew"   ))
  VVtZf8.append(itemOf(bool(VVtZf81)    , "Find (from Filter) ..."   , "filter"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Table Statistcis"             , "tableStat"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((FFxrb0("Export Table to .html"     , VVmxw7) , "VVekMm" ))
  VVtZf8.append((FFxrb0("Export Table to .csv"     , VVmxw7) , "VVwgO7" ))
  VVtZf8.append((FFxrb0("Export Table to .txt (Tab Separated)", VVmxw7) , "VVe9Am" ))
  if self.addSort:
   sList = []
   tot  = 0
   for i in range(self.totalCols):
    if self.VV3FCq[i] > 1 or self.VV3FCq[i] == self.VV0RN2:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     sList.append(("Sort by : %s" % name, i))
   if tot:
    VVtZf8.append(VVh3VV)
    if tot == 1 : VVtZf8.append(("Sort", sList[0][1]))
    else  : VVtZf8 += sList
  VVR5O9 = ("Keys Help", self.FFuI68Help)
  FFd7BR(self, self.VVncdg, VVtZf8=VVtZf8, title=self.VVYGKg(), VVR5O9=VVR5O9)
 def VVncdg(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VVmzTZ()
   elif item == "findPrev"  : self.VVmzTZ(isPrev=True)
   elif item == "findNew"  : self.VVlzpU()
   elif item == "filter"  : self.VVLgUk()
   elif item == "tableStat" : self.VVZiI3()
   elif item == "VVekMm": FFn5td(self, self.VVekMm, title=title)
   elif item == "VVwgO7" : FFn5td(self, self.VVwgO7 , title=title)
   elif item == "VVe9Am" : FFn5td(self, self.VVe9Am , title=title)
   else:
    if self.VVFsq0 == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVFsq0, self.lastSortModeIsReverese = item, False
    if self.VV3cto and self.VVFsq0 == 0 or self.VV0hxT(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVIaEV(onlyHeader=True)
 def FFuI68Help(self, VVlE2Q, path):
  FF4fCC(self, "_help_table", "Table (Keys Help)")
 def VV3DuO(self):
  self["myTable"].up()
  self.VVzpyz()
 def VVT50f(self):
  self["myTable"].down()
  self.VVzpyz()
 def VV4BB5(self):
  self["myTable"].pageUp()
  self.VVzpyz()
 def VVjNpQ(self):
  self["myTable"].pageDown()
  self.VVzpyz()
 def VVUJE3(self):
  self["myTable"].moveToIndex(0)
  self.VVzpyz()
 def VVSXho(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVzpyz()
 def VV8i74(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVzpyz()
 def VVdmDv(self):
  if self.lastFindConfigObj.getValue():
   if self.VVXRaz() == len(self["myTable"].list) - 1 : FFrBcM(self, "End reached", 1000)
   else              : self.VVmzTZ()
  else:
   FFrBcM(self, 'Set "Find" in Menu', 1500)
 def VVdLpM(self):
  if self.lastFindConfigObj.getValue():
   if self.VVXRaz() == 0 : FFrBcM(self, "Top reached", 1000)
   else       : self.VVmzTZ(isPrev=True)
  else:
   FFrBcM(self, 'Set "Find" in Menu', 1500)
 def VVBn1v(self, txt):
  FFSeyu(self.lastFindConfigObj, txt)
 def VVlzpU(self):
  FFsCnW(self, self.VVSzWU, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VVSzWU(self, VVudej):
  if not VVudej is None:
   txt = VVudej.strip()
   self.VVBn1v(txt)
   if VVudej: self.VVmzTZ(reset=True)
   else  : FFrBcM(self, "Nothing to find !", 1500)
 def VVLgUk(self):
  VVtZf8, VVO2lh = CCmB9U.VVLnbC(self, False, False)
  VVJlf7 = ("Edit Filter", BF(self.VVlxG8, VVO2lh))
  if VVtZf8 : FFd7BR(self, self.VV4N7B, VVtZf8=VVtZf8, VVJlf7=VVJlf7, title="Find from Filter")
  else  : FFrBcM(self, "Filter Error !", 1500)
 def VV4N7B(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVBn1v(txt)
    self.VVmzTZ(reset=True)
   else:
    FFrBcM(self, "No entry !", 1500)
 def VVlxG8(self, VVO2lh, selectionObj, sel):
  if fileExists(VVO2lh) : CCteri(self, VVO2lh, VVqhY7=None)
  else       : FFPQyp(self, VVO2lh)
  selectionObj.cancel()
 def VVmzTZ(self, reset=False, isPrev=False):
  curRow = self.VVXRaz()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCmB9U.VVbRSg(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VV8i74(i)
      break
    elif any(x in line for x in tupl):
     self.VV8i74(i)
     break
   else:
    FFrBcM(self, "Not found", 1000)
  else:
   FFrBcM(self, "Check your query", 1500)
 def VVe9Am(self):
  expFile = self.VVwYgD() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVbtm1()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVgdey(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV3FCq[ndx] > self.VVYZjR or self.VV3FCq[ndx] == self.VV00We:
      col = self.VVYjom(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VViurA(expFile)
 def VVwgO7(self):
  expFile = self.VVwYgD() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVbtm1()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVgdey(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VV3FCq[ndx] > self.VVYZjR or self.VV3FCq[ndx] == self.VV00We:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVYjom(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VViurA(expFile)
 def VVekMm(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVYGKg(), PLUGIN_NAME, VVDJVr)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVYGKg()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVbtm1()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VV3FCq:
   colgroup += '   <colgroup>'
   for w in self.VV3FCq:
    if w > self.VVYZjR or w == self.VV00We:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVwYgD() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVgdey(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VV3FCq[ndx] > self.VVYZjR or self.VV3FCq[ndx] == self.VV00We:
      col = self.VVYjom(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VViurA(expFile)
 def VVbtm1(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VV3FCq[ndx] > self.VVYZjR or self.VV3FCq[ndx] == self.VV00We:
     newRow.append(col.strip())
  return newRow
 def VVYjom(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFpnOy(col)
 def VVwYgD(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVYGKg())
  fileName = fileName.replace("__", "_")
  path  = FF9GYH(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FF0Isj()
  return expFile
 def VViurA(self, expFile):
  FFx4Fl(self, "File exported to:\n\n%s" % expFile, title=self.VVYGKg())
 def VVzpyz(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   totCols = len(row)
   if row[totCols - 1][0] == 0 : lastCol = totCols - 1
   else      : lastCol = totCols - 2
   x, y, w, h = row[lastCol][1:5]
   self["myTable"].l.setSelectionClip(eRect(0, 0, int(x + w), int(h)), True)
 @staticmethod
 def VVZhgD(x, y, w, h, png, bg=None, bgSel=None):
  typ = eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST
  if VVG5hg: return (typ, x, y, w, h, png, bg, bgSel, VVG5hg | CENTER)
  else   : return (typ, x, y, w, h, png, bg, bgSel)
class CCmJoX():
 def __init__(self, pixmapObj, picPath, VV84wP=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VV84wP  = VV84wP or "#2200002a"
 def VV2coA(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VVbLui)
    except:
     self.picLoad.PictureData.get().append(self.VVbLui)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VV84wP])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VVbLui(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVO4Ch(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVlbww(pixmapObj, path, VV84wP=None):
  cl = CCmJoX(pixmapObj, path, VV84wP)
  ok = cl.VV2coA()
  if ok: return cl
  else : return None
class CCSQFA(Screen):
 def __init__(self, session, VVukle, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FF3tfX()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FF98gL(VVe902, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVukle = VVukle
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFd98D(self)
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVCvz0  ,
   "up" : BF(self.VVpBPv, -1),
   "down" : BF(self.VVpBPv,  1),
   "left" : BF(self.VVpBPv, -1),
   "right" : BF(self.VVpBPv,  1)
  }, -1)
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFD5nM(self)
  self.VVEJPb()
  self.picViewer = CCmJoX.VVlbww(self["myPic"], self.VVukle)
  if self.picViewer:
   if self.showGrnMsg:
    FFrBcM(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFBsVa(self, "Cannot view picture file:\n\n%s" % self.VVukle)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVO4Ch()
  if self.cbFnc  : self.cbFnc(self.VVukle)
 def VVpBPv(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVukle = FF9GYH(os.path.dirname(self.VVukle)) + fName
    self.picViewer.picPath = self.VVukle
    self.picViewer.VV2coA()
    self.VVEJPb()
 def VVCvz0(self):
  txt = "%s:\n  %s" % (FFxrb0("Path", VVwwau), self.fakePath or self.VVukle)
  size, sizeTxt, resTxt, form, mode = CC7MvF.VVWQP2(self.VVukle)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFxrb0("Properties", VVwwau)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FFVBx2(self, txt, title="File Information")
 def VVEJPb(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVukle)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VV9tRL(SELF, VVukle, **kwargs):
  SELF.session.open(CCSQFA, VVukle, **kwargs)
class CCBQzP(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FF98gL(VVEosT, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFd98D(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VV583n)
  self.onClose.append(self.onExit)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFkQDN("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVrQvP(SELF, mviFile):
  SELF.session.openWithCallback(BF(CCBQzP.VV94Iu, SELF), CCBQzP, mviFile)
 @staticmethod
 def VV94Iu(SELF, reason=None):
  if reason == -1: FFBsVa(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CChKAm(Screen, ConfigListScreen):
 VVh1NY = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FF98gL(VV79iE, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFd98D(self, title=self.Title)
  FF1N71(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVhSKl()
  self.onShown.append(self.VV583n)
 def VVhSKl(self):
  kList = {
    "ok" : self.VVnIt0   ,
    "green" : self.VVeoGk ,
    "menu" : self.VVzQTb ,
    "cancel": self.VV5e3B ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVgEu0, 0)
     kList["chanDown"] = BF(self["config"].VVgEu0, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(VVO7iZ, kList, -1)
  else:
   self["actions"] = ActionMap(VVO7iZ, kList, -1)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFD5nM(self)
  FFzlUl(self["config"])
  FFzxez(self, self["config"])
  FFRet2(self)
  self["config"].onSelectionChanged.append(self.VVaK6K)
  self.VVaK6K()
  FFwVrd(self["keyRed"], "#11000000")
  self["keyRed"].show()
 def VVaK6K(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVnIt0(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVjdQP()
   elif item == CFG.MovieDownloadPath   : self.VV535A(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVkYHp()
   elif isinstance(item, ConfigDirectory) : self.VViZ9S(item)
   else         : CChKAm.VVOmhN(self, item, title)
 @staticmethod
 def VVOmhN(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)   : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelectionNumber): lst = [(x, x) for x in confItem.choices.choices]
   elif isinstance(confItem, ConfigSelection)  : lst = confItem.choices.choices
   else           : return
  curNdx = defNdx = -1
  VVtZf8 = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVTVZG + txt
    elif val == confItem.default: defNdx, txt = ndx, VV0V0q + txt
   VVtZf8.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VVR5O9  = ("Current", BF(CChKAm.VV1s0u, curNdx))
  VVJlf7 = ("Default", BF(CChKAm.VV1s0u, defNdx))
  VVlE2Q = FFd7BR(SELF, BF(CChKAm.VVIAKX, confItem, cbFnc, isSave), VVtZf8=VVtZf8, width=1200, VVJlf7=VVJlf7, VVR5O9=VVR5O9, title=title, VVRmfT="#33221111", VVRNJt="#33110011")
  VVlE2Q.VVIgUV(curNdx)
 @staticmethod
 def VVIAKX(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFSeyu(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VV1s0u(ndx, selectionObj, item):
  selectionObj.VVIgUV(ndx)
 @staticmethod
 def VVMQkP(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VV535A(self, item, title):
  tot = CCPYn3.VVM9Nw()
  if tot : FFBsVa(self, "Cannot change while downloading.", title=title)
  else : self.VViZ9S(item)
 def VVkYHp(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCiVik.VVjYp5(self, "", curEnc)
  if lst:
   VVJlf7 = ("Default", self.VVjqOB)
   VVR5O9  = ("Current", self.VVczKn)
   VVlE2Q = FFd7BR(self, self.VVed8V, title="Select Priority Encoding", VVtZf8=lst, width=1000, height=1000, VVR5O9=VVR5O9, VVJlf7=VVJlf7, VVRmfT="#22220000", VVRNJt="#22220000", VVkmYm=True)
   VVlE2Q.VVsNSx(curEnc)
 def VVed8V(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVjqOB(self, VVlE2Q, item): VVlE2Q.VVsNSx(VVsrqw)
 def VVczKn(self, VVlE2Q, item): VVlE2Q.VVsNSx(CFG.subtDefaultEnc.getValue())
 def VVjdQP(self):
  VVtZf8 = []
  VVtZf8.append(("Auto Find" , "auto"))
  VVtZf8.append(("Custom Path" , "cust"))
  FFd7BR(self, self.VVNMo9, VVtZf8=VVtZf8, title="IPTV Hosts Files Path")
 def VVNMo9(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVikmx)
   elif item == "cust":
    VVaKg1 = self.VV3KlZ()
    if VVaKg1 : self.VVy8t7(VVaKg1)
    else  : self.session.openWithCallback(self.VVq5bN, BF(CC5iId, mode=CC5iId.VVtux5, VV0aja="/"))
 def VVy8t7(self, VVaKg1):
  VV0cge = self.VVsJlQ
  VVXfC8 = ("Remove"  , self.VVwyQb , [])
  VVFaAj = ("Add "  , self.VVWf4s, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVGQvW  = (LEFT   , LEFT  )
  FFuI68(self, None, title="IPTV Hosts Search Paths", header=header, VVBQW6=VVaKg1, width=1200, height=700, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=26, VV0cge=VV0cge, VVXfC8=VVXfC8, VVFaAj=VVFaAj
    , VVRmfT="#22220000", VVRNJt="#22110000", VV84wP="#22110011", VVvmBM="#11223025", VVfpy3="#0a333333", VViJnU="#11400040")
 def VVsJlQ(self, VVzzNZ):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVRtvF)
  VVzzNZ.cancel()
 def VVq5bN(self, path):
  if path:
   FFSeyu(CFG.iptvHostsDirs, FF9GYH(path.strip()))
   VVaKg1 = self.VV3KlZ()
   if VVaKg1 : self.VVy8t7(VVaKg1)
   else  : FFrBcM(self, "Cannot add dir", 1500)
 def VVDIyn(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVikmx:
   return []
  return lst
 def VV3KlZ(self):
  lst = self.VVDIyn()
  if lst:
   VVaKg1 = []
   for Dir in lst:
    VVaKg1.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVaKg1.sort(key=lambda x: x[0].lower())
   return VVaKg1
  else:
   return []
 def VVWf4s(self, VVzzNZ, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVkEtm, VVzzNZ)
         , BF(CC5iId, mode=CC5iId.VVtux5, VV0aja=sDir))
 def VVkEtm(self, VVzzNZ, path):
  if path:
   path = FF9GYH(path.strip())
   if self.VVtP3j(VVzzNZ, path):
    FFrBcM(VVzzNZ, "Already added", 1500)
   else:
    lst = self.VVDIyn()
    lst.append(path)
    FFSeyu(CFG.iptvHostsDirs, ",".join(lst))
    VVaKg1 = self.VV3KlZ()
    VVzzNZ.VV311O(VVaKg1, tableRefreshCB=BF(self.VVws85, path))
 def VVws85(self, path, VVzzNZ, title, txt, colList):
  self.VVtP3j(VVzzNZ, path)
 def VVtP3j(self, VVzzNZ, path):
  for ndx, row in enumerate(VVzzNZ.VVMHVB()):
   if row[0].strip() == path.strip():
    VVzzNZ.VV8i74(ndx)
    return True
  return False
 def VVwyQb(self, VVzzNZ, title, txt, colList):
  path = colList[0]
  FFEN35(self, BF(self.VVg1XW, VVzzNZ), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVg1XW(self, VVzzNZ):
  row = VVzzNZ.VVQ0F0()
  path, rem = row[0], row[1]
  VVaKg1 = []
  lst = []
  for ndx, row in enumerate(VVzzNZ.VVMHVB()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVaKg1.append((tPath, tRem))
  if len(VVaKg1) > 0:
   FFSeyu(CFG.iptvHostsDirs, ",".join(lst))
   VVzzNZ.VV311O(VVaKg1)
   FFrBcM(VVzzNZ, "Deleted", 1500)
  else:
   FFSeyu(CFG.iptvHostsMode, VVikmx)
   FFSeyu(CFG.iptvHostsDirs, "")
   VVzzNZ.cancel()
   FFb5Nn(BF(FFrBcM, self, "Changed to Auto-Find", 1500))
 def VViZ9S(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVkB5L, configObj)
         , BF(CC5iId, mode=CC5iId.VVtux5, VV0aja=sDir))
 def VVkB5L(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VV5e3B(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFEN35(self, self.VVeoGk, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVeoGk(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVgBvO()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VVzQTb(self):
  VVtZf8 = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVtZf8.append((txt    , "VVOlYJ"   ))
  else        : VVtZf8.append((txt    ,       ))
  VVtZf8.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Reset %s Settings" % PLUGIN_NAME      , "VV60vR"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Backup %s Settings" % PLUGIN_NAME      , "VV6Wlv"  ))
  VVtZf8.append(("Restore %s Settings" % PLUGIN_NAME     , "VVRUNC"  ))
  if fileExists(VVzbRf + CChKAm.VVh1NY):
   VVtZf8.append(VVh3VV)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVtZf8.append(('%s Checking for Update' % txt1     , txt2     ))
   VVtZf8.append(("Reinstall %s" % PLUGIN_NAME      , "VVlxBr"  ))
   VVtZf8.append(("Update %s" % PLUGIN_NAME      , "VVKPYg"   ))
  FFd7BR(self, self.VVq83h, VVtZf8=VVtZf8, title="Config. Options")
 def VVq83h(self, item=None):
  if item:
   if   item == "VVOlYJ"  : FFEN35(self, self.VVOlYJ , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCpGRu)
   elif item == "VV60vR"  : FFEN35(self, BF(self.VV60vR, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VV6Wlv" : self.VV6Wlv()
   elif item == "VVRUNC" : FFn5td(self, self.VVRUNC, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFSeyu(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFSeyu(CFG.checkForUpdateAtStartup, False)
   elif item == "VVlxBr" : FFn5td(self, BF(self.VV7jPN, True ), "Checking Server ...")
   elif item == "VVKPYg"  : FFn5td(self, BF(self.VV7jPN, False), "Checking Server ...")
 def VV6Wlv(self):
  path = "%sajpanel_settings_%s" % (VVzbRf, FF0Isj())
  FFnedc("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VV7aeL, path))
  FFx4Fl(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVRUNC(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFIM7p("find / %s -iname '%s*' | grep %s" % (FFwS2p(1), name, name))
  if files:
   err = CC5iId.VVuDDL(files)
   if err:
    FFEN35(self, BF(self.VVSQ27, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVtZf8 = []
    for line in files:
     VVtZf8.append((line, line))
    FFd7BR(self, BF(self.VVPmrx, title), title=title, VVtZf8=VVtZf8, width=1200, VVK9oq="")
  else:
   FFBsVa(self, "No settings files found !", title=title)
 def VVSQ27(self, title, path=None):
  sDir = "/"
  for path in (VVzbRf, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVPmrx, title), BF(CC5iId, patternMode="ajpSet", VV0aja=sDir))
 def VVPmrx(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFMy5k(path)
    self.VV60vR()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVgBvO()
    FFCdSV()
    FFrBcM(self, "Apllied", 1500, isGrn=True)
   else:
    FFPQyp(self, path, title=title)
 def VVOlYJ(self):
  newPath = FF9GYH(VVzbRf)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVgBvO()
 @staticmethod
 def VVOMtU():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VV60vR(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVgBvO()
  if exit:
   self.close()
 def VVgBvO(self):
  configfile.save()
  global VVzbRf
  VVzbRf = CFG.backupPath.getValue()
  FFvzUJ()
 def VV7jPN(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CChKAm.VVqYN6()
  if   err    : FFBsVa(self, err, title)
  elif isHigher or force : FFEN35(self, BF(FFn5td, self, BF(self.VVxk7N, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FFx4Fl(self, FFxrb0("No update required.", VVCKEk) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVxk7N(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFNDlH() == "dpkg" else "ipk")
  path, err = FFjgmp(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFgOTM(VVJxPG, path)
   else : cmd = FFgOTM(VVhXh6, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FFeWwS(self, cmd, title=title)
   else:
    FF5yx0(self, title=title)
  else:
   FFBsVa(self, err, title=title)
 @staticmethod
 def VVqYN6():
  span = iSearch(r"v*(\d.\d.\d)", VVDJVr, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVzbRf + CChKAm.VVh1NY
  if fileExists(path):
   span = iSearch(r"(http.+)", FFl3Sc(path), IGNORECASE)
   if span : url = FF9GYH(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFjgmp(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFl3Sc(path).strip().replace(" ", "")
   FFKqXn(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCpGRu(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF98gL(VVJh9Z, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VVzsiD
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFd98D(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VVUfk4("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VVUfk4("\c00888888", i) + sp + "GREY\n"
   txt += self.VVUfk4("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VVUfk4("\c00FF0000", i) + sp + "RED\n"
   txt += self.VVUfk4("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VVUfk4("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VVUfk4("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VVUfk4("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VVUfk4("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VVUfk4("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VVUfk4("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VVUfk4("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok" : self.VVnIt0 ,
   "green" : self.VVnIt0 ,
   "left" : self.VV3UwQ ,
   "right" : self.VVWKwc ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  self.VVQAJf()
 def VVnIt0(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFEN35(self, self.VVUHqT, "Change to : %s" % txt, title=self.Title)
 def VVUHqT(self):
  FFSeyu(CFG.mixedColorScheme, self.cursorPos)
  global VVzsiD
  VVzsiD = self.cursorPos
  self.VVgV3m()
  self.close()
 def VV3UwQ(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVQAJf()
 def VVWKwc(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVQAJf()
 def VVQAJf(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VVUfk4(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV97a4(color):
  if VV0V0q: return "\\" + color
  else    : return ""
 @staticmethod
 def VVgV3m():
  global VVi96Z, VVUpvF, VVKRbh, VVD46d, VVmxw7, VVOICC, VVOIiN, VVLhUP, VVCKEk, VVs7I8, VV0V0q, VVwwau, VVTVZG, VVquhO, VVDF46, VVDysW
  VVDysW   = CCpGRu.VVUfk4("\c00FFFFFF", VVzsiD)
  VVUpvF    = CCpGRu.VVUfk4("\c00888888", VVzsiD)
  VVi96Z  = CCpGRu.VVUfk4("\c005A5A5A", VVzsiD)
  VVLhUP    = CCpGRu.VVUfk4("\c00FF0000", VVzsiD)
  VVKRbh   = CCpGRu.VVUfk4("\c00FF5000", VVzsiD)
  VVD46d   = CCpGRu.VVUfk4("\c00FFBB66", VVzsiD)
  VV0V0q   = CCpGRu.VVUfk4("\c00FFFF00", VVzsiD)
  VVwwau = CCpGRu.VVUfk4("\c00FFFFAA", VVzsiD)
  VVCKEk   = CCpGRu.VVUfk4("\c0000FF00", VVzsiD)
  VVs7I8  = CCpGRu.VVUfk4("\c00AAFFAA", VVzsiD)
  VVOIiN    = CCpGRu.VVUfk4("\c000066FF", VVzsiD)
  VVTVZG    = CCpGRu.VVUfk4("\c0000FFFF", VVzsiD)
  VVquhO  = CCpGRu.VVUfk4("\c00AAFFFF", VVzsiD)  #
  VVDF46   = CCpGRu.VVUfk4("\c00FA55E7", VVzsiD)
  VVmxw7    = CCpGRu.VVUfk4("\c00FF8F5F", VVzsiD)
  VVOICC  = CCpGRu.VVUfk4("\c00FFC0C0", VVzsiD)
CCpGRu.VVgV3m()
class CCMlOB(Screen):
 def __init__(self, session, path, VVITRg):
  self.skin, self.skinParam = FF98gL(VVKs5Q, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVB4Rr   = path
  self.VVo656   = ""
  self.VVdZqQ   = ""
  self.VVITRg    = VVITRg
  self.VVm99N    = ""
  self.VV41zd  = ""
  self.VVdaP2    = False
  self.VVNnPK  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VVcCW4  = "enigma2-plugin-extensions-"
  self.VVJu3y  = "enigma2-plugin-systemplugins-"
  self.VVaLbE = "enigma2-"
  self.VV7ZoJ  = 0
  self.VViXaL  = 1
  self.VV9Jqz  = 2
  if pathExists(self.Path + "DEBIAN") : self.VV0SKl = "DEBIAN"
  else        : self.VV0SKl = "CONTROL"
  self.controlPath = self.Path + self.VV0SKl
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVITRg:
   self.packageExt  = ".deb"
   self.VV84wP  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VV84wP  = "#11001020"
  FFd98D(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FF1N71(self["keyRed"] , "Create")
  FF1N71(self["keyGreen"] , "Post Install")
  FF1N71(self["keyYellow"], "Installation Path")
  FF1N71(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(VVO7iZ,
  {
   "red"   : self.VVxbrZ  ,
   "green"   : self.VVJv8m ,
   "yellow"  : self.VVUJe9  ,
   "blue"   : self.VVRg2H  ,
   "cancel"  : self.VV2oQQ
  }, -1)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFRet2(self)
  if self.VV84wP:
   FFwVrd(self["myBody"], self.VV84wP)
   FFwVrd(self["myLabel"], self.VV84wP)
  self.VVgP23(True)
  self.VVkSRf(True)
 def VVkSRf(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VViWYx()
  if isFirstTime:
   if   package.startswith(self.VVcCW4) : self.VVB4Rr = VVJT98 + self.VVm99N + "/"
   elif package.startswith(self.VVJu3y) : self.VVB4Rr = VVU7z8 + self.VVm99N + "/"
   else            : self.VVB4Rr = self.Path
  if self.VVdaP2 : myColor = VVmxw7
  else    : myColor = VVDysW
  txt  = ""
  txt += "Source Path\t: %s\n" % FFxrb0(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFxrb0(self.VVB4Rr, VV0V0q)
  if self.VVdZqQ : txt += "Package File\t: %s\n" % FFxrb0(self.VVdZqQ, VVUpvF)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFxrb0("Check Control File fields : %s" % errTxt, VVKRbh)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFxrb0("Restart GUI", VVmxw7)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFxrb0("Reboot Device", VVmxw7)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFxrb0("Post Install", VVCKEk), act)
  if not errTxt and VVKRbh in controlInfo:
   txt += "Warning\t: %s\n" % FFxrb0("Errors in control file may affect the result package.", VVKRbh)
  txt += "\nControl File\t: %s\n" % FFxrb0(self.controlFile, VVUpvF)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVJv8m(self):
  if self["keyGreen"].getVisible():
   VVtZf8 = []
   VVtZf8.append(("No Action"    , "noAction"  ))
   VVtZf8.append(("Restart GUI"    , "VVCjpM"  ))
   VVtZf8.append(("Reboot Device"   , "rebootDev"  ))
   FFd7BR(self, self.VVCtng, title="Package Installation Option (after completing installation)", VVtZf8=VVtZf8)
 def VVCtng(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVCjpM"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VVgP23(False)
   self.VVkSRf()
 def VVUJe9(self):
  rootPath = FFxrb0("/%s/" % self.VVm99N, VVwwau)
  VVtZf8 = []
  VVtZf8.append(("Current Path"        , "toCurrent"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Extension Path"       , "toExtensions" ))
  VVtZf8.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVtZf8.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFd7BR(self, self.VVxtgW, title="Installation Path", VVtZf8=VVtZf8)
 def VVxtgW(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VVNu6C(FFghFX(self.Path, True))
   elif item == "toExtensions"  : self.VVNu6C(VVJT98)
   elif item == "toSystemPlugins" : self.VVNu6C(VVU7z8)
   elif item == "toRootPath"  : self.VVNu6C("/")
   elif item == "toRoot"   : self.VVNu6C("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVhAvZ, BF(CC5iId, mode=CC5iId.VVtux5, VV0aja=VVzbRf))
 def VVhAvZ(self, path):
  if len(path) > 0:
   self.VVNu6C(path)
 def VVNu6C(self, parent, withPackageName=True):
  if withPackageName : self.VVB4Rr = parent + self.VVm99N + "/"
  else    : self.VVB4Rr = "/"
  mode = self.VVPR8I()
  FFkQDN("sed -i '/Package/c\Package: %s' %s" % (self.VVLXFH(mode), self.controlFile))
  self.VVkSRf()
 def VVRg2H(self):
  if fileExists(self.controlFile):
   lines = FFMy5k(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFsCnW(self, self.VVRJrD, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFBsVa(self, "Version not found or incorrectly set !")
  else:
   FFPQyp(self, self.controlFile)
 def VVRJrD(self, VVudej):
  if VVudej:
   version, color = self.VVOsK2(VVudej, False)
   if color == VVTVZG:
    FFkQDN("sed -i '/Version:/c\Version: %s' %s" % (VVudej, self.controlFile))
    self.VVkSRf()
   else:
    FFBsVa(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VV2oQQ(self):
  if self.newControlPath:
   if self.VVdaP2:
    self.VVtOd3()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFxrb0(self.newControlPath, VVUpvF)
    txt += FFxrb0("Do you want to keep these files ?", VV0V0q)
    FFEN35(self, self.close, txt, callBack_No=self.VVtOd3, title="Create Package", VV00ww=True)
  else:
   self.close()
 def VVtOd3(self):
  FFkQDN("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVLXFH(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VV41zd
  if package.startswith(self.VVaLbE):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVaLbE, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VViXaL : prefix = self.VVcCW4
  elif mode == self.VV9Jqz : prefix = self.VVJu3y
  return (prefix + name).lower()
 def VVPR8I(self):
  if   self.VVB4Rr.startswith(VVJT98) : return self.VViXaL
  elif self.VVB4Rr.startswith(VVU7z8) : return self.VV9Jqz
  else            : return self.VV7ZoJ
 def VVgP23(self, isFirstTime):
  self.VVm99N   = FFzOGe(self.Path)
  self.VVm99N   = "_".join(self.VVm99N.split())
  self.VV41zd = self.VVm99N.lower()
  self.VVdaP2 = self.VV41zd == VV9Vh8.lower()
  if self.VVdaP2 and self.VV41zd.endswith(VV9Vh8.lower()):
   self.VV41zd += "el"
  if self.VVdaP2 : self.VVo656 = VVzbRf
  else    : self.VVo656 = CFG.packageOutputPath.getValue()
  self.VVo656 = FF9GYH(self.VVo656)
  if not pathExists(self.controlPath):
   FFkQDN("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVPR8I()
  if fileExists(self.controlFile):
   lines = FFMy5k(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVdaP2 : version, descripton, maintainer = VVDJVr , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVm99N , self.VVm99N
   txt = ""
   txt += "Package: %s\n"  % self.VVLXFH(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVdaP2 : t = PLUGIN_NAME
  else    : t = self.VVm99N
  self.VVEJoZ(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVEJoZ(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVdaP2 : self.VVEJoZ(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVDJVr))
  else    : self.VVEJoZ(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVm99N)
  if isFirstTime and not mode == self.VV7ZoJ:
   self.postInstAcion = 1
  txt = self.VVZJmO(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFl3Sc(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VVZJmO(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFkQDN("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVEJoZ(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VVZJmO(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VViWYx(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFMy5k(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFxrb0(line, VVKRbh)
     elif not line.startswith(" ")    : line = FFxrb0(line, VVKRbh)
     else          : line = FFxrb0(line, VVTVZG)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVTVZG
   else   : color = VVKRbh
   descr = FFxrb0(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVKRbh
     elif line.startswith((" ", "\t")) : color = VVKRbh
     elif line.startswith("#")   : color = VVUpvF
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVOsK2(val, True)
      elif key == "Version"  : version, color = self.VVOsK2(val, False)
      elif key == "Maintainer" : maint  , color = val, VVTVZG
      elif key == "Architecture" : arch  , color = val, VVTVZG
      else:
       color = VVTVZG
      if not key == "OE" and not key.istitle():
       color = VVKRbh
     else:
      color = VVmxw7
     txt += FFxrb0(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVdZqQ = self.VVo656 + packageName
   self.VVNnPK = True
   errTxt = ""
  else:
   self.VVdZqQ  = ""
   self.VVNnPK = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVOsK2(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVTVZG
  else          : return val, VVKRbh
 def VVxbrZ(self):
  if not self.VVNnPK:
   FFBsVa(self, "Please fix Control File errors first.")
   return
  if self.VVITRg: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FFghFX(self.VVB4Rr, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVm99N
  symlinkTo  = FF3NDk(self.Path)
  dataDir   = self.VVB4Rr.rstrip("/")
  removePorjDir = FFaBql("rm -rf '%s'"  % projDir)
  cmd  = ""
  cmd += FFaBql("rm -f '%s'" % self.VVdZqQ)
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFJDAH()
  if self.VVITRg:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FFhejV("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVdaP2:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVB4Rr == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VV0SKl)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVdZqQ, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVdZqQ
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVdZqQ, FFPk5q(result  , VVCKEk))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVB4Rr, FFPk5q(instPath, VVTVZG))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFPk5q(failed, VVKRbh))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FFeWwS(self, cmd)
class CCQq9Y():
 VVYF6j  = "666"
 VVMzWC   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VVlE2Q   = None
  self.VVk2Hy()
 def VVk2Hy(self):
  VVtZf8 = CCQq9Y.VVVLD3()
  if VVtZf8:
   VVJlf7 = ("Create New", self.VV1uO8)
   self.VVlE2Q = FFd7BR(self.SELF, self.VVaGYV, VVtZf8=VVtZf8, title=self.Title, VVJlf7=VVJlf7, VVkmYm=True, VVRmfT="#22222233", VVRNJt="#22222233")
  else:
   self.VV1uO8()
 def VVaGYV(self, item):
  if item:
   bName, bRef, ndx = item
   self.VV8Y4z(bName, bRef)
  else:
   CCQq9Y.VVRZXQ(self)
 def VV1uO8(self, selectionObj=None, item=None):
  FFsCnW(self.SELF, BF(self.VVQqEo), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVQqEo(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VVlE2Q:
     self.VVlE2Q.cancel()
    self.VV8Y4z(bName, "")
   else:
    FFrBcM(self.VVlE2Q, "Incorrect Bouquet Name !", 2000)
    CCQq9Y.VVRZXQ(self)
 def VV8Y4z(self, bName, bRef):
  FFn5td(self.waitMsgSELF, BF(self.VVtlr4, bName, bRef), title="Adding Services ...")
 def VVtlr4(self, bName, bRef):
  CCQq9Y.VVFFSs(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVRZXQ(classObj):
  del classObj
 @staticmethod
 def VVFFSs(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFBsVa(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VV7aeL + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFPQyp(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCQq9Y.VV9zDX(bRef)
   bPath = VV7aeL + bFile
  else:
   fName = CCnYqq.VVwgy6(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VV7aeL + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VV7aeL + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FF4xUI(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FF4xUI(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCjCYH.VVzyVV()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFkQDN("cp -f '%s' '%s'" % (poster, picon))
       FFkQDN(CCFLza.VVPCa2(picon))
       break
  FFOnqc()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FFVBx2(SELF, txt, title=title)
 @staticmethod
 def VVYjPl(bName):
  mode = CCG0xP.VVY2KO(default=-1)
  modeTxt = "tv" if mode == 0 else "radio"
  fName = CCnYqq.VVwgy6(bName)
  bFile = "userbouquet.%s.%s" % (fName, modeTxt)
  num   = 0
  while fileExists(VV7aeL + bFile):
   num += 1
   bFile = "userbouquet.%s_%d.%s" % (fName, num, modeTxt)
  with open(VV7aeL + bFile, "w") as f:
   f.write("#NAME %s\n" % bName)
  mainBFile = "%sbouquets.%s" % (VV7aeL, modeTxt)
  if fileExists(mainBFile):
   FF4xUI(mainBFile)
   with open(mainBFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
 @staticmethod
 def VV2YUz(ref, bName):
  bFile = CCQq9Y.VV9zDX(ref)
  ok = False
  if bFile:
   bFile = VV7aeL + bFile
   if fileExists(bFile):
    lines = FFMy5k(bFile, keepends=True)
    with open(bFile, "w") as f:
     for line in lines:
      if line.startswith("#NAME "):
       f.write("#NAME %s\n" % bName)
       ok = True
      else:
       f.write(line)
  return ok
 @staticmethod
 def VVVLD3(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVtZf8 = []
  if mode in (0, 2): VVtZf8.extend(CCQq9Y.VVjKFc(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVtZf8.extend(CCQq9Y.VVjKFc(1, showTitle, prefix, onlyIptv))
  return VVtZf8
 @staticmethod
 def VVjKFc(mode, showTitle, prefix, onlyIptv):
  VVtZf8 = []
  lst = CCQq9Y.VV1Md2(mode)
  if onlyIptv:
   lst = CCQq9Y.VV5zmM(lst)
  if lst:
   if showTitle:
    VVtZf8.append(FFbAzs("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVtZf8.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVtZf8.append((item[0], item[1].toString()))
  return VVtZf8
 @staticmethod
 def VV5zmM(lst):
  fLst = CCnYqq.VVQk0n(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VViv0F():
  lst = CCQq9Y.VV1Md2(0)
  lst.extend(CCQq9Y.VV1Md2(1))
  return lst
 @staticmethod
 def VV1Md2(mode=0):
  bList = []
  VVjKXg = InfoBar.instance
  VVenrc = VVjKXg and VVjKXg.servicelist
  if VVenrc:
   curMode = VVenrc.mode
   CCQq9Y.VVxjyQ(VVenrc, mode)
   bList.extend(VVenrc.getBouquetList() or [])
   CCQq9Y.VVxjyQ(VVenrc, curMode)
  return bList
 @staticmethod
 def VVxjyQ(VVenrc, mode):
  if not mode == VVenrc.mode:
   if   mode == 0: VVenrc.setModeTv()
   elif mode == 1: VVenrc.setModeRadio()
 @staticmethod
 def VVplok(isAll=True, onlyMain=False):
  bLst = []
  inst = InfoBar.instance
  if inst:
   csel = inst.servicelist
   if csel:
    root = csel.bouquet_root
    VVntaB = eServiceCenter.getInstance()
    if onlyMain:
     info = VVntaB.info(root)
     if info:
      bLst.append((info.getName(root), root.toString()))
    else:
     list = VVntaB and VVntaB.list(root)
     if list:
      while True:
       s = list.getNext()
       if not s.valid():
        break
       if isAll or (s.flags & eServiceReference.isDirectory and not s.flags & eServiceReference.isInvisible):
        info = VVntaB.info(s)
        if info:
         bLst.append((info.getName(s), s.toString()))
  return bLst
 @staticmethod
 def VV9zDX(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : return ""
 @staticmethod
 def VVQbIy(ref, dstFile):
  dstFile = VV7aeL + dstFile
  if fileExists(dstFile):
   FF4xUI(dstFile)
   bLine = ""
   srcFile = CCQq9Y.VV9zDX(ref)
   if srcFile:
    span = iSearch(r"\.(.+)\.(tv|radio)", srcFile, IGNORECASE)
    if span:
     fName, fType = span.group(1), span.group(2)
     newName = "userSubBouquet.%s.%s" % (fName, fType)
     num = 0
     while fileExists(VV7aeL + newName):
      num += 1
      newName = "userSubBouquet.%s_%d.%s" % (fName, num, fType)
     subFile = VV7aeL + newName
     FFkQDN("cp -f '%s%s' '%s'" % (VV7aeL, srcFile, subFile))
     if fileExists(subFile):
      bLine = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % newName
   else:
    bLine = ref
   if bLine:
    if fileExists(dstFile):
     with open(dstFile, "a") as f:
      f.write("#SERVICE %s\n" % bLine)
     return True
  return False
 @staticmethod
 def VVK5Cl():
  try:
   fName = CCQq9Y.VV9zDX(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VV7aeL, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVzYiQ():
  path = CCQq9Y.VVK5Cl()
  if path:
   txt = FFl3Sc(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVXEX3():
  return FFemXY(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VV67bC():
  lst = []
  for b in CCQq9Y.VViv0F():
   bName = b[0]
   bRef  = b[1].toString()
   path = VV7aeL + CCQq9Y.VV9zDX(bRef)
   if fileExists(path):
    lines = FFMy5k(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVDDRO(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VV6ShY(SID="", stripRType=False):
  if SID : patt = CCQq9Y.VVDDRO(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCQq9Y.VViv0F():
   for service in FFemXY(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVFMme():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCQq9Y.VViv0F():
   for service in FFemXY(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVh5up(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVkpUX(pathLst, rType=""):
  refLst = CCQq9Y.VV6ShY(CCQq9Y.VVYF6j, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCQq9Y.VVh5up(rType, CCQq9Y.VVYF6j, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CC5iId(Screen):
 VVL251   = 0
 VV45t5  = 1
 VVtux5  = 2
 VVnecM = 3
 VVkCHL    = 20
 VVWYFf   = 0
 VVleQ2   = 1
 VVYQki   = 2
 def __init__(self, session, VV0aja="/", mode=VVL251, VV1w5C="Select", width=1400, height=920, VVJgEp=30, VVRmfT="#22001111", VVRNJt="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FF98gL(VVL2J2, width, height, 30, 40, 20, VVRmfT, VVRNJt, VVJgEp, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVRmfT   = VVRmfT
  self.VVRNJt    = VVRNJt
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFd98D(self)
  FF1N71(self["keyRed"] , "Exit")
  FF1N71(self["keyYellow"], "More Options")
  FF1N71(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VV1w5C = VV1w5C
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VV0f8o = None
  if patternMode:
   self.mode = self.VVnecM
   if   patternMode == "srt"  : VV0f8o = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VV0f8o = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VV0f8o = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VV0f8o = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VV0f8o = ("^.*\.(%s)$" % "|".join(CCYpe9.VVtxMu()["mov"]), IGNORECASE)
   else       : VV0f8o = None
  if self.mode in (self.VVtux5, self.VVnecM):
   FF1N71(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVlQUo, self.VV0aja = True , FFghFX(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVlQUo, self.VV0aja = True , CC5iId.VVOhYP(self)[1] or "/"
  elif self.mode == self.VVL251  : VVlQUo, self.VV0aja = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVtux5 : VVlQUo, self.VV0aja = False, VV0aja
  elif self.mode == self.VVnecM : VVlQUo, self.VV0aja = True , VV0aja
  else           : VVlQUo, self.VV0aja = True , VV0aja
  self.VV0aja = FF9GYH(self.VV0aja)
  self["myMenu"] = CCYpe9(  directory   = None
         , VV0f8o = VV0f8o
         , VVlQUo   = VVlQUo
         , VVAC6T = True
         , VVpzqd = True
         , VVMAO9   = self.skinParam["width"]
         , VVJgEp   = self.skinParam["bodyFontSize"]
         , VV2u5U  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(VVO7iZ,
  {
   "ok" : self.VVnIt0    ,
   "red" : self.VVHM4t   ,
   "green" : self.VV53qx,
   "yellow": self.VVErOp  ,
   "blue" : self.VV1Kx0 ,
   "menu" : self.VVJu3b  ,
   "info" : self.VVDj39  ,
   "cancel": self.VV0ruW    ,
   "pageUp": self.VVpeLD   ,
   "chanUp": self.VVpeLD
  }, -1)
  FFcKND(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVgNjM)
  global VVyR2u
  VVyR2u = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.mode == self.VVL251:
   FFNb6h("VVyR2u")
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VVgNjM)
  FFD5nM(self)
  FFzlUl(self["myMenu"], bg=self.cursorBG)
  FFRet2(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVtux5, self.VVnecM):
   FF1N71(self["keyGreen"], self.VV1w5C)
   self.VVcero(self.VVleQ2)
  self.VVgNjM()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVnCOF(self.VV0aja) > self.bigDirSize: FFn5td(self, self.VVOaQb, title="Changing directory...")
  else              : self.VVOaQb()
 def VVOaQb(self):
  if self.jumpToFile : self.VVLS8O(self.jumpToFile)
  elif self.gotoMovie : self.VVwrTH(chDir=False)
  else    : self["myMenu"].VVtiSX(self.VV0aja)
 def VV8i74(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVPRyY(self):
  FFn5td(self, self.VVN79p, title="Refreshing list ...")
 def VVN79p(self):
  isSel = self["myMenu"].VVXMa9()
  if not isSel:
   self.VVPhEc(False)
  FFbfAi()
 def VV3ekk(self, saved):
  if saved: self.VVPRyY()
 def VVnCOF(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVnIt0(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVoR3z()
   if ok : self["keyBlue"].setText(self.VV6rqQ())
   else : FFrBcM(self, "Cannot select item", 500)
  elif self["myMenu"].VVN6qu(): self.VVcCyb()
  else       : self.VVS00Z()
 def VVpeLD(self):
  if self.multiSelectState:
   FFrBcM(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VV5cfZ():
    self.VVcCyb()
 def VVcCyb(self, isDirUp=False):
  if self["myMenu"].VVN6qu():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VV8GbQ(self.VVy3ES())
   if self.VVnCOF(path) > self.bigDirSize : FFn5td(self, self.VV1dLl, title="Changing directory...")
   else           : self.VV1dLl()
 def VV1dLl(self):
  self["myMenu"].descent()
  self.VVgNjM()
 def VV0ruW(self):
  if   self.multiSelectState     : self.VVPhEc(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVHM4t()
  else          : self.VVpeLD()
 def VVHM4t(self):
  if not FFgLwO(self):
   self.close("")
 def VV53qx(self):
  path = self.VV8GbQ(self.VVy3ES())
  if self.mode == self.VVtux5:
   self.close(path)
  elif self.mode == self.VVnecM:
   if os.path.isfile(path) : self.close(path)
   else     : FFrBcM(self, "Cannot access this file", 1000)
 def VVDj39(self):
  FFn5td(self, self.VV1LOW, title="Calculating size ...")
 def VV1LOW(self):
  path = self.VV8GbQ(self.VVy3ES())
  param = self.VVKnoe(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FFz86l("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CC5iId.VVPQRH(path)
     freeSize = CC5iId.VVpbj4(path)
     size = totSize - freeSize
     totSize  = CC5iId.VVp3Jg(totSize)
     freeSize = CC5iId.VVp3Jg(freeSize)
    else:
     size = FFQzS1(path)
   usedSize = CC5iId.VVp3Jg(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFxrb0(pathTxt, VVmxw7) + "\n"
   if slBroken : fileTime = self.VV9qiY(path)
   else  : fileTime = self.VVSVJT(path)
   def VVdl9w(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVdl9w("Path"    , pathTxt)
   txt += VVdl9w("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVdl9w("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVdl9w("Total Size"   , "%s" % totSize)
    txt += VVdl9w("Used Size"   , "%s" % usedSize)
    txt += VVdl9w("Free Size"   , "%s" % freeSize)
   else:
    txt += VVdl9w("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVdl9w("Owner"    , owner)
   txt += VVdl9w("Group"    , group)
   txt += VVdl9w("Perm. (User)"  , permUser)
   txt += VVdl9w("Perm. (Group)"  , permGroup)
   txt += VVdl9w("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVdl9w("Perm. (Ext.)" , permExtra)
   txt += VVdl9w("iNode"    , iNode)
   txt += VVdl9w("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVOHGY(path)
  else:
   FFBsVa(self, "Cannot access information !")
  if len(txt) > 0:
   FFVBx2(self, txt)
 def VVKnoe(self, path):
  path = path.strip()
  path = FF3NDk(path)
  result = FFz86l("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVfAnM(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVfAnM(perm, 1, 4)
   permGroup = VVfAnM(perm, 4, 7)
   permOther = VVfAnM(perm, 7, 10)
   permExtra = VVfAnM(perm, 10, 100)
   typeChar = perm[0:1]
   typeStr = {"-":"File", "b":"Block Device File", "c":"Character Device File", "d":"Directory", "e":"External Link", "l":"Symbolic Link", "n":"Network File", "p":"Named Pipe", "s":"Local Socket File"}.get(typeChar, "Unknown")
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FFHFMV("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVOHGY(self, path):
  txt  = ""
  res  = FFz86l("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = {"a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file"}
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFxrb0("File Attributes:", VVDF46), txt)
  return txt
 def VVSVJT(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF2ADr(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FF2ADr(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FF2ADr(os.path.getctime(path))
  return txt
 def VV9qiY(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFz86l("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FFz86l("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FFz86l("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VV8GbQ(self, currentSel):
  currentDir  = self["myMenu"].VV9o2M()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVN6qu():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVy3ES(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VVgNjM(self):
  path = self.VV8GbQ(self.VVy3ES())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVtMou()
  if self.mode == self.VVL251:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVnecM:
   path = self.VV8GbQ(self.VVy3ES())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVJu3b(self):
  color1 = VVOICC
  color2 = VVwwau
  color3 = VVquhO
  totSel = 0
  menuW = 1000
  title = "Options"
  VVtZf8= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVM0oZ()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FFAHjU(totSel))
     VVtZf8.append((color1 + txt1     , "VVM9Cj1" ))
     VVtZf8.append((color1 + txt1 + txt2   , "VVM9Cj2" ))
     VVtZf8.append(VVh3VV)
    VVtZf8.append(("[6] Copy"       , "copyBulk" ))
    VVtZf8.append(("[7] Move"       , "moveBulk" ))
    VVtZf8.append(("[8] %sDELETE" % VVmxw7 , "VVujj2" ))
   else:
    FFrBcM(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVtux5, self.VVnecM):
   VVtZf8.append(("Properties"           , "properties" ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VV8GbQ(self.VVy3ES())
   isEditable = self["myMenu"].VVSdo7()
   VVtZf8.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVtZf8.append(VVh3VV)
     VVtZf8.append((color1 + "Archiving / Packaging", "VVGtAd_dir"))
   elif os.path.isfile(path):
    selFile = self.VVy3ES()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVtZf8.append((color1 + "Archive ...", "VVGtAd_file"))
    isText = False
    txt = ""
    if   isArch            : VVtZf8.extend(self.VVIquE(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVtZf8.extend(self.VVlLig(True))
    elif selFile.endswith(".sh"):
     VVtZf8.extend(self.VVQ9d3(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CC5iId.VV45v0(path):
     VVtZf8.append(VVh3VV)
     VVtZf8.append((color2 + "View"     , "textView_def"))
     VVtZf8.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVtZf8.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VVxeAu(path) == "pic":
     VVtZf8.append(VVh3VV)
     VVtZf8.append((color2 + "Set as PIcon for current channel" , "VVQxUl" ))
     if FFtTXa("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVtZf8.append(VVh3VV)
      VVtZf8.append((color2 + "Convert to MVI (1280 x 720 )" , "VVZw8oHd"   ))
      VVtZf8.append((color2 + "Convert to MVI (1920 x 1080)" , "VVZw8oFhd"   ))
    elif selFile.endswith(CC5iId.VVHMT3()):
     if selFile.endswith(".mvi"):
      if FFtTXa("showiframe"):
       VVtZf8.append(VVh3VV)
       VVtZf8.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVtZf8.append(VVh3VV)
      VVtZf8.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVtZf8.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVtZf8.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVtZf8.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVtZf8.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVtZf8.append((color1 + "Convert Line-Breaks to Unix Format..." , "VVpOK7" ))
    if len(txt) > 0:
     VVtZf8.append(VVh3VV)
     VVtZf8.append((color1 + txt, "VVS00Z"))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("[4] Create SymLink", "VVVhss"))
   if isEditable:
    VVtZf8.append(("[5] Rename"      , "VVWhXD" ))
    VVtZf8.append(("[6] Copy"       , "copyFileOrDir" ))
    VVtZf8.append(("[7] Move"       , "moveFileOrDir" ))
    VVtZf8.append(("[8] %sDELETE" % VVmxw7 , "VVMD3P" ))
    if fileExists(path):
     VVtZf8.append(VVh3VV)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVtZf8.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVtZf8.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVtZf8.append((chmodTxt + "777)", "chmod777"))
   VVtZf8.append(VVh3VV)
   VVtZf8.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVtZf8.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CC5iId.VVOhYP(self)
   if fPath:
    VVtZf8.append(VVh3VV)
    VVtZf8.append((color2 + "Go to Current Movie Dir", "VVwrTH"))
  FFd7BR(self, self.VVPpRF, width=menuW, height=1050, title=title, VVtZf8=VVtZf8, VVbj8e=False, VVRmfT="#00101020", VVRNJt="#00101A2A")
 def VVPpRF(self, item=None):
  if item is not None:
   path = self.VV8GbQ(self.VVy3ES())
   selFile = self.VVy3ES()
   if   item == "VVM9Cj1"    : self.VVM9Cj(False)
   if   item == "VVM9Cj2"    : self.VVM9Cj(True)
   elif item == "copyBulk"     : self.VV5W1d(False)
   elif item == "moveBulk"     : self.VV5W1d(True)
   elif item == "VVujj2"    : self.VVujj2()
   elif item == "properties"    : self.VVDj39()
   elif item == "VVGtAd_dir" : self.VVGtAd(path, True)
   elif item == "VVGtAd_file" : self.VVGtAd(path, False)
   elif item == "VV0Uaf"  : self.VV0Uaf(path)
   elif item == "VVRsyc"  : self.VVRsyc(path)
   elif item.startswith("extract_")  : self.VVcsvq(path, selFile, item)
   elif item.startswith("script_")   : self.VV507G(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVSa5D(path, selFile, item)
   elif item.startswith("textView_def") : FF5vJp(self, path)
   elif item.startswith("textView_enc") : self.VVtLaU(path)
   elif item.startswith("text_Edit")  : CCteri(self, path, VVqhY7=self.VV3ekk)
   elif item.startswith("textSave_encUtf8"): self.VVU3tq(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVU3tq(path, "Save as Other Encoding", False)
   elif item.startswith("VVpOK7") : self.VVpOK7(path)
   elif item == "viewAsBootlogo"   : self.VVp7XM(path, True)
   elif item == "addMovieToBouquet"  : self.VVPr6U(path, False)
   elif item == "addAllMoviesToBouquet" : self.VVPr6U(path, True)
   elif item == "playWith"     : self.VVXAZ2(path)
   elif item == "VVQxUl" : self.VVQxUl(path)
   elif item == "VVZw8oHd"   : FFn5td(self, BF(self.VVZw8o, path, False))
   elif item == "VVZw8oFhd"   : FFn5td(self, BF(self.VVZw8o, path, True))
   elif item == "VVVhss"   : self.VVVhss(path, selFile)
   elif item == "VVWhXD"   : self.VVWhXD(path, selFile)
   elif item == "copyFileOrDir"   : self.VVLYYl(path, False)
   elif item == "moveFileOrDir"   : self.VVLYYl(path, True)
   elif item == "VVMD3P"   : self.VVMD3P(path, selFile)
   elif item == "chmod644"     : self.VVmtI2(path, selFile, "644")
   elif item == "chmod755"     : self.VVmtI2(path, selFile, "755")
   elif item == "chmod777"     : self.VVmtI2(path, selFile, "777")
   elif item == "createNewFile"   : self.VVkOEf(path, True)
   elif item == "createNewDir"    : self.VVkOEf(path, False)
   elif item == "VVwrTH"   : self.VVwrTH()
   elif item == "VVS00Z"    : self.VVS00Z()
 def VVS00Z(self):
  if self.mode == self.VVnecM and not self.patternMode == "poster":
   return
  selFile = self.VVy3ES()
  path  = self.VV8GbQ(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VVxeAu(path)
   if   cat == "pic"       : self.VVQ5gK(path)
   elif cat == "txt"       : FF5vJp(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VViZCT(path, selFile)
   elif cat == "scr"       : self.VVnTKY(path, selFile)
   elif cat == "m3u"       : self.VVN3HJ(path, selFile)
   elif cat in ("ipk", "deb")     : self.VVSo1i(path, selFile)
   elif cat in ("mov", "mus")     : self.VVp7XM(path)
   elif not CC5iId.VV45v0(path) : FF5vJp(self, path)
 def VVQ5gK(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VVxeAu(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCSQFA.VV9tRL(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVNSto)
 def VVNSto(self, path):
  self.VVLS8O(path)
 def VVp7XM(self, path, asLogo=False):
  if asLogo : CCBQzP.VVrQvP(self, path)
  else  : FFn5td(self, BF(self.VV0HP2, self, path), title="Playing Media ...")
 def VV1Kx0(self):
  if self["keyBlue"].getVisible():
   VVBQW6 = self.VVpVGo()
   if VVBQW6:
    path = self.VV8GbQ(self.VVy3ES())
    enableGreenBtn = False if path in self.VVpVGo() else True
    newList = []
    for line in VVBQW6:
     newList.append((line, line))
    VV8QNc  = ("Delete"    , self.VVL4Fw    )
    VVA2fW  = ("Add Current Dir"   , BF(self.VVtn05, path) ) if enableGreenBtn else None
    VVJlf7 = ("Move Up"     , self.VVdz0I    )
    VVR5O9  = ("Move Down"   , self.VVxCkx    )
    self.bookmarkMenu = FFd7BR(self, self.VVOthv, width=1200, title="Bookmarks", VVtZf8=newList, minRows=10 ,VV8QNc=VV8QNc, VVA2fW=VVA2fW, VVJlf7=VVJlf7, VVR5O9=VVR5O9, VVRmfT="#00000022", VVRNJt="#00000022")
 def VVL4Fw(self, VVlE2Q=None, path=None):
  VVBQW6 = self.VVpVGo()
  if VVBQW6:
   while path in VVBQW6:
    VVBQW6.remove(path)
   self.VV2Zez(VVBQW6)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVKpZT(VVBQW6)
   self.bookmarkMenu.VVXyYg(("Add Current Dir", BF(self.VVtn05, path)))
  else:
   FFrBcM(self, "Removed", 800)
  self.VVtMou()
 def VVtn05(self, path, VVlE2Q=None, item=None):
  VVBQW6 = self.VVpVGo()
  if len(VVBQW6) >= self.VVkCHL:
   FFBsVa(SELF, "Max bookmarks reached (max=%d)." % self.VVkCHL)
  elif not path in VVBQW6:
   if not os.path.isdir(path):
    path = FFghFX(path, True)
   newList = [path] + VVBQW6
   self.VV2Zez(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVKpZT(newList)
    self.bookmarkMenu.VVXyYg()
   else:
    FFrBcM(self, "Added", 800)
  self.VVtMou()
 def VVdz0I(self, selectionObj, path):
  if self.bookmarkMenu:
   VVBQW6 = self.bookmarkMenu.VVfuHV(True)
   if VVBQW6:
    self.VV2Zez(VVBQW6)
 def VVxCkx(self, selectionObj, path):
  if self.bookmarkMenu:
   VVBQW6 = self.bookmarkMenu.VVfuHV(False)
   if VVBQW6:
    self.VV2Zez(VVBQW6)
 def VVOthv(self, folder=None):
  if folder:
   folder = FF9GYH(folder)
   self["myMenu"].VVtiSX(folder)
   self["myMenu"].moveToIndex(0)
  self.VVgNjM()
 def VVpVGo(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VV42Wp(self):
  return True if VVpVGo() else False
 def VV2Zez(self, VVBQW6):
  line = ",".join(VVBQW6)
  FFSeyu(CFG.browserBookmarks, line)
 def VVLS8O(self, path):
  if fileExists(path):
   fDir  = FF9GYH(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVtiSX(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FFrBcM(self, "Not found", 1000)
 def VVwrTH(self, chDir=True):
  fPath, fDir, fName = CC5iId.VVOhYP(self)
  self.VVLS8O(fPath)
 def VVErOp(self):
  path = self.VV8GbQ(self.VVy3ES())
  isAdd = False if path in self.VVpVGo() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVTVZG, VVs7I8, VVwwau
  VVtZf8 = []
  VVtZf8.append(("Find Files ..." , "find"))
  VVtZf8.append(("Sort ..."   , "sort"))
  VVtZf8.append(VVh3VV)
  if isAdd: VVtZf8.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVtZf8.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVL251:
   VVtZf8.append(VVh3VV)
   if self.multiSelectState: VVtZf8.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVtZf8.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVtZf8.append(       (c3 + "Select all"    , "selAll"  ))
  FFd7BR(self, BF(self.VVGm5V, path), width=750, title="More Options", VVtZf8=VVtZf8, VVRmfT="#00221111", VVRNJt="#00221111")
 def VVGm5V(self, path, item):
  if item:
   if   item == "find"  : self.VVgOI6(path)
   elif item == "sort"  : self.VVP9kj()
   elif item == "addBM" : self.VVtn05(path)
   elif item == "remBM" : self.VVL4Fw(None, path)
   elif item == "start" : self.VVyzhL(path)
   elif item == "multiOn" : self.VVPhEc(True)
   elif item == "multiOff" : self.VVPhEc(False)
   elif item == "selAll" : self.VVPhEc(True, True)
 def VVPhEc(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFn5td(self, BF(self["myMenu"].VVPizx, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVcero(self.VVYQki if isOn else self.VVWYFf)
 def VVcero(self, mode=0):
  if   mode == self.VVleQ2 : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVYQki: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVRmfT, self.VVRNJt
  FFwVrd(self["myTitle"], titBg)
  FFwVrd(self["myBar"], titBg)
  FFwVrd(self["myBody"], bodBg)
  FFwVrd(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VV6rqQ()
  else     : bg, txt = VVbCEM[3], "Bookmarks"
  FF1N71(self["keyBlue"], txt)
  FFwVrd(self["keyBlue"], bg)
  self.VVtMou()
 def VV6rqQ(self):
  return "Selected Items = %d" % self["myMenu"].VVM0oZ()
 def VVtMou(self):
  if self.VVpVGo() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVgOI6(self, path):
  VVtZf8 = []
  VVtZf8.append(("Find in Current Directory"    , "findCur"  ))
  VVtZf8.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVtZf8.append(("Find in all Storage Systems"    , "findAll"  ))
  FFd7BR(self, BF(self.VVUaMN, path), width=700, title="Find File/Pattern", VVtZf8=VVtZf8, VVkmYm=True, VVh2Zj=True, VVRmfT="#00221111", VVRNJt="#00221111")
 def VVUaMN(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VVi49s(0, path, title)
   elif item == "findCurR" : self.VVi49s(1, path, title)
   elif item == "findAll" : self.VVi49s(2, path, title)
 def VVi49s(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFsCnW(self, BF(self.VV67kl, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VV67kl(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFSeyu(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FFrBcM(self, "No entery", 1500)
   elif badLst  : FFrBcM(self, "Too many file !", 1500)
   else   : FFn5td(self, BF(self.VV70fh, mode, path, title, filePatt), title="Searching ...")
 def VV70fh(self, mode, path, title, filePatt):
  lst = FFIM7p(FFIjyj("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CC5iId.VVuDDL(lst)
   if err:
    FFBsVa(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVZRP4 = (""     , self.VVunw1 , [])
    VVIZTW = ("Go to File Location", self.VVUYOc  , [])
    FFuI68(self, None, title="%s : %s" % (title, filePatt), header=header, VVBQW6=lst, VV3FCq=widths, VVJgEp=26, VVZRP4=VVZRP4, VVIZTW=VVIZTW)
  else:
   FFQAm4(self, "Not found !", 2000)
 def VVUYOc(self, VVzzNZ, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVzzNZ.cancel()
   self.VVLS8O(path)
  else:
   FFrBcM(VVzzNZ, "Path not found !", 1000)
 def VVunw1(self, VVzzNZ, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFxrb0("File:"  , VVwwau), colList[0])
  txt += "%s\n%s"  % (FFxrb0("Directory:", VVwwau), FF9GYH(colList[1]))
  FFVBx2(VVzzNZ, txt, title=title)
 def VVP9kj(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVr5qe()
  VVtZf8 = []
  VVtZf8.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVtZf8.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVtZf8.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVtZf8.append(("Type\t%s" % typeTxt, "typeAlp"))
  VVR5O9 = ("Mix", BF(self.VVL5vL, True))
  FFd7BR(self, BF(self.VVCEpm, False), barText=txt, width=650, title="Sort Options", VVtZf8=VVtZf8, VVR5O9=VVR5O9, VVh2Zj=True, VVRmfT="#00221111", VVRNJt="#00221111")
 def VVL5vL(self, isMix, VVlE2Q, item):
  self.VVCEpm(True, item)
 def VVCEpm(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVr5qe()
   title = "Sorting ... "
   if   item == "nameAlp": FFn5td(self, BF(self["myMenu"].VVScFc, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFn5td(self, BF(self["myMenu"].VVScFc, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFn5td(self, BF(self["myMenu"].VVScFc, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFn5td(self, BF(self["myMenu"].VVScFc, typeMode , isMix, False), title=title)
 def VVyzhL(self, path):
  if not os.path.isdir(path):
   path = FFghFX(path, True)
  FFSeyu(CFG.browserStartPath, path)
  FFrBcM(self, "Done", 500)
 def VVJvfP(self, selFile, VVub3W, command):
  FFEN35(self, BF(FFeWwS, self, command, consFont=True, VVBjuq=self.VVPRyY), "%s\n\n%s" % (VVub3W, selFile))
 def VVIquE(self, path, calledFromMenu):
  destPath = self.VVq4Td(path)
  lastPart = FFzOGe(destPath)
  color = VVwwau if calledFromMenu else ""
  VVtZf8 = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVtZf8.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVtZf8.append(VVh3VV)
   VVtZf8.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVtZf8.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVtZf8.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVtZf8.append(VVh3VV)
     VVtZf8.append((color + "Convert .zip to .tar.gz"       , "VV0Uaf" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVtZf8.append(VVh3VV)
     VVtZf8.append((color + "Convert .tar.gz to .zip"       , "VVRsyc" ))
  return VVtZf8
 def VViZCT(self, path, selFile):
  FFd7BR(self, BF(self.VVcsvq, path, selFile), title="Compressed File Options", VVtZf8=self.VVIquE(path, False))
 def VVcsvq(self, path, selFile, item=None):
  if item is not None:
   parent  = FFghFX(path, False)
   destPath = self.VVq4Td(path)
   lastPart = FFzOGe(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FFhejV("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FFhejV("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n\n';" % path
     cmd += "totFiles=$(tar -tf '%s' | wc -l);" % path
     cmd += "if (( $totFiles > 300 )); then moreInf='  ... Will list the first 300 only ...'; else moreInf=''; fi;"
     cmd += "echo -e '\n%s\n--- Contents (Total='$totFiles')'$moreInf'\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s' | head -n300;" % path
     cmd += "if (( $totFiles > 300 )); then echo '\n... Only the first 300 are listed ...'; fi;"
    cmd += "echo '';"
    cmd += linux_sep
    FFxN9O(self, cmd)
   elif path.endswith(".zip"):
    if item == "VV0Uaf" : self.VV0Uaf(path)
    else       : self.VVuTY9(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VVRsyc" and path.endswith(".tar.gz"):
    self.VVRsyc(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FFz86l("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FFx4Fl(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVPRyY()
    else:
     FFBsVa(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VVhp3q(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFaBql("mkdir '%s'"   % lastPart)
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVJvfP(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVJvfP(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FFghFX(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVJvfP(selFile, "Extract Here ?"      , cmd)
 def VVq4Td(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVuTY9(self, item, path, parent, destPath, VVub3W):
  FFEN35(self, BF(self.VVvQR1, item, path, parent, destPath), VVub3W)
 def VVvQR1(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFhejV("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFPk5q(destPath, VVCKEk))
  cmd +=   sep
  cmd += "fi;"
  FFQwGu(self, cmd, VVBjuq=self.VVPRyY)
 def VVhp3q(self, item, path, parent, destPath, VVub3W):
  FFEN35(self, BF(self.VVjZO4, item, path, parent, destPath), VVub3W)
 def VVjZO4(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF9GYH(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FFhejV("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFPk5q(destPath, VVCKEk))
  cmd +=   sep
  cmd += "fi;"
  FFQwGu(self, cmd, VVBjuq=self.VVPRyY)
 def VVQ9d3(self, addSep=False):
  VVtZf8 = []
  if addSep:
   VVtZf8.append(VVh3VV)
  VVtZf8.append((VVwwau + "View Script File"  , "script_View"  ))
  VVtZf8.append((VVwwau + "Execute Script File" , "script_Execute" ))
  VVtZf8.append((VVwwau + "Edit"     , "script_Edit"  ))
  return VVtZf8
 def VVnTKY(self, path, selFile):
  FFd7BR(self, BF(self.VV507G, path, selFile), title="Script File Options", VVtZf8=self.VVQ9d3())
 def VV507G(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FF5vJp(self, path)
   elif item == "script_Execute" : self.VVJvfP(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCteri(self, path, VVqhY7=self.VV3ekk)
 def VVlLig(self, addSep=False):
  VVtZf8 = []
  if addSep:
   VVtZf8.append(VVh3VV)
  VVtZf8.append((VVwwau + "Browse IPTV Channels" , "m3u_Browse" ))
  VVtZf8.append((VVwwau + "Edit"     , "m3u_Edit" ))
  VVtZf8.append((VVwwau + "View"     , "m3u_View" ))
  return VVtZf8
 def VVN3HJ(self, path, selFile):
  FFd7BR(self, BF(self.VVSa5D, path, selFile), title="M3U/M3U8 File Options", VVtZf8=self.VVlLig())
 def VVSa5D(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFn5td(self, BF(self.session.open, CCnYqq, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCteri(self, path, VVqhY7=self.VV3ekk)
   elif item == "m3u_View"  : FF5vJp(self, path)
 def VVtLaU(self, path):
  if fileExists(path) : FFn5td(self, BF(CCiVik.VV2psM, self, path, BF(self.VV9SVE, path)), title="Loading Codecs ...")
  else    : FFPQyp(self, path)
 def VV9SVE(self, path, item=None):
  if item:
   FF5vJp(self, path, encLst=item)
 def VVU3tq(self, path, title, asUtf8):
  if fileExists(path) : FFn5td(self, BF(CCiVik.VV2psM, self, path, BF(self.VVGBSB, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFPQyp(self, path)
 def VVGBSB(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVP6ZV(path, title, fromEnc, "UTF-8")
   else  : CCiVik.VVNSH8(self, BF(self.VVP6ZV, path, title, fromEnc), title="Convert to Encoding")
 def VVP6ZV(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFxrb0("Successful\n\n", VVCKEk)
      txt += FFxrb0("From Encoding (%s):\n" % fromEnc, VV0V0q)
      txt += "%s\n\n" % path
      txt += FFxrb0("To Encoding (%s):\n" % toEnc, VV0V0q)
      txt += "%s\n\n" % outFile
      FFVBx2(self, txt, title=title)
    except:
     FFBsVa(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FFrBcM(self, "Cannot open file", 2000)
   self.VVPRyY()
 def VVpOK7(self, path):
  title = "File Line-Break Conversion"
  FFEN35(self, BF(self.VVTRGT, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVTRGT(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFxrb0("File converted:", VVCKEk), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FFx4Fl(self, txt, title=title)
  else:
   FFPQyp(self, path, title=title)
 def VVmtI2(self, path, selFile, newChmod):
  FFEN35(self, BF(self.VVItlv, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVItlv(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV6Dap)
  result = FFz86l(cmd)
  if result == "Successful" : FFx4Fl(self, result)
  else      : FFBsVa(self, result)
 def VVVhss(self, path, selFile):
  parent = FFghFX(path, False)
  self.session.openWithCallback(self.VVhVxK, BF(CC5iId, mode=CC5iId.VVtux5, VV0aja=parent, VV1w5C="Create Symlink here"))
 def VVhVxK(self, newPath):
  if len(newPath) > 0:
   target = self.VV8GbQ(self.VVy3ES())
   target = FF3NDk(target)
   linkName = FFzOGe(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF9GYH(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFBsVa(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFEN35(self, BF(self.VVr3zn, target, link), "Create Soft Link ?\n\n%s" % txt, VV00ww=True)
 def VVr3zn(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV6Dap)
  result = FFz86l(cmd)
  if result == "Successful" : FFx4Fl(self, result)
  else      : FFBsVa(self, result)
 def VVWhXD(self, path, selFile):
  lastPart = FFzOGe(path)
  FFsCnW(self, BF(self.VVXWoC, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVXWoC(self, path, selFile, VVudej):
  if VVudej:
   parent = FFghFX(path, True)
   if os.path.isdir(path):
    path = FF3NDk(path)
   newName = parent + VVudej
   cmd = "mv '%s' '%s' %s" % (path, newName, VV6Dap)
   if VVudej:
    if selFile != VVudej:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFEN35(self, BF(self.VVcFXl, cmd), message, title="Rename file?")
    else:
     FFBsVa(self, "Cannot use same name!", title="Rename")
 def VVcFXl(self, cmd):
  result = FFz86l(cmd)
  if "Fail" in result:
   FFBsVa(self, result)
  self.VVPRyY()
 def VVM9Cj(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVgRGi, title, preserve)
      , VVqhY7 = BF(self.VVT8OA, title))
 def VVgRGi(self, title, preserve, VVomkw):
  totSel = self["myMenu"].VVM0oZ()
  totOk = totFail = 0
  VVomkw.VVITUK(totSel)
  VVomkw.VV6uui = ["", totSel, totOk, totFail, ""]
  VVomkw.VVttgG("Prepareing targz file")
  curDir = self["myMenu"].VV9o2M()
  lastPart = FFzOGe(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVomkw or VVomkw.isCancelled:
      return
     if row[2][6]:
      VVomkw.VVReKT(1)
      name  = FF3NDk(row[0][0])
      lastPath = FFzOGe(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVomkw:
       VVomkw.VV6uui = [outF, totSel, totOk, totFail, path]
       VVomkw.VVAGgq(totOk, lastPath)
  except:
   totFail += 1
   if VVomkw:
    VVomkw.VV6uui = [outF, totSel, totOk, totFail, path]
 def VVT8OA(self, title, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VV6uui
  txt  = "%s:\n%s\n\n"   % (FFxrb0("Output File", VVCKEk), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFxrb0("Failed\t: %d\n" % totFail, VVmxw7)
  if not VVuCFf: txt += "%s\n%s" % (FFxrb0("\nCancelled while copying:", VVmxw7), path)
  FFVBx2(self, txt, title=title)
  self.VVPRyY()
 def VV5W1d(self, isMove):
  self.session.openWithCallback(BF(self.VVn5jM, isMove), BF(CC5iId, mode=CC5iId.VVtux5, VV0aja=self["myMenu"].VV9o2M(), VV1w5C="Move to here" if isMove else "Paste here"))
 def VVn5jM(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVBZDH, title, action, isMove, newPath)
       , VVqhY7 = BF(self.VV6zOr, title, action, isMove, newPath))
 def VVBZDH(self, title, action, isMove, newPath, VVomkw):
  curDir = self["myMenu"].VV9o2M()
  totOk = totFail = 0
  totSel = self["myMenu"].VVM0oZ()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVomkw.VVITUK(totSel)
  VVomkw.VV6uui = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVomkw or VVomkw.isCancelled:
    return
   if row[2][6]:
    VVomkw.VVReKT(1)
    VVomkw.VVEzB2(action, totOk, FFzOGe(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FFzOGe(path)
    if os.path.isdir(path): path = FF3NDk(path)
    dest = os.path.join(newPath, lastPart)
    if FFkQDN("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVomkw:
     VVomkw.VV6uui = [totSel, totOk, totFail, path]
     VVomkw.VVEzB2(action, totOk, FFzOGe(row[0][0]))
 def VV6zOr(self, title, action, isMove, newPath, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VV6uui
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFxrb0("Failed\t: %d\n" % totFail, VVmxw7)
  if not VVuCFf: txt += "%s\n%s" % (FFxrb0("\nCancelled while copying:", VVmxw7), path)
  FFVBx2(self, txt, title=title)
  self.VVPRyY()
 def VVujj2(self):
  tot = self["myMenu"].VVM0oZ()
  FFEN35(self, BF(FFn5td, self, self.VV9awM, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FFAHjU(tot)), title="Delete Selection")
 def VV9awM(self):
  path = self["myMenu"].VV9o2M()
  for row in self["myMenu"].list:
   if row[2][6]:
    FFFFoV(os.path.join(path, row[0][0]))
  FFrBcM(self)
  self.VVPRyY()
 def VVLYYl(self, path, isMove):
  self.session.openWithCallback(BF(self.VV6n8j, isMove, path), BF(CC5iId, mode=CC5iId.VVtux5, VV0aja=FFghFX(path, False), VV1w5C="Move to here" if isMove else "Paste here"))
 def VV6n8j(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FF3NDk(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FF3NDk(src)
  dst = os.path.join(dst, FFzOGe(src))
  if src == dst:
   FFBsVa(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFEN35(self, BF(self.VVUPqD, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFEN35(self, BF(self.VVUPqD, prams), "Overwrite Destination Files", title=title)
  else         : self.VVUPqD(prams)
 def VVUPqD(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CC5iId.VVg6qp(src) == CC5iId.VVg6qp(dst):
   FFn5td(self, BF(self.VV9jPU, prams), title="Moving %s ..." % srcSubj)
  else:
   FFn5td(self, BF(self.VV2oGc, prams), title="Calculating Size ...")
 def VV9jPU(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FFz86l("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVPRyY()
  else:
   FFBsVa(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VV2oGc(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFotbw(src)
  else  : size = FFQzS1(src)
  if size > -1:
   self.session.open(CCIpg5, barTheme=CCIpg5.VV0bv2, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VVz9C5, prams, size)
       , VVqhY7 = BF(self.VVEvLH, prams))
  else:
   FFBsVa(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VVz9C5(self, prams, size, VVomkw):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVomkw.VVITUK(size)
  VVomkw.VV6uui = ("", "", False)
  def VVbF8S(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFKqXn(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVomkw or VVomkw.isCancelled:
        VVomkw.VV6uui = (srcFile, "", True)
        FFKqXn(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVomkw.VVReKT(len(data))
       except Exception as e:
        VVomkw.VV6uui = (srcFile, str(e), False)
        FFKqXn(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFKqXn(srcFile)
   return True
  if isFile:
   tot = 1
   VVbF8S(src, dst)
  else:
   VVomkw.VVttgG("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FFFX6Q(src)
   if not VVomkw or VVomkw.isCancelled:
    VVomkw.VV6uui = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVomkw.VV6uui = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVomkw.VVttgG("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVbF8S(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFkQDN("rm -fr '%s'" % Dir)
   if isMove:
    FFkQDN("rm -fr '%s'" % src)
 def VVEvLH(self, prams, VVuCFf, VV6uui, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VV6uui
  if err:
   FFBsVa(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FFrBcM(self, "Canelled", 1000)
   else  : FFBsVa(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FFrBcM(self, "Done", 1500, isGrn=True)
  if VVuCFf and isMove:
   self.VVPRyY()
 def VVMD3P(self, path, fileName):
  path = FF3NDk(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFEN35(self, BF(FFn5td, self, BF(self.VV1MAK, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VV1MAK(self, path):
  FFFFoV(path)
  FFrBcM(self)
  self.VVPRyY()
 def VVkOEf(self, path, isFile):
  dirName = FF9GYH(os.path.dirname(path))
  if isFile : objName, VVudej = "File"  , self.edited_newFile
  else  : objName, VVudej = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFsCnW(self, BF(self.VVxgQ3, dirName, isFile, title), title=title, defaultText=VVudej, message="Enter %s Name:" % objName)
 def VVxgQ3(self, dirName, isFile, title, VVudej):
  if VVudej:
   if isFile : self.edited_newFile = VVudej
   else  : self.edited_newDir  = VVudej
   path = dirName + VVudej
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV6Dap)
    else  : cmd = "mkdir '%s' %s" % (path, VV6Dap)
    result = FFz86l(cmd)
    if "Fail" in result:
     FFBsVa(self, result)
    self.VVPRyY()
   else:
    FFBsVa(self, "Name already exists !\n\n%s" % path, title)
 def VVSo1i(self, path, selFile):
  c1, c2, c3 = VVs7I8, VVwwau, VVOICC
  VVtZf8 = []
  VVtZf8.append((c1 + "List Package Files"         , "VVmiYO"     ))
  VVtZf8.append((c1 + "Package Information"         , "VVfg8Z"     ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c2 + "Install Package"          , "VVN3As_CheckVersion" ))
  VVtZf8.append((c2 + "Install Package (force reinstall)"     , "VVN3As_ForceReinstall" ))
  VVtZf8.append((c2 + "Install Package (force overwrite)"     , "VVN3As_ForceOverwrite" ))
  VVtZf8.append((c2 + "Install Package (force downgrade)"     , "VVN3As_ForceDowngrade" ))
  VVtZf8.append((c2 + "Install Package (ignore failed dependencies)"  , "VVN3As_IgnoreDepends" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c3 + "Remove Related Package"        , "VVXpG0_ExistingPackage" ))
  VVtZf8.append((c3 + "Remove Related Package (force remove)"    , "VVXpG0_ForceRemove"  ))
  VVtZf8.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVXpG0_IgnoreDepends" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Extract Files"           , "VV0w1C"     ))
  VVtZf8.append(("Unbuild Package"           , "VV8MHO"     ))
  FFd7BR(self, BF(self.VVeWDD, path, selFile), VVtZf8=VVtZf8)
 def VVeWDD(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVmiYO"      : self.VVmiYO(path, selFile)
   elif item == "VVfg8Z"      : self.VVfg8Z(path)
   elif item == "VVN3As_CheckVersion"  : self.VVN3As(path, selFile, VV6ESW     )
   elif item == "VVN3As_ForceReinstall" : self.VVN3As(path, selFile, VVJxPG )
   elif item == "VVN3As_ForceOverwrite" : self.VVN3As(path, selFile, VVhXh6 )
   elif item == "VVN3As_ForceDowngrade" : self.VVN3As(path, selFile, VVQjjG )
   elif item == "VVN3As_IgnoreDepends" : self.VVN3As(path, selFile, VVlHps )
   elif item == "VVXpG0_ExistingPackage" : self.VVXpG0(path, selFile, VV2r4e     )
   elif item == "VVXpG0_ForceRemove"  : self.VVXpG0(path, selFile, VVyJXQ  )
   elif item == "VVXpG0_IgnoreDepends"  : self.VVXpG0(path, selFile, VV2nyt )
   elif item == "VV0w1C"     : self.VV0w1C(path, selFile)
   elif item == "VV8MHO"     : self.VV8MHO(path, selFile)
 def VVmiYO(self, path, selFile):
  if FFtTXa("ar") : cmd = "allOK='1';"
  else    : cmd  = FFJDAH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFtL5B(self, cmd, VVBjuq=self.VVPRyY)
 def VV0w1C(self, path, selFile):
  lastPart = FFzOGe(path)
  dest  = FFghFX(path, True) + selFile[:-4]
  cmd  =  FFJDAH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFaBql("mkdir '%s'" % dest)
  cmd +=    FFaBql("cd '%s'" % dest)
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFPk5q(dest, VVCKEk))
  cmd += "fi;"
  FFeWwS(self, cmd, VVBjuq=self.VVPRyY)
 def VV8MHO(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VVMwIx = os.path.splitext(path)[0]
  else        : VVMwIx = path + "_"
  if path.endswith(".deb")   : VV0SKl = "DEBIAN"
  else        : VV0SKl = "CONTROL"
  cmd  = FFJDAH()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' > /dev/null 2>&1;" % VVMwIx
  cmd += "  mkdir '%s';"      % VVMwIx
  cmd += "  CONTPATH='%s/%s';"    % (VVMwIx, VV0SKl)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"       % VVMwIx
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"      % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVMwIx, VVMwIx)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVMwIx
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VVMwIx, VVMwIx)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VVMwIx
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VVMwIx
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VVMwIx, FFPk5q(VVMwIx, VVCKEk))
  cmd += "fi;"
  FFeWwS(self, cmd, VVBjuq=self.VVPRyY)
 def VVfg8Z(self, path):
  listCmd  = FFYH4A(VV5oWt, "")
  infoCmd  = FFgOTM(VVl8YC , "")
  filesCmd = FFgOTM(VVDid1, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFdk7R(VV0V0q)
   notInst = "Package not installed."
   cmd  = FF9OqO("File Info", VV0V0q)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FF9OqO("System Info", VV0V0q)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFPk5q(notInst, VVmxw7))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FF9OqO("Related Files", VV0V0q)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFxN9O(self, cmd)
  else:
   FF5yx0(self)
 def VVN3As(self, path, selFile, cmdOpt):
  cmd = FFgOTM(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFEN35(self, BF(FFeWwS, self, cmd, VVBjuq=FFbfAi), "Install Package ?\n\n%s" % selFile)
  else:
   FF5yx0(self)
 def VVXpG0(self, path, selFile, cmdOpt):
  listCmd  = FFYH4A(VV5oWt, "")
  infoCmd  = FFgOTM(VVl8YC, "")
  instRemCmd = FFgOTM(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFPk5q(errTxt, VVmxw7))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFPk5q(cannotTxt, VVmxw7))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFPk5q(tryTxt, VVmxw7))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFEN35(self, BF(FFeWwS, self, cmd, VVBjuq=FFbfAi), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FF5yx0(self)
 def VVLeuv(self, path):
  hostName = FFz86l("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVGtAd(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVtZf8 = []
  VVtZf8.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVtZf8.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVtZf8.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVtZf8.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVtZf8.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVtZf8.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVtZf8.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVtZf8.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVtZf8.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVtZf8.append(VVh3VV)
   VVtZf8.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVtZf8.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFd7BR(self, BF(self.VVttrl, path, isDir, title), VVtZf8=VVtZf8, title=title, VVRmfT=c1, VVRNJt=c2)
 def VVttrl(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVtYSG(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVtYSG(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVtYSG(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVtYSG(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVtYSG(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVtYSG(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVtYSG(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVtYSG(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVtYSG(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVtYSG(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVjkVG(path, False)
   elif item == "convertDirToDeb" : self.VVjkVG(path, True)
 def VVjkVG(self, path, VVITRg):
  self.session.openWithCallback(self.VVPRyY, BF(CCMlOB, path=path, VVITRg=VVITRg))
 def VVtYSG(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FFghFX(path, True)
  lastPart = FFzOGe(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FFhejV("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FFhejV("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FFhejV("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFaBql("rm -f '%s'" % archFile)
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFPk5q(failed, VVD46d))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFPk5q(srcTxt, VVTVZG))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFPk5q("Output", VVCKEk))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFPk5q(failed, VVKRbh))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFtL5B(self, cmd, VVBjuq=self.VVPRyY, title=title)
 def VVPr6U(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CC5iId.VVs8dI(FFghFX(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCQq9Y(self, self, title, BF(self.VVwJEh, pathLst))
 def VVwJEh(self, pathLst):
  return CCQq9Y.VVkpUX(pathLst)
 def VV0Uaf(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVrNQ4, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFEN35(self, BF(FFn5td, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFn5td(self, fnc, title=txt)
  else:
   FFBsVa(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVrNQ4(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFVBx2(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVPRyY()
  else:
   FFKqXn(tarPath)
   FFBsVa(self, "Error while converting.", title=title)
 def VVRsyc(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVSrr0, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFEN35(self, BF(FFn5td, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFn5td(self, fnc, title=txt)
  else:
   FFBsVa(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVSrr0(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FFVBx2(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVPRyY()
  else:
   FFKqXn(zipPath)
   FFBsVa(self, "Error while converting.", title=title)
 def VVZw8o(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FF9GYH(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFkQDN("rm -f '%s' '%s'" % (m1v, mvi))
  if FFkQDN("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFkQDN("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVPRyY()
   FFx4Fl(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFBsVa(self, "Cannot convert this file !", title=title)
 def VVQxUl(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCjCYH.VVzyVV()
  if pathExists(pPath):
   if CC7MvF.VVIckV(self, title, False, cbFnc=BF(self.VVQxUl, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVtZf8 = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVtZf8.append(("%d x %d" % (item), item))
    VVlTMa = self.VVo784
    VVR5O9 = ("Stretch", BF(self.VVeOaw, title, path, picon))
    VVlE2Q = FFd7BR(self, BF(self.VVsW8Q, title, path, picon, False), VVtZf8=VVtZf8, width=700, title='PIcon Max. Size', VVlTMa=VVlTMa, VVR5O9=VVR5O9, barText="OK = Fit within size")
    VVlE2Q.VVIgUV(3)
  else:
   FFBsVa(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVeOaw(self, title, path, picon, selectionObj, item):
  self.VVsW8Q(title, path, picon, True, item)
  selectionObj.cancel()
 def VVsW8Q(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFqy2T(self, fncMode=CCFLza.VVO8n6)
   except Exception as e:
    FFBsVa(self, "Image Processing error:\n\n%s" % e)
 def VVo784(self, VVlE2Q, txt, ref, ndx):
  FF4fCC(self, "_help_resize", "Picture File Resizing")
 def VVXAZ2(self, path):
  FFd7BR(self, BF(self.VV3YFO, path), VVtZf8=CCnYqq.VVJ1iq(), width=650, title="Select Player", VVRmfT="#11220000", VVRNJt="#11220000")
 def VV3YFO(self, path, rType=None):
  if rType:
   FFn5td(self, BF(self.VV0HP2, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VV0HP2(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCQFZI.VVbh0Z(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VVOhYP(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF9GYH(fDir), fName
  return "", "", ""
 @staticmethod
 def VVPQRH(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVpbj4(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVp3Jg(size, mode=0):
  txt = CC5iId.VVM2Dv(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VVM2Dv(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VV45v0(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVHX4f(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFBsVa(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VVHMT3():
  tDict = CCYpe9.VVtxMu()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVs8dI(path):
  lst = []
  for ext in CC5iId.VVHMT3():
   lst.extend(FF8hHp(path, "*.%s" % ext))
  return sorted(lst, key=FFKuFF(FFvHSH))
 @staticmethod
 def VVgNvP(path):
  return FFkQDN("tar -tzf '%s'" % path)
 @staticmethod
 def VVg6qp(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVuDDL(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VV7PZ9:
   return VV7PZ9
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCYpe9(MenuList):
 VVVzFF   = 0
 VVvGNu   = 1
 VVhgwH   = 2
 VVymZS   = 3
 VVxtLy   = 4
 VV7xkq   = 5
 VVbo8s   = 6
 VVDnQ3   = 7
 VVP1wl   = "<List of Storage Devices>"
 VVxzrQ  = "<Parent Directory>"
 VVc1Sl   = 0
 VVqW5g   = 1
 VVIty0 = 2
 VVIO8m  = 3
 VVgL0E   = 4
 VVzptD   = 5
 FILE_TYPE_LINK   = 6
 VVZgZG  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVpzqd=False, directory="/", VVJRkE=True, VVlQUo=True, VVAC6T=True, VV0f8o=None, VVhUjR=False, VVmszM=False, VVsGrS=False, isTop=False, VV8fs4=None, VVMAO9=1000, VVJgEp=30, VV2u5U=30):
  MenuList.__init__(self, list, VVpzqd, eListboxPythonMultiContent)
  self.VVJRkE  = VVJRkE
  self.VVlQUo    = VVlQUo
  self.VVAC6T  = VVAC6T
  self.VV0f8o  = VV0f8o
  self.VVhUjR   = VVhUjR
  self.VVmszM   = VVmszM or []
  self.VVsGrS   = VVsGrS or []
  self.isTop     = isTop
  self.additional_extensions = VV8fs4
  self.VVMAO9    = VVMAO9
  self.VVJgEp    = VVJgEp
  self.VV2u5U    = VV2u5U
  self.EXTENSIONS    = CCYpe9.VVtxMu()
  self.VVntaB   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFV5jv("#11ff4444")
  self.l.setFont(0, gFont(VVQgMh, self.VVJgEp))
  self.l.setItemHeight(self.VV2u5U)
  self.png_mem   = CCYpe9.VVSzzU("mem")
  self.png_usb   = CCYpe9.VVSzzU("usb")
  self.png_fil   = CCYpe9.VVSzzU("fil")
  self.png_dir   = CCYpe9.VVSzzU("dir")
  self.png_dirup   = CCYpe9.VVSzzU("dirup")
  self.png_srv   = CCYpe9.VVSzzU("srv")
  self.png_slwfil   = CCYpe9.VVSzzU("slwfil")
  self.png_slbfil   = CCYpe9.VVSzzU("slbfil")
  self.png_slwdir   = CCYpe9.VVSzzU("slwdir")
  self.VVyQ8h()
  self.VVtiSX(directory)
 @staticmethod
 def VVSzzU(category):
  return LoadPixmap("%s%s.png" % (VVG8hM, category), getDesktop(0))
 @staticmethod
 def VVtxMu():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVF0Pv(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FF3NDk(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFxrb0(" -> " , VV0V0q) + FFxrb0(os.readlink(path), VVCKEk)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VV2u5U + 10, 0, self.VVMAO9, self.VV2u5U, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   tableRow.append(CCLGNO.VVZhgD(0, 2, self.VV2u5U-4, self.VV2u5U-4, png))
  return tableRow
 def VVxeAu(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVyQ8h(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VVNogN(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVymsj(self, file):
  if os.path.realpath(file) == file:
   return self.VVNogN(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VVNogN(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VVNogN(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVoR3z(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVJdef(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VVPizx(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVJdef(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVJdef(self, row, bg):
  if self.VV7Bo9(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VV7Bo9(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VVzptD, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVgL0E:
    if   VV0GEW           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVSdo7(self):
  return self.VV7Bo9(self.list[self.l.getCurrentSelectionIndex()])
 def VVM0oZ(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVI54m(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVtiSX(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVAC6T:
    self.current_mountpoint = self.VVymsj(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVAC6T:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVsGrS and not self.VVI54m(path, self.VVmszM):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVF0Pv(name=p.description, absolute=path, isDir=True, typ=self.VVc1Sl, png=png))
    path = "/"
    if path not in self.VVsGrS and not self.VVI54m(path, self.VVmszM):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVF0Pv(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VVqW5g, png=self.png_mem))
  elif self.VVhUjR:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVntaB = eServiceCenter.getInstance()
   list = VVntaB.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VVJRkE and not self.isTop:
   if directory == self.current_mountpoint and self.VVAC6T:
    self.list.append(self.VVF0Pv(name=self.VVP1wl, absolute=None, isDir=True, typ=self.VVIty0, png=self.png_dirup))
   elif (directory != "/") and not (self.VVsGrS and self.VVNogN(directory) in self.VVsGrS):
    self.list.append(self.VVF0Pv(name=self.VVxzrQ, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVIO8m, png=self.png_dirup))
  if self.VVJRkE:
   for x in directories:
    if not (self.VVsGrS and self.VVNogN(x) in self.VVsGrS) and not self.VVI54m(x, self.VVmszM):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVF0Pv(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FF3NDk(x)) else self.VVgL0E, png=png))
  if self.VVlQUo:
   for x in files:
    if self.VVhUjR:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FFxrb0(" -> " , VV0V0q) + FFxrb0(target, VVCKEk)
       else:
        png = self.png_slbfil
        name += FFxrb0(" -> " , VV0V0q) + FFxrb0(target, VVKRbh)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VVxeAu(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVG8hM, category))
    if (self.VV0f8o is None) or iCompile(self.VV0f8o[0], flags=self.VV0f8o[1]).search(path):
     self.list.append(self.VVF0Pv(name=name, absolute=x , isDir=False, typ=self.VVzptD, png=png))
  if self.VVAC6T and len(self.list) == 0:
   self.list.append(self.VVF0Pv(name=FFxrb0("No USB connected", VVUpvF), absolute=None, isDir=False, typ=self.VVZgZG, png=self.png_usb))
  self.l.setList(self.list)
  self.VVScFc()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VV9o2M(self):
  return self.current_directory
 def VVN6qu(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VV5cfZ(self):
  return self.VVPKZ6() and self.VV9o2M()
 def VVPKZ6(self):
  return self.list[0][1][7] in (self.VVP1wl, self.VVxzrQ)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVtiSX(self.getSelection()[0], self.current_directory)
 def VVOrqT(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVjccH)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVjccH)
 def VVjccH(self, action, device):
  self.VVyQ8h()
  if self.current_directory is None:
   self.VVXMa9()
 def VVXMa9(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVtiSX(self.current_directory, self.VVOrqT())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVr5qe(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVVzFF : nameAlpMode, nameAlpTxt = self.VVvGNu, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVVzFF, sAZ
  if mode == self.VVhgwH : nameNumMode, nameNumTxt = self.VVymZS, s90
  else       : nameNumMode, nameNumTxt = self.VVhgwH, s09
  if mode == self.VVxtLy : dateMode, dateTxt = self.VV7xkq, sON
  else       : dateMode, dateTxt = self.VVxtLy, sNO
  if mode == self.VVbo8s : typeMode, typeTxt = self.VVDnQ3, sZA
  else       : typeMode, typeTxt = self.VVbo8s, sAZ
  if   mode in (self.VVVzFF, self.VVvGNu): txt = "Name (%s)" % (sAZ if mode == self.VVVzFF else sZA)
  elif mode in (self.VVhgwH, self.VVymZS): txt = "Name (%s)" % (s09 if mode == self.VVVzFF else s90)
  elif mode in (self.VVxtLy, self.VV7xkq): txt = "Date (%s)" % (sNO if mode == self.VVxtLy else sON)
  elif mode in (self.VVbo8s, self.VVDnQ3): txt = "Type (%s)" % (sAZ if mode == self.VVbo8s else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVScFc(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFSeyu(CFG.browserSortMode, mode)
   FFSeyu(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVPKZ6() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVVzFF, self.VVvGNu):
    rev = True if mode == self.VVvGNu else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VVhgwH, self.VVymZS):
    rev = True if mode == self.VVymZS else False
    self.list = sorted(self.list[item0:], key=FFKuFF(BF(self.VVRkms, isMix, rev)), reverse=rev)
   elif mode in (self.VVxtLy, self.VV7xkq):
    rev = True if mode == self.VV7xkq else False
    self.list = sorted(self.list[item0:], key=FFKuFF(BF(self.VVdB2F, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVDnQ3 else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVRkms(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFvHSH(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFPIiD(dir2, dir1) or FFvHSH(name1, name2)
 def VVdB2F(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFPIiD(stat2.st_ctime, stat1.st_ctime)
    else : return FFPIiD(dir2, dir1) or FFPIiD(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCPUUw(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FF98gL(VVUEeM, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVBQW6   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVWmcY(defFG, "#00FFFFFF")
  self.defBG   = self.VVWmcY(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFd98D(self, self.Title)
  self["keyRed"].show()
  FF1N71(self["keyGreen"] , "< > Transp.")
  FF1N71(self["keyYellow"], "Foreground")
  FF1N71(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(VVO7iZ,
  {
   "ok"   : self.VVQ2Lb     ,
   "green"   : self.VVQ2Lb     ,
   "yellow"  : BF(self.VV5Jc4, False)  ,
   "blue"   : BF(self.VV5Jc4, True)  ,
   "up"   : self.VVSK0n       ,
   "down"   : self.VVvWX5      ,
   "left"   : self.VV3UwQ      ,
   "right"   : self.VVWKwc      ,
   "last"   : BF(self.VVCt1O, -5) ,
   "next"   : BF(self.VVCt1O, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV583n)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFwVrd(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFwVrd(self["keyRed"] , c)
  FFwVrd(self["keyGreen"] , c)
  self.VVBzTV()
  self.VVL4eY()
  FFBe4X(self["myColorTst"], self.defFG)
  FFwVrd(self["myColorTst"], self.defBG)
 def VVWmcY(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VVL4eY(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VV9DnY(0, 0)
     return
 def VVQ2Lb(self):
  self.close(self.defFG, self.defBG)
 def VVSK0n(self): self.VV9DnY(-1, 0)
 def VVvWX5(self): self.VV9DnY(1, 0)
 def VV3UwQ(self): self.VV9DnY(0, -1)
 def VVWKwc(self): self.VV9DnY(0, 1)
 def VV9DnY(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VVEKnD()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVZl4Q()
 def VVBzTV(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVZl4Q(self):
  color = self.VVEKnD()
  if self.isBgMode: FFwVrd(self["myColorTst"], color)
  else   : FFBe4X(self["myColorTst"], color)
 def VV5Jc4(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVBzTV()
   self.VVL4eY()
 def VVCt1O(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VV9DnY(0, 0)
 def VVQUiz(self):
  return hex(self.transp)[2:].zfill(2)
 def VVEKnD(self):
  return ("#%s%s" % (self.VVQUiz(), self.colors[self.curRow][self.curCol])).upper()
class CCAayk(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FF98gL(VVtwgT, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFd98D(self, title="%s%s%s" % (self.Title, " " * 10, FFxrb0("Change values with Up , Down, < , 0 , >", VVUpvF)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(VVO7iZ,
  {
   "ok"  : self.VVnIt0      ,
   "cancel" : self.VVBrRb      ,
   "info"  : self.VVBlCN    ,
   "red"  : self.VVUmXa  ,
   "green"  : self.VVIrk5   ,
   "yellow" : BF(self.VVVPBm, 0)  ,
   "blue"  : self.VVuTWe    ,
   "menu"  : self.VVchMD      ,
   "left"  : self.VV3UwQ      ,
   "right"  : self.VVWKwc      ,
   "last"  : self.VVfhf2     ,
   "next"  : self.VVg4nU     ,
   "0"   : self.VVaW46    ,
   "up"  : self.VVSK0n       ,
   "down"  : self.VVvWX5      ,
   "pageUp" : BF(self.VVzg5h, True) ,
   "pageDown" : BF(self.VVzg5h, False) ,
   "chanUp" : BF(self.VVzg5h, True) ,
   "chanDown" : BF(self.VVzg5h, False) ,
   "play"  : BF(self.VVE49v, "pause")  ,
   "pause"  : BF(self.VVE49v, "pause")  ,
   "playPause" : BF(self.VVE49v, "pause")  ,
   "stop"  : BF(self.VVE49v, "pause")  ,
   "audio"  : BF(self.VVE49v, "audio")  ,
   "subtitle" : BF(self.VVE49v, "subtitle") ,
   "rewind" : BF(self.VVE49v, "rewind" ) ,
   "forward" : BF(self.VVE49v, "forward" ) ,
   "rewindDm" : BF(self.VVE49v, "rewindDm") ,
   "forwardDm" : BF(self.VVE49v, "forwardDm")
  }, -1)
  self.VVzJal()
  self.onShown.append(self.VV583n)
  self.onClose.append(self.VVbNta)
 def VVzJal(self):
  lst = []
  for fil in FF8hHp(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVTiT1:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VV583n(self):
  self.onShown.remove(self.VV583n)
  FFRet2(self)
  FFD5nM(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVr8BE()
  self.VVINhB()
  self.VVprOb()
 def VVbNta(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVDcGW(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFwVrd(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VVqNCq()
 def VVr8BE(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFwVrd(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVnIt0(self):
  if self.settingShown:
   confItem = self.VVtoQn()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVtZf8 = []
   if isinstance(lst[0], tuple):
    for item in lst: VVtZf8.append((item[1], item[0]))
   else:
    for item in lst: VVtZf8.append((item, item))
   VVlE2Q = FFd7BR(self, self.VV7Uux, VVtZf8=VVtZf8, width=700, title=title, VVRmfT="#33221111", VVRNJt="#33110011")
   VVlE2Q.VV7hwP(confItem.getText())
  else:
   self.close("subtExit")
 def VV7Uux(self, item=None):
  if item:
   self.VVtoQn()[self.CursorPos].setValue(item)
   self.VVqNCq()
   self.VVINhB()
   self.VVr8cU(True)
 def VVBrRb(self):
  for confItem in self.VVtoQn():
   if confItem.isChanged():
    FFEN35(self, BF(self.VVIA85, cbFnc=self.VVyiby), "Save Changes ?", callBack_No=self.VVJec3, title=self.Title)
    break
  else:
   self.VVyiby()
 def VVyiby(self):
   if self.settingShown: self.VVr8BE()
   else    : self.close("subtExit")
 def VVchMD(self):
  if self.settingShown: self.VVUW3I()
  else    : self.VVDcGW()
 def VV3UwQ(self): self.VVsoqg(-1)
 def VVWKwc(self): self.VVsoqg(1)
 def VVsoqg(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVkCZo()
   if pos == -1: ndx = self.VVjpWW(posVal)
   else  : ndx = self.VVbDAh(posVal)
   if   ndx < 0      : FFrBcM(self, "Not found" , 500)
   elif ndx == 0      : FFrBcM(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FFrBcM(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VVLYYy(frmSec)
    if allow:
     self.VVVPBm(delay, True)
     self.VVr8cU(force=True)
     CC2Wqe(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FFrBcM(self, "Delay out of range", 800)
 def VVzg5h(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VVE49v(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVfhf2(self) : self.VVpbau(5)
 def VVg4nU(self) : self.VVpbau(6)
 def VVaW46(self) : self.VVpbau(-1)
 def VVSK0n(self):
  if self.settingShown: self.VVpbau(1)
  else    : self.VVzg5h(True)
 def VVvWX5(self):
  if self.settingShown: self.VVpbau(0)
  else    : self.VVzg5h(False)
 def VVpbau(self, direction):
  if self.settingShown:
   confItem = self.VVtoQn()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VVqNCq()
   self.VVINhB()
   self.VVr8cU(True)
 def VVtoQn(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VVJec3(self):
  for confItem in self.VVtoQn(): confItem.cancel()
  self.VVqNCq()
  self.VVINhB()
  self.VVr8BE()
 def VVUmXa(self):
  if self.settingShown:
   FFEN35(self, self.VVrwnT, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVrwnT(self):
  for confItem in self.VVtoQn(): confItem.setValue(confItem.default)
  self.VVIA85()
  self.VVqNCq()
  self.VVINhB()
 def VVVPBm(self, delay, force=False):
  if self.settingShown or force:
   FFSeyu(CFG.subtDelaySec, delay)
   self.VVHK5D()
   self.VVqNCq()
   self.VVINhB()
   if self.settingShown:
    FFrBcM(self, 'Reset to "0"', 800, isGrn=True)
 def VVIrk5(self):
  if self.settingShown:
   self.VVIA85()
   self.VVr8BE()
 def VVIA85(self, cbFnc=None):
  for confItem in self.VVtoQn(): confItem.save()
  configfile.save()
  self.VVHK5D()
  FFrBcM(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VVqNCq(self):
  cfgLst = self.VVtoQn()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VVINhB(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFJIrJ(path, fnt, isRepl=1)
  else:
   fnt = VVQgMh
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FFUY5i(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFBe4X(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFwVrd(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFMSMB(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FFUY5i(CFG.subtVerticalPos.getValue(), 0, 100, 0, FF3tfX()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFM0oF(self, winW, winH)
 def VVBlCN(self):
  sp = "    "
  txt  = "%s\n"   % FFxrb0("Subtitle File:", VVwwau)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFxrb0("Subtitle Settings:", VVwwau)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVkCZo()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FFNguX(frmSec1)
   time2 = FFNguX(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFxrb0("Timing:", VVwwau)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FFNguX(durVal)
   txt += sp + "Progress\t: %s\n" % FFNguX(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFxrb0("Subtitle end reached.", VVD46d)
  FFVBx2(self, txt, title="Current Subtitle")
 def VVprOb(self, path="", delay=0, enc=""):
  FFn5td(self, BF(self.VVWgTR, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVWgTR(self, path="", delay=0, enc=""):
  FFrBcM(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVUsZf(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VVqNCq()
     self.VVEM6q()
   else:
    path, delay, enc = CCAayk.VVcqbj(self)
    if path:
     self.VVprOb(path=path, delay=delay, enc=enc)
    else:
     self.VVUW3I()
  except:
   pass
 def VVEM6q(self):
  posVal, durVal = self.VVkCZo()
  if self.VVmlLK(posVal):
   return
  CCAayk.VVb8VR(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVr8cU)
  except:
   self.timerUpdate.callback.append(self.VVr8cU)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVmyeZ)
  except:
   self.timerEndText.callback.append(self.VVmyeZ)
  FFrBcM(self, "Subtitle started", 700, isGrn=True)
 def VVmlLK(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CCAayk.VVSpJT(self)
   FFKqXn(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VVUW3I(self):
  c1, c2, c3, c4, c5 = "", VVwwau, VVquhO, VVOICC, VVD46d
  VVtZf8 = []
  VVtZf8.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVtZf8.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVtZf8.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVtZf8.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVtZf8.append(VVh3VV)
   VVtZf8.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVtZf8.append(VVh3VV)
   VVtZf8.append(("Help (Keys)"        , "help"  ))
  FFd7BR(self, self.VVRrMg, VVtZf8=VVtZf8, width=700, title='Find Subtitle ".srt" File', VVRmfT="#33221111", VVRNJt="#33110011")
 def VVRrMg(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVUIeI(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVUIeI(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVTrVo, BF(CC5iId, patternMode="srt", VV0aja=sDir))
   elif item.startswith("sugSrt") : self.VVUIeI(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFn5td(self, BF(CCiVik.VV2psM, self, self.lastSubtFile, self.VVyNpU, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FFrBcM(self, "SRT File error", 1000)
   elif item == "disab":
    FFKqXn(CCAayk.VVSpJT(self))
    self.close("subtExit")
   elif item == "help"    : FF4fCC(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVyNpU(self, item=None):
  if item:
   FFn5td(self, BF(self.VVprOb, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVTrVo(self, path):
  if path:
   FFSeyu(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVprOb(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVUIeI(self, defSrt="", mode=0, coeff=0.25):
  FFn5td(self, BF(self.VVy2mN, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVy2mN(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CCAayk.VVM1i6(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFIM7p('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFwS2p(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VV6wdx(srtList, coeff)
     if err:
      if self.settingShown: FFQAm4(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVaKg1 = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FF9GYH(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVaKg1.append((fName, Dir))
   VVTXLQ  = ("Select"    , self.VVaz2e     , [])
   VV0cge = self.VVADsn
   VVZRP4 = (""     , self.VVfPpG       , [])
   VVeJ6x = (""     , BF(self.VVcN33, defSrt, False) , [])
   VVIZTW = ("Find Current File" , BF(self.VVcN33, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VV3FCq=widths, VVJgEp=28, VVTXLQ=VVTXLQ, VV0cge=VV0cge, VVZRP4=VVZRP4, VVeJ6x=VVeJ6x, VVIZTW=VVIZTW, lastFindConfigObj=CFG.lastFindSubtitle
     , VVRmfT="#11002222", VVRNJt="#33001111", VV84wP="#33001111", VVH7qA="#11ffff00", VVvmBM="#11445544", VVfpy3="#22222222", VViJnU="#11002233")
  elif self.settingShown : FFQAm4(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVADsn(self, VVzzNZ):
  VVzzNZ.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VVfPpG(self, VVzzNZ, title, txt, colList):
  fName, Dir = colList
  FFVBx2(VVzzNZ, "%s\n\n%s%s" % (FFxrb0("Path:", VVwwau), Dir, fName), title=title)
 def VVcN33(self, path, VVg3ap, VVzzNZ, title, txt, colList):
  for ndx, row in enumerate(VVzzNZ.VVMHVB()):
   if path == row[1].strip() + row[0].strip():
    VVzzNZ.VV8i74(ndx)
    break
  else:
   if VVg3ap:
    FFrBcM(VVzzNZ, "Not in list !", 1000)
 def VVaz2e(self, VVzzNZ, title, txt, colList):
  VVzzNZ.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVprOb(path=path)
 def VV6wdx(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCNVQf.VV8rAN(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCNVQf.VV5Zdo(evName, "en")[0] or evName
   lst, err = CCAayk.VV3erH(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVUsZf(self, path, enc=None):
  if enc and CCiVik.VViPTu(path, enc)      : enc = enc
  elif CCiVik.VViPTu(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFotbw(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFMy5k(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVQxq8(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVicMi(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VVHK5D()
  return subtList, ""
 def VVicMi(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVQxq8(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VVHK5D(self):
  path = CCAayk.VVSpJT(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVr8cU(self, force=False):
  posVal, durVal = self.VVkCZo()
  if self.VVmlLK(posVal):
   return
  curIndex = self.VVFxRS(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVmyeZ()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFBe4X(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVkCZo(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCQFZI.VVYaVF(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCNVQf.VV8rAN(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VVFxRS(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVjpWW(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVbDAh(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVmyeZ(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFBe4X(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVuTWe(self):
  FFn5td(self, self.VVxWqF, title="Loading Lines ...")
 def VVxWqF(self):
  VVaKg1 = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVaKg1.append((cap, FFNguX(frm), str(frm), firstLine))
  if VVaKg1:
   title = "Select Current Subtitle Line"
   VV8TXR  = self.VV6yEZ
   VV0cge = self.VVxsuT
   VVTXLQ  = ("Select"   , self.VVMFSI , [title])
   VVIZTW = ("Current Line" , self.VVuNun , [True])
   VVFaAj = ("Reset Delay" , self.VVKFeE , [])
   VV6CVp = ("New Delay"  , self.VV7cK8   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVGQvW  = (CENTER , CENTER, CENTER , LEFT    )
   VVzzNZ = FFuI68(self, None, title=title, header=header, VVBQW6=VVaKg1, VVGQvW=VVGQvW, VV3FCq=widths, VVJgEp=28, VV8TXR=VV8TXR, VV0cge=VV0cge, VVTXLQ=VVTXLQ, VVIZTW=VVIZTW, VVFaAj=VVFaAj, VV6CVp=VV6CVp
          , VVRmfT="#33002222", VVRNJt="#33001111", VV84wP="#33110011", VVH7qA="#11ffff00", VVvmBM="#0a334455", VVfpy3="#22222222", VViJnU="#33002233")
  else:
   FFQAm4(self, "Cannot read lines !", 2000)
 def VV6yEZ(self, VVzzNZ):
  self.subtLinesTable = VVzzNZ
  if CFG.subtDelaySec.getValue():
   VVzzNZ["keyYellow"].show()
   VVzzNZ["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVzzNZ["keyYellow"].hide()
  VVzzNZ["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFwVrd(VVzzNZ["keyBlue"], "#22222222")
  VVzzNZ.VVLx7i(BF(self.VVfIDS, VVzzNZ))
  self.VVuNun(VVzzNZ, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVhtyO)
  except:
   self.timerSubtLines.callback.append(self.VVhtyO)
  self.timerSubtLines.start(1000, False)
 def VVxsuT(self, VVzzNZ):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVzzNZ.cancel()
 def VVhtyO(self):
  if self.subtLinesTable:
   VVzzNZ = self.subtLinesTable
   posVal, durVal = self.VVkCZo()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVFxRS(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVzzNZ.VVgdey(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVzzNZ.VVNshL(self.subtLinesTableNdx, row)
     row = VVzzNZ.VVgdey(curIndex)
     row[0] = color + row[0]
     VVzzNZ.VVNshL(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVMFSI(self, VVzzNZ, Title):
  delay, color, allow = self.VVxR4f(VVzzNZ)
  if allow:
   self.VVxsuT(VVzzNZ)
   self.VVVPBm(delay, True)
  else:
   FFrBcM(VVzzNZ, "Delay out of range", 1500)
 def VVuNun(self, VVzzNZ, VVg3ap, onlyColor=False):
  if VVzzNZ:
   posVal, durVal = self.VVkCZo()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VVFxRS(posVal)
    if curIndex > -1:
     VVzzNZ.VV8i74(curIndex)
    else:
     ndx = self.VVjpWW(posVal)
     if ndx > -1:
      VVzzNZ.VV8i74(ndx)
 def VVKFeE(self, VVzzNZ, title, txt, colList):
  if VVzzNZ["keyYellow"].getVisible():
   self.VVVPBm(0, True)
   VVzzNZ["keyYellow"].hide()
   self.VVuNun(VVzzNZ, False)
 def VVfIDS(self, VVzzNZ):
  delay, color, allow = self.VVxR4f(VVzzNZ)
  VVzzNZ["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVxR4f(self, VVzzNZ):
  lineTime = float(VVzzNZ.VVQ0F0()[2].strip())
  return self.VVLYYy(lineTime)
 def VVLYYy(self, lineTime):
  posVal, durVal = self.VVkCZo()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVs7I8
   else     : allow, color = False, VVD46d
   delay = FFMpNv(val, -600, 600)
  return delay, color, allow
 def VV7cK8(self, VVzzNZ, title, txt, colList):
  pass
 @staticmethod
 def VVvjwu(SELF):
  path, delay, enc = CCAayk.VVcqbj(SELF)
  return True if path else False
 @staticmethod
 def VVcqbj(SELF):
  path, delay, enc = CCAayk.VVx3gY(SELF)
  if not path:
   path = CCAayk.VVyTZg(SELF)
  return path, delay, enc
 @staticmethod
 def VVx3gY(SELF):
  srtCfgPath = CCAayk.VVSpJT(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFMy5k(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVSpJT(SELF):
  fPath, fDir, fName = CC5iId.VVOhYP(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCNVQf.VV8rAN(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFMcRT(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVyTZg(SELF):
  bestRatio = 0
  fPath, fDir, fName = CC5iId.VVOhYP(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CCAayk.VVM1i6(SELF)
    bLst, err = CCAayk.VV3erH(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVM1i6(SELF):
  fPath, fDir, fName = CC5iId.VVOhYP(SELF)
  if pathExists(fDir):
   files = FF8hHp(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VV3erH(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVDyQr():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVb8VR(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CCAayk.VVVE0X()
 @staticmethod
 def VVVE0X():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CC0aUK(ScrollLabel):
 def __init__(self, parentSELF, text="", VVqlsY=True):
  ScrollLabel.__init__(self, text)
  self.VVqlsY   = VVqlsY
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VVFTHJ  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVJgEp    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(VVO7iZ,
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VVuAol ,
   "green"   : self.VVtxMZ ,
   "yellow"  : self.VVBr2L ,
   "blue"   : self.VV7e9n ,
   "up"   : self.VV4BB5   ,
   "down"   : self.VVjNpQ  ,
   "left"   : self.VV4BB5   ,
   "right"   : self.VVjNpQ  ,
   "last"   : BF(self.VVWurv, 0) ,
   "0"    : BF(self.VVWurv, 1) ,
   "next"   : BF(self.VVWurv, 2) ,
   "pageUp"  : self.VVVrl1   ,
   "chanUp"  : self.VVVrl1   ,
   "pageDown"  : self.VVHwMO   ,
   "chanDown"  : self.VVHwMO
  }, -1)
 def VVc45w(self, isResizable=True, VV8l2N=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFBe4X(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFwVrd(self.parentSELF["keyRedTop"], "#113A5365")
  FFRet2(self.parentSELF, True)
  self.isResizable = isResizable
  if VV8l2N:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVJgEp  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFwVrd(self, color)
 def VVXDge(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VV2u5U  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VV2u5U)
  margin   = int(VV2u5U / 6)
  self.pageHeight = int(self.pageLines * VV2u5U)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VVFTHJ - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVPj69()
 def VV4BB5(self):
  if self.VVFTHJ > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVjNpQ(self):
  if self.VVFTHJ > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVVrl1(self):
  self.setPos(0)
 def VVHwMO(self):
  self.setPos(self.VVFTHJ-self.pageHeight)
 def VVLQjH(self):
  return self.VVFTHJ <= self.pageHeight or self.curPos == self.VVFTHJ - self.pageHeight
 def getText(self):
  return self.message
 def VVPj69(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VVFTHJ, 3))
   start = int((100 - vis) * self.curPos / (self.VVFTHJ - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VVeLJi=VVDwe9):
  old_VVLQjH = self.VVLQjH()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VVFTHJ = self.long_text.calculateSize().height()
   if self.VVqlsY and self.VVFTHJ > self.pageHeight:
    self.scrollbar.show()
    self.VVPj69()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VVFTHJ))
    self.VVFTHJ = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VVFTHJ))
   else:
    self.scrollbar.hide()
   if   VVeLJi == VV8sAj: self.setPos(0)
   elif VVeLJi == VVEkFU : self.VVHwMO()
   elif old_VVLQjH    : self.VVHwMO()
 def appendText(self, text, VVeLJi=VVEkFU):
  self.setText(self.message + str(text), VVeLJi=VVeLJi)
 def VVBr2L(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVOld2(size)
 def VV7e9n(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVOld2(size)
 def VVtxMZ(self):
  self.VVOld2(self.VVJgEp)
 def VVOld2(self, VVJgEp):
  self.long_text.setFont(gFont(self.fontFamily, VVJgEp))
  self.setText(self.message, VVeLJi=VVDwe9)
  self.VVK7a0()
 def VVWurv(self, align):
  self.long_text.setHAlign(align)
 def VVuAol(self):
  VVtZf8 = []
  VVtZf8.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Align Left" , "left" ))
  VVtZf8.append(("Align Center" , "center" ))
  VVtZf8.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVtZf8.append(VVh3VV)
   VVtZf8.append((FFxrb0("Save to File", VVwwau), "save"))
  VVtZf8.append(VVh3VV)
  VVtZf8.append(("Keys (Shortcuts)", "help"))
  FFd7BR(self.parentSELF, self.VVz5sx, VVtZf8=VVtZf8, title="Text Option", width=500)
 def VVz5sx(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVWurv(0)
   elif item == "center" : self.VVWurv(1)
   elif item == "right" : self.VVWurv(2)
   elif item == "save"  : self.VVFKZU()
   elif item == "help"  : FF4fCC(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVFKZU(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FF9GYH(expPath), self.outputFileToSave, FF0Isj())
   with open(outF, "w") as f:
    f.write(FFpnOy(self.message))
   FFx4Fl(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFBsVa(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVK7a0(self, minHeight=0):
  if self.isResizable:
   VV2u5U = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VV2u5U * (len(self.message.splitlines()) + 1))
   if textH < self.pageHeight and self.VVFTHJ < self.pageHeight:
    textH = max(textH, self.VVFTHJ)
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
