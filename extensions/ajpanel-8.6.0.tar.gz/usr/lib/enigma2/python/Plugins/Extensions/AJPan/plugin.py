import os
from io       import open as ioOpen
from json      import loads as jLoads, dumps as iDumps
from glob      import glob as iGlob
from re       import match as iMatch, escape as iEscape
from re       import sub as iSub, subn as iSubn, split as iSplit
from re       import search as iSearch, compile as iCompile
from re       import findall as iFindall, finditer as iFinditer
from re       import IGNORECASE
from math      import floor as iFloor, ceil as iCeil, log as iLog
from time      import localtime, mktime, strftime, time as iTime
from time      import sleep as iSleep
from threading     import Thread as iThread, enumerate as iEnumerate
from datetime     import datetime, timedelta
from collections    import Counter as iCounter
from base64      import b64encode, b64decode
from sys      import version_info as pyVersion
from skin      import parseColor
from Tools.Directories   import fileExists, pathExists, crawlDirectory
from Tools.Directories   import resolveFilename, SCOPE_PLUGINS, SCOPE_FONTS
from Tools.Directories   import SCOPE_CURRENT_SKIN
from Plugins.Plugin    import PluginDescriptor
from Screens.Screen    import Screen
from Screens.ChannelSelection import ChannelContextMenu
from Screens.ChannelSelection import service_types_tv, service_types_radio
from Screens.InfoBar   import InfoBar
from Tools.BoundFunction  import boundFunction as BF
from Tools.LoadPixmap   import LoadPixmap
from Components.PluginComponent import plugins as iPlugins
from Components.Harddisk  import harddiskmanager
from Components.Label   import Label
from Components.ScrollLabel  import ScrollLabel
from Components.Button   import Button
from Components.MenuList  import MenuList
from Components.ActionMap  import ActionMap
from Components.Pixmap   import Pixmap
from Components.MultiContent import MultiContentEntryText
from Components.NimManager  import nimmanager
from Components.Slider   import Slider
from enigma      import getDesktop, ePoint, eSize, gFont, eRect
from enigma      import eTimer, eDVBDB, addFont, fontRenderClass
from enigma      import iServiceInformation
from enigma      import eServiceReference, eServiceCenter
from enigma      import eListboxPythonMultiContent
from enigma      import RT_HALIGN_LEFT as LEFT
from enigma      import RT_HALIGN_CENTER as CENTER
from enigma      import RT_VALIGN_CENTER
from Components.ConfigList  import ConfigListScreen
from Components.config   import config, ConfigSubsection, configfile
from Components.config   import getConfigListEntry, ConfigDirectory
from Components.config   import ConfigYesNo, ConfigElement, ConfigText
from Components.config   import ConfigSelection, ConfigSelectionNumber
from Components.config   import ConfigSubList, ConfigInteger
try:  import tarfile as iTar
except: iTar = None
try:  import zipfile as iZip
except: iZip = None
try: from xml.etree import ElementTree as iElem
except: iElem = None
try: from shutil import move as iMove, copyfile as iCopyfile, copymode as iCopymode
except: iMove = iCopyfile = iCopymode = None
try:
 from urllib2 import Request as iRequest, urlopen as iUrlopen, URLError as iURLError, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
 from urllib  import unquote as iUnquote, quote as iQuote
 from urlparse import urlparse as iUrlparse, parse_qs as iUrlparse_qs
except:
 try:
  from urllib.request import Request as iRequest, urlopen as iUrlopen, build_opener, install_opener, HTTPPasswordMgrWithDefaultRealm, HTTPDigestAuthHandler, HTTPHandler
  from urllib.error import URLError as iURLError
  from urllib.parse import unquote as iUnquote, quote as iQuote, urlparse as iUrlparse, parse_qs as iUrlparse_qs
 except:
  iRequest = iUrlopen = iURLError = iUnquote = iQuote = iUrlparse = build_opener = install_opener = HTTPPasswordMgrWithDefaultRealm = HTTPDigestAuthHandler = HTTPHandler = None
PLUGIN_NAME    = "AJPanel"
PLUGIN_DESCRIPTION  = "Enigma2 Tools"
VVLBtR   = "v8.6.0"
VVoq2O    = "26-02-2023"
EASY_MODE    = 0
VVGLjm   = 0
VVrOXT   = 0
VVh8TB  = resolveFilename(SCOPE_PLUGINS, base="Extensions/")
VVZk2h  = resolveFilename(SCOPE_PLUGINS, base="SystemPlugins/")
VVNemM    = "/media/usb/"
VViBRH    = "/usr/share/enigma2/picon/"
VV4DWx = "/etc/enigma2/blacklist"
VVNwTu   = "/etc/enigma2/"
VV1aX3   = "AJPan"
VVqj4V  = "AUTO FIND"
VVT2YZ  = "Custom"
VVDCOh  = None
VVnuVz    = ""
VVW5nC = "Regular"
VV5RV1 = "Fixed"
VVn0Sb  = "AJP_Main"
VVGtks = "AJP_Terminal"
VV4JdF = "AJP_System"
VVR8AG  = VVW5nC
VVc5QS    = ""
VV5wTt   = " && echo 'Successful' || echo 'Failed!'"
VVzo6v  = "Cannot continue (No Enough Memory) !"
VV6Q1c  = ["#119f1313","#11005500","#11a08000","#1118188b"]
VVhRht  = "utf8"
VVoqHH    = ("-" * 100, )
SEP      = "-" * 80
VVoWDM  = False
VV8Ixy  = False
VVF5EY     = 0
VVTnM0    = 1
VVFX81    = 2
VVwFfF   = 3
VVRoYj    = 4
VVsieY    = 5
VVAtoE = 6
VVq2lk = 7
VVe3Gb  = 8
VVQI2Y   = 9
VVGUPT  = 10
VVa8YL  = 11
VVGa0l = 12
VVC6jd = 13
VV3Lt2 = 14
VV8OK0  = 15
VVmZLR    = 16
VVQNPR   = 17
VVASkO   = 18
VVdCmB    = 19
VVAjlU    = 20
VV2Zdx  = 21
VVkWtE    = 22
VVP6Rb   = 0
VVBTEe   = 1
VV0QS5   = 2
def FFfSz6():
 lst = []
 try:
  from enigma import getFontFaces
  lst = sorted(set(getFontFaces()))
 except:
  try:
   from skin import getFontFaces
   lst = sorted(set(getFontFaces()))
  except:
   pass
 if lst:
  global VVR8AG
  if VVn0Sb in lst and CFG.fontPathMain.getValue(): VVR8AG = VVn0Sb
  else               : VVR8AG = VVW5nC
  return lst
 else:
  return [VVW5nC]
def FFJ9zu(path, alias, scale=100, isRepl=0):
 try:
  addFont(path, alias, scale, isRepl)
  return True
 except:
  try:
   addFont(path, alias, scale, isRepl, 0)
   return True
  except:
   pass
 return False
config.plugins.AJPanel = ConfigSubsection()
CFG = config.plugins.AJPanel
CFG.showInMainMenu    = ConfigYesNo(default=False)
CFG.showInExtensionMenu   = ConfigYesNo(default=True)
CFG.showInChannelListMenu  = ConfigYesNo(default=True)
CFG.EventsInfoMenu    = ConfigYesNo(default=True)
CFG.keyboard     = ConfigSelection(default="v", choices=[("v", "Virtual Keyboard"),("s", "System Default")])
CFG.FileManagerExit    = ConfigSelection(default="d", choices=[("d", "Directory Up"),("e", "Exit")])
CFG.hotkey_signal    = ConfigSelection(default="lesc", choices=[("off", "Disable"),("lok", "Long-OK"),("lesc", "Long-Exit"),("lred", "Long-Red")])
CFG.subtDefaultEnc    = ConfigDirectory(default=VVhRht)
CFG.screenshotFType    = ConfigSelection(default="jpg", choices=[("off", "Disable"),("jpg", "JPG"),("png", "PNG"),("bmp", "BMP")])
CFG.iptvAddToBouquetRefType  = ConfigSelection(default="4097", choices=[("1", "1 (DVB Stream)"),("4097", "4097 (servicemp3)"),("5001", "5001 (GST Player)"),("5002", "5002 (Ext-3 EPlayer)"),("8192", "8192 (HDMI input)"),("8193", "8193 (eServiceUri)")])
CFG.autoResetFrozenIptvChan  = ConfigYesNo(default=True)
CFG.hideIptvServerAdultWords = ConfigYesNo(default=False)
CFG.hideIptvServerChannPrefix = ConfigYesNo(default=False)
CFG.iptvHostsMode    = ConfigDirectory(default=VVqj4V, visible_width=45)
CFG.MovieDownloadPath   = ConfigDirectory(default="/media/hdd/movie/", visible_width=45)
CFG.portalConnTimeout   = ConfigSelection(default=2, choices=[(x, str(x)) for x in range(1, 6, 1)])
CFG.PIconsPath     = ConfigDirectory(default=VViBRH, visible_width=45)
CFG.backupPath     = ConfigDirectory(default=VVNemM, visible_width=45)
CFG.packageOutputPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.downloadedPackagesPath  = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedTablesPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.exportedPIconsPath   = ConfigDirectory(default="/tmp/", visible_width=45)
CFG.iptvHostsDirs    = ConfigText(default="")
CFG.favServerPlaylist   = ConfigText(default="")
CFG.favServerPortal    = ConfigText(default="")
CFG.browserStartPath   = ConfigText(default="/")
CFG.browserBookmarks    = ConfigText(default="/tmp/,/")
CFG.browserSortMode    = ConfigInteger(default=0, limits=(0, 5))
CFG.browserSortMix    = ConfigYesNo(default=False)
CFG.signalPos     = ConfigInteger(default=5, limits=(1, 9))
CFG.playerPos     = ConfigInteger(default=0, limits=(0, 1))
CFG.signalSize     = ConfigInteger(default=3, limits=(1, 13))
CFG.mixedColorScheme   = ConfigInteger(default=4, limits=(0, 4))
CFG.checkForUpdateAtStartup  = ConfigYesNo(default=False)
CFG.playerJumpMin    = ConfigInteger(default=5, limits=(1, 10))
CFG.downloadAutoResume   = ConfigYesNo(default=True)
CFG.downloadMonitor    = ConfigYesNo(default=False)
CFG.lastTerminalCustCmdLineNum = ConfigInteger(default=0)
CFG.lastSharePickerDvbRow  = ConfigInteger(default=0)
CFG.lastSharePickerIptvRow  = ConfigInteger(default=0)
CFG.lastFileManFindPatt   = ConfigText(default="")
CFG.lastFileManFindSrt   = ConfigText(default="/media/")
CFG.lastPkgProjDir    = ConfigText(default="/media/")
CFG.lastFindTerminal   = ConfigText(default="")
CFG.lastFindServers    = ConfigText(default="")
CFG.lastFindIptv    = ConfigText(default="")
CFG.lastFindMovie    = ConfigText(default="")
CFG.lastFindSubtitle   = ConfigText(default="")
CFG.lastFindPackages   = ConfigText(default="")
CFG.lastFindServices   = ConfigText(default="")
CFG.lastFindSatName    = ConfigText(default="")
CFG.lastFindContextFind   = ConfigText(default="")
CFG.lastFindEditor    = ConfigText(default="")
CFG.lastFindGeneral    = ConfigText(default="")
CFG.fontPathMain    = ConfigText(default="")
CFG.fontPathTerm    = ConfigText(default="")
CFG.fontPathSys     = ConfigText(default="")
CFG.transpColorPicons   = ConfigText(default="#11404040")
CFG.transpColorPosters   = ConfigText(default="#11404040")
CFG.transpColorMovies   = ConfigText(default="#11404040")
CFG.transpColorChannels   = ConfigText(default="#88004040")
CFG.epgLangTitle    = ConfigText(default="")
CFG.epgLangDescr    = ConfigText(default="")
CFG.lastFtpLocalPath   = ConfigText(default="")
CFG.lastNetworkDevice   = ConfigInteger(default=0)
CFG.terminalCmdFile    = ConfigText(default="LinuxCommands.lst")
tmp = [("srt","FROM SRT FILE"),("#00FFFF","Aqua"),("#000000","Black"),("#0000FF","Blue"),("#FF00FF","Fuchsia"),("#808080","Gray"),("#008000","Green"),("#00FF00","Lime"),("#800000","Maroon"),("#000080","Navy"),("#808000","Olive"),("#800080","Purple"),("#FF0000","Red"),("#C0C0C0","Silver"),("#008080","Teal"),("#FFFFFF","White"),("#FFFF00","Yellow")]
CFG.subtDelaySec    = ConfigSelectionNumber(default=0, stepwidth=1, min=-600, max=600, wraparound=False)
CFG.subtBGTransp    = ConfigSelectionNumber(default=100, stepwidth=10, min=0, max=100, wraparound=False)
CFG.subtTextFg     = ConfigSelection(default="#FFFFFF", choices=tmp)
CFG.subtTextFont    = ConfigSelection(default=VVR8AG, choices=[(x,  x) for x in FFfSz6()])
CFG.subtTextSize    = ConfigSelectionNumber(default=50, stepwidth=5, min=30, max=100, wraparound=False)
CFG.subtTextAlign    = ConfigSelection(default="1", choices=[("0", "Left"),("1", "Center"),("2", "Right")])
CFG.subtShadowColor    = ConfigSelection(default="#000080", choices=tmp[1:])
CFG.subtShadowSize    = ConfigSelectionNumber(default=5, stepwidth=1, min=0, max=10, wraparound=False)
CFG.subtVerticalPos    = ConfigSelectionNumber(default=90, stepwidth=1, min=0, max=100, wraparound=False)
del tmp
def FFs8uQ():
 mode = CFG.mixedColorScheme.getValue()
 if mode == 4:
  VVKJET  = 0 == os.system("if which systemctl > /dev/null 2>&1; then exit 0; else exit 1; fi")
  VV1tlF = 0 == os.system("if grep -q 'open.*vision' /etc/issue; then exit 0; else exit 1; fi")
  if  VVKJET  : return 0
  elif VV1tlF : return 1
  else    : return 3
 else:
  return max(min(3, mode), 0)
VV5yC1 = FFs8uQ()
VV7jS2 = VVGb6D = VVGe5h = VVLbyB = VVsObI = VVMrXw = VVO6N6 = VVD5sL = VVVjNM = VVkIQ9 = VVVCGb = VVUVAI = VVkqaK = VVWOjU = VV21C5 = VVqFea = ""
def FFm4zT()  : FFK2wa(FFHHTV())
def FF27Jk()  : FFK2wa(FFQr0j())
def FFR3KV(tDict): FFK2wa(iDumps(tDict, indent=4, sort_keys=True))
def FFvfkK(*args): FFxXtF(True, True, *args)
def FFK2wa(*args) : FFxXtF(True , False , *args)
def FF5A0J(*args): FFxXtF(False, False, *args)
def FFxXtF(addSep=True, isArray=True, *args):
 if VVGLjm:
  sep = (">>>> %s\n" % ("#" * 80)) if addSep else ""
  txt = sep
  if isArray:
   for item in args:
    if isinstance(item, list) or isinstance(item, tuple):
     txt += ">>>> LIST START <--\n"
     for itm in item: txt += ".... %s\n" % str(itm)
     txt += ">>>> LIST END <--\n"
    elif isinstance(item, dict):
     txt += ">>>> LIST START <--\n"
     Len = 0
     for key, val in item.items(): Len = max(Len, len(str(key)))
     for key, val in item.items(): txt += ".... %s: %s\n" % (str(str(key).ljust(Len)), str(val))
     txt += ">>>> LIST END <--\n"
    else:
     txt += "---> %s\n" % str(item)
  else:
   cr = "\n" if addSep else ""
   txt += ">>>> %s%s" % (" , ".join(list(map(str, args))), cr)
  txt += sep.replace("#", "-")
  os.system("cat << '_EOF' \n" + str(txt) + "\n_EOF")
def FFl1cg(fnc):
 def VV1xsX(*args, **kwargs):
  t1 = iTime()
  fnc(*args, **kwargs)
  FFK2wa(">>>>>> Elapsed : %s sec\nargs = %s\nkwargs = %s" % (("%.6f" % (iTime() - t1)).rstrip("0"), args, kwargs))
 return VV1xsX
def FFPZYI(*args):
 if VVGLjm:
  path = "/tmp/ajp_log.txt"
  with open(path, "a") as f:
   f.write(">>>> %s\n" % (" , ".join(list(map(str, args)))))
  FF5A0J("Added to : %s" % path)
def FFIDyf(txt, isAppend=True, ignoreErr=False):
 if VVGLjm:
  tm = FFky63()
  err = ""
  if not ignoreErr:
   err = FFQr0j()
  fileName = "/tmp/ajp_log.txt"
  with open(fileName, "a" if isAppend else "w") as f:
   if err:
    f.write(err)
   f.write("%s >> %s\n" % (tm, str(txt)))
  if err:
   FFK2wa(err)
  FFK2wa("Output Log File : %s" % fileName)
def FFQr0j():
 try:
  from traceback import format_exc, format_stack
  trace = format_exc()
  if trace and len(trace) > 5:
   tm = FFky63()
   stack = format_stack()[:-1]
   sep = "*" * 70
   err = "\n%s\n*** %s\n%s\n\n" % (sep, tm, sep)
   err += "%s\n\n%s\n%s\n" % ("".join(stack), trace, sep)
   return err
 except:
  return "Cannot Trace !"
def FFHHTV():
 import inspect
 lst = []
 for ndx, f in enumerate(inspect.stack()):
  if ndx > 0:
   lst.append("%s >> %s" % (os.path.basename(f[1]), f[3]))
 return "Last Fncs:\n" + "\n".join(lst)
VVcugN = 0
def FFltMF():
 global VVcugN
 VVcugN = iTime()
def FFt8cE(txt=""):
 FFK2wa(">>>>>> Elapsed : %s sec\t%s" % (("%.6f" % (iTime() - VVcugN)).rstrip("0"), txt))
VV9dIY = []
def FFF9tS(win):
 global VV9dIY
 if not win in VV9dIY:
  VV9dIY.append(win)
def FFJgMq(*args):
 global VV9dIY
 for win in VV9dIY:
  try:
   win.close()
  except:
   pass
 VV9dIY = []
def FFFwMt():
 BT_SCALE = BT_KEEP_ASPECT_RATIO = None
 try:
  from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
 except:
  try  : from enigma import BT_SCALE, BT_FIXRATIO as BT_KEEP_ASPECT_RATIO
  except : pass
 if BT_SCALE and BT_KEEP_ASPECT_RATIO: return BT_SCALE | BT_KEEP_ASPECT_RATIO
 else        : return None
VVnvLp = FFFwMt()
def getDescriptor(fnc, where, name=PLUGIN_NAME, descr="", needsRestart=False):
 w = getDesktop(0).size().width()
 if w and w < 1920 : icon="icon.png"
 else    : icon="iconhd.png"
 if not descr: descr = PLUGIN_DESCRIPTION
 else  : descr = "%s %s" % (PLUGIN_NAME, descr)
 return PluginDescriptor(fnc=fnc, where=where, needsRestart=needsRestart, name=name, description=descr, icon=icon)
def FFPrQV()    : return PluginDescriptor(fnc=FFOTM0, where=[PluginDescriptor.WHERE_SESSIONSTART], needsRestart=True   , description="AJPanel Startup")
def FFoihR()      : return getDescriptor(FFqymg , [ PluginDescriptor.WHERE_MENU    ] , PLUGIN_NAME     , descr="Main Menu")
def FFnarm()     : return getDescriptor(FFx5as  , [ PluginDescriptor.WHERE_PLUGINMENU  ] , needsRestart=True)
def FFWIzX()  : return getDescriptor(FFpS9o, [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ File Manager"   , descr="File Maneger")
def FFtY2M() : return getDescriptor(FFttq2 , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ IPTV Menu"   , descr="IPTV Menu")
def FFK8Uh()  : return getDescriptor(FFodGH , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Player Bar"   , descr="Player Bar")
def FFGlls()  : return getDescriptor(FFBrcN  , [ PluginDescriptor.WHERE_EXTENSIONSMENU ] , "AJ Signal Monitor"  , descr="Signal Monitor")
def FFdxq4()      : return getDescriptor(FFMX4I, [ PluginDescriptor.WHERE_EVENTINFO  ] , "AJ Service Information" , descr="Service Info")
def Plugins(**kwargs):
 result = [ FFnarm() , FFoihR() , FFPrQV() ]
 if CFG.showInExtensionMenu.getValue():
  result.append(FFWIzX())
  result.append(FFtY2M())
  result.append(FFK8Uh())
  result.append(FFGlls())
 if CFG.EventsInfoMenu.getValue():
  result.append(FFdxq4())
 return result
def FFOTM0(reason, **kwargs):
 if reason == 0:
  CC42f6.VVzEzC()
  if "session" in kwargs:
   session = kwargs["session"]
   FFj3Qr(session)
   CCAPNc(session)
def FFqymg(menuid, **kwargs):
 if menuid == "mainmenu" and CFG.showInMainMenu.getValue():
  return [(PLUGIN_NAME, FFx5as, PLUGIN_NAME, 45)]
 else:
  return []
def FFx5as(session, **kwargs):
 session.open(Main_Menu)
def FFpS9o(session, **kwargs):
 session.open(CCCXvS)
def FFttq2(session, **kwargs):
 session.open(CC9X9s)
def FFodGH(session, **kwargs):
 CCb9j4.VV6JFp(session)
def FFBrcN(session, **kwargs):
 FFdawr(session, reopen=True)
def FFMX4I(session, **kwargs):
 session.open(CCjQ0P, fncMode=CCjQ0P.VV2TAI)
def FFxCEh():
 FFHVv5(CFG.showInExtensionMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EXTENSIONSMENU), [ FFWIzX(), FFtY2M(), FFK8Uh(), FFGlls() ])
 FFHVv5(CFG.EventsInfoMenu.getValue(), iPlugins.getPlugins(PluginDescriptor.WHERE_EVENTINFO), [ FFdxq4() ])
def FFHVv5(setVal, pluginList, dList):
 try:
  if setVal:
   for item in dList:
    if not item in pluginList:
     iPlugins.addPlugin(item)
  else:
   for item in dList:
    if item in pluginList:
     iPlugins.removePlugin(item)
 except:
  pass
def FFj3Qr(session):
 hk = ActionMap(["KeyMap_HK"])
 hk.execBegin()
 hk.actions["longOK"] = BF(FFtdvi, session, "lok")
 hk.actions["longCancel"]= BF(FFtdvi, session, "lesc")
 hk.actions["longRed"] = BF(FFtdvi, session, "lred")
 for k in (CCMSfE.VV8aau, CCMSfE.VVYAcp, CCMSfE.VVrLQt):
  hk.actions[k] = BF(CCMSfE.VVXBwK, session, k)
def FFtdvi(session, key):
 if CFG.hotkey_signal.getValue() == key:
  try:
   if CCn3nB.VViaTx:
    CCn3nB.VViaTx.close()
   if not CCb9j4.VVavYK:
    CCb9j4.VV6JFp(session)
  except:
   pass
def FFdEZ4(confItem, val):
 confItem.setValue(val)
 confItem.save()
 configfile.save()
def FFmmH7(SELF, title="", addLabel=False, addScrollLabel=False, VVZJ87=None, addCloser=False):
 Screen.__init__(SELF, SELF.session)
 if title == "" : title = FFwrBW()
 else   : title = "  %s  " % title
 SELF["myTitle"] = Label(title)
 SELF["myBody"] = Label()
 SELF["myInfoFrame"] = Label()
 SELF["myInfoBody"] = Label()
 SELF.VVHYJv = eTimer()
 try: SELF.VVq7Ig = SELF.VVHYJv.timeout.connect(BF(FF0P1X, SELF))
 except: SELF.VVHYJv.callback.append(BF(FF0P1X, SELF))
 SELF.onClose.append(SELF.VVHYJv.stop)
 FF0P1X(SELF)
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): SELF["keyMenu"] = Pixmap()
 if btnMode in (2, 3): SELF["keyInfo"] = Pixmap()
 if SELF.skinParam["barHeight"] > 0:
  SELF["myBar"]  = Label()
  SELF["myLine"]  = Label()
  SELF["keyRed"]  = Label()
  SELF["keyGreen"] = Label()
  SELF["keyYellow"] = Label()
  SELF["keyBlue"]  = Label()
  SELF["keyRed"].hide()
  SELF["keyGreen"].hide()
  SELF["keyYellow"].hide()
  SELF["keyBlue"].hide()
 if addLabel:
  SELF["myLabel"] = Label()
 if addScrollLabel:
  SELF["myLabel"] = CCUveG(SELF)
 if VVZJ87:
  SELF["myMenu"] = MenuList(VVZJ87)
  SELF["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.VVxCTS ,
   "cancel": SELF.close ,
  }, -1)
 if addCloser:
  SELF["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : SELF.close,
   "cancel": SELF.close,
   "red" : SELF.close
  }, -1)
def FF5k1E(SELF, tableObj, colNum=0, isMenu=False):
 SELF.keyPressed = -1
 SELF["myActionMap"].actions.update({
  "0" : BF(FFW9vc, SELF, "0"),
  "1" : BF(FFW9vc, SELF, "1"),
  "2" : BF(FFW9vc, SELF, "2"),
  "3" : BF(FFW9vc, SELF, "3"),
  "4" : BF(FFW9vc, SELF, "4"),
  "5" : BF(FFW9vc, SELF, "5"),
  "6" : BF(FFW9vc, SELF, "6"),
  "7" : BF(FFW9vc, SELF, "7"),
  "8" : BF(FFW9vc, SELF, "8"),
  "9" : BF(FFW9vc, SELF, "9")
 })
 from Tools.NumericalTextInput import NumericalTextInput
 SELF.numericalTextInput = NumericalTextInput(nextFunc=BF(FF3rla, SELF, tableObj, colNum, isMenu))
 SELF.numericalTextInput.setUseableChars('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
def FFW9vc(SELF, key):
 SELF.keyPressed = SELF.numericalTextInput.getKey(int(key))
 for group in [ "1", "2ABC", "3DEF", "4GHI", "5JKL", "6MNO", "7PQRS", "8TUV", "9WXYZ", "0" ]:
  if SELF.keyPressed in group:
   if VVqFea:
    txt = " ".join(group)
    txt = txt.replace(SELF.keyPressed, VVqFea + SELF.keyPressed + VVGb6D)
    txt = VVGb6D + txt
   else:
    sep = "    "
    txt = sep + sep.join(group) + sep
    txt = txt.replace(sep + SELF.keyPressed + sep, "   [%s]   " % SELF.keyPressed)
   FF5uKN(SELF, txt)
def FF3rla(SELF, tableObj, colNum, isMenu):
 FF5uKN(SELF)
 try:
  if tableObj and tableObj.list is not None:
   for i in range(len(tableObj.list)):
    if isMenu: item = tableObj.list[i][colNum].strip()
    else  : item = tableObj.list[i][colNum + 1][7].strip()
    item = FFxmTk(item).encode().decode()
    firstChar = item.upper()[:1]
    if firstChar == SELF.keyPressed:
     if isMenu: SELF.VV6zBC(i)
     else  : SELF.VVYNxS(i)
     break
 except:
  pass
def FFwrBW():
 return ("  %s" % VVc5QS)
def FFR9Qm(btn, txt):
 btn.setText(txt)
 if txt : btn.show()
 else : btn.hide()
def FFxmTk(txt):
 if "\c" in txt:
  txt = iSub(r"\\c(.){8}" ,"" , txt, flags=IGNORECASE)
 return txt
def FFkR1T(color):
 return parseColor(color).argb()
def FFHNWi(obj, color):
 obj.instance.setForegroundColor(parseColor(color))
 obj.instance.invalidate()
def FFWN9Z(obj, color):
 obj.instance.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFKdGK(obj, color):
 obj.long_text.setBackgroundColor(parseColor(color))
 obj.instance.invalidate()
def FFXRSi(txt, color):
 if color:
  if "/" in txt: txt = txt.replace("/", "\/")
  return " | sed 's/%s/\\%s&\%s/gI'" % (txt, color, VVqFea)
 else:
  return ""
def FFfCOf(word, color):
 if color: return "echo -e '\%s%s\n--- %s\n%s\%s';" % (color, SEP, word, SEP, VVqFea)
 else : return "echo -e '%s\n--- %s\n%s';" % (SEP, word, SEP)
def FFGB9z(word, color, backToColor=None):
 if backToColor : return color + word + backToColor
 else   : return color + word + VVqFea
def FFgg7s(color):
 if color: return "echo -e '%s' %s;" % (SEP, FFXRSi(SEP, VVVCGb))
 else : return "echo -e '%s';" % SEP
def FFfR82(title, color):
 title = "%s\n%s\n%s\n" % (SEP, title, SEP)
 return FFGB9z(title, color)
def FFplRG(menuObj, fg="#00ffffff", bg="#08005555"):
 menuObj.instance.setForegroundColorSelected(parseColor(fg))
 menuObj.instance.setBackgroundColorSelected(parseColor(bg))
def FFQQYI(menuObj):
 try:
  menuObj.instance.setHAlign(1)
 except:
  pass
def FFFANg(fncCB):
 tCons = CC1WBa()
 tCons.ePopen("echo", BF(FFScmH, fncCB))
def FFScmH(fncCB, result, retval):
 fncCB()
def FFJsIX(SELF, fnc, title="Processing ...", clearMsg=True):
 FF5uKN(SELF, title)
 tCons = CC1WBa()
 tCons.ePopen("echo", BF(FFEeYV, SELF, fnc, clearMsg))
def FFEeYV(SELF, fnc, clearMsg, result, retval):
 fnc()
 if clearMsg:
  FF5uKN(SELF)
def FF5IiQ(cmd):
 from subprocess import Popen, PIPE
 try:
  process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True, shell=True)
  stdout, stderr = process.communicate()
  stdout = stdout.strip()
  stderr = stderr.strip()
  if stderr : return stderr
  else  : return stdout
 except Exception as e:
  if "memory" in str(e).lower(): return VVzo6v
  else       : return ""
def FFnAC3(cmd):
 txt = FF5IiQ(cmd)
 txt = txt.splitlines()
 return list(map(str.strip, txt))
def FF3RLi(cmd):
 lines = FFnAC3(cmd)
 if lines: return lines[0]
 else : return ""
def FFRULi(SELF, cmd):
 lines = FFnAC3(cmd)
 VVX3wb = []
 for line in lines:
  line = line.strip()
  if ":" in line:
   parts = line.split(":")
   key  = parts[0].strip()
   val  = parts[1].strip()
   VVX3wb.append((key, val))
  elif line:
   VVX3wb.append((line, ""))
 if VVX3wb:
  header   = ("Parameter" , "Value" )
  widths   = (50    , 50  )
  FF1Dpj(SELF, None, header=header, VVarfR=VVX3wb, VVhAo0=widths, VVTFXq=28)
 else:
  FF6Z0v(SELF, cmd)
def FFuB0V(cmd):
 return os.system(FFIV1X(cmd)) == 0
def FF6Z0v(    SELF, cmd, **kwargs): SELF.session.open(CCUEpT, VVA1ht=cmd, VVMP7V=True, VV4VK0=VVBTEe, **kwargs)
def FFvYk0(  SELF, cmd, **kwargs): SELF.session.open(CCUEpT, VVA1ht=cmd, **kwargs)
def FFleea(   SELF, cmd, **kwargs): SELF.session.open(CCUEpT, VVA1ht=cmd, VVw8D9=True, VVpphv=True, VV4VK0=VVBTEe, **kwargs)
def FF3aHD(  SELF, cmd, **kwargs): SELF.session.open(CCUEpT, VVA1ht=cmd, VVw8D9=True, VVpphv=True, VV4VK0=VV0QS5, **kwargs)
def FF1Q61(  SELF, cmd, **kwargs): SELF.session.open(CCUEpT, VVA1ht=cmd, VV0qCB=True , **kwargs)
def FFYLpx(  session, cmd, **kwargs):      session.open(CCUEpT, VVA1ht=cmd, VV0qCB=True , **kwargs)
def FFhbKO( SELF, cmd, **kwargs): SELF.session.open(CCUEpT, VVA1ht=cmd, VVWnWi=True   , **kwargs)
def FFG0r2( SELF, cmd, **kwargs): SELF.session.open(CCUEpT, VVA1ht=cmd, VVk2KC=True  , **kwargs)
def FFIV1X(cmd):
 return cmd + " > /dev/null 2>&1"
def FF627U(cmd):
 return cmd + " 2> /dev/null"
def FFZSD6():
 return " > /dev/null 2>&1"
def FFhcfU(cmd):
 return FFuB0V("which %s" % cmd)
def FFX0mI():
 cmd = "if [ -f /etc/apt/apt.conf ]; then echo dpkg; else if [ -f /etc/opkg/opkg.conf ]; then echo opkg; else if which dpkg; then echo dpkg; else if which opkg; then echo opkg; else if which ipkg; then echo ipkg; else echo ''; fi; fi; fi; fi; fi"
 return FF3RLi(cmd)
def FFEZzf(mode=0):
 if mode == 0:
  dirs = [ "*boot*", "*/ba", "/proc" ]
 else:
  dirs = [  "*boot*"
    , "*picon*"
    , "*/ba"
    , "/bin"
    , "/dev"
    , "/hdd"
    , "/lib"
    , "/linuxrc"
    , "/mnt"
    , "/newroot"
    , "/proc"
    , "/run"
    , "/sbin"
    , "/sys"
    , "/usr"
    ]
 paths = []
 for item in dirs:
  paths.append("-ipath '%s'" % item)
 txt = " -o ".join(paths)
 return "-type d \( %s \) -prune -o " % txt
VVxYBL     = 0
VVBCs3      = 1
VVcrnB   = 2
VVm6ci   = 3
VVqsbt      = 4
VVWyGQ      = 5
VVElJX     = 6
VVMnUw     = 7
VV33Lu     = 8
VVDaFy = 9
VV57oW = 10
VVygvf = 11
VVfGaS  = 12
VVi1yR     = 13
VVbez3  = 14
VV0vnU  = 15
def FF8jae(parmNum, grepTxt):
 if   parmNum == VVxYBL  : param = ["update"   , "dpkg update"    ]
 elif parmNum == VVBCs3   : param = ["list"   , "apt list"    ]
 elif parmNum == VVcrnB: param = ["list-installed" , "dpkg -l"     ]
 elif parmNum == VVm6ci: param = ["list-upgradable", "apt list --upgradable"]
 else         : param = []
 if param:
  pkg = FFX0mI()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], grepTxt)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], grepTxt)
 return ""
def FFETOG(parmNum, package):
 if   parmNum == VVqsbt      : param = ["info"      , "apt show"         ]
 elif parmNum == VVWyGQ      : param = ["files"      , "dpkg -L"          ]
 elif parmNum == VVElJX     : param = ["search"      , "dpkg -S"          ]
 elif parmNum == VVMnUw     : param = ["download"     , "apt-get download"       ]
 elif parmNum == VV33Lu     : param = ["install"     , "apt-get install -y"       ]
 elif parmNum == VVDaFy : param = ["install --force-reinstall" , "apt-get install --reinstall -y"    ]
 elif parmNum == VV57oW : param = ["install --force-overwrite" , "dpkg -i --force-all"       ]
 elif parmNum == VVygvf : param = ["install --force-downgrade" , "apt-get install --allow-downgrades -y"  ]
 elif parmNum == VVfGaS  : param = ["install --force-depends" , "apt-get install --no-install-recommends -y" ]
 elif parmNum == VVi1yR     : param = ["remove"      , "apt-get purge --auto-remove -y"    ]
 elif parmNum == VVbez3  : param = ["remove --force-remove"  , "dpkg --purge --force-all"     ]
 elif parmNum == VV0vnU  : param = ["remove --force-depends"  , "dpkg --remove --force-depends"    ]
 else            : param = []
 if param:
  if package:
   package = "'%s'" % package
  pkg = FFX0mI()
  if   pkg in ("ipkg", "opkg"): return "%s %s %s" % (pkg, param[0], package)
  elif pkg == "dpkg"   : return "%s %s" % (param[1], package)
 return ""
def FFcMGy():
 result = FF3RLi("ar -V 2> /dev/null | grep 'GNU ar'")
 if result.startswith("GNU ar"):
  cmd = " allOK='1';"
 else:
  notFoundCmd = " echo -e 'GNU \"ar\" command not found!';"
  installCmd = FFETOG(VV33Lu, "")
  if installCmd:
   verCmd = "FOUND=$(ar -V 2> /dev/null | grep 'GNU ar');"
   failed1 = "Please update your software or manually install \"ar\" command and try again."
   failed2 = "(\"ar\" is available in the packages : \"opkg-tools\" or \"binutils\")"
   failed3 = "Process Failed."
   cmd  = " allOK='0';"
   cmd += verCmd
   cmd += 'if [[ -z "$FOUND" ]]; then '
   cmd +=   notFoundCmd
   cmd += "  echo -e 'Trying to install \"opkg-Tools\" ...';"
   cmd +=    FFIV1X("%s enigma2-plugin-extensions-opkg-tools" % installCmd) + ";"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += " echo -e 'Trying to install \"binutils\" ...';"
   cmd +=   FFIV1X("%s binutils" % installCmd) + ";"
   cmd += " fi;"
   cmd +=   verCmd
   cmd += ' if [[ -z "$FOUND" ]]; then '
   cmd += "  echo -e 'Installation failed !';"
   cmd += "  echo -e '%s' %s;"  % (failed1, FFXRSi(failed1, VVVCGb))
   cmd += "  echo -e '%s' %s;"  % (failed2, FFXRSi(failed2, VVVCGb))
   cmd += "  echo -e '\n%s' %s;" % (failed3, FFXRSi(failed3, VVGe5h))
   cmd += " else"
   cmd += "  echo -e 'Installed successfully.';"
   cmd += "  allOK='1';"
   cmd += " fi;"
   cmd += "else"
   cmd += "  allOK='1';"
   cmd += "fi;"
  else:
   cmd = " allOK='0';"
   cmd += notFoundCmd
 return cmd
def FF09Tg(commandTool, toolPkgName, displayedName):
 cmd1 = ""
 installCmd = FFETOG(VV33Lu , "")
 if installCmd:
  failed1 = "Please update your software and try again."
  failed2 = "Process Failed."
  cmd1 += " echo -e '%s not found.';" % displayedName
  cmd1 += " echo -e 'Trying to install ...';"
  cmd1 +=   FFIV1X("%s %s" % (installCmd, toolPkgName)) + ";"
  cmd1 += " FOUND=$(which  %s);"  % commandTool
  cmd1 += ' if [[ -z "$FOUND" ]]; then '
  cmd1 += "  echo -e 'Installation failed !';"
  cmd1 += "  echo -e '%s\n' %s;" % (failed1, FFXRSi(failed1, VVVCGb))
  cmd1 += "  echo -e '%s' %s;" % (failed2, FFXRSi(failed2, VVGe5h))
  cmd1 += " else"
  cmd1 += "  echo -e 'Installed successfully.';"
  cmd1 += "  allOK='1';"
  cmd1 += " fi;"
 else:
  cmd1 += " echo -e '%s not found.';" % displayedName
 cmd  = " allOK='0';"
 cmd += "FOUND=$(which %s);" % commandTool
 cmd += 'if [[ -z "$FOUND" ]]; then '
 cmd +=   cmd1
 cmd += "else"
 cmd += "  allOK='1';"
 cmd += "fi;"
 return cmd
def FFQ5la(path, maxSize=-1, encLst=None):
 if   encLst is None    : encLst = CCqdtK.VVLlKS()
 elif isinstance(encLst, str) : encLst = [encLst]
 txt = ""
 for enc in encLst:
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    txt = f.read(maxSize)
    txt = str(txt)
   break
  except:
   pass
 if txt.startswith(chr(239) + chr(187) + chr(191)):
  txt = txt[3:]
 return txt
def FFZQjt(path, keepends=False, maxSize=-1, encLst=None):
 txt = FFQ5la(path, maxSize, encLst=encLst)
 return txt.splitlines(keepends)
def FFF5Ye(SELF, path, encLst=None):
 title = os.path.basename(path)
 if fileExists(path):
  maxSize = 60000
  if (FFqLWj(path) > maxSize):
   title="File too big (showing first 60kB only)"
  else:
   maxSize = -1
  lines = FFQ5la(path, maxSize=maxSize, encLst=encLst)
  if lines: FF90Bc(SELF, lines, title=title, VV4VK0=VVBTEe, width=1600, height=1000, titleFontSize=30)
  else : FF5BXO(SELF, path, title=title)
 else:
  FFZoTn(SELF, path, title)
def FFqsYG(SELF, fName, title):
 path = VVrrZu + fName
 if fileExists(path):
  txt = FFQ5la(path)
  txt = txt.replace("#W#", VVqFea)
  txt = txt.replace("#Y#", VVUVAI)
  txt = txt.replace("#G#", VVGb6D)
  txt = txt.replace("#C#", VVkqaK)
  txt = txt.replace("#P#", VVsObI)
  FF90Bc(SELF, txt, title=title)
 else:
  FFZoTn(SELF, path, title)
def FF11rW(path):
 if pathExists(path):
  tList = os.listdir(path)
  if tList:
   dirs = []
   for item in tList:
    if os.path.isdir(path + item):
     dirs.append(item)
   if dirs:
    dirs.sort()
    return dirs
 return []
def FF0y7s(path, addTrailingSlash):
 parent = os.path.abspath(os.path.join(path, os.pardir))
 if addTrailingSlash : return FF1vNj(parent)
 else    : return FFAxSo(parent)
def FF65m2(path):
 return os.path.basename(os.path.normpath(path))
def FFjzhy(path):
 try:
  os.mkdir(path)
  return "" if pathExists(path) else "Cannot create dir !"
 except Exception as e:
  return str(e)
def FFqLWj(path):
 try:
  if os.path.islink(path)  : return os.lstat(path).st_size
  elif os.path.isfile(path): return os.path.getsize(path)
 except:
  pass
 return -1
def FFxuAp(path):
 path = FFAxSo(path)
 if   os.path.islink(path) : return "SymLink"
 elif os.path.ismount(path) : return "Mount"
 elif os.path.isfile(path) : return "File"
 elif os.path.isdir(path) : return "Directory"
 else      : return ""
def FFkSE4(path):
 size = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   try:
    if os.path.islink(fp) : size += os.lstat(fp).st_size
    elif os.path.isfile(fp) : size += os.path.getsize(fp)
   except:
    pass
 return size
def FF9Mxg(path):
 totDir = totFile = totLink = 0
 for Dir, dirs, files in os.walk(path):
  files = os.listdir(Dir)
  for f in files:
   fp = os.path.join(Dir, f)
   if os.path.islink(fp) : totLink += 1
   elif os.path.isfile(fp) : totFile += 1
   else     : totDir += 1
 return totDir, totFile, totLink
def FFzyFM(path):
 try: os.remove(path)
 except: pass
def FFA11O(path):
 with open(path, "rb+") as f:
  try:
   f.seek(-1, 2)
   if ord(f.read(1)) not in (10, 13):
    f.write(b"\n")
  except:
   pass
def FF1bsb(path):
 FFuB0V("chattr -AacDdijsStu '%s'; rm -fr '%s'" % (path, path))
def FFn7Bv(path):
 return FFuB0V("cp -f '%s' '%s.bak'" % (path, path))
def FF1vNj(path):
 if not path.endswith("/"):
  path += "/"
 return path
def FFAxSo(path):
 if not path == "/":
  path = path.rstrip("/")
 return path
def FFYRfF():
 sigFile = "ajpanel_res_marker"
 try:
  p = os.path.abspath(os.path.dirname(__file__))
  if p:
   mainP = os.path.join(p, "")
   resP = os.path.join(p, "res", "")
   if fileExists(os.path.join(resP, sigFile)):
    return mainP, resP
 except:
  pass
 paths = []
 paths.append(VVh8TB)
 paths.append(VVh8TB.replace("lib", "lib64"))
 ba = "/media/ba/ba/"
 list = FF11rW(ba)
 for p in list:
  p = ba + p + VVh8TB
  paths.append(p)
 for p in paths:
  p = os.path.join(p, VV1aX3, "")
  if fileExists(os.path.join(p, "res", sigFile)):
   mainP = os.path.join(p, "")
   resP = os.path.join(mainP, "res", "")
   return mainP, resP
 mainP = os.path.join(VVh8TB, VV1aX3 , "")
 resP = os.path.join(mainP, "res", "")
 return mainP, resP
VVOJt3, VVrrZu = FFYRfF()
def FFDEHe():
 def VVLzIw(item, defPath):
  path = item.getValue()
  if not pathExists(path):
   item.setValue(defPath)
   item.save()
   return path
  return ""
 t = "/tmp/"
 oldMovieDownloadPath = ""
 if not pathExists(CFG.MovieDownloadPath.getValue()):
  for p in ("/media/hdd/movie/", "/media/usb/movie/", t, "/"):
   if pathExists(p):
    CFG.MovieDownloadPath.setValue(p)
    CFG.MovieDownloadPath.save()
    oldMovieDownloadPath = p
    break
 VVzIjJ   = VVLzIw(CFG.backupPath, CCcHsQ.VVorgX())
 VVEb2k   = VVLzIw(CFG.downloadedPackagesPath, t)
 VVmRnO  = VVLzIw(CFG.exportedTablesPath, t)
 VVIJjG  = VVLzIw(CFG.exportedPIconsPath, t)
 VVGCAe   = VVLzIw(CFG.packageOutputPath, t)
 global VVNemM
 VVNemM = FF1vNj(CFG.backupPath.getValue())
 if VVzIjJ or VVGCAe or VVEb2k or VVmRnO or VVIJjG or oldMovieDownloadPath:
  configfile.save()
 return VVzIjJ, VVGCAe, VVEb2k, VVmRnO, VVIJjG, oldMovieDownloadPath
def FFGQYc(path):
 path = FFAxSo(path)
 target = ""
 try:
  if os.path.exists(path) and os.path.islink(path):
   target = os.readlink(path)
 except:
  pass
 return target
def FFeF3s(SELF, pathList, tarFileName, addTimeStamp=True):
 VVarfR = []
 t = ""
 for path in pathList:
  if os.path.isfile(path):
   if fileExists(path):
    VVarfR.append(path)
  elif os.path.isdir(path):
   if os.listdir(path):
    VVarfR.append(path)
  else:
   dirName  = os.path.dirname(path)
   fileName = os.path.basename(path)
   fileName = fileName.replace("*", ".*")
   if crawlDirectory(dirName, fileName):
    VVarfR.append(path)
 if not VVarfR:
  FFw5OO(SELF, "Files not found!")
 elif not pathExists(VVNemM):
  FFw5OO(SELF, "Path not found!\n\n%s" % VVNemM)
 else:
  VV31vM = FF1vNj(VVNemM)
  tarFileName = "%s%s" % (VV31vM, tarFileName)
  if addTimeStamp:
   tarFileName = "%s_%s" % (tarFileName, FFUD38())
  tarFileName += ".tar.gz"
  filesLine = ""
  for f in VVarfR:
   filesLine +=  "%s " % f
  sep  = "echo -e '%s';" % SEP
  failed = "Process failed !"
  cmd  =  sep
  cmd += "echo -e 'Collecting files ...\n';"
  cmd += "tar -czvf '%s' %s 2> /dev/null;" % (tarFileName, filesLine)
  cmd += "if [ -f '%s' ]; then "    % tarFileName
  cmd += " chmod 644 '%s';"     % tarFileName
  cmd += " echo -e '\nDONE\n';"
  cmd += " echo -e 'Result File:\n%s\n' %s;" % (tarFileName, FFXRSi(tarFileName, VVVjNM))
  cmd += "else"
  cmd += " echo -e '\n%s\n' %s;"    % (failed, FFXRSi(failed, VVVjNM))
  cmd += "fi;"
  cmd +=  sep
  FFvYk0(SELF, cmd)
def FFj9eW(SELF):
 btnMode = SELF.skinParam["topRightBtns"]
 if btnMode in (1, 2): FFDhpr(SELF["keyMenu"], "menu")
 if btnMode in (2, 3): FFDhpr(SELF["keyInfo"], "info")
def FFDhpr(barObj, fName):
 path = "%s%s%s" % (VVrrZu, fName, ".png")
 if fileExists(path):
  try:
   barObj.instance.setScale(1)
   barObj.instance.setPixmapFromFile(path)
   return True
  except:
   pass
 return False
def FFWHDS(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satName = ""
  try:
   satName = nimmanager.getSatName(satNum)
  except:
   pass
  if not satName or "N/A" in satName:
   satName = FFXHW8(satNum)
  return satName
def FFXHW8(satNum):
 satNum  = int(satNum)
 if   satNum == 0xeeee: return "DVB-T"
 elif satNum == 0xffff: return "DVB-C"
 else:
  satDir = "E"
  if satNum > 1800:
   satDir = "W"
   satNum = 3600 - satNum
  satNum /= 10.0
  return "%s%s" % (str(satNum), satDir)
def FFPqiq(refCode, isLong):
 sat = ""
 if refCode.count(":") > 8:
  nameSpace = refCode.split(":")[6]
  s   = nameSpace.zfill(8)[:4]
  val   = int(s, 16)
  if isLong : sat = FFWHDS(val)
  else  : sat = FFXHW8(val)
 return sat
def FF0JDR(sat):
 try:
  s = sat.upper()
  if s.endswith("E") or s.endswith("W"):
   num = float(sat[:-1]) * 10
   if s.endswith("W"):
    num = 3600 - num
   return FFWHDS(num)
 except:
  pass
 return sat
def FFnBDO(satNumStr):
 satDir = "E"
 satNum = int(satNumStr)
 if satNum < 0:
  satDir = "W"
 satNum /= 10.0
 return "%s%s" % (str(abs(satNum)), satDir)
def FFGh4f(SELF, isFromSession=False, addInfoObj=False):
 info = refCode = decodedUrl = origUrl = iptvRef = chName = prov = state = ""
 if not isFromSession: SELF = SELF.session
 service = SELF.nav.getCurrentService()
 if service:
  info = service.info()
  if info:
   chName = info.getName()
   refCode = FFSmtF(info, iServiceInformation.sServiceref)
   prov = FFSmtF(info, iServiceInformation.sProvider)
   state = str(FFSmtF(info, iServiceInformation.sDVBState))
   if not state  : state = ""
   elif  state == "0" : state = "No free tuner"
   elif  state == "1" : state = "Tune Failed"
   elif  state == "2" : state = "Timeout reading PAT"
   elif  state == "3" : state = "SID not found in PAT"
   elif  state == "4" : state = "Timeout reading PMT"
   elif  state == "10" : state = "Check tuner configuration"
   else    : state = "Tuned"
   if refCode.count(":") > 8:
    refCode = refCode.rstrip(":")
    if FF4Jai(refCode):
     chName = chName.rstrip(":")
     if refCode.endswith(("%3a", "%3A")): refCode = refCode[:-3]
     refCode, decodedUrl, origUrl, iptvRef = FFzRjC(refCode)
 if addInfoObj: return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info
 else   : return refCode, decodedUrl, origUrl, iptvRef, chName, prov, state
def FFSmtF(info, param):
 if info:
  v = info.getInfo(param)
  if v == -1: return ""
  if v == -2: return info.getInfoString(param)
  if v ==  1: return info.getInfoString(param)
  return str(v)
 else:
  return ""
def FFunPR(refCode, iptvRef, chName):
 if iptvRef : return iptvRef.replace(":" + chName, "")
 else  : return refCode
def FFyNG3(refCode):
 info = FF8PoC(refCode)
 return info and info.getName(eServiceReference(refCode)) or ""
def FFqAbm(refCode):
 try:
  ns = refCode.split(":")[6]
  ns = ns.zfill(8)[:4]
 except:
  ns = ""
 return ns.upper()
def FFy54D(path, fName):
 if os.path.isfile(path + fName):
  return fName
 else:
  if fName.count("_") > 8:
   parts = fName.split("_")
   parts[2] = "1"
   fName = "_".join(parts)
   if os.path.isfile(path + fName):
    return fName
 return ""
def FF8PoC(refCode):
 service = eServiceReference(refCode)
 info = None
 if service:
  VVkVSB = eServiceCenter.getInstance()
  if VVkVSB:
   info = VVkVSB.info(service)
 return info
def FFkwBg(SELF, refCode, VVIC8r=True, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if "j.php" in refCode and "&end=:" in refCode:
  refCode1, decodedUrl, origUrl, iptvRef = FFzRjC(refCode)
  chName = decodedUrl[decodedUrl.index("&end=:") + 6:]
  pr = CCdmJK()
  if pr.VVfc6w(refCode1, chName, decodedUrl, iptvRef):
   if pr.VVwvmQ(SELF, isFromSession):
    return
   else:
    fromPortalReplay = True
 if refCode.count(":") > 8:
  serviceRef = eServiceReference(str(refCode))
  FFeWbP(SELF, serviceRef, checkParentalControl, isFromSession, fromPortalReplay)
  if VVIC8r:
   FFNwm2(SELF, isFromSession)
 try:
  VVhMBa = InfoBar.instance
  if VVhMBa:
   VVsufg = VVhMBa.servicelist
   if VVsufg:
    servRef = eServiceReference(refCode)
    VVsufg.saveChannel(servRef)
 except:
  pass
def FFeWbP(SELF, serviceRef, checkParentalControl=False, isFromSession=False, fromPortalReplay=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 session.nav.playService(serviceRef, checkParentalControl=checkParentalControl)
 if not fromPortalReplay:
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(SELF, isFromSession=isFromSession)
  if decodedUrl:
   if "chCode=" in decodedUrl:
    pr = CCdmJK()
    if pr.VVfc6w(refCode, chName, decodedUrl, iptvRef):
     pr.VVwvmQ(SELF, isFromSession)
def FF4Jai(refCode):
 return True if iSearch(r"([A-Fa-f0-9]+[:]){10}.+\/\/.+", refCode, IGNORECASE) else False
def FFqWLZ(ref):
 if "chcm=" in ref.lower(): return False
 else      : return True if iSearch(r"https?([:]|%3a)\/\/(127.0.0.\d|0.0.0.0|192.168.\d.\d|localhost).+", ref, IGNORECASE) else False
def FFEjXT(url): return FF7cGO(url) or FFe0eK(url)
def FF7cGO(url) : return not "mode=itv" in url and any(x in url for x in ("/movie/", "/vod/", "/video/", ".m3u8", "mode=vod"))
def FFe0eK(url): return any(x in url for x in ("/series/", "mode=series"))
def FFzRjC(refCode):
 span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+\/\/.+)", refCode, IGNORECASE)
 if span:
  refCode = span.group(1).upper()
  origUrl = span.group(2)
  if refCode.endswith(("%3a", "%3A")):
   refCode = refCode[:-3]
  refCode = refCode.rstrip(":")
  decodedUrl = FFlOsc(origUrl)
  return refCode, decodedUrl, origUrl, refCode + ":" + origUrl
 else:
  return refCode, "", "", ""
def FFlOsc(url):
 if url and iUnquote : return iUnquote(url)
 else    : return url
def FFGN9H(url):
 if url and iQuote : return iQuote(url)
 else    : return url
def FFjhdq(txt):
 try:
  return str(b64encode(txt.encode("utf-8")).decode("utf-8"))
 except:
  return txt
def FFH6Pe(txt):
 try:
  return str(b64decode(txt).decode("utf-8"))
 except:
  return txt
def FFQXBr(txt):
 try:
  return FFjhdq(FFH6Pe(txt)) == txt
 except:
  return False
def FFzSvJ(path, patt):
 if "[" in path or "]" in path:
  newPath = ""
  for char in path:
   if   char == "[": char = "[[]"
   elif char == "]": char = "[]]"
   newPath += char
 else:
  newPath = path
 return iGlob("%s%s" % (FF1vNj(newPath), patt))
def FFNwm2(SELF, isFromSession=False):
 if isFromSession: session = SELF
 else   : session = SELF.session
 refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(SELF, isFromSession=isFromSession)
 isForPlayer = False
 serv = session.nav.getCurrentlyPlayingServiceReference()
 if serv:
  servPath = serv.getPath()
  if servPath and not "FROM BOUQUET " in servPath.upper():
   isForPlayer = True
 if iptvRef or isForPlayer: CCb9j4.VV6JFp(session)
 else      : FFdawr(session, reopen=True)
def FFdawr(session, reopen=False):
 if reopen:
  try:
   session.openWithCallback(BF(FFdawr, session), CCn3nB)
  except:
   try:
    FFOsAJ(session, "Cannot launch Signal Monitor !", title="Signal Monitor")
   except:
    pass
def FFxrtX(refCode):
 tp = CCyH2c()
 if tp.VVgElx(refCode) : return True
 else        : return False
def FFxl59(refCode, isHide, skipReload=False):
 if refCode.count(":") > 8:
  sRef = eServiceReference(refCode)
  if sRef:
   db = eDVBDB.getInstance()
   if db:
    if isHide : ret = db.addFlag(sRef , 0x2)
    else  : ret = db.removeFlag(sRef, 0x2)
    if skipReload:
     return True if ret == 0 else False
    elif ret == 0:
     FFAvBD(True)
     return True
 return False
def FFAvBD(save=False):
 db = eDVBDB.getInstance()
 if db:
  if save:
   db.saveServicelist()
  db.reloadServicelist()
  db.reloadBouquets()
 FF3jYs()
def FF3jYs():
 VVhMBa = InfoBar.instance
 if VVhMBa:
  VVsufg = VVhMBa.servicelist
  if VVsufg:
   VVsufg.setMode()
def FFw4Nf(root):
 lst = []
 try:
  servicelist  = root and eServiceCenter.getInstance().list(root)
  VVkVSB = eServiceCenter.getInstance()
  if servicelist:
   while True:
    service = servicelist.getNext()
    if not service.valid():
     break
    if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
     continue
    info = VVkVSB.info(service)
    lst.append((service.toString(), info.getName(service)))
 except:
  pass
 return lst
def FFHW7H():
 VVT9rY = {0x01:"TV MPEG-2 SD",0x02:"Radio MPEG-1",0x03:"Teletext",0x04:"NVOD SD",0x05:"NVOD SD T.Shift",0x06:"Mosaic",0x07:"FM Radio",0x08:"DVB SRM",0x09:"Res. 9",0x0A:"Radio Adv. Codec",0x0B:"AVC Mosaic",0x0C:"Data",0x0D:"CI",0x0E:"RCS Map",0x0F:"RCS FLS",0x10:"DVB MHP",0x11:"TV HD MPEG-2",0x16:"TV SD H.264",0x17:"NVOD SD T.Sh.",0x18:"NVOD SD Ref.",0x19:"TV HD H.264",0x1A:"NVOD HD T.Sh.",0x1B:"NVOD HD Ref.",0x1C:"TV HD H.264",0x1D:"NVOD HD T.Sh.",0x1E:"NVOD HD Ref.",0x1F:"TV HEVC",0x20:"TV HEVC (HDR)",0x80:"User Def.",0x64:"Custom",0x81:"Custom",0x82:"Custom",0x84:"Custom",0x95:"Custom",0x98:"Custom",0x9B:"Custom",0xAB:"Custom",0xB4:"Custom",0xB5:"Custom",0xC6:"Custom",0xFA:"Custom",0xFB:"Custom",0xFC:"Custom"}
 VVqcet = list(VVT9rY)
 return VVqcet, VVT9rY
def FFsMPf():
 try:
  iPlugins.clearPluginList()
  iPlugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
 except:
  pass
def FFznCE(delta=0):
 Time = datetime.now() + timedelta(delta)
 midnight = Time.replace(hour=0, minute=0, second=0, microsecond=0)
 return mktime(midnight.timetuple())
def FFC3u1(unixTime):
 return datetime.fromtimestamp(unixTime).strftime('%Y-%m-%d %H:%M:%S')
def FFxN8A():
 year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
 return "%04d-%02d-%02d %02d:%02d:%02d" % (year, month, day, hour, minute, second)
def FFUD38():
 return FFxN8A().replace(" ", "_").replace("-", "").replace(":", "")
def FF3Odj(secs):
 m, s = divmod(secs, 60)
 h, m = divmod(m   , 60)
 return "%02d:%02d:%02d" % (h, m, s)
def FFky63():
 return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
def FFtKyC(url, outFile, timeout=3, mustBeImage=False):
 tmpDir  = "/tmp/"
 outFile  = tmpDir + outFile
 span = iSearch(r".*data.+base64,(.+)", url, IGNORECASE)
 if span:
  b64 = span.group(1)
  with open(outFile, "wb") as f:
   f.write(b64decode(b64))
  return outFile, ""
 if not CC9X9s.VVXxn6(url, justValidate=True):
  return "", "Invalid URL"
 if not iRequest:
  return "" , "Cannot import URLLIB/URLLIB2 !"
 try:
  req = iRequest(url.strip())
  req.add_header('User-Agent', 'Enigma2-Plugin')
  res = iUrlopen(req, timeout=timeout)
  resCode = res.code
  if resCode == 200 :
   if mustBeImage and "text/html" in res.headers.get("Content-Type"):
    return "", "Received TEXT/HTML (instead of image)"
   with open(outFile, "wb") as f:
    f.write(res.read())
   cont = res.headers.get("content-disposition")
   if cont:
    phpFile = ""
    span = iSearch(r'filename=["*](.+)["*]', str(cont), IGNORECASE)
    if span:
     phpFile = span.group(1)
     phpFiLe = phpFile.replace(".", "")
     fName, ext = os.path.splitext(phpFile)
     fName = CC9X9s.VVRoT5(fName)
     phpFile = tmpDir + fName + ext
     FFuB0V("mv -f '%s' '%s'" % (outFile, phpFile))
     outFile = phpFile
   if fileExists(outFile) : return outFile, ""
   else     : return "", "Cannot create file."
  else:
   if   resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", "Download Failed (%s)" % err
 except Exception as e:
  return "", str(e)
def FFOPNa(numStr):
 return iMatch(r"^([-+]?\d+(\.\d*)?$)", numStr) is not None
def FF1I1d(num):
 return "s" if num > 1 else ""
def FFgevD(num, minNum, maxNum):
 return max(min(maxNum, num), minNum)
def FF6NMP(OldValue, OldMin, OldMax, NewMin, NewMax):
 return (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
def FFtF9Z(a, b):
 return (a > b) - (a < b)
def FFAyBN(a, b):
 def VVc2Vb(var):
  return [ (int(c) if c.isdigit() else c) for c in iSplit(r'(\d+)', var) ]
 a = VVc2Vb(a)
 b = VVc2Vb(b)
 return (a > b) - (a < b)
def FFDgxV(mycmp):
 class CCvGfl(object):
  def __init__(self, obj, *args) : self.obj = obj
  def __lt__(self, other): return mycmp(self.obj, other.obj) < 0
  def __gt__(self, other): return mycmp(self.obj, other.obj) > 0
  def __eq__(self, other): return mycmp(self.obj, other.obj) == 0
  def __le__(self, other): return mycmp(self.obj, other.obj) <= 0
  def __ge__(self, other): return mycmp(self.obj, other.obj) >= 0
  def __ne__(self, other): return mycmp(self.obj, other.obj) != 0
 return CCvGfl
def FF15cM(SELF, message, title="", VVCeou=None):
 SELF.session.openWithCallback(VVCeou, CCQGiA, title=title, message=message, VVbYzk=True)
def FF90Bc(SELF, message, title="", VV4VK0=VVBTEe, VVCeou=None, **kwargs):
 SELF.session.openWithCallback(VVCeou, CCQGiA, title=title, message=message, VV4VK0=VV4VK0, **kwargs)
def FFw5OO(SELF, message, title="")  : FFOsAJ(SELF.session, message, title)
def FFZoTn(SELF, path, title="") : FFOsAJ(SELF.session, "File not found !\n\n%s" % path, title)
def FF5BXO(SELF, path, title="") : FFOsAJ(SELF.session, "File is empty !\n\n%s"  % path, title)
def FFgq4o(SELF, title="")  : FFOsAJ(SELF.session, "OPKG/IPKG/DPKG Tools not found", title)
def FFOsAJ(session, message, title="") : session.open(BF(CCCCSM, title=title, message=message))
def FFaSvq(SELF, VVCeou, title="", defaultText="", message=""):
 mode = CFG.keyboard.getValue()
 allOK = False
 if mode == "v":
  try:
   from Screens.VirtualKeyBoard import VirtualKeyBoard
   obj = SELF.session.openWithCallback(VVCeou, VirtualKeyBoard, title=message, text=defaultText)
   allOK = True
   obj.setTitle(title)
  except:
   pass
 elif mode == "s":
  try:
   from Screens.InputBox import InputBox
   SELF.session.openWithCallback(VVCeou, InputBox, windowTitle=title, title=message.replace("\n", " "), text=defaultText)
   allOK = True
  except:
   pass
 if not allOK:
  try:
   FFw5OO(SELF, "Cannot run the Input Dialog (keyboard) !", title="Keyboard Error")
  except:
   pass
def FFNKVM(SELF, callBack_Yes, VVILc0, callBack_No=None, title="", VV4evd=False, VVvAFb=True, isFromExternal=False):
 session = SELF if isFromExternal else SELF.session
 return session.openWithCallback(BF(FFkXyy, callBack_Yes, callBack_No)
         , BF(CCyNBo, title=title, VVILc0=VVILc0, VVvAFb=VVvAFb, VV4evd=VV4evd))
def FFkXyy(callBack_Yes, callBack_No, FFNKVMed):
 if FFNKVMed : callBack_Yes()
 elif callBack_No: callBack_No()
def FF5uKN(SELF, txt="", timeout=0, isGrn=False):
 if len(txt) > 0:
  try:
   if isGrn: FFWN9Z(SELF["myInfoBody"], "#00004040")
   SELF["myInfoFrame"].show()
   SELF["myInfoBody"].show()
   SELF["myInfoBody"].setText(str(txt))
   if timeout > 0: SELF.VVHYJv.start(timeout, True)
  except: pass
 else: FF0P1X(SELF)
def FFzLBa(*kargs, **kwargs):
 FFFANg(BF(FF5uKN, *kargs, **kwargs))
def FF0P1X(SELF):
 try:
  SELF.VVHYJv.stop()
  SELF["myInfoFrame"].hide()
  SELF["myInfoBody"].hide()
 except:
  pass
def FFBF0K(SELF):
 try: return SELF["myInfoBody"].visible
 except: return False
def FF1Dpj(SELF, callBackFunc, **kwargs):
 try:
  if callBackFunc : win = SELF.session.openWithCallback(callBackFunc, BF(CCw8v2, **kwargs))
  else   : win = SELF.session.open(BF(CCw8v2, **kwargs))
  FFF9tS(win)
  return win
 except:
  return None
def FFYySC(SELF, callBackFunc, **kwargs):
 win = SELF.session.openWithCallback(callBackFunc, BF(CCcsto, **kwargs))
 FFF9tS(win)
 return win
def FFHf46(txt):
 return ("--[ %s ]%s" % (txt,  "-" * 100), )
def FFnqNr(txt, ref, cond, color=""):
 return (color + txt, ref) if cond else (txt,)
def FFcpNw(SELF, **kwargs):
 SELF.session.open(CCjQ0P, **kwargs)
def FFHLqT(SELF, isTopBar=False):
 if isTopBar : names = [ "keyRedTop" , "keyGreenTop" , "keyYellowTop", "keyBlueTop"  ]
 else  : names = [ "keyRed" , "keyGreen" , "keyYellow" , "keyBlue"  ]
 for name in names:
  try:
   FFy4xL(SELF[name], "#000000", 3)
  except:
   pass
def FFy4xL(label, color, w):
 try:
  inst = label.instance
  inst.setBorderColor(parseColor(color))
  inst.setBorderWidth(w)
 except:
  pass
def FFSK9d(SELF, menuObj):
 try:
  menuObj.instance.setFont(gFont(VVR8AG, SELF.skinParam["bodyFontSize"]))
 except:
  pass
def FFR3zK(SELF, menuObj=None, minRows=0):
 if not menuObj:
  menuObj = SELF["myMenu"]
 FFSK9d(SELF, menuObj)
 winInst  = SELF.instance
 menuInst = menuObj.instance
 maxH = SELF.skinParam["height"]
 winW = winInst.size().width()
 winH = winInst.size().height()
 menuW = menuInst.size().width()
 menuH = menuInst.size().height()
 lineH = menuObj.l.getItemSize().height()
 menuH1 = (max(minRows, len(menuObj.list))) * lineH
 diff = menuH1 - menuH
 winNewH = winH + diff
 btnDiff = diff
 if winNewH > winH:
  if winH + lineH <= maxH:
   btnDiff = lineH
   menuH = menuH + lineH
   menuInst.resize(eSize(*(menuW, menuH)))
   winInst.resize(eSize(*(winW, winH + lineH)))
  else:
   btnDiff = 0
  pos  = menuObj.getPosition()
  part = menuInst.size().height() % lineH
  half = int(part / 2)
  menuInst.resize(eSize(*(menuW, menuH - part)))
  menuInst.move(ePoint(pos[0], pos[1] + half))
 else:
  menuInst.resize(eSize(*(menuW, menuH + diff)))
  winInst.resize(eSize(*(winW, winNewH)))
 winH = winInst.size().height()
 screenSize = getDesktop(0).size()
 winInst.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winH) // 2))
 names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
 for name in names:
  try:
   obj = SELF[name]
   pos = obj.getPosition()
   obj.instance.move(ePoint(pos[0], pos[1] + btnDiff))
  except:
   pass
 winSize = winInst.size()
 FFYIKB(SELF, winSize.width(), winSize.height())
def FFYIKB(SELF, w, h):
 fSize = SELF["myInfoFrame"].instance.size()
 bSize  = SELF["myInfoBody"].instance.size()
 SELF["myInfoFrame"].instance.move(ePoint((w - fSize.width()) // 2, (h - fSize.height()) // 2))
 SELF["myInfoBody"].instance.move(ePoint((w - bSize.width()) // 2, (h - bSize.height()) // 2))
def FFwz8B():
 s = getDesktop(0).size()
 return (s.width(), s.height())
def FFq3UP(VVTFXq):
 screenSize  = FFwz8B()
 screenH   = screenSize[1]
 ratioH   = screenH / 1080.0
 bodyFontSize = int(ratioH  * VVTFXq)
 return bodyFontSize
def FFdrU1(VVTFXq, extraSpace):
 font = gFont(VVR8AG, VVTFXq)
 VVNyBH = fontRenderClass.getInstance().getLineHeight(font) or (VVTFXq * 1.25)
 return int(VVNyBH + VVNyBH * extraSpace)
def FFRBRO(winType, width, height, titleFontSize, marginLeft, marginTop, titleColor, bodyColor, bodyFontSize, barHeight=0, vSliderW=0, topRightBtns=0, lineGap=0.15, addFramedPic=False, usefixedFont=False, winRatio=1, titleSep=True, menuLabel=0, morePar={}):
 screenSize = FFwz8B()
 screenW = int(screenSize[0] * winRatio)
 screenH = int(screenSize[1] * winRatio)
 if width == 0 : width  = screenW
 if height == 0: height = screenH
 extraPar  = None
 ratioW   = screenW / 1920.0
 ratioH   = screenH / 1080.0
 width   = int(ratioW  * width)
 height   = int(ratioH  * height)
 titleH   = int(ratioH  * 50)
 marginLeft  = int(ratioW  * marginLeft)
 marginTop  = int(ratioH  * marginTop)
 bodyFontSize = int(ratioH  * bodyFontSize)
 barHeight  = int(ratioH  * barHeight)
 vSliderW  = int(ratioW  * vSliderW)
 marginTop  = max(1, marginTop)
 scrollBarW  = int(ratioW * 15)
 bodyFontStr  = 'font="%s;%d"' % (VVR8AG, bodyFontSize)
 alignCenter  = 'halign="center" valign="center"'
 alignLeftTop = 'halign="left" valign="top"'
 alignLeftCenter = 'halign="left" valign="center"'
 alignRightCenter= 'halign="right" valign="center"'
 titleFontSize = min(int(ratioH  * titleFontSize), int(0.7  * titleH))
 bodyLineH  = FFdrU1(bodyFontSize, lineGap)
 bodyW   = width - marginLeft * 2
 bodyTop   = titleH + 1 + marginTop
 bodyH   = height - bodyTop - marginTop
 if barHeight > 0: bodyH -= barHeight
 tmp  =  '<screen position="center,center" size="%d,%d" backgroundColor="%s" title="%s" flags="wfNoBorder" >' % (width, height, bodyColor, PLUGIN_NAME)
 tmp += '<widget  name="myBody" position="0,0" size="%d,%d" zPosition="-1" backgroundColor="%s" />' % (width, height, bodyColor)
 if titleSep:
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (titleH + 1, width)
 tmp += '<widget name="myTitle" position="0,0" size="%d,%d" zPosition="2" noWrap="1" backgroundColor="%s" font="%s;%d" foregroundColor="#ffffbb"  %s />' % (width, titleH, titleColor, VVR8AG, titleFontSize, alignLeftCenter)
 if winType in (VVF5EY, VVTnM0):
  if winType == VVTnM0 : menuName = "config"
  else      : menuName = "myMenu"
  menuW = bodyW - int(bodyW * menuLabel / 100.0) - marginLeft if menuLabel else bodyW
  tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" itemHeight="%d" scrollbarMode="showOnDemand" />' % (menuName, marginLeft, bodyTop, menuW, bodyH, bodyColor, bodyLineH)
  if menuLabel:
   param = 'backgroundColor="%s" foregroundColor="#ffffff" %s' % (bodyColor, bodyFontStr)
   x, w, gap = menuW + marginLeft * 2, bodyW - menuW - marginLeft, int(marginLeft / 2.0)
   tmp += '<widget name="myLabelFrm" position="%d,%d" size="%d,%d" zPosition="3" %s />' % (x - gap, bodyTop, w + gap * 2, bodyH, param)
   tmp += '<widget name="myLabelTit" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (x, bodyTop + 10, w, titleH, alignCenter, param)
   tmp += '<widget name="myLabelTxt" position="%d,%d" size="%d,%d" zPosition="4" noWrap="1" %s %s />' % (x, bodyTop + titleH + gap , w, bodyH - titleH - gap * 2, alignLeftCenter, param)
 elif winType == VV2Zdx:
  tmp += '<widget name="myWinTitle" position="0,0" size="%d,%d" zPosition="3" noWrap="1" transparent="1" foregroundColor="#ffffff" shadowColor="#440000" shadowOffset="-2,-2" %s %s />' % (width, titleH, bodyFontStr, alignCenter)
 elif winType == VVAjlU:
  names = ("Red", "Green", "Yellow", "Blue")
  colors = [ "#229f1313", "#22005500", "#22a08000", "#2218188b"]
  totBtns = len(names)
  gap  = 5
  btnW = int(width * 0.09)
  btnH = int(titleH * 0.7)
  left = width - btnW - titleH * 2
  top  = int((titleH - btnH) / 2.0)
  fSize = int(0.45  * titleH)
  for i in range(totBtns-1, -1, -1):
   tmp += '<widget name="key%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" backgroundColor="%s" %s />' % (names[i], left, top, btnW, btnH, VVR8AG, fSize, colors[i], alignCenter)
   left -= (btnW + gap)
  names = ("Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos")
  totBtns = len(names)
  btnW = int((width - gap * (totBtns + 1)) / totBtns)
  btnH = titleH
  left = gap
  param = 'size="%d,%d" zPosition="3" backgroundColor="#33222222" %s %s ' % (btnW, btnH, bodyFontStr, alignCenter)
  for i in range(totBtns):
   tmp += '<widget name="mySubt%s"  position="%d,%d" foregroundColor="#00cccccc" %s />' % (names[i], left, titleH + gap  , param)
   tmp += '<widget name="mySubt%s1" position="%d,%d" foregroundColor="#00ffff88" %s />' % (names[i], left, titleH + btnH + 1, param)
   left += btnW + gap
  tmp += '<widget name="mySubtCursor" position="0,%d" size="%d,%d" zPosition="2" backgroundColor="#00ffff00" />' % (titleH + 1, btnW + gap * 2, btnH * 2 + gap - 1)
  top = titleH + 1 + btnH * 2 + gap
  tmp += '<widget name="mySubtCover" position="0,0" size="%d,%d" zPosition="5" backgroundColor="#ff000000" />' % (width, top - 1)
  tmp += '<widget name="mySubtFr" position="0,%d" size="%d,%d" zPosition="3" backgroundColor="#ff002233" />' % (top, width, height - top)
  for i in range(4):
   tmp += '<widget name="mySubtSep%d" position="1,%d" size="%d,1" zPosition="7" backgroundColor="#00555555" />' % (i, top + 1, width - 2)
   if i < 3:
    tmp += '<widget name="mySubt%d" position="1,%d" size="%d,%d" zPosition="6" noWrap="1" backgroundColor="#00000000" %s %s />' % (i, top + 1, width - 2, titleH - 2, bodyFontStr, alignCenter)
   top += titleH
 elif winType == VVmZLR:
  barH = int((bodyH + marginTop - marginTop * 3.0) / 3.0)
  picW = int(bodyW * 0.07)
  barW = bodyW - picW - marginLeft
  b1Top = bodyTop
  b2Top = b1Top + barH + marginTop
  b3Top = b2Top + barH + marginTop
  timeW = int(barW * 0.1)
  b2Left1 = marginLeft
  b2Left2 = timeW + marginLeft * 2
  b2Left4 = barW - timeW + marginLeft
  b2Left3 = b2Left4 - marginLeft - timeW
  pLeft = width - picW - marginLeft
  FF15cML = b2Left2 + timeW + marginLeft
  FF15cMW = b2Left3 - marginLeft - FF15cML
  name = "myPlay"
  tmp += '<widget name="%sBarF"  position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#0a444444" />' % (name, marginLeft, b1Top, barW, barH)
  tmp += '<widget name="%sBarBG" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#11000000" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sBar"   position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#06445566" />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2)
  tmp += '<widget name="%sMov"   position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#0aff8000" />' % (name, marginLeft + 1, b1Top - 4, 3, barH + 8)
  tmp += '<widget name="%sVal"   position="%d,%d" size="%d,%d" zPosition="5" backgroundColor="#0a005555" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" %s %s />' % (name, marginLeft + 1, b1Top + 1, barW - 2, barH - 2, bodyFontStr, alignCenter)
  param = 'zPosition="1" noWrap="1" backgroundColor="%s" %s' % (bodyColor, bodyFontStr)
  tmp += '<widget name="%sPos"  position="%d,%d" size="%d,%d" %s foregroundColor="#00aacccc" %s />' % (name, b2Left1, b2Top, timeW, barH, param, alignLeftCenter)
  tmp += '<widget name="%sSkp"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffff00" %s />' % (name, b2Left2, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sMsg"  position="%d,%d" size="%d,%d" %s foregroundColor="#00ffffff" %s />' % (name, FF15cML , b2Top, FF15cMW , barH, param, alignCenter)
  tmp += '<widget name="%sRem"  position="%d,%d" size="%d,%d" %s foregroundColor="#00CDAE77" %s />' % (name, b2Left3, b2Top, timeW, barH, param, alignCenter)
  tmp += '<widget name="%sDur"  position="%d,%d" size="%d,%d" %s foregroundColor="#00B1C177" %s />' % (name, b2Left4, b2Top, timeW, barH, param, alignRightCenter)
  sepTop = int(b3Top - marginTop / 2.0)
  tmp += '<widget name="myPlaySep" position="0,%d" size="%d,1" zPosition="1" backgroundColor="#11444444" />' % (sepTop, pLeft)
  color = ["#0a004400", "#00555555", "#00bbbb55", "#00bbbb55", "#00777777", "#00999999", "#00999999", "#00999999", "#0a18188b"]
  names = ["Grn"  , "Jmp"   , "Dat"   , "Tim"    , "Mrk"  , "Res"   , "Fps"   , "Asp"    , "Blu"  ]
  Len  = len(names)
  b3W  = int((barW - marginLeft * (Len - 1)) / Len)
  left = marginLeft
  for i in range(9):
   if i in (0, Len-1) : bg = 'foregroundColor="#00FFFFFF" backgroundColor="%s"' % color[i]
   else     : bg = 'foregroundColor="%s"'        % color[i]
   tmp += '<widget name="myPlay%s" position="%d,%d" size="%d,%d" zPosition="1" noWrap="1" %s %s %s />' % (names[i], left, b3Top + 1, b3W, barH, bodyFontStr, alignCenter, bg)
   left += b3W + marginLeft
  pTop = titleH + 6
  pW  = width - pLeft - 8
  pH  = height - pTop - 4
  tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00333333" />' % (pLeft, titleH + 2, height - titleH + 1)
  tmp += '<widget name="myPlayPic" position="%d,%d" size="%d,%d" zPosition="1" alphatest="blend" />' % (pLeft + 4, pTop, pW, pH)
  tmp += '<widget name="myPlayTyp" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#1100202a" %s %s />' % (pLeft + 4, pTop, pW, pH, alignCenter, bodyFontStr)
  sz = int(titleH * 0.6)
  top = int((titleH - sz) / 2.0)
  tmp += '<widget name="myPlayDnld" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  tmp += '<widget name="myPlayRpt" position="%d,%d" size="%d,%d" zPosition="100" alphatest="blend" />' % (0, top, sz, sz)
  params = 'zPosition="10" backgroundColor="#11444411"'
  tmp += '<eLabel %s position="0,0"  size="%d,1" />' % (params, width)
  tmp += '<eLabel %s position="0,%d" size="%d,1" />' % (params, height - 1, width)
  tmp += '<eLabel %s position="0,0"  size="1,%d" />' % (params, height)
  tmp += '<eLabel %s position="%d,0" size="1,%d" />' % (params, width - 1, height -1)
 elif winType == VVQNPR:
  w  = int((width - 10) / 4.0)
  h  = bodyH - 10
  left = 5
  top  = bodyTop + 5
  tmp += '<widget name="myColorF" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00ffffff" />' % (left, top, w, h)
  for i in range(4):
   tmp += '<widget name="myColor%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (i, left + 4, top + 4, w - 8, h - 8, bodyColor, bodyFontStr, alignLeftCenter)
   left += w
 elif winType == VVRoYj:
  itemsH  = bodyLineH * 2.0
  menuH  = int(bodyLineH * 2.5)
  menuW  = int(ratioW  * 200)
  menuLeft = int((width - menuW) / 2.0)
  textH  = bodyH - menuH
  menuTop  = bodyTop + textH
  itemsTop = int(menuTop + marginTop / 2.0 + (menuH - itemsH) / 2.0)
  tmp += '<widget name="myLine"  position="0,%d"  size="%d,1"  zPosition="3" backgroundColor="#11444444" />' % (menuTop, width)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" %s %s />' % (marginLeft, bodyTop, bodyW, textH, bodyColor, alignCenter, bodyFontStr)
  tmp += '<widget name="myMenu"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" foregroundColor="#ffffff" scrollbarMode="showOnDemand" itemHeight="%d" />' % (menuLeft, itemsTop, menuW, itemsH, bodyColor, bodyLineH)
 elif winType == VVFX81:
  tmp += '<widget name="myTableH" position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, 0, bodyColor, scrollBarW)
  tmp += '<widget name="myTable"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" scrollbarMode="showOnDemand" scrollbarWidth="%d" />' % (marginLeft, bodyTop, bodyW, bodyH, bodyColor, scrollBarW)
 elif winType == VVwFfF:
  titleFont = int(bodyFontSize * 0.6)
  boxFont  = int(bodyFontSize * 1.2)
  boxH  = int(bodyFontSize * 2.0)
  digitW  = int(bodyFontSize * 1.3)
  names  = ["year", "month", "day", "gap", "hour", "min", "sec"]
  boxW  = [  4   ,    2   ,   2  ,   1  ,   2   ,   2  ,   2  ]
  gap   = 4
  boxLeft  = int((width - digitW * 15) / 2.0 - gap)
  btnTitleH = titleFont * 2
  titleTop = int(bodyTop + (height - barHeight - bodyTop - (btnTitleH + boxH + gap)) / 2.0)
  boxTop  = titleTop + btnTitleH + gap
  tmp += '<widget name="curTime" position="0,%d" size="%d,%d" zPosition="2" foregroundColor="white" transparent="1" %s %s />' % (titleH + 1, width, titleTop - titleH - 2, bodyFontStr, alignCenter)
  for i in range(0, 7):
   tmpW = digitW * boxW[i]
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i]+"Title", boxLeft, titleTop, tmpW - gap, btnTitleH, VVR8AG, titleFont, alignCenter)
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="3" font="%s;%d" foregroundColor="white" backgroundColor="#11404040" %s />' % (names[i], boxLeft, boxTop, tmpW - gap, boxH, VVR8AG, boxFont, alignCenter)
   boxLeft += tmpW + boxW[i]
 elif winType == VVGUPT:
  barW  = int(ratioW  * 500)
  infH  = int(titleH * 0.8)
  infTop  = height - infH
  infFont  = int(0.5  * infH)
  bAreaH  = int(height - titleH - infH)
  barH  = int((bAreaH - marginTop * 4) / 3)
  barTop  = titleH + marginTop
  barL  = int(width - barW - titleH / 2)
  txtW  = barL - marginLeft - 4
  name  = [ "SNR", "AGC", "BER"]
  tmp += '<widget name="mySNRdB" text="0 dB" position="%d,%d" size="%d,%d" %s %s zPosition="4" transparent="1" foregroundColor="white" />' % (0, 0, width - 20, titleH, bodyFontStr, alignRightCenter)
  for i in range(3):
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="5" text="%s" %s %s backgroundColor="%s" foregroundColor="white" />' % (marginLeft, barTop, txtW, barH, name[i], bodyFontStr, alignLeftCenter, bodyColor)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#ffffff" />' % (barL-1, barTop-1, barW+2, barH+2)
   tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="%s" />' % (barL, barTop, barW, barH, bodyColor)
   tmp += '<widget name="mySlider%s" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="mySliderCov%s" position="%d,%d" size="%d,%d" zPosition="6" />' % (name[i], barL, barTop, barW, barH)
   tmp += '<widget name="my%s" position="%d,%d" size="%d,%d" %s %s zPosition="7" text="0 " foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" />' % (name[i], barL, barTop, barW, barH, bodyFontStr, alignCenter)
   barTop += barH + marginTop
  tmp += '<widget name="myTPInfo" position="0,%d" size="%d,%d" zPosition="8" backgroundColor="%s" font="%s;%d" %s />' % (infTop, width, infH, titleColor, VVR8AG, infFont, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="9" backgroundColor="#22aaaaaa" />' % (infTop -1, width)
 elif winType == VVASkO:
  barW = bodyW
  barH = int(bodyH * 0.7)
  barL = marginLeft
  barT = int(bodyTop + (bodyH - barH) / 2.0)
  fontH = int(0.5  * barH)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#ffffff" />' % (barL-1, barT-1, barW+2, barH+2)
  tmp += '<eLabel position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="%s" />' % (barL, barT, barW, barH, bodyColor)
  tmp += '<widget name="myProgBar" position="%d,%d" size="%d,%d" zPosition="4" backgroundColor="#004444" foregroundColor="#ffffff" />' % (barL, barT, barW, barH)
  tmp += '<widget name="myProgBarVal" position="%d,%d" size="%d,%d" zPosition="5" foregroundColor="#ffffff" transparent="1" shadowColor="#00000000" shadowOffset="-1,-1" font="%s;%d" %s />' % (barL, barT, barW, barH, VVR8AG, fontH, alignCenter)
 elif winType in (VVa8YL, VVGa0l, VVC6jd, VV3Lt2, VV8OK0):
  if   winType == VVa8YL  : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.75, 0.25, int(width * 0.45), int(width * 0.55), CFG.transpColorPicons.getValue()
  elif winType == VVGa0l : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorPosters.getValue()
  elif winType == VVC6jd : totRows, totCols, picR, lblR, w1, w2, transpBG = 2, 6, 0.90, 0.10, int(width * 0.85), int(width * 0.15), CFG.transpColorMovies.getValue()
  elif winType == VV3Lt2 : totRows, totCols, picR, lblR, w1, w2, transpBG = 5, 7, 0.80, 0.20, int(width * 0.80), int(width * 0.20), CFG.transpColorChannels.getValue()
  else          : totRows, totCols, picR, lblR, w1, w2, transpBG = 4, 5, 0.65, 0.35, int(width * 0.85), int(width * 0.15), ""
  infT = titleH + 2
  infH = int(titleH * 1.8)
  boxT = infT + infH + marginTop + 2
  boxW = int((width - vSliderW - marginLeft * 2)  / totCols)
  boxH = int((height - barHeight - boxT - marginTop * 2) / totRows)
  extraPar = marginLeft, boxT, boxW, boxH
  s = '<widget name="myPiconInf%d" position="%d,%d" size="%d,%d" zPosition="1" foregroundColor="%s" noWrap="1" backgroundColor="%s" font="%s;%d" %s />'
  h = int(infH * 0.3333)
  y = infT + 1
  fg= "#00ffffff"
  if winType == VVa8YL:
   fntSz, bg = int(h * 0.7), ("#00002828", "#00003333", "#00004444", "#00002233", "#00003344", "#00004455")
   for i in range(3):
    tmp += s % (i  , 0   , y, w1, h, fg, bg[i]  , VVR8AG, fntSz, alignLeftCenter)
    tmp += s % (i+3, w1+1, y, w2, h, fg, bg[i+3], VVR8AG, fntSz, alignLeftCenter)
    y += h
  else:
   h1, h2 = int(infH * 0.60), int(infH * 0.40)
   tmp += s % (0, 0, y  , w1, h1 , "#0088ff88", "#00333333", VVR8AG, int(h1 * 0.7), alignLeftCenter)
   tmp += s % (1, 0, y + h1, w1, h2 , "#00aaaaaa", "#002a2a2a", VVR8AG, int(h2 * 0.7), alignLeftCenter)
   h, fntSz, bg = int(infH * 0.50), int(bodyFontSize * 0.52), "#33001111"
   tmp += s % (2, w1+1, y   , w2, h, fg, bg, VVR8AG, fntSz, alignCenter)
   tmp += s % (3, w1+1, y + h, w2, h, fg, bg, VVR8AG, fntSz, alignCenter)
  tmp += '<eLabel position="0,%d"  size="%d,1"  zPosition="1" backgroundColor="#22aaaaaa" />' % (infT + infH, width)
  pT = infT + 3
  pH = infH - 6
  pW = int(pH * 1.66)
  pL = width - pW - 12
  tmp += '<widget name="myPiconF"   position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#0a555500" />' % (pL    , pT    , pW  , pH)
  tmp += '<widget name="myPiconBG"  position="%d,%d" size="%d,%d" zPosition="3" backgroundColor="#0a220000" />' % (pL + 1, pT + 1, pW - 2 , pH - 2)
  tmp += '<widget name="myPiconPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />'    % (pL + 2, pT + 2, pW - 4 , pH - 5)
  if morePar.get("grid", 0):
   y = boxT + boxH
   for i in range(totRows - 1):
    tmp += '<eLabel position="0,%d"  size="%d,1" zPosition="1" backgroundColor="#00555555" />' % (y, width)
    y += boxH
   x = boxW
   h = height - barHeight - boxT
   for i in range(totCols - 1):
    tmp += '<eLabel position="%d,%d"  size="1,%d" zPosition="1" backgroundColor="#00555555" />' % (x, boxT-2, h)
    x += boxW
  tmp += '<widget name="myPiconPtr" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="%s"/>' % (marginLeft, boxT + marginTop, boxW, boxH, morePar.get("cursC", "#00ffff00"))
  picBgTr = 'transparent="1"' if morePar.get("picBgTr", 0) else ""
  lblTr = 'transparent="1"' if morePar.get("lblTr", 0) else ""
  lblC = morePar.get("lblC", "#00003333")
  gapX = morePar.get("gapX", 3)
  gapY = morePar.get("gapY", 3)
  midGap = morePar.get("mGap", 0)
  areaW = boxW - gapX * 2
  areaH = boxH - gapY * 2 - midGap
  picT = boxT + gapY
  picH = int(areaH * picR)
  lblH = int(areaH * lblR)
  lblT = boxT + gapY + picH + midGap
  lblFont = int(lblH * 0.65)
  transpBG = 'backgroundColor="%s"'% transpBG if transpBG else ""
  for row in range(totRows):
   left = marginLeft + gapX
   for col in range(totCols):
    tmp += '<widget name="myPosterRep%d%d" position="%d,%d" size="%d,%d" zPosition="4" %s %s />' % (row, col, left, picT, areaW, picH, transpBG, picBgTr)
    tmp += '<widget name="myPosterPic%d%d" position="%d,%d" size="%d,%d" zPosition="5" alphatest="blend" />' % (row, col, left, picT, areaW, picH)
    tmp += '<widget name="myPosterLbl%d%d" position="%d,%d" size="%d,%d" zPosition="6" backgroundColor="%s" noWrap="1" %s font="%s;%d" %s />' % (row, col, left, lblT, areaW, lblH, lblC, lblTr, VVR8AG, lblFont, alignCenter)
    left += boxW
   picT += boxH
   lblT += boxH
 elif winType == VVdCmB:
  totRows = 6
  totCols = 8
  tstW = int(width - marginLeft  * 2)
  tstH = int(height * 0.15)
  tstT = int(height - barHeight - tstH)
  boxT = titleH + 2
  boxW = int(width  / totCols)
  boxH = int((height - barHeight - tstH - boxT) / totRows)
  tmp += '<widget name="myColorPtr" position="%d,%d" size="%d,%d" zPosition="1" backgroundColor="#00aaaa00" />' % (0, boxT, boxW, boxH)
  gap  = marginTop
  gap1 = int(gap / 2.0)
  for row in range(totRows):
   boxL = 0
   for col in range(totCols):
    tmp += '<widget name="myColor%d%d" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00000000" />' % (row, col, boxL+gap1, boxT+gap1, boxW-gap, boxH-gap)
    boxL += boxW
   boxT += boxH
  tmp += '<widget name="myColorTst" position="%d,%d" size="%d,%d" zPosition="2" backgroundColor="#00aaaaaa" %s %s />' % (marginLeft, tstT, tstW, tstH, alignCenter, bodyFontStr)
 elif winType == VVsieY:
  tmp += '<widget name="myPic" position="0,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (bodyTop, bodyW+3, bodyH+3)
 else:
  if   winType == VVq2lk : align = alignLeftCenter
  elif winType == VVAtoE : align = alignLeftTop
  else          : align = alignCenter
  if winType == VVQI2Y:
   iconSize = 60
   iconLeft = int(ratioH  * 20)
   iconTop  = int(bodyTop + (height - bodyTop - iconSize) / 2.0)
   iconW  = iconSize + iconLeft * 2
   marginLeft += iconW
   bodyW  -= iconW
   tmp += '<widget name="errPic" position="%d,%d" size="%d,%d" zPosition="4" alphatest="blend" />' % (iconLeft, iconTop, iconSize, iconSize)
  fontName = VVR8AG
  if usefixedFont and winType == VVAtoE:
   fLst = FFfSz6()
   if   VVGtks in fLst and CFG.fontPathTerm.getValue(): fontName = VVGtks
   elif VV5RV1 in fLst         : fontName = VV5RV1
  moreParams = 'backgroundColor="%s" foregroundColor="#ffffff" font="%s;%d" %s ' % (bodyColor, fontName, bodyFontSize, align)
  tmp += '<widget name="myLabel" position="%d,%d" size="%d,%d" zPosition="4" %s />' % (marginLeft, bodyTop, bodyW, bodyH, moreParams)
 infoW  = int(ratioW  * 500)
 infoH  = int(ratioH  * 100)
 infoLeft = int((width - infoW) / 2.0)
 infoTop  = int((height - infoH) / 2.0)
 VVTFXq = int(ratioH  * 30)
 tmp += '<widget name="myInfoFrame" position="%d,%d" size="%d,%d" zPosition="20" backgroundColor="#aaaa00" />' % (infoLeft, infoTop, infoW, infoH)
 tmp += '<widget name="myInfoBody"  position="%d,%d" size="%d,%d" zPosition="21" backgroundColor="#550000" foregroundColor="#ffff00" font="%s;%d" %s />' % (infoLeft+2, infoTop+2, infoW-4, infoH-4, VVR8AG, VVTFXq, alignCenter)
 if topRightBtns > 0:
  gap  = 6
  sz  = titleH - gap * 2
  mnuL = width - sz - gap * 2
  infL = mnuL if topRightBtns == 3 else mnuL - sz - gap
  par = 'size="%d,%d" zPosition="20" alphatest="blend"' % (sz, sz)
  if topRightBtns in (1, 2): tmp += '<widget name="keyMenu" position="%d,%d" %s />' % (mnuL, gap, par)
  if topRightBtns in (2, 3): tmp += '<widget name="keyInfo" position="%d,%d" %s />' % (infL, gap, par)
 if barHeight > 0:
  lineTop = height - barHeight
  topGap = max(3, int(ratioH  * 3))
  btnTop = lineTop + topGap
  btnH = height - btnTop - topGap
  barFont = int(0.7  * btnH)
  gap  = btnH
  spaceW = gap * (5)
  btnW = int((width - spaceW) / 4)
  left = gap
  name = [ "keyRed"   , "keyGreen" , "keyYellow", "keyBlue"  ]
  tmp += '<widget name="myBar"  position="0,%d"  size="%d,%d" zPosition="7" backgroundColor="%s" font="%s;%d" %s />' % (lineTop, width, height - lineTop, titleColor, VVR8AG, barFont, alignLeftCenter)
  tmp += '<widget name="myLine" position="0,%d"  size="%d,1"  zPosition="8" backgroundColor="#22aaaaaa" />' % (lineTop, width)
  for i in range(4):
   tmp += '<widget name="%s" position="%d,%d" size="%d,%d" zPosition="9" backgroundColor="%s" font="%s;%d" foregroundColor="white" noWrap="1" %s />' % (name[i], left, btnTop, btnW, btnH, VV6Q1c[i], VVR8AG, barFont, alignCenter)
   left += btnW + gap
 if vSliderW:
  par = 'position="0,0" size="20,20"'
  tmp += '<widget name="mySbFrm" zPosition="13" %s />' % par
  tmp += '<widget name="mySbBak" zPosition="14" %s />' % par
  tmp += '<widget name="mySbSld" zPosition="15" %s />' % par
 if winType == VVAtoE:
  name = [ "keyRedTop", "keyGreenTop" , "keyYellowTop", "keyBlueTop" ]
  btnW = int(ratioW  * 85)
  btnH = int(titleH * 0.6)
  btnTop = int(titleH * 0.2)
  btnLeft = width - (btnW + btnTop) * 4
  btnFont = int(btnH * 0.65)
  for i in range(4):
   tmp += '<widget name="%s1" position="%d,%d" size="%d,%d" zPosition="10" backgroundColor="#0affffff" />' % (name[i], btnLeft, btnTop, btnW, btnH)
   tmp += '<widget name="%s"  position="%d,%d" size="%d,%d" zPosition="11" backgroundColor="%s" font="%s;%d" foregroundColor="white" %s />' % (name[i], btnLeft+1, btnTop+1, btnW-2, btnH-2, VV6Q1c[i], VVR8AG, btnFont, alignCenter)
   btnLeft += (btnW + btnTop)
  if addFramedPic:
   picW = int(width  * 0.2)
   picH = int(height * 0.2)
   picLeft = width - picW - marginLeft - scrollBarW * 2
   tmp += '<widget name="myPicF" position="%d,%d" size="%d,%d" zPosition="12" backgroundColor="#0affffff" />' % (picLeft    , bodyTop    , picW  , picH)
   tmp += '<widget name="myPicB" position="%d,%d" size="%d,%d" zPosition="13" backgroundColor="%s" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2, bodyColor)
   tmp += '<widget name="myPic"  position="%d,%d" size="%d,%d" zPosition="14" alphatest="blend" />'   % (picLeft + 1, bodyTop + 1, picW - 2 , picH - 2)
 tmp += '</screen>'
 skinParam = {"width":width, "height":height, "titleH":titleH, "marginLeft":marginLeft, "marginTop":marginTop, "titleColor":titleColor, "bodyColor":bodyColor, "bodyFontSize":bodyFontSize, "barHeight":barHeight, "topRightBtns":topRightBtns, "bodyLineH":bodyLineH, "scrollBarW":scrollBarW, "lineGap":lineGap, "extraPar":extraPar}
 return tmp, skinParam
class Main_Menu(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 800, 950, 40, 50, 30, "#1a002244", "#10002233", 33, barHeight=40, topRightBtns=2)
  self.session  = session
  self.VVfYeC = ""
  self.themsList  = []
  self.Title   = "%s - %s" % (PLUGIN_NAME, VVLBtR)
  VVZJ87 = []
  if VVrOXT:
   VVZJ87.append(("-- MY TEST --", "myTest" ))
  VVZJ87.append(("File Manager"  , "fMan" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("IPTV"    , "iptv" ))
  VVZJ87.append(("Movies Browser" , "movie" ))
  VVZJ87.append(("Services/Channels", "chan" ))
  VVZJ87.append(("PIcons"   , "picon" ))
  VVZJ87.append(("EPG"    , "epg"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Terminal"   , "term" ))
  VVZJ87.append(("SoftCam"   , "soft" ))
  VVZJ87.append(("Plugins"   , "plug" ))
  VVZJ87.append(("Backup & Restore" , "bakup" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Date/Time"  , "date" ))
  VVZJ87.append(("Network"   , "net"  ))
  for ndx, item in enumerate(VVZJ87):
   item = list(item)
   item[0] = "  %s" % item[0]
   VVZJ87[ndx] = tuple(item)
  FFmmH7(self, title=self.Title, VVZJ87=VVZJ87)
  FFR9Qm(self["keyRed"] , "Exit")
  FFR9Qm(self["keyGreen"] , "Settings")
  FFR9Qm(self["keyYellow"], "Dev. Info.")
  FFR9Qm(self["keyBlue"] , "Color/Font")
  self["myActionMap"].actions.update({
   "red" : self.close       ,
   "green" : self.VVrJjZ      ,
   "yellow": self.VVnuPE      ,
   "blue" : self.VVZIeE     ,
   "info" : BF(FFJsIX, self, self.VVUb64) ,
   "text" : self.VVWRrp      ,
   "menu" : self.VVs6Lp    ,
   "0"  : BF(self.VVfy1h, 0)   ,
   "1"  : BF(self.VVzO14, "fMan")   ,
   "2"  : BF(self.VVzO14, "iptv")   ,
   "3"  : BF(self.VVzO14, "movie")   ,
   "4"  : BF(self.VVzO14, "chan")   ,
   "5"  : BF(self.VVzO14, "picon")   ,
   "6"  : BF(self.VVzO14, "epg")   ,
   "7"  : BF(self.VVzO14, "term")   ,
   "8"  : BF(self.VVzO14, "soft")   ,
   "9"  : BF(self.VVzO14, "plug")   ,
   "last" : BF(self.VVzO14, "bakup")   ,
   "next" : BF(self.VVzO14, "date")
  })
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
  global VVoWDM, VV8Ixy, VVofuN
  VVoWDM = VV8Ixy = False
  VVofuN = True
 def VVxCTS(self):
  self.VVzO14(self["myMenu"].l.getCurrentSelection()[1])
 def VVzO14(self, item):
  if item is not None:
   for ndx, param in enumerate(self["myMenu"].list):
    if len(param) > 1 and param[1] == item:
     self["myMenu"].moveToIndex(ndx)
     break
   global VVc5QS
   VVc5QS = self["myMenu"].l.getCurrentSelection()[0].strip()
   if   item == "myTest" : self.VVscj7()
   elif item == "fMan"  : self.session.open(CCCXvS)
   elif item == "iptv"  : self.session.open(CC9X9s)
   elif item == "movie" : FFJsIX(self, BF(CCC4Ww.VVQCAN, self))
   elif item == "chan"  : self.session.open(CCdAiy)
   elif item == "picon" : self.VVIq1f()
   elif item == "epg"  : self.session.open(CCvWMS)
   elif item == "term"  : self.session.open(CC03Db)
   elif item == "soft"  : self.session.open(CCXkrC)
   elif item == "plug"  : self.session.open(CCXYqv)
   elif item == "bakup" : self.session.open(CCIEaN)
   elif item == "date"  : self.session.open(CCfRDb)
   elif item == "net"  : self.session.open(CCgtPP)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
  FFHLqT(self)
  FFj9eW(self)
  VVzIjJ, VVGCAe, VVEb2k, VVmRnO, VVIJjG, oldMovieDownloadPath = FFDEHe()
  if VVzIjJ or VVGCAe or VVEb2k or VVmRnO or VVIJjG or oldMovieDownloadPath:
   VVYPGf = lambda path, subj: "%s:\n%s\n\n" % (subj, FFGB9z(path, VVLbyB)) if path else ""
   txt = "The following directories were not found and were changed to default:\n\n"
   txt += VVYPGf(VVzIjJ   , "Backup/Restore Path"    )
   txt += VVYPGf(VVGCAe  , "Created Package Files (IPK/DEB)" )
   txt += VVYPGf(VVEb2k  , "Download Packages (from feeds)" )
   txt += VVYPGf(VVmRnO , "Exported Tables"     )
   txt += VVYPGf(VVIJjG , "Exported PIcons"     )
   txt += VVYPGf(oldMovieDownloadPath , "Movie/Series Download"   )
   txt += "\nYou can change paths from Settings.\n"
   FF90Bc(self, txt, title="Settings Paths")
  self.VVYq6l()
  if (EASY_MODE or VVGLjm or VVrOXT):
   FFWN9Z(self["myTitle"], "#ff0000")
  var = "PLUGIN" + "_VERSION"
  if var in globals():
   FF5uKN(self, "Welcome", 300)
  FFFANg(self.VVYcEo)
 def VVYcEo(self):
  if CFG.checkForUpdateAtStartup.getValue():
   curVer, webVer, url, isHigher, err = CCcHsQ.VVS4em()
   if webVer and isHigher:
    self["myTitle"].setText("  %s (v%s available)" % (self.Title, webVer))
 def onExit(self):
  FFuB0V("rm -f /tmp/ajp_*")
  global VVoWDM, VV8Ixy, VVofuN
  VVoWDM = VV8Ixy = False
  del VVofuN
 def VVfy1h(self, digit):
  self.VVfYeC += str(digit)
  ln = len(self.VVfYeC)
  global VVoWDM
  if ln == 4:
   if self.VVfYeC == "0" * ln:
    VVoWDM = True
    FFWN9Z(self["myTitle"], "#11805040")
   else:
    self.VVfYeC = "x"
 def VVWRrp(self):
  self.VVfYeC += "t"
  if self.VVfYeC == "0" * 4 + "t" * 2:
   global VV8Ixy
   VV8Ixy = True
   FFWN9Z(self["myTitle"], "#dd5588")
 def VVIq1f(self):
  found = False
  pPath = CCijoe.VV4boJ()
  if pathExists(pPath):
   for fName, fType in CCijoe.VV5WZn(pPath):
    if fName:
     found = True
     break
  if found:
   self.session.open(CCijoe)
  else:
   VVZJ87 = []
   VVZJ87.append(("PIcons Tools" , "CCijoe" ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(CCijoe.VV5A2L())
   VVZJ87.append(VVoqHH)
   VVZJ87 += CCijoe.VVuPbO()
   FFYySC(self, self.VVXKym, VVZJ87=VVZJ87)
 def VVXKym(self, item=None):
  if item:
   if   item == "CCijoe"   : self.session.open(CCijoe)
   elif item == "VVsVVN"  : CCijoe.VVsVVN(self)
   elif item == "VVi5EK"  : CCijoe.VVi5EK(self)
   elif item == "findPiconBrokenSymLinks" : CCijoe.VVVQKj(self, True)
   elif item == "FindAllBrokenSymLinks" : CCijoe.VVVQKj(self, False)
 def VVUb64(self):
  changeLogFile = VVrrZu + "_changeLog.txt"
  txt = ""
  if fileExists(changeLogFile):
   lines  = FFZQjt(changeLogFile)
   for line in lines:
    line = line.strip()
    if line and not line.startswith("#"):
     if line.startswith("[") and line.endswith("]"):
      line = line.replace("[", "").replace("]", "")
      line = FFGB9z("\n%s\n%s\n%s" % (SEP, line, SEP), VVVCGb, VVqFea)
     elif line.strip().startswith("-"): line = "\n" + line
     elif line.strip().startswith(".."): line = FFGB9z(line, VVGb6D, VVqFea)
     txt += line +"\n"
  else:
   txt += "Change Log file not found:\n%s" % changeLogFile
  FF90Bc(self, txt.strip(), title="%s %s  -  %s  - By AMAJamry" % (PLUGIN_NAME, VVLBtR, PLUGIN_DESCRIPTION), VVTFXq=28, width=1600, height=1000, VVzgHY="#11000011")
 def VVs6Lp(self):
  VVZJ87 = []
  VVZJ87.append(("%s Requirements" % PLUGIN_NAME, "libr"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Keys Help"     , "hlp" ))
  FFYySC(self, self.VVWeJE, VVZJ87=VVZJ87, width=650, title="Options")
 def VVWeJE(self, item=None):
  if item:
   if   item == "libr" : FFJsIX(self, BF(self.VVk7V5))
   elif item == "hlp" : FFqsYG(self, "_help_main", "Main Page (Keys Help)")
 def VVrJjZ(self) : self.session.open(CCcHsQ)
 def VVnuPE(self) : self.session.open(CCcK2w)
 def VVZIeE(self):
  title = "Colors and Fonts"
  c1, c2, c3, c4 = VVkIQ9, VVLbyB, VVUVAI, VVMrXw
  VVZJ87 = []
  VVZJ87.append((c1 + "Change Title Colors"   , "title"  ))
  VVZJ87.append((c1 + "Change Menu Area Colors"  , "body"  ))
  VVZJ87.append((c1 + "Change Menu Pointer Colors" , "cursor"  ))
  VVZJ87.append((c1 + "Change Bottom Bar Colors" , "bar"   ))
  VVZJ87.append((c2 + "Reset Colors"    , "resetColor" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c3 + "Change %s Font" % PLUGIN_NAME, "mainFont" ))
  VVZJ87.append((c3 + "Change Termianl Font"   , "termFont" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c4 + "Change System Font"    , "sysFont"  ))
  FFYySC(self, BF(self.VVT0CN, title), VVZJ87=VVZJ87, width=600, title=title)
 def VVT0CN(self, title, item=None):
  if item:
   if item in ("title", "body", "cursor", "bar"):
    tDict = self.VVmSiC()
    fg = tDict.get("main_%s_fg" % item, "")
    bg = tDict.get("main_%s_bg" % item, "")
    self.session.openWithCallback(BF(self.VVcI99, tDict, item), CCrMdZ, defFG=fg, defBG=bg)
   elif item == "resetColor" : FFNKVM(self, self.VVGnro, "Reset to default colors ?", title=title)
   elif item == "mainFont"  : self.VVlP0s(VVn0Sb  )
   elif item == "termFont"  : self.VVlP0s(VVGtks)
   elif item == "sysFont"  : self.VVlP0s(VV4JdF  )
 def VVk7V5(self):
  title = "%s requirements (for some features)" % PLUGIN_NAME
  VVX3wb, pkgs = self.VVdujg()
  VVX66G = ("Install", BF(self.VVOyCq, title, pkgs)  , [])
  VVFadD  = ("Update Sys. Packages", self.VVPueS , [])
  header  = ("Library", "State", "Usage" )
  widths  = (20   , 25  , 55  )
  VVFvCJ = (LEFT  , CENTER , LEFT  )
  VVxBfP = FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=28, width=1350, VVX66G=VVX66G, VVFadD=VVFadD, VVqSOL="#00ffffaa", VVqDAH=1)
 def VVOyCq(self, Title, pkgs, VVxBfP, title, txt, colList):
  if "Not" in colList[1]:
   cbFnc = BF(self.VVw6VH, VVxBfP)
   item = colList[0]
   if   item == "requests" : CC2hCu.VViy1e(self, cbFnc=cbFnc)
   elif item == "Imaging" : CCMSfE.VVftxD(self, Title, False, cbFnc=cbFnc)
   elif item == "ar"  : FF1Q61(self, FFcMGy(), VVYxQ2=cbFnc)
   elif item in pkgs  : FF1Q61(self, FF09Tg(item, item, item.capitalize()), VVYxQ2=cbFnc)
  else:
   FF5uKN(VVxBfP, "Already installed.", 700, isGrn=True)
 def VVPueS(self, VVxBfP, title, txt, colList):
  CCXYqv.VVCAeb(self)
 def VVw6VH(self, VVxBfP):
  VVX3wb, pkgs = self.VVdujg()
  VVxBfP.VVBaiu(VVX3wb[VVxBfP.VVgu5W()])
 def VVdujg(self):
  tDict = {}
  path = VVrrZu + "_sup_lib"
  if fileExists(path):
   for line in FFZQjt(path):
    lib, eq, txt = line.partition("=")
    tDict[lib] = txt
  def VVYPGf(lib, ok):
   txt = tDict.get(lib, "")
   if ok: return (lib, FFGB9z("Installed", VVVjNM), txt)
   else : return (lib, FFGB9z("Not installed", VVGe5h), txt)
  pkgs = ("xz", "zip", "unrar", "bzip2", "ffmpeg")
  VVX3wb = []
  VVX3wb.append(VVYPGf("requests", CC2hCu.VViy1e(self, install=False)))
  VVX3wb.append(VVYPGf("Imaging" , CCMSfE.VVftxD(self, "", False, install=False)))
  VVX3wb.append(VVYPGf("ar"   , FFuB0V("if [[ \"$(ar -V 2> /dev/null | grep 'GNU ar')\" ]]; then exit 0; else exit 1; fi")))
  for item in pkgs: VVX3wb.append(VVYPGf(item, FFhcfU(item)))
  VVX3wb.sort(key=lambda x: x[0].lower())
  return VVX3wb, pkgs
 def VVZFa0(self):
  return VVNemM + "ajpanel_colors"
 def VVmSiC(self):
  tDict = { "main_title_fg" : ""
    , "main_title_bg" : ""
    , "main_body_fg" : ""
    , "main_body_bg" : ""
    , "main_cursor_fg" : ""
    , "main_cursor_bg" : ""
    , "main_bar_fg"  : ""
    , "main_bar_bg"  : ""
    }
  p = self.VVZFa0()
  if fileExists(p):
   txt = FFQ5la(p)
   lst = iFindall(r"(.*[^\s])\s*=\s*(#(?:[A-Fa-f0-9]{8}))", txt, IGNORECASE)
   for txt, c in lst:
    tDict[txt] = c
  return tDict
 def VVcI99(self, tDict, item, fg, bg):
  if fg:
   self.VVHYsW(item, fg)
   self.VVurOj(item, bg)
   tDict["main_%s_fg" % item] = fg
   tDict["main_%s_bg" % item] = bg
   self.VVIT9L(tDict)
 def VVIT9L(self, tDict):
   p = self.VVZFa0()
   with open(p, "w") as f:
    for key, val in tDict.items():
     f.write("%s=%s\n" % (key, val))
 def VVHYsW(self, item, fg):
  if   item == "title" : FFHNWi(self["myTitle"], fg)
  elif item == "body"  :
   FFHNWi(self["myMenu"], fg)
   FFHNWi(self["myBody"], fg)
  elif item == "cursor" : self["myMenu"].instance.setForegroundColorSelected(parseColor(fg))
  elif item == "bar"  :
   for item in ("myBar", "keyRed", "keyGreen", "keyYellow", "keyBlue"): FFHNWi(self[item], fg)
 def VVurOj(self, item, bg):
  if   item == "title" : FFWN9Z(self["myTitle"], bg)
  elif item == "body"  :
   FFWN9Z(self["myMenu"], bg)
   FFWN9Z(self["myBody"], bg)
  elif item == "cursor" : self["myMenu"].instance.setBackgroundColorSelected(parseColor(bg))
  elif item == "bar"  : FFWN9Z(self["myBar"], bg)
 def VVGnro(self):
  FFuB0V("rm '%s'" % self.VVZFa0())
  self.close()
 def VVYq6l(self):
  tDict = self.VVmSiC()
  for item in ("title", "body", "cursor", "bar"):
   self.VVHQxs(tDict, item)
 def VVHQxs(self, tDict, name):
  fg = tDict.get("main_%s_fg" % name, "")
  bg = tDict.get("main_%s_bg" % name, "")
  if fg: self.VVHYsW(name, fg)
  if bg: self.VVurOj(name, bg)
 def VVlP0s(self, which):
  if   which == VVn0Sb  : rest, defFnt, title = False, CFG.fontPathMain.getValue(), PLUGIN_NAME
  elif which == VVGtks : rest, defFnt, title = False, CFG.fontPathTerm.getValue(), "Terminal "
  elif which == VV4JdF  : rest, defFnt, title = True , CFG.fontPathSys.getValue() , "System"
  CC4tie.VVV42N(self, "Change %s Font" % title, defFnt, rest, BF(self.VVw2it, which))
 def VVw2it(self, which, path=None):
  if path:
   path = "" if path == "DEFAULT" else path
   if   which == VVn0Sb  : FFdEZ4(CFG.fontPathMain, path)
   elif which == VVGtks: FFdEZ4(CFG.fontPathTerm, path)
   elif which == VV4JdF  : FFdEZ4(CFG.fontPathSys , path)
   err = Main_Menu.VVq9lG(which)
   if err          : FFw5OO(self, err, title=title)
   elif which == VVn0Sb   : self.close()
   elif which == VVGtks  : FF5uKN(self, "Terminal font applied", 1500, isGrn=True)
   elif which == VV4JdF and path: FF5uKN(self, "System font applied", 1500, isGrn=True)
   elif which == VV4JdF   : FFNKVM(self, BF(Main_Menu.VVWnWi, self), "Font changed (will take effect after GUI Restart).\n\nRestart GUI ?", title="Reset font to default")
 @staticmethod
 def VVWnWi(SELF):
  from Screens.Standby import TryQuitMainloop
  SELF.session.open(TryQuitMainloop, 3)
 @staticmethod
 def VVq9lG(name):
  if   name == VVn0Sb : path, repl = CFG.fontPathMain.getValue(), 0
  elif name == VVGtks: path, repl = CFG.fontPathTerm.getValue(), 0
  elif name == VV4JdF : path, repl = CFG.fontPathSys.getValue() , 1
  if not path:
   FFfSz6()
   return ""
  elif not fileExists(path):
   return "Font file not found"
  nameLst = []
  if name == VV4JdF:
   nameLst = []
   for nm in FFfSz6():
    if not nm in (VVn0Sb, VVGtks):
     nameLst.append(nm)
  else:
   nameLst = [name]
  totDone = 0
  for fntName in nameLst:
   if FFJ9zu(path, fntName, isRepl=repl):
    totDone += 1
  if totDone > 0: FFfSz6()
  else    : return "Could not add font"
 def VVscj7(self):
  CCb9j4.VV6JFp(self.session)
class CCgtPP(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 800, 950, 40, 50, 30, "#22300030", "#0a202020", 33)
  self.session  = session
  self.netEntryFile = "%s%s" % (VVNemM, "ajpanel_network")
  c1, c2 = VVUVAI, VVkIQ9
  VVZJ87 = []
  VVZJ87.append((c1 + "Network Devices"     , "dev" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Network Scanner (ping)"    , "ping"))
  VVZJ87.append(("Port Scanner (scan for famous ports)" , "port"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c2 + "Check Internet Connection"  , "intr"))
  FFmmH7(self, title="Network Tools", VVZJ87=VVZJ87)
  FFmmH7(self, VVZJ87=VVZJ87)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if   item == "dev" : FFJsIX(self, self.VVy23Q, title="REading Devices ...")
  elif item == "ping" : FFJsIX(self, self.VVjJZI, title="Scanning ...")
  elif item == "port" : CC66h0.VVdDGl(self, self.VVpjb9, title="Select host to scan")
  elif item == "intr" : self.session.open(CCWSaK)
 def VVy23Q(self, canCencel=False):
  title = "Network Devices"
  VVX3wb = self.VVSZjb()
  if VVX3wb:
   bg = "#0a223333"
   VVX3wb.sort(key=lambda x: x[0].lower())
   VV0xpR = BF(self.VVORvd, canCencel)
   VVwmV1  = ("Start FTP"   , self.VVzsnM    , [])
   VVIrDY = ("Entry Options"  , self.VVjpCU  , [])
   VVFadD = ("Scan for Devices" , self.VV4jE3 , [])
   header  = ("Num" , "IP-Address", "Username", "Password", "Default Path", "Remarks" )
   widths  = (7  , 25   , 19  , 19  , 0.01   , 30  )
   VVFvCJ = (CENTER , LEFT   , LEFT  , LEFT  , LEFT   , LEFT  )
   VVxBfP = FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, width=1500, height=900, VVhAo0=widths, VVTFXq=28, VVwmV1=VVwmV1, VV0xpR=VV0xpR, VVIrDY=VVIrDY, VVFadD=VVFadD
       , VVDlGi=bg, VVaSSM=bg, VVzgHY=bg, VVqSOL="#11ffff00", VVkUYa="#11220000", VVivoO="#00333333", VVdjpa="#11400040")
   ndx = CFG.lastNetworkDevice.getValue()
   if isinstance(ndx, int):
    VVxBfP.VVYNxS(ndx)
  else:
   FFNKVM(self, BF(FFJsIX, self, BF(self.VVgTqk, canCencel=canCencel), title="Scanning ..."), "No devices found !\n\nScan network ?", callBack_No=BF(self.VVORvd, canCencel), title=title)
 def VVjpCU(self, VVxBfP, title, txt, colList):
  VVZJ87 = []
  VVZJ87.append(("Change Username"   , "user"))
  VVZJ87.append(("Change Password"   , "pass"))
  VVZJ87.append(("Change Remarks"   , "rem"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Remove Selected Server" , "del"))
  FFYySC(self, BF(self.VVKd1x, VVxBfP), VVZJ87=VVZJ87, title="Entry Options")
 def VVKd1x(self, VVxBfP, item=None):
  if item:
   if   item == "user" : self.VVHpa1("u", VVxBfP)
   elif item == "pass" : self.VVHpa1("p", VVxBfP)
   elif item == "rem" : self.VVHpa1("r", VVxBfP)
   elif item == "del" : FFNKVM(self, BF(FFJsIX, self, BF(self.VVaKuY, VVxBfP), title="Deleting ..."), "Continue ?", title="Delete Entry")
 def VVORvd(self, canCencel, VVxBfP=None):
  if VVxBfP: VVxBfP.cancel()
  if canCencel : self.close()
 def VVzsnM(self, VVxBfP, title, txt, colList):
  num, ip, u, p, path, rem = colList
  entry = (ip, u, p, path, rem)
  FFdEZ4(CFG.lastNetworkDevice, VVxBfP.VVgu5W())
  self.session.openWithCallback(BF(self.VV3HSK, entry, VVxBfP), CChv5h, entry)
 def VV3HSK(self, entry, VVxBfP, newPath=None):
  if newPath:
   ip, u, p, path, rem = entry
   if path != newPath:
    self.VVKdXi("d", newPath, ip, u, p, path, rem)
    self.VVGXd7(VVxBfP)
 def VV4jE3(self, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VVgTqk, mainTableInst=VVxBfP), title="Scanning Network ...")
 def VVgTqk(self, canCencel=False, mainTableInst=None):
  title = "Network Devices"
  ftpLst, err = CC66h0.VV4EuU(CC66h0.VVN0b6)
  if err:
   FFw5OO(self, err, title=title)
   return
  telLst, err = CC66h0.VV4EuU(CC66h0.VV66hV)
  if err:
   FFw5OO(self, err, title=title)
   return
  tLst = list(set(ftpLst + telLst))
  lst = []
  for item in tLst:
   typ = []
   if item in ftpLst: typ.append("FTP")
   if item in telLst: typ.append("Telnet")
   lst.append((item[0], item[1], " / ".join(typ)))
  ftpLst = telLst = tLst = None
  if lst:
   def VViHW8(p1, p2): return FFAyBN(p1[0], p2[0])
   lst.sort(key=FFDgxV(VViHW8))
   bg = "#0a202020"
   VV0xpR = BF(self.VVORvd, canCencel)
   VVwmV1  = ("Add to Devices" , BF(self.VVRl4p, mainTableInst, canCencel) , [])
   header  = ("IP-Address" , "MAC-Address" , "Open Ports" )
   widths  = (40   , 34   , 26   )
   VVFvCJ = (LEFT   , CENTER   , CENTER  )
   FF1Dpj(self, None, title=title, header=header, VVarfR=lst, VVFvCJ=VVFvCJ, VVhAo0=widths, width=1200, VVTFXq=30, VVwmV1=VVwmV1, VV0xpR=VV0xpR, VVqDAH=2
     , VVDlGi=bg, VVaSSM=bg, VVzgHY=bg, VVkUYa="#0a225555", VVdjpa="#11403040")
  else:
   FFw5OO(self, "No devices found !", title=title)
 def VVjJZI(self):
  title = 'Hosts that responded to "ping"'
  lst, err = CC66h0.VV4EuU(-1)
  if err:
   FFw5OO(self, err, title=title)
  elif lst:
   def VViHW8(p1, p2): return FFAyBN(p1[0], p2[0])
   lst.sort(key=FFDgxV(VViHW8))
   bg = "#0a202020"
   header  = ("IP-Address" , "MAC-Address" )
   widths  = (50   , 50   )
   VVFvCJ = (LEFT   , LEFT   )
   FF1Dpj(self, None, title=title, header=header, VVarfR=lst, VVFvCJ=VVFvCJ, VVhAo0=widths, width=1000, height=700, VVTFXq=30
     , VVDlGi=bg, VVaSSM=bg, VVzgHY=bg, VVkUYa="#0a225555", VVdjpa="#11403040")
  else:
   FFw5OO(self, "Network scanning failed !", title=title)
 def VVpjb9(self, ip=None):
  if ip:
   FFJsIX(self, BF(self.VVYJ2U, ip), title="Scanning %s" % ip)
 def VVYJ2U(self, ip):
  dct = {20: "FTP Data Transfer", 21: "FTP Control", 22: "SSH", 23: "Telnet", 25: "SMTP (eMail)", 80: "HTTP", 443: "HTTPS"}
  txt  = "IP:\n   %s\n\n" % ip
  txt += "Ping Result:\n   %s\n\n" % ("OK" if CC66h0.VVCKfw(ip) else "Failed")
  txt += "Available Ports:\n"
  ports = ""
  for port, subj in dct.items():
   ok = CC66h0.VVbXCM(ip, port, timeout=0.5)
   if ok:
    ports += "   %d : %s\n" % (port, subj)
  FF90Bc(self, txt + (ports or "   None"), title="Scanned ports : %s" % str(list(dct)).strip("[]"))
 def VVSZjb(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFQ5la(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VViHW8(p1, p2): return FFAyBN(p1[0], p2[0])
  tLst.sort(key=FFDgxV(VViHW8))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVSZjb(self):
  tLst = []
  if fileExists(self.netEntryFile):
   txt = FFQ5la(self.netEntryFile)
   data = iFindall(r"host\s*=(.+),\s*user\s*=(.+),\s*pass\s*=(.*),\s*path\s*=(.*),\s*rem\s*=(.*)", txt, IGNORECASE)
   for ip, u, p, path, rem in data:
    ip, u, p, path, rem = ip.strip(), u.strip(), p.strip(), path.strip() or "/", rem.strip()
    tLst.append((ip, u, p, path, rem))
  def VViHW8(p1, p2): return FFAyBN(p1[0], p2[0])
  tLst.sort(key=FFDgxV(VViHW8))
  lst = []
  for num1, item in enumerate(tLst, start=1):
   ip, u, p, path, rem = item
   lst.append((str(num1), ip, u, p, path, rem))
  return lst
 def VVRl4p(self, mainTableInst, canCencel, VVxBfP, title, txt, colList):
  ip, mac, typ = VVxBfP.VVzNXU(VVxBfP.VVgu5W())
  if "Own" in ip:
   FF5uKN(VVxBfP, "Cannot add your device", 1500)
  else:
   gw = "Gateway"
   if gw in ip : ip, u, p, path, rem = ip.split()[0].strip(), "admin", "123456", "/", gw
   else  : ip, u, p, path, rem = ip, "root", "dreambox", "/", "No-name"
   for entry in self.VVSZjb():
    num1, ip1, u1, p1, path1, rem1 = entry
    if (ip, u, p, path, rem) == (ip1, u1, p1, path1, rem1):
     break
   else:
    if fileExists(self.netEntryFile):
     FFA11O(self.netEntryFile)
    with open(self.netEntryFile, "a") as f:
     f.write(self.VV2gTL(ip, u, p, path, rem))
   if mainTableInst: self.VVGXd7(mainTableInst, [ip, u, p, path, rem])
   else   : self.VVy23Q(canCencel)
   VVxBfP.cancel()
 def VV2gTL(self, ip, u, p, path, rem):
  return "host=%s,user=%s,pass=%s,path=%s,rem=%s\n" % (ip, u, p, path, rem)
 def VVaKuY(self, VVxBfP):
  num, ip, u, p, path, rem = VVxBfP.VVzNXU(VVxBfP.VVgu5W())
  lst = self.VVSZjb()
  tot = 0
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if not (ip1, u1, p1, path1, rem1) == (ip, u, p, path, rem):
     f.write(self.VV2gTL(ip1, u1, p1, path1, rem1))
     tot += 1
  if tot:
   self.VVGXd7(VVxBfP)
  else:
   VVxBfP.cancel()
 def VVHpa1(self, col, VVxBfP):
  num, ip, u, p, path, rem = VVxBfP.VVzNXU(VVxBfP.VVgu5W())
  if   col == "u": orig, subj = u  , "User"
  elif col == "p": orig, subj = p  , "Password"
  elif col == "r": orig, subj = rem, "Remarks"
  FFaSvq(self, BF(self.VVsY9i, col, orig, VVxBfP, num, ip, u, p, path, rem), defaultText=orig, title="Change %s" % subj, message="Enter %s:" % subj)
 def VVsY9i(self, col, orig, VVxBfP, num, ip, u, p, path, rem, newTxt):
  if not newTxt == None:
   newTxt = newTxt.strip()
   if orig == newTxt:
    FF5uKN(VVxBfP, "No change", 1500)
   elif not newTxt and col == "u":
    FF5uKN(VVxBfP, "No user !", 2000)
   else:
    self.VVKdXi(col, newTxt, ip, u, p, path, rem)
    self.VVGXd7(VVxBfP)
 def VVKdXi(self, col, newTxt, ip, u, p, path, rem):
  lst = self.VVSZjb()
  oldItem = (ip, u, p, path, rem)
  with open(self.netEntryFile, "w") as f:
   for item in lst:
    num1, ip1, u1, p1, path1, rem1 = item
    if (ip1, u1, p1, path1, rem1) == oldItem:
     if   col == "u": u1  = newTxt
     elif col == "p": p1  = newTxt
     elif col == "d": path1 = newTxt
     elif col == "r": rem1 = newTxt
    f.write(self.VV2gTL(ip1, u1, p1, path1, rem1))
 def VVGXd7(self, VVxBfP, newEntry=None):
  VVX3wb = self.VVSZjb()
  if VVX3wb : VVxBfP.VVcckS(VVX3wb, tableRefreshCB=BF(self.VVSTLU, newEntry))
  else  : VVxBfP.cancel()
 def VVSTLU(self, newEntry, VVxBfP, title, txt, colList):
  if newEntry:
   for ndx, row in enumerate(VVxBfP.VVlHja()):
    if row[1:] == newEntry:
     VVxBfP.VVYNxS(ndx)
 def VVORvd(self, canCencel, VVxBfP=None):
  if VVxBfP: VVxBfP.cancel()
  if canCencel : self.close()
class CC66h0():
 VVN0b6 = 21
 VV66hV = 23
 def __init__(self):
  self.VVjVc2()
 def VVjVc2(self):
  self.ftp  = None
  self.ftpIp  = ""
  self.ftpUser = ""
  self.ftpPass = ""
  self.ftpSys  = ""
 def VVI43e(self, ip, User, Pass, timeout=5):
  myIp = CC66h0.VV9k4t()
  if ip != myIp:
   if CC66h0.VVbXCM(ip, CC66h0.VVN0b6):
    self.VVjVc2()
    err = ""
    try:
     from ftplib import FTP
     self.ftp  = FTP(ip, user=User, passwd=Pass, timeout=timeout)
     self.ftp.set_pasv(False)
     self.ftpIp  = ip
     self.ftpUser = User
     self.ftpPass = Pass
    except Exception as e:
     err = str(e)
   else:
    err = "Connection timed out !\n\n%s" % ip
  else:
   err = "Cannot FTP to your Device-IP:\n\n%s" % ip
  return err
 def VVGz5D(self):
  try: return self.ftp.sendcmd("SYST")
  except: return ""
 def VVIj4l(self):
  try: return self.ftp.sendcmd("NOOP")
  except: return ""
 def VVxkyS(self, timeout=3):
  t1 = iTime()
  while True:
   state = self.VVIj4l()
   if not state or state == "200 OK" or iTime() - t1 >= timeout:
    break
 def VVpf1R(self):
  try: return self.ftp.sendcmd("STAT")
  except: return ""
 def VV8PpI(self, Dir, isLong=False):
  files, err = [], ""
  if self.ftp and self.VVkYHl(Dir):
   try:
    if isLong: self.ftp.dir(files.append)
    else  : self.ftp.nlst()
   except Exception as e:
    err = str(e)
  else:
   err = "No FTP Connection !"
  return files, err
 def VVEpRz(self):
  try: return self.ftp.pwd()
  except: return ""
 def VV20pj(self, path):
  try:
   size = self.ftp.sendcmd("SIZE %s" % path)
   return "f"
  except:
   curDir = self.VVEpRz()
   if self.VVkYHl(path) : typ = "d"
   else      : typ = "b"
   self.VVkYHl(curDir)
   return typ
 def VVp7Ou(self, path):
  try: return self.ftp.size(path)
  except: return -1
 def VVkYHl(self, path):
  try:
   self.ftp.cwd(path)
   return True
  except:
   return False
 def VVCyUl(self, path):
  try:
   self.ftp.mkd(path)
   return True
  except:
   return False
 def VVRHr2(self, path, flag):
  try:
   if flag == "d" : self.ftp.rmd(path)
   else   : self.ftp.delete(path)
   return True
  except:
   return False
 def VVdD9z(self, fromN, toN):
  try:
   self.ftp.rename(fromN, toN)
   return True
  except:
   return False
 def VVwI1D(self, remFile, locFile="", maxSz=10000000):
  sz = self.VVp7Ou(remFile)
  if   sz == -1 : return "", sz, "Cannot read file size."
  elif sz > maxSz : return "", sz, "File too big."
  else   : err= ""
  locFile = locFile or "/tmp/%s" % os.path.basename(remFile)
  try:
   self.ftp.retrbinary("RETR %s" % remFile, open(locFile, "wb").write)
   if fileExists(locFile) : return locFile, sz, ""
   else     : return "", sz, "Download Failed."
  except Exception as e:
   FFzyFM(locFile)
   return "", sz, str(e)
 def VVGgdn(self):
  if self.ftp:
   try: self.ftp.quit()
   except: pass
  self.VVjVc2()
 @staticmethod
 def VVsJxP():
  from uuid import getnode
  return ':'.join(iFindall('..', '%012x' % getnode())).upper()
 @staticmethod
 def VV9k4t():
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_DGRAM
  try:
   setdefaulttimeout(1)
   s = socket(AF_INET, SOCK_DGRAM)
   s.connect(("1.1.1.1", 80))
   ip = s.getsockname()[0]
   s.close()
   return ip
  except:
   return ""
 @staticmethod
 def VVhOFo():
  myIp = CC66h0.VV9k4t()
  if myIp.count(".") == 3:
   parts = myIp.split('.')
   return ".".join(parts[:3]) + "."
  return ""
 @staticmethod
 def VVdvMI():
  span = iSearch(r"((?:\d+.){3}\.\d+)", FF3RLi("ip route | grep default"), IGNORECASE)
  return span.group(1) if span else ""
 @staticmethod
 def VVC9G2(port=-1):
  lst = []
  def VVzU5F(ip):
   if port > -1: ok = CC66h0.VVbXCM(ip, port)
   else  : ok = CC66h0.VVCKfw(ip)
   if ok:
    lst.append(ip)
  try:
   baseIp = CC66h0.VVhOFo()
   thLst  = []
   for num in range(1, 255):
    ip = "%s%d" % (baseIp, num)
    th = iThread(name="ajp_scanIp%d" % num, target=BF(VVzU5F, ip))
    th.start()
    thLst.append(th)
   for th in thLst: th.join()
   return lst, ""
  except Exception as e:
   err = str(e)
   return [], err + '\n\nMax Threads = %d\nCheck your system "Max User Processes" with "ulimit -u"' % len(thLst) if "can't start new thread" in err else ""
 @staticmethod
 def VV4EuU(port):
  myIp = CC66h0.VV9k4t()
  myGw = CC66h0.VVdvMI()
  tDict = { myIp: CC66h0.VVsJxP() }
  devLst, err = CC66h0.VVC9G2(port)
  if err:
   return [], err
  else:
   for ip in devLst:
    span = iSearch(r"((?:\d+.){3}\.\d+).+\s+((?:[a-f\d]{2}:){5}[a-f\d]{2})", FF5IiQ("arp -n %s" % ip), IGNORECASE)
    if span    : tDict[ip] = span.group(2).upper()
    elif not ip == myIp : tDict[ip] = ""
   lst = []
   for key, val in tDict.items():
    if   key == myIp: txt = " %s Own" % VVUVAI
    elif key == myGw: txt = " %s Gateway" % VVUVAI
    else   : txt = ""
    lst.append((key + txt, val))
   return lst, ""
 @staticmethod
 def VVCKfw(ip):
  return FFuB0V("ping -W1 -q -c1 %s" % ip)
 @staticmethod
 def VVbXCM(host, port, timeout=1.0):
  from socket import socket, setdefaulttimeout, AF_INET, SOCK_STREAM
  setdefaulttimeout(timeout)
  try:
   socket(AF_INET, SOCK_STREAM).connect((host, port))
   return True
  except:
   return False
 @staticmethod
 def VVP0Wq(ip="1.1.1.1", timeout=1):
  if CC66h0.VVbXCM(ip, 53, timeout):
   return True
  if CC66h0.VVCKfw(ip):
   return True
  return FFuB0V("wget -q -T %d -t 1 --spider %s" % (timeout, ip))
 @staticmethod
 def VVdDGl(SELF, okFnc, title):
  baseIp = CC66h0.VVhOFo()
  lst = []
  for num in range(1, 255):
   item = "%s%d" % (baseIp, num)
   lst.append((item, item))
  FFYySC(SELF, okFnc, VVZJ87=lst, width=600, title=title, VVDlGi="#222222", VVaSSM="#222222")
class CChv5h(Screen, CC66h0):
 def __init__(self, session, entry):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 1400, 920, 40, 50, 30, "#11333344", "#08303030", 30, barHeight=40, topRightBtns=2)
  self.session  = session
  self.ftpEntry  = entry
  self.VVTFXq  = self.skinParam["bodyFontSize"]
  self.VVNyBH  = self.skinParam["bodyLineH"]
  self.VVx14V  = self.skinParam["width"]
  self.curDir   = "/"
  self.list   = []
  self.png_fil  = CCA8jA.VV4Yr5("fil")
  self.png_dir  = CCA8jA.VV4Yr5("dir")
  self.png_dirup  = CCA8jA.VV4Yr5("dirup")
  self.png_slwfil  = CCA8jA.VV4Yr5("slwfil")
  self.png_slbfil  = CCA8jA.VV4Yr5("slbfil")
  self.png_slwdir  = CCA8jA.VV4Yr5("slwdir")
  self.serverOrigData = None
  self.Title   = "FTP (%s)" % entry[0]
  CC66h0.__init__(self)
  VVZJ87 = [("Item-%d" % x,) for x in range(50)]
  FFmmH7(self, title=self.Title, VVZJ87=VVZJ87)
  FFR9Qm(self["keyRed"] , "Exit")
  self["myMenu"] = MenuList(VVZJ87, True, eListboxPythonMultiContent)
  self["myMenu"].l.setFont(0, gFont(VVR8AG, self.VVTFXq))
  self["myMenu"].l.setItemHeight(self.VVNyBH)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : BF(self.VVunSf, True) ,
   "ok" : self.VVxCTS    ,
   "cancel": self.VVunSf    ,
   "menu" : self.VVepbP   ,
   "info" : self.VVDx1k  ,
   "pageUp": self.VVifBm    ,
   "chanUp": self.VVifBm
  })
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VVjGbj)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
  FFHLqT(self)
  FFj9eW(self)
  FFWN9Z(self["keyBlue"], "#11333333")
  FFJsIX(self, self.VVq1SA, title="Connecting ...")
 def VVq1SA(self):
  ip, u, p, path, rem = self.ftpEntry
  err = self.VVI43e(ip, u, p)
  if err:
   FFw5OO(self, err, title=self.Title)
   FFR9Qm(self["keyBlue"] , "")
   self.close()
  elif self.ftp:
   FFR9Qm(self["keyBlue"], self.ftpIp)
   if not self.VVkYHl(path):
    path = "/"
   self.VVNdg1(path)
   self.serverOrigData = (ip, u, p, path, rem)
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  if self.VVIj4l():
   self.VVGgdn()
 def VVxCTS(self):
  if self.VVpRLg():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    if   flag == "d" or targetState == "d" : self.VVNdg1(os.path.join(self.curDir, name))
    elif flag == "x"      : self.VVifBm()
    else         : self.VVdDLs(os.path.join(self.curDir, name))
 def VVunSf(self, force=False):
  if force or CFG.FileManagerExit.getValue() == "e": self.close(self.curDir)
  else            : self.VVifBm()
 def VVpRLg(self):
  if self.VVIj4l():
   return True
  else:
   FFw5OO(self, "FTP Server is now diconnected !", title=self.Title)
   return False
 def VVdDLs(self, path):
  cat = self.VV4oxd(path)
  if cat in ("pic"):
   FFJsIX(self, BF(self.VVff7R, path))
  elif cat in ("mov", "mus"):
   if CC9X9s.VVXe1d("5002"):
    url = "ftp%%3a//%s%%3a%s@%s%s" % (self.ftpUser, self.ftpPass, self.ftpIp, path)
    rType = "5002"
   else:
    rType = CFG.iptvAddToBouquetRefType.getValue()
    url = "http%%3a//%s/file?file=%s" % (self.ftpIp, path)
   FFJsIX(self, BF(CCCXvS.VVDPDb, self, url, rType=rType), title="Playing Media ...")
 def VVff7R(self, path):
  locFile, size, err = self.VVwI1D(path)
  if err: FFw5OO(self, err, title="View Picture File")
  else  : CCo6hs.VVhaNU(self, locFile, fakePath="ftp:/%s" % path, cbFnc=BF(FFzyFM))
 def VVjGbj(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel: title = "  %s  " % os.path.join(self.curDir, "" if sel[0][0] == CCA8jA.VVUfaS else sel[0][0])
  else  : title=  VVGe5h + "  No Files Found !"
  self["myTitle"].setText(title)
 def VVifBm(self):
  if self.VVpRLg():
   lastPart = FF65m2(self.curDir)
   parentDir = os.path.abspath(os.path.join(self.curDir, os.pardir))
   self.VVNdg1(parentDir, lastPart, "d")
 def VVNdg1(self, Dir, moveTo="", moveToType=""):
  FFJsIX(self, BF(self.VV1Xo3, Dir, moveTo, moveToType))
 def VV1Xo3(self, Dir, moveTo, moveToType):
  files, err = self.VV8PpI(Dir, isLong=True)
  self.curDir = self.VVEpRz() or "/"
  self.VV3k0g(files)
  if moveTo:
   for ndx, item in enumerate(self.list):
    name, target, targetState, flag, sortSeq = item[0]
    if moveTo == name:
     if not moveToType or moveToType == flag:
      self["myMenu"].moveToIndex(ndx)
      break
  else:
   self["myMenu"].moveToIndex(0)
 def VV3k0g(self, files):
  self.list = []
  if self.curDir != "/":
   self.list.append(self.VVbIon(CCA8jA.VVUfaS, CCA8jA.VVUfaS, "", "", "x"))
  for item in files:
   linkTo = ""
   isDir = isFile = isLink = False
   item = item.strip()
   if   item.startswith("l")     : flag = "l"
   elif item.startswith("d") or "<DIR>" in item: flag = "d"
   else          : flag = "f"
   gaps = 3 if item[:1].isdigit() else 8
   name = item.split(None, gaps)[gaps]
   linkSep = " -> "
   origName = name
   target = targetState = ""
   if linkSep in name:
    flag = "l"
    name, _, target = name.partition(linkSep)
    if not target.startswith("/"):
     target = "/" + target
    targetState = self.VV20pj(target)
    color = VVGe5h if targetState == "b" else VVVjNM
    origName = name + VVVCGb + linkSep + color + " "+ target
   self.list.append(self.VVbIon(origName, name, target, targetState, flag))
  self.list.sort(key=lambda x: (x[0][4], x[0][0]))
  self["myMenu"].l.setList(self.list)
 def VVbIon(self, origName, name, target, targetState, flag):
  if flag == "f":
   png = self.png_fil
   ext = os.path.splitext(name)[1]
   if ext:
    cat = self.VV4oxd(name)
    if cat: png = LoadPixmap("%s%s.png" % (VVrrZu, cat))
  elif flag == "d": png = self.png_dir
  elif flag == "l":
   if   targetState == "f" : png = self.png_slwfil
   elif targetState == "d" : png = self.png_slwdir
   elif targetState == "b" : png = self.png_slbfil
   else      : png = self.png_slwfil
  elif flag == "x": png = self.png_dirup
  else   : png = self.png_fil
  if   origName == CCA8jA.VVUfaS: sortSeq = 0
  elif flag == "d" or targetState == "d"  : sortSeq = 1
  else          : sortSeq = 2
  tableRow = [ (name, target, targetState, flag, sortSeq) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVNyBH + 10, 0, self.VVx14V, self.VVNyBH, 0, LEFT | RT_VALIGN_CENTER, origName))
  if VVnvLp: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVNyBH-4, self.VVNyBH-4, png, None, None, VVnvLp))
  else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVNyBH-4, self.VVNyBH-4, png, None, None))
  return tableRow
 def VV4oxd(self, path):
  ext = os.path.splitext(path)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in CCA8jA.VV1p4d().items():
    if ext in lst:
     return cat
  return ""
 def VVepbP(self):
  sel = self["myMenu"].l.getCurrentSelection()
  if sel : name, target, targetState, flag, sortSeq = sel[0]
  else : name = target = targetState = flag = ""
  isTop  = name == CCA8jA.VVUfaS
  isDir  = flag == "d" or targetState == "d"
  isFile = flag == "f" or targetState == "f"
  def VVpjmb(titl, ref, chk, color=""):
   if chk: return VVZJ87.append((color + titl, ref))
   else  : return VVZJ87.append((titl, ))
  VVZJ87 = []
  VVpjmb("Properties", "VVDx1k", not isTop)
  c = VVUVAI
  VVZJ87.append(VVoqHH)
  VVpjmb("Download Selected File ..."    , "FFtKyCFromServer", isFile, c)
  VVpjmb("Upload a Local File to Remote Server ...", "VV46Yf" , True  , c)
  VVZJ87.append(VVoqHH)
  VVpjmb("Create new directory", "VV3RYl", True)
  VVpjmb("Rename", "VVooqR", not isTop)
  VVpjmb("DELETE", "VVJcVq", not isTop, VVsObI)
  VVZJ87.append(VVoqHH)
  VVpjmb("FTP Server Information", "VVOYz9", True)
  VVZJ87.append(VVoqHH)
  VVpjmb("Refresh File List", "refresh", True)
  FFYySC(self, self.VVjp7b, VVZJ87=VVZJ87, title="Options")
 def VVjp7b(self, item=None):
  if item:
   if   item == "VVDx1k"     : self.VVDx1k()
   elif item == "FFtKyCFromServer"   : self.FFtKyCFromServer()
   elif item == "VV46Yf"   : self.VV46Yf()
   elif item == "VV3RYl"   : self.VV3RYl()
   elif item == "VVooqR"   : self.VVooqR()
   elif item == "VVJcVq"   : self.VVJcVq()
   elif item == "VVOYz9"    : self.VVOYz9()
   elif item == "refresh"and self.VVpRLg() : self.VVNdg1(self.curDir)
 def VVDx1k(self):
  if self.VVpRLg():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    path = os.path.join(self.curDir, name)
    txt = "%s:\n%s\n\n" % (FFGB9z("Path", VVUVAI), path)
    typ = {"d": "Directory", "f": "File", "l": "SymLink", "x": ""}.get(flag, "")
    if typ: txt += "Type\t: %s%s\n" % (typ, " (Broken)" if targetState == "b" else "")
    if target: txt += "Target\t: %s\n" % target
    sz = self.VVp7Ou(path)
    if sz > -1: txt += "Size\t: %s" % CCCXvS.VVutW7(sz)
   else:
    txt = "Nothing selected"
   FF90Bc(self, txt, title="Properties")
 def VVOYz9(self):
  if self.VVpRLg():
   Sys  = self.VVGz5D() or " -"
   txt = "%s\n  %s\n\n" % (FFGB9z("System:", VVUVAI), Sys[4:] if Sys.startswith("215 ") else Sys)
   Stat = self.VVpf1R() or " -"
   txt += "%s\n" % (FFGB9z("Status:", VVUVAI))
   for line in Stat.splitlines():
    txt += "  %s\n" % (line[4:] if line.startswith("211-") or line.startswith("211 ") else line)
   FF90Bc(self, txt, title="FTP Server Information")
 def VV3RYl(self, name=""):
  if self.VVpRLg():
   title = "Add New Directory"
   FFaSvq(self, BF(self.VVqyqw, title), defaultText=name, title=title, message="Enter Directory name")
 def VVqyqw(self, title, name):
  if name and name.strip():
   if self.VVCyUl(name) : self.VVNdg1(self.curDir, name, "d")
   else     : FFw5OO(self, "Failed to create : %s" % name, title)
 def VVooqR(self):
  if self.VVpRLg():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Rename"
    name, target, targetState, flag, sortSeq = sel[0]
    FFaSvq(self, BF(self.VVQyAu, title, name, flag), defaultText=name, title=title, message="Enter new name")
 def VVQyAu(self, title, name, flag, newName):
  if newName and newName.strip():
   if self.VVdD9z(name, newName.strip()) : self.VVNdg1(self.curDir, newName, flag)
   else          : FFw5OO(self, "Failed to rename to : %s" % newName, title)
 def VVJcVq(self):
  if self.VVpRLg():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    name, target, targetState, flag, sortSeq = sel[0]
    FFNKVM(self, BF(FFJsIX, self, BF(self.VVURIN, name, flag), title="Deleting ..."), "Delete ?\n\n%s" % name, title="Delete")
 def VVURIN(self, name, flag):
  if self.VVRHr2(name, flag) : self.VVNdg1(self.curDir)
  else         : FFw5OO(self, "Failed to delete:\n\n%s" % name, "Delete")
 def FFtKyCFromServer(self):
  if self.VVpRLg():
   sel = self["myMenu"].l.getCurrentSelection()
   if sel:
    title = "Download File"
    name, target, targetState, flag, sortSeq = sel[0]
    remFile = os.path.join(self.curDir, name)
    size = self.VVp7Ou(remFile)
    if size == -1:
     FFw5OO(self, "Cannot get file size for:\n\n%s" % remFile, title=title)
    else:
     Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVNemM
     self.session.openWithCallback(BF(self.VVjjlC, title, remFile, name, size), BF(CCCXvS, mode=CCCXvS.VVutD6, VVDuqR="Download here", VVMbDq=Dir, width=1200, height=840, pickTitleBG="#11002222", pickBodyBG="#11003333", cursorBG="#11005566"))
 def VVjjlC(self, title, remFile, name, size, locPath):
  if locPath:
   FFdEZ4(CFG.lastFtpLocalPath, locPath)
   locFile = os.path.join(locPath, name)
   self.session.open(CCmNws, barTheme=CCmNws.VV3z22, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Downloading ..."
       , fncToRun  = BF(self.VVlRnx, remFile, size, locFile)
       , VVCeou = BF(self.VVeE8m, remFile, size, locFile))
 def VVlRnx(self, remFile, size, locFile, VVXLiB):
  VVXLiB.VVCnyB(size)
  VVXLiB.VVlaij = ""
  with open(locFile, "wb") as locFileObj:
   try:
    def VVPZf7(data):
     if not VVXLiB or VVXLiB.isCancelled:
      return
     locFileObj.write(data)
     VVXLiB.VV1Vtn(len(data))
    self.ftp.retrbinary("RETR %s" % remFile, VVPZf7)
   except Exception as e:
    VVXLiB.VVlaij = str(e)
 def VVeE8m(self, remFile, size, locFile, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  title = "File Download"
  delF = False
  if VVlaij:
   FFw5OO(self, "%s\n\nftp:/%s" % (VVlaij, remFile), title="Download Error")
   delF = True
  elif not VVeObj:
   FFw5OO(self, "Download cancelled for:\n\nftp:/%s" % remFile, title=title)
   delF = True
  else:
   if size == FFqLWj(locFile):
    txt = "Successfully downloaded to:\n\n%s" % locFile
    FF15cM(self, txt, title=title)
   else:
    FFw5OO(self, "Incorrect downloaded file size for:\n\nftp:/%s" % remFile, title=title)
    delF = True
  if delF:
   FFzyFM(locFile)
 def VV46Yf(self):
  if self.VVpRLg():
   Dir = CFG.lastFtpLocalPath.getValue() if pathExists(CFG.lastFtpLocalPath.getValue()) else VVNemM
   self.session.openWithCallback(self.VVtR8N, BF(CCCXvS, VVDuqR="Upload selected file", VVMbDq=Dir, patternMode="all", width=1200, height=850, pickTitleBG="#11001122", pickBodyBG="#11330033", cursorBG="#11662200"))
 def VVtR8N(self, locFile):
  if locFile:
   title = "Upload File to Remote Server"
   FFdEZ4(CFG.lastFtpLocalPath, os.path.dirname(locFile))
   size = FFqLWj(locFile)
   if size == -1:
    FFw5OO(self, "Cannot get file size for:\n\n%s" % locFile, title=title)
   else:
    remFile = os.path.join(self.curDir, os.path.basename(locFile))
    self.session.open(CCmNws, barTheme=CCmNws.VV3z22, titleBg="#22220022", bodyBg="#22220022"
        , titlePrefix = "Uploading ..."
        , fncToRun  = BF(self.VVfCXG, locFile, size, remFile)
        , VVCeou = BF(self.VV93Mc, locFile, size, remFile))
 def VVfCXG(self, locFile, size, remFile, VVXLiB):
  VVXLiB.VVCnyB(size)
  VVXLiB.VVlaij = ""
  with open(locFile, "rb") as locFileObj:
   try:
    def VVYfBa(data):
     if not VVXLiB or VVXLiB.isCancelled:
      VVXLiB.VVlaij = "Upload cancelled"
      locFileObj.close()
      return
     VVXLiB.VV1Vtn(len(data))
    self.ftp.storbinary("STOR %s" % remFile, locFileObj, callback=VVYfBa)
   except Exception as e:
    VVXLiB.VVlaij = VVXLiB.VVlaij or str(e)
 def VV93Mc(self, locFile, size, remFile, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  title = "File Upload"
  err = ""
  if VVeObj:
   if size == FFqLWj(locFile) : FF15cM(self, "Successfully uploaded to:\n\n%s" % remFile, title=title)
   else       : err = "Incorrect uploaded file size for:\n\nftp:/%s" % remFile
  elif VVlaij : err = "%s\n\n%s" % (VVlaij, locFile)
  else    : err = "Incomplete file transfer:\n\n%s" % locFile
  if err:
   FFw5OO(self, err, title=title)
   self.VVxkyS()
   self.VVRHr2(remFile, "")
  self.VVNdg1(self.curDir)
class CCMSfE():
 VV8aau  = "all"
 VVYAcp = "vid"
 VVrLQt  = "osd"
 @staticmethod
 def VVXBwK(session, k):
  if not CFG.screenshotFType.getValue() == "off":
   title = "%s Screenshot" % PLUGIN_NAME
   if FFhcfU("grab"):
    winShown = session.current_dialog.shown
    if k == CCMSfE.VVYAcp and winShown: session.current_dialog.hide()
    FFFANg(BF(CCMSfE.VVMGSl, title, session, k, winShown))
   else:
    FFOsAJ(session, "No Grab command !", title=title)
 @staticmethod
 def VVMGSl(title, session, k, winShown):
  fTitle = skinName = ""
  x = y = w = h = 0
  if k == CCMSfE.VVrLQt:
   if not winShown:
    FFOsAJ(session, "No Window to capture !", title=title)
    return
   if not CCMSfE.VVftxD(session, title, True):
    return
   valid, origTitle, clnTitle, skinName, x, y, w, h = CCMSfE.VVCkFq(session)
   fTitle = "%s_(%s)" % (clnTitle, skinName)
   if not valid:
    FFOsAJ(session, "Cannot get Window Dimensions !", title=title)
    return
  if not fTitle:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(session, isFromSession=True)
   chName = iSub(r"[^A-Za-z0-9]" ,"-" , chName.strip())
   fTitle = chName or refCode.replace(":", "_")
  ext = CFG.screenshotFType.getValue()
  if   ext == "jpg": typ = "-j 100"
  elif ext == "png": typ = "-p"
  else    : typ = ""
  path = "%sscreenshot_%s_%s.%s" % (FF1vNj(CFG.exportedPIconsPath.getValue()), fTitle, FFUD38(), ext)
  res = os.system(FF627U("grab -q -s %s > '%s'" % (typ, path)))
  if k == CCMSfE.VVYAcp and winShown:
   session.current_dialog.show()
  elif k == CCMSfE.VVrLQt:
   ok = CCMSfE.VVMrM5(path, x, y, w, h)
   if not ok:
    FFzyFM(path)
    FFOsAJ(session, "Error while cropping image file !", title=title)
    return
  if res == 0 and fileExists(path): session.open(BF(CCo6hs, title=path, VVbLQv=path))
  else       : FFOsAJ(session, "Error while capturing screen !", title=title)
 @staticmethod
 def VVftxD(SELF, title, isFromExternal, install=True, cbFnc=None):
  try:
   from PIL import Image
   return True
  except:
   if install:
    FFNKVM(SELF, BF(CCMSfE.VVzoCp, SELF, isFromExternal, cbFnc=cbFnc), "Imaging Library is required.\n\nInstall ?", title=title, isFromExternal=isFromExternal)
   return False
 @staticmethod
 def VVzoCp(SELF, isFromExternal, cbFnc=None):
  if pyVersion[0] >= 3: name = "python3-pillow"
  else    : name = "python-imaging"
  if isFromExternal: fnc = BF(FFYLpx, VVYxQ2=cbFnc)
  else    : fnc = BF(FF1Q61 , VVYxQ2=cbFnc)
  fnc(SELF, FFETOG(VV33Lu, name), checkNetAccess=True, title="Installing Imaging Library")
 @staticmethod
 def VVCkFq(session, repl="-"):
  valid = False
  origTitle = clnTitle = skinName = ""
  x = y = w = h = 0
  obj = session.current_dialog
  if obj:
   inst = obj.instance
   skinName = obj.skinName
   if inst:
    origTitle = inst.getTitle()
    pos, size = inst.position(), inst.size()
    x, y, w, h = pos.x(), pos.y(), size.width(), size.height()
    valid = w != 0 and h !=0
    clnTitle = iSub(r"[^A-Za-z0-9]", repl , origTitle.strip())
  return valid, origTitle, clnTitle, skinName, x, y, w, h
 @staticmethod
 def VVMrM5(path, x, y, w, h, scaleToScreen=True):
  try:
   from PIL import Image
   im = Image.open(path)
   x1 = w + x
   y1 = h + y
   if scaleToScreen:
    scrW, scrH = FFwz8B()
    w, h = im.size
    if w != scrW or h != scrH:
     x  = FF6NMP(x , 0, scrW, 0, w)
     y  = FF6NMP(y , 0, scrH, 0, h)
     x1 = FF6NMP(x1, 0, scrW, 0, w)
     y1 = FF6NMP(y1, 0, scrH, 0, h)
   im = im.crop((x, y, x1, y1))
   im.save(path)
   return True
  except:
   return False
 @staticmethod
 def VVhox0(path):
  size = FFqLWj(path)
  sizeTxt = CCCXvS.VVutW7(size) if size > -1 else ""
  try:
   from PIL import Image
   im = Image.open(path)
   form = im.format
   mode = im.mode
   resTxt = "%d x %d" % im.size
  except:
   resTxt = form = mode = ""
  return size, sizeTxt, resTxt, form, mode
class CC4tie(Screen):
 def __init__(self, session, title, fontsList, defFnt, withRestart):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 1400, 1000, 40, 40, 30, "#0a001100", "#10110000", 30, barHeight=220)
  self.session  = session
  self.fontsList  = fontsList
  self.defFnt   = defFnt
  txt = FFGB9z(" (Requires GUI Restart)", VVMrXw) if withRestart else ""
  VVZJ87 = []
  for path in self.fontsList:
   VVZJ87.append((os.path.splitext(os.path.basename(path))[0], path))
  VVZJ87.sort(key=lambda x: x[0].lower())
  VVZJ87.insert(0, VVoqHH)
  VVZJ87.insert(0, ("Reset to Default%s" % txt, "DEFAULT"))
  curIndex = 0
  if self.defFnt:
   for ndx, item in enumerate(VVZJ87):
    if len(item) == 2 and item[1] == self.defFnt:
     VVZJ87[ndx] = (VVVjNM + item[0], item[1])
     curIndex = ndx
     break
  else:
   VVZJ87[curIndex] = (VVVjNM + VVZJ87[curIndex][0], VVZJ87[curIndex][1])
  FFmmH7(self, VVZJ87=VVZJ87, title=title)
  self["myActionMap"].actions.update({"cancel": self.cancel})
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
  self["myMenu"].onSelectionChanged.append(self.VVZuMj)
  self["myBar"].setText(self.VVshbo())
  self["myBar"].instance.setHAlign(1)
  self.VVZuMj()
 def VVxCTS(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVZuMj(self):
  path = self["myMenu"].l.getCurrentSelection()[1]
  if fileExists(path):
   fnt = "AJP_Sample"
   FFJ9zu(path, fnt, isRepl=1)
  else:
   fnt = VVW5nC
  self["myMenu"].instance.setFont(gFont(fnt, self.skinParam["bodyFontSize"]))
  self["myMenu"].instance.invalidate()
  self["myBar"].instance.setFont(gFont(fnt, int(self.skinParam["bodyFontSize"] * 1.3)))
  self["myBar"].instance.invalidate()
 def VVshbo(self):
  txt = ""
  for i in range(65, 91): txt += chr(i)
  txt += "\n"
  for i in range(97, 123): txt += chr(i)
  txt += "  "
  for i in range(48, 58): txt += chr(i)
  txt += "\n"
  txt += u"\u0623\u0628\u062c\u062f \u0647\u0648\u0632 \u062d\u0637\u064a \u0643\u0644\u0645\u0646 \u0633\u0639\u0641\u0635 \u0642\u0631\u0634\u062a \u062b\u062e\u0630 \u0636\u0638\u063a  \u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669"
  return str(txt)
 @staticmethod
 def VVV42N(SELF, title, defFnt, rest, VVCeou):
  fntPath = resolveFilename(SCOPE_FONTS)
  fontsList = FFzSvJ(fntPath, "*.[tToO][tT][fF]")
  if fontsList: SELF.session.openWithCallback(VVCeou, CC4tie, title, fontsList, defFnt, rest)
  else  : FFw5OO(self, "No fonts found in:\n\n%s" % fntPath, title=title)
class CCdjYE(Screen):
 def __init__(self, session, path, VVZJ87, title):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 1700, 1000, 40, 40, 30, "#11001122", "#11002233", 30, menuLabel=50)
  self.session = session
  self.path  = path
  FFmmH7(self, VVZJ87=VVZJ87, title=title)
  self["myLabelFrm"] = Label()
  self["myLabelTit"] = Label("Result Sample")
  self["myLabelTxt"] = Label()
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVxCTS   ,
   "cancel" : self.cancel   ,
   "pageUp" : self.VVr6b9,
   "chanUp" : self.VVr6b9,
   "pageDown" : self.VVqiDF ,
   "chanDown" : self.VVqiDF ,
  }, -1)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
  FFWN9Z(self["myLabelFrm"], "#11110000")
  FFWN9Z(self["myLabelTit"], "#11663322")
  FFWN9Z(self["myLabelTxt"], "#11110000")
  self["myMenu"].onSelectionChanged.append(self.VVLteL)
  self.VVLteL()
 def VVLteL(self):
  if fileExists(self.path): txt = FFQ5la(self.path, maxSize=1000, encLst=[self["myMenu"].l.getCurrentSelection()[1]])
  else     : txt = "Review error !"
  self["myLabelTxt"].setText(txt.strip())
 def VVxCTS(self):
  self["myMenu"].onSelectionChanged = []
  self.close(self["myMenu"].l.getCurrentSelection()[1])
 def cancel(self):
  self["myMenu"].onSelectionChanged = []
  self.close("")
 def VVr6b9(self) : self["myMenu"].moveToIndex(0)
 def VVqiDF(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCqdtK():
 @staticmethod
 def VVLlKS():
  return [None, "utf-8"] + ["iso-8859-%d" % i for i in range(1,17)] + ["windows-125%d" % i for i in range(1,9)]
 @staticmethod
 def VVciDE(SELF):
  import sys, locale
  lst = []
  c1 = "#f#00ffbbff#"
  c2 = "#f#00ffffaa#"
  lst.append(("Language Code"     , locale.getdefaultlocale()[0]  ))
  lst.append(("Default Locale Encoding"  , locale.getdefaultlocale()[1]  ))
  lst.append((c1 + "Preferred Encoding"  , c1 + locale.getpreferredencoding(False)))
  lst.append((c2 + "System Default Encoding" , c2 + sys.getdefaultencoding()  ))
  lst.append((c2 + "Filesystem Encoding"  , c2 + sys.getfilesystemencoding() ))
  c = "#f#11aaffff#"
  for item in locale.setlocale(locale.LC_ALL).split(";"):
   parts = item.split("=")
   if len(parts) == 2:
    lst.append((c + parts[0], c +
    parts[1]))
  FF1Dpj(SELF, None, VVarfR=lst, VVTFXq=30, VVqDAH=1)
 @staticmethod
 def VVAtdG(path, SELF=None):
  for enc in CCqdtK.VVLlKS():
   try:
    with ioOpen(path, "r", encoding=enc) as f:
     for line in f:
      pass
    return enc
   except:
    pass
  if SELF:
   FFw5OO(SELF, "Cannot detect file encoding for:\n\n%s" % path)
  return -1
 @staticmethod
 def VVpAZI(path, enc):
  try:
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     pass
   return True
  except:
   return False
 @staticmethod
 def VVpZ7B(SELF, path, cbFnc, curEnc=VVhRht, title="Select Encoding"):
  lst = CCqdtK.VV5WsH(SELF, path, "")
  if lst:
   SELF.session.openWithCallback(cbFnc, CCdjYE, path, lst, title)
 @staticmethod
 def VV56Pf(SELF, cbFnc, curEnc=VVhRht, title="Select Encoding"):
  lst = CCqdtK.VV5WsH(SELF, "", "")
  if lst:
   FFYySC(SELF, cbFnc, title=title, VVZJ87=lst, width=1000, height=1000, VVDlGi="#22220000", VVaSSM="#22220000", VV18hv=True)
 @staticmethod
 def VV5WsH(SELF, path, curEnc):
  lst = CCqdtK.VVvTTE(path)
  if lst:
   VVZJ87 = []
   for name, enc in lst:
    txt = "%s (%s)" % (name, enc)
    if   enc == curEnc   : c = VVVjNM
    elif enc == VVhRht: c = VVVCGb
    else      : c = ""
    VVZJ87.append((c + txt, enc))
   return VVZJ87
  else:
   FFzLBa(SELF, "No proper encoding", 2000)
 @staticmethod
 def VVvTTE(path=""):
  encLst = []
  cPath = VVrrZu + "_sup_codecs"
  if fileExists(cPath):
   lines = FFZQjt(cPath)
   for line in lines:
    parts = line.split("\t")
    if len(parts) == 2:
     encLst.append((parts))
  if not encLst:
   tmp = list(CCqdtK.VVLlKS())
   tmp.pop(0)
   encLst = [("General", ",".join(tmp))]
  lst = []
  for item in encLst:
   for enc in (item[1].split(",")):
    if path:
     try:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        pass
      lst.append((item[0], enc))
     except:
      pass
    else:
     lst.append((item[0], enc))
  return lst
class CCcK2w(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 900, 950, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVZJ87 = []
  VVZJ87.append(("Settings File"   , "SettingsFile"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Box Info"     , "VVZG4E"   ))
  VVZJ87.append(("Tuners Info"    , "VV0NiC"  ))
  VVZJ87.append(("Python Version"   , "VVxIX3"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Screen Size"    , "ScreenSize"   ))
  VVZJ87.append(("Language/Locale"   , "Locale"    ))
  VVZJ87.append(("Processor"    , "Processor"   ))
  VVZJ87.append(("Operating System"   , "OperatingSystem"  ))
  VVZJ87.append(("Drivers"     , "drivers"    ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("System Users"    , "SystemUsers"   ))
  VVZJ87.append(("Logged-in Users"   , "LoggedInUsers"  ))
  VVZJ87.append(("Uptime"     , "Uptime"    ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Host Name"    , "HostName"   ))
  VVZJ87.append(("MAC Address"    , "MACAddress"   ))
  VVZJ87.append(("Network Configuration" , "NetworkConfiguration"))
  VVZJ87.append(("Network Status"   , "NetworkStatus"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Disk Usage"    , "VV3lC8"   ))
  VVZJ87.append(("Mount Points"    , "MountPoints"   ))
  VVZJ87.append(("File System Table (FSTAB)", "FileSystemTable"  ))
  VVZJ87.append(("USB Devices"    , "USB_Devices"   ))
  VVZJ87.append(("List Block-Devices"  , "listBlockDevices" ))
  VVZJ87.append(("Directory Size"   , "DirectorySize"  ))
  VVZJ87.append(("Memory"     , "Memory"    ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Loaded Kernel Modules" , "LoadedKernelModules" ))
  VVZJ87.append(("Running Processes"  , "RunningProcesses" ))
  VVZJ87.append(("Processes with open files", "ProcessesOpenFiles" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Bootloader Second-stage (old DreamBox only)" , "DreamBoxBootloader"))
  FFmmH7(self, VVZJ87=VVZJ87, title="Device Information")
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "SettingsFile"   : self.session.open(CCT1z4)
   elif item == "VVZG4E"   : self.VVZG4E()
   elif item == "VV0NiC"  : self.VV0NiC()
   elif item == "VVxIX3"  : self.VVxIX3()
   elif item == "ScreenSize"   : FF90Bc(self, "Width\t: %s\nHeight\t: %s" % (FFwz8B()[0], FFwz8B()[1]))
   elif item == "Locale"    : CCqdtK.VVciDE(self)
   elif item == "Processor"   : self.VVDNT3()
   elif item == "OperatingSystem"  : FF6Z0v(self, "uname -a")
   elif item == "drivers"    : self.VVyUIg()
   elif item == "SystemUsers"   : FF6Z0v(self, "id")
   elif item == "LoggedInUsers"  : FF6Z0v(self, "who -a", consFont=True)
   elif item == "Uptime"    : FF6Z0v(self, "uptime")
   elif item == "HostName"    : FF6Z0v(self, "hostname")
   elif item == "MACAddress"   : self.VVXynO()
   elif item == "NetworkConfiguration" : FF6Z0v(self, "ifconfig %s %s" % (FFXRSi("HWaddr", VV21C5), FFXRSi("addr:", VVVCGb)))
   elif item == "NetworkStatus"  : FF6Z0v(self, "netstat -tulpn", VVTFXq=24, consFont=True)
   elif item == "VV3lC8"   : self.VV3lC8()
   elif item == "MountPoints"   : FF6Z0v(self, "mount %s" % (FFXRSi(" on ", VVVCGb)))
   elif item == "FileSystemTable"  : FF6Z0v(self, "cat /etc/fstab", VVTFXq=24, consFont=True)
   elif item == "USB_Devices"   : FF6Z0v(self, "lsusb")
   elif item == "listBlockDevices"  : FF6Z0v(self, "blkid")
   elif item == "DirectorySize"  : FF6Z0v(self, "du -shc /* | sed '/total/i-----\t-------------' | sed 's/total/TOTAL/g'", VVRkcg="Reading size ...")
   elif item == "Memory"    : FF6Z0v(self, "cat /proc/meminfo | sed 's/ //g' | sed 's/:/\t: /g' | sed '/MemAvailable/a%s'" % ("-" * 25))
   elif item == "LoadedKernelModules" : self.VVsWrB()
   elif item == "RunningProcesses"  : FF6Z0v(self, "ps", consFont=True)
   elif item == "ProcessesOpenFiles" : FF6Z0v(self, "lsof", consFont=True)
   elif item == "DreamBoxBootloader"  : self.VVRaXn()
   else        : self.close()
 def VVXynO(self):
  res = FF5IiQ("ip link")
  list = iFindall(r"[0-9]+:\s+(.+):\s+.+\n.+\s+(.+)brd", res, IGNORECASE)
  if list:
   txt = ""
   for item in list:
    brd = item[0].upper()
    mac = item[1].upper()
    if not brd == "LO":
     txt += "%s\t: %s\n" % (item[0].upper(), item[1].upper())
   FF90Bc(self, txt)
  else:
   FF6Z0v(self, "ip link")
 def VVtID3(self, cmd, headerRepl, length, use2Spaces):
  if headerRepl:
   cmd += " | sed 's/%s/%s/g'" % (headerRepl, headerRepl.replace(" ", "_"))
  if use2Spaces:
   col = ""
   for i in range(length):
    col += "$%d" % (i + 1)
    if i < length - 1:
     col += '"#"'
   cmd += " | awk -F '  +' '{print %s}'" % col
  else:
   cmd += " | sed 's/[* ]\+/\#/g'"
  lines = FFnAC3(cmd)
  return lines
 def VVZ0z8(self, lines, headerRepl, widths, VVFvCJ):
  VVX3wb = []
  header  = []
  for ndx, line in enumerate(lines):
   if ndx == 0 and headerRepl:
    line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
   parts = line.split("#")
   if ndx == 0 : header = parts
   else  : VVX3wb.append(parts)
  if VVX3wb and len(header) == len(widths):
   VVX3wb.sort(key=lambda x: x[0].lower())
   FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=28, VVqDAH=1)
   return True
  else:
   return False
 def VV3lC8(self):
  headerRepl = "Mounted on"
  cmd   = "df -Th"
  txt = FF5IiQ(cmd)
  if not "invalid option" in txt:
   lines  = self.VVtID3(cmd, headerRepl, 6, False)
   widths  = (25 , 12 , 10 , 9  , 10 , 9  , 25 )
   VVFvCJ = (LEFT , CENTER, CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVZ0z8(lines, headerRepl, widths, VVFvCJ)
  else:
   cmd = "df -h"
   lines  = self.VVtID3(cmd, headerRepl, 6, False)
   widths  = (28 , 11 , 11 , 11 , 11 , 28 )
   VVFvCJ = (LEFT , CENTER, CENTER, CENTER, CENTER, LEFT )
   allOK = self.VVZ0z8(lines, headerRepl, widths, VVFvCJ)
  if not allOK:
   lines = FFnAC3(cmd)
   if lines:
    mountList = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
    mountList = [FFAxSo(x) for x in mountList]
    mountList = tuple(mountList)
    txt   = ""
    note  = ""
    if VVVjNM:
     note = "\n%s" % FFGB9z("Green = Mounted Partitions", VVVjNM)
    lines = lines[:1] + sorted(lines[1:])
    for line in lines:
     if "Use%" in line:
      line = line.replace(headerRepl.replace(" ", "_"), headerRepl)
      color = VVVCGb
     elif line.endswith(mountList) : color = VVVjNM
     else       : color = VVGb6D
     txt += FFGB9z(line, color) + "\n"
    FF90Bc(self, txt + note)
   else:
    FFw5OO(self, "Not data from system !")
 def VVsWrB(self):
  cmd   = "lsmod"
  headerRepl = "Used by"
  lines  = self.VVtID3(cmd, headerRepl, 3, True)
  widths  = [30 , 15 , 55 ]
  VVFvCJ = (LEFT , CENTER, LEFT )
  allOK = self.VVZ0z8(lines, headerRepl, widths, VVFvCJ)
  if not allOK:
   FF6Z0v(self, cmd)
 def VVyUIg(self):
  cmd = FF8jae(VVcrnB, "| grep -e '-blindscan-\|dvb-modules\|-grab-\|-libs-\|-loadmodules-\|-opengl\|-partitions-\|-reader-\|-showiframe-'")
  if cmd : FF6Z0v(self, cmd)
  else : FFgq4o(self)
 def VVDNT3(self):
  cmd  = "RES=$(uname -m | awk '{print toupper($0)}');"
  cmd += "if [ -z \"$RES\" ] ; then RES=$(uname -a | awk '{print toupper($12)}'); fi;"
  cmd += "if [ -z \"$RES\" ] ; then echo 'Could not read Info.!'; else echo $RES; fi"
  FF6Z0v(self, cmd)
 def VVRaXn(self):
  cmd = FF8jae(VVBCs3, "| grep secondstage")
  if cmd : FF6Z0v(self, 'output=$(%s); if [ -z "$output" ] ; then echo "Not found for this receiver."; else echo $output; fi' % cmd)
  else : FFgq4o(self)
 def VVZG4E(self):
  c = VVVjNM
  VVarfR = []
  VVarfR.append((FFGB9z("Box Type"  , c), FFGB9z(self.VVWLdx("boxtype").upper(), c)))
  VVarfR.append((FFGB9z("Board Version", c), FFGB9z(self.VVWLdx("board_revision") , c)))
  VVarfR.append((FFGB9z("Chipset"  , c), FFGB9z(self.VVWLdx("chipset")  , c)))
  VVarfR.append((FFGB9z("S/N"   , c), FFGB9z(self.VVWLdx("sn")    , c)))
  VVarfR.append((FFGB9z("Version"  , c), FFGB9z(self.VVWLdx("version")  , c)))
  VVKf8s   = []
  VV5lFV = ""
  try:
   from Components.SystemInfo import SystemInfo
   keysList = list(SystemInfo)
   if keysList:
    for key in keysList:
     if key == "canMultiBoot":
      VV5lFV = SystemInfo[key]
     else:
      VVKf8s.append((FFGB9z(str(key), VVkqaK), FFGB9z(str(SystemInfo[key]), VVkqaK)))
  except:
   pass
  if VV5lFV:
   VVgsQV = self.VVVVLn(VV5lFV)
   if VVgsQV:
    VVgsQV.sort(key=lambda x: x[0].lower())
    VVarfR += VVgsQV
  if VVKf8s:
   VVKf8s.sort(key=lambda x: x[0].lower())
   VVarfR += VVKf8s
  if VVarfR:
   header  = ("Subject" , "Value")
   widths  = (40    , 60)
   FF1Dpj(self, None, header=header, VVarfR=VVarfR, VVhAo0=widths, VVTFXq=28, VVqDAH=1)
  else:
   FF90Bc(self, "Could not read info!")
 def VVWLdx(self, fileName):
  fileName = "/proc/stb/info/" + fileName
  if fileExists(fileName):
   try:
    txt = FFZQjt(fileName)[0]
    if txt:
     return txt
   except:
    pass
  return "-"
 def VVVVLn(self, mbDict):
  try:
   mbList = list(mbDict)
   VVarfR = []
   for key in mbList:
    bootDict = mbDict[key]
    device  = bootDict.get("device"  , "")
    rootsubdir = bootDict.get("rootsubdir" , "")
    startupfile = bootDict.get("startupfile", "")
    subject  = "Multiboot-" + str(key)
    value  = ""
    if startupfile : subject += " ... "      + startupfile
    if rootsubdir : value  += "Root-Sub-Dir = %s  ...  " % rootsubdir
    if device  : value  += "Device = "     + device
    if not value:
     value  = str(bootDict)
    VVarfR.append((FFGB9z(subject, VVVCGb), FFGB9z(value, VVVCGb)))
  except:
   pass
  return VVarfR
 def VV0NiC(self):
  txt = self.VVwRe0("/proc/stb/bus/nim_sockets")
  if not txt: txt = self.VVwRe0("/proc/bus/nim_sockets")
  if not txt: txt = self.VV1DYV()
  txt = txt.strip()
  if not txt:
   txt = "Could not read info!"
  FF90Bc(self, txt)
 def VV1DYV(self):
  txt = ""
  VVYPGf = lambda x, y: "%s\t: %s\n" % (x, str(y))
  try:
   for slot in nimmanager.nim_slots:
    if slot.frontend_id is not None:
     slotName = VVYPGf("Slot Name" , slot.getSlotName())
     txt += FFGB9z(slotName, VVVCGb)
     txt += VVYPGf("Description"  , slot.getFullDescription())
     txt += VVYPGf("Frontend ID"  , slot.frontend_id)
     txt += VVYPGf("I2C ID"   , slot.getI2C())
     txt += "\n"
  except:
   pass
  return txt
 def VVwRe0(self, fileName):
  txt = ""
  if fileExists(fileName):
   try   : lines = FFZQjt(fileName)
   except: lines = None
   if lines:
    for line in lines:
     if line.endswith(":"):
      line = FFGB9z(line, VVVCGb)
      if txt:
       txt += "\n"
     elif ":" in line:
      parts = line.split(":")
      if len(parts[0]) > 12 : tab = "\t: "
      else     : tab = "\t\t: "
      line = line.replace(":", tab)
     if not "Has_Outputs" in line:
      txt += line + "\n"
  return txt
 def VVxIX3(self):
  major   = pyVersion[0]
  minor   = pyVersion[1]
  micro   = pyVersion[2]
  releaselevel = pyVersion[3]
  serial   = pyVersion[4]
  txt = "Version\t: %d.%d.%d\n" % (major, minor, micro)
  txt += "Release\t: %s\n"  % releaselevel
  txt += "Serial\t: %d\n"   % serial
  FF90Bc(self, txt)
 @staticmethod
 def VVvU7X():
  def VVYPGf(v, ndx):
   lst = v.split(";")[ndx].split(",")
   return {lst[i]: lst[i + 1] for i in range(0, len(lst), 2)}
  v = "openbox,OpenBox,openpli,OpenPLI,openvision,OpenVision;areadeltasat,ArEaDeltaSat,cobralibero,Cobralibero,opentr,OpenTR,peter,PeterPan;italysat,ItalySat,oozoon,OoZooN,openatv,openATV,openeight,OpenEight,openmips,OpenMips,opennfr,OpenNFR,openplus,OpenPlus,openspa,OpenSPA,pure2,Pure2,rudream,ruDream,teamblue,teamBlue,titannit,OpenAFF_Titan"
  v = {"/etc/issue": VVYPGf(v,0), "/etc/issue.net": VVYPGf(v,1), "/etc/image-version": VVYPGf(v,2)}
  for p1, d in v.items():
   img = CCcK2w.VVZUrJ(p1, d)
   if img: return img
  v = "Blackhole,Blackhole,DE,Dream-Elite,EGAMI,Egami,LT,LT,MediaSat,MediaSat,OPENDROID,OpenDroid,Bp/geminimain,GP3;Domica,Domica,SatLodge,Satlodge,Satdreamgr,SatdreamGr,TSimage,OpenTS_Ts,newnigma2,newnigma2;DemonisatManager,DDD-Demoni,VTIPanel,VTI,ViX,OpenVIX;AddOnManager,Merlin3,DreamOSatcamManager,DreamOSat CamManager,ExtraAddonss,OpenESI,HDF-Toolbox,OpenHDF,HDMUCenter,HDMU,LDteam,OpenLD,NssPanel,NonSoloSat,PKT,PKT,PowerboardCenter,PBNigma-VX,TDW,TDW"
  p = "/usr/lib/enigma2/python/"
  v = {p: VVYPGf(v,0), p + "Plugins/": VVYPGf(v,1), VVZk2h: VVYPGf(v,2), VVh8TB: VVYPGf(v,3)}
  for p1, d in v.items():
   img = CCcK2w.VVR9sC(p1, d)
   if img: return img
  return "OpenBlackhole" if iGlob("%sScreens/BpBlue.p*" % p) else ""
 @staticmethod
 def VVZUrJ(path, d):
  if fileExists(path):
   txt = FFQ5la(path).lower()
   for key, val in d.items():
    if key in txt: return val
  return ""
 @staticmethod
 def VVR9sC(path, d):
  for key, val in d.items():
   if pathExists(path + key): return val
  return ""
class CCT1z4(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 700, 630, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  VVZJ87 = []
  VVZJ87.append(("Settings (All)"   , "Settings_All"   ))
  VVZJ87.append(("Settings (Hot Keys)"  , "Settings_HotKeys"  ))
  VVZJ87.append(("Settings (Tuner/DiSEqC)" , "Settings_Tuner_DiSEqC" ))
  VVZJ87.append(("Settings (Plugins)"  , "Settings_Plugins"  ))
  VVZJ87.append(("Settings (Usage)"   , "Settings_Usage"   ))
  VVZJ87.append(("Settings (Time Zone)"  , "Settings_TimeZone"  ))
  VVZJ87.append(("Settings (Skin)"   , "Settings_Skin"   ))
  if VV8Ixy:
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Settings (%s)" % PLUGIN_NAME , "Settings_ajp" ))
   VVZJ87.append(("Settings (FHDG-17)"   , "Settings_FHDG_17"))
  FFmmH7(self, VVZJ87=VVZJ87)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   cmd  = "cat %ssettings" % VVNwTu
   grep = " | grep "
   if   item == "Settings_All"   : FF6Z0v(self, cmd)
   elif item == "Settings_HotKeys"  : FF6Z0v(self, cmd + grep + "'config.misc.hotkey.\|config.misc.ButtonSetup.'")
   elif item == "Settings_ajp"   : FF6Z0v(self, cmd + grep + "'config.plugins.%s.'" % PLUGIN_NAME)
   elif item == "Settings_FHDG_17"  : FF6Z0v(self, cmd + grep + "'config.plugins.setupGlass17.'")
   elif item == "Settings_Tuner_DiSEqC": FF6Z0v(self, cmd + grep + "'config.Nims.'")
   elif item == "Settings_Plugins"  : FF6Z0v(self, cmd + grep + "'.plugins.\|config.TS'")
   elif item == "Settings_Usage"  : FF6Z0v(self, cmd + grep + "'.usage.'")
   elif item == "Settings_TimeZone" : FF6Z0v(self, cmd + grep + "'.timezone.'")
   elif item == "Settings_Skin"  : FF6Z0v(self, cmd + grep + "'.skin.'")
   else        : self.close()
class CCXkrC(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 950, 800, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVZcgm, VVsYQW, VV7UIG, camCommand = CCXkrC.VVzmuP()
  self.VVsYQW = VVsYQW
  self.camInfo_cmd = camCommand + " -V 2> /dev/null"
  camName = "SoftCam"
  nC = oC = c = ""
  if VVsYQW:
   c = VVkIQ9 if VV7UIG else VVWOjU
   if   "oscam" in VVsYQW : camName, oC = "OSCam", c
   elif "ncam"  in VVsYQW : camName, nC = "NCam" , c
  VVZJ87 = []
  VVZJ87.append(("OSCam Files" , "OSCamFiles" ))
  VVZJ87.append(("NCam Files" , "NCamFiles" ))
  VVZJ87.append(("CCcam Files" , "CCcamFiles" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((VVUVAI + 'Convert "/etc/CCcam.cfg" to OSCam/NCam Readers', "VVSMef" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((oC + "OSCam Readers Table (oscam.server)" , "OSCamReaders" ))
  VVZJ87.append((nC + "NCam Readers Table (ncam.server)" , "NSCamReaders" ))
  VVZJ87.append(VVoqHH)
  camCmd = os.path.basename(camCommand)
  txt = "%s Settings%s" % (camName, "" if camCmd in ("oscam", "ncam") else " ( %s )" % camCmd)
  VVZJ87.append(FFnqNr(txt, "camInfo", VVsYQW, c))
  VVZJ87.append(VVoqHH)
  camLst = ((c + camName + " Live Status" , "camLiveStatus" )
    , (c + camName + " Live Readers", "camLiveReaders" )
    , (c + camName + " Live Log" , "camLiveLog"  ))
  if VVsYQW:
   for item in camLst: VVZJ87.append(item)
  else:
   for item in camLst: VVZJ87.append((item[0], ))
  FFmmH7(self, VVZJ87=VVZJ87)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "OSCamFiles"  : self.session.open(BF(CCNRzF, "oscam"))
   elif item == "NCamFiles"  : self.session.open(BF(CCNRzF, "ncam"))
   elif item == "CCcamFiles"  : self.session.open(BF(CCNRzF, "cccam"))
   elif item == "VVSMef" : self.VVSMef()
   elif item == "OSCamReaders"  : self.VVVXPy("os")
   elif item == "NSCamReaders"  : self.VVVXPy("n")
   elif item == "camInfo"   : FFRULi(self, self.camInfo_cmd)
   elif item == "camLiveStatus" : CCXkrC.VVkKQz(self.session, CCFgOL.VVmD4t)
   elif item == "camLiveReaders" : CCXkrC.VVkKQz(self.session, CCFgOL.VVmsG4)
   elif item == "camLiveLog"  : CCXkrC.VVkKQz(self.session, CCFgOL.VVFtec)
   else       : self.close()
 def VVSMef(self):
  path = "/etc/CCcam.cfg"
  outFile = "%scccam_to_reader_%s.txt" % (VVNemM, FFUD38())
  if fileExists(path):
   lines = FFZQjt("/etc/CCcam.cfg")
   lst = []
   for line in lines:
    line = line.strip()
    if line.startswith("C:"):
     while "  " in line: line = line.replace("  ", " ")
     parts = line.split(" ")
     if len(parts) == 5:
      CTxt, host, port, User, Pass = parts
      lst.append((host, port, User, Pass))
   newLine = []
   if lst:
    VVYPGf = lambda txt, val: "%s= %s\n" % (txt.ljust(30), str(val))
    with open(outFile, "w") as f:
     for ndx, item in enumerate(lst, start=1):
      host, port, User, Pass = item
      f.write("[reader]\n")
      f.write(VVYPGf("label"    , "CCcam-Line-%d" % ndx))
      f.write(VVYPGf("description"  , "CCcam-Line-%d" % ndx))
      f.write(VVYPGf("protocol"   , "cccam"))
      f.write(VVYPGf("device"    , "%s,%s" % (host, port)))
      f.write(VVYPGf("user"    , User))
      f.write(VVYPGf("password"   , Pass))
      f.write(VVYPGf("fallback"   , "1"))
      f.write(VVYPGf("group"    , "64"))
      f.write(VVYPGf("cccversion"   , "2.3.2"))
      f.write(VVYPGf("audisabled"   , "1"))
      f.write("\n")
    tot = len(lst)
    FF15cM(self, "Output = %d Reader%s in:\n\n%s" % (tot, FF1I1d(tot), outFile))
   else:
    FF5uKN(self, "No valid CCcam lines", 1500)
  else:
   FF5uKN(self, "%s not found" % path, 1500)
 def VVVXPy(self, camPrefix):
  VVX3wb = self.VVIacp(camPrefix)
  if VVX3wb:
   VVX3wb.sort(key=lambda x: int(x[0]))
   if self.VVsYQW and self.VVsYQW.startswith(camPrefix):
    VVX66G = ("Toggle State", self.VV7FIk, [camPrefix], "Changing State ...")
   else:
    VVX66G = None
   header   = ("No." , "State", "Label", "Description", "URL", "Port", "Protocol", "User", "Password")
   widths   = (4  , 5   , 21    , 18     , 14  , 7  , 11   , 10  , 10   )
   VVFvCJ  = (CENTER, CENTER , LEFT   , LEFT    , LEFT , CENTER, LEFT  , LEFT, LEFT  )
   FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVX66G=VVX66G, VVUdUN=True)
 def VVIacp(self, camPrefix):
  readersFile = self.VVZcgm + camPrefix + "cam.server"
  VVX3wb = []
  if fileExists(readersFile):
   tag   = "[reader]"
   lines  = FFZQjt(readersFile)
   tagFound = False
   enable  = label = description = url = port = protocol = User = password = ""
   onStr  = "#f#1100ff00#" + "ON"
   offStr  = "OFF"
   for ndx, line in enumerate(lines):
    if tag in line.lower() or ndx >= len(lines) - 1:
     if enable or label or description or url or port or protocol or User or password:
      if enable == "":
       enable = onStr
      VVX3wb.append((str(len(VVX3wb) + 1),enable, label, description, url, port, protocol, User, password))
     enable = label = description = url = port = protocol = User = password = ""
    elif "=" in line:
     parts = line.split("=")
     key  = parts[0].strip().lower()
     val  = parts[1].strip()
     if   key == "label"   : label   = val
     elif key == "description" : description = val
     elif key == "protocol"  : protocol  = val
     elif key == "user"   : User   = val
     elif key == "password"  : password  = val
     elif key == "enable"  :
      if val == "0" : enable = offStr
      else   : enable = onStr
     elif key == "device"  :
      if "," in val:
       parts = val.split(",")
       url  = parts[0].strip()
       port = parts[1].strip()
      else:
       url, port = val, ""
   if not VVX3wb:
    FFw5OO(self, "No readers found !")
  else:
   FFZoTn(self, readersFile)
  return VVX3wb
 def VV7FIk(self, VVxBfP, camPrefix):
  confFile  = "%s%scam.conf" % (self.VVZcgm, camPrefix)
  readerState  = VVxBfP.VVYzwE(1)
  readerLabel  = VVxBfP.VVYzwE(2)
  if "off" in readerState.lower() : newState = "enable"
  else       : newState = "disable"
  urlAction = "&label=%s&action=%s" % (readerLabel, newState)
  urlStuff = CCXkrC.VVMQdd(self, camPrefix, confFile, "readerlist", urlAction)
  if urlStuff:
   UrlRequest, elementTree = urlStuff
   try:
    page = iUrlopen(UrlRequest, timeout=4)
   except Exception as e:
    VVxBfP.VVW7OH()
    FFw5OO(self, "Cannot connect to SoftCAM !\n\nError = %s" % str(e))
    return
   VVX3wb = self.VVIacp(camPrefix)
   if VVX3wb:
    VVxBfP.VVcckS(VVX3wb)
  else:
   VVxBfP.VVW7OH()
 @staticmethod
 def VVMQdd(SELF, camPrefix, confFile, urlPart, urlAction):
  if fileExists(confFile):
   lines = FFZQjt(confFile)
   user = "root"
   pwd  = port = ""
   if lines:
    webif = False
    for line in lines:
     line = line.strip().lower()
     if "[webif]" in line:
      webif = True
     if webif and "=" in line:
      if   line.startswith("httpuser") : user = line.split("=")[1].strip()
      elif line.startswith("httppwd")  : pwd = line.split("=")[1].strip()
      elif line.startswith("httpport") : port = line.split("=")[1].strip()
   if not webif:
    FFw5OO(SELF, "Cannot connect to SoftCAM Web Interface !")
    return None
   elif not port:
    FFw5OO(SELF, "SoftCAM Web Port not found in file:\n\n%s" % confFile)
    return None
  else:
   FFZoTn(SELF, confFile)
   return None
  if not iRequest:
   FFw5OO(SELF, "Module not found\n\nurllib/urllib2")
   return None
  if not CCXkrC.VVumgt(SELF):
   return None
  try:
   url = "http://127.0.0.1:%s/%scamapi.html?part=%s%s" % (port, camPrefix, urlPart, urlAction)
   acceccManager  = HTTPPasswordMgrWithDefaultRealm()
   acceccManager.add_password(None, url, user, pwd)
   handlers   = HTTPDigestAuthHandler(acceccManager)
   opener    = build_opener(HTTPHandler, handlers)
   install_opener(opener)
   return iRequest(url), iElem
  except Exception as e:
   FFw5OO(SELF, "Error while preparing URL Request !\n\n %s" % str(e))
   return None
 @staticmethod
 def VVumgt(SELF):
  if iElem:
   return True
  else:
   FFw5OO(SELF, "Module not found:\n\nxml.etree")
   return False
 @staticmethod
 def VVkKQz(session, VVZUYY):
  VVZcgm, VVsYQW, VV7UIG, camCommand = CCXkrC.VVzmuP()
  if VVsYQW:
   runLog = False
   if   VVZUYY == CCFgOL.VVmD4t : runLog = True
   elif VVZUYY == CCFgOL.VVmsG4 : runLog = True
   elif not VV7UIG          : FFOsAJ(session, message="SoftCam not started yet!")
   elif fileExists(VV7UIG)        : runLog = True
   else             : FFOsAJ(session, message="File not found !\n\n%s" % VV7UIG)
   if runLog:
    session.open(BF(CCFgOL, VVZcgm=VVZcgm, VVsYQW=VVsYQW, VV7UIG=VV7UIG, VVZUYY=VVZUYY))
  else:
   FFOsAJ(session, message="No active OSCam/NCam found !", title="Live Log")
 @staticmethod
 def VVzmuP():
  VVZcgm = "/etc/tuxbox/config/"
  VVsYQW = None
  VV7UIG  = None
  camCommand = FF3RLi("lsof | grep 'oscam\|ncam' | tail -1 | awk '{print $2}'")
  if camCommand:
   camCmd = os.path.basename(camCommand).lower()
   if   camCmd.startswith("oscam") : VVsYQW = "oscam"
   elif camCmd.startswith("ncam") : VVsYQW = "ncam"
  if VVsYQW:
   tStr = os.path.basename(camCommand).lower()
   for path in iGlob("/etc/init.d/softcam.*"):
    _, _, camName = os.path.basename(path).lower().partition(".")
    if camName == tStr:
     span = iSearch(r"-config-dir\s(\/etc\/tuxbox.*?)\s", FFQ5la(path), IGNORECASE)
     if span:
      VVZcgm = FF1vNj(span.group(1))
      break
   else:
    path = FF3RLi(camCommand + " -V 2> /dev/null | grep -i configdir | awk '{print $2}'")
    path = FF1vNj(path)
    if pathExists(path):
     VVZcgm = path
   tFile = FF1vNj(VVZcgm) + VVsYQW + ".conf"
   tFile = FF3RLi("FILE='%s'; [ -f $FILE ] && cat $FILE | grep -i LOGFILE | awk '{print $3}'" % tFile)
   if fileExists(tFile):
    VV7UIG = tFile
  return VVZcgm, VVsYQW, VV7UIG, camCommand
class CCNRzF(Screen):
 def __init__(self, VV5ucp, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 700, 650, 50, 40, 30, "#22003300", "#22001100", 30)
  self.session  = session
  self.VVZcgm, VVsYQW, VV7UIG, camCommand = CCXkrC.VVzmuP()
  if   VV5ucp == "ncam" : self.prefix = "n"
  elif VV5ucp == "oscam" : self.prefix = "os"
  else     : self.prefix = ""
  VVZJ87 = []
  if self.prefix == "":
   VVZJ87.append(("CCcam.cfg"         , "c_CCcam_cfg"  ))
   VVZJ87.append(("ecm.info"          , "c_ecm_info"  ))
  else:
   VVZJ87.append(("AutoRoll.Key"         , "x_AutoRoll_Key" ))
   VVZJ87.append(("constant.cw"         , "x_constant_cw" ))
   VVZJ87.append((self.prefix + "cam.ccache"      , "x_cam_ccache" ))
   VVZJ87.append((self.prefix + "cam.conf"      , "x_cam_conf"  ))
   VVZJ87.append((self.prefix + "cam.dvbapi"      , "x_cam_dvbapi" ))
   VVZJ87.append((self.prefix + "cam.provid"      , "x_cam_provid" ))
   VVZJ87.append((self.prefix + "cam.server"      , "x_cam_server" ))
   VVZJ87.append((self.prefix + "cam.services"     , "x_cam_services" ))
   VVZJ87.append((self.prefix + "cam.srvid2"      , "x_cam_srvid2" ))
   VVZJ87.append((self.prefix + "cam.user"      , "x_cam_user"  ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("SoftCam.Key / SoftCam.key"     , "x_SoftCam_Key" ))
   VVZJ87.append(("CCcam.cfg"         , "x_CCcam_cfg"  ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append((self.prefix + "cam.log (last 100 lines)"  , "x_cam_log"  ))
   VVZJ87.append((self.prefix + "cam.log-prev (last 100 lines)" , "x_cam_log_prev" ))
   VVZJ87.append((self.prefix + "cam.pid"      , "x_cam_pid"  ))
  FFmmH7(self, VVZJ87=VVZJ87)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  pathTmp = "/tmp/"
  if item is not None:
   if   item == "c_CCcam_cfg"  : FFF5Ye(self, "/var/etc/CCcam.cfg")
   elif item == "c_ecm_info"  : FFF5Ye(self, "/tmp/ecm.info")
   elif item == "x_AutoRoll_Key" : FFF5Ye(self, self.VVZcgm + "AutoRoll.Key")
   elif item == "x_constant_cw" : FFF5Ye(self, self.VVZcgm + "constant.cw")
   elif item == "x_cam_ccache"  : self.VVUAIj("cam.ccache")
   elif item == "x_cam_conf"  : self.VVUAIj("cam.conf")
   elif item == "x_cam_dvbapi"  : self.VVUAIj("cam.dvbapi")
   elif item == "x_cam_provid"  : self.VVUAIj("cam.provid")
   elif item == "x_cam_server"  : self.VVUAIj("cam.server")
   elif item == "x_cam_services" : self.VVUAIj("cam.services")
   elif item == "x_cam_srvid2"  : self.VVUAIj("cam.srvid2")
   elif item == "x_cam_user"  : self.VVUAIj("cam.user")
   elif item == "x_SEP"   : pass
   elif item == "x_SoftCam_Key" : self.VVmYSi()
   elif item == "x_CCcam_cfg"  : FFF5Ye(self, self.VVZcgm + "CCcam.cfg")
   elif item == "x_SEP"   : pass
   elif item == "x_cam_log"  : FFF5Ye(self, pathTmp + self.prefix + "cam.log")
   elif item == "x_cam_log_prev" : FFF5Ye(self, pathTmp + self.prefix + "cam.log-prev")
   elif item == "x_cam_pid"  : FFF5Ye(self, pathTmp + self.prefix + "cam.pid")
   else       : self.close()
 def VVUAIj(self, fileName):
  FFF5Ye(self, self.VVZcgm + self.prefix + fileName)
 def VVmYSi(self):
  path = self.VVZcgm + "SoftCam.Key"
  if fileExists(path) : FFF5Ye(self, path)
  else    : FFF5Ye(self, path.replace(".Key", ".key"))
class CCFgOL(Screen):
 VVmD4t  = 0
 VVmsG4 = 1
 VVFtec = 2
 def __init__(self, session, VVZcgm="", VVsYQW="", VV7UIG="", VVZUYY=VVmD4t):
  self.skin, self.skinParam = FFRBRO(VVAtoE, 1400, 800, 50, 30, 20, "#22002030", "#33000011", 25, barHeight=40)
  self.session   = session
  self.VV7UIG   = VV7UIG
  self.VVZUYY  = VVZUYY
  self.fileTime   = ""
  self.timer    = eTimer()
  self.timerRunning  = False
  self.Title    = "Live Log"
  self.readersFile  = VVZcgm + VVsYQW + ".server"
  self.elementTree  = None
  self.UrlRequest   = None
  self.camWebIfData  = None
  self.camWebIfErrorFound = False
  self.user    = "root"
  self.pwd    = ""
  self.port    = ""
  if "oscam" in VVsYQW : titleTxt, self.camPrefix = "OSCam", "os"
  else     : titleTxt, self.camPrefix = "NCam" , "n"
  self.confFile   = "%s%scam.conf" % (VVZcgm, self.camPrefix)
  if self.VVZUYY == self.VVmD4t:
   self.Title   = "  %s Status"  % titleTxt
   self.period   = 10000
  elif self.VVZUYY == self.VVmsG4:
   self.Title   = "  %s Readers" % titleTxt
   self.period   = 10000
  else:
   self.Title   = "  %s Live Log" % titleTxt
   self.period   = 3000
  FFmmH7(self, self.Title, addScrollLabel=True)
  FFR9Qm(self["keyRed"], "Stop")
  self["myAction"].actions["red"] = self.VVubaT
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  self["myLabel"].VVlfXl(isResizable=False)
  self["myBar"].instance.setHAlign(1)
  FFHLqT(self)
  self.VVubaT()
 def onExit(self):
  self.timer.stop()
 def VVoDyW(self):
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV85wB)
  except:
   self.timer.callback.append(self.VV85wB)
  self.timer.start(self.period, False)
  self.timerRunning = True
  self["keyRed"].setText("Stop")
  self["myTitle"].setText(self.Title + " (Running)")
  self["myBar"].setText("Waiting for update ...")
  FF5uKN(self, "Started", 1000)
 def VVCaSM(self):
  self.timer.stop()
  self.timerRunning = False
  try:
   self.timer.callback.remove(self.VV85wB)
  except:
   pass
  self["keyRed"].setText("Start")
  self["myTitle"].setText(self.Title)
  self["myBar"].setText("")
  FF5uKN(self, "Stopped", 1000)
 def VVubaT(self):
  if self.timerRunning:
   self.VVCaSM()
  else:
   self.VVoDyW()
   if self.VVZUYY == self.VVmD4t or self.VVZUYY == self.VVmsG4:
    if self.VVZUYY == self.VVmD4t : urlPart = "status"
    else           : urlPart = "readerlist"
    urlStuff = CCXkrC.VVMQdd(self, self.camPrefix, self.confFile, urlPart, "")
    if urlStuff:
     self.UrlRequest, self.elementTree = urlStuff
     if self.camWebIfErrorFound:
      self.camWebIfErrorFound = False
      self["myLabel"].setText("Reading from SoftCAM Interface ...")
     FFFANg(self.VViyHC)
    else:
     self.close()
   else:
    self.VVYAkt()
 def VV85wB(self):
  if self.timerRunning:
   if   self.VVZUYY == self.VVmD4t : self.VVNkGp()
   elif self.VVZUYY == self.VVmsG4 : self.VVNkGp()
   else            : self.VVYAkt()
 def VVYAkt(self):
  if fileExists(self.VV7UIG):
   fTime = FFC3u1(os.path.getmtime(self.VV7UIG))
   if fTime != self.fileTime:
    self.fileTime = fTime
    self["myBar"].setText("Last Update : %s" % fTime)
    self["myLabel"].setText(self.VVXIns(), VV4VK0=VV0QS5)
  else:
   self["myLabel"].setText("\n\tWaiting for %s ..." % self.VV7UIG)
 def VViyHC(self):
  self.VVNkGp()
 def VVNkGp(self):
  err = ""
  try:
   page = iUrlopen(self.UrlRequest, timeout=1).read()
  except iURLError as e:
   if hasattr(e, "code") : err = "Error Code : %s\n" % str(e.code)
   if hasattr(e, "reason") : err += "Reason : %s\n" % str(e.reason)
   if not err    : err += "Error : %s"  % str(e)
  except Exception as e:
   err = str(e)
  if err:
   self["myLabel"].setText(FFGB9z("Cannot read from SoftCAM Interface !\n\nError = %s\n\nPlease activate Oscam or Ncam." % err, VVsObI))
   self.camWebIfErrorFound = True
   self.VVCaSM()
   return
  page = page.decode("UTF-8")
  lines = page.splitlines()
  xml = '<?xml version="1.0" encoding="UTF-8" ?>\n'
  if self.VVZUYY == self.VVmD4t : tags = ("<status", "<client", "<request", "<times", "<connection", "</client", "</status")
  else           : tags = ("<readers", "<reader", "</readers")
  for line in lines:
   line = line.strip()
   if line.startswith(tags):
    xml += line
  parseError = False
  try:
   root = self.elementTree.fromstring(xml)
  except Exception as e:
   parseError = FFGB9z("Error while parsing data elements !\n\nError = %s" % str(e), VVGe5h)
   self.camWebIfErrorFound = True
   self.VVCaSM()
  txt = ""
  if not parseError is False : txt = parseError
  else      : txt = self.VVlhCh(root)
  self["myLabel"].setText(txt, VV4VK0=VV0QS5)
  self["myBar"].setText("Last Update : %s" % FFxN8A())
 def VVlhCh(self, rootElement):
  def VVYPGf(key, val):
   if val : return "%s\t: %s\n" % (key, val)
   else : return ""
  txt = ""
  if self.VVZUYY == self.VVmD4t:
   for client in rootElement.findall("client"):
    name  = client.get("name")
    desc  = client.get("desc")
    protocol = client.get("protocol")
    ip   = client.find("connection").get("ip")
    port  = client.find("connection").get("port")
    status  = client.find("connection").text
    if status.upper() in ["OK", "CONNECTED"] : status = FFGB9z(status, VVVjNM)
    else          : status = FFGB9z(status, VVGe5h)
    txt += SEP + "\n"
    txt += VVYPGf("Name"  , name)
    txt += VVYPGf("Description" , desc)
    txt += VVYPGf("IP/Port"  , "%s : %s" % (ip, port))
    txt += VVYPGf("Protocol" , protocol)
    txt += VVYPGf("Status"  , status)
  else:
   for client in rootElement.findall("reader"):
    label  = client.get("label")
    protocol = client.get("protocol")
    enabled  = client.get("enabled")
    if enabled == "1" : enabTxt = FFGB9z("Yes", VVVjNM)
    else    : enabTxt = FFGB9z("No", VVGe5h)
    txt += SEP + "\n"
    txt += VVYPGf("Label"  , label)
    txt += VVYPGf("Protocol" , protocol)
    txt += VVYPGf("Enabled" , enabTxt)
  return txt
 def VVXIns(self):
  lines = FFnAC3("tail -n %d %s" % (100, self.VV7UIG))
  txt   = ""
  for line in lines:
   line = line.strip()
   span = iSearch(r"^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}\s+", line, IGNORECASE)
   if span:
    line = "\n" + VVMrXw + line[:19] + VVGb6D + line[19:]
    for preTxt in (" connecting to ", " from server ", " by ", "reader ", "server ", "(reader) "):
     if preTxt in line:
      if preTxt == " by " and " by WebIf" in line:
       line = line.replace("WebIf", VVO6N6 + "WebIf" + VVGb6D)
      else:
       t1, t2, t3 = line.partition(preTxt)
       if t2:
        h1, h2, h3 = t3.partition(" ")
        line = t1 + t2 + VVkqaK + h1 + h2 + VVGb6D + h3
    span = iSearch(r"(.+:\s*)(found\s*)(\(\d+\s*ms\))(.+)", line, IGNORECASE)
    if span:
     line = "\n" + span.group(1) + VVVjNM + span.group(2) + VVUVAI + span.group(3) + VVGb6D + span.group(4)
    line = self.VVCBc2(line, VVUVAI, ("(webif)", ))
    line = self.VVCBc2(line, VVUVAI, ("(anticasc)", "(anticasc)", "(cache)", "(cccam)", "(chk)", "(client)", "(config)", "(dvbapi)", "(ecm)", "(emm)", "(emmcache)", "(emu)", "(main)", "(net)", "(newcamd)", "(reader)", "(stat)"))
    line = self.VVCBc2(line, VVVjNM, ("OSCam", "NCam", "log switched"))
    line = self.VVCBc2(line, VVLbyB, (": not found", "failed", "rejected group", "usr/pwd invalid", "timeout", "no matching reader", "disconnected"))
    ndx = line.find(") - ")
    if ndx > -1:
     line = line[:ndx + 3] + VVVCGb + line[ndx + 3:] + VVGb6D
   elif line.startswith("----") or ">>" in line:
    line = FFGB9z(line, VVqFea)
   txt += line + "\n"
  return txt
 def VVCBc2(self, line, color, lst):
  for txt in lst:
   if txt in line:
    t1, t2, t3 = line.partition(txt)
    if t2:
     return t1 + color + t2 + VVGb6D + t3
  return line
class CCIEaN(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 750, 1000, 50, 60, 30, "#17164965", "#17102A3F", 30)
  self.session  = session
  VVZJ87 = []
  VVZJ87.append(("Backup Channels"    , "VVTdhk"   ))
  VVZJ87.append(("Restore Channels"    , "Restore_Channels"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Backup SoftCAM Files"   , "VVFIr9" ))
  VVZJ87.append(("Restore SoftCAM Files"  , "Restore_SoftCAM_Files" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Backup Tuner Settings"  , "Backup_TunerDiSEqC"  ))
  VVZJ87.append(("Restore Tuner Settings"  , "Restore_TunerDiSEqC"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Backup HotKeys Settings"  , "Backup_Hotkey_FHDG17" ))
  VVZJ87.append(("Restore HotKeys Settings"  , "Restore_Hotkey_FHDG17" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Backup Network Settings"  , "VV1Glv"   ))
  VVZJ87.append(("Restore Network Settings"  , "Restore_Network"   ))
  if VV8Ixy:
   VVZJ87.append(VVoqHH)
   VVZJ87.append((VVsObI + "1- Fix %s Code (New Obf)"  % PLUGIN_NAME    , "VVhWRY"   ))
   VVZJ87.append((VVVjNM + "2- Create %s for IPK (%s)"   % (PLUGIN_NAME, VVoq2O), "createMyIpk"   ))
   VVZJ87.append((VVVjNM + "3- Create %s for DEB (%s)"  % (PLUGIN_NAME, VVoq2O), "createMyDeb"   ))
   VVZJ87.append((VVkqaK + "Create %s TAR (Absolute Path)" % PLUGIN_NAME    , "createMyTar"   ))
   VVZJ87.append((VVkqaK + "Decode %s Crash Report"   % PLUGIN_NAME    , "VVr0Ou" ))
   VVZJ87.append((VVkqaK + "Show Windows Stats"           , "VVzkoj" ))
  FFmmH7(self, VVZJ87=VVZJ87)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVTdhk"    : self.VVTdhk()
   elif item == "Restore_Channels"    : self.VVclcN("channels_backup*.tar.gz", self.VVR4MQ, isChan=True)
   elif item == "VVFIr9"   : self.VVFIr9()
   elif item == "Restore_SoftCAM_Files"  : self.VVclcN("softcam_backup*.tar.gz", self.VVnnAl)
   elif item == "Backup_TunerDiSEqC"   : self.VVOgF1("tuner_backup", "config.Nims.")
   elif item == "Restore_TunerDiSEqC"   : self.VVclcN("tuner_backup*.backup", BF(self.VVaYBY, "tuner"), isTuner=True)
   elif item == "Backup_Hotkey_FHDG17"   : self.VVOgF1("hotkey_backup", "config.plugins.setupGlass17.\|config.misc.hotkey.\|config.misc.ButtonSetup.")
   elif item == "Restore_Hotkey_FHDG17"  : self.VVclcN("hotkey_*backup*.backup", BF(self.VVaYBY, "misc"))
   elif item == "VV1Glv"    : self.VV1Glv()
   elif item == "Restore_Network"    : self.VVclcN("network_backup*.tar.gz", self.VVPQwl)
   elif item == "VVhWRY"     : FFNKVM(self, BF(FFJsIX, self, BF(CCIEaN.VVhWRY, self)), "Erase previous obf ?")
   elif item == "createMyIpk"     : self.VVu20d(False)
   elif item == "createMyDeb"     : self.VVu20d(True)
   elif item == "createMyTar"     : self.VVtTUV()
   elif item == "VVr0Ou"   : self.VVr0Ou()
   elif item == "VVzkoj"    : CCIEaN.VVzkoj(self)
 @staticmethod
 def VVNaqF(SELF):
  OBF_Path = VVOJt3 + "OBF/"
  if fileExists(OBF_Path + "obf.py"):
   from sys import path as iPath
   iPath.append(OBF_Path)
   from imp import reload
   try: from .OBF import obf
   except: import obf
   reload(obf)
   return obf
  else:
   FFZoTn(SELF, OBF_Path)
   return None
 @staticmethod
 def VVzkoj(SELF):
  obf = CCIEaN.VVNaqF(SELF)
  if obf:
   txt, title = obf.windowsStats()
   FF90Bc(SELF, txt, title=title, outputFileToSave="WinStat")
 @staticmethod
 def VVhWRY(SELF):
  obf = CCIEaN.VVNaqF(SELF)
  if obf:
   txt, err = obf.fixCode(VVOJt3, VVLBtR, VVoq2O)
   if err : FFw5OO(SELF, err)
   else : FF90Bc(SELF, txt)
 def VVu20d(self, VVFsmA):
  OBF_Path = VVOJt3 + "OBF/"
  files = iGlob("%s*main_final.py" % OBF_Path)
  if not files:
   FFw5OO(self, "Final File .py not found in:\n\n%s" % OBF_Path)
   return
  FFuB0V("rm -f %s__pycache__/" % VVOJt3)
  FFuB0V("mv -f '%smain.py' '%s'" % (VVOJt3, OBF_Path))
  FFuB0V("mv -f '%splugin.py' '%s'" % (VVOJt3, OBF_Path))
  FFuB0V("cp -f %s*main_final.py %splugin.py" % (OBF_Path, VVOJt3))
  self.session.openWithCallback(self.VV9rv1, BF(CCjJUX, path=VVOJt3, VVFsmA=VVFsmA))
 def VV9rv1(self):
  FFuB0V("mv -f %s %s" % (VVOJt3 + "OBF/main.py" , VVOJt3))
  FFuB0V("mv -f %s %s" % (VVOJt3 + "OBF/plugin.py", VVOJt3))
 def VVr0Ou(self):
  path = "/tmp/OBF/"
  if not pathExists(path):
   FFw5OO(self, "Path not found:\n%s" % path)
   return
  files = iGlob("%s*.log" % path)
  if not files:
   FFw5OO(self, "No log files in:\n\n%s" % path)
   return
  codF, err = self.VV3NLu("%s*.list" % path)
  if err:
   FFZoTn(self, path + "*.list")
   return
  srcF, err = self.VV3NLu("%s*main_final.py" % path)
  if err:
   FFZoTn(self, path + "*.final.py")
   return
  VVarfR = []
  for f in files:
   f = os.path.basename(f)
   VVarfR.append((f, f))
  FFYySC(self, BF(self.VVfmrA, path, codF, srcF), VVZJ87=VVarfR)
 def VVfmrA(self, path, codF, srcF, item=None):
  if item:
   logF = path + item
   if not fileExists(logF) : FFZoTn(self, logF)
   else     : FFJsIX(self, BF(self.VVwJ3g, logF, codF, srcF))
 def VVwJ3g(self, logF, codF, srcF):
  lst  = []
  lines = FFZQjt(codF)
  for line in lines:
   line = line.split(":")[1]
   parts = line.split("->")
   lst.append((parts[1].strip(), parts[0].strip()))
  if not lst:
   FFw5OO(self, "No codes in : %s" % codF)
   return
  newLogF = logF.replace(".log", ".NEW.log")
  newSrcF = srcF.replace(".py" , ".DBG.py")
  totLog  = self.VVXcfa(lst, logF, newLogF)
  totSrc  = self.VVXcfa(lst, srcF, newSrcF)
  txt = "Found\t: %s\nIn\t: %s\n\nFound\t: %s\nIn\t: %s\n\nNew Files\t:\n" % (totLog, logF, totSrc, srcF)
  if not totLog and not totSrc:
   txt += "None"
  else:
   if totLog: txt += "    %s\n" % newLogF
   if totSrc: txt += "    %s\n" % newSrcF
  FF90Bc(self, txt)
 def VV3NLu(self, patt):
  tFiles = iGlob(patt)
  if not tFiles:
   return "", "*.list"
  f = tFiles[0]
  if not fileExists(f):
   return "", "Not found:\n\n"
  return f, ""
 def VVXcfa(self, lst, f1, f2):
  txt = FFQ5la(f1)
  tot = 0
  for item in lst:
   if item[0] in txt:
    tot += 1
   txt = txt.replace(item[0], item[1])
  if tot > 0:
   with open(f2, "w") as f:
    f.write(txt)
  return tot
 def VVtTUV(self):
  VVarfR = []
  VVarfR.append("%s%s" % (VVOJt3, "*.py"))
  VVarfR.append("%s%s" % (VVOJt3, "*.png"))
  VVarfR.append("%s%s" % (VVOJt3, "*.xml"))
  VVarfR.append("%s"  % (VVrrZu))
  FFeF3s(self, VVarfR, "%s_%s" % (PLUGIN_NAME, VVLBtR), addTimeStamp=False)
 def VVTdhk(self):
  path1 = VVNwTu
  path2 = "/etc/tuxbox/"
  VVarfR = []
  VVarfR.append("%s%s" % (path1, "*.tv"))
  VVarfR.append("%s%s" % (path1, "*.radio"))
  VVarfR.append("%s%s" % (path1, "*list"))
  VVarfR.append("%s%s" % (path1, "lamedb*"))
  VVarfR.append("%s%s" % (path2, "*.xml"))
  FFeF3s(self, VVarfR, self.VVDwOq("channels_backup"), addTimeStamp=True)
 def VVFIr9(self):
  VVarfR = []
  VVarfR.append("/etc/tuxbox/config/")
  VVarfR.append("/usr/keys/")
  VVarfR.append("/usr/scam/")
  VVarfR.append("/etc/CCcam.cfg")
  FFeF3s(self, VVarfR, self.VVDwOq("softcam_backup"), addTimeStamp=True)
 def VV1Glv(self):
  VVarfR = []
  VVarfR.append("/etc/hostname")
  VVarfR.append("/etc/default_gw")
  VVarfR.append("/etc/resolv.conf")
  VVarfR.append("/etc/wpa_supplicant*.conf")
  VVarfR.append("/etc/network/interfaces")
  VVarfR.append("%snameserversdns.conf" % VVNwTu)
  FFeF3s(self, VVarfR, self.VVDwOq("network_backup"), addTimeStamp=True)
 def VVDwOq(self, fName):
  img = CCcK2w.VVvU7X()
  if img: fName = "%s_%s" % (fName, img)
  return fName
 def VVR4MQ(self, fileName=None):
  if fileName:
   FFNKVM(self, BF(FFJsIX, self, BF(self.VVbwKR, fileName), title="Restoring ..."), "Overwrite current channels ?")
 def VVbwKR(self, fileName):
  path = "%s%s" % (VVNemM, fileName)
  if fileExists(path):
   if CCCXvS.VV7YC3(path):
    VVA5X1 , VVW7fq = CCdAiy.VVslUe()
    VV6cOv, VVrphN = CCdAiy.VVfnOh()
    cmd  = FFIV1X("cd %s" % VVNwTu) + ";"
    cmd += FFIV1X("rm -f *.tv *.radio *.del lamedb* whitelist blacklist satellites.xml %s %s" % (VVW7fq, VVrphN))+ ";"
    cmd += "tar -xzf '%s' -C /" % path
    res = FFuB0V(cmd)
    FFAvBD()
    if res == 0 : FF15cM(self, "Channels Restored.")
    else  : FFw5OO(self, "Error while restoring:\n\n%s" % fileName)
   else:
    FFw5OO(self, "Invalid tar file:\n\n%s" % path)
  else:
   FFZoTn(self, path)
 def VVnnAl(self, fileName=None):
  if fileName:
   FFNKVM(self, BF(self.VVHwUw, fileName), "Overwrite SoftCAM files ?")
 def VVHwUw(self, fileName):
  fileName = "%s%s" % (VVNemM, fileName)
  if fileExists(fileName):
   sep  = "echo -e '%s'" % SEP
   note = "You may need to restart your SoftCAM."
   FF3aHD(self, "%s;tar -xzvf '%s' -C /;%s;echo -e '\nDONE\n\n%s\n' %s;%s;" % (sep, fileName, sep, note, FFXRSi(note, VVVCGb), sep))
  else:
   FFZoTn(self, fileName)
 def VVPQwl(self, fileName=None):
  if fileName:
   FFNKVM(self, BF(self.VV0tOX, fileName), "Overwrite Network Settings (and REBOOT) ?")
 def VV0tOX(self, fileName):
  fileName = "%s%s" % (VVNemM, fileName)
  if fileExists(fileName):
   cmd = "tar -xzvf '%s' -C /;" % fileName
   cmd += "echo ''; echo 'REBOOTING ...';"
   cmd += "sleep 3; reboot"
   FF1Q61(self,  cmd)
  else:
   FFZoTn(self, fileName)
 def VVclcN(self, pattern, callBackFunction, isTuner=False, isChan=False):
  title = FFwrBW()
  if pathExists(VVNemM):
   myFiles = FFzSvJ(VVNemM, pattern)
   if len(myFiles) > 0:
    myFiles.sort(key=os.path.getmtime, reverse=True)
    VVarfR = []
    for myFile in myFiles:
     fileName = os.path.basename(myFile)
     VVarfR.append((fileName, fileName))
    if len(myFiles) > 1:
     title = title + " (Sorted by time)"
    if   isTuner  : VVbiUc = ("Sat. List", self.VV5dRW)
    elif isChan and iTar: VVbiUc = ("Bouquets Importer", CCgpQ0.VVYJ3G)
    else    : VVbiUc = None
    FFYySC(self, callBackFunction, title=title, width=1200, VVZJ87=VVarfR, VVbiUc=VVbiUc, VVAL4K=VVNemM)
   else:
    FFw5OO(self, "No files found in:\n\n%s" % VVNemM, title)
  else:
   FFw5OO(self, "Path not found:\n\n%s" % VVNemM, title)
 def VVOgF1(self, filePrefix, wordsFilter):
  settingFile = "%ssettings" % VVNwTu
  tCons = CC1WBa()
  tCons.ePopen("if [ -f '%s' ]; then cat %s | grep '%s'; else echo '?'; fi" % (settingFile, settingFile, wordsFilter), BF(self.VVSLWE, filePrefix))
 def VVSLWE(self, filePrefix, result, retval):
  title = FFwrBW()
  if pathExists(VVNemM):
   result = str(result).strip()
   if retval > 0 or result == "?":
    FFw5OO(self, "Cannot read settings file", title)
   else:
    fName = "%s%s%s_%s.backup" % (VVNemM, filePrefix, self.VVDwOq(""), FFUD38())
    try:
     VVarfR = str(result.strip()).split()
     if VVarfR:
      with open(fName, "w") as newFile:
       txt = ""
       for line in VVarfR:
        newLine = "%s\n" % line
        newFile.write(newLine)
        txt += newLine
      if fileExists(fName):
       txt += "%s\n\nDONE\n\nFile:\n%s\n\n%s" % (SEP, FFGB9z(fName, VVVCGb), SEP)
       FF90Bc(self, txt, title=title, VV4VK0=VV0QS5)
      else:
       FFw5OO(self, "File creation failed!", title)
     else:
      FFw5OO(self, "Parameters not found in settings file.", title)
    except IOError as e:
     FFuB0V("rm %s" % fName)
     FFw5OO(self, "Error [%d] : %s\n\nChange Backup Folder and try again." % (e.errno, e.strerror))
    except:
     FFuB0V("rm %s" % fName)
     FFw5OO(self, "Error while writing file.")
  else:
   FFw5OO(self, "Path not found:\n\n%s" % VVNemM, title)
 def VVaYBY(self, mode, path=None):
  if path:
   path = "%s%s" % (VVNemM, path)
   if fileExists(path):
    lines = FFZQjt(path, keepends=True)
    if lines:
     if mode == "tuner" : txt = "tuner"
     else    : txt = "Hotkeys"
     FFNKVM(self, BF(self.VVglDJ, path, mode, lines), "Overwrite %s settings (and restart) ?" % txt)
    else:
     FF5BXO(self, path, title=FFwrBW())
   else:
    FFZoTn(self, path)
 def VVglDJ(self, path, mode, lines):
  grepFilter = ""
  if mode == "tuner":
   grepFilter = ".Nims."
   newList = []
   for line in lines:
    newList.append(line)
    if ".dvbs." in line:
     newList.append(line.replace(".dvbs.", "."))
    else:
     parts = line.split(".")
     if len(parts) > 3:
      tunerNum = ".%s." % parts[2]
      newList.append(line.replace(tunerNum, "%sdvbs." % tunerNum))
  elif mode == "misc":
   grepFilter = ".setupGlass17.\|.hotkey.\|.ButtonSetup."
   newList = []
   for line in lines:
    newList.append(line)
    if   ".hotkey."   in line : newList.append(line.replace(".hotkey.", ".ButtonSetup."))
    elif ".ButtonSetup." in line : newList.append(line.replace(".ButtonSetup.", ".hotkey."))
  finalList = []
  for line in newList:
   if line.strip() and not line in finalList:
    finalList.append(line)
  VVA1ht = []
  sFile = "/etc/enigma2/settings"
  tFile = "/tmp/ajp_tmp"
  VVA1ht.append("echo -e 'Reading current settings ...'")
  VVA1ht.append("cat %s | grep -v '%s' > %s" % (sFile, grepFilter, tFile))
  settingsLines = "echo -e '"
  for line in finalList:
   settingsLines += line
  settingsLines = settingsLines.strip()
  settingsLines += "' >> %s" % tFile
  VVA1ht.append("echo -e 'Preparing new settings ...'")
  VVA1ht.append(settingsLines)
  VVA1ht.append("echo -e 'Applying new settings ...'")
  VVA1ht.append("mv -f %s %s" % (tFile, sFile))
  FFG0r2(self, VVA1ht)
 def VV5dRW(self, VVbBRSObj, path):
  if not path:
   return
  path = VVNemM + path
  if not fileExists(path):
   FFZoTn(self, path)
   return
  txt = FFQ5la(path)
  satList = []
  lst = iFindall(r".+[.](diseqc.?)[=](\d+)", txt, IGNORECASE)
  for sat in lst:
   diseqc = sat[0].upper()
   satNum = sat[1]
   satList.append((diseqc.replace("DISEQC", "DiSEqC-"), satNum))
  lst = iFindall(r".+[.]sat[.](\d+)[.](lnb[=].+)", txt, IGNORECASE)
  for sat in lst:
   satNum = sat[0]
   lnb  = sat[1].upper()
   satList.append((lnb.replace("LNB=", "LNB-"), satNum))
  if satList:
   satList = list(set(satList))
   satList.sort(key=lambda x: x[0])
   txt = ""
   for item in satList:
    txt += "%s\t%s\n" % (item[0], FFWHDS(item[1]))
   FF90Bc(self, txt, title="Satellites List")
  else:
   FFw5OO(self, "Incorrect Tuner Backup file !\n\n(or missing info.)", title="  Satellites List")
class CCgpQ0():
 def __init__(self, SELF):
  self.SELF   = SELF
  self.Title   = "Bouquets Importer"
  self.fileName  = ""
  self.filePath  = ""
  self.instance  = None
  self.isZip   = False
 @staticmethod
 def VVYJ3G(SELF, fName):
  bi = CCgpQ0(SELF)
  bi.instance = bi
  bi.VVxft5(SELF, fName)
 @staticmethod
 def VVAGW8(SELF):
  bi = CCgpQ0(SELF)
  bi.instance = bi
  bi.VVxOK0()
 def VVxft5(self, waitObg, fName):
  self.fileName = fName
  self.filePath = VVNemM + fName
  self.isZip   = fName.endswith(".zip")
  if fileExists(self.filePath): FFJsIX(waitObg, self.VVX71u, title="Reading bouquets ...")
  else      : self.VVLb99(self.filePath)
 def VVl8O9(self, txt) : FFw5OO(self.SELF, txt, title=self.Title)
 def VV70Sp(self, txt)  : FF5uKN(self, txt, 1500)
 def VVLb99(self, path) : FFZoTn(self.SELF, path, title=self.Title)
 def VVxOK0(self):
  if pathExists(VVNemM):
   lst = FFzSvJ(VVNemM, "channels_backup*.tar.gz")
   if iZip: lst.extend(self.VV2gup())
   if len(lst) > 0:
    VVZJ87 = []
    for item in lst:
     item = os.path.basename(item)
     txt = FFGB9z(item, VVUVAI) if item.endswith(".zip") else item
     VVZJ87.append((txt, item))
    VVZJ87.sort(key=lambda x: x[1].lower())
    VVkUAu = self.VVqv9b
    FFYySC(self.SELF, self.VVGguJ, minRows=3, title=self.Title, width=1200, VVZJ87=VVZJ87, VVkUAu=VVkUAu, VVAL4K=VVNemM, VVDlGi="#22111111", VVaSSM="#22111111")
   else:
    self.VVl8O9("No valid backup files found in:\n\n%s" % VVNemM)
  else:
   self.VVl8O9("Backup Directory not found:\n\n%s" % VVNemM)
 def VVqv9b(self, item=None):
  if item:
   VV4EHV, txt, fName, ndx = item
   self.VVxft5(VV4EHV, fName)
 def VVGguJ(self, item=None):
  if not item and self.instance:
   del self.instance
 def VV2gup(self):
  files = FFzSvJ(VVNemM, "*.zip")
  lst = []
  for path in files:
   bakFile = os.path.basename(path)
   with iZip.ZipFile(path) as zipF:
    dbFound = bFound = False
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     if fName == "lamedb" : dbFound = True
     if fName.endswith(".tv"): bFound = True
     if dbFound and bFound:
      lst.append(bakFile)
      break
  return lst
 def VVX71u(self):
  lines, err = CCgpQ0.VVNlMX(self.filePath, "bouquets.tv")
  if err:
   self.VVl8O9(err)
   return
  bTvSortLst  = self.VVENOV(lines)
  lines, err = CCgpQ0.VVNlMX(self.filePath, "bouquets.radio")
  if err:
   self.VVl8O9(err)
   return
  bRadSortLst = self.VVENOV(lines)
  VVX3wb = []
  subBouquets = {}
  if self.filePath.endswith(".zip"):
   with iZip.ZipFile(self.filePath) as zipF:
    for zipInfo in zipF.infolist():
     fName = os.path.basename(zipInfo.filename)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      with zipF.open(zipInfo.filename) as f:
       row, bnbLst, err = self.VVn7NF(f, mode, len(VVX3wb), zipInfo.filename, False)
       if err:
        return
       tName = os.path.basename(row[9])
       if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
       elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
       VVX3wb.append(row)
       parent = zipInfo.filename
       lst = []
       for fPath in bnbLst:
        for zipInfo in zipF.infolist():
         fName = os.path.basename(zipInfo.filename)
         if fName == fPath:
          with zipF.open(zipInfo.filename) as f:
           row, bnbLst, err = self.VVn7NF(f, mode, len(VVX3wb), zipInfo.filename, True)
           if err:
            return
           lst.append(row)
       if lst:
        subBouquets[tName] = lst
  else:
   with iTar.open(self.filePath) as tar:
    for mem in tar.getmembers():
     fName = os.path.basename(mem.name)
     span = iSearch(r"userbouquet\..+\.(tv|radio)$", fName, IGNORECASE)
     if span:
      mode = span.group(1)
      f = tar.extractfile(mem)
      row, bnbLst, err = self.VVn7NF(f, mode, len(VVX3wb), mem.name, False)
      if err:
       return
      tName = os.path.basename(row[9])
      if   tName in bTvSortLst : row[0] = str(bTvSortLst.index(tName))
      elif tName in bRadSortLst: row[0] = str(1000000 + bRadSortLst.index(tName))
      VVX3wb.append(row)
      parent = mem.name
      lst = []
      for fPath in bnbLst:
       for mem in tar.getmembers():
        fName = os.path.basename(mem.name)
        if fName == fPath:
         f = tar.extractfile(mem.name)
         row, bnbLst, err = self.VVn7NF(f, mode, len(VVX3wb), mem.name, True)
         if err:
          return
         lst.append(row)
      if lst:
       subBouquets[tName] = lst
  if VVX3wb:
   VVX3wb.sort(key=lambda x: int(x[0]))
   for ndx, item in enumerate(VVX3wb): VVX3wb[ndx][0] = str(ndx + 1)
   for key, lst in subBouquets.items():
    for ndx, row in enumerate(VVX3wb):
     if key == os.path.basename(row[9]):
      VVX3wb = VVX3wb[:ndx+1] + lst + VVX3wb[ndx+1:]
      break
   for ndx, item in enumerate(VVX3wb): VVX3wb[ndx][0] = str(ndx + 1)
   VVzgHY = "#11000600"
   VVwmV1  = ("Show Services" , self.VVJnsC  , [], "Reading ..." )
   VVs5AA = (""    , self.VVXQUk, [])
   VVIrDY = ("Options"  , self.VVjfqe, []    )
   header   = ("Num" , "Bouquet Name", "Mode", "Items" , "DVB" , "IPTV", "S.Relay" , "Local" , "Marker" , "Bouquet" , "File")
   widths   = (7  , 36   , 7  , 7   , 7  , 7  , 7   , 7   , 7   , 8   ,  0.01 )
   VVFvCJ  = (CENTER , LEFT   , CENTER, CENTER , CENTER, CENTER, CENTER , CENTER , CENTER , CENTER ,  LEFT )
   FF1Dpj(self.SELF, None, title=self.Title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=24, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVIrDY=VVIrDY, searchCol=1, lastFindConfigObj=CFG.lastFindServers
     , VVDlGi=VVzgHY, VVaSSM=VVzgHY, VVzgHY=VVzgHY, VVkUYa="#00004455", VVivoO="#0a282828")
  else:
   self.VVl8O9("No valid bouquets in:\n\n%s" % self.filePath)
 def VVENOV(self, lines):
  lst = []
  for line in lines:
   span = iSearch(r".+(userbouquet\..+\.(tv|radio))", line, IGNORECASE)
   if span:
    lst.append(span.group(1))
  return lst
 def VVXQUk(self, VVxBfP, title, txt, colList):
  FF90Bc(self.SELF, FFxmTk(txt), title=title)
 def VVjfqe(self, VVxBfP, title, txt, colList):
  mSel = CCHw3d(self.SELF, VVxBfP)
  if VVxBfP.VVQW9r:
   totSel = VVxBfP.VVsyP1()
   if totSel: VVZJ87 = [("Import %s Bouquet%s" % (FFGB9z(str(totSel), VVVjNM), FF1I1d(totSel)), "imp")]
   else  : VVZJ87 = [("Import Bouquet (nothing selected)", )]
  else:
   bName = colList[1]
   if len(bName) > 40: bName = bName[:40] + " .."
   bName = FFGB9z(bName, VVVjNM)
   VVZJ87 = [("Import Selected Bouquet : %s" % bName, "imp")]
  cbFncDict = {"imp": BF(FFJsIX, VVxBfP, BF(CCgpQ0.VVwCcE, self.SELF, VVxBfP, self.filePath))}
  mSel.VVsKHw(VVZJ87, cbFncDict)
 def VVJnsC(self, VVxBfP, title, txt, colList):
  err = ""
  if fileExists(self.filePath):
   lines, err = CCgpQ0.VVNlMX(self.filePath, "lamedb")
   if err:
    self.VVl8O9(err)
    return
   dbServLst = CCdAiy.VV7jZ4(lines, mode=10)
   num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName = VVxBfP.VVc6YJ()
   lines, err = CCgpQ0.VVNlMX(self.filePath, os.path.basename(fName))
   if err:
    self.VVl8O9(err)
    return
   VVX3wb = []
   bnbFound = False
   for line in lines:
    if line.startswith("#SERVICE "):
     span = iSearch(r"1:64:(?:[A-Fa-f0-9]+:){8}:(.+)", line, IGNORECASE)
     if span:
      VVX3wb.append((span.group(1).strip(), "Marker"))
     else:
      span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
      if span:
       VVX3wb.append((span.group(1) or "-", "Sub-Bouquet"))
       bnbFound = True
      else:
       span = iSearch(r"(?:[A-Fa-f0-9]+:){10}http.+:(.+)", line)
       if span:
        VVX3wb.append((span.group(1).strip() or "-", "Stream Relay" if FFqWLZ(line) else "IPTV"))
       else:
        span = iSearch(r"(?:[A-Fa-f0-9]+:){10}(\/.+)", line)
        if span:
         VVX3wb.append((os.path.basename(span.group(1).strip() or "-"), "Local Media"))
        else:
         span = iSearch(r'.+1:7:.+FROM BOUQUET\s+"(.+)"', line, IGNORECASE)
         if span:
          VVX3wb.append((span.group(1) or "-", "Sub-Bouquet"))
          bnbFound = True
         else:
          span = iSearch(r"((?:[A-Fa-f0-9]+:){10})(?:$|:.+)", line)
          if span:
           dbCode = CCdAiy.VVJ0q7(span.group(1))
           for dbCode1, name, prov in dbServLst:
            if dbCode1.upper() in dbCode:
             VVX3wb.append((name.strip() or "-", FFPqiq(span.group(1), False)))
             break
   if bnbFound:
    for ndx, item in enumerate(VVX3wb):
     name, descr = item
     if iMatch(r".+\..+\.tv", name, IGNORECASE):
      lines, err = CCgpQ0.VVNlMX(self.filePath, os.path.basename(name))
      if lines and not err:
       span = iSearch(r"#NAME\s+(.+)", lines[0], IGNORECASE)
       if span:
        bName = span.group(1).strip()
        if bName:
         VVX3wb[ndx] = (bName, descr)
   if VVX3wb:
    VVzgHY = "#11001122"
    bName = iSub(r"\s{4,}" ," .. " , bName)
    header  = ("Service", "Type")
    widths  = (80  , 20 )
    VVFvCJ = (LEFT  , CENTER)
    FF1Dpj(self.SELF, None, title="Services in : %s" % bName, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=28, VVDlGi=VVzgHY, VVaSSM=VVzgHY, VVzgHY=VVzgHY, lastFindConfigObj=CFG.lastFindServers)
   else:
    err = "No valid services !"
  else:
   err = "Cannot open file !"
  if err : FF5uKN(VVxBfP, err, 1500)
  else : VVxBfP.VVW7OH()
 def VVn7NF(self, f, mode, sequence, fPath, isSubB):
  bName = ""
  totItem = totDVB = totMrk = totBnb = totIptv = totSRelay = totLoc = 0
  bnbLst = []
  for line in f:
   try:
    line = str(line.decode()).strip()
   except:
    self.VVl8O9("Encoding Error in the archived file:\n\n%s" % fPath)
    return [], [], "File Encoding Error"
   if line.startswith("#SERVICE "):
    totItem +=1
    if   iMatch(r".+1:64:(?:[A-Fa-f0-9]+:){8}:.+", line)      : totMrk += 1
    elif iMatch(r".+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET.+", line, IGNORECASE) :
     totBnb += 1
     span = iSearch(r'.+1:7:(?:[A-Fa-f0-9]+:){8}FROM BOUQUET\s+"(.+)".+', line)
     if span:
      bnbLst.append(span.group(1))
    elif FFqWLZ(line)             : totSRelay += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}http.+:.+", line, IGNORECASE)   : totIptv += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}\/.+", line)       : totLoc += 1
    elif iMatch(r".+(?:[A-Fa-f0-9]+:){10}(?:$|:.+)", line)      : totDVB += 1
   elif line.startswith("#NAME "):
    bName = line[6:]
  def VVpQZy(var):
   return str(var) if var else VV7jS2 + str(var)
  totItem = VVVCGb + str(totItem)
  bMode = "TV" if mode == "tv" else "Radio"
  if   totBnb : bColor, totBnb  = VVsObI   , str(totBnb)
  elif isSubB : bColor, totBnb  = VVUVAI, "Sub-B."
  else  : bColor, totBnb = ""      , VVpQZy(totBnb)
  row = [str(2000001 + sequence), bColor + bName, bMode, totItem, VVpQZy(totDVB), VVpQZy(totIptv), VVpQZy(totSRelay), VVpQZy(totLoc), VVpQZy(totMrk), totBnb, fPath]
  return row, bnbLst, ""
 @staticmethod
 def VVwCcE(SELF, VVxBfP, archPath):
  title = "Import Bouquets"
  tvBouquetFile = VVNwTu + "bouquets.tv"
  radBouquetFile = VVNwTu + "bouquets.radio"
  if not fileExists(tvBouquetFile):
   FFZoTn(SELF, tvBouquetFile, title=title)
   return
  elif not fileExists(radBouquetFile):
   FFZoTn(SELF, radBouquetFile, title=title)
   return
  isMulti = VVxBfP.VVQW9r
  if isMulti : rows = VVxBfP.VVJKAn()
  else  : rows = [VVxBfP.VVc6YJ()]
  for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
   if totBnb.isdigit():
    FFw5OO(SELF, "Cannot import Sub-Bouquets from:\n\n%s" % FFxmTk(bName), title=title)
    return
  bList = []
  totAllServ = 0
  if fileExists(archPath):
   for num, bName, bMode, totItem, totDVB, totIptv, totSRelay, totLoc, totMrk, totBnb, fName in rows:
    totAllServ += int(FFxmTk(totItem))
    newFile = os.path.basename(fName)
    span = iSearch(r".+\.(.+)\.(tv|radio)", newFile, IGNORECASE)
    if span : fNamePart, fNameExt = span.group(1), span.group(2)
    else : fNamePart, fNameExt = "bouquet", "tv"
    newFile = "userbouquet.%s.%s" % (fNamePart, fNameExt)
    bPath = VVNwTu + newFile
    num  = 0
    while fileExists(bPath):
     num += 1
     newFile = "userbouquet.%s_%d.%s" % (fNamePart, num, fNameExt)
     bPath = VVNwTu + newFile
    CCgpQ0.VVb4cz(archPath, fName, VVNwTu, newFile)
    if fileExists(bPath):
     bList.append(newFile)
  totTP = totServ = totTv = totRad = totMissTP = totMissServ = 0
  if bList:
   FFA11O(tvBouquetFile)
   FFA11O(radBouquetFile)
   for bFile in bList:
    if bFile.endswith("tv") : mainBFile, totTv = tvBouquetFile , totTv  + 1
    else     : mainBFile, totRad = radBouquetFile, totRad + 1
    with open(mainBFile, "a") as f:
     f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
   totTP, totServ, totMissTP, totMissServ = CCgpQ0.VVcha1(SELF, archPath, bList)
   FFAvBD()
  txt  = FFGB9z("Added:\n", VVUVAI)
  txt += "Bouquets\t: %d     (%d TV , %d Radio)\n" % (len(bList), totTv, totRad)
  txt += "Services\t: %d\n" % totAllServ
  if totTP or totServ:
   txt += "\n"
   txt += FFGB9z("Imported to lamedab:\n", VVUVAI)
   if totTP : txt += "Transponders\t: %d\n" % totTP
   if totServ : txt += "Services\t: %d\n"  % totServ
  if totMissTP or totMissServ:
   txt += "\n"
   txt += FFGB9z("Missing from archived lamedb:\n", VVsObI)
   if totMissTP : txt += "Transponders\t: %d\n" % totMissTP
   if totMissServ : txt += "Services\t: %d"  % totMissServ
  FF90Bc(SELF, txt, title=title, width=1000)
 @staticmethod
 def VVcha1(SELF, archPath, bList):
  VVA5X1, err = CCdAiy.VVq36Z(SELF, VVPhms=False)
  if err:
   return 0, 0, 0, 0
  dbServIDs = CCdAiy.VV4Wwj(VVA5X1, mode=11)
  if not dbServIDs:
   return 0, 0, 0, 0
  newDbTpIDs  = []
  newDbServIDs = []
  for bFile in bList:
   lines = FFZQjt(VVNwTu + bFile)
   for line in lines:
    span = iSearch(r"((?:[A-Fa-f0-9]+:){10}$)", line, IGNORECASE)
    if span:
     refCode = span.group(1)
     dbCode = CCdAiy.VVJ0q7(refCode)
     if not dbCode in dbServIDs:
      newDbServIDs.append(dbCode)
      tpID = CCdAiy.VVh6VM(refCode)
      if not tpID in newDbTpIDs:
       newDbTpIDs.append(tpID)
  dbServIDs = None
  tFile = ""
  if newDbServIDs and fileExists(archPath):
   dbName = "lamedb"
   tFile = "/tmp/%s.tmp" % dbName
   fName = CCgpQ0.VVWyKD(archPath, dbName)
   CCgpQ0.VVb4cz(archPath, fName, "/tmp/", dbName + ".tmp")
  newTPLines = []
  if newDbTpIDs:
   for item in CCdAiy.VV4Wwj(tFile, mode=0):
    if item[0].upper() in newDbTpIDs:
     newTPLines.append(item)
  newServLines = []
  for item in CCdAiy.VV4Wwj(tFile, mode=10):
   if item[0].upper() in newDbServIDs:
    newServLines.append(item)
  dbCodeLst = CCdAiy.VV4Wwj(tFile, mode=1)
  totMissTP = 0
  for dbCode in newDbTpIDs:
   if not dbCode in dbCodeLst:
    totMissTP += 1
  dbCodeLst = CCdAiy.VV4Wwj(tFile, mode=11)
  totMissServ = 0
  for dbCode in newDbServIDs:
   if not dbCode in dbCodeLst:
    totMissServ += 1
  FFzyFM(tFile)
  totServ = totTP = 0
  if newDbTpIDs or newServLines:
   isServ = isTP = False
   tmpDbFile = VVA5X1 + ".tmp"
   lines   = FFZQjt(VVA5X1)
   with open(tmpDbFile, "w") as f:
    for line in lines:
     sLine = line.strip()
     if   sLine == "transponders": isTP, isServ = True, False
     elif sLine == "services" : isTP, isServ = False, True
     elif sLine == "end":
      if isTP:
       for item in (newTPLines):
        totTP += 1
        for L in item:
         f.write(L + "\n")
      elif isServ:
       for item in (newServLines):
        totServ += 1
        for L in item:
         f.write(L + "\n")
     f.write(line + "\n")
   FFuB0V("mv -f '%s' '%s'" % (tmpDbFile, VVA5X1))
  return totTP, totServ, totMissTP, totMissServ
 @staticmethod
 def VV89cB(path):
  lst = []
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     lst.append(os.path.basename(zipInfo.filename), zipInfo.filename)
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     lst.append(os.path.basename(mem.name), mem.name)
  return lst
 @staticmethod
 def VVWyKD(path, baseName):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    for zipInfo in zipF.infolist():
     if os.path.basename(zipInfo.filename) == baseName:
      return zipInfo.filename
  else:
   with iTar.open(path) as tar:
    for mem in tar.getmembers():
     if os.path.basename(mem.name) == baseName:
      return mem.name
  return ""
 @staticmethod
 def VVb4cz(path, fName, newPath, newFile):
  if path.endswith(".zip"):
   with iZip.ZipFile(path) as zipF:
    zipInfo = zipF.getinfo(fName)
    zipInfo.filename = newFile
    zipF.extract(zipInfo, newPath)
  else:
   with iTar.open(path) as tar:
    mem = tar.getmember(fName)
    mem.name = newFile
    tar.extract(mem, path=newPath)
 @staticmethod
 def VVNlMX(path, subFile):
  lines = []
  try:
   if path.endswith(".zip"):
    with iZip.ZipFile(path) as zipF:
     for zipInfo in zipF.infolist():
      fName = os.path.basename(zipInfo.filename)
      if fName == subFile:
       with zipF.open(zipInfo.filename) as f:
        lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   else:
    with iTar.open(path) as tar:
     for mem in tar.getmembers():
      fName = os.path.basename(mem.name)
      if fName == subFile:
       f = tar.extractfile(mem)
       lines = f.read().decode().splitlines()
       break
     else:
      return [], "Archived file not found:\n\n%s" % subFile
   return [str(x.strip()) for x in lines], ""
  except:
   return [], "Error while reading the archived file:\n\n%s" % subFile
class CCob8d():
 def __init__(self):
  self.projTitle   = "Package Creator"
  self.projPrefix   = "ajpanel_package_"
  self.projMainPath  = CFG.packageOutputPath.getValue()
  self.projName   = ""
  self.projPath   = ""
  self.projFile   = ""
  self.projMenu   = None
  self.projTable   = None
  self.projFile_control = ""
  self.projFile_preRm  = ""
  self.projFile_postRm = ""
  self.projFile_preInst = ""
  self.projFile_postInst = ""
  self.projLastDepends = ""
  self.VV3Mu1()
 def VV3Mu1(self):
  self.projPkg   = ""
  self.projVer   = ""
  self.projArch   = ""
  self.projFilesSize  = 0
  self.projTotalDirs  = 0
  self.projTotalFiles  = 0
  self.projAct_postInst = 0
  self.projAct_postRm  = 0
 def VVITN2(self):
  FFJsIX(self, self.VVtddb)
 def VVtddb(self):
  if pathExists(self.projMainPath):
   lst = FF11rW(self.projMainPath)
   VVZJ87 = []
   if lst:
    for path in lst:
     if path.startswith(self.projPrefix):
      prName = os.path.basename(path)
      VVZJ87.append((prName, prName))
   if VVZJ87:
    VVZJ87.sort(key=lambda x: x[1].lower())
    VVkUAu = self.VVkv31
    VVbiUc = ("Add new project", self.VV01wB)
    VV3ba7= ("Delete Project" , self.VVbn4R)
    self.projMenu = FFYySC(self, None, VVZJ87=VVZJ87, width=1100, VVkUAu=VVkUAu, VVbiUc=VVbiUc, VV3ba7=VV3ba7, minRows=5, VVDlGi="#22111133", VVaSSM="#22111133")
   else:
    FFNKVM(self, self.VVwdhF, "No projects found !\n\n Create new project ?", title=self.projTitle)
  else:
   self.VV7zP6("Main Packages Directory not found:\n\n%s" % self.projMainPath)
 def VVwdhF(self)    : FFJsIX(self, BF(self.VVKSmA))
 def VV01wB(self, VV4EHV, item) : FFJsIX(self.projMenu, BF(self.VVKSmA))
 def VVKSmA(self):
  c = 0
  while True:
   c += 1
   name = "project_%d" % (c)
   if not pathExists("%s%s%s" % (self.projMainPath, self.projPrefix, name)):
    break
  self.VVbKoa(name)
 def VVbKoa(self, name, cbFnc=None):
  FFaSvq(self, cbFnc or self.VVy1gd, defaultText=name, title="New Project Name", message="Enter project name")
 def VVy1gd(self, name):
  if name and name.strip():
   path = "%s%s%s" % (self.projMainPath, self.projPrefix, name)
   if pathExists(path):
    FFNKVM(self, BF(self.VVbKoa, name), "Project directory already exists !\n\n Change name ?", title=self.projTitle)
   else:
    err = FFjzhy(path)
    if err:
     self.VV7zP6("Cannot create project directory !\n\n %s" % err)
    else:
     item = os.path.basename(path)
     if self.projMenu: self.projMenu.VVYAqb((item, item), isSort=True)
     else   : self.VVITN2()
 def VVbn4R(self, VV4EHV, path):
  if path:
   path = self.projMainPath + path
   if pathExists(path):
    totDir, totFile, totLink = FF9Mxg(path)
    FFNKVM(self, BF(self.VVo16d, path), "Project directory contains %d items.\n\n%s\n\nDelete ?" %(totDir + totFile + totLink, path), title=self.projTitle)
 def VVo16d(self, path):
  if FFuB0V("rm -rf '%s'" % path):
   self.projMenu.VVMQZS()
 def VVkv31(self, item=None):
  if item:
   VV4EHV, txt, Dir, ndx = item
   self.VV3Mu1()
   self.projName = os.path.basename(Dir)[len(self.projPrefix):]
   self.projPath = "%s%s/" % (self.projMainPath, Dir)
   self.projFile = "%s%s.cfg"  % (self.projPath, self.projName)
   self.projFile_control = self.projPath + "control"
   self.projFile_preRm  = self.projPath + "prerm"
   self.projFile_postRm = self.projPath + "postrm"
   self.projFile_preInst = self.projPath + "preinst"
   self.projFile_postInst = self.projPath + "postinst"
   tmplF = "%sajpanel_pkg" % VVrrZu
   if not fileExists(self.projFile_control) and fileExists(tmplF):
    pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
    with open(self.projFile_control, "w") as f:
     for line in FFZQjt(tmplF, keepends=True):
      f.write(line.replace("xx1", pkg).replace("xx2", self.projName))
   if not fileExists(self.projFile):
    with open(self.projFile, "w") as f:
     sep = "#" * 80
     f.write("%s\n" % sep)
     f.write("%s Project\t: %s\n" % ("#", self.projName))
     f.write("%s Started\t: %s\n" % ("#", FFxN8A()))
     f.write("%s\n" % sep)
   if fileExists(self.projFile): self.VVoGcs()
   else      : self.VV7zP6("Cannot create project file:\n\n%s" % self.projFile)
 def VVoGcs(self, VV4EHV=None, jmpDict=None):
  FFJsIX(VV4EHV or self.projTable or self, BF(self.VVbIUl, jmpDict))
 def VVbIUl(self, jmpDict):
  self.VV3Mu1()
  pkgRows, ctrlRows, actnRows, fileRows, unknRows = [], [], [], [], []
  if fileExists(self.projFile_control):
   for lineNdx, line in enumerate(FFZQjt(self.projFile_control)):
    line = line.strip()
    if ":" in line:
     subj, val, rem = self.VV4hKL(line)
     pkgRows.append((str(lineNdx), "Control", subj, val, "", rem, ""))
  if not pkgRows:
   self.VV7zP6('Invalid "control" file:\n\n%s' % self.projFile_control)
   return
  for path in (self.projFile_preInst, self.projFile_postInst, self.projFile_preRm, self.projFile_postRm):
   size = val = ""
   if fileExists(path):
    val = path
    sz = FFqLWj(path)
    if sz > -1: size = CCCXvS.VVutW7(sz, mode=4)
    else   : size = FFGB9z("Size error", VVsObI)
   ctrlRows.append(("", "Script", os.path.basename(path), val, size, "", ""))
  for lineNdx, line in enumerate(FFZQjt(self.projFile)):
   lineNdx = str(lineNdx)
   line = line.strip()
   if line and not line.startswith("#"):
    validF = size = rem = ""
    if line.startswith("/"):
     path, fName, typ, size, rem, validF = self.VVXKaN(line, fileRows)
     fileRows.append((lineNdx, "Resource", typ or "Unknown", path, size, rem, validF))
    else:
     Title, val = self.VVanXP(line)
     if Title: actnRows.append((lineNdx, "Action", Title, val, size, rem, validF))
     else : unknRows.append((lineNdx, "?", "-", line, size, FFGB9z("Unknown value", VVsObI), validF))
  for ndx, row in enumerate(actnRows):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   rem = ""
   if   fileExists(self.projFile_postInst) and Title == "postinst" : rem = "Ignored (if custom postinst)"
   elif fileExists(self.projFile_postRm  ) and Title == "postrm" : rem = "Ignored (if custom postrm)"
   if rem:
    actnRows[ndx] = (lineNdx, Section, Title, Value, Size, FFGB9z(rem, VVsObI), ValidF)
  actnRows.sort(key=lambda x: x[2].lower())
  fileRows.sort(key=lambda x: (x[2].lower(), x[3].lower()))
  unknRows.sort(key=lambda x: x[3].lower())
  VVX3wb = pkgRows
  VVX3wb.extend(actnRows)
  VVX3wb.extend(ctrlRows)
  VVX3wb.extend(fileRows)
  VVX3wb.extend(unknRows)
  cDict = {"Control":"", "Action":"0c302636", "Script":"0a28281a", "Resource":"1100385a", "?":"11550000"}
  for ndx, row in enumerate(VVX3wb):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   color = cDict.get(Section, "")
   if color:
    if ValidF: Remarks = "%s%s" % (FFGB9z("Valid", VVVjNM), " ... " + Remarks if Remarks else "")
    VVX3wb[ndx] = (lineNdx, "#b#%s#" % color + Section, Title, Value, Size, "#b#0a0b0b1b#" + Remarks, ValidF)
  if self.projTable:
   self.projTable.VVcckS(VVX3wb, tableRefreshCB=BF(self.VVeN5m, jmpDict) if jmpDict else None, isSort=False)
  else:
   bg = "#15000000"
   title = "%s : %s" % (self.projTitle, self.projName)
   VVs5AA = (""     , self.VVVes2   , [])
   menuButtonFnc = (""     , self.VVt1TZ   , [])
   VVZ224 = ("Create Package"  , self.VV5kqu , [])
   VVIrDY = ("Post Install Action", self.VVxmwh, [])
   VVFadD = ("Edit File"   , self.VVl3y6  , [])
   header  = ("lineNdx", "Section" , "Title" , "Value / Path", "Size", "Remarks" , "ValidF")
   widths  = (0  , 9   , 11  , 48   , 10 , 22  , 0   )
   VVFvCJ = (CENTER , CENTER , LEFT  , LEFT   , CENTER, LEFT  , CENTER )
   self.projTable = FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, width=1850, height=1040, VVTFXq=26, VVs5AA=VVs5AA, menuButtonFnc=menuButtonFnc, VVZ224=VVZ224, VVIrDY=VVIrDY, VVFadD=VVFadD, searchCol=2
         , VVDlGi=bg, VVaSSM=bg, VVzgHY=bg, VVkUYa="#00664411", VVivoO="#00444444", VVdjpa="#08442211")
   self.projTable.VVByXR(self.VVY16I)
   self.VVY16I()
 def VVeN5m(self, jmpDict, VVxBfP, title, txt, colList):
  self.projTable.VVp2CY(jmpDict)
 def VVY16I(self):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = self.projTable.VVc6YJ()
  if Section == "Control":
   txt = '"control" File'
  elif Section == "Script" :
   txt = "Script File"
   if Value.startswith("/") and fileExists(Value):
    txt = "Script File"
   else:
    self.projTable["keyBlue"].hide()
    return
  else:
   txt = "Project File"
  self.projTable["keyBlue"].show()
  self.projTable["keyBlue"].setText("Edit %s" % txt)
 def VV4hKL(self, line):
  def VVzU5F(patt, val, Len):
   if len(val) < Len   : return FFGB9z("Length error" , VVsObI)
   elif not iMatch(patt, val) : return FFGB9z("Invalid format" , VVsObI)
   else      : return ""
  subj, _, val = line.partition(":")
  val, rem = val.strip(), ""
  if   not self.projPkg  and subj == "Package"  : self.projPkg, rem = val, VVzU5F(r"^[a-z]+[a-z0-9+-_.]+$", val, 2)
  elif not self.projVer  and subj == "Version"  : self.projVer, rem = val, VVzU5F(r"^[a-zA-Z0-9_+-.~]*$" , val, 1)
  elif not self.projArch and subj == "Architecture": self.projArch = val
  return subj, val, rem
 def VVXKaN(self, path, fileRows):
  rem = note = validF = targetType = ""
  size = "-"
  isCtrl = False
  fName = os.path.basename(path)
  typ = FFxuAp(path)
  path = FFAxSo(path)
  c = VVsObI
  if   typ == "Mount" : rem = FFGB9z("Not allowed", c)
  elif not typ  : rem = FFGB9z("Not found", c)
  else:
   for item in fileRows:
    if item[3].strip() == path:
     rem = FFGB9z("Duplicate", c)
     break
   else:
    sz = -1
    skipSz = False
    if typ == "Directory":
     sz = FFkSE4(path)
    elif typ == "SymLink":
     targetPath = os.path.realpath(path)
     targetType = FFxuAp(targetPath)
     if  targetType == "Mount"  : skipSz, rem = True, FFGB9z("Not allowed", c)
     elif targetType == "Directory" : sz = FFkSE4(targetPath)
     elif targetType == "File"  : sz = FFqLWj(targetPath)
     else       : sz, rem = FFqLWj(path), FFGB9z("Invalid", c)
     note = "%s%s%s" % (note, " ... " if note else "", "Linked to : %s" % targetPath)
    elif typ == "File":
     sz = FFqLWj(path)
    if not skipSz:
     if sz > -1:
      validF = "" if rem else "1"
      if validF:
       if "Directory" in (typ, targetType) : self.projTotalDirs  += 1
       if "File" in (typ, targetType)  : self.projTotalFiles += 1
       self.projFilesSize += sz
      size = CCCXvS.VVutW7(sz, mode=4)
     else:
      size = FFGB9z("Size error", c)
    rem = "%s%s%s" % (rem, " ... " if rem else "", note)
  return path, fName, typ, size, rem, validF
 def VVanXP(self, line):
  Title = val = ""
  actDict = {"restart":1, "reboot":2 }
  span = iSearch(r"postinst\s*=\s*(.+)", line, IGNORECASE)
  if span:
   act = span.group(1).lower()
   self.projAct_postInst = actDict.get(act, 0)
   Title, val = "postinst", "%s after the package is installed" % act.capitalize()
  else:
   span = iSearch(r"postrm\s*=\s*(.+)", line, IGNORECASE)
   if span:
    act = span.group(1).lower()
    self.projAct_postRm = actDict.get(act, 0)
    Title, val = "postrm", "%s after the package is removed" % act.capitalize()
  return Title, val
 def VVl3y6(self, VVxBfP, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  if   Section == "Control": path, lineNdx = self.projFile_control, int(lineNdx)
  elif Section == "Script" : path, lineNdx = Value, 0
  else      : path, lineNdx = self.projFile, int(lineNdx)
  if fileExists(path) : CCQ3ND(self, path, VVCeou=self.VV9x38, curRowNum=lineNdx)
  else    : FFZoTn(self, path)
 def VV9x38(self, fileChanged):
  if fileChanged:
   self.VVoGcs()
 def VV7zP6(self, txt):
  FFw5OO(self, txt, title=self.projTitle)
 def VVVes2(self, VVxBfP, title, txt, colList):
  tab = lambda x, y: "%s\t: %s\n" % (x, y)
  c = VVUVAI
  s  = FFfR82("Current Row", c)
  s += title + "\n"
  s += txt + "\n"
  s += FFfR82("Project", c)
  s += tab("File Name", self.projFile)
  s += tab("Valid Dirs", self.projTotalDirs)
  s += tab("Valid Files", self.projTotalFiles)
  s += tab("Total Size", CCCXvS.VVutW7(self.projFilesSize))
  FF90Bc(self, s, title="Project Info", width=1600)
 def VVt1TZ(self, VVxBfP, title, txt, colList):
  lineNdx, Section, Title, Value, Size, Remarks, ValidF = colList
  c1, c2, c3 = VVkIQ9, VVWOjU, VVUVAI
  VVZJ87 = []
  VVZJ87.append((c1 + "Add Resource File"  , "addFile" ))
  VVZJ87.append((c1 + "Add Resource Directory" , "addDir" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Change Package Name"   , "pkgNam" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c2 + "Add Dependency"   , "addDep" ))
  VVZJ87.append((c2 + "Remove Dependency"  , "delDep" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Import Control File (control/preinst/prerm/postinst/postrm)", "ctrlFMan"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c3 + 'Import Control Data from an Installed Package' , "ctrlImprt" ))
  VVZJ87.append(FFnqNr('Undo Last "control" File Changes'   , "ctrlUndo" , fileExists(self.projFile_control + ".bak"), c3))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(FFnqNr("Delete Current Row (from Project File)" , "delRow"  , Section not in ("Control", "Script")   , VVsObI))
  FFYySC(self, self.VVVlhD, VVZJ87=VVZJ87, width=1050, title="Options", VVDlGi="#11001122", VVaSSM="#11001122")
 def VVVlhD(self, item=None):
  if item:
   if   item == "addFile" : self.VVWWob(False)
   elif item == "addDir" : self.VVWWob(True)
   elif item == "pkgNam" : self.VVgQFz()
   elif item == "addDep" : FFJsIX(self.projTable, self.VVI8Nx)
   elif item == "delDep" : self.VV17c1()
   elif item == "ctrlFMan" : self.VVgmMq()
   elif item == "ctrlImprt": FFJsIX(self.projTable, self.VVuYxT)
   elif item == "ctrlUndo" : self.VV7VZg()
   elif item == "delRow" : self.VVmANG()
 def VVWWob(self, isDir):
  Dir = FF0y7s(CFG.lastPkgProjDir.getValue(), False)
  if isDir: self.session.openWithCallback(self.VVg9oX, BF(CCCXvS, mode=CCCXvS.VVutD6, VVMbDq=Dir))
  else : self.session.openWithCallback(self.VVg9oX, BF(CCCXvS, patternMode="all", VVMbDq=Dir))
 def VVg9oX(self, path):
  if path:
   FFdEZ4(CFG.lastPkgProjDir, path)
   self.VVcv01(path, 2)
 def VVgmMq(self):
  Dir = FF0y7s(CFG.lastPkgProjDir.getValue(), False)
  self.session.openWithCallback(self.VVmFOk, BF(CCCXvS, patternMode="pkgCtrl", VVMbDq=Dir))
 def VVmFOk(self, path):
  if path:
   FFdEZ4(CFG.lastPkgProjDir, path)
   fName = os.path.basename(path)
   if FFuB0V("cp -f '%s' '%s'" % (path, self.projPath + fName)):
    self.VVoGcs()
    self.projTable.VVp2CY({1:"Script", 2:fName})
 def VVuYxT(self):
  cmd = FF8jae(VVcrnB, "")
  if not cmd:
   FFgq4o(self)
   return
  lst = FFnAC3(cmd)
  if lst:
   err = CCCXvS.VVgw5W(lst, fromFind=False)
   if err:
    self.VV7zP6(err)
    return
   lst.sort()
   VVX3wb = []
   for item in lst:
    span = iSearch(r"(.+) - (.+)", item)
    if span:
     VVX3wb.append(("", span.group(1), span.group(2)))
   if VVX3wb:
    VVX66G = ("Import 'control' data", self.VVbAxV, [])
    VVIrDY = ("Package Info.", self.VVX6BQ     , [])
    header = ("dum", "Package" , "Version" )
    widths = (0 , 70  , 30  )
    FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVhAo0=widths, VVTFXq=30, VVX66G=VVX66G, VVIrDY=VVIrDY, VVqC9o=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
      , VVDlGi="#22110011", VVaSSM="#22191111", VVzgHY="#22191111", VVkUYa="#00003030", VVivoO="#00333333")
   else:
    self.VV7zP6("Cannot process installed packages !")
  else:
   self.VV7zP6("Cannot read installed packages !")
 def VV7VZg(self):
  if FFuB0V("mv -f '%s' '%s'" % (self.projFile_control + ".bak", self.projFile_control)):
   self.VVoGcs(jmpDict={1:"Control", 2:"Package"})
  else:
   self.VV7zP6("Process Failed !")
 def VVbAxV(self, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VVFwx9, VVxBfP, colList[1]))
 def VVFwx9(self, VVxBfP, pkg):
  lines = []
  for line in FFnAC3(FFETOG(VVqsbt, pkg)):
   span = iSearch(r"^([A-Z].+):\s*.+", line)
   if span and span.group(1) in ("Package", "Version", "Depends", "Section", "Architecture", "Maintainer", "Source", "Description"):
    lines.append(line)
  if lines: FFNKVM(self, BF(self.VVERjy, VVxBfP, lines), "Replace current fields ?", title="Import Control Fields")
  else : self.VV7zP6("Cannot import from this package:\n\n%s" % pkg)
 def VVERjy(self, VVxBfP, lines):
  VVxBfP.cancel()
  FFn7Bv(self.projFile_control)
  with open(self.projFile_control, "w") as f:
   for line in lines:
    f.write(line.strip()+ "\n")
  self.VVoGcs(jmpDict={1:"Control", 2:"Package"})
 def VVmANG(self):
  lineNum = int(self.projTable.VVc6YJ()[0]) + 1
  FFuB0V("sed -i.bak -e '%dd' '%s'" % (lineNum, self.projFile))
  self.VVoGcs()
 def VVcv01(self, line, jmp):
  if fileExists(self.projFile):
   FFn7Bv(self.projFile)
   FFA11O(self.projFile)
   with open(self.projFile, "a") as f:
    f.write("%s\n" % line)
   if   jmp == 1: jmpDict = {1:"Action" , 2:line.split("=")[0]}
   elif jmp == 2: jmpDict = {1:"Resource" , 3:line.strip().rstrip("/")}
   else   : jmpDict = None
   self.VVoGcs(jmpDict=jmpDict)
  else:
   FFZoTn(self, self.projFile, title=self.projTitle)
 def VVxmwh(self, VVxBfP, title, txt, colList):
  VVZJ87 = []
  VVZJ87.append(FFnqNr("No-Action after installation" , "instNon", self.projAct_postInst != 0))
  VVZJ87.append(FFnqNr("Restart after installation" , "instRes", self.projAct_postInst != 1))
  VVZJ87.append(FFnqNr("Reboot after installation"  , "instReb", self.projAct_postInst != 2))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(FFnqNr("No-Action after removal" , "rmNon", self.projAct_postRm != 0))
  VVZJ87.append(FFnqNr("Restart after removal" , "rmRes", self.projAct_postRm != 1))
  VVZJ87.append(FFnqNr("Reboot after removal"  , "rmReb", self.projAct_postRm != 2))
  FFYySC(self, self.VV0rX8, VVZJ87=VVZJ87, title="Action (after the package is installed/removed)")
 def VV0rX8(self, item=None):
  if item:
   if   item == "instNon" : self.VVXALW("postinst", 0)
   elif item == "instRes" : self.VVXALW("postinst", 1)
   elif item == "instReb" : self.VVXALW("postinst", 2)
   elif item == "rmNon" : self.VVXALW("postrm", 0)
   elif item == "rmRes" : self.VVXALW("postrm", 1)
   elif item == "rmReb" : self.VVXALW("postrm", 2)
 def VVXALW(self, subj, val):
  if fileExists(self.projFile):
   lines = FFZQjt(self.projFile)
   FFn7Bv(self.projFile)
  else:
   lines = []
  inFile = False
  with open(self.projFile, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if not iMatch(r"%s\s*=.+" % subj, line, IGNORECASE) : f.write(line + "\n")
    else            : inFile = True
  if val > 0: self.VVcv01("%s=%s" % (subj, {1:"restart", 2:"reboot"}.get(val, "")), 1)
  elif inFile: self.VVoGcs()
 def VVgQFz(self):
  pkg = iSub(r"([^\x00-\x7F]+)", r"_", self.projName, flags=IGNORECASE).lower()
  VVZJ87 = []
  VVZJ87.append((pkg, pkg))
  VVZJ87.append(VVoqHH)
  for s in ("extensions", "systemplugins", "", "skins", "picons", "softcams", "", "drivers", "security", "settings"):
   if s:
    name = "enigma2-plugin-%s-%s" % (s, pkg)
    c = VVUVAI if name == self.projPkg else ""
    VVZJ87.append((c + name, name))
   else:
    VVZJ87.append(VVoqHH)
  FFYySC(self, self.VVaPyE, VVZJ87=VVZJ87, title="Package Name")
 def VVaPyE(self, item=None):
  if item:
   self.VVZ34I("Package", item)
 def VVI8Nx(self):
  lst = set()
  for s in ("d", "o", "i"):
   path = "/var/lib/%spkg/status" % s
   if fileExists(path):
    with open(path, "r") as f:
     for line in f:
      if line.startswith(("Package:", "Depends:", "Recommends:", "Suggests:", "Conflicts:", "Replaces:", "Breaks:", "Provides:")):
       line = line.split(":", 1)[1]
       for dep in line.split(","):
        lst.add(dep.strip())
  if lst:
   VVZJ87 = []
   for item in lst: VVZJ87.append((item, item))
   VVZJ87.sort(key=lambda x: x[0].lower())
   VV4EHV = FFYySC(self, self.VV5bST, VVZJ87=VVZJ87, width=1100, title="Add Dependency")
   if self.projLastDepends:
    VV4EHV.VVCLkK(self.projLastDepends)
  else:
   self.VV7zP6("Cannot read dependencies list !")
 def VV5bST(self, item=None):
  if item:
   lst = []
   self.projLastDepends = item
   if fileExists(self.projFile_control):
    for line in FFZQjt(self.projFile_control):
     if line.startswith("Depends:"):
      lst = list(map(str.strip, line[8:].split(",")))
      break
   if not item in lst:
    lst.append(item)
    self.VVZ34I("Depends", ", ".join(lst))
   else:
    FF5uKN(self.projTable, "Already added", 1500)
    self.projTable.VVp2CY({1:"Control", 2:"Depends"})
 def VV17c1(self):
  lst = []
  for row in self.projTable.VVlHja():
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Title == "Depends":
    lst = list(map(str.strip, Value.split(",")))
    break
  if lst:
   VVZJ87 = []
   for item in lst: VVZJ87.append((item, item))
   FFYySC(self, BF(self.VVrmXP, lst), VVZJ87=VVZJ87, title="Remove Dependency")
  else:
   self.VV7zP6("No dependencies to remove !")
 def VVrmXP(self, lst, item=None):
  if item:
   for ndx, dep in enumerate(lst):
    if dep == item:
     del lst[ndx]
     break
   if lst:
    self.VVZ34I("Depends", ", ".join(lst))
   else:
    FFuB0V("sed -i '/Depends:*/d' '%s'" % self.projFile_control)
    self.VVoGcs()
 def VVZ34I(self, subj, val):
  lines = FFZQjt(self.projFile_control) if fileExists(self.projFile_control) else []
  inFile = False
  with open(self.projFile_control, "w") as f:
   for ndx, line in enumerate(lines):
    line = line.strip()
    if iMatch(r"%s\s*:\s*.+" % subj, line):
     line = "%s: %s" % (subj, val)
     inFile = True
    f.write(line + "\n")
   if not inFile:
    f.write("%s: %s\n" % (subj, val))
  self.VVoGcs(jmpDict={1:"Control", 2:subj})
 def VV5kqu(self, VVxBfP, title, txt, colList):
  VVZJ87 = []
  VVZJ87.append(("Create .ipk"  , "ipk"))
  VVZJ87.append(("Create .deb"  , "deb"))
  VVZJ87.append(("Create .tar.gz" , "tar"))
  FFYySC(self, self.VVEMZD, VVZJ87=VVZJ87, width=500, title=self.projTitle)
 def VVEMZD(self, item=None):
  if item:
   FFJsIX(self.projTable, BF(self.VVowTD, item))
 def VVowTD(self, item):
  if self.projTotalDirs + self.projTotalFiles == 0:
   self.VV7zP6("No Dirs/Files found !\n\nYou need to add at least 1 directory or 1 file to the project !")
   return
  if   item in ("ipk", "tar") : VVFsmA, tarParam, tarExt = False, "-czhf", ".tar.gz"
  elif item == "deb"   : VVFsmA, tarParam, tarExt = True , "-cJhf", ".tar.xz"
  if   not self.projPkg : err = "Package"
  elif not self.projVer : err = "Version"
  elif not self.projArch : err = "Architecture"
  else     : err = ""
  if err:
   VV7zP6(self, 'Parameter "%s" not found !' % err)
   return
  if item == "tar": pName, arch, ext = self.projName, "", "tar.gz"
  else   : pName, arch, ext = self.projPkg , self.projArch, item
  pkgFile = "%s%s_%s_%s.%s" % (CFG.packageOutputPath.getValue(), pName, self.projVer, arch, ext)
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  dataTmpPath  = projDir + "DATA/"
  dataFile  = projDir + "data" + tarExt
  removePorjDir = FFIV1X("rm -rf '%s'" % projDir) + ";"
  ctrlDir   = "%sCONTROL" % projDir
  controlTarF  = projDir + "control" + tarExt
  controlFile  = "%s/control" % ctrlDir
  debianFile  = projDir + "debian-binary"
  result = "Package:"
  failed= "Process Failed."
  resCmd  = " if [ -f '%s' ]; then "  % pkgFile
  resCmd += "  echo -e '\n%s\n%s' %s;" % (result, pkgFile, FFXRSi(result  , VVVjNM))
  resCmd += " else"
  resCmd += "  echo -e '\n%s' %s;"  % (failed, FFXRSi(failed, VVGe5h))
  resCmd += " fi;"
  cmd  = ""
  cmd += FFIV1X("rm -f '%s'" % pkgFile) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % dataTmpPath
  linkLst = []
  ctrlLst = []
  for ndx, row in enumerate(self.projTable.VVlHja()):
   lineNdx, Section, Title, Value, Size, Remarks, ValidF = row
   if Section == "Control":
    ctrlLst.append("%s: %s" % (Title, Value))
   elif ValidF:
    Dir = os.path.dirname(Value)
    cmd += "mkdir -p '%s%s';"  % (dataTmpPath, Dir)
    cmd += "ln -sf '%s' '%s%s';" % (Value, dataTmpPath, Value)
  if item == "tar":
   cmd += "echo 'Processing Data Files ...';"
   cmd += "tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, pkgFile)
   cmd += resCmd
   cmd += removePorjDir
   FF1Q61(self, cmd)
   return
  cmd += "mkdir -p '%s';"  % ctrlDir
  cmd += " echo '2.0' > %s;" % debianFile
  if not FFuB0V(cmd) or not pathExists(ctrlDir):
   VV7zP6(self, "Preparation Failed")
   return
  else:
   with open(controlFile, "w") as f:
    for item in ctrlLst:
     f.write("%s\n" % item)
  fName = ("prerm"     ,"preinst"      ,"postrm"     , "postinst"     )
  srcF  = (self.projFile_preRm  , self.projFile_preInst   , self.projFile_postRm  , self.projFile_postInst  )
  line  = ("Removing package : xx ...", "Installing Package : xx ..." , "Package removed (xx)." , "Installation completed (xx)" )
  act   = (0       , 0        , self.projAct_postRm  , self.projAct_postInst   )
  def VVzU5F(act):
   if   act == 1: return "echo 'RESTARTING GUI ...'\nif which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
   elif act == 2: return "echo 'REBOOTING DEVICE ...'\nsleep 3; reboot\n"
   else   : return "echo 'echo 'You may need to Restart GUI.'\n"
  for fName, srcF, line, act in zip(fName, srcF, line, act):
   dstF = os.path.join(ctrlDir, fName)
   if fileExists(srcF):
    FFuB0V("cp -f '%s' '%s'" % (srcF, dstF))
   else:
    with open(dstF, "w") as f:
     f.write("#!/bin/bash\n")
     f.write("echo '%s'\n" % line.replace("xx", self.projPkg))
     f.write(VVzU5F(act) if srcF in (self.projFile_postInst, self.projFile_postRm) else "")
     f.write("exit 0\n")
   FFA11O(dstF)
   FFuB0V("chmod 755 '%s'" % dstF)
  cmd  = ""
  cmd += FFcMGy()
  if VVFsmA:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF09Tg("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  cmd += "cd '%s';" % dataTmpPath
  cmd += " echo 'Processing Control Files ...';"
  cmd += " cd '%s';"   % ctrlDir
  cmd += " tar %s '%s' ./*;" % (tarParam, controlTarF)
  cmd += " echo 'Processing Data Files ...';"
  cmd += " tar -C '%s' %s '%s' ./;" % (dataTmpPath, tarParam, dataFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlTarF, "control.tar")
  cmd += checkCmd % (dataFile   , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (pkgFile, debianFile, controlTarF, dataFile)
  cmd += " fi;"
  cmd +=  resCmd
  cmd += "fi;"
  cmd += removePorjDir
  FF1Q61(self, cmd)
class CCXYqv(Screen, CCob8d):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 850, 800, 50, 40, 30, "#221a001a", "#22110011", 30)
  self.session   = session
  self.lastSelectedRow = -1
  CCob8d.__init__(self)
  c1, c2, c3, c4 = VVkIQ9, VVWOjU, VVMrXw, VVUVAI
  VVZJ87 = []
  VVZJ87.append((c1 + "Plugins Browser"        , "pluginsBrowser"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c2 + "Download/Install Packages (from image feeds)", "downloadInstallPackages" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c3 + "Remove Packages (show all)"     , "VVh5btsAll"  ))
  VVZJ87.append((c3 + "Remove Packages (Plugins/SoftCams/Skins)" , "removePluginSkinSoftCAM" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c2 + "Update Packages List from Feed"    , "VVCAeb"  ))
  VVZJ87.append((c2 + "Upgradable Packages"       , "VVpzjT" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c4 + "Package Creator (ipk/deb/tar.gz)"   , "packageCreator"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Packaging Tool"         , "VVcMHV"   ))
  VVZJ87.append(("Active Feeds"          , "VVXnbr"   ))
  FFmmH7(self, VVZJ87=VVZJ87)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "pluginsBrowser"    : CCo7ti.VVjodP(self)
   elif item == "downloadInstallPackages"  : FFJsIX(self, BF(self.VVr2zQ, 0, ""))
   elif item == "VVh5btsAll"   : FFJsIX(self, BF(self.VVr2zQ, 1, ""))
   elif item == "removePluginSkinSoftCAM"    : FFJsIX(self, BF(self.VVr2zQ, 2, "| grep -e skin -e enigma2-"))
   elif item == "VVCAeb"   : CCXYqv.VVCAeb(self)
   elif item == "VVpzjT"  : FFJsIX(self, self.VVpzjT)
   elif item == "packageCreator"    : self.VVITN2()
   elif item == "VVcMHV"    : self.VVcMHV()
   elif item == "VVXnbr"    : FFJsIX(self, self.VVXnbr)
   else          : self.close()
 def VVXnbr(self):
  files = []
  for s in ("d", "o", "i"):
   files.extend(iGlob("/var/lib/%spkg/lists/*" % s))
  VVX3wb = []
  if files:
   for path in files:
    tot = 0
    with open(path, "r") as f:
     for line in f:
      if line.startswith("Package:"): tot += 1
    VVX3wb.append((os.path.basename(path), str(tot)))
  if VVX3wb:
   VVX3wb.sort(key=lambda x: x[0].lower())
   header  = ("Feed","Packages")
   widths  = (82  , 18  )
   VVFvCJ = (LEFT  , CENTER )
   FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, width=1000, VVTFXq=26, VVqDAH=2)
  else:
   self.VV7zP6("Cannot read packages list !")
 def VVpzjT(self, VVxBfP=None):
  lst = FFnAC3(FF8jae(VVm6ci, ""))
  VVX3wb = []
  if lst:
   lst.sort(key=lambda x: x.lower())
   for line in lst:
    pkg = curV = newVer = ""
    span = iSearch(r"(.+) - (.+) - (.+)", line)
    if span:
     pkg, curV, newVer = span.group(1), span.group(2), span.group(3)
    else:
     span = iSearch(r"(.+) (.+) (.+) \[upgradable from: (.+)\]", line)
     if span:
      pkg, newVer, arch, curV = span.group(1), span.group(2), span.group(3), span.group(4)
    if all((pkg, curV, newVer)):
     VVX3wb.append((str(len(VVX3wb) + 1), pkg, curV, newVer))
   if VVX3wb:
    if VVxBfP:
     VVxBfP.VVcckS(VVX3wb, VVuO90Msg=True)
    else:
     bg = "#00221111"
     VVX66G = ("Upgrade", self.VV0yZe   , [])
     VVIrDY = ("Package Info.", self.VVX6BQ , [])
     header  = ("Num" ,"Package" ,"Version" , "New Version" )
     widths  = (6  , 42  , 26  , 26   )
     VVFvCJ = (CENTER , LEFT  , LEFT  , LEFT   )
     FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, width=1700, VVTFXq=26, VVX66G=VVX66G, VVIrDY=VVIrDY, VVUdUN=True, VVcLcW=0, searchCol=1, lastFindConfigObj=CFG.lastFindPackages, VVDlGi=bg, VVaSSM=bg, VVzgHY=bg, VVqSOL="#00ffff55", VVkUYa="#00003040")
  if not VVX3wb:
   FFzLBa(self, "Nothing to upgrade", 1500)
   if VVxBfP: VVxBfP.cancel()
 def VV0yZe(self, VVxBfP, title, txt, colList):
  pkg = colList[1]
  cmd = FFETOG(VV33Lu, pkg)
  if cmd : FF1Q61(self, cmd, title="Installing : %s" % pkg, VVYxQ2=BF(self.VVpzjT, VVxBfP))
  else : FFgq4o(SELF)
 def VVcMHV(self):
  pkg = FFX0mI()
  aptT = "apt - Advanced Package Tool" if FFhcfU("apt") else ""
  txt = {"ipkg": "Itsy", "opkg": "Open", "dpkg": "Debian"}.get(pkg, "")
  txt = "%s - %s Package Management System" % (pkg, txt) if txt else ""
  txt += "%s%s" % ("\n\nand\n\n" if txt and aptT else "", aptT)
  FF15cM(self, txt or "No packaging tools found!")
 def VVr2zQ(self, mode, grep, VVxBfP=None, title=""):
  if   mode == 0: cmd = FF8jae(VVBCs3    , grep)
  elif mode == 1: cmd = FF8jae(VVcrnB , grep)
  elif mode == 2: cmd = FF8jae(VVcrnB , grep)
  if not cmd:
   FFgq4o(self)
   return
  VVX3wb = FFnAC3(cmd)
  if VVX3wb:
   err = CCCXvS.VVgw5W(VVX3wb, fromFind=False)
   if err:
    FFw5OO(self, err)
    return
  else:
   if VVxBfP: VVxBfP.VVW7OH()
   FFw5OO(self, "No packages found!")
   return
  wordsToSkip = ("base", "conf", "config", "configs", "common", "common3", "core", "bin", "feed", "enigma", "mount", "opkg", "samba4", "utils")
  PLUGIN  = "enigma2-plugin-"
  VVarfR  = []
  for item in VVX3wb:
   parts = item.split(" - ")
   if len(parts) > 1:
    package = parts[0]
    version = parts[1]
    parts  = package.split("-")
    totItems = len(parts)
    if "feed" in package:
     name ="feed"
    elif totItems > 3:
     if package.startswith(PLUGIN):
      if totItems > 4 and parts[4][:1].isdigit() : name = parts[3]
      elif totItems > 3       : name = "-".join(parts[3:])
      else          : name = package
     else:
      for item in reversed(parts):
       if len(item) > 3 and item.isalpha():
        if not "." in item and not item.isdigit() and not item in (wordsToSkip):
         name = item
         break
      else:
       name = parts[0]
    else:
     name = package
    VVarfR.append((name, package, version))
  if mode > 0:
   extensions = FFnAC3("ls %s -l | grep '^d' | awk '{print $9}'" % VVh8TB)
   for item in extensions:
    if not "__pycache__" in item:
     for row in VVarfR:
      if item.lower() == row[0].lower():
       break
     else:
      name = item
      if name == VV1aX3: name += "el"
      VVarfR.append((name, VVh8TB + item, "-"))
   systemPlugins = FFnAC3("ls %s -l | grep '^d' | awk '{print $9}'" % VVZk2h)
   for item in systemPlugins:
    if not "__pycache__" in item:
     for row in VVarfR:
      if item.lower() == row[0].lower():
       break
     else:
      VVarfR.append((item, VVZk2h + item, "-"))
  if not VVarfR:
   FFw5OO(self, "No packages found!")
   return
  if VVxBfP:
   VVarfR.sort(key=lambda x: x[0].lower())
   VVxBfP.VVcckS(VVarfR, title)
  else:
   widths = (20, 50, 30)
   VVX66G = None
   VVFadD = None
   if mode == 0:
    VVZ224 = ("Install" , self.VVBUpr   , [])
    VVX66G = ("Download" , self.VVYhDn   , [])
    VVFadD = ("Filter"  , self.VV3AYy , [])
   elif mode == 1:
    VVZ224 = ("Uninstall", self.VVh5bt, [])
   elif mode == 2:
    VVZ224 = ("Uninstall", self.VVh5bt, [])
    widths= (18, 57, 25)
   VVarfR.sort(key=lambda x: x[0].lower())
   VVIrDY = ("Package Info.", self.VVX6BQ, [])
   header   = ("Name" ,"Package" , "Version" )
   FF1Dpj(self, None, header=header, VVarfR=VVarfR, VVhAo0=widths, VVTFXq=28, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, VVqC9o=self.lastSelectedRow, lastFindConfigObj=CFG.lastFindPackages
     , VVDlGi="#22110011", VVaSSM="#22191111", VVzgHY="#22191111", VVkUYa="#00003030", VVivoO="#00333333")
 def VVX6BQ(self, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VVrhv7, VVxBfP, colList[1]))
 def VVrhv7(self, VVxBfP, pkg):
  if pathExists(pkg):
   pkg, err = CCXYqv.VVMWQB(pkg)
   if err:
    FFzLBa(VVxBfP, err, 1000)
    return
  CCXYqv.VVnhoE(self, pkg)
 def VV3AYy(self, VVxBfP, title, txt, colList):
  words  = ("Alsa", "Dream", "Drivers", "Enigma", "Extensions", "Feeds", "Firmware", "GLibc", "GStreamer", "Kernel", "Lib", "Linux", "Locale", "Network", "Octagon", "PIcons", "Perl", "Pkg", "Plugin", "Python", "Samba", "Settings", "Skin", "SoftCam", "SystemPlugins", "Tools", "Util", "Zip")
  VVZJ87 = []
  VVZJ87.append(("All Packages", "all"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Plugin/SoftCAM/Skin", "plugins"))
  VVZJ87.append(VVoqHH)
  for word in words:
   VVZJ87.append((word, word))
  FFYySC(self, BF(self.VV5joj, VVxBfP), VVZJ87=VVZJ87, title="Select Filter")
 def VV5joj(self, VVxBfP, item=None):
  if item:
   if item == "all":
    titleTxt = "All"
    grep = ""
   elif item == "plugins":
    titleTxt = "Plugin/SoftCAM/Skin"
    grep  = "| grep '^enigma2-plugin-' | grep 'extensions\|systemplugins\|softcams\|skin'"
   else:
    titleTxt = item
    word = item.lower()
    if word.endswith("s"):
     word = word[:-1]
    grep = "| grep '%s'" % word
   FFJsIX(VVxBfP, BF(self.VVr2zQ, 0, grep, VVxBfP, "Download/Install (Filter = %s)" % titleTxt), title="Filtering ...")
 def VVh5bt(self, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VV307D, VVxBfP, colList[1]))
 def VV307D(self, VVxBfP, package):
  if pathExists(package):
   pkg, err = CCXYqv.VVMWQB(package)
   if pkg:
    package = pkg
  if package.startswith((VVh8TB, VVZk2h)):
   FFNKVM(self, BF(self.VVAXum, VVxBfP, package), "Delete Plugin Folder ?\n\n%s" % package)
  else:
   VVZJ87 = []
   VVZJ87.append(("Remove Package"         , "remove_ExistingPackage" ))
   VVZJ87.append(("Remove Package (force remove)"     , "remove_ForceRemove"  ))
   VVZJ87.append(("Remove Package (ignore failed dependencies)"  , "remove_IgnoreDepends" ))
   FFYySC(self, BF(self.VVB8R0, VVxBfP, package), VVZJ87=VVZJ87)
 def VVAXum(self, VVxBfP, package):
  cmd  = "echo -e 'Deleting plugin directory:\n%s\n';" % package
  cmd += "rm -rf '%s' &>/dev/null %s" % (package, VV5wTt)
  FF1Q61(self, cmd, VVYxQ2=BF(self.VVZHuD, VVxBfP))
 def VVB8R0(self, VVxBfP, package, item):
  if item:
   if   item == "remove_ExistingPackage" : cmdOpt = VVi1yR
   elif item == "remove_ForceRemove"  : cmdOpt = VVbez3
   elif item == "remove_IgnoreDepends"  : cmdOpt = VV0vnU
   FFNKVM(self, BF(self.VVNmhU, VVxBfP, package, cmdOpt), "Remove Package ?\n\n%s" % package)
 def VVNmhU(self, VVxBfP, package, cmdOpt):
  self.lastSelectedRow = VVxBfP.VVgu5W()
  cmd = FFETOG(cmdOpt, package)
  if cmd : FF1Q61(self, cmd, VVYxQ2=BF(self.VVZHuD, VVxBfP))
  else : FFgq4o(self)
 def VVZHuD(self, VVxBfP):
  VVxBfP.cancel()
  FFsMPf()
 def VVBUpr(self, VVxBfP, title, txt, colList):
  package  = colList[1]
  VVZJ87 = []
  VVZJ87.append(("Install Package"        , "install_CheckVersion" ))
  VVZJ87.append(("Install Package (force reinstall)"   , "install_ForceReinstall" ))
  VVZJ87.append(("Install Package (force overwrite)"   , "install_ForceOverwrite" ))
  VVZJ87.append(("Install Package (force downgrade)"   , "install_ForceDowngrade" ))
  VVZJ87.append(("Install Package (ignore failed dependencies)" , "install_IgnoreDepends" ))
  FFYySC(self, BF(self.VVr1Y7, package), VVZJ87=VVZJ87)
 def VVr1Y7(self, package, item):
  if item:
   if   item == "install_CheckVersion"  : cmdOpt = VV33Lu
   elif item == "install_ForceReinstall" : cmdOpt = VVDaFy
   elif item == "install_ForceOverwrite" : cmdOpt = VV57oW
   elif item == "install_ForceDowngrade" : cmdOpt = VVygvf
   elif item == "install_IgnoreDepends" : cmdOpt = VVfGaS
   FFNKVM(self, BF(self.VVhhqR, package, cmdOpt), "Install Package ?\n\n%s" % package)
 def VVhhqR(self, package, cmdOpt):
  cmd = FFETOG(cmdOpt, package)
  if cmd : FF1Q61(self, cmd, VVYxQ2=FFsMPf, checkNetAccess=True)
  else : FFgq4o(self)
 def VVYhDn(self, VVxBfP, title, txt, colList):
  package  = colList[1]
  FFNKVM(self, BF(self.VVHK7Z, package), "Download Package ?\n\n%s" % package)
 def VVHK7Z(self, package):
  if CC66h0.VVP0Wq():
   cmd = FFETOG(VVMnUw, package)
   if cmd:
    dest = CFG.downloadedPackagesPath.getValue()
    success = "Downloaded to:"
    andTxt = "echo -e '\n%s\n%s' %s" % (success, dest, FFXRSi(success, VVVjNM))
    fail = "Download Failed"
    orTxt = "echo -e '\n%s' %s" % (fail, FFXRSi(fail, VVGe5h))
    cmd  = "cd '%s'; %s && %s || %s" % (dest, cmd, andTxt, orTxt)
    FF1Q61(self, cmd, VVOuQk=[VVGe5h, "error:", "collected errors:", "failed", "not found"], checkNetAccess=True)
   else:
    FFgq4o(self)
  else:
   FFw5OO(self, "No internet connection !")
 @staticmethod
 def VVCAeb(SELF):
  cmd = FF8jae(VVxYBL, "")
  if cmd : FF1Q61(SELF, cmd, checkNetAccess=True)
  else : FFgq4o(SELF)
 @staticmethod
 def VVMWQB(path):
  pkg = err = ""
  if pathExists(path):
   for line in FFnAC3(FFETOG(VVElJX, "*%s*" % path)):
    span = iSearch(r"(.+) - .+", line)
    if span:
     pkg = span.group(1)
     break
    else:
     span = iSearch(r"(.+):+", line)
     if span:
      pkg = span.group(1)
      break
   if not pkg:
    err = "No package info !"
  else:
   err = "Path not found !"
  return pkg, err
 @staticmethod
 def VVnhoE(SELF, package, title=""):
  title = title or package
  infoCmd  = FFETOG(VVqsbt, package)
  filesCmd = FFETOG(VVWyGQ, package)
  listInstCmd = FF8jae(VVcrnB, "")
  if infoCmd and filesCmd and listInstCmd:
   timeText = "Installed-Time: "
   notInst  = "Package not installed with Packaging Tools."
   sep   = FFgg7s(VVVCGb)
   cmd  = "PACK='%s';" % package
   cmd += "FOUND=$(%s | grep $PACK);" % listInstCmd
   cmd += "if [[ -z \"$FOUND\" ]]; then "
   cmd += " echo -e 'No package information !\n';"
   cmd += " echo -e '%s' %s;" % (notInst, FFXRSi(notInst, VVsObI))
   cmd += "else "
   cmd +=   FFfCOf("System Info", VVVCGb)
   cmd += " %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += " TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, timeText, timeText)
   cmd += " HTIME=$(date -d @$TIME);"
   cmd += " echo %s$HTIME | sed 's/: /\t: /g';" % timeText
   cmd += " echo '';"
   cmd +=   FFfCOf("Related Files", VVVCGb)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " echo '';"
   cmd +=   sep
   cmd += "fi;"
   FFleea(SELF, cmd, title=title)
  else:
   FFgq4o(SELF, title=title)
class CCAmUK():
 def VV1ZF3(self, isRef, onlyEpg=False):
  self.shareIsRef   = isRef
  self.onlyEpg   = onlyEpg
  self.shareFilePrefix = "ajpanel_share_%s_" % ("ref" if self.shareIsRef else "data")
  self.shareFilePath  = ""
  self.shareData   = []
  self.VVPOKG()
 def VVPOKG(self):
  files = FFzSvJ(VVNemM, self.shareFilePrefix + "*.xml")
  if files:
   files.sort()
   VVZJ87 = []
   for fil in files:
    VVZJ87.append((os.path.basename(fil), fil))
   if self.shareIsRef : VVDlGi, VVaSSM = "#22221133", "#22221133"
   else    : VVDlGi, VVaSSM = "#22003344", "#22002233"
   VVbiUc  = ("Add new File", self.VVVEhL)
   FFYySC(self, self.VVPvb5, VVZJ87=VVZJ87, width=1100, VVbiUc=VVbiUc, VVAL4K="", minRows=4, VVDlGi=VVDlGi, VVaSSM=VVaSSM)
  else:
   FFNKVM(self, self.VV5LxP, "No files found.\n\nCreate a new file ?")
 def VV5LxP(self):
  path = self.VVx4PS()
  if fileExists(path) : self.VVPOKG()
  else    : FF5uKN(self, "Cannot create file", 1500)
 def VVVEhL(self, VV4EHV, path):
  path = self.VVx4PS()
  VV4EHV.VVYAqb((os.path.basename(path), path), isSort=True)
 def VVx4PS(self):
  path = "%s%s%s.xml" % (VVNemM, self.shareFilePrefix, FFUD38())
  with open(path, "w") as f:
   f.write('<?xml version="1.0" encoding="utf-8"?>\n<share>\n\n\t<ch>\n\t\t<name1>Channel-1</name1>  <ref1>5001:0:1:22:22:22:22:0:0:0</ref1>\n\t\t<name2>Channel-2</name2>  <ref2>4097:0:1:22:22:22:22:0:0:0</ref2>\n\t</ch>\n\n</share>')
  return path
 def VVPvb5(self, path=None):
  if path:
   FFJsIX(self, BF(self.VVhg8W, path))
 def VVhg8W(self, path):
  if not fileExists(path):
   FFZoTn(self, path)
   return
  elif not CCCXvS.VVJWb9(self, path, FFwrBW()):
   return
  else:
   self.shareFilePath = path
  if not CCXkrC.VVumgt(self):
   return
  tree = CCdAiy.VVSSCQ(self, self.shareFilePath)
  if not tree:
   return
  refLst = CCSrvY.VVOuEy()
  def VVYPGf(refCode):
   if   FFxrtX(refCode): return FFGB9z("DVB", VVkIQ9)
   elif refCode in refLst     : return FFGB9z("IPTV", VVkIQ9)
   else         : return ""
  VVX3wb= []
  errColor= "#f#00ffaa55#"
  num  = 1
  dupl = 0
  for ch in tree.getroot():
   ok, srcName, srcRef, dstName, dstRef = self.VVxY8x(ch)
   if ok:
    srcTxt = VVYPGf(srcRef)
    dstTxt = VVYPGf(dstRef)
    srcName, dstName = srcName.strip(), dstName.strip()
    skip = False
    for num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 in VVX3wb:
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      dupl += 1
      break
    else:
     if  srcRef == dstRef : remark, c1, c2 = "4", errColor, errColor
     elif srcTxt and dstTxt : remark, c1, c2 = "0", ""  , ""
     elif dstTxt    : remark, c1, c2 = "1", errColor, ""
     elif srcTxt    : remark, c1, c2 = "2", ""  , errColor
     else     : remark, c1, c2 = "3", errColor, errColor
     c3 = "#f#0000ff00#" if remark == "0" else errColor
     VVX3wb.append((c3 + str(num), c1 + srcName, c1 + srcRef, c1 + srcTxt, c2 + dstName, c2 + dstRef, c2 + dstTxt, remark))
     num += 1
  refLst = None
  if VVX3wb:
   if self.shareIsRef : VVDlGi, VVaSSM, optTxt = "#1a221133", "#1a221133", "Share Reference"
   else    : VVDlGi, VVaSSM, optTxt = "#1a003344", "#1a002233", "Copy EPG" if self.onlyEpg else "Copy EPG/PIcons"
   VVotuX = (""    , BF(self.VV7mZ5, dupl), [])
   VVs5AA = (""    , self.VVm4d8    , [])
   VVZ224 = ("Delete Entry" , self.VVdSOl   , [])
   VVX66G = ("Add Entry"  , self.VVMXl4   , [])
   VVIrDY = (optTxt   , self.VVT2ID  , [])
   header  = ("Num" , "Source" , "Source Ref." ,"Type" , "Destination" , "Dest. Ref." , "Type", "Remark" )
   widths  = (8  , 25  , 15   , 6  , 25   , 15   , 6  , 0   )
   VVFvCJ = (CENTER , LEFT  , LEFT   ,CENTER , LEFT   , LEFT   , CENTER, CENTER )
   VVxBfP = FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=24, VVotuX=VVotuX, VVs5AA=VVs5AA, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, VVUdUN=True, searchCol=1, lastFindConfigObj=CFG.lastFindServices
         , VVDlGi=VVDlGi, VVaSSM=VVaSSM, VVzgHY=VVaSSM, VVkUYa="#0a000000")
  else:
   FFw5OO(self, "No valid sharing data found in:\n\n%s" % self.shareFilePath)
 def VV7mZ5(self, dupl, VVxBfP, title, txt, colList):
  if dupl:
   VVxBfP.VVIzOr("Skipped %d duplicate%s" % (dupl, FF1I1d(dupl)), 2000)
 def VVm4d8(self, VVxBfP, title, txt, colList):
  def VVYPGf(key, val): return "%s\t: %s\n" % (key, val or FFGB9z("?", VVLbyB))
  Keys = VVxBfP.VVCpTV()
  Vals = VVxBfP.VVc6YJ()
  txt = ""
  for i in range(len(Keys) - 1):
   txt += VVYPGf(Keys[i], Vals[i])
   if i in (0, 3, 6):
    txt += "\n"
  remark = colList[7]
  txt1 = "Remarks\t: "
  c1, c2 = VVVjNM, VVLbyB
  if   remark == "0": txt1 += c1 + "Valid"
  elif remark == "1": txt1 += c2 + "Source channel is not in system"
  elif remark == "2": txt1 += c2 + "Destination channel is not in system"
  elif remark == "3": txt1 += c2 + "Both channels are not in system"
  elif remark == "4": txt1 += c2 + "Both channels have same Reference"
  FF90Bc(self, txt + txt1, title=title)
 def VVxY8x(self, chElem):
  srcName = chElem.find("name1")
  srcRef  = chElem.find("ref1")
  dstName = chElem.find("name2")
  dstRef  = chElem.find("ref2")
  patt = r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))"
  if srcName is not None and srcRef is not None and dstName is not None and dstRef is not None:
   lst = [srcName.text or "", srcRef.text or "", dstName.text or "", dstRef.text or ""]
   for i, text in enumerate(lst):
    lst[i] = str(text.encode("UTF-8").decode())
   srcName, srcRef, dstName, dstRef = lst
   span = iSearch(patt, srcRef)
   if span:
    srcRef = span.group(1).upper()
    span = iSearch(patt, dstRef)
    if span:
     dstRef = span.group(1).upper()
     return True, srcName.strip(), srcRef.strip(":"), dstName.strip(), dstRef.strip(":")
  return False, "", "", "", ""
 def VVdSOl(self, VVxBfP, title, txt, colList):
  if VVxBfP.VVgu5W() == 0 and VVxBfP.VVWnGz() == 1:
   isLast, ques = True, "This is the last entry.\n\nDelete File ?"
  else:
   isLast, ques = False, "Delete current row ?"
  FFNKVM(self, BF(self.VVHLMU, isLast, VVxBfP), ques)
 def VVHLMU(self, isLast, VVxBfP):
  if isLast:
   FFzyFM(self.shareFilePath)
   VVxBfP.cancel()
  else:
   num, srcName, srcRef, srcType, dstName, dstRef, dstType, remark = VVxBfP.VVc6YJ()
   if self.VVByF2(srcName, srcRef, dstName, dstRef):
    VVxBfP.VVrBGY()
    VVxBfP.VVOiFn()
    FF5uKN(VVxBfP, "Deleted", 500, isGrn=True)
   else:
    FF5uKN(VVxBfP, "Cannot delete from file", 2000)
 def VVMXl4(self, VVxBfP, title, txt, colList):
  self.shareData = []
  if self.shareIsRef : self.VVDgyY(VVxBfP, isDvb=True)
  else    : self.VVTm1J(VVxBfP, "Source Channel", "#22003344", "#22002233")
 def VVTm1J(self, mainTableInst, title, VVDlGi, VVaSSM):
  FFYySC(self, BF(self.VVhEuT, mainTableInst, title), VVZJ87=[("DVB", "DVB"), ("IPTV / Stream Relay", "IPTV")], title=title + " Type", width=800, VVDlGi=VVDlGi, VVaSSM=VVaSSM)
 def VVhEuT(self, mainTableInst, title, item=None):
  if item:
   FFJsIX(mainTableInst, BF(self.VV6uGA, mainTableInst, title, item), clearMsg=False)
 def VV6uGA(self, mainTableInst, title, item):
  FF5uKN(mainTableInst)
  if item == "DVB": self.VVDgyY(mainTableInst, isDvb=True)
  else   : self.VVDgyY(mainTableInst, isDvb=False)
 def VVLp5q(self, mainTableInst, chType, VVxBfP, title, txt, colList):
  self.shareData.append((colList[0], colList[3], chType))
  curRowNdx = VVxBfP.VVgu5W()
  if   chType == "DVB" : FFdEZ4(CFG.lastSharePickerDvbRow , curRowNdx)
  elif chType == "IPTV": FFdEZ4(CFG.lastSharePickerIptvRow, curRowNdx)
  if len(self.shareData) == 2:
   srcName, srcRef, srcTxt = self.shareData[0]
   dstName, dstRef, dstTxt = self.shareData[1]
   srcName, dstName = srcName.strip(), dstName.strip()
   if not srcRef == dstRef:
    for ndx, row in enumerate(mainTableInst.VVlHja()):
     num1, srcName1, srcRef1, srcTxt1, dstName1, dstRef1, dstTxt1, remark1 = row
     if (srcRef, dstRef) == (srcRef1, dstRef1):
      FFw5OO(self, "Already added in row Num-%d" % (ndx + 1))
      break
    else:
     if self.VVqXKb(srcName, srcRef, dstName, dstRef):
      mainTableInst.VVjWa0((str(mainTableInst.VVWnGz() + 1), srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, "0"))
      FF5uKN(mainTableInst, "Added", 500, isGrn=True)
     else:
      FF5uKN(mainTableInst, "Cannot edit XML File", 2000)
   else:
    FF5uKN(mainTableInst, "Cannot use same Reference", 2000)
  else:
   if self.shareIsRef : self.VVDgyY(mainTableInst, isDvb=False)
   else    : FFFANg(BF(self.VVTm1J, mainTableInst, "Select Destination", "#11661122", "#11661122"))
  VVxBfP.cancel()
 def VVLXXt(self, item, VVxBfP, title, txt, colList):
  if   item == "DVB" : ndx = CFG.lastSharePickerDvbRow.getValue()
  elif item == "IPTV": ndx = CFG.lastSharePickerIptvRow.getValue()
  VVxBfP.VVYNxS(ndx)
 def VVDgyY(self, VVxBfP, isDvb):
  typ  = "DVB" if isDvb else "IPTV"
  txt  = "Soruce" if len(self.shareData) == 0 else "Destination"
  okFnc = BF(self.VVLp5q, VVxBfP, typ)
  doneFnc = BF(self.VVLXXt, typ)
  if isDvb: CCAmUK.VVffcV(VVxBfP , "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
  else : CCAmUK.VV97E5(VVxBfP, "Select %s (%s)" % (txt, typ), okFnc, doneFnc)
 @staticmethod
 def VVffcV(SELF, title, okFnc, doneFnc=None):
  FFJsIX(SELF, BF(CCAmUK.VVz55A, SELF, title, okFnc, doneFnc), title="Loading DVB Services ...")
 @staticmethod
 def VVz55A(SELF, title, okFnc, doneFnc=None):
  VVX3wb, err = CCdAiy.VVcFnp(SELF, CCdAiy.VVZ67J)
  if VVX3wb:
   color = "#0a000022"
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVwmV1 = ("Select" , okFnc, [])
   VVotuX= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Provider", "Sat.", "Reference" )
   widths  = (29  , 27  , 9  , 35   )
   VVFvCJ = (LEFT  , LEFT  , CENTER, LEFT    )
   FF1Dpj(SELF, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVDlGi=color, VVaSSM=color, VVzgHY=color, VVwmV1=VVwmV1, VVotuX=VVotuX, lastFindConfigObj=CFG.lastFindServices)
  else:
   FFw5OO(SELF, "No DVB Services !")
 @staticmethod
 def VV97E5(SELF, title, okFnc, doneFnc=None):
  FFJsIX(SELF, BF(CCAmUK.VVhukG, SELF, title, okFnc, doneFnc), title="Loading IPTV Services ...")
 @staticmethod
 def VVhukG(SELF, title, okFnc, doneFnc=None):
  VVX3wb = CCAmUK.VV5Bfy()
  if VVX3wb:
   color = "#0a112211"
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVwmV1 = ("Select" , okFnc, [])
   VVotuX= ("", doneFnc, []) if doneFnc else None
   header  = ("Name" , "Bouquet" , "URL" , "Reference" )
   widths  = (35  , 35  , 15 , 15   )
   FF1Dpj(SELF, None, title=title, header=header, VVarfR=VVX3wb, VVhAo0=widths, VVTFXq=26, VVDlGi=color, VVaSSM=color, VVzgHY=color, VVwmV1=VVwmV1, VVotuX=VVotuX, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFw5OO(SELF, "No IPTV Services !")
 @staticmethod
 def VV5Bfy():
  VVX3wb = []
  files  = CC9X9s.VV3Es2()
  patt  = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+(.+)"
  if files:
   for path in files:
    txt = FFQ5la(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV1h0S = span.group(1)
    else : VV1h0S = ""
    VV1h0S_lCase = VV1h0S.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper().strip(":")
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     VVX3wb.append((chName, VV1h0S, url, refCode))
  return VVX3wb
 def VVqXKb(self, srcName, srcRef, dstName, dstRef):
  tree = CCdAiy.VVSSCQ(self, self.shareFilePath)
  if not tree:
   return False
  root = tree.getroot()
  ch = iElem.Element("ch")
  root.append(ch)
  name  = iElem.SubElement(ch, "name1")
  ref   = iElem.SubElement(ch, "ref1")
  name.text = srcName
  ref.text = srcRef
  name  = iElem.SubElement(ch, "name2")
  ref   = iElem.SubElement(ch, "ref2")
  name.text = dstName
  ref.text = dstRef
  self.VV4vI2(tree, root)
  return True
 def VVByF2(self, srcName1, srcRef1, dstName1, dstRef1):
  tree = CCdAiy.VVSSCQ(self, self.shareFilePath)
  if not tree:
   return False
  tableLst = [srcName1, srcRef1, dstName1, dstRef1]
  found = False
  root = tree.getroot()
  for ch in root:
   ok, srcName, srcRef, dstName, dstRef = self.VVxY8x(ch)
   if ok and [srcName, srcRef, dstName, dstRef] == tableLst:
    root.remove(ch)
    found = True
  if found:
   self.VV4vI2(tree, root)
  return found
 def VV4vI2(self, tree, root, withComments=True):
  xmlTxt = iElem.tostring(root)
  txt  = CCdAiy.VVvJAg(xmlTxt)
  parser = CCdAiy.CCouRD()
  if withComments : parser = iElem.XMLParser(target=parser)
  else   : parser = None
  root = iElem.fromstring(txt, parser=parser)
  tree._setroot(root)
  tree.write(self.shareFilePath, encoding="UTF-8")
 def VVT2ID(self, VVxBfP, title, txt, colList):
  if self.onlyEpg:
   self.VVp1J8(VVxBfP, "epg")
  else:
   if self.shareIsRef:
    FFNKVM(self, BF(FFJsIX, VVxBfP, BF(self.VVZUV2, VVxBfP)), "Copy all References from Source to Destination ?")
   else:
    VVZJ87 = []
    VVZJ87.append(("Copy EPG\t (All List)" , "epg"  ))
    VVZJ87.append(("Copy Picons\t (All List)" , "picon" ))
    FFYySC(self, BF(self.VVp1J8, VVxBfP), VVZJ87=VVZJ87, width=1000)
 def VVp1J8(self, VVxBfP, item=None):
  if item:
   if   item == "epg" : fnc, txt = self.VVRqE0  , "EPG"
   elif item == "picon": fnc, txt = self.VVlbAp , "PIcons"
   title = "Copy %s" % txt
   tot   = VVxBfP.VVWnGz()
   FFNKVM(self, BF(FFJsIX, VVxBfP, BF(fnc, VVxBfP, title)), "Overwrite %s for %d Service%s ?" % (FFGB9z(txt, VVVCGb), tot, FF1I1d(tot)), title=title)
 def VVZUV2(self, VVxBfP):
  files = CC9X9s.VV3Es2()
  totChange = 0
  if files:
   for path in files:
    txt = FFQ5la(path)
    toSave = False
    for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVxBfP.VVlHja():
     if remark == "0":
      srcPart = ":".join(srcRef.split(":")[1:]) + ":"
      dstPart = ":".join(dstRef.split(":")[1:]) + ":"
      txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]))%s(.+\/\/.+)" % dstPart, r"\g<1>%s\2" % srcPart, txt, IGNORECASE)
      if tot:
       toSave = True
       totChange += tot
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
  if totChange > 0:
   FFAvBD()
  tot = VVxBfP.VVWnGz()
  txt  = "Services\t: %d\n" % tot
  txt += "Changed\t: %d\n"  % totChange
  txt += "Skipped\t: %d\n"  % (tot- totChange)
  FF90Bc(self, txt)
 def VVlbAp(self, VVxBfP, title):
  if not iCopyfile:
   FFw5OO(self, "Module not found:\n\nshutil", title=title)
   return
  pPath = CCijoe.VV4boJ()
  totFound = totDone = totSame = totErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVxBfP.VVlHja():
   srcPng = pPath + srcRef.replace(":", "_") + ".png"
   dstPng = pPath + dstRef.replace(":", "_") + ".png"
   if fileExists(srcPng):
    totFound += 1
    if srcPng == dstPng:
     totSame += 1
    else:
     try:
      iCopyfile(srcPng, dstPng)
      totDone += 1
     except:
      totErr += 1
  txt  = "Services\t: %d\n" % VVxBfP.VVWnGz()
  txt += "Found\t: %d\n" % totFound
  txt += "Copied\t: %d"  % totDone
  if totSame: txt += "\nSame Ref.\t: %d" % totSame
  if totErr : txt += "\nErrors\t: %d"  % totErr
  FF90Bc(self, txt, title=title)
 def VVRqE0(self, VVxBfP, title):
  txt, err = CCvWMS.VVmAk5(VVxBfP, title)
  if err : FFw5OO(self, err, title=title)
  else : FF90Bc(self, txt, title=title)
 class CCouRD(iElem.TreeBuilder):
  def comment(self, data):
   self.start(iElem.Comment, {})
   self.data(data)
   self.end(iElem.Comment)
 @staticmethod
 def VVSSCQ(SELF, path, withComments=True, title=""):
  try:
   if withComments : parser = iElem.XMLParser(target=CCdAiy.CCouRD())
   else   : parser = None
   return iElem.parse(path, parser=parser)
  except Exception as e:
   txt  = "%s\n%s\n\n" % (FFGB9z("XML Parse Error in:", VVLbyB), path)
   txt += "%s\n%s\n\n" % (FFGB9z("Error:", VVLbyB), str(e))
   FF90Bc(SELF, txt, VVzgHY="#11220000", title=title)
   return None
 @staticmethod
 def VVvJAg(xmlTxt):
  txt = iSub(r">[\n\s]*", ">" , xmlTxt.decode("UTF-8"))
  txt = iSub(r"([^12])>\s*<" , r"\1>\n<", txt)
  txt = iSub(r"ref1>\s*<name2", r"ref1>\n<name2", txt)
  txt = iSub(r"</ref2></ch>" , r"</ref2>\n</ch>\n", txt)
  txt = iSub(r"<ch>"   , r"\t<ch>", txt)
  txt = iSub(r"</ch>"   , r"\t</ch>", txt)
  txt = iSub(r"<name1>"  , r"\t\t<name1>", txt)
  txt = iSub(r"<name2>"  , r"\t\t<name2>", txt)
  txt = iSub(r"(<!-- .+ -->)" , r"\t\1\n", txt)
  txt = iSub(r"<share>"  , r"<share>\n", txt)
  return txt
class CCvWMS(Screen, CCAmUK):
 VVtVWy  = "BDTSE"
 VVStU9   = "save"
 VV5HIp   = "load"
 VV5YnC  = "flushEPG"
 def __init__(self, session):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 950, 800, 50, 40, 30, "#22110011", "#22110022", 30)
  self.session  = session
  valid, path, sz, szTxt = CCvWMS.VVtxyj()
  qUrl, iptvRef = CC9X9s.VVxFip(self)
  VVZJ87 = []
  VVZJ87.append((VVkIQ9 + "Cache File Info." , "inf"))
  VVZJ87.append(VVoqHH)
  fTxt = " (%s)" % os.path.basename(path) if valid else ""
  VVZJ87.append(FFnqNr("Save EPG to File%s" % fTxt , self.VVStU9, valid))
  VVZJ87.append(FFnqNr("Load EPG from File%s" % fTxt , self.VV5HIp, valid))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((VVsObI + "Delete EPG (from RAM only)", self.VV5YnC))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(FFnqNr("Update Current Bouquet EPG (from IPTV Server)", "refreshIptvEPG", qUrl or "chCode" in iptvRef))
  VVZJ87.append(("Copy EPG between Channels (from xml file)", "copyEpg" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Translate Current Channel EPG %s(Experimental)" % VVsObI, "VV4l6M"))
  FFmmH7(self, VVZJ87=VVZJ87)
  self.onShown.append(self.VV0wap)
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "inf"    : self.VV84sS()
   elif item in (self.VVStU9, self.VV5HIp, self.VV5YnC):
    reset = item == self.VV5HIp
    FFNKVM(self, BF(FFJsIX, self, BF(self.VVs0J2, item, reset)), VVILc0="Continue ?")
   elif item == "refreshIptvEPG"  : CC9X9s.VVCBtN(self)
   elif item == "VV4l6M" : self.VV4l6M()
   elif item == "copyEpg"    : self.VV1ZF3(False, onlyEpg=True)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVs0J2(self, act, reset=False):
  ok = CCvWMS.VVMqMm(act)
  if ok:
   if reset:
    CCvWMS.VVskpv(self)
   FF15cM(self, "Done")
  else:
   FF15cM(self, "Failed!")
 def VV84sS(self):
  title = "EPG Cache File"
  valid, path, sz, szTxt = CCvWMS.VVtxyj()
  if path:
   if valid: txt = "File Path\t: %s\n\nFile Size\t: %s\n" % (path, szTxt or "?")
   else : txt = "System Settings: %s\n\n%s" % (path, FFGB9z("File not found (check System EPG settings).", VVsObI))
   FF90Bc(self, txt, title=title)
  else:
   FFw5OO(self, "Cannot read Path Settings !", title=title)
 @staticmethod
 def VVvMNv():
  return [("", "Disable"),("af","Afrikaans"),("sq","Albanian"),("am","Amharic"),("ar","Arabic"),("hy","Armenian"),("as","Assamese"),("ay","Aymara"),("az","Azerbaijani"),("bm","Bambara"),("eu","Basque"),("be","Belarusian"),("bn","Bengali"),("bho","Bhojpuri"),("bs","Bosnian"),("bg","Bulgarian"),("ca","Catalan"),("ceb","Cebuano"),("ny","Chichewa"),("zh-CN","Chinese (Simplified)"),("zh-TW","Chinese (Traditional)"),("co","Corsican"),("hr","Croatian"),("cs","Czech"),("da","Danish"),("dv","Dhivehi"),("doi","Dogri"),("nl","Dutch"),("en","English"),("eo","Esperanto"),("et","Estonian"),("ee","Ewe"),("tl","Filipino"),("fi","Finnish"),("fr","French"),("fy","Frisian"),("gl","Galician"),("ka","Georgian"),("de","German"),("el","Greek"),("gn","Guarani"),("gu","Gujarati"),("ht","Haitian Creole"),("ha","Hausa"),("haw","Hawaiian"),("iw","Hebrew"),("hi","Hindi"),("hmn","Hmong"),("hu","Hungarian"),("is","Icelandic"),("ig","Igbo"),("ilo","Ilocano"),("id","Indonesian"),("ga","Irish"),("it","Italian"),("ja","Japanese"),("jw","Javanese"),("kn","Kannada"),("kk","Kazakh"),("km","Khmer"),("rw","Kinyarwanda"),("gom","Konkani"),("ko","Korean"),("kri","Krio"),("ku","Kurdish (Kurmanji)"),("ckb","Kurdish (Sorani)"),("ky","Kyrgyz"),("lo","Lao"),("la","Latin"),("lv","Latvian"),("ln","Lingala"),("lt","Lithuanian"),("lg","Luganda"),("lb","Luxembourgish"),("mk","Macedonian"),("mai","Maithili"),("mg","Malagasy"),("ms","Malay"),("ml","Malayalam"),("mt","Maltese"),("mi","Maori"),("mr","Marathi"),("mni-Mtei","Meiteilon (Manipuri)"),("lus","Mizo"),("mn","Mongolian"),("my","Myanmar (Burmese)"),("ne","Nepali"),("no","Norwegian"),("or","Odia (Oriya)"),("om","Oromo"),("ps","Pashto"),("fa","Persian"),("pl","Polish"),("pt","Portuguese"),("pa","Punjabi"),("qu","Quechua"),("ro","Romanian"),("ru","Russian"),("sm","Samoan"),("sa","Sanskrit"),("gd","Scots Gaelic"),("nso","Sepedi"),("sr","Serbian"),("st","Sesotho"),("sn","Shona"),("sd","Sindhi"),("si","Sinhala"),("sk","Slovak"),("sl","Slovenian"),("so","Somali"),("es","Spanish"),("su","Sundanese"),("sw","Swahili"),("sv","Swedish"),("tg","Tajik"),("ta","Tamil"),("tt","Tatar"),("te","Telugu"),("th","Thai"),("ti","Tigrinya"),("ts","Tsonga"),("tr","Turkish"),("tk","Turkmen"),("ak","Twi"),("uk","Ukrainian"),("ur","Urdu"),("ug","Uyghur"),("uz","Uzbek"),("vi","Vietnamese"),("cy","Welsh"),("xh","Xhosa"),("yi","Yiddish"),("yo","Yoruba"),("zu","Zulu")]
 def VV4l6M(self):
  title = "Translate Current Channel EPG"
  bg = "#11101010"
  VVwmV1  = (""  , BF(self.VVVJKq, title, True) , [])
  VVX66G = ("Start" , BF(self.VVVJKq, title, False), [])
  VVFadD = ("Change Language", self.VVaZfY      , [])
  widths  = (70 , 30)
  VVFvCJ = (LEFT , CENTER)
  FF1Dpj(self, None, title=title, VVarfR=self.VVZ9wp(), VVFvCJ=VVFvCJ, VVhAo0=widths, width=1200, vMargin=20, VVTFXq=30, VVwmV1=VVwmV1, VVX66G=VVX66G, VVFadD=VVFadD, VVqDAH=2
    , VVDlGi="#11201010", VVaSSM=bg, VVzgHY=bg, VVkUYa="#00004455", VVivoO=bg)
 def VVZ9wp(self):
  Def, ch = "DISABLED", dict(CCvWMS.VVvMNv())
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  VVarfR = [("Event Name Language", ch.get(tVal, Def)), ("Description Language", ch.get(dVal, Def))]
  return VVarfR
 def VVaZfY(self, VVxBfP, title, txt, colList):
  ndx = VVxBfP.VVgu5W()
  title = colList[0]
  confItem = CFG.epgLangTitle if ndx == 0 else CFG.epgLangDescr
  CCcHsQ.VVsrg7(self, confItem, title, lst=CCvWMS.VVvMNv(), cbFnc=BF(self.VVo30B, VVxBfP), isSave=True)
 def VVo30B(self, VVxBfP):
  for ndx, row in enumerate(self.VVZ9wp()):
   VVxBfP.VVr9B1(ndx, row)
 def VVVJKq(self, Title, isAsk, VVxBfP, title, txt, colList):
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  if not (tVal or dVal):
   FF5uKN(VVxBfP, "Change Language", 700)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
   refCode, evList, err = CCvWMS.VVcyzN(refCode)
   fnc = BF(self.VVBHn4, Title, refCode, evList, VVxBfP)
   if   err : FFw5OO(self, err, title=Title)
   elif isAsk : FFNKVM(self, fnc, "Start ?", title=Title)
   else  : fnc()
 def VVBHn4(self, title, refCode, evList, VVxBfP):
  self.session.open(CCmNws, barTheme=CCmNws.VV3z22, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVlOig, evList)
      , VVCeou = BF(self.VVEEIR, title, refCode))
  VVxBfP.cancel()
 def VVlOig(self, evList, VVXLiB):
  totEv = len(evList)
  newLst = []
  totErrName = totErrShort = totErrLong = totSkip = 0
  VVXLiB.VVCnyB(totEv)
  VVXLiB.VVlaij = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
  lang = CFG.epgLangDescr.getValue()
  for ev in evList:
   trName, trShort, trLong, errName, errShort, errLong = CCvWMS.VVxOVz(*ev[2:5])
   totErrName  += errName
   totErrShort += errShort
   totErrLong  += errLong
   if not VVXLiB or VVXLiB.isCancelled:
    return
   VVXLiB.VV1Vtn(1)
   VVXLiB.VVaVYA(len(newLst), ev[2] if len(ev[2]) < 22 else ev[2][:22] + " ...")
   name1, short1, long1 = ev[2:5]
   if (name1, short1, long1) != (trName, trShort, trLong):
    item = list(ev)
    item[2], item[3], item[4] = trName, trShort, trLong
    item.append(1)
    newLst.append(tuple(item))
   else:
    totSkip += 1
   VVXLiB.VVlaij = (newLst, totEv, totErrName, totErrShort, totErrLong, totSkip)
 def VVEEIR(self, title, refCode, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  newLst, totEv, totErrName, totErrShort, totErrLong, totSkip = VVlaij
  if newLst: totEv, totOK = CCvWMS.VV2PtB(refCode, newLst)
  else  : totOK = 0
  if totOK:
   CCvWMS.VVUXih()
   CCvWMS.VVskpv(self)
  txt  = "Events\t: %d\n"  % totEv
  txt += "Processed\t: %d\n" % len(newLst)
  txt += "Changed\t: %d\n" % totOK
  if totSkip : txt += "Skipped\t: %d \t... Same language\n" % totSkip
  if any((totErrName, totErrShort, totErrLong)):
   txt += "\nErrors:\n"
   if totErrName : txt += "  Event Name\t: %d\n" % totErrName
   if totErrShort: txt += "  Description\t: %d\n" % totErrShort
   if totErrLong : txt += "  Description\t: %d\n" % totErrLong
  FF90Bc(self, txt, title=title)
 @staticmethod
 def VVxOVz(eName, eShort, eLong):
  eName, eShort, eLong = eName.strip(), eShort.strip(), eLong.strip()
  tVal, dVal = CFG.epgLangTitle.getValue(), CFG.epgLangDescr.getValue()
  lang, lst, resLst, errLst = (tVal, dVal, dVal), (eName, eShort, eLong), ["", "", ""], [0, 0, 0]
  def VVYPGf(ndx):
   if lst[ndx] and lang[ndx]:
    txt, err = CCvWMS.VVRbBu(lst[ndx], lang[ndx])
    resLst[ndx], errLst[ndx] = txt, 1 if err else 0
  thLst = []
  for ndx in range(3):
   th = iThread(name="ajp_%d" % ndx, target=BF(VVYPGf, ndx))
   th.start()
   thLst.append(th)
  for th in thLst: th.join()
  trName, trShort, trLong = resLst[0] or eName, resLst[1] or eShort, resLst[2] or eLong
  errName, errShort, errLong = errLst
  return trName, trShort, trLong, errName, errShort, errLong
 @staticmethod
 def VVRbBu(txt, toLang):
  txt = txt.strip()
  if txt:
   qUrl = "%s%s&q=%s" % ("=lt&otua=ls&?m/moc.elgoog.etalsnart//:sptth"[::-1], toLang, FFGN9H(txt))
   txt, err = CC9X9s.VVuaOC(qUrl, timeout=1, allowDocType=True)
   if err:
    return "", err
   else:
    txt = FFlOsc(txt)
    ndx  = txt.find('<div class="result-container">')
    if ndx > -1:
     txt = txt[ndx + 30:]
     ndx  = txt.find("</div>")
     if ndx > -1:
      return str(CCvWMS.VV27tg(txt[:ndx])).strip(), ""
   return "", "Could not translate"
  else:
   return "", "Nothing to translate"
 @staticmethod
 def VVtxyj():
  path = szTxt = ""
  valid = sz = 0
  try: path = config.misc.epgcache_filename.getValue()
  except: pass
  if fileExists(path):
   valid = 1
   sz = FFqLWj(path)
   szTxt = CCCXvS.VVutW7(sz) if sz > -1 else ""
  return valid, path, sz, szTxt
 @staticmethod
 def VVQzqO():
  try:
   from enigma import eEPGCache
   return eEPGCache, eEPGCache.getInstance()
  except:
   return None, None
 @staticmethod
 def VVUXih(): CCvWMS.VVMqMm(CCvWMS.VVStU9)
 @staticmethod
 def VVMqMm(act):
  ec, inst = CCvWMS.VVQzqO()
  if inst and hasattr(ec, act):
   try:
    exec("inst.%s()" % act)
    return True
   except:
    pass
  return False
 @staticmethod
 def VVskpv(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   SELF.session.nav.stopService()
   SELF.session.nav.playService(serv)
 @staticmethod
 def VVcyzN(refCode):
  ec, inst = CCvWMS.VVQzqO()
  if inst:
   try:
    evList = inst.lookupEvent([CCvWMS.VVtVWy, (refCode, 0, -1, 20160)])
    if evList: return refCode, evList, ""
    else  : return refCode, [], "System returned empty EPG list"
   except:
    return refCode, [], "EPG Read-Error !"
  else:
   return refCode, [], "Cannot read EPG Cache !"
 @staticmethod
 def VV2PtB(refCode, events, longDescDays=0):
  ec, inst = CCvWMS.VVQzqO()
  totEv, totOK, fnc = 0, 0, None
  if inst:
   if   hasattr(ec, "importEvents"): fnc = inst.importEvents
   elif hasattr(ec, "importEvent") : fnc = inst.importEvent
  if fnc:
   for data in events:
    totEv += 1
    try:
     if longDescDays and data[0] > iTime() + 86400 * longDescDays:
      data = data[:4] + ("",) + data[5:]
     fnc(refCode, (data,))
     totOK += 1
    except:
     pass
  return totEv, totOK
 @staticmethod
 def VVMkbO(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   ec, inst = CCvWMS.VVQzqO()
   if ec:
    event = inst.lookupEventTime(serv, -1, 0)
    if event:
     return CCvWMS.VVgqdD(event)
   try:
    info = serv and eServiceCenter.getInstance().info(serv)
    event = info and info.getEvent(serv)
    if event:
     return CCjQ0P.CCvWMS(event)
   except:
    pass
  return [""] * 7
 @staticmethod
 def VVgqdD(event):
  evName = event.getEventName().strip()    or ""
  evTime = event.getBeginTime()      or ""
  evDur = event.getDuration()      or ""
  evShort = event.getShortDescription().strip()  or ""
  evDesc = event.getExtendedDescription().strip() or ""
  genre, PR = CCvWMS.VVLNHz(event)
  return evName, evTime, evDur, evShort, evDesc, genre, PR
 @staticmethod
 def VVLpmH(refCode):
  service = eServiceReference(refCode)
  evLst = []
  if service:
   ec, inst = CCvWMS.VVQzqO()
   try:
    if inst:
     for evNum in range(2):
      event = inst.lookupEventTime(service, -1, evNum)
      evName, evTime, evDur, evShort, evDesc, genre, PR = CCvWMS.VVgqdD(event)
      evEnd = evPos = evRem = evCom = 0
      evTimeTxt = evPosTxt = evDurTxt = evEndTxt = evRemTxt = evComTxt = ""
      if evTime and evDur:
       evEnd = evTime + evDur
       evTimeTxt = FFC3u1(evTime)
       evEndTxt  = FFC3u1(evEnd)
       evDurTxt  = FF3Odj(evDur)
       now = int(iTime())
       if now > evTime and now < evEnd:
        evPos = now - evTime
        evPosTxt = FF3Odj(evPos)
        evRem = evEnd - now
        evRemTxt = FF3Odj(evRem)
       elif now < evTime:
        evCom = evTime - now
        evComTxt = FF3Odj(evCom)
      evLst.append((evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt))
   except:
    pass
  return evLst
 @staticmethod
 def VVLNHz(event):
  genre = PR = ""
  try:
   genre  = CCvWMS.VVi3PL(event.getGenreData().getLevel1(), event.getGenreData().getLevel2())
   age = event.getParentalData().getRating()
   PR  = CCvWMS.VVAUZQ(age)
  except:
   pass
  return genre, PR
 @staticmethod
 def VVAUZQ(age):
  if   age == 0 : return "Undefinded (all ages)"
  elif age > 15 : return "Rated by broadcaster (%d)" % age
  else   : return "Minimum Age = %d years" % (age + 3)
 @staticmethod
 def VVi3PL(L1, L2):
  if   L1 <= 0  : return "Undefined Content"
  elif L1 >= 15  : return "User Defined Genre"
  elif L1 > 12  : return "Unlisted Genre"
  else:
   MG, SG = CCvWMS.VVKSyN()
   if MG and SG:
    key = "%d,%d" % (L1, L2)
    if key in SG   : return SG[key].title()
    elif L1 - 1 < len(MG) : return MG[L1 - 1] .title()
    else     : return "Unknown Genre"
   else:
    return ""
 @staticmethod
 def VVKSyN():
  path = VVrrZu + "_sup_genre"
  MG = SG = ""
  if fileExists(path):
   MG = iFindall(r"\d,0;(\w+\s?\w+)", FFQ5la(path), IGNORECASE)
   SG = iFindall(r"(\d+,\d+);(.+)", FFQ5la(path), IGNORECASE)
   if SG: SG = dict(SG)
  return MG, SG
 @staticmethod
 def VVmAk5(VVxBfP, title):
  ec, inst = CCvWMS.VVQzqO()
  if not inst:
   return "", "Cannot access EPG Cache !"
  totFound = totEvents = totSuccess = totInvalid = totEvErr = 0
  for num, srcName, srcRef, srcTxt, dstName, dstRef, dstTxt, remark in VVxBfP.VVlHja():
   if remark == "0":
    try:
     evList = inst.lookupEvent([CCvWMS.VVtVWy, (srcRef, 0, -1, 20160)])
    except:
     totEvErr += 1
     evList = []
    if evList:
     totFound += 1
     lst = []
     for item in evList:
      lst.append((item[0], item[1], item[2], item[3], item[4], 1))
     totEv, totOK = CCvWMS.VV2PtB(dstRef, lst)
     totEvents += totEv
     totSuccess += totOK
   else:
    totInvalid += 1
  if totSuccess > 0:
   CCvWMS.VVUXih()
  txt  = "Services\t: %d\n"  % VVxBfP.VVWnGz()
  txt += "Invalid Ref.\t: %s\n" % totInvalid
  txt += "With Events\t: %d\n\n" % totFound
  txt += "Found Events\t: %d\n" % totEvents
  txt += "Copied Events\t: %d\n" % totSuccess
  if totEvErr:
   txt += "EPG Errors\t: %d" % totEvErr
  return txt, ""
 @staticmethod
 def VVYb1s(info, refCode):
  epg = ""
  if info:
   for evNum in range(2):
    try:
     event = info.getEvent(evNum)
     epg += CCvWMS.VV5Z0w(event, evNum)
    except:
     pass
  elif refCode:
   service = eServiceReference(refCode)
   if service:
    try:
     from enigma import eEPGCache
     eCache = eEPGCache.getInstance()
     if eCache:
      for evNum in range(2):
       event = eCache.lookupEventTime(service, -1, evNum)
       epg += CCvWMS.VV5Z0w(event, evNum)
    except:
     pass
    if not epg:
     try:
      info = eServiceCenter.getInstance().info(service)
      if info:
       event = info.getEvent(service)
       epg += CCvWMS.VV5Z0w(event, 0)
     except:
      pass
  return epg
 @staticmethod
 def VV5Z0w(event, evNum):
  txt = ""
  if event:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCvWMS.VVgqdD(event)
   if any([evName, evShort, evDesc, evTime, evDur]):
    trName, trShort, trLong, errName, errShort, errLong = CCvWMS.VVxOVz(evName, evShort, evDesc)
    evShort, evDesc = trShort, trLong
    evNameTransl = trName if evName and trName and evName != trName else ""
    if evName          : txt += "Name\t: %s\n"   % FFGB9z(evName, VVUVAI)
    if evNameTransl         : txt += "Name (%s)\t: %s\n" % (CFG.epgLangDescr.getValue().upper(), FFGB9z(evNameTransl, VVUVAI))
    if evTime           : txt += "Start Time\t: %s\n" % FFC3u1(evTime)
    if evTime and evDur        : txt += "End Time\t: %s\n"  % FFC3u1(evTime + evDur)
    if evDur           : txt += "Duration\t: %s\n"  % FF3Odj(evDur)
    if evTime and evDur        :
     now = int(iTime())
     if   now > evTime and now < evTime + evDur : txt += "Remaining\t: %s\n" % FF3Odj(evTime + evDur - now)
     elif now < evTime        : txt += "Starts in\t: %s\n" % FF3Odj(evTime - now)
    if genre          : txt += "Genre\t: %s\n"  % genre
    if PR           : txt += "PC Rating\t: %s\n" % PR
    evShort = str(evShort)
    if evShort           : txt += "\nSummary:\n%s\n"  % FFGB9z(evShort, VVWOjU)
    if evDesc and evDesc.strip()     : txt += "\nDescription:\n%s\n" % FFGB9z(evDesc , VVWOjU)
    if txt:
     txt = FFGB9z("\n%s\n%s Event:\n%s\n" % (SEP, ("Current", "Next")[evNum], SEP), VVUVAI) + txt
  return txt
 @staticmethod
 def VV27tg(txt):
  try:
   from HTMLParser import HTMLParser
   return HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html.parser
   return html.parser.HTMLParser().unescape(txt)
  except:
   pass
  try:
   import html
   return html.unescape(txt)
  except:
   pass
  return txt
class CCdAiy(Screen, CCAmUK):
 VVRIHp  = 0
 VVIrOs = 1
 VV5qCJ  = 2
 VVHRvr  = 3
 VVeJkE = 4
 VVPj3L = 5
 VVuhUG = 6
 VVZ67J   = 7
 def __init__(self, session):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 1000, 1040, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session   = session
  self.filterObj    = None
  self.VVEuus = None
  self.lastfilterUsed  = None
  self.servFilterInFilter = False
  VVZJ87 = self.VVqfnJ()
  FFmmH7(self, VVZJ87=VVZJ87, title="Services/Channels")
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self["myMenu"].setList(self.VVqfnJ())
  FFplRG(self["myMenu"])
  FFR3zK(self)
 def VVqfnJ(self):
  VVZJ87 = []
  c = VVkIQ9
  VVZJ87.append((c + "Open Player Bar"         , "openPlayer"       ))
  VVZJ87.append((c + "Open Signal Monitor"        , "openSignal"       ))
  VVZJ87.append((c + "Current Service Information"      , "currentServiceInfo"     ))
  VVZJ87.append(VVoqHH)
  c = VVUVAI
  VVZJ87.append((c + "Services (Change Parental-Control & Hidden)"  , "lameDB_allChannels_with_refCode"  ))
  VVZJ87.append((c + "Services (Transponders)"       , "lameDB_allChannels_with_tranaponder" ))
  VVZJ87.append((VVLbyB + "More tables ..."     , "VV81Ul"    ))
  c = VVWOjU
  VVZJ87.append(VVoqHH)
  txt = "Import Bouquets from Backup Files"
  if iTar : VVZJ87.append((c + txt          , "VVAGW8"  ))
  else : VVZJ87.append((txt           ,          ))
  VVZJ87.append((c + 'Export Services to "channels.xml"'    , "VVkG6D"      ))
  VVZJ87.append((c + "Copy EPG/PIcons between Channels (from xml file)" , "copyEpgPicons"      ))
  c = VVMrXw
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c + "Satellites Services Cleaner"      , "SatellitesCleaner"     ))
  VVZJ87.append((c + "Invalid Services Cleaner"       , "VVpVPR"    ))
  c = VVMrXw
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c + "Delete Channels with no names"     , "VV52ex"    ))
  VVZJ87.append((c + "Delete Empty Bouquets"       , "VVSvCF"     ))
  VVZJ87.append(VVoqHH)
  VVA5X1, VVW7fq = CCdAiy.VVslUe()
  if fileExists(VVA5X1):
   enab = fileExists(VVW7fq)
   if enab: VVZJ87.append(("Enable Hidden Services List"    , "enableHiddenChannels"    ))
   else   : VVZJ87.append(("Disable Hidden Services List"   , "disableHiddenChannels"    ))
  VVZJ87.append(("Reset Parental Control Settings"      , "VVS2U9"    ))
  VVZJ87.append(("Reload Channels and Bouquets"       , "VVnFbH"      ))
  return VVZJ87
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "openPlayer"       : CCb9j4.VV6JFp(self.session)
   elif item == "openSignal"       : FFdawr(self.session, reopen=True)
   elif item == "currentServiceInfo"     : FFcpNw(self, fncMode=CCjQ0P.VV2TAI)
   elif item == "lameDB_allChannels_with_refCode"  : FFJsIX(self, self.VVupaI)
   elif item == "lameDB_allChannels_with_tranaponder" : FFJsIX(self, self.VVzAsV)
   elif item == "VV81Ul"     : self.VV81Ul()
   elif item == "VVAGW8"  : CCgpQ0.VVAGW8(self)
   elif item == "VVkG6D"      : self.VVkG6D()
   elif item == "copyEpgPicons"      : self.VV1ZF3(False)
   elif item == "SatellitesCleaner"     : FFJsIX(self, self.FFJsIX_SatellitesCleaner)
   elif item == "VVpVPR"    : FFJsIX(self, BF(self.VVpVPR))
   elif item == "VV52ex"    : FFJsIX(self, self.VV52ex)
   elif item == "VVSvCF"     : self.VVSvCF(self)
   elif item == "enableHiddenChannels"     : self.VV8x8o(True)
   elif item == "disableHiddenChannels"    : self.VV8x8o(False)
   elif item == "VVS2U9"    : FFNKVM(self, self.VVS2U9, "Reset and Restart ?")
   elif item == "VVnFbH"      : FFJsIX(self, BF(CCdAiy.VVnFbH, self))
 def VV81Ul(self):
  VVZJ87 = []
  VVZJ87.append(("Services (IDs)"       , "lameDB_allChannels_with_details" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Services (Parental-Control List)"   , "parentalControlChannels"   ))
  VVZJ87.append(("Services (Hidden List)"     , "showHiddenChannels"    ))
  VVZJ87.append(("Services with PIcons for the System"  , "VV2CL6"    ))
  VVZJ87.append(("Services without PIcons for the System" , "servicesWithMissingPIcons"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Transponders (Statistics)"    , "TranspondersStats"    ))
  VVZJ87.append(("Satellites.xml (Statistics)"    , "SatellitesXmlStats"    ))
  FFYySC(self, self.VVhncn, VVZJ87=VVZJ87, title="Service Information", VV18hv=True)
 def VVhncn(self, item):
  if item:
   title, ref, ndx = item
   if   ref == "lameDB_allChannels_with_details" : FFJsIX(self, BF(self.VV95LT, title))
   elif ref == "parentalControlChannels"   : FFJsIX(self, BF(self.VVnuor, title))
   elif ref == "showHiddenChannels"    : FFJsIX(self, BF(self.VVgfbb, title))
   elif ref == "VV2CL6"    : FFJsIX(self, BF(self.VV8Uez, title))
   elif ref == "servicesWithMissingPIcons"   : FFJsIX(self, BF(self.VVV3sx, title))
   elif ref == "TranspondersStats"     : FFJsIX(self, BF(self.VVZJXQ, title))
   elif ref == "SatellitesXmlStats"    : FFJsIX(self, BF(self.VVJG6z, title))
 def VVkG6D(self):
  VVZJ87 = []
  VVZJ87.append(("All DVB-S/C/T Services", "all"))
  VVZJ87.extend(CCSrvY.VVSrxf())
  FFYySC(self, self.VVibMR, VVZJ87=VVZJ87, title="", VV18hv=True)
 def VVibMR(self, item=None):
  if item:
   txt, ref, ndx = item
   if ref == "all" : lst = CCdAiy.VVTLlJ("1:7:")
   else   : lst = FFw4Nf(eServiceReference(ref))
   if lst:
    tot = len(lst)
    if tot > 0:
     rows = []
     for r, n in lst:
      sat = "?"
      serv = eServiceReference(r)
      if serv:
       chPath = serv.getPath()
       if not chPath    : sat = FFPqiq(r, False)
       elif chPath.startswith("/") : sat = "Local"
       elif FFqWLZ(r)  : sat = "Stream Relay"
       elif FF4Jai(r)    : sat = "IPTV"
       rows.append('<!-- %s --><channel id="%s">%s</channel><!-- %s -->\n' % (sat, n, r, n))
     if rows:
      rows.sort()
      fPath = "%schannels_%s.xml" % (FF1vNj(CFG.exportedTablesPath.getValue()), FFUD38())
      with open(fPath, "w") as f:
       f.write('<?xml version="1.0" encoding="utf-8"?>\n')
       f.write('<channels>\n\n')
       for row in rows: f.write(row)
       f.write('\n</channels>\n')
      FF15cM(self, "Saved %d services to:\n\n%s" % (tot, fPath))
      return
   FF5uKN(self, "No Services found !", 1500)
 @staticmethod
 def VVnFbH(SELF):
  FFAvBD()
  FF15cM(SELF, "Finished\n\nReloaded Channels and Bouquets")
 def VVupaI(self):
  self.VVEuus = None
  self.lastfilterUsed  = None
  self.filterObj   = CCdUgX(self)
  VVX3wb, err = CCdAiy.VVcFnp(self, self.VVRIHp)
  if VVX3wb:
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVwmV1  = ("Zap"   , self.VVgXja     , [])
   VVs5AA = (""    , self.VVPBtX   , [])
   VVIrDY = ("Options"  , self.VVJzhI , [])
   VVX66G = ("Current Service", self.VVm0OL , [])
   VVFadD = ("Filter"   , self.VVz8eT  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Sat.", "Reference" , "PC"  , "Hidden" )
   widths   = (24  , 20  , 9  , 34   , 6   , 7   )
   VVFvCJ  = (LEFT  , LEFT  , CENTER, LEFT    , CENTER , CENTER )
   FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindServices)
 def VVzAsV(self):
  self.VVEuus = None
  self.lastfilterUsed  = None
  self.filterObj   = CCdUgX(self)
  VVX3wb, err = CCdAiy.VVcFnp(self, self.VVIrOs)
  if VVX3wb:
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVwmV1  = ("Zap"   , self.VVgXja      , [])
   VVs5AA = (""    , self.VVPBtX    , [])
   VVX66G = ("Current Service", self.VVm0OL  , [])
   VVIrDY = ("Options"  , self.VVlbW5 , [])
   VVFadD = ("Filter"   , self.VVSI5N  , [], "Loading Filters ...")
   header   = ("Name" , "Provider", "Type", "Ref.", "Sat.", "Transponder" , "Freq." , "Pol.", "FEC" , "SR" )
   widths   = (25  , 24  , 14 , 0.01 , 9  , 0.02   , 8   , 5  , 7  , 8  )
   VVFvCJ  = (LEFT  , LEFT  , CENTER, CENTER, CENTER, CENTER   , CENTER , CENTER, CENTER, CENTER)
   FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindServices)
 def VVJzhI(self, VVxBfP, title, txt, colList):
  servName = colList[0].strip()
  refCode  = colList[3].strip()
  pcState  = colList[4].strip()
  hidState = colList[5].strip()
  mSel = CCHw3d(self, VVxBfP)
  VVZJ87 = []
  isMulti = VVxBfP.VVQW9r
  if isMulti:
   refCodeList = VVxBfP.VVf36z(3)
   if refCodeList:
    VVZJ87.append(("Add Selection to Parental Control"  , "parentalControl_sel_add"  ))
    VVZJ87.append(("Remove Selection from Parental Control" , "parentalControl_sel_remove" ))
    VVZJ87.append(VVoqHH)
    VVZJ87.append(("Add Selection to Hidden Services"   , "hiddenServices_sel_add"  ))
    VVZJ87.append(("Remove Selection from Hidden Services" , "hiddenServices_sel_remove" ))
    VVZJ87.append(VVoqHH)
  else:
   txt1 = "Add to Parental Control"
   txt2 = "Remove from Parental Control"
   if pcState == "No":
    VVZJ87.append((txt1, "parentalControl_add" ))
    VVZJ87.append((txt2,        ))
   else:
    VVZJ87.append((txt1,       ))
    VVZJ87.append((txt2, "parentalControl_remove" ))
   VVZJ87.append(VVoqHH)
   txt1 = "Add to Hidden Services"
   txt2 = "Remove from Hidden Services"
   if hidState == "No":
    VVZJ87.append((txt1, "hiddenServices_add"  ))
    VVZJ87.append((txt2,       ))
   else:
    VVZJ87.append((txt1,        ))
    VVZJ87.append((txt2, "hiddenServices_remove" ))
   VVZJ87.append(VVoqHH)
  cbFncDict = { "parentalControl_add"   : BF(self.VVqYJH, VVxBfP, refCode, True)
     , "parentalControl_remove"  : BF(self.VVqYJH, VVxBfP, refCode, False)
     , "hiddenServices_add"   : BF(self.VVRUKW, VVxBfP, refCode, True)
     , "hiddenServices_remove"  : BF(self.VVRUKW, VVxBfP, refCode, False)
     , "parentalControl_sel_add"  : BF(self.VVbT8X, VVxBfP, True)
     , "parentalControl_sel_remove" : BF(self.VVbT8X, VVxBfP, False)
     , "hiddenServices_sel_add"  : BF(self.VVE9CF, VVxBfP, True)
     , "hiddenServices_sel_remove" : BF(self.VVE9CF, VVxBfP, False)
     }
  VVZJ871, cbFncDict1 = CCdAiy.VVoNaY(self, VVxBfP, servName, 3)
  VVZJ87.extend(VVZJ871)
  for key, val in cbFncDict1.items(): cbFncDict[key] = val
  mSel.VVsKHw(VVZJ87, cbFncDict)
 def VVlbW5(self, VVxBfP, title, txt, colList):
  servName = colList[0]
  mSel = CCHw3d(self, VVxBfP)
  VVZJ87, cbFncDict = CCdAiy.VVoNaY(self, VVxBfP, servName, 3)
  mSel.VVsKHw(VVZJ87, cbFncDict)
 @staticmethod
 def VVoNaY(SELF, VVxBfP, servName, refCodeCol):
  tot = VVxBfP.VVsyP1()
  if tot > 0:
   sTxt = FFGB9z("%d Service%s" % (tot, FF1I1d(tot)), VVUVAI)
   VVZJ87 = [("Add %s to Bouquet ..." % sTxt   , "addToBouquet_multi" )]
  else:
   servName = FFxmTk(servName)
   if len(servName) > 20: servName = servName[:20] + ".."
   servName = FFGB9z(servName, VVUVAI)
   VVZJ87 = [('Add "%s" to Bouquet ...' % servName , "addToBouquet_one" )]
  cbFncDict = { "addToBouquet_multi" : BF(CCdAiy.VVntfJ, SELF, VVxBfP, refCodeCol, True)
     , "addToBouquet_one" : BF(CCdAiy.VVntfJ, SELF, VVxBfP, refCodeCol, False)
     }
  return VVZJ87, cbFncDict
 @staticmethod
 def VVntfJ(SELF, VVxBfP, refCodeCol, isMulti):
  picker = CCSrvY(SELF, VVxBfP, "Add to Bouquet", BF(CCdAiy.VV7UFN, VVxBfP, refCodeCol, isMulti))
 @staticmethod
 def VV7UFN(VVxBfP, refCodeCol, isMulti):
  if isMulti : refCodeList = VVxBfP.VVf36z(refCodeCol)
  else  : refCodeList = [VVxBfP.VVc6YJ()[refCodeCol]]
  chUrlLst = []
  for ref in refCodeList:
   chUrlLst.append(ref)
  return chUrlLst
 def VVqYJH(self, VVxBfP, refCode, isAddToBlackList):
  VVxBfP.VVx85I("Processing ...")
  FFFANg(BF(self.VV7BU4, VVxBfP, [refCode], isAddToBlackList))
 def VVbT8X(self, VVxBfP, isAddToBlackList):
  refCodeList = VVxBfP.VVf36z(3)
  if not refCodeList:
   FFw5OO(self, "Nothing selected", title="Change Parental-Control State")
   return
  VVxBfP.VVx85I("Processing ...")
  FFFANg(BF(self.VV7BU4, VVxBfP, refCodeList, isAddToBlackList))
 def VV7BU4(self, VVxBfP, refCodeList, isAddToBlackList):
  for ndx, refCode in enumerate(refCodeList):
   refCode = refCode.strip()
   if not refCode.endswith(":"):
    refCode += ":"
    refCodeList[ndx] = refCode
  changed = False
  if isAddToBlackList:
   if isAddToBlackList:
    with open(VV4DWx, "a") as f:
     for refCode in refCodeList:
      f.write(refCode + "\n")
      changed = True
  elif fileExists(VV4DWx):
   lines = FFZQjt(VV4DWx)
   if lines:
    for refCode in refCodeList:
     while refCode in lines:
      ndx = lines.index(refCode)
      lines[ndx] = ""
      changed = True
    if changed:
     with open(VV4DWx, "w") as f:
      for line in lines:
       if line:
        f.write(line + "\n")
  if changed:
   from Components.ParentalControl import parentalControl
   parentalControl.open()
   isMulti = VVxBfP.VVQW9r
   if isMulti:
    self.VVwrxB(VVxBfP, len(refCodeList))
   else:
    if refCode.endswith(":"):
     refCode = refCode[:-1]
    self.VV7XyS(VVxBfP, refCode)
    VVxBfP.VVW7OH()
  else:
   VVxBfP.VVIzOr("No changes")
 def VVRUKW(self, VVxBfP, refCode, isHide):
  title = "Change Hidden State"
  if FFxrtX(refCode):
   VVxBfP.VVx85I("Processing ...")
   ret = FFxl59(refCode, isHide)
   if ret : FFJsIX(self, BF(self.VV7XyS, VVxBfP, refCode))
   else : FFw5OO(self, "Cannot Hide/Unhide this channel.", title=title)
  else:
   FFw5OO(self, "Cannot Hide/Unhide this channel.\n\n(Invalid transponder)", title=title)
 def VV7XyS(self, VVxBfP, refCode):
  VVX3wb, err = CCdAiy.VVcFnp(self, self.VVRIHp, VVUgwx=[3, [refCode], False])
  done = False
  if VVX3wb:
   data = VVX3wb[0]
   if data[3] == refCode:
    done = VVxBfP.VVBaiu(data)
  if not done:
   self.VVMHkz(VVxBfP, VVxBfP.VVLGq4(), self.VVRIHp)
  VVxBfP.VVW7OH()
 def VVwrxB(self, VVxBfP, totRefCodes):
  VVX3wb, err = CCdAiy.VVcFnp(self, self.VVRIHp, VVUgwx=self.VVEuus)
  VVxBfP.VVcckS(VVX3wb)
  VVxBfP.VVDjjC(False)
  VVxBfP.VVIzOr("%d Processed" % totRefCodes)
 def VVE9CF(self, VVxBfP, isHide):
  refCodeList = VVxBfP.VVf36z(3)
  if not refCodeList:
   FFw5OO(self, "Nothing selected", title="Change Hidden State")
   return
  VVxBfP.VVx85I("Processing ...")
  FFFANg(BF(self.VVBfIx, VVxBfP, refCodeList, isHide))
 def VVBfIx(self, VVxBfP, refCodeList, isHide):
  totChanges = 0
  for refCode in refCodeList:
   ret = FFxl59(refCode, isHide, skipReload=True)
   if ret:
    totChanges += 1
  if totChanges > 0:
   FFAvBD(True)
   self.VVwrxB(VVxBfP, len(refCodeList))
  else:
   VVxBfP.VVIzOr("No changes")
 def VVz8eT(self, VVxBfP, title, txt, colList):
  inFilterFnc = BF(self.VVQTCu, VVxBfP) if self.VVEuus else None
  self.filterObj.VV4hrU(1, VVxBfP, 2, BF(self.VV04Jo, VVxBfP), inFilterFnc=inFilterFnc)
 def VV04Jo(self, VVxBfP, item):
  self.VVJsPA(VVxBfP, False, item, 2, self.VVRIHp)
 def VVQTCu(self, VVxBfP, VV4EHV, item):
  self.VVJsPA(VVxBfP, True, item, 2, self.VVRIHp)
 def VVSI5N(self, VVxBfP, title, txt, colList):
  inFilterFnc = BF(self.VVhmVN, VVxBfP) if self.VVEuus else None
  self.filterObj.VV4hrU(2, VVxBfP, 4, BF(self.VVTkIA, VVxBfP), inFilterFnc=inFilterFnc)
 def VVTkIA(self, VVxBfP, item):
  self.VVJsPA(VVxBfP, False, item, 4, self.VVIrOs)
 def VVhmVN(self, VVxBfP, VV4EHV, item):
  self.VVJsPA(VVxBfP, True, item, 4, self.VVIrOs)
 def VVcIL6(self, VVxBfP, title, txt, colList):
  inFilterFnc = BF(self.VVKgve, VVxBfP) if self.VVEuus else None
  self.filterObj.VV4hrU(0, VVxBfP, 4, BF(self.VVr7h7, VVxBfP), inFilterFnc=inFilterFnc)
 def VVr7h7(self, VVxBfP, item):
  self.VVJsPA(VVxBfP, False, item, 4, self.VV5qCJ)
 def VVKgve(self, VVxBfP, VV4EHV, item):
  self.VVJsPA(VVxBfP, True, item, 4, self.VV5qCJ)
 def VVJsPA(self, VVxBfP, isInFilter, item, satCol, mode):
  self.servFilterInFilter = isInFilter
  if self.lastfilterUsed and self.lastfilterUsed == [item, satCol, mode]:
   return
  self.lastfilterUsed = [item, satCol, mode]
  if   item.startswith("__s__") : col, words, title = satCol, item[5:] , item[5:]
  elif item.startswith("__w__") : col, words, title = 0  , item[5:] , item[5:]
  elif item == "parentalControl" : col, words, title = 4  , "Yes"  , "Parental Control"
  elif item == "hiddenServices" : col, words, title = 5  , "Yes"  , "Hidden Services"
  elif item == "selectedTP"  :
   tp = VVxBfP.VVYzwE(5)
   col, words, title = 5  , tp , tp
  elif item == "emptyTP"   : col, words, title = 6  , "-"  , "Channels with no Transponder"
  else       : col, words, title = None , "All"  , "All"
  title = "Filter = %s" % title
  if len(title) > 55:
   title = title[:55] + ".."
  if col is None:
   self.VVEuus = None
  else:
   words, asPrefix = CCdUgX.VV0Xfy(words)
   self.VVEuus = [col, words, asPrefix]
  if words: FFJsIX(VVxBfP, BF(self.VVMHkz, VVxBfP, title, mode), clearMsg=False)
  else : FF5uKN(VVxBfP, "Incorrect filter", 2000)
 def VVMHkz(self, VVxBfP, title, mode):
  VVX3wb, err = CCdAiy.VVcFnp(self, mode, VVUgwx=self.VVEuus, VV7D78=False)
  if self.servFilterInFilter:
   lst = []
   for row in VVxBfP.VVlHja():
    try:
     ndx = VVX3wb.index(tuple(list(map(str.strip, row))))
     lst.append(VVX3wb[ndx])
    except:
     pass
   VVX3wb = lst
  if VVX3wb:
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVxBfP.VVcckS(VVX3wb, title, VVuO90Msg=True)
  else:
   FF5uKN(VVxBfP, "Not found!", 1500)
 def VVEeyp(self, title, VVarfR, VVwmV1=None, VVs5AA=None, VVZ224=None, VVX66G=None, VVIrDY=None, VVFadD=None):
  VVX66G = ("Current Service", self.VVm0OL, [], )
  header  = ("Name" , "Provider", "Sat.", "Reference" )
  widths  = (29  , 27  , 9  , 35   )
  VVFvCJ = (LEFT  , LEFT  , CENTER, LEFT    )
  FF1Dpj(self, None, title=title, header=header, VVarfR=VVarfR, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindServices)
 def VVm0OL(self, VVxBfP, title, txt, colList):
  self.VVNlg9(VVxBfP)
 def VVfkFs(self, VVxBfP, title, txt, colList):
  self.VVNlg9(VVxBfP, True)
 def VVNlg9(self, VVxBfP, isFromDetails=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  if refCode:
   if isFromDetails:
    refCode  = refCode.upper()
    parts  = refCode.split(":")
    Namespace = parts[6].zfill(8)
    SID   = parts[3].zfill(4)
    TSID  = parts[4].zfill(4)
    ONID  = parts[5].zfill(4)
    colDict  = { 0:chName, 5:Namespace, 6:SID, 7:TSID, 8:ONID }
    VVxBfP.VVp2CY(colDict, VV70Sp=True)
   else:
    VVxBfP.VVr96u(3, refCode, True)
   return
  FFw5OO(self, "Cannot read current Reference Code !")
 def VV95LT(self, title):
  self.VVEuus = None
  self.lastfilterUsed  = None
  self.filterObj   = CCdUgX(self)
  VVX3wb, err = CCdAiy.VVcFnp(self, self.VV5qCJ)
  if VVX3wb:
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVs5AA = (""    , self.VVozpO , []      )
   VVX66G = ("Current Service", self.VVfkFs  , []      )
   VVFadD = ("Filter"   , self.VVcIL6   , [], "Loading Filters ..." )
   VVwmV1  = ("Zap"   , self.VVStPI      , []      )
   header   = ("Name" , "Provider", "Type-Val", "Type" , "Sat.", "Namespace" ,"SID" , "TSID", "ONID" )
   widths   = (24  , 22  , 0   , 16  , 9  , 11   , 6  , 6  , 6    )
   VVFvCJ  = (LEFT  , LEFT  , CENTER , CENTER , CENTER, CENTER  , CENTER, CENTER, CENTER )
   FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVX66G=VVX66G, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindServices)
 def VVozpO(self, VVxBfP, title, txt, colList):
  refCode  = self.VVJY4u(colList)
  chName  = colList[0]
  txt   = "%s\n\n%s" % (title, txt)
  txt   += "Reference\t: %s" % refCode
  FFcpNw(self, fncMode=CCjQ0P.VVJQp5, refCode=refCode, chName=chName, text=txt)
 def VVStPI(self, VVxBfP, title, txt, colList):
  refCode = self.VVJY4u(colList)
  FFkwBg(self, refCode)
 def VVgXja(self, VVxBfP, title, txt, colList):
  FFkwBg(self, colList[3])
 def VVJY4u(self, colList):
  chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID = colList
  refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
  refCode = refCode.replace("::", ":0:")
  return refCode
 @staticmethod
 def VV4Wwj(VVA5X1, mode=0):
  lines = FFZQjt(VVA5X1, encLst=["UTF-8"])
  return CCdAiy.VV7jZ4(lines, mode)
 @staticmethod
 def VV7jZ4(lines, mode):
  lst = []
  header = "transponders" if mode < 10 else "services"
  if header in lines:
   lines = lines[lines.index(header) + 1:]
   if "end" in lines:
    lines = lines[:lines.index("end")]
    if len(lines) % 3 == 0:
     for i in range(0, len(lines), 3):
      if   mode in (0, 10): lst.append((lines[i], lines[i + 1], lines[i + 2]))
      elif mode in (1, 11): lst.append(lines[i].upper())
      elif mode in (2, 12): lst.append(lines[i + 1])
      elif mode in (3, 13): lst.append(lines[i + 2])
  return lst
 @staticmethod
 def VVcFnp(SELF, mode, VVUgwx=None, VV7D78=True, VVPhms=True):
  VVA5X1, err = CCdAiy.VVq36Z(SELF, VVPhms)
  if err:
   return None, err
  asPrefix = False
  if VVUgwx:
   filterCol = VVUgwx[0]
   filterWords = VVUgwx[1]
   asPrefix = VVUgwx[2]
   filterWords = list(filterWords)
   for ndx, item in enumerate(filterWords):
    filterWords[ndx] = item.strip().lower()
  else:
   filterWords = None
  if mode == CCdAiy.VVRIHp:
   blackList = None
   if fileExists(VV4DWx):
    blackList = FFZQjt(VV4DWx)
    if blackList:
     blackList = set(blackList)
  elif mode == CCdAiy.VVIrOs:
   tp = CCyH2c()
  VVqcet, VVT9rY = FFHW7H()
  if mode in (CCdAiy.VVPj3L, CCdAiy.VVuhUG):
   VVX3wb = {}
  else:
   VVX3wb = []
  tagFound = False
  with ioOpen(VVA5X1, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end":
      break
     lines.append(line)
     if len(lines) >= 3:
      chCode = lines[0].upper()
      chName = lines[1]
      chProv = lines[2]
      if chCode.count(":") > 4 and not "," in chCode:
       parts = chCode.split(":")
       SID   = parts[0]
       NameSpace = parts[1]
       TSID  = parts[2]
       ONID  = parts[3]
       STYPE  = parts[4]
      else:
       SID = NameSpace = TSID = ONID = STYPE = SNUM = refCode = ""
      chProvOrig = chProv
      if ","  in chProv : chProv = chProv.split(",")[0].strip()
      if "p:" in chProv : chProv = chProv.split("p:")[1].strip()
      if len(chName) == 0 : chName = "-"
      if len(chProv) == 0 : chProv = "-"
      s = NameSpace.zfill(8)[:4]
      val = int(s, 16)
      sat = FFXHW8(val)
      try:
       sTypeInt = int(STYPE)
       servTypeHex = (hex(sTypeInt))[2:].upper()
      except:
       sTypeInt = 0
       servTypeHex = "0"
      if mode == CCdAiy.VV5qCJ:
       if sTypeInt in VVqcet:
        STYPE = VVT9rY[sTypeInt]
       tRow = (chName, chProv, servTypeHex, STYPE, sat, NameSpace, SID, TSID, ONID)
       if filterWords:
        tmp = tRow[filterCol].lower()
        if asPrefix:
         if any(tmp.startswith(x) for x in filterWords) : VVX3wb.append(tRow)
        elif any(x in tmp for x in filterWords)    : VVX3wb.append(tRow)
       else:
        VVX3wb.append(tRow)
      else:
       refCode = "1:0:%s:%s:%s:%s:%s:0:0:0" % (servTypeHex, SID.lstrip("0"), TSID.lstrip("0"), ONID.lstrip("0"), NameSpace.lstrip("0") )
       refCode = refCode.replace("::", ":0:")
       if mode == CCdAiy.VVZ67J:
        VVX3wb.append((chName, chProv, sat, refCode))
       elif mode == CCdAiy.VVPj3L:
        VVX3wb[refCode.replace(":", "_")] = (chName, sat, 1)
       elif mode == CCdAiy.VVuhUG:
        VVX3wb[chName] = refCode
       elif mode == CCdAiy.VVRIHp:
        if blackList and refCode + ":" in blackList : isBlackList = "Yes"
        else          : isBlackList = "No"
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2 : hidStr = "Yes"
        else          : hidStr =  "No"
        tRow = (chName, chProv, sat, refCode, isBlackList, hidStr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVX3wb.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVX3wb.append(tRow)
        else:
         VVX3wb.append(tRow)
       elif mode == CCdAiy.VVIrOs:
        if sTypeInt in VVqcet:
         STYPE = VVT9rY[sTypeInt]
        freq, pol, fec, sr, syst = tp.VVZ8Ib(refCode)
        if not "-S" in syst:
         sat = syst
        if freq == "-" : tpStr = "-"
        else   : tpStr = sat + " " + freq + " " + pol + " " + fec + " " + sr
        tRow = (chName, chProv, STYPE, refCode, sat, tpStr, freq, pol, fec, sr)
        if filterWords:
         tmp = tRow[filterCol].lower()
         if asPrefix:
          if any(tmp.startswith(x) for x in filterWords) : VVX3wb.append(tRow)
         elif any(x in tmp for x in filterWords)    : VVX3wb.append(tRow)
        else:
         VVX3wb.append(tRow)
       elif mode == CCdAiy.VVHRvr:
        flag = iSearch(r"f:([A-Fa-f0-9]+)", chProvOrig)
        if flag and int(flag.group(1), 16) & 2 == 2:
         VVX3wb.append((chName, chProv, sat, refCode))
       elif mode == CCdAiy.VVeJkE:
        VVX3wb.append((chName, chProv, sat, refCode))
      lines = []
    elif line == "services":
     tagFound = True
  if not VVX3wb and VV7D78:
   FFw5OO(SELF, "No services found!")
  return VVX3wb, ""
 def VVnuor(self, title):
  if fileExists(VV4DWx):
   lines = FFZQjt(VV4DWx)
   if lines:
    newRows = []
    VVX3wb, err = CCdAiy.VVcFnp(self, self.VVeJkE)
    if VVX3wb:
     lines = set(lines)
     for item in VVX3wb:
      refCode = item[3] + ":"
      if refCode in lines:
       newRows.append((item[0], item[1], item[2], refCode))
     if newRows:
      VVX3wb = newRows
      VVX3wb.sort(key=lambda x: x[0].lower())
      VVs5AA = ("", self.VVPBtX, [])
      VVwmV1 = ("Zap", self.VVgXja, [])
      self.VVEeyp(title, VVX3wb, VVwmV1=VVwmV1, VVs5AA=VVs5AA)
     else:
      FF90Bc(self, "No matching Reference Code found !\n\nPC Lines\t: %d\nLameDB\t: %d" % (len(lines), len(VVX3wb)))
   else:
    FF15cM(self, "No active Parental Control services.", FFwrBW())
  else:
   FFZoTn(self, VV4DWx)
 def VVgfbb(self, title):
  VVX3wb, err = CCdAiy.VVcFnp(self, self.VVHRvr)
  if VVX3wb:
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVs5AA = ("" , self.VVPBtX, [])
   VVwmV1  = ("Zap", self.VVgXja, [])
   self.VVEeyp(title, VVX3wb, VVwmV1=VVwmV1, VVs5AA=VVs5AA)
  elif err:
   pass
  else:
   FF15cM(self, "No hidden services.", FFwrBW())
 def VVpVPR(self):
  title = "Services unused in Tuner Configuration"
  VVA5X1, err = CCdAiy.VVq36Z(self, title=title)
  if err:
   return
  nsLst = set()
  usedSats = CCdAiy.VVB2C0()
  for tuner in usedSats:
   for item in tuner[1]:
    ns = self.VVshfX(str(item[0]))
    nsLst.add(ns)
  sysLst = CCdAiy.VVTLlJ("1:7:")
  tpLst  = CCdAiy.VV4Wwj(VVA5X1, mode=1)
  VVX3wb = []
  for refCode, chName in sysLst:
   servID = CCdAiy.VVJ0q7(refCode)
   tpID = CCdAiy.VVh6VM(refCode)
   refNs = refCode.split(":")[6].zfill(8)[:4]
   if not tpID in tpLst or not refNs in nsLst:
    VVX3wb.append((chName, FFPqiq(refCode, False), refCode, servID))
  if VVX3wb:
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVIrDY = ("Options"   , BF(self.VVh2Jr, title), [])
   header   = ("Name" , "Media" , "Reference" , '"lamedb" Code' )
   widths   = (55  , 10  , 0    , 35    )
   VVFvCJ  = (LEFT  , CENTER , LEFT   , CENTER   )
   FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVIrDY=VVIrDY, VVDlGi="#0a001122", VVaSSM="#0a001122", VVzgHY="#0a001122", VVkUYa="#00004455", VVivoO="#0a333333", VVdjpa="#11331100", lastFindConfigObj=CFG.lastFindServices)
  else:
   FF15cM(self, "No invalid service found !", title=title)
 def VVh2Jr(self, Title, VVxBfP, title, txt, colList):
  mSel = CCHw3d(self, VVxBfP)
  isMulti = VVxBfP.VVQW9r
  if isMulti : txt = "Remove %s Services" % FFGB9z(str(VVxBfP.VVsyP1()), VVLbyB)
  else  : txt = "Remove : %s" % FFGB9z(VVxBfP.VVc6YJ()[0], VVLbyB)
  VVZJ87 = [(txt, "del")]
  cbFncDict = {"del": BF(FFJsIX, VVxBfP, BF(self.VVNxx2, VVxBfP, Title))}
  mSel.VVsKHw(VVZJ87, cbFncDict)
 def VVNxx2(self, VVxBfP, title):
  VVA5X1, err = CCdAiy.VVq36Z(self, title=title)
  if err:
   return
  isMulti = VVxBfP.VVQW9r
  skipLst = []
  if isMulti : skipLst = VVxBfP.VVf36z(3)
  else  : skipLst = [VVxBfP.VVc6YJ()[3]]
  tpLst = CCdAiy.VV4Wwj(VVA5X1, mode=0)
  servLst = CCdAiy.VV4Wwj(VVA5X1, mode=10)
  tmpDbFile = VVA5X1 + ".tmp"
  lines   = FFZQjt(VVA5X1)
  skip = False
  with open(tmpDbFile, "w") as f:
   for line in lines:
    tLine = line.strip()
    if tLine == "services":
     skip = True
     f.write(line + "\n")
     for item in servLst:
      if not item[0].upper() in skipLst:
       for L in item:
        f.write(L + "\n")
    elif skip and tLine == "end":
     skip = False
    if not skip:
     f.write(line + "\n")
  FFuB0V("mv -f '%s' '%s'" % (tmpDbFile, VVA5X1))
  VVX3wb = []
  for row in VVxBfP.VVlHja():
   if not row[3] in skipLst:
    VVX3wb.append(row)
  FFAvBD()
  FF90Bc(self, "Removed Services : %d" % len(skipLst), title="Remove Services")
  if VVX3wb:
   VVxBfP.VVcckS(VVX3wb, title)
   VVxBfP.VVDjjC(False)
  else:
   VVxBfP.cancel()
 def VVZJXQ(self, title):
  VVA5X1, err = CCdAiy.VVq36Z(self)
  if err:
   return
  totT, totC, totA, totS, totS2, satList = self.VVvJpK(VVA5X1)
  txt = FFGB9z("Total Transponders:\n\n", VVkqaK)
  txt += "   DVB-S    Satellite\t: %d \n"  % totS
  txt += "   DVB-S2  Satellite\t: %d\n"  % totS2
  txt += "   DVB-T    Terrestrial\t: %d\n" % totT
  txt += "   DVB-C    Cable\t: %d\n"   % totC
  txt += "   DVB-A    ATSC\t: %d\n"   % totA
  if satList and len(satList) > 0:
   txt += FFGB9z("\nSatellite Transponders (Total=%d):\n\n" % (totS + totS2), VVkqaK)
   uniqSat = []
   for sat in satList:
    if not sat in uniqSat:
     uniqSat.append(sat)
   uniqSat.sort(key=lambda x: int(x))
   for item in uniqSat:
    txt += "   %s\t: %d\n" % (FFnBDO(item), satList.count(item))
  FF90Bc(self, txt, title)
 def VVvJpK(self, VVA5X1):
  totT = totC = totA = totS = totS2 = 0
  satList = []
  tagFound = False
  with ioOpen(VVA5X1, "r", encoding="utf-8") as f:
   lines = []
   for line in f:
    line = str(line).strip()
    if tagFound:
     if line == "end"    : break
     elif line.startswith("t")  : totT += 1
     elif line.startswith("c")  : totC += 1
     elif line.startswith("a")  : totA += 1
     elif line.startswith("s"):
      c = line.count(":")
      if   c > 9: totS2 += 1
      elif c > 5: totS  += 1
      if c > 5:
       satList.append(line.split(":")[4])
    elif line == "transponders":
     tagFound = True
  return totT, totC, totA, totS, totS2, satList
 def VVJG6z(self, title):
  path = "/etc/tuxbox/satellites.xml"
  if not fileExists(path):
   FFZoTn(self, path, title=title)
   return
  elif not CCCXvS.VVJWb9(self, path, title):
   return
  if not CCXkrC.VVumgt(self):
   return
  tree = CCdAiy.VVSSCQ(self, path, title=title)
  if not tree:
   return
  VVX3wb = []
  root  = tree.getroot()
  totTpColor = "#f#00FFFF55#"
  for sat in root.findall("sat"):
   name = str(sat.get("name", "").encode("UTF-8").decode())
   pos  = sat.get("position", "")
   totTp = len(sat)
   hor = ver = cirL = cirR = unk = 0
   dvbS = dvbS2 = dvbUnk = 0
   for tp in sat.findall("transponder"):
    pol = tp.get("polarization")
    if   pol == "0" : hor += 1
    elif pol == "1" : ver += 1
    elif pol == "2" : cirL += 1
    elif pol == "3" : cirR += 1
    Sys = tp.get("system")
    if   Sys == "0" : dvbS += 1
    elif Sys == "1" : dvbS2 += 1
   try:
    posNum = int(pos)
    if posNum == 1801:
     posCalc = "180.1E"
    else:
     if posNum < 0:
      posNum += 3600
     posCalc = FFXHW8(posNum)
   except:
    posCalc = "?"
    pos  = "-9999"
   if " " in name : posXml, name = name.split(" ", 1)
   else   : posXml = posCalc
   bg = "" if posCalc.endswith("W") else "#b#00003333#"
   VVX3wb.append((bg + name, pos, posXml, posCalc, totTpColor + str(totTp), str(hor), str(ver), str(cirL), str(cirR), str(dvbS), str(dvbS2)))
  if VVX3wb:
   VVX3wb.sort(key=lambda x: int(x[1]))
   VVX66G = ("Current Satellite", BF(self.VVJtRx, 3), [])
   header   = ("Satellite" , "Pos #" , "xml Pos" , "Position", "TP" , "Hor" , "Ver" , "Circ-L" , "Circ-R" , "DVB-S" , "DVB-S2" )
   widths   = (36    , 8   , 0   , 10  , 6  , 5  , 5  , 7   , 7   , 8   , 8   )
   VVFvCJ  = (LEFT   , CENTER , CENTER , CENTER , CENTER, CENTER, CENTER, CENTER , CENTER , CENTER , CENTER )
   FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=25, VVcLcW=1, VVX66G=VVX66G, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFw5OO(self, "No data found !", title=title)
 def VVJtRx(self, satCol, VVxBfP, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  sat = FFPqiq(refCode, False)
  for ndx, row in enumerate(VVxBfP.VVlHja()):
   if sat == row[satCol].strip():
    VVxBfP.VVYNxS(ndx)
    break
  else:
   FF5uKN(VVxBfP, "No listed !", 1500)
 def FFJsIX_SatellitesCleaner(self):
  satLst = nimmanager.getSatList()
  if not satLst:
   FFw5OO(self, "No Satellites found !")
   return
  usedSats = CCdAiy.VVB2C0()
  VVX3wb = []
  for sat in satLst:
   tunerLst = []
   for tuner, sats in usedSats:
    if sat in sats:
     tunerLst.append(tuner)
   tunerLst.sort()
   tuners = " , ".join(tunerLst) if tunerLst else ""
   posVal = sat[0]
   if posVal > 1800: posTxt = str(posVal - 3600)
   else   : posTxt = str(posVal)
   VVX3wb.append((sat[1], posTxt, FFXHW8(sat[0]), tuners, str(posVal)))
  if VVX3wb:
   VVzgHY = "#11222222"
   VVX3wb.sort(key=lambda x: int(x[1]))
   VVX66G = ("Current Satellite" , BF(self.VVJtRx, 2) , [])
   VVIrDY = ("Options"   , self.VVOakx  , [])
   header   = ("Satellite" , "Pos #" , "Position", "Tuners" , "posVal" )
   widths   = ( 50    , 10  , 10  , 30  , 0   )
   VVFvCJ  = ( LEFT  , CENTER , CENTER , CENTER , CENTER )
   FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=28, VVX66G=VVX66G, VVIrDY=VVIrDY, VVDlGi=VVzgHY, VVaSSM=VVzgHY, VVzgHY=VVzgHY, lastFindConfigObj=CFG.lastFindSatName)
  else:
   FFw5OO(self, "No data found !")
 def VVOakx(self, VVxBfP, title, txt, colList):
  mSel = CCHw3d(self, VVxBfP)
  isMulti = VVxBfP.VVQW9r
  if isMulti : txt = "Remove ALL Services on %s Satellites" % FFGB9z(str(VVxBfP.VVsyP1()), VVLbyB)
  else  : txt = "Remove ALL Services on : %s" % FFGB9z(VVxBfP.VVc6YJ()[0], VVLbyB)
  VVZJ87 = []
  VVZJ87.append((txt, "deleteSat"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Delete Empty Bouquets", "VVSvCF"))
  cbFncDict = { "deleteSat"   : BF(FFJsIX, VVxBfP, BF(self.VVYhU9, VVxBfP))
     , "VVSvCF" : BF(self.VVSvCF, VVxBfP)
     }
  mSel.VVsKHw(VVZJ87, cbFncDict)
 def VVYhU9(self, VVxBfP):
  posLst = []
  isMulti = VVxBfP.VVQW9r
  posLst = []
  if isMulti : posLst = VVxBfP.VVf36z(4)
  else  : posLst = [VVxBfP.VVc6YJ()[4]]
  nsLst = []
  for pos in posLst:
   nsLst.append(self.VVshfX(pos))
  db = eDVBDB.getInstance()
  if db:
   for pos in posLst:
    db.removeServices(-1, -1, -1, int(pos))
  totCh, totBoq = self.VV6S65(nsLst)
  FFAvBD(True)
  FF90Bc(self, "Deleted Satellites:\n%d\n\nDeleted Services:\n%d\n\nCleaned Bouquets:\n%d" % (len(posLst), totCh, totBoq), title="Delete Satellites")
 def VVSvCF(self, winObj):
  title = "Delete Empty Bouquets"
  FFNKVM(self, BF(FFJsIX, winObj, BF(self.VVcXGg, title)), "Delete bouquets with no services ?", title=title)
 def VVcXGg(self, title):
  bList = CCSrvY.VV7U5I()
  bNames = []
  if bList:
   fList = []
   for bName, bRef in bList:
    bFile = CCSrvY.VVArA6(bRef)
    bPath = VVNwTu + bFile
    FFzyFM(bPath)
    bNames.append(bName)
    fList.append(bFile)
   if fList:
    for fil in ("bouquets.tv", "bouquets.radio"):
     path = VVNwTu + fil
     if fileExists(path):
      lines = FFZQjt(path)
      newLines = []
      for line in lines:
       for bFile in fList:
        if bFile in line:
         break
       else:
        newLines.append(line)
      if newLines:
       with open(path, "w") as f:
        f.write("\n".join(newLines) + "\n")
   FFAvBD(True)
  if bNames: txt = "%s\n\n%s" % (FFGB9z("Deleted Bouquets:", VVUVAI), "\n".join(bNames))
  else  : txt = "No empty bouquets."
  FF90Bc(self, txt, title=title)
 def VVshfX(self, pos):
  pos = int(pos.strip())
  if pos < 0:
   pos += 3600
  return ("%04x" % pos).upper()
 def VV6S65(self, nsLst):
  totCh = totBoq = 0
  files = iGlob("%suserbouquet.*.tv" % VVNwTu)
  for srcF in files:
   if fileExists(srcF):
    lines = FFZQjt(srcF)
    newLines = []
    found = False
    for line in lines:
     span = iSearch(r"#SERVICE\s+((?:[A-Za-z0-9]+:){10})$", line, IGNORECASE)
     if span:
      ns = FFqAbm(span.group(1))
      if ns in nsLst:
       found = True
       totCh += 1
       continue
     newLines.append(line)
    if found and newLines:
     totBoq += 1
     with open(srcF, "w") as f:
      f.write("\n".join(newLines) + "\n")
  return totCh, totBoq
 def VV8Uez(self, title)   : self.VV2CL6(title, True)
 def VVV3sx(self, title) : self.VV2CL6(title, False)
 def VV2CL6(self, title, isWithPIcons):
  piconsPath = CCijoe.VV4boJ()
  if pathExists(piconsPath):
   totalPicons = 0
   for fName, fType in CCijoe.VV5WZn(piconsPath):
    if fName:
     totalPicons +=1
   if totalPicons > 0:
    VVX3wb, err = CCdAiy.VVcFnp(self, self.VVeJkE)
    if VVX3wb:
     channels = []
     for (chName, chProv, sat, refCode) in VVX3wb:
      fName = refCode.replace(":", "_") + ".png"
      pFile = FFy54D(piconsPath, fName)
      if isWithPIcons:
       if pFile:
        channels.append((chName, chProv, sat, refCode))
      else:
       if not pFile:
        channels.append((chName, chProv, sat, refCode))
     totalServices = len(VVX3wb)
     totalFound  = len(channels)
     if isWithPIcons:
      totalWithPIcons  = totalFound
      totalMissingPIcons = totalServices - totalWithPIcons
     else:
      totalMissingPIcons = totalFound
      totalWithPIcons  = totalServices - totalMissingPIcons
     def VVYPGf(key, val):
      return "%s\t\t: %s\n" % (key, str(val))
     txt = ""
     txt += VVYPGf("PIcons Path"  , piconsPath)
     txt += VVYPGf("Total PIcons" , totalPicons)
     txt += "\n"
     txt += VVYPGf("Total services" , totalServices)
     txt += VVYPGf("With PIcons"  , totalWithPIcons)
     txt += VVYPGf("Missing PIcons" , totalMissingPIcons)
     if totalFound == 0:
      FF90Bc(self, txt)
     else:
      VVs5AA     = (""      , self.VVPBtX , [])
      if isWithPIcons : VVFadD = ("Export Current PIcon", self.VVWyzu  , [])
      else   : VVFadD = None
      VVIrDY     = ("Statistics", FF90Bc, [txt])
      VVwmV1      = ("Zap", self.VVgXja, [])
      channels.sort(key=lambda x: x[0].lower())
      self.VVEeyp(title, channels, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVIrDY=VVIrDY, VVFadD=VVFadD)
   else:
    FFw5OO(self, "No picons found in path:\n\n%s" % piconsPath)
  else:
   FFw5OO(self, "PIcons path not found.\n\n%s" % piconsPath)
 def VVPBtX(self, VVxBfP, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  txt  = "%s\n\n%s" % (title, txt)
  FFcpNw(self, fncMode=CCjQ0P.VVJQp5, refCode=refCode, chName=chName, text=txt)
 def VVWyzu(self, VVxBfP, title, txt, colList):
  png, path = CCijoe.VVZ9qg(colList[3], colList[0])
  if path:
   CCijoe.VV79QH(self, png, path)
 @staticmethod
 def VVslUe():
  VVA5X1  = "%slamedb" % VVNwTu
  VVW7fq = "%slamedb.disabled" % VVNwTu
  return VVA5X1, VVW7fq
 @staticmethod
 def VVfnOh():
  VV6cOv  = "%slamedb5" % VVNwTu
  VVrphN = "%slamedb5.disabled" % VVNwTu
  return VV6cOv, VVrphN
 def VV8x8o(self, isEnable):
  VVA5X1, VVW7fq = CCdAiy.VVslUe()
  if isEnable and not fileExists(VVW7fq):
   FF15cM(self, "Aready enabled.")
  elif not isEnable and not fileExists(VVA5X1):
   FFw5OO(self, "LameDB File not found!")
  else:
   if isEnable : word = "Enable"
   else  : word = "Disable"
   FFNKVM(self, BF(self.VVPS9I, isEnable), "%s Hidden Channels ?" % word)
 def VVPS9I(self, isEnable):
  VVA5X1 , VVW7fq = CCdAiy.VVslUe()
  VV6cOv, VVrphN = CCdAiy.VVfnOh()
  cmd = ""
  if isEnable:
   word = "Enabled"
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVW7fq, VVW7fq, VVA5X1)
   cmd += "if [ -f '%s' ]; then mv -f '%s' '%s'; fi;"   % (VVrphN, VVrphN, VV6cOv)
  else:
   word = "Disabled"
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VVA5X1  , VVA5X1 , VVW7fq)
   cmd += "if [ -f '%s' ]; then cp -f '%s' '%s'; fi;"   % (VV6cOv , VV6cOv, VVrphN)
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVW7fq, VVA5X1 )
   cmd += "if [ -f '%s' ]; then sed -i 's/,f:2//' '%s'; fi;" % (VVrphN, VV6cOv)
  ok = FFuB0V(cmd)
  FFAvBD()
  if ok: FF15cM(self, "Hidden List %s" % word)
  else : FFw5OO(self, "Error while restoring:\n\n%s" % fileName)
 def VVS2U9(self):
  cmd = ""
  cmd += "echo -e 'Reading current settings ...';"
  cmd += "cat %ssettings | grep -v 'config.ParentalControl' > /tmp/settings_my_tmp.txt;" % VVNwTu
  cmd += "echo -e 'Applying new settings ...';"
  cmd += "mv /tmp/settings_my_tmp.txt %ssettings" % VVNwTu
  FFG0r2(self, cmd)
 def VV52ex(self):
  VVA5X1, err = CCdAiy.VVq36Z(self)
  if err:
   return
  tmpFile = "/tmp/ajp_lamedb"
  FFzyFM(tmpFile)
  totChan = totRemoved = 0
  lines = FFZQjt(VVA5X1, keepends=True)
  with open(tmpFile, "w") as f:
   servFound = False
   servLines = []
   for line in lines:
    if servFound:
     if line.strip() == "end":
      f.write(line)
      break
     else:
      servLines.append(line)
      if len(servLines) == 3:
       if len(servLines[1].strip()) > 0:
        totChan += 1
        f.write(servLines[0])
        f.write(servLines[1])
        f.write(servLines[2])
       else:
        totRemoved += 1
       servLines = []
    else:
     f.write(line)
     if line.strip() == "services":
      servFound = True
  if totRemoved:
   FFNKVM(self, BF(FFJsIX, self, BF(self.VVZYVv, tmpFile, VVA5X1, totRemoved, totChan))
      , "Delete %d servce%s (out of %d service%s) ?" % (totRemoved, FF1I1d(totRemoved), totChan, FF1I1d(totChan))
      , callBack_No=BF(self.VVjxv6, tmpFile))
  else:
   FF90Bc(self, "Total Channels\t: %d\nWith no names\t: %d" % (totChan, totRemoved))
 def VVZYVv(self, tmpFile, VVA5X1, totRemoved, totChan):
  FFuB0V("mv -f '%s' '%s'" % (tmpFile, VVA5X1))
  FFAvBD()
  FF90Bc(self, "Total Channels\t: %d\nTotal Removed\t: %d" % (totChan, totRemoved))
 def VVjxv6(self, tmpFile):
  FFzyFM(tmpFile)
 @staticmethod
 def VVq36Z(SELF, VVPhms=True, title=""):
  VVA5X1, VVW7fq = CCdAiy.VVslUe()
  if   not fileExists(VVA5X1)       : err = "File not found !\n\n%s" % VVA5X1
  elif not CCCXvS.VVJWb9(SELF, VVA5X1) : err = "'lamedb' file is not in 'UTF-8' Encoding !"
  else             : err = ""
  if err and VVPhms:
   FFw5OO(SELF, err, title=title)
  return VVA5X1, err
 @staticmethod
 def VVh6VM(refCode):
  _, flg, _, _, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([ns.zfill(8), tsid.zfill(4), nid.zfill(4)])).upper()
  else   : return ""
 @staticmethod
 def VVJ0q7(refCode):
  _, flg, st, sid, tsid, nid, ns, _, _, _ = refCode.rstrip(":").split(":")
  if flg == "0": return (":".join([sid.zfill(4), ns.zfill(8), tsid.zfill(4), nid.zfill(4), str(int(st, 16)), "0", "0"])).upper()
  else   : return ""
 @staticmethod
 def VVTLlJ(servTypes):
  VVkVSB  = eServiceCenter.getInstance()
  VVjaPa   = '%s ORDER BY name' % servTypes
  VVd2Qg   = eServiceReference(VVjaPa)
  VVkBgw = VVkVSB.list(VVd2Qg)
  if VVkBgw: return VVkBgw.getContent("CN", False)
  else     : return []
 @staticmethod
 def VVB2C0():
  slotSats = []
  for slot in nimmanager.nim_slots:
   if slot.frontend_id is not None:
    lst = nimmanager.getSatListForNim(slot.frontend_id)
    if lst:
     slotSats.append((slot.getSlotName(), lst))
  return slotSats
class CCjQ0P(Screen):
 VV2TAI  = 0
 VV6sNs   = 1
 VVy2hO   = 2
 VVJQp5    = 3
 VVLHuP    = 4
 VVoozH   = 5
 VVPCZ6   = 6
 VV1gCU    = 7
 VVufbi   = 8
 VVzinH   = 9
 VVQdzu   = 10
 VVtg1b   = 11
 def __init__(self, session, **kwargs):
  self.skin, self.skinParam = FFRBRO(VVAtoE, 1400, 1000, 50, 30, 10, "#05001921", "#05001921", 30, addFramedPic=True)
  self.session  = session
  self.fncMode  = kwargs.get("fncMode"  , self.VV2TAI)
  self.callingSELF = kwargs.get("callingSELF" , None)
  self.info   = kwargs.get("info"   , None)
  self.refCode  = kwargs.get("refCode"  , "")
  self.decodedUrl  = kwargs.get("decodedUrl" , "")
  self.origUrl  = kwargs.get("origUrl"  , "")
  self.iptvRef  = kwargs.get("iptvRef"  , "")
  self.chName   = kwargs.get("chName"  , "")
  self.prov   = kwargs.get("prov"   , "")
  self.state   = kwargs.get("state"  , "")
  self.portalMode  = kwargs.get("portalMode" , "")
  self.portalHost  = kwargs.get("portalHost" , "")
  self.portalMac  = kwargs.get("portalMac" , "")
  self.catID   = kwargs.get("catID"  , "")
  self.stID   = kwargs.get("stID"   , "")
  self.chNum   = kwargs.get("chNum"  , "")
  self.chCm   = kwargs.get("chCm"   , "")
  self.serCode  = kwargs.get("serCode"  , "")
  self.serId   = kwargs.get("serId"  , "")
  self.picUrl   = kwargs.get("picUrl"  , "")
  self.picPath  = kwargs.get("picPath"  , "")
  self.text   = kwargs.get("text"   , "")
  self.epg   = kwargs.get("epg"   , "")
  self.chUrl   = kwargs.get("chUrl"  , "")
  self.isIptv   = kwargs.get("isIptv"  , False)
  self.portalEpgUrl = kwargs.get("portalEpgUrl", "")
  self.piconShown  = False
  self.Sep   = FFGB9z("%s\n", VV7jS2) % SEP
  self.picViewer  = None
  FFmmH7(self, title="Service Info.", addScrollLabel=True)
  self["myAction"].actions.update({ "info": self.VVoK92 })
  self["myPicF"] = Label()
  self["myPicB"] = Label()
  self["myPic"] = Pixmap()
  self["myPicF"].hide()
  self["myPicB"].hide()
  self["myPic"].hide()
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  self["myLabel"].VVlfXl(outputFileToSave="chann_info")
  if   self.fncMode == self.VV2TAI : fnc = self.VVfnrn
  elif self.fncMode == self.VV6sNs  : fnc = self.VVfnrn
  elif self.fncMode == self.VVy2hO  : fnc = self.VVfnrn
  elif self.fncMode == self.VVJQp5  : fnc = self.VVaf7V
  elif self.fncMode == self.VVLHuP  : fnc = self.VV1mm2
  elif self.fncMode == self.VVoozH  : fnc = self.VVxjxu
  elif self.fncMode == self.VVPCZ6  : fnc = self.VVMRES
  elif self.fncMode == self.VV1gCU  : fnc = self.VVqQdC
  elif self.fncMode == self.VVufbi  : fnc = self.VV8sLK
  elif self.fncMode == self.VVzinH : fnc = self.VVS10N
  elif self.fncMode == self.VVQdzu  : fnc = self.VVVayC
  elif self.fncMode == self.VVtg1b : fnc = self.VV9gFr
  self["myLabel"].setText("\n   Reading Info ...")
  self["myLabel"].VVFhN7()
  FFFANg(fnc)
 def onExit(self):
  if self.picViewer:
   self.picViewer.VVMxHB()
 def VVgEQM(self, err):
  self["myLabel"].setText(err)
  FFWN9Z(self["myTitle"], "#22200000")
  FFWN9Z(self["myBody"], "#22200000")
  self["myLabel"].VVgbSO("#22200000")
  self["myLabel"].VVFhN7()
 def VVfnrn(self):
  try:
   dum = self.session
  except:
   return
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  self.refCode = refCode
  self.VVwYG5(chName)
 def VVaf7V(self):
  self.VVwYG5(self.chName)
 def VV1mm2(self):
  self.VVwYG5(self.chName)
 def VVxjxu(self):
  self.VVwYG5(self.chName)
 def VVMRES(self):
  self.VVwYG5("Picon Info")
 def VVqQdC(self):
  self.VVwYG5(self.chName)
 def VV8sLK(self):
  self.VVwYG5(self.chName)
 def VVS10N(self):
  self.VVwYG5(self.chName)
 def VVVayC(self):
  if self.chCm.startswith("Zz1") : self.chUrl = FFH6Pe(self.chCm[3:])
  else       : self.chUrl = self.refCode + self.callingSELF.VVESRp(self.portalMode, self.chCm, self.serCode, self.serId)
  self.VVwYG5(self.chName)
 def VV9gFr(self):
  self.VVwYG5(self.chName)
 def VVwYG5(self, title):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFGh4f(self, addInfoObj=True)
  if info and refCode.rstrip(":") == self.refCode.rstrip(":"):
   self.text  = self.VVS9bZ(info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state)
   self.info  = info
   self.refCode = refCode
   self.decodedUrl = decodedUrl
   self.origUrl = origUrl
   self.iptvRef = iptvRef
   self.chName  = chName
   self.prov  = prov
   self.state  = state
   self.isIptv  = len(iptvRef) > 0
  else:
   tUrl = self.portalEpgUrl or self.decodedUrl or self.iptvRef or self.chUrl
   if tUrl:
    if not self.text.endswith("\n"):
     self.text += "\n"
    self.text += "\nURL:\n%s\n" % FFGB9z(self.VV07qf(tUrl), VVGb6D)
  if not self.epg:
   epg = CCvWMS.VVYb1s(self.info, self.refCode)
   if epg:
    self.epg = epg
    self.text += self.epg
  if not self.piconShown and self.picPath:
   self.piconShown = self.VVuHn9(self.picPath)
  if not self.piconShown and self.refCode and self.chName:
   png, path = CCijoe.VVZ9qg(self.refCode, self.chName)
   if png:
    self.picPath = path
    self.piconShown = self.VVuHn9(path)
  self.VV38wX()
  self.VVdINd(decodedUrl)
  self["myLabel"].setText(self.text or "   No active service", VV4VK0=VVBTEe)
  if self["myPicF"].getVisible() : minH = self["myPicF"].instance.size().height()
  else       : minH = 0
  self["myLabel"].VVFhN7(minHeight=minH)
 def VVdINd(self, decodedUrl):
  url = max([self.refCode, self.chUrl, self.iptvRef, self.portalEpgUrl], key=len)
  if not FF4Jai(url):
   return
  url = url.replace("%3a", ":").replace("%3A", ":")
  span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})(.+)", url, IGNORECASE)
  if span:
   self.refCode = span.group(1).upper().rstrip(":")
   url    = span.group(2)
  if "?" in url:
   url = url[:url.index("?")]
  epg, picUrl, err = self.VVnrij(FFlOsc(url))
  if not epg:
   if self.portalEpgUrl: epg, err = CCsdD3.VVNA3Q(self.portalEpgUrl)
   else    : epg, err = CCsdD3.VVNA3Q(decodedUrl)
  if epg:
   self.text += "\n" + FFfR82("EPG:", VVUVAI) + epg
  if picUrl:
   self.picUrl = picUrl
   self.VV38wX()
 def VV38wX(self):
  if not self.piconShown and self.picUrl:
   path, err = FFtKyC(self.picUrl, "ajp_tmp.png", timeout=2, mustBeImage=True)
   if path:
    self.piconShown = self.VVuHn9(path)
    if self.piconShown and self.refCode:
     self.VV2a8f(path, self.refCode)
 def VV2a8f(self, path, refCode):
  if path and fileExists(path) and FFhcfU("ffmpeg"):
   pPath = CCijoe.VV4boJ()
   if pathExists(pPath):
    picon = refCode.replace(":", "_").rstrip("_") + ".png"
    cmd = CCjQ0P.VV92Yh(path)
    cmd += FFIV1X("mv -f '%s' '%s%s'" % (path, pPath, picon)) + ";"
    FFuB0V(cmd)
 def VVuHn9(self, path):
  if path and fileExists(path):
   err, w, h = self.VVMoOV(path)
   if not err:
    if h > w:
     self.VV1fPF(self["myPicF"], w, h, True)
     self.VV1fPF(self["myPicB"], w, h, False)
     self.VV1fPF(self["myPic"] , w, h, False)
   self.picViewer = CC5J0P.VVDKxb(self["myPic"], path)
   if self.picViewer:
    self["myPicF"].show()
    self["myPicB"].show()
    self["myPic"].show()
    return True
  return False
 def VV1fPF(self, obj, picW, picH, isFrame):
  w  = obj.instance.size().width()
  pos  = obj.getPosition()
  left = pos[0]
  top  = pos[1]
  newW = obj.instance.size().width() * 0.6
  newH = newW * picH / picW
  if isFrame:
   newW += 2
  obj.instance.resize(eSize(*(int(newW), int(newH))))
  obj.instance.move(ePoint(int(left + int(w - newW)), int(top)))
 def VVMoOV(self, path):
  cmd = "ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=X:p=0 '%s' 2> /dev/null" % path
  res = FF3RLi(cmd)
  if "X" in res:
   w, h = res.split("X")
   if w.isdigit() and h.isdigit() : return "", int(w), int(h)
   else       : return res, -1, -1
  else:
   return res, -1, -1
 def VVS9bZ(self, info, refCode, decodedUrl, origUrl, iptvRef, chName, prov, state):
  txt = ""
  txt += "Service Name\t: %s\n" % FFGB9z(chName, VVUVAI)
  txt += self.VVYPGf(info, "Provider"     , iServiceInformation.sProvider     )
  if state:
   if not state == "Tuned":
    state = FFGB9z(state, VVsObI)
   txt += "State\t: %s\n" % state
  w = FFSmtF(info       , iServiceInformation.sVideoWidth    ) or -1
  h = FFSmtF(info       , iServiceInformation.sVideoHeight    ) or -1
  if w != -1 and h != -1:
   txt += "Dimensions\t: %s x %s\n" % (w, h)
  aspect = self.VVm3uK(info)
  if aspect:
   txt += "Video Format\t: %s\n" % aspect
  txt += self.VVYPGf(info, "Video Type"    , iServiceInformation.sVideoType  , 4  )
  txt += self.VVYPGf(info, "Frame Rate"    , iServiceInformation.sFrameRate  , 5  )
  txt += self.VVYPGf(info, "Crypted"     , iServiceInformation.sIsCrypted  , 3  )
  tot = self.VVgBsi()
  if tot > -1: txt += "Audio Tracks\t: %d\n" % tot
  tot = self.VVmo2P()
  if tot > -1: txt += "Subtitles\t: %d\n" % tot
  fPath, fDir, fName, picFile = CCjQ0P.VVo8yW(self)
  isLocal = False
  isIptv  = len(iptvRef) > 0
  if isIptv:
   txt += "Service Type\t: %s\n" % FFGB9z("Stream-Relay" if FFqWLZ(decodedUrl) else "IPTV", VVkqaK)
   txt += self.VVk2BR(iptvRef)
  elif fPath:
   isLocal = True
   txt += "Reference\t: %s\n" % ":".join(refCode.split(":")[:10])
   txt += "Service Type\t: Local Recording\n"
   txt += "Directory\t: %s\n" % fDir
   if picFile and fileExists(picFile):
    self.picPath = picFile
  elif refCode:
   txt += "Reference\t: %s\n" % refCode
  if not isLocal:
   txt += "\n"
   txt += self.VVtsje(refCode, iptvRef, chName)
  if not isLocal and not isIptv:
   txt += "\n"
   txt += self.Sep
   namespace = None
   if refCode:
    tp = CCyH2c()
    tpTxt, namespace = tp.VV5Spu(refCode)
    if tpTxt:
     txt += FFGB9z("Tuner:\n", VVUVAI)
     txt += tpTxt
     txt += "\n"
     txt += self.Sep
   txt += FFGB9z("Codes:\n", VVUVAI)
   if namespace: txt += "Namespace\t: %s\n" % namespace
   else  : txt += self.VVYPGf(info, "Namespace" , iServiceInformation.sNamespace  , 1, 8 )
   txt += self.VVYPGf(info, "Video PID"    , iServiceInformation.sVideoPID   , 2, 4 )
   txt += self.VVYPGf(info, "Audio PID"    , iServiceInformation.sAudioPID   , 2, 4 )
   txt += self.VVYPGf(info, "PCR PID"     , iServiceInformation.sPCRPID   , 2, 4 )
   txt += self.VVYPGf(info, "PMT PID"     , iServiceInformation.sPMTPID   , 2, 4 )
   txt += self.VVYPGf(info, "TXT PID"     , iServiceInformation.sTXTPID   , 2, 4 )
   txt += self.VVYPGf(info, "SID"      , iServiceInformation.sSID    , 2, 4 )
   txt += self.VVYPGf(info, "ONID"      , iServiceInformation.sONID    , 2, 4 )
   txt += self.VVYPGf(info, "TSID"      , iServiceInformation.sTSID    , 2, 4 )
  return txt
 @staticmethod
 def VVm3uK(info):
  if info:
   aspect = FFSmtF(info, iServiceInformation.sAspect)
   if aspect.isdigit():
    aspect = int(aspect)
    if aspect in ( 1, 2, 5, 6, 9, 0xA, 0xD, 0xE ) : return "4:3"
    else           : return "16:9"
  return ""
 def VVYPGf(self, info, name, what, mode=0, digits=0):
  tab = "\t"
  txt = str(FFSmtF(info, what))
  if len(txt) > 0:
   try  : hexVal = hex(int(txt))[2:].upper()
   except : hexVal = ""
   if digits > 0:
    hexVal = hexVal.zfill(digits)
   if   mode == 1     : txt = hexVal
   elif mode == 2     : txt = "%s\tdec: %s" % (hexVal, txt)
   elif mode == 3     : txt = "Yes" if txt=="1" else "No"
   elif mode == 4     : txt = self.VV08IK(txt)
   elif mode == 5 and txt.isdigit(): txt = str(int(txt)/1000)
   if txt : return "%s%s: %s\n" % (name, tab, txt)
   else : return ""
  else:
   return ""
 def VV08IK(self, sVideoType):
  codec_data = { -1: "", 0: "MPEG-2", 1: "H.264 (MPEG-4 AVC)", 2: "H.263", 3: "VC1", 4: "MPEG-4 (VC)", 5: "VC1-SM", 6: "MPEG-1", 7: "H.265 (HEVC)", 8: "VP8", 9: "VP9", 10: "XVID", 11: "11", 12: "12", 13: "DIVX 3.11", 14: "DIVX 4", 15: "DIVX 5", 16: "AVS", 17: "17", 18: "VP6", 19: "19", 20: "20", 21: "SPARK" }
  return codec_data.get(int(sVideoType), "")
 def VVgBsi(self):
  try:
   return self.session.nav.getCurrentService().audioTracks().getNumberOfTracks() or 0
  except:
   return -1
 def VVmo2P(self):
  try:
   return len(InfoBar.instance.getCurrentServiceSubtitle().getSubtitleList())
  except:
   return -1
 def VVtsje(self, refCode, iptvRef, chName):
  refCode = FFunPR(refCode, iptvRef, chName)
  if not refCode:
   return self.Sep + "Bouquet\t: -\n"
  fList = []
  txt = FFQ5la(VVNwTu + "bouquets.tv")
  list =  iFindall(r"(userbouquet[.].*[.]tv)", txt, IGNORECASE)
  if list: fList += list
  txt = FFQ5la(VVNwTu + "bouquets.radio")
  list =  iFindall(r"(userbouquet[.].*[.]radio)", txt, IGNORECASE)
  if list: fList.extend(list)
  VVarfR = []
  tmpRefCode = FFlOsc(refCode)
  for item in fList:
   path = VVNwTu + item
   if fileExists(path):
    txt = FFQ5la(path)
    if tmpRefCode in FFlOsc(txt):
     span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
     if span : bName = span.group(1)
     else : bName = "[ No Name ]"
     VVarfR.append((bName, os.path.basename(path)))
  txt = self.Sep
  if VVarfR:
   if len(VVarfR) == 1:
    txt += "%s\t: %s%s\n" % (FFGB9z("Bouquet", VVUVAI), VVarfR[0][0], " (%s)" % VVarfR[0][1] if VVoWDM else "")
   else:
    txt += FFGB9z("Bouquets:\n", VVUVAI)
    for ndx, item in enumerate(VVarfR):
     txt += "%d- %s%s\n" % (ndx + 1, item[0].strip(), " (%s)" % item[1] if VVoWDM else "")
  else:
   txt += "Bouquet\t: -\n"
  return txt
 def VVk2BR(self, refCode):
  refCode, decodedUrl, origUrl, iptvRef = FFzRjC(refCode)
  if decodedUrl:
   txt = "Reference\t: %s\n" % refCode
   p = CCsdD3()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVdTlz(decodedUrl)
   del p
   if host : txt += "Portal Host\t: %s\n" % host
   if mac : txt += "Portal MAC\t: %s\n" % mac
   if mode : txt += "Portal Mode\t: %s\n" % mode.upper()
   txt += "\n"
   txt += FFGB9z("URL:", VVkqaK) + "\n%s\n" % self.VV07qf(decodedUrl)
  else:
   txt = "\n"
   txt += FFGB9z("Reference:", VVkqaK) + "\n%s\n" % refCode
  return txt
 def VV07qf(self, url):
  if not FFqWLZ(url):
   span = iSearch(r"(?:[A-Fa-f0-9]+[:]){10}(.+)", url, IGNORECASE)
   if span:
    url = span.group(1)
   if not VV8Ixy:
    url = iSub(r"[&?]mode=.+end=", r"", url, flags=IGNORECASE)
  return FFlOsc(url)
 def VVnrij(self, decodedUrl):
  if not CC66h0.VVP0Wq():
   return "", "", "No internet connection !"
  uType, uHost, uUser, uPass, uId, uChName = CC9X9s.VVXxn6(decodedUrl)
  if not all([uHost, uUser, uPass, uId]):
   return "", "", "No EPG (invalid ULR) !"
  qUrl = "%s/player_api.php?username=%s&password=%s&action=" % (uHost, uUser, uPass)
  if   uType == "live" : qUrl += "get_simple_data_table&stream_id=%s" % (uId)
  elif uType == "movie" : qUrl += "get_vod_info&vod_id=%s" % (uId)
  elif uType == "series" : return "", "", "No EPG for Series Channels !"
  txt, err = CC9X9s.VVuaOC(qUrl, timeout=1)
  tDict = {}
  if err:
   return "", "", "No EPG from server (%s)" % err
  else:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    return "", "", "Could not parse server data !"
  epg = picUrl = ""
  if tDict:
   if   uType == "live" : epg = self.VV21Og(tDict)
   elif uType == "movie" : epg, picUrl = CCjQ0P.VVRvxH(tDict)
  err = "" if epg else "No EPG from server !"
  return epg, picUrl, err
 def VV21Og(self, tDict):
  epg = lang = ""
  if "epg_listings" in tDict:
   try:
    evNum = 1
    for item in tDict["epg_listings"]:
     tTitle    = CC9X9s.VVV2zK(item, "title"    , is_base64=True )
     lang    = CC9X9s.VVV2zK(item, "lang"         ).upper()
     description   = CC9X9s.VVV2zK(item, "description"  , is_base64=True ).replace("\n", " .. ")
     start_timestamp  = CC9X9s.VVV2zK(item, "start_timestamp" , isDate=True  )
     start_timestamp_unix= CC9X9s.VVV2zK(item, "start_timestamp"      )
     stop_timestamp  = CC9X9s.VVV2zK(item, "stop_timestamp"  , isDate=True  )
     stop_timestamp_unix = CC9X9s.VVV2zK(item, "stop_timestamp"       )
     now_playing   = CC9X9s.VVV2zK(item, "now_playing"       )
     skip = False
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
     except:
      pass
     if not skip:
      if now_playing == "0": color, txt = VVqFea, ""
      else     : color, txt = VVsObI , "    (CURRENT EVENT)"
      epg += FFGB9z("_" * 32 + "\n", VV7jS2)
      epg += FFGB9z("Event\t: %d%s\n" % (evNum, txt), color)
      epg += "Start\t: %s\n"   % start_timestamp
      epg += "End\t: %s\n"   % stop_timestamp
      epg += "Title\t: %s\n"   % tTitle
      if description : epg += "Description:\n%s\n" % FFGB9z(description, VVGb6D)
      else   : epg += "Description\t: - \n"
      evNum += 1
      try:
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       totEv, totOK = CCvWMS.VV2PtB(self.refCode, [(start, dur, tTitle, shortDesc, description, 1)], longDescDays=7)
      except:
       pass
   except:
    pass
  if lang:
   epg = "Language\t: %s\n\n%s" % (lang.capitalize(), epg)
  return epg
 @staticmethod
 def VVRvxH(tDict):
  epg = movie_image = ""
  if "info" in tDict:
   try:
    item = tDict["info"]
    movie_image = CC9X9s.VVV2zK(item, "movie_image" )
    genre  = CC9X9s.VVV2zK(item, "genre"   ) or "-"
    plot  = CC9X9s.VVV2zK(item, "plot"   ) or "-"
    country  = CC9X9s.VVV2zK(item, "country"  ) or "-"
    actors  = CC9X9s.VVV2zK(item, "actors"   ) or "-"
    cast  = CC9X9s.VVV2zK(item, "cast"   ) or "-"
    rating  = CC9X9s.VVV2zK(item, "rating"   ) or "-"
    director = CC9X9s.VVV2zK(item, "director"  ) or "-"
    releasedate = CC9X9s.VVV2zK(item, "releasedate" ) or "-"
    duration = CC9X9s.VVV2zK(item, "duration"  ) or "-"
    try:
     lang = CC9X9s.VVV2zK(tDict["info"]["audio"]["tags"], "language")
     if lang:
      epg += "Language\t: %s\n" % lang.capitalize()
    except:
     pass
    epg += "Genre\t: %s\n"   % genre
    epg += "Released\t: %s\n"  % releasedate
    epg += "Country\t: %s\n"  % country
    epg += "Duration\t: %s\n"  % duration
    epg += "Director\t: %s\n"  % director
    epg += "Rating\t: %s\n\n"  % rating
    epg += "Cast:\n%s\n\n"   % FFGB9z(cast if cast != "-" else actors, VVGb6D)
    epg += "Plot:\n%s"    % FFGB9z(plot, VVGb6D)
   except:
    pass
  return epg, movie_image
 def VVoK92(self):
  if VV8Ixy:
   def VVYPGf(key, val):
    return "%s= %s\n" % (key.ljust(12), val)
   txt = ""
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
   n = ("refCode" , "decodedUrl" , "origUrl" , "iptvRef" , "chName" , "prov", "state" )
   v = (refCode , decodedUrl , origUrl , iptvRef , chName , prov , state  )
   for i in range(len(n)):
    txt += VVYPGf(n[i], v[i])
   if "chCode" in iptvRef:
    p = CCsdD3()
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVdTlz(decodedUrl)
    n = ("valid", "ph1" , "playHost", "mode", "host", "mac" , "epNum" , "epId", "chCm", "query" )
    v = (valid , ph1 , playHost , mode , host , mac , epNum  , epId , chCm , query  )
    for i in range(len(n)):
     txt += VVYPGf(n[i], v[i])
   path = "/tmp/ajp_channel_details"
   with open(path, "a") as f:
    f.write("%s\n%s\n" % (SEP, txt))
   FF5uKN(self, "Saved to : %s" % path, 1000)
 @staticmethod
 def VVBOlG(SELF):
  if not CC2hCu.VViy1e(SELF):
   return
  title = "File Size"
  fSize = "Not received from server"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(SELF)
  err = url =  fSize = resumable = ""
  if FFEjXT(decodedUrl):
   url = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
   url = iSub(r"[?]play_token.+", r"", url, flags=IGNORECASE)
   if url.endswith(":" + chName):
    url = url[:-(len(chName) + 1)]
   if "chCode" in decodedUrl:
    url = CCsdD3.VVF0ln(decodedUrl)
   try:
    import requests
    resp = requests.get(url, headers=CCsdD3.VVvvDS(), timeout=4, stream=True, verify=False)
    if not resp.ok:
     FFw5OO(SELF, "Err-%d : %s" % (resp.status_code, resp.reason), title=title)
     return
    hSize = resp.headers.get("Content-Length", "")
    if hSize and hSize.isdigit():
     size = int(hSize)
     fSize = CCCXvS.VVutW7(size)
     if "vnd.apple" in resp.headers.get("content-type", ""):
      fSize += FFGB9z(" (M3U/M3U8 File)", VVGb6D)
    else:
     fSize = "No info. from server. Try again later."
    resumable = "Yes" if CCrhIe.VV1r2k(resp) else "No"
   except requests.Timeout as e: err = "Connection Timeout"
   except      : err = "Connection Error"
  else:
   err = "Not a Movie/Series !"
  def VVpQZy(subj, val):
   return "%s\n%s\n\n" % (FFGB9z("%s:" % subj, VVUVAI), val)
  title = "File Size"
  txt  = VVpQZy(title , fSize or "?")
  txt += VVpQZy("Name" , chName)
  txt += VVpQZy("URL" , url)
  if resumable: txt += VVpQZy("Supports Download-Resume", resumable)
  if err  : txt += FFGB9z("Error:\n", VVsObI) + err
  FF90Bc(SELF, txt, title=title)
 @staticmethod
 def VVo8yW(SELF):
  fPath, fDir, fName = CCCXvS.VV6Qx4(SELF)
  if fPath:
   fPic = ""
   fName, fExt = os.path.splitext(fName)
   for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
    pic = "%s%s.%s" % (fDir, fName, ext)
    if fileExists(pic):
     fPic = pic
     break
   return fPath, fDir, fName, fPic
  else:
   return "", "", "", ""
 @staticmethod
 def VV92Yh(path):
  return "ffmpeg -y -i '%s' -vf scale=-1:132 '%s' > /dev/null 2>&1;" % (path, path)
 @staticmethod
 def VVcMJR(refCode):
  span = iSearch(r"((?:[A-Fa-f0-9]+:){9}(?:[A-Fa-f0-9]+))", refCode.rstrip(":"))
  if span:
   pPath = CCijoe.VV4boJ() + span.group(1).strip(":").replace(":", "_").upper() + ".png"
   return pPath
  return ""
 @staticmethod
 def VV4GBq(serv):
  isLocal = isIptv = isFtp = isDvb = isDvbS = isDvbC = isDvbT = False
  typeTxt = chPath = ""
  if serv:
   refCode = serv.toString() or ""
   chPath = serv.getPath() or ""
   if "file?file" in refCode or ":ftp%3a//" in refCode:
    isFtp = True
    typeTxt = "FTP"
   elif FF4Jai(refCode):
    isIptv = True
    typeTxt = "IPTV"
   elif chPath.startswith("/"):
    isLocal = True
    typeTxt = "Local Media"
   elif not chPath:
    isDvb = True
    ns = FFqAbm(refCode)
    if   ns.startswith("EEEE") : isDvbT, typeTxt = True, "DVB-T"
    elif ns.startswith("FFFF") : isDvbC, typeTxt = True, "DVB-C"
    else      : isDvbS, typeTxt = True, "DVB-S"
  return isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath
class CCsdD3():
 def __init__(self):
  self.VVuM1W()
  self.VVTex6    = ""
  self.VVDPUO   = "#f#11ffffaa#User"
  self.VVpyaD   = "#f#11aaffff#Server"
 def VVuM1W(self):
  self.VV4Xnp   = ""
  self.VVktxB    = ""
  self.VVCsmZ   = ""
  self.VVWPyC = ""
  self.VV414J  = ""
  self.VVUq9A = 0
 def VVhVda(self, url, mac, ph1="", VV70Sp=True):
  self.VVuM1W()
  self.VVTex6 = {"s": "/server/load.php", "p": "/portal.php", "q": "/portal1.php"}.get(ph1, "")
  host = self.VVV1cj(url)
  if not host:
   if VV70Sp:
    self.VVl8O9("Incorrect URL Format !\n\n%s" % url)
   return False
  mac = self.VVtJ1J(mac)
  if not host:
   if VV70Sp:
    self.VVl8O9("Incorrect MAC Format !\n\n%s" % mac)
   return False
  self.VV4Xnp = host
  self.VVktxB  = mac
  return True
 def VV224Q(self):
  return {"/server/load.php":"s", "/portal.php":"p", "/portal1.php":"q"}.get(self.VVTex6, "")
 def VVV1cj(self, url):
  if url.endswith("mac=") : url = url[:-4]
  if url.endswith("mac") : url = url[:-4]
  url = url.rstrip("/?")
  if url.endswith("/c") : url = url[:-2]
  url = url.rstrip("/ :")
  span = iSearch(r"(.+)(\/playlist.+mac)", url, IGNORECASE)
  if span:
   url = span.group(1)
  return url
 def VVtJ1J(self, mac):
  span = iSearch(r"((?:[A-Fa-f0-9]{2}:){5}[A-Fa-f0-9]{2})", mac, IGNORECASE)
  if span : return span.group(1).upper()
  else : return ""
 def VVlMNQ(self):
  res, err = self.VVxaAJ(self.VVN7Px())
  if "404" in err or res and res.status_code == 200 and not res.text.strip():
   if self.VV4Xnp.endswith("/c"):
    self.VV4Xnp = self.VV4Xnp[:-2]
    res, err = self.VVxaAJ(self.VVN7Px())
   elif self.VV4Xnp.endswith("/stalker_portal"):
    self.VV4Xnp = self.VV4Xnp[:-15]
    res, err = self.VVxaAJ(self.VVN7Px())
   else:
    self.VV4Xnp += "/c"
    res, err = self.VVxaAJ(self.VVN7Px())
  token = rand = ""
  if not err:
   try:
    tDict = jLoads(res.text)         #
    token = CC9X9s.VVV2zK(tDict["js"], "token")
    rand  = CC9X9s.VVV2zK(tDict["js"], "random")
   except:
    pass
  return token.strip(), rand.strip(), err
 def VVHGWF(self, VV70Sp=True):
  if not self.VVTex6:
   self.VVLHnP()
  err = blkMsg = FF15cMTxt = ""
  try:
   token, rand, err = self.VVlMNQ()
   if token:
    self.VVCsmZ = token
    self.VVWPyC = rand
    if rand:
     self.VVUq9A = 2
    prof, retTxt = self.VVBv8Y(True)
    if prof:
     self.VV414J = retTxt
     if any(x in retTxt for x in ("device_id mismatch", "old firmware")):
      self.VVUq9A = 3
      prof, retTxt = self.VVBv8Y(False)
      if retTxt:
       self.VV414J = retTxt
    return token, prof, ""
  except:
   pass
  tErr = err or "Could not get Token from server !"
  if blkMsg or FF15cMTxt:
   tErr += "\n"
   if blkMsg: tErr += "\n%s" % blkMsg
   if FF15cMTxt: tErr += "\n%s" % FF15cMTxt
  if VV70Sp:
   self.VVl8O9(tErr)
  return "", "", tErr
 def VVLHnP(self):
  try:
   import requests
   url = self.VV95q4()
   jsFile = "xpcom.common.js"
   res = requests.get("%s/stalker_portal/c/%s" % (url, jsFile), headers=CCsdD3.VVvvDS(), stream=True, timeout=2)
   if not res.ok or not "javascript" in res.headers.get("content-type"):
    res = requests.get("%s/c/%s" % (url, jsFile), headers=CCsdD3.VVvvDS(), stream=True, timeout=2)
   if res.ok and "javascript" in res.headers.get("content-type"):
    patt = ""
    for line in res.iter_lines():
     if line:
      line = str(line.decode('utf-8'))
      span = iSearch(r"\s*var\s+pattern\s*=\s*\/(.+)\/\s*;", line, IGNORECASE)
      if span:
       patt = span.group(1)
      span = iSearch(r".+ajax_loader.+'(\/.+\.php)'", line, IGNORECASE)
      if span:
       if "portal_path" in line:
        if patt.endswith("*\/(.)*") : url += "/c"
        else      : url += "/stalker_portal"
       self.VV4Xnp = url
       self.VVTex6 = span.group(1)
       return
  except:
   pass
  self.VVTex6 = "/server/load.php"
 def VV95q4(self):
  url = self.VV4Xnp.rstrip("/")
  if url.endswith("/c")    : url = url[:-2]
  if url.endswith("/stalker_portal") : url = url[:-15]
  if url.endswith("/c")    : url = url[:-2]
  return url
 def VVr1jo(self, url, isJsFile=False):
  import requests
  jsFile = "xpcom.common.js" if isJsFile else "version.js"
  res, err = self.VVxaAJ("%s/stalker_portal/c/%s" % (url, jsFile))
  if not res or not "javascript" in res.headers.get("content-type"):
   res, err = self.VVxaAJ("%s/c/%s" % (url, jsFile))
  if res and "javascript" in res.headers.get("content-type"):
   if isJsFile:
    return str(res.content), ""
   else:
    span = iSearch(r"var\s+ver\s*=\s*'(.+)'", res.text, IGNORECASE)
    if span:
     return span.group(1), ""
  return "", err
 def VVBv8Y(self, capMac):
  res, err = self.VVxaAJ(self.VVSGbt(capMac))
  if not err:
   try:
    tDict = jLoads(res.text)
    word = "m" + "sg"
    blkMsg = CC9X9s.VVV2zK(tDict["js"], "block_%s" % word)
    FF15cMTxt = CC9X9s.VVV2zK(tDict["js"], word)
    return tDict, FF15cMTxt.strip() or blkMsg.strip()
   except:
    pass
  return "", ""
 def VVSGbt(self, capMac):
  param = ""
  if self.VV414J or self.VVWPyC:
   param = self.getMoreAuth_params(self.getMoreAuth_IDs(self.VVktxB.upper() if capMac else self.VVktxB.lower(), self.VVWPyC))
  return self.VVOGA2() + "type=stb&action=get_profile" + param
 exec(FFH6Pe("ZGVmIGdldE1vcmVBdXRoX3BhcmFtcyhzZWxmLCBJZCk6DQogcGFyYW0gPSAiJmF1dGhfc2Vjb25kX3N0ZXA9MSZod192ZXJzaW9uPTIuMTctSUItMDAmaHdfdmVyc2lvbl8yPTYyJnNuPSVzJmRldmljZV9pZD0lcyZkZXZpY2VfaWQyPSVzJnNpZ25hdHVyZT0lcyIgJSAoSWRbMF0sIElkWzFdLCBJZFsxXSwgSWRbMl0pDQogcmV0dXJuIHBhcmFtICsgJyZ2ZXI9UGxheWVyIEVuZ2luZSB2ZXJzaW9uOiAweDU4YyZtZXRyaWNzPXsibWFjIjoiJXMiLCJzbiI6IiVzIiwidHlwZSI6IlNUQiIsIm1vZGVsIjoiTUFHMjUwIiwicmFuZG9tIjoiJXMifScgJSAoSWRbM10sIElkWzBdLCBJZFs0XSkNCmRlZiBnZXRNb3JlQXV0aF9JRHMoc2VsZiwgbSwgcik6DQogaW1wb3J0IGhhc2hsaWINCiBtYWNVdGY4ID0gbS5lbmNvZGUoJ3V0Zi04JykNCiBzID0gaGFzaGxpYi5tZDUobWFjVXRmOCkuaGV4ZGlnZXN0KCkudXBwZXIoKVs6MTNdDQogcmV0dXJuIHMsIGhhc2hsaWIuc2hhMjU2KG1hY1V0ZjgpLmhleGRpZ2VzdCgpLnVwcGVyKCksIGhhc2hsaWIuc2hhMjU2KChzICsgbSkuZW5jb2RlKCd1dGYtOCcpKS5oZXhkaWdlc3QoKS51cHBlcigpLCBtLCBy"))
 def VVYXWK(self, forceMoreInfo=False):
  rows = []
  if not forceMoreInfo:
   rows = self.VV28zt()
  if len(rows) < 10:
   rows = self.VVgCcA()
  if not rows or len(rows[0]) == 2:
   rows.append(("Host"    , self.VV4Xnp ))
   rows.append(("MAC (from URL)" , self.VVktxB ))
   rows.append(("Token"   , self.VVCsmZ ))
   rows.sort(key=lambda x: x[0].lower())
   return rows, 2
  else:
   rows.append(("1", self.VVDPUO  , "MAC" , self.VVktxB ))
   rows.append(("2", self.VVpyaD, "Host" , self.VV4Xnp ))
   rows.append(("2", self.VVpyaD, "Token" , self.VVCsmZ ))
   rows.sort(key=lambda x: (x[0], x[2]))
   return rows, 4
 def VV6EQ6(self, isPhp=True, VV70Sp=False):
  token, profile, tErr = self.VVHGWF(VV70Sp)
  if not token:
   return "", "", "", "", tErr
  m3u_Url = host = user1 = pass1 = err=  ""
  url = self.VVcgqg()
  res, err = self.VVxaAJ(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    m3u_Url = CC9X9s.VVV2zK(tDict["js"], "cmd")
    m3u_Url = m3u_Url.replace("ffmpeg ", "")
    span = iSearch(r"(http.+)\/(.+)\/(.+)(\/\?.+)", m3u_Url, IGNORECASE)
    if span:
     host = span.group(1)
     user1 = FFGN9H(span.group(2))
     pass1 = FFGN9H(span.group(3))
     if isPhp:
      m3u_Url = "%s/player_api.php?username=%s&password=%s" % (host, user1, pass1)
     else:
      m3u_Url = "%s/%s/%s/" % (host, user1, pass1)
   except:
    pass
  return m3u_Url, host, user1, pass1, err
 def VV28zt(self):
  m3u_Url, host, user1, pass1, err = self.VV6EQ6()
  rows = []
  if m3u_Url:
   res, err = self.VVxaAJ(m3u_Url)
   if not err:
    try:
     tDict = jLoads(res.text)
     for key, val in tDict["user_info"].items() :
      if any(x in key for x in ("exp_date", "created_at")): val = FFC3u1(int(val))
      if isinstance(val, list): val = str(" , ".join(val))
      else     : val = str(val)
      rows.append(("1", self.VVDPUO, str(key).replace("_", " ").title(), val))
     for key, val in tDict["server_info"].items():
      if "timestamp_now"  in key : val = FFC3u1(int(val))
      else      : val = str(val)
      rows.append(("2", self.VVpyaD, str(key).replace("_", " ").title(), val))
    except:
     pass
  return rows
 def VVgCcA(self):
  token, profile, tErr = self.VVHGWF()
  try:
   item = profile["js"]
  except:
   return []
  if not isinstance(item, dict):
   return []
  rows = []
  c  = "#f#11ffff55#"
  rows = []
  for key, val in item.items():
   if not val:
    continue
   try:
    if key == "mac":
     if val and FFQXBr(val): val = FFH6Pe(val.decode("UTF-8"))
     else     : val = self.VVktxB
    elif key == "play_token":
     parts = val.split(":")
     if len(parts) == 3:
      pToken = parts[0]
      started = FFC3u1(int(parts[1]))
      if parts[2] : ends = FFC3u1(int(parts[1]) + int(parts[2]))
      else  : ends = ""
      val = "%s (%s ... %s)" % (pToken, started, ends)
    elif key == "aspect":
     val = " , ".join(["%s=%s" % (k, v) for k, v in jLoads(val)["js"].items()])
    elif key in ("created", "last_watchdog"):
     val = FFC3u1(int(val))
    elif isinstance(val, list):
     val = str(" , ".join(val))
    elif isinstance(val, dict):
     val = str(val).replace("u'", "").replace("'", "").strip("{} ")
    else:
     val = str(val).strip()
   except:
    val = str(val)
   rows.append(((str(key).replace("_", " ").title(), str(val))))
  return rows
 def VVESRp(self, mode, chCm, epNum, epId):
  token, profile, tErr = self.VVHGWF(VV70Sp=False)
  if not token:
   return ""
  crLinkUrl = self.VVXThX(mode, chCm, epNum, epId)
  res, err = self.VVxaAJ(crLinkUrl)
  chUrl = ""
  if not err:
   try:
    chUrl = CC9X9s.VVV2zK(jLoads(res.text)['js'], "cmd")
   except:
    pass
  chUrl = chUrl.replace("ffmpeg ", "")
  chUrl = chUrl.replace(":", "%3a")
  chUrl = chUrl.replace("auto ", "")
  return chUrl
 def VVOGA2(self):
  return self.VV4Xnp + self.VVTex6 + "?"
 def VVN7Px(self):
  return self.VVOGA2() + "type=stb&action=handshake&token=&mac=%s" % self.VVktxB
 def VVfDrn(self, mode):
  url = self.VVOGA2() + "type=%s&action=" % mode
  if   mode == "itv"  : url += "get_genres"
  elif mode == "vod"  : url += "get_categories&force_ch_link_check="
  elif mode == "series": url += "get_categories"
  return url
 def VVsbtE(self, catID):
  return self.VVOGA2() + "type=series&action=get_ordered_list&sortby=added&movie_id=%s&p=1" % catID
 def VVpV08(self, mode, catID, page):
  url = self.VVOGA2() + "type=%s&action=get_ordered_list&sortby=number&p=%d&" % (mode, page)
  if mode == "itv": url += "genre=%s" % catID
  else   : url += "category=%s&force_ch_link_check=" % catID
  return url
 def VVoP7A(self, mode, searchName, catId, page):
  catId = ("&category=%s" % catId) if catId else ""
  return self.VVOGA2() + "type=%s&action=get_ordered_list&search=%s&%s&p=%d" % (mode, searchName, catId, page)
 def VVCGo7(self, stID):
  return self.VVOGA2() + "type=itv&action=get_short_epg&ch_id=%s" % stID
 def VVXThX(self, mode, chCm, serCode, serId):
  url = self.VVOGA2() + "action=create_link&"
  if mode == "series" : url += "type=vod&series=%s&cmd=/media/%s.mpg" % (serCode, serId)
  else    : url += "type=%s&cmd=%s&forced_storage=0&disable_ad=0&download=0" % (mode, chCm)
  return url
 def VVcgqg(self):
  return self.VVOGA2() + "type=itv&action=create_link"
 def VVJNpF(self, host, mac, mode, chName, catID, stID, chNum, chCm, serCode, serId):
  refCode = self.VVcDWB(catID, stID, chNum)
  query = self.VVqtiW(mode, self.VV224Q(), FFjhdq(host), FFjhdq(mac), serCode, serId, chCm, catID, stID)
  if chCm.endswith(".m3u8") : chUrl = "%s?%s" % (chCm, query)
  else      : chUrl = "%s/j.php?%s" % (host, query)
  chUrl = refCode + chUrl.replace(":", "%3a") + ":" + chName
  return refCode, chUrl
 def VVqtiW(self, mode, ph1, host, mac, serCode, serId, chCm, catID, stID):
  query = "mode=%s&ph1=%s&hst=%s&chCode=%s&epNum=%s&epId=%s&cId=%s&sId=%s&chCm=%s&end=" % (mode, ph1, host, mac, serCode, serId, catID, stID, chCm)
  return query.replace("ffmpeg ", "").replace(":", "%3a")
 def VVdTlz(self, url):
  if   "mode=itv"  in url: mode = "itv"
  elif "mode=vod"  in url: mode = "vod"
  elif "mode=series" in url: mode = "series"
  else       : return False, "", "", "", "", "", "", "", "", "", "", ""
  res  = iUrlparse(url)
  scheme = res.scheme
  netloc = res.netloc
  tDict = iUrlparse_qs(res.query)
  ph1  = tDict.get("ph1" , [""])[0].strip()
  host = tDict.get("hst" , [""])[0].strip()
  mac  = tDict.get("chCode", [""])[0].strip()
  epNum = tDict.get("epNum" , [""])[0].strip().replace(":" , "%3a")
  epId = tDict.get("epId" , [""])[0].strip().replace(":" , "%3a")
  chCm = tDict.get("chCm" , [""])[0].strip().replace("ffmpeg ", "").replace(":" , "%3a")
  catID = tDict.get("cId" , [""])[0].strip()
  stID = tDict.get("sId" , [""])[0].strip()
  query = self.VVqtiW(mode, ph1, host, mac, epNum, epId, FFGN9H(chCm), catID, stID)
  if scheme: scheme += "://"
  playHost = scheme + netloc
  host  = FFH6Pe(host)
  mac   = FFH6Pe(mac)
  valid = False
  if self.VVV1cj(playHost) and self.VVV1cj(host) and self.VVV1cj(mac):
   if (mode in ("itv", "vod") and chCm) or (mode == "series" and epNum and epId):
    valid = True
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query
 def VVxaAJ(self, url, useCookies=True):
  try:
   import requests
  except:
   return "", 'The "Requests" library is not installed'
  err = ""
  try:
   headers = CCsdD3.VVvvDS()
   if self.VVCsmZ:
    headers["Authorization"] = "Bearer %s" % self.VVCsmZ
   if useCookies : cookies = {"mac": self.VVktxB, "stb_lang": "en"}
   else   : cookies = None
   res = requests.get(url, headers=headers, allow_redirects=True, timeout=CFG.portalConnTimeout.getValue(), cookies=cookies)
   if res.ok:
    return res, ""
   else:
    if res.status_code == 407: reason = "Proxy Authentication Required"
    else      : reason = "Unknown"
    err = "Err-%d : %s" % (res.status_code, res.reason or reason)
  except requests.Timeout as e     : err = "Connection Timeout"
  except requests.ConnectionError as e   : err = "Connection Error"
  except requests.exceptions.RequestException as e: err = "Request Error"
  except Exception as e       : err = "Error\n" + str(e)[:120]
  return "", err
 @staticmethod
 def VV8GpE(url, verify=False):
  try:
   import requests
   resp = requests.get(url, headers=CCsdD3.VVvvDS(), timeout=3, verify=verify)
   if resp.ok : return str(resp.text) , ""
   else  : return ""    , "Error %d\n\n%s" % (resp.status_code, resp.reason)
  except:
   return "", "Error while contacting server !"
 @staticmethod
 def VVvvDS():
  return {'User-Agent': "Mozilla/5.0 (QtEmbedded; U; Linux; C; Emulator/1.2.12) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
 def VVl8O9(self, err, title="Portal Browser"):
  FFw5OO(self, str(err), title=title)
 def VVzaKN(self, mode):
  if   mode in ("itv"  , CC9X9s.VVymqZ , CC9X9s.VVTObo)  : return "Live"
  elif mode in ("vod"  , CC9X9s.VVJ6qH , CC9X9s.VVPA9X)  : return "VOD"
  elif mode in ("series" , CC9X9s.VVKYG7 , CC9X9s.VVhOAc) : return "Series"
  else                          : return "IPTV"
 def VVfC9z(self, mode, searchName):
  return 'Find in %s : %s' % (self.VVzaKN(mode), FFGB9z(searchName, VVGb6D))
 def VVS5Zj(self, catchup=False):
  VVZJ87 = []
  VVZJ87.append(("Live"    , "live"  ))
  VVZJ87.append(("VOD"    , "vod"   ))
  VVZJ87.append(("Series"   , "series"  ))
  if catchup:
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Catch-up TV" , "catchup"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Account Info." , "accountInfo" ))
  return VVZJ87
 @staticmethod
 def VVN5jb(decodedUrl):
  m3u_Url = host = user1 = pass1 = streamId = ""
  p = CCsdD3()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVdTlz(decodedUrl)
  if valid:
   ok = p.VVhVda(host, mac, ph1, VV70Sp=False)
   if ok:
    m3u_Url, host1, user1, pass1, err = p.VV6EQ6(isPhp=False, VV70Sp=False)
    streamId = CCsdD3.VVckbE(decodedUrl)
  return valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err
 @staticmethod
 def VVckbE(decodedUrl):
  p = CCsdD3()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVdTlz(decodedUrl)
  if valid and chCm:
   if   mode == "itv"  : patt = r'.+ch\/(\d+)_'
   elif mode == "vod"  : patt = r'stream_id":"*(\d+)'
   elif mode == "series": patt = r'series_id":"*(\d+)'
   span = iSearch(patt, FFH6Pe(chCm), IGNORECASE)
   if span:
    return span.group(1)
  return ""
 @staticmethod
 def VVF0ln(decodedUrl):
  p = CCsdD3()
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVdTlz(decodedUrl)
  if valid:
   if CCsdD3.VVxY6P(chCm):
    return FFlOsc(chCm)
   else:
    ok = p.VVhVda(host, mac, ph1, VV70Sp=False)
    if ok:
     try:
      chUrl = p.VVESRp(mode, chCm, epNum, epId)
      return FFlOsc(chUrl)
     except:
      pass
  return ""
 @staticmethod
 def VVxY6P(chCm):
  return chCm.startswith("http") and not "//localhost/" in chCm
 @staticmethod
 def VVNA3Q(decodedUrl, retLst=False):
  epg = err = res = ""
  if "mode=itv" in decodedUrl:
   p = CCsdD3()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVdTlz(decodedUrl)
   if valid:
    if not stID:
     stID = CCsdD3.VVckbE(decodedUrl)
    if stID:
     if p.VVhVda(host, mac, ph1, VV70Sp=False):
      token, profile, tErr = p.VVHGWF(VV70Sp=False)
      if token:
       res, err = p.VVxaAJ(p.VVCGo7(stID))
       if res: epg, err = CCsdD3.VVP87L(res.text, retLst)
  return epg, err
 @staticmethod
 def VVP87L(txt, retLst=False):
  epg, lst = "", []
  try:
   tDict = jLoads(txt)
   evNum = 1
   for item in tDict["js"]:
    actor    = CC9X9s.VVV2zK(item, "actor"       )
    category   = CC9X9s.VVV2zK(item, "category"      )
    descr    = CC9X9s.VVV2zK(item, "descr"   , is_base64=True).replace("\n", " .. ")
    director   = CC9X9s.VVV2zK(item, "director"      )
    name    = CC9X9s.VVV2zK(item, "name"   , is_base64=True)
    start_timestamp  = CC9X9s.VVV2zK(item, "start_timestamp", isDate=True )
    start_timestamp_unix= CC9X9s.VVV2zK(item, "start_timestamp"    )
    stop_timestamp  = CC9X9s.VVV2zK(item, "stop_timestamp" , isDate=True )
    stop_timestamp_unix = CC9X9s.VVV2zK(item, "stop_timestamp"     )
    if retLst:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ""
       lst.append((start, dur, name, shortDesc, descr, 1))
     except:
      pass
    else:
     skip, curEv = False, ""
     try:
      if float(stop_timestamp_unix) < iTime():
       skip = True
      if float(start_timestamp_unix) < iTime() and float(stop_timestamp_unix) > iTime():
       curEv = FFGB9z("    (CURRENT EVENT)", VVkIQ9)
     except:
      pass
     if not skip:
      epg += FFGB9z("_" * 32 + "\n", VV7jS2)
      epg += "Event\t: %d%s\n" % (evNum, curEv)
      epg += "Title\t: %s\n"  % FFGB9z(name, VVUVAI)
      epg += "Start\t: %s\n"  % start_timestamp
      epg += "End\t: %s\n"  % stop_timestamp
      epg += "Description:\n%s\n" % FFGB9z(descr , VVGb6D) if descr else "Description\t: - \n"
      epg += "Genre:\n%s\n"  % FFGB9z(category, VVGb6D) if category else ""
      epg += "Actors:\n%s\n"  % FFGB9z(actor , VVGb6D) if actor else ""
      epg += "Director:\n%s\n" % FFGB9z(director, VVGb6D) if director else ""
      evNum += 1
  except:
   return "", "Cannot parse received data !"
  if retLst: return lst, ""
  else  : return epg, ""
class CCdmJK(CCsdD3):
 def __init__(self):
  CCsdD3.__init__(self)
  self.mode   = ""
  self.refCode  = ""
  self.chName   = ""
  self.iptvRef  = ""
  self.chCm   = ""
  self.epNum   = ""
  self.epId   = ""
  self.query   = ""
 def VVfc6w(self, refCode, chName, decodedUrl, iptvRef):
  valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = self.VVdTlz(decodedUrl)
  if valid:
   if self.VVhVda(host, mac, ph1, VV70Sp=False):
    self.mode  = mode
    self.refCode = refCode
    self.chName  = chName
    self.iptvRef = iptvRef
    self.chCm  = chCm
    self.epNum  = epNum
    self.epId  = epId
    self.query  = query
    return True
  return False
 def VVwvmQ(self, passedSELF=None, isFromSession=False):
  chUrl = ""
  if self.chCm.startswith("Zz1"):
   self.chCm = FFH6Pe(self.chCm[3:])
  else:
   try:
    chUrl = self.VVESRp(self.mode, self.chCm, self.epNum, self.epId)
   except:
    return False
  isDirect = False
  if CCsdD3.VVxY6P(self.chCm):
   chUrl = FFlOsc(self.chCm)
   chUrl = FFGN9H(self.chCm)
   chUrl = chUrl.replace("%253a", "%3a")
   if not "?" in chUrl:
    chUrl += "?"
  elif " " in self.chCm or " " in chUrl:
   if " " in chUrl:
    chUrl = chUrl.split(" ")[1]
   if not "?" in chUrl:
    chUrl += "?"
  if not chUrl.startswith("http"):
   return False
  if not self.refCode.endswith(":"):
   self.refCode += ":"
  chUrl = chUrl.strip()
  chUrl = self.refCode + chUrl + ":" + self.chName
  newIptvRef = self.VVzr8l(chUrl)
  bPath = CCSrvY.VVPlYj()
  if newIptvRef:
   if passedSELF:
    FFkwBg(passedSELF, newIptvRef, VVIC8r=False, fromPortalReplay=True, isFromSession=isFromSession)
   else:
    FFkwBg(self, newIptvRef, VVIC8r=False, fromPortalReplay=True)
   if self.iptvRef and newIptvRef and bPath:
    serv = eServiceReference(newIptvRef)
    newCode = serv and serv.toString()
    if newCode:
     self.VVOBlK(self.iptvRef, newCode, bPath)
   return True
  else:
   return False
 def VVzr8l(self, chUrl):
  newIptvRef = ""
  playMarks = ("play_token=", "/play/", "lid=")
  for toFind in playMarks:
   if toFind in chUrl:
    ndx = chUrl.find(toFind)
    if ndx > -1:
     ndx = chUrl.find(":", ndx)
     if ndx > -1:
      left  = chUrl[:ndx]
      right  = chUrl[ndx:]
      newIptvRef = left + "&" + self.query + right
    break
  if not newIptvRef:
   x1 = chUrl.find("?")
   if x1 > -1:
    x2 = chUrl[x1:].find(":")
    if x2 > -1:
     newIptvRef = chUrl[:x1+x2] + "&" + self.query + chUrl[x1+x2:]
  return newIptvRef
 def VVOBlK(self, oldCode, newCode, bPath):
  patt = r"((?:[A-Fa-f0-9]+[:]){10}).+(mode=.+)chCm="
  span = iSearch(patt, newCode, IGNORECASE)
  if span:
   newRef, newPar = span.group(1).upper(), span.group(2)
   params = ("&ph1=s", "&ph1=p", "&ph1=q", "&ph1=")
   for param in params: newPar = newPar.replace(param, "")
   lines = FFZQjt(bPath)
   for ndx, line in enumerate(lines):
    span = iSearch(patt, line, IGNORECASE)
    if span:
     fileRef, filePar = span.group(1).upper(), span.group(2)
     if newRef == fileRef:
      for param in params: filePar = filePar.replace(param, "")
      if newPar == filePar:
       lines[ndx] = "#SERVICE %s" % newCode
       with open(bPath, "w") as f: f.write("\n".join(lines) + "\n")
       FFAvBD()
class CCAPNc(CCdmJK):
 def __init__(self, passedSession):
  CCdmJK.__init__(self)
  self.passedSession = passedSession
  self.lastRef  = ""
  self.startTime  = iTime()
  self.timer1   = eTimer()
  self.timer2   = eTimer()
  self.dnldWin  = None
  self.isFromEOF  = False
  Main_Menu.VVq9lG(VVn0Sb  )
  Main_Menu.VVq9lG(VVGtks)
  Main_Menu.VVq9lG(VV4JdF  )
  try:
   from Components.ServiceEventTracker import ServiceEventTracker
   from enigma import iPlayableService
   evTrk = ServiceEventTracker(screen=self.passedSession.screen, eventmap={iPlayableService.evStart: self.VVc5Fe, iPlayableService.evEOF: self.VVzzE1, iPlayableService.evEnd: self.VVNxGN})
  except:
   pass
  try:
   self.timer_conn = self.timer2.timeout.connect(self.VVv2fa)
  except:
   self.timer2.callback.append(self.VVv2fa)
  self.timer2.start(3000, False)
  self.VVv2fa()
 def VVv2fa(self):
  if not CFG.downloadMonitor.getValue():
   self.VVkTTE()
   return
  lst = CCrhIe.VVjUzR()
  avPerc = []
  txt = ""
  if lst:
   for path, totSz, logF in lst:
    if totSz:
     totSz = int(totSz) if totSz.isdigit() else 0
     curSz = 0
     sz = FFqLWj(path)
     if sz > -1:
      curSz = sz
     if totSz:
      perc = (float(curSz) / float(totSz) * 100.0)
      avPerc.append(perc)
    elif logF:
     perc = CCrhIe.VVMUAC(logF)
     if perc > -1:
      avPerc.append(perc)
   if lst:
    txt = "Files=%d" % len(lst)
    if avPerc:
     perc = sum(avPerc) / len(avPerc)
     if perc: txt += "   %.2f %%" % perc
  if txt:
   if not self.dnldWin : self.dnldWin = CC03RI.VV9BLi(self.passedSession, txt, 30)
   else    : CC03RI.VVxNiI(self.dnldWin, txt)
  elif self.dnldWin:
   self.VVkTTE()
 def VVkTTE(self):
  if self.dnldWin:
   self.passedSession.deleteDialog(self.dnldWin)
   self.dnldWin = None
 def VVc5Fe(self):
  self.startTime = iTime()
 def VVzzE1(self):
  global VV94uO
  VV94uO = ".....EOF....."
  if CFG.autoResetFrozenIptvChan.getValue() and (iTime() - self.startTime) > 5:
   serv = self.passedSession.nav.getCurrentlyPlayingServiceReference()
   if serv:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self.passedSession, isFromSession=True)
    if iptvRef and not "file?file" in iptvRef and not ":ftp%3a//" in iptvRef and not FFEjXT(decodedUrl):
     self.isFromEOF = True
     CC03RI(self.passedSession, "Refreshing")
     self.passedSession.nav.stopService()
     self.passedSession.nav.playService(serv)
     InfoBar.instance.hide()
     self.startTime = iTime()
 def VVNxGN(self):
  self.startTime = iTime()
  try:
   self.timer1_conn = self.timer1.timeout.connect(self.VVOOAC)
  except:
   self.timer1.callback.append(self.VVOOAC)
  self.timer1.start(100, True)
 def VVOOAC(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self.passedSession, isFromSession=True)
  if decodedUrl:
   span = iSearch(r"(mode=.+end=)", decodedUrl, IGNORECASE)
   if span:
    ref = span.group(1)
    if self.isFromEOF or not ref == self.lastRef:
     valid = self.VVfc6w(refCode, chName, decodedUrl, iptvRef)
     if valid:
      self.lastRef = ref
      if self.isFromEOF or not CCb9j4.VVavYK:
       self.isFromEOF = False
       self.VVwvmQ(self.passedSession, isFromSession=True)
class CC6gLq():
 def __init__(self):
  self.removeTag  = CFG.hideIptvServerChannPrefix.getValue()
  self.hideAdult  = CFG.hideIptvServerAdultWords.getValue()
  self.beInTagPatt = r"(b[-]*e[-]*I[-]*N)"
  self.beInRepl  = r"beIN"
  self.nameTagPatt = iCompile( r"\s*^[A-Za-z]{2,3}\d*\s*[|:-]+\s*(.+)"
          r"|^(?!\[)*\s*[\[(|:][ A-Za-z0-9\/\-._:|\]\[]+[\])|:](.+)"
          r"|^[A-Za-z]{,3}[^\x00-\x7F](.+)")
  self.prefixRemoveList = self.VVBd1X(self.removeTag, "ajpanel_iptv_prefix", False, ())
  self.adultWords = self.VVBd1X(self.hideAdult, "ajpanel_iptv_blacklist", True, ("adult","aduld","sex","porn","xxx","xxi","erotic","x-rated","xrated","skin flick","dirty movie","dirty film","blue movie","blue film","18+","+18","r18 movie","r18 film","r-18 movie","r-18 film","r-17 movie","r-17 film"))
 def VVBd1X(self, cond, fName, isLower, tSet):
  tSet = set(tSet)
  if cond:
   for path in (VVrrZu, VVNemM):
    path += fName
    if fileExists(path):
     for line in FFZQjt(path):
      line = line.strip()
      if len(line) >= 3:
       tSet.add(line.lower() if isLower else line)
  return tuple(sorted(tSet, key=lambda x: x.lower()))
 def VVbGFt(self, name,  censored=""):
  if self.hideAdult and (censored == "1" or any(x in name.lower() for x in self.adultWords)):
   return ""
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  if CC9X9s.VVNowk(name):
   return CC9X9s.VVumjC(name)
  return self.VVe8u8(name)
 def VVe8u8(self, name):
  newName = ""
  if self.removeTag:
   span = iSearch(self.nameTagPatt, name)
   if span:
    tName = span.group(1) or span.group(2) or span.group(3)
    if not tName.startswith(("HD", "[HD]", "SD", "[SD]")):
     newName = tName
   for t in self.prefixRemoveList:
    if name.startswith(t):
     newName = name[len(t):]
     break
  return newName.strip() or name
 def VVrS8k(self, name):
  name = iSub(self.beInTagPatt, self.beInRepl, name, flags=IGNORECASE).strip()
  name = self.VVe8u8(name)
  return name.lower().replace(" hd", "").replace(" fm", "").replace(" 4k", "").replace(" tv", "").replace(" sd", "").strip()
 def VV3HOG(self, name):
  if self.hideAdult:
   tName = name.lower()
   if any(x in tName for x in self.adultWords):
    return ""
  return name.strip()
 def VVEvvi(self, wordsList):
  return any(x in self.adultWords for x in wordsList)
 def VVVfjQ(self):
  return 'Cannot continue with adults words !\n\n"Skip Adults Channels" is activated in settings.'
class CC2hCu(CCsdD3):
 def __init__(self):
  CCsdD3.__init__(self)
 def VV7F06(self):
  if CC2hCu.VViy1e(self):
   FFJsIX(self, BF(self.VVNxZn, 2), title="Searching ...")
 def VV7fmP(self, winSession, url, mac):
  self.curUrl = url
  if CC2hCu.VViy1e(self):
   if self.VVhVda(url, mac):
    FFJsIX(winSession, self.VVXJmo, title="Checking Server ...")
   else:
    FFw5OO(self, "Incorrect URL or MAC format !", title="Starting Portal Browser")
 def VV0F6Q(self, item=None):
  if item:
   VV4EHV, txt, path, ndx = item
   enc = CCqdtK.VVAtdG(path, self)
   if enc == -1:
    return
   self.session.open(CCmNws, barTheme=CCmNws.VVkie3
       , titlePrefix = "Processing file lines"
       , fncToRun  = BF(self.VVgZII, path, enc)
       , VVCeou = BF(self.VV2dDC, VV4EHV, path))
 def VVgZII(self, path, enc, VVXLiB):
  urlMacPatt  = r"(.*)(https?:\/\/.+(?::[0-9]+)*)(?:.+)((?:[A-Fa-f0-9]{2}\s*:\s*){5}[A-Fa-f0-9]{2})(.*)"
  urlOnlyPatt = r"\s*(https?:\/\/.+(?::[0-9]+)*)"
  macOnlyPatt = r"((?:(?:.*mac\s*)[^A-Fa-f0-9]\s*)*)((?:(?:(?:[A-Fa-f0-9]{2})\s*:\s*){5})\s*(?:[A-Fa-f0-9]{2}))(.*)"
  tableRows = []
  url   = ""
  c   = 0
  totLines = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    totLines += 1
  VVXLiB.VVCnyB(totLines)
  VVXLiB.VVlaij = []
  lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    if not VVXLiB or VVXLiB.isCancelled:
     return
    VVXLiB.VV1Vtn(1, True)
    line = str(line).strip()
    if not line or len(line) > 500 or "password" in line:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(urlMacPatt, line, IGNORECASE)
    if span:
     c  += 1
     subj = span.group(1).strip() or "-"
     url  = span.group(2).strip().split(" ")[0].split("\t")[0].strip()
     mac  = span.group(3).strip().replace(" ", "").upper()
     info = span.group(4).strip().strip(";") or "-"
     host = self.VVV1cj(url)
     mac  = self.VVtJ1J(mac)
     if host and mac and VVXLiB:
      VVXLiB.VVlaij.append((str(c), str(lineNum), subj, host, mac, info))
     url  = ""
     continue
    if not url:
     span = iSearch(urlMacPatt, line, IGNORECASE)
     if not span:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
    else:
     span = iSearch(macOnlyPatt, line.replace("\t", " "), IGNORECASE)
     if span:
      c  += 1
      subj = span.group(1).strip() or "-"
      mac  = span.group(2).strip().replace(" ", "").upper()
      info = span.group(3).strip().strip(";") or "-"
      host = self.VVV1cj(url)
      mac  = self.VVtJ1J(mac)
      if host and mac and not mac.startswith("AC") and VVXLiB:
       VVXLiB.VVlaij.append((str(c), str(lineNum), "-", host, mac, info))
     else:
      span = iSearch(urlOnlyPatt, line, IGNORECASE)
      if span:
       url = span.group(1).split(" ")[0]
 def VV2dDC(self, VV4EHV, path, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  title = "Portals File : %s" % os.path.basename(path)
  if VVlaij:
   VVZ224  = ("Home Menu"  , FFJgMq            , [])
   VVIrDY = ("Edit File"  , BF(self.VVDeGX, path)       , [])
   VVX66G = ("M3U Options" , self.VVBj11         , [])
   VVFadD = ("Check & Filter" , BF(self.VVW1xU, VV4EHV, path), [])
   VVwmV1  = ("Select"   , self.VVrZFb      , [])
   header   = ("Num" , "LineNum" , "Title" , "Host", "MAC-Address" , "Comments")
   widths   = (7  , 0   , 12  , 36 , 20   , 25  )
   VVFvCJ  = (CENTER , CENTER , LEFT  , LEFT , CENTER  , LEFT  )
   VVxBfP = FF1Dpj(self, None, title=title, header=header, VVarfR=VVlaij, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, VVDlGi="#0a001122", VVaSSM="#0a001122", VVzgHY="#0a001122", VVkUYa="#00004455", VVivoO="#0a333333", VVdjpa="#11331100", VVUdUN=True, searchCol=3, lastFindConfigObj=CFG.lastFindServers)
   if not VVeObj:
    FF5uKN(VVxBfP, "Stopped at line %s" % threadCounter, 1000)
  else:
   if VVeObj:
    FFw5OO(self, "No valid portal data (or incorrect file format) in:\n\n%s" % path, title=title)
 def VVBj11(self, VVxBfP, title, txt, colList):
  host = colList[3]
  mac  = colList[4]
  title = "Portal M3U Options"
  VVZJ87 = []
  VVZJ87.append(("Browse as M3U"  , "browse"))
  VVZJ87.append(("Download M3U File" , "downld"))
  FFYySC(self, BF(self.VVO6o0, VVxBfP, host, mac), title=title, VVZJ87=VVZJ87, width=600, VV18hv=True)
 def VVO6o0(self, VVxBfP, host, mac, item):
  if item:
   title, item, ndx = item
   if   item == "browse": FFJsIX(VVxBfP, BF(self.VVmuGe, VVxBfP, title, host, mac, item), title="Checking Server ...")
   elif item == "downld": FFNKVM(self, BF(FFJsIX, VVxBfP, BF(self.VVmuGe, VVxBfP, title, host, mac, item), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVmuGe(self, VVxBfP, title, host, mac, item):
  p = CCsdD3()
  m3u_Url = ""
  ok = p.VVhVda(host, mac, VV70Sp=False)
  err = ""
  if ok:
   m3u_Url, host, user1, pass1, err = p.VV6EQ6(VV70Sp=False)
  if m3u_Url:
   if   item == "browse": self.VVcKAy(title, m3u_Url)
   elif item == "downld": self.VVn2bV(title, "%s/get.php?username=%s&password=%s&type=m3u" % (host, user1, pass1))
  else:
   FFw5OO(self, err or "No response from Server !", title=title)
 def VVrZFb(self, VVxBfP, title, txt, colList):
  url = colList[3]
  mac = colList[4]
  self.VV7fmP(VVxBfP, url, mac)
 def VVDeGX(self, path, VVxBfP, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCQ3ND(self, path, VVCeou=BF(self.VVXw3b, VVxBfP), curRowNum=rowNum)
  else    : FFZoTn(self, path)
 def VVW1xU(self, VV4EHV, path, VVxBfP, title, txt, colList):
  self.session.open(CCmNws, barTheme=CCmNws.VV3z22
      , titlePrefix = "Checking Portals"
      , fncToRun  = BF(self.VV6VGw, VVxBfP)
      , VVCeou = BF(self.VVwljG, VV4EHV, VVxBfP, path))
 def VV6VGw(self, VVxBfP, VVXLiB):
  VVXLiB.VVlaij = []
  VVXLiB.VVCnyB(VVxBfP.VVWnGz())
  for row in VVxBfP.VVlHja():
   if not VVXLiB or VVXLiB.isCancelled:
    return
   VVXLiB.VV1Vtn(1, showFound=True)
   num, lNum, titl, host, mac, cmnt = row
   if self.VVhVda(host, mac, VV70Sp=False):
    token, profile, tErr = self.VVHGWF(VV70Sp=False)
    if token and VVXLiB and not VVXLiB.isCancelled:
     res, err = self.VVxaAJ(self.VVfDrn("itv"))
     if res and VVXLiB and not VVXLiB.isCancelled:
      try:
       tot = len(jLoads(res.text)["js"])
       VVXLiB.VV1Vtn(0, showFound=True)
       VVXLiB.VVlaij.append((titl, host, mac, cmnt))
      except:
       pass
   if not VVXLiB:
    return
 def VVwljG(self, VV4EHV, VVxBfP, path, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  if VVlaij:
   VVxBfP.close()
   VV4EHV.close()
   newPath = "%s_OK_%s.txt" % (path, FFUD38())
   with open(newPath, "w") as f:
    for titl, host, mac, cmnt in VVlaij:
     f.write("%s\t%s\t%s\t%s\n" % (titl, host, mac, cmnt))
   if threadTotal == threadCounter:
    totChk = str(threadCounter)
    skipped = ""
   else:
    totChk = FFGB9z(str(threadCounter), VVsObI)
    skipped = FFGB9z(str(threadTotal - threadCounter), VVsObI)
   txt  = "Total Portals\t: %d\n" %  threadTotal
   txt += "Checked\t: %s\n"  %  totChk
   if skipped:
    txt += "Cancelled\t: %s\n" %  skipped
   txt += "Accessible\t: %d\n\n" %  len(VVlaij)
   txt += "%s\n\n%s"    %  (FFGB9z("Result File:", VVUVAI), newPath)
   FF90Bc(self, txt, title="Accessible Portals")
  elif VVeObj:
   FFw5OO(self, "No portal access found !", title="Accessible Portals")
 def VVUmet(self, iptvRef):
  host = mac = ""
  isPortalUrl = False
  if "chCode" in iptvRef:
   isPortalUrl = True
   iptvRef = iptvRef.replace("%3a", ":").replace("%3A", ":")
   span = iSearch(r"[A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}(.+)", iptvRef, IGNORECASE)
   if span:
    url  = span.group(1)
    try:
     res  = iUrlparse(url)
     tDict = iUrlparse_qs(res.query)
     chCode = tDict.get("chCode", [""])[0].strip()
     mac  = FFH6Pe(chCode)
     if res.netloc:
      host = res.netloc
      if res.scheme:
       host = res.scheme + "://" + host
    except:
     pass
  return host, mac, isPortalUrl
 def VVXJmo(self):
  token, profile, tErr = self.VVHGWF()
  if token:
   dots = "." * self.VVUq9A
   dots += {"s":"", "p":"+", "q":"++", }.get(self.VV224Q(), "")
   dots += "*" if not self.VV4Xnp == self.curUrl else ""
   VVZJ87  = self.VVS5Zj()
   VVkUAu = self.VVvfmV
   VVXyZL = self.VVgtnM
   VV6LYc = ("Home Menu", FFJgMq)
   VV3ba7= ("Add to Menu", BF(CC9X9s.VViT6z, self, True, self.VV4Xnp + "\t" + self.VVktxB))
   VV2YYF = ("Bookmark Server", BF(CC9X9s.VVU5D0, self, True, self.VV4Xnp + "\t" + self.VVktxB))
   FFYySC(self, None, title="Portal Resources (MAC=%s) %s" % (self.VVktxB, dots), VVZJ87=VVZJ87, VVkUAu=VVkUAu, VVXyZL=VVXyZL, VV6LYc=VV6LYc, VV3ba7=VV3ba7, VV2YYF=VV2YYF)
 def VVvfmV(self, item=None):
  if item:
   VV4EHV, title, ref, ndx = item
   if   ref == "live"   : mode = "itv"
   elif ref == "vod"   : mode = "vod"
   elif ref == "series"  : mode = "series"
   elif ref == "accountInfo" : mode = ""
   if mode : FFJsIX(VV4EHV, BF(self.VVddlr, mode), title="Reading Categories ...")
   else : FFJsIX(VV4EHV, BF(self.VVsddb, VV4EHV, title), title="Reading Account ...")
 def VVsddb(self, VV4EHV, title, forceMoreInfo=False):
  rows, totCols = self.VVYXWK(forceMoreInfo)
  title = "%s (MAC=%s)" % (title, self.VVktxB)
  VVZ224  = ("Home Menu" , FFJgMq           , [])
  VVX66G  = None
  if VV8Ixy:
   VVX66G = ("Get JS"  , BF(self.VVZ9xI, self.VV95q4()) , [])
  if totCols == 2:
   VVFadD = None
   header   = ("Subject" , "Value" )
   widths   = (43   , 57  )
   searchCol  = 0
  else:
   VVFadD = ("More Info.", BF(self.VVO6dN, VV4EHV)    , [])
   header   = ("Num", "User/Server" , "Subject" , "Value" )
   widths   = (0 , 15   , 35  , 50  )
   searchCol  = 2
  FF1Dpj(self, None, title=title, width=1200, header=header, VVarfR=rows, VVhAo0=widths, VVTFXq=26, VVZ224=VVZ224, VVX66G=VVX66G, VVFadD=VVFadD, VVDlGi="#0a00292B", VVaSSM="#0a002126", VVzgHY="#0a002126", VVkUYa="#00000000", searchCol=searchCol)
 def VVZ9xI(self, url, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VVWRsB, url), title="Getting JS ...")
 def VVWRsB(self, url):
  txt  = "// Host\t: %s\t%s\n" % (url, self.VVktxB)
  ver, err = self.VVr1jo(url)
  txt += "// Version\t: %s\n\n" % (ver or err)
  js , err = self.VVr1jo(url, isJsFile=True)
  if err: txt += "Error : %s" % err
  else  : txt += js
  FF90Bc(self, txt, title="JS Info", outputFileToSave="Server_xpcom.common.js")
 def VVO6dN(self, VV4EHV, VVxBfP, title, txt, colList):
  VVxBfP.cancel()
  FFJsIX(VV4EHV, BF(self.VVsddb, VV4EHV, "Account Info.", forceMoreInfo=True), title="Reading Account ...")
 def VVddlr(self, mode):
  token, profile, tErr = self.VVHGWF()
  if not token:
   return
  res, err = self.VVxaAJ(self.VVfDrn(mode))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList = tDict["js"]
     for item in chList:
      Id   = CC9X9s.VVV2zK(item, "id"       )
      Title  = CC9X9s.VVV2zK(item, "title"      )
      censored = CC9X9s.VVV2zK(item, "censored"     )
      Title = self.VV3HOG(Title)
      if Title:
       isAll = Title.strip().lower() == "all"
       if not isAll or isAll and VVoWDM:
        list.append((Title.strip(), Id))
   except:
    pass
  title = self.VVzaKN(mode)
  if list:
   list.sort(key=lambda x: x[0].lower())
   VVDlGi, VVaSSM, VVzgHY, VVkUYa = self.VVU1Pf(mode)
   mName = self.VVzaKN(mode)
   VVwmV1   = ("Show List"   , BF(self.VVP5aM, mode)   , [])
   VVZ224  = ("Home Menu"   , FFJgMq        , [])
   if mode in ("vod", "series"):
    VVIrDY = ("Find in %s" % mName , BF(self.VVE5uD, mode, False), [])
    VVFadD = ("Find in Selected" , BF(self.VVE5uD, mode, True) , [])
   else:
    VVIrDY = None
    VVFadD = None
   header   = None
   widths   = (100   , 0  )
   FF1Dpj(self, None, title=title, width=1200, header=header, VVarfR=list, VVhAo0=widths, VVTFXq=30, VVZ224=VVZ224, VVIrDY=VVIrDY, VVFadD=VVFadD, VVwmV1=VVwmV1, VVDlGi=VVDlGi, VVaSSM=VVaSSM, VVzgHY=VVzgHY, VVkUYa=VVkUYa, lastFindConfigObj=CFG.lastFindIptv)
  else:
   s = "Authorization failed"
   if err:
    txt = err
   elif s in res.text:
    txt = s
    if self.VV414J:
     txt += "\n\n( %s )" % self.VV414J
   else:
    txt = "Could not get Categories from server!"
   FFw5OO(self, txt, title=title)
 def VVTHdc(self, mode, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VVrcp9, mode, VVxBfP, title, txt, colList), title="Downloading ...")
 def VVrcp9(self, mode, VVxBfP, title, txt, colList):
  token, profile, tErr = self.VVHGWF()
  if not token:
   return
  seriesName = colList[1]
  catID  = colList[2]
  res, err  = self.VVxaAJ(self.VVsbtE(catID))
  list = []
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     chList  = tDict["js"]['data']
     for item in chList:
      Id    = CC9X9s.VVV2zK(item, "id"    )
      actors   = CC9X9s.VVV2zK(item, "actors"   )
      added   = CC9X9s.VVV2zK(item, "added"   )
      age    = CC9X9s.VVV2zK(item, "age"   )
      category_id  = CC9X9s.VVV2zK(item, "category_id" )
      description  = CC9X9s.VVV2zK(item, "description" )
      director  = CC9X9s.VVV2zK(item, "director"  )
      genres_str  = CC9X9s.VVV2zK(item, "genres_str"  )
      name   = CC9X9s.VVV2zK(item, "name"   )
      path   = CC9X9s.VVV2zK(item, "path"   )
      screenshot_uri = CC9X9s.VVV2zK(item, "screenshot_uri" )
      series   = CC9X9s.VVV2zK(item, "series"   )
      cmd    = CC9X9s.VVV2zK(item, "cmd"   )
      cmd    = cmd.replace("ffmpeg ", "")
      for episode in eval(series):
       list.append((seriesName, name, str(episode), category_id, Id, added, age, cmd, director, genres_str, actors, description, screenshot_uri, path))
   except:
    pass
  if list:
   list.sort(key=lambda x: (x[1], int(x[2])))
   VVwmV1  = ("Play"    , BF(self.VVQ4tR, mode)       , [])
   VVs5AA = (""     , BF(self.VV0Fwe, mode)     , [])
   VVZ224 = ("Home Menu"   , FFJgMq            , [])
   VVX66G = ("Download Options" , BF(self.VVjmFH, mode, "sp", seriesName) , [])
   VVIrDY = ("Options"   , BF(self.VVOXnV, "pEp", mode, seriesName) , [])
   VVFadD = ("Posters Mode"  , BF(self.VVjfVG, mode, True)      , [])
   header   = ("Name" , "Season" , "Episode" , "catID" , "ID" , "Added" , "Age" , "cmd" , "Director", "Genre" , "Actors" , "Description" , "Screenshot" , "Path")
   widths   = (65  , 20  , 15  , 0   , 0   , 0.01 , 0.01 , 0  , 0.01  , 0.01  , 0   , 0    , 0    , 0  )
   VVFvCJ  = (LEFT  , LEFT  , CENTER , LEFT  , LEFT  , LEFT , LEFT , LEFT , LEFT  , LEFT  , LEFT  , LEFT   , LEFT   , LEFT )
   FF1Dpj(self, None, title=seriesName, width=1200, header=header, VVarfR=list, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindIptv, VVDlGi="#0a00292B", VVaSSM="#0a002126", VVzgHY="#0a002126", VVkUYa="#00000000")
  else:
   FFw5OO(self, "Could not get Episodes from server!", title=seriesName)
 def VVE5uD(self, mode, searchInCat, VVxBfP, title, txt, colList):
  searchCatId = colList[1].strip() if searchInCat else ""
  VVZJ87 = []
  VVZJ87.append(("Keyboard"  , "manualEntry"))
  VVZJ87.append(("From Filter" , "fromFilter"))
  FFYySC(self, BF(self.VVufBX, VVxBfP, mode, searchCatId), title="Input Type", VVZJ87=VVZJ87, width=400)
 def VVufBX(self, VVxBfP, mode, searchCatId, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFaSvq(self, BF(self.VVkY0I, VVxBfP, mode, searchCatId), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCdUgX(self)
    filterObj.VV4D6G(BF(self.VVkY0I, VVxBfP, mode, searchCatId))
 def VVkY0I(self, VVxBfP, mode, searchCatId, item):
  if not item is None:
   searchName = item.strip()
   FFdEZ4(CFG.lastFindIptv, searchName)
   title = self.VVfC9z(mode, searchName)
   if "," in searchName : FFw5OO(self, "Use only one word to search in Portal Servers !\n\nRemove the comma.", title=title)
   elif len(searchName) < 3: FFw5OO(self, "Enter at least 3 characters.", title=title)
   else     :
    if CFG.hideIptvServerAdultWords.getValue() and self.VVEvvi([searchName]):
     FFw5OO(self, self.VVVfjQ(), title=title)
    else:
     self.VVbrzV(mode, searchName, "", searchName, searchCatId)
 def VVP5aM(self, mode, VVxBfP, title, txt, colList):
  bName = colList[0].strip()
  catID = colList[1].strip()
  self.VVbrzV(mode, bName, catID, "", "")
 def VVbrzV(self, mode, bName, catID, searchName, searchCatId):
  self.session.open(CCmNws, barTheme=CCmNws.VVkie3
      , titlePrefix = "Reading from server"
      , fncToRun  = BF(self.VV78So, mode, bName, catID, searchName, searchCatId)
      , VVCeou = BF(self.VVe82l, mode, bName, catID, searchName, searchCatId))
 def VVe82l(self, mode, bName, catID, searchName, searchCatId, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  if searchName : title = self.VVfC9z(mode, searchName)
  else   : title = "%s : %s" % (self.VVzaKN(mode), bName)
  if VVlaij:
   VVX66G = None
   VVIrDY = None
   if mode == "series":
    VVDlGi, VVaSSM, VVzgHY, VVkUYa = self.VVU1Pf("series2")
    VVwmV1  = ("Episodes"   , BF(self.VVTHdc, mode)           , [])
   else:
    VVDlGi, VVaSSM, VVzgHY, VVkUYa = self.VVU1Pf("")
    VVwmV1  = ("Play"    , BF(self.VVQ4tR, mode)           , [])
    VVX66G = ("Download Options" , BF(self.VVjmFH, mode, "vp" if mode == "vod" else "", "") , [])
    VVIrDY = ("Options"   , BF(self.VVOXnV, "pCh", mode, bName)      , [])
   VVs5AA = (""      , BF(self.VVWTnN, mode)         , [])
   VVZ224 = ("Home Menu"    , FFJgMq                , [])
   VVFadD = ("Posters Mode"   , BF(self.VVjfVG, mode, False)         , [])
   header   = ("Num" , "Name", "catID", "genreID" , "Icon", "cmd" , "Cat./Genre" , "Logo", "play", "actors" , "descr" , "director")
   widths   = (9  , 60  , 0   , 0     , 0  , 0  , 25   , 6  , 0  , 0   , 0   , 0   )
   VVFvCJ  = (CENTER, LEFT  , CENTER , CENTER  , LEFT , LEFT , LEFT   , CENTER, LEFT , LEFT  , LEFT  , LEFT  )
   VVxBfP = FF1Dpj(self, None, title=title, header=header, VVarfR=VVlaij, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindIptv, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVDlGi=VVDlGi, VVaSSM=VVaSSM, VVzgHY=VVzgHY, VVkUYa=VVkUYa, VVUdUN=True, searchCol=1)
   if not VVeObj:
    if not threadCounter == threadTotal:
     tot = " (Stopped at %d of %d) " % (threadCounter, threadTotal)
     VVxBfP.VVanwx(VVxBfP.VVLGq4() + tot)
    if threadErr: FF5uKN(VVxBfP, "Error while reading !", 2000)
    else  : FF5uKN(VVxBfP, "Stopped at channel %s" % threadCounter, 1000)
  else:
   if searchName : FFw5OO(self, "Could not find names with:\n\n%s" % searchName, title=title)
   else   : FFw5OO(self, "Could not get list from server !", title=title)
 def VVWTnN(self, mode, VVxBfP, title, txt, colList):
  ttl = lambda x, y: "%s\n%s\n\n" % (FFGB9z(x, VVUVAI), str(y)) if y.strip() and not "N/A" in y else ""
  tab = lambda x, y: "%s\t: %s\n" % (x, y) if y.strip() and not "N/A" in y else ""
  Num, Name, catID, genreID, Icon, cmd, Cat_Genre, Logo, play, actors, descr, director = colList
  txt  = tab("Number"  , Num)
  txt += tab("Name"  , Name)
  txt += tab("Cat./Genre" , Cat_Genre)
  txt += tab("Director" , director)
  txt += "\n"
  txt += ttl("Actors"  , actors)
  txt += ttl("Description", descr)
  play = play.strip()
  if play and not play.startswith("[No "):
   txt += ttl("Cur. Playing", play)
  if mode == "series":
   chName = colList[1]
   picUrl = colList[4]
   txt  = "%s\n\n%s" % (title, txt)
   FFcpNw(self, fncMode=CCjQ0P.VVtg1b, portalHost=self.VV4Xnp, portalMac=self.VVktxB, chName=chName, text=txt, picUrl=picUrl)
  else:
   self.VVVJwU(mode, VVxBfP, title, txt, colList)
 def VV0Fwe(self, mode, VVxBfP, title, txt, colList):
  txt += "\n"
  txt += "Actors:\n%s\n\n" % FFGB9z(colList[10], VVGb6D)
  txt += "Description:\n%s" % FFGB9z(colList[11], VVGb6D)
  self.VVVJwU(mode, VVxBfP, title, txt, colList)
 def VVVJwU(self, mode, VVxBfP, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVPMtD(mode, colList)
  refCode, chUrl = self.VVJNpF(self.VV4Xnp, self.VVktxB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  txt = "%s\n\n%s" % (title, txt)
  FFcpNw(self, fncMode=CCjQ0P.VVQdzu, callingSELF=self, portalMode=mode, refCode=refCode, chName=chName, text=txt, picUrl=picUrl, chCm=chCm, serCode=serCode, serId=serId, portalEpgUrl=chUrl)
 def VV78So(self, mode, bName, catID, searchName, searchCatId, VVXLiB):
  try:
   token, profile, tErr = self.VVHGWF()
   if not token:
    return
   if VVXLiB.isCancelled:
    return
   VVXLiB.VVlaij, total_items, max_page_items, err = self.VVDiSW(mode, catID, 1, 1, searchName, searchCatId)
   if VVXLiB.isCancelled:
    return
   if VVXLiB.VVlaij and total_items > -1 and max_page_items > -1:
    VVXLiB.VVCnyB(total_items)
    VVXLiB.VV1Vtn(max_page_items, True)
    pages = int(iCeil(float(total_items) / float(max_page_items)))
    total_items = pages
    for i in range(pages - 1):
     if VVXLiB.isCancelled:
      return
     page = i + 2
     counter = (i + 1) * max_page_items + 1
     list, total_items, max_page_items, err = self.VVDiSW(mode, catID, page, counter, searchName, searchCatId)
     if err:
      VVXLiB.VV4dPB()
     if VVXLiB.isCancelled:
      return
     if list:
      VVXLiB.VVlaij += list
      VVXLiB.VV1Vtn(len(list), True)
  except:
   pass
 def VVDiSW(self, mode, catID, page, counter, searchName, searchCatId):
  list  = []
  total_items = max_page_items = -1
  if searchName : url = self.VVoP7A(mode, searchName, searchCatId, page)
  else   : url = self.VVpV08(mode, catID, page)
  res, err = self.VVxaAJ(url)
  if not err:
   try:
    tDict = jLoads(res.text)
    if tDict:
     item = tDict["js"]
     total_items  = self.VV3geB(CC9X9s.VVV2zK(item, "total_items" ))
     max_page_items = self.VV3geB(CC9X9s.VVV2zK(item, "max_page_items" ))
     chList = tDict["js"]['data']
     cmdStr = "http://localhost/ch/"
     for item in chList:
      Id    = CC9X9s.VVV2zK(item, "id"    )
      name   = CC9X9s.VVV2zK(item, "name"   )
      o_name   = CC9X9s.VVV2zK(item, "o_name"   )
      tv_genre_id  = CC9X9s.VVV2zK(item, "tv_genre_id" )
      number   = CC9X9s.VVV2zK(item, "number"   ) or str(counter)
      logo   = CC9X9s.VVV2zK(item, "logo"   )
      screenshot_uri = CC9X9s.VVV2zK(item, "screenshot_uri" )
      pic    = CC9X9s.VVV2zK(item, "pic"   )
      cmd    = CC9X9s.VVV2zK(item, "cmd"   )
      censored  = CC9X9s.VVV2zK(item, "censored"  )
      genres_str  = CC9X9s.VVV2zK(item, "genres_str"  )
      curPlay   = CC9X9s.VVV2zK(item, "cur_playing" )
      actors   = CC9X9s.VVV2zK(item, "actors"   )
      descr   = CC9X9s.VVV2zK(item, "description" )
      director  = CC9X9s.VVV2zK(item, "director"  )
      if name == "video_name_format" and o_name:
       name = o_name
      if " " in cmd and cmdStr in cmd:
       cmd = cmd.split(" ")[1]
      if mode == "itv" and not cmdStr in cmd and not cmd.endswith(".m3u8") and not "ffrt" in cmd:
       if "token=" in cmd and "d=Mag" in cmd:
        cmd = "Zz1" + FFjhdq(cmd)
       else:
        span = iSearch(r"stream=(.+)&", cmd)
        if span:
         cmd = "%s%s_" % (cmdStr, span.group(1))
        else:
         span = iSearch(r".+\/.+\/.+\/(.+)", cmd)
         if span:
          cmd = "%s%s_" % (cmdStr, span.group(1))
      if   logo.startswith("http")   : picon = logo
      elif pic.startswith("http")    : picon = pic
      elif screenshot_uri.startswith("http") : picon = screenshot_uri
      else         : picon = logo or screenshot_uri or pic
      sp = "/stalker_portal"
      if picon.startswith(sp):
       picon = (self.VV4Xnp + picon).replace(sp * 2, sp)
      isIcon = "Yes" if picon.startswith("http") else ""
      counter += 1
      name = self.VVbGFt(name, censored)
      if name:
       list.append((number, name, Id, tv_genre_id, picon, cmd, genres_str, isIcon, curPlay, actors, descr, director))
   except:
    err = "Channel Parse Error !"
  return list, total_items, max_page_items, err
 def VV3geB(self, valStr):
  try:
   return int(valStr)
  except:
   return -1
 def VVQ4tR(self, mode, VVxBfP, title, txt, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVPMtD(mode, colList)
  refCode, chUrl = self.VVJNpF(self.VV4Xnp, self.VVktxB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  if self.VVNowk(chName):
   FF5uKN(VVxBfP, "This is a marker!", 300)
  else:
   FFJsIX(VVxBfP, BF(self.VVV0ni, mode, VVxBfP, chUrl), title="Playing ...")
 def VVV0ni(self, mode, VVxBfP, chUrl):
  FFkwBg(self, chUrl, VVIC8r=False)
  CCb9j4.VV6JFp(self.session, iptvTableParams=(self, VVxBfP, mode))
 def VV0Eue(self, mode, VVxBfP, colList):
  chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVPMtD(mode, colList)
  refCode, chUrl = self.VVJNpF(self.VV4Xnp, self.VVktxB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  return chName, chUrl
 def VVPMtD(self, mode, colList):
  if mode == "series":
   chName = colList[0]
   season = colList[1]
   serCode = colList[2]
   catID = colList[3]
   serId = colList[4]
   chCm = colList[7]
   picUrl = colList[12]
   chName = "%s (%s - %s)" % (chName, season, serCode)
   chNum = serCode
   stID = serId.replace(":", "")
  else:
   chNum = colList[0]
   chName = colList[1]
   catID = colList[2]
   picUrl = colList[4]
   chCm = colList[5]
   stID = catID
   serCode = ""
   serId = ""
  return chName.strip(), catID.strip(), stID.strip(), chNum.strip(), chCm.strip(), serCode.strip(), serId.strip(), picUrl.strip()
 @staticmethod
 def VViy1e(SELF, install=True, cbFnc=None):
  try:
   import requests
   return True
  except:
   if install:
    title = 'Install "Requests"'
    VVZJ87 = []
    VVZJ87.append((title        , "inst" ))
    VVZJ87.append(("Update Packages then %s" % title , "updInst" ))
    FFYySC(SELF, BF(CC2hCu.VVYL71, SELF, cbFnc=cbFnc), title='This requires Python "Requests" library', VVZJ87=VVZJ87)
   return False
 @staticmethod
 def VVYL71(SELF, item=None, cbFnc=None):
  if item:
   cmdUpd = FF8jae(VVxYBL, "")
   if cmdUpd:
    cmdInst = FFETOG(VV33Lu, "python-requests")
    if pyVersion[0] >= 3:
     cmdInst = cmdInst.replace("python-", "python3-")
    if   item == "inst"  : cmd = cmdInst
    elif item == "updInst" : cmd = cmdUpd + " && " + cmdInst
    FF1Q61(SELF, cmd, checkNetAccess=True, title='Installing "Requests" Library', VVYxQ2=cbFnc)
   else:
    FFgq4o(SELF)
class CC9X9s(Screen, CC2hCu, CC6gLq, CCAmUK):
 VVq3Pd    = 0
 VVPq0V    = 1
 VVkE0m    = 2
 VVaXHN    = 3
 VVXpp9     = 4
 VVyd5U     = 5
 VVswEo     = 6
 VV4iF5     = 7
 VV0Thk     = 8
 VVsM7x     = 9
 VVsQ1z      = 10
 VVygdN     = 11
 VVIp7D     = 12
 VV4zzI     = 13
 VVFh3Q     = 14
 VVs4rv      = 15
 VVLH3J      = 16
 VVbbdE      = 17
 VVedlT      = 18
 VVhJnM      = 19
 VVe1w4    = 0
 VVymqZ   = 1
 VVJ6qH   = 2
 VVKYG7   = 3
 VVCUx4  = 4
 VVFVA3  = 5
 VVTObo   = 6
 VVPA9X   = 7
 VVhOAc  = 8
 VVW6Tp  = 9
 VV6X6H  = 10
 VVrdZ4 = 0
 VVfIZF = 1
 def __init__(self, session, m3uOrM3u8File=None):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 1050, 1050, 50, 40, 30, "#0a001a20", "#0a001a20", 28, topRightBtns=1)
  self.session     = session
  self.m3uOrM3u8File    = m3uOrM3u8File
  self.m3uOrM3u8BName    = ""
  self.VVxBfP    = None
  self.tableTitle     = "IPTV Channels List"
  self.VVMcR7Data    = {}
  self.localIptvFilterInFilter = False
  self.iptvFileAvailable   = CC9X9s.VV3Es2(atLeastOne=True)
  self.isFirstTime    = True
  self.curUrl      = ""
  CC2hCu.__init__(self)
  CC6gLq.__init__(self)
  VVZJ87 = self.VVqfnJ()
  FFmmH7(self, title="IPTV", VVZJ87=VVZJ87)
  self["myActionMap"].actions.update({
   "menu" : self.VVJMjN
  })
  self["myMenu"].onSelectionChanged.append(self.VVWXLZ)
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
  global VVbfpk
  VVbfpk = True
 def VV0wap(self):
  self["myMenu"].setList(self.VVqfnJ())
  FFR3zK(self)
  FFj9eW(self)
  if self.isFirstTime:
   self.isFirstTime = False
   FFplRG(self["myMenu"])
   FFF9tS(self)
   if self.m3uOrM3u8File:
    self.VV9sGF(self.m3uOrM3u8File)
 def onExit(self):
  global VVbfpk
  del VVbfpk
 def VVWXLZ(self):
  if self["myMenu"].getCurrent()[1] in ("VV0eBT", "VViJ8BPortal") : self["keyMenu"].show()
  else                      : self["keyMenu"].hide()
 def VVJMjN(self):
  if self["myMenu"].getVisible():
   title = self["myMenu"].getCurrent()[0]
   item  = self["myMenu"].getCurrent()[1]
   if   item == "VViJ8BPortal" : confItem = CFG.favServerPortal
   elif item == "VV0eBT" : confItem = CFG.favServerPlaylist
   else         : return
   FFNKVM(self, BF(self.VVtVV4, confItem), 'Remove from menu ?', title=title)
 def VVtVV4(self, confItem):
  FFdEZ4(confItem, "")
  self.VV0wap()
 def VVqfnJ(self):
  isFav1, isFav2 = CFG.favServerPlaylist.getValue(), CFG.favServerPortal.getValue()
  c = VVMrXw
  VVZJ87 = []
  if isFav1: VVZJ87.append((c +  "Favourite Playlist Server"   , "VV0eBT" ))
  if isFav2: VVZJ87.append((c +  "Favourite Portal Server"    , "VViJ8BPortal" ))
  VVZJ87.append(("IPTV Server Browser (from Playlists)"     , "VVMcR7_fromPlayList" ))
  VVZJ87.append(("IPTV Server Browser (from Portal List)"    , "VVMcR7_fromMac"  ))
  VVZJ87.append(("IPTV Server Browser (from M3U/M3U8 Subscription File)", "VVMcR7_fromM3u"  ))
  qUrl, iptvRef = CC9X9s.VVxFip(self)
  fromCurCond = qUrl or "chCode" in iptvRef
  VVZJ87.append(FFnqNr("IPTV Server Browser (from Current Channel)", "VVMcR7_fromCurrChan", fromCurCond))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("M3U/M3U8 File Browser"        , "VVGvoX"   ))
  if self.iptvFileAvailable:
   VVZJ87.append(("Local IPTV Services"        , "iptvTable_all"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(FFnqNr("Update Current Bouquet EPG (from IPTV Server)" , "refreshIptvEPG"  , fromCurCond))
  VVZJ87.append(FFnqNr("Update Current Bouquet PIcons (from IPTV Server)" , "refreshIptvPicons", fromCurCond))
  if self.iptvFileAvailable:
   VVZJ87.append(VVoqHH)
   c1, c2 = VVWOjU, VVUVAI
   t1 = FFGB9z("auto-match names", VVMrXw)
   t2 = FFGB9z("from xml file"  , VVMrXw)
   VVZJ87.append((c1 + "Count Available IPTV Channels"    , "VVdexc"    ))
   VVZJ87.append((c1 + "Copy EPG/PIcons between Channels (%s)" % t2 , "copyEpgPicons"   ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append((c2 + "Share Reference with DVB Channels (%s)" % t2 , "renumIptvRef_fromFile" ))
   VVZJ87.append((c2 + "Share Reference with DVB Channels (%s)" % t1 , "VVUbKS" ))
   VVZJ87.append((VVLbyB + "More Reference Tools ..."  , "VVD3Ms"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Reload Channels and Bouquets"       , "VVnFbH"   ))
  VVZJ87.append(VVoqHH)
  if not CCrhIe.VVyUPR():
   VVZJ87.append(("Download Manager"         , "dload_stat"    ))
  else:
   VVZJ87.append(("Download Manager ... No downloads"    ,       ))
  return VVZJ87
 def VVzO14(self, item):
  self.curUrl = ""
  tTitle = "Share Reference with DVB Service"
  if item is not None:
   title = "Searching ..."
   if   item == "VVJKT1"   : self.VVJKT1()
   elif item == "VV00qe" : FFNKVM(self, self.VV00qe, "Change Current List References to Unique Codes ?")
   elif item == "VVXUqD_rows" : FFNKVM(self, BF(FFJsIX, self.VVxBfP, self.VVXUqD), "Change Current List References to Identical Codes ?")
   elif item == "VVN5El"   : self.VVN5El(tTitle)
   elif item == "VVKfcx"   : self.VVKfcx(tTitle)
   elif item == "VV0eBT" : self.VViJ8B(False)
   elif item == "VViJ8BPortal" : self.VViJ8B(True)
   elif item == "VVMcR7_fromPlayList" : FFJsIX(self, BF(self.VVNxZn, 1), title=title)
   elif item == "VVMcR7_fromM3u"  : FFJsIX(self, BF(self.VV3ZT5, CC9X9s.VVrdZ4), title=title)
   elif item == "VVMcR7_fromMac"  : self.VV7F06()
   elif item == "VVMcR7_fromCurrChan" : self.VV0AUe()
   elif item == "VVGvoX"   : self.VVGvoX()
   elif item == "iptvTable_all"   : FFJsIX(self, BF(self.VVSEUH, self.VVq3Pd), title="Loading Channels ...")
   elif item == "refreshIptvEPG"   : CC9X9s.VVCBtN(self)
   elif item == "refreshIptvPicons"  : self.VVUCe8()
   elif item == "VVdexc"    : FFJsIX(self, self.VVdexc)
   elif item == "copyEpgPicons"   : self.VV1ZF3(False)
   elif item == "renumIptvRef_fromFile" : self.VV1ZF3(True)
   elif item == "VVUbKS" : FFNKVM(self, BF(FFJsIX, self, self.VVUbKS), VVILc0="Continue ?")
   elif item == "VVD3Ms"    : self.VVD3Ms()
   elif item == "VVnFbH"   : FFJsIX(self, BF(CCdAiy.VVnFbH, self))
   elif item == "dload_stat"    : CCrhIe.VVFNli(self)
 def VVGvoX(self):
  if CC2hCu.VViy1e(self):
   FFJsIX(self, BF(self.VV3ZT5, CC9X9s.VVfIZF), title="Searching ...")
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  self.VVzO14(item)
 def VVSEUH(self, mode):
  VVX3wb = self.VVIbVP(mode)
  if VVX3wb:
   VVX66G = ("Current Service", self.VV1Zbj , [])
   VVIrDY = ("Options"  , self.VVf67F   , [])
   VVFadD = ("Filter"   , self.VVQiLL   , [])
   VVwmV1  = ("Play"   , BF(self.VVNCPR)  , [])
   VVs5AA = (""    , self.VV4SVi    , [])
   VVotuX = (""    , self.VVtHp1     , [])
   header   = ("Num" , "Name", "Bouquet" , "Type", "Ref.", "URL" )
   widths   = (9  , 22 , 18  , 6  , 22 , 23 )
   VVFvCJ  = (CENTER , LEFT , LEFT  , CENTER, LEFT , LEFT )
   FF1Dpj(self, None, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26
     , VVwmV1=VVwmV1, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, VVs5AA=VVs5AA, VVotuX=VVotuX
     , VVDlGi="#0a00292B", VVaSSM="#0a002126", VVzgHY="#0a002126", VVkUYa="#00000000", VVUdUN=True, searchCol=1)
  else:
   if mode == self.VVsM7x: err = "No Live IPTV channels !"
   else       : err = "No IPTV channels !"
   FFw5OO(self, err)
 def VVtHp1(self, VVxBfP, title, txt, colList):
  self.VVxBfP = VVxBfP
 def VVf67F(self, VVxBfP, title, txt, colList):
  VVZJ87 = []
  VVZJ87.append(("Add Current List to a New Bouquet"    , "VVJKT1"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Change Current List References to Unique Codes" , "VV00qe"))
  VVZJ87.append(("Change Current List References to Identical Codes", "VVXUqD_rows" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Share Reference with DVB Service (manual entry)" , "VVN5El"   ))
  VVZJ87.append(("Share Reference with DVB Service (auto-find)"  , "VVKfcx"   ))
  FFYySC(self, self.VVzO14, title="IPTV Tools", VVZJ87=VVZJ87)
 def VVQiLL(self, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VVESSv, VVxBfP))
 def VVESSv(self, VVxBfP):
  VVZJ87 = []
  VVZJ87.append(("All"         , "all"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Prefix of Selected Channel"   , "sameName" ))
  VVZJ87.append(("Suggest Words from Selected Channel" , "partName" ))
  VVZJ87.append(("Names with Non-English Characters" , "nonEnglish" ))
  VVZJ87.append(("Duplicate References"     , "depRef"  ))
  VVZJ87.append(("Reference x:x:x:x:0:0:0:0:0:0:"  , "ref00"  ))
  VVZJ87.append(("Stream Relay"       , "SRelay"  ))
  VVZJ87.append(FFHf46("Category"))
  VVZJ87.append(("Live TV"        , "live"  ))
  VVZJ87.append(("VOD"         , "vod"   ))
  VVZJ87.append(("Series"        , "series"  ))
  VVZJ87.append(("Uncategorised"      , "uncat"  ))
  VVZJ87.append(FFHf46("Media"))
  VVZJ87.append(("Video"        , "video"  ))
  VVZJ87.append(("Audio"        , "audio"  ))
  VVZJ87.append(FFHf46("File Type"))
  VVZJ87.append(("MKV"         , "MKV"   ))
  VVZJ87.append(("MP4"         , "MP4"   ))
  VVZJ87.append(("MP3"         , "MP3"   ))
  VVZJ87.append(("AVI"         , "AVI"   ))
  VVZJ87.append(("FLV"         , "FLV"   ))
  VVZJ87.extend(CCSrvY.VVSrxf(prefix="__b__", onlyIptv=True))
  inFilterFnc = BF(self.VV0c2b, VVxBfP) if VVxBfP.VVLGq4().startswith("IPTV Filter ") else None
  filterObj = CCdUgX(self)
  filterObj.VV0Gkf(VVZJ87, VVZJ87, BF(self.VVyRz5, VVxBfP, False), inFilterFnc=inFilterFnc)
 def VV0c2b(self, VVxBfP, VV4EHV, item):
  self.VVyRz5(VVxBfP, True, item)
 def VVyRz5(self, VVxBfP, inFilter, item=None):
  self.localIptvFilterInFilter = inFilter
  prefix = VVxBfP.VVYzwE(1).split(" ")[0]
  if item is not None:
   f = "IPTV Filter "
   if   item == "all"    : mode, words, title = self.VVq3Pd , ""  , self.tableTitle
   elif item == "sameName"   : mode, words, title = self.VVPq0V , prefix , f + "= %s ..." % prefix
   elif item == "partName"   : mode, words, title = self.VVkE0m , ""  , ""
   elif item == "nonEnglish"  : mode, words, title = self.VVaXHN , ""  , f + "= Names with Non-English Characters"
   elif item == "depRef"   : mode, words, title = self.VVswEo  , ""  , f + "= Duplicate References"
   elif item == "ref00"   : mode, words, title = self.VV4iF5  , ""  , f + "= Reference x:x:x:x:0:0:0:0:0:0:"
   elif item == "SRelay"   : mode, words, title = self.VV0Thk  , ""  , f + "= Stream Relay"
   elif item == "live"    : mode, words, title = self.VVsM7x  , ""  , f + "= Live"
   elif item == "vod"    : mode, words, title = self.VVsQ1z   , ""  , f + "= VOD"
   elif item == "series"   : mode, words, title = self.VVygdN  , ""  , f + "= Series"
   elif item == "uncat"   : mode, words, title = self.VVIp7D  , ""  , f + "= Uncategorised"
   elif item == "video"   : mode, words, title = self.VV4zzI  , ""  , f + "= Video"
   elif item == "audio"   : mode, words, title = self.VVFh3Q  , ""  , f + "= Audio"
   elif item == "MKV"    : mode, words, title = self.VVs4rv   , ""  , f + "= MKV"
   elif item == "MP4"    : mode, words, title = self.VVLH3J   , ""  , f + "= MP4"
   elif item == "MP3"    : mode, words, title = self.VVbbdE   , ""  , f + "= MP3"
   elif item == "AVI"    : mode, words, title = self.VVedlT   , ""  , f + "= AVI"
   elif item == "FLV"    : mode, words, title = self.VVhJnM   , ""  , f + "= FLV"
   elif item.startswith("__b__") : mode, words, title = self.VVXpp9  , item[5:] , f + "Bouquets = " + item[5:]
   elif item.startswith("__w__") : mode, words, title = self.VVyd5U  , item[5:] , f + "Name = "  + item[5:]
   else       : return
  if len(title) > 58:
   title = title[:58] + ".."
  if mode == self.VVkE0m:
   VVZJ87 = []
   chName = VVxBfP.VVYzwE(1)
   if chName:
    list = set()
    for match in iFinditer(r"((?:[^\x00-\x7F]+\s*)+)", chName, IGNORECASE):
     list.add(match.group(1).strip())
    if list:
     for match in iFinditer(r"(\w+)", chName, IGNORECASE):
      list.add(match.group(1).strip())
    words = chName.split(" ")
    tWord = ""
    for word in words:
     tWord += " " + word
     list.add(word.strip())
     list.add(tWord.strip())
    for item in sorted(list):
     if item:
      VVZJ87.append((item, item))
    if not VVZJ87 and chName:
     VVZJ87.append((chName, chName))
    FFYySC(self, BF(self.VVykEE, title), title="Words from Current Selection", VVZJ87=VVZJ87)
   else:
    VVxBfP.VVIzOr("Invalid Channel Name")
  else:
   words, asPrefix = CCdUgX.VV0Xfy(words)
   if not words and mode in (self.VVXpp9, self.VVyd5U):
    FF5uKN(self.VVxBfP, "Incorrect filter", 2000)
   else:
    FFJsIX(self.VVxBfP, BF(self.VVFrGX, mode, words, asPrefix, title), clearMsg=False, title="Filtering ...")
 def VVykEE(self, title, word=None):
  if word:
   words = [word.lower()]
   FFJsIX(self.VVxBfP, BF(self.VVFrGX, self.VVkE0m, words, False, title), clearMsg=False, title="Filtering ...")
 @staticmethod
 def VVumjC(txt):
  return "#f#11ffff00#" + txt
 def VVFrGX(self, mode, words, asPrefix, title):
  if self.localIptvFilterInFilter : VVX3wb = self.VVUwHe(mode=mode, words=words, asPrefix=asPrefix)
  else       : VVX3wb = self.VVIbVP(mode=mode, words=words, asPrefix=asPrefix)
  if VVX3wb : self.VVxBfP.VVcckS(VVX3wb, title)
  else  : self.VVxBfP.VVIzOr("Not found")
 def VVUwHe(self, mode=0, words=None, asPrefix=False):
  VVX3wb = []
  for row in self.VVxBfP.VVlHja():
   row = list(map(str.strip, row))
   chNum, chName, VV1h0S, chType, refCode, url = row
   if self.VVOuIF(mode, refCode, FFlOsc(url).lower(), chName, words, VV1h0S.lower(), asPrefix):
    VVX3wb.append(row)
  VVX3wb = self.VVW8Tp(mode, VVX3wb)
  return VVX3wb
 def VVIbVP(self, mode=0, words=None, asPrefix=False, isStripChan=False):
  patt = r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8})(http.+)\n#DESCRIPTION\s+"
  if isStripChan: patt += r"[^\x00-\x7F]*(.+)[^\x00-\x7F]*"
  else    : patt += r"(.+)"
  VVX3wb = []
  files = CC9X9s.VV3Es2()
  if files:
   chNum = 1
   for path in files:
    if path.endswith("radio"): chType = "Radio"
    else      : chType = "TV"
    txt = FFQ5la(path)
    span = iSearch(r"#NAME\s(.+)", txt, IGNORECASE)
    if span : VV1h0S = span.group(1)
    else : VV1h0S = ""
    VV1h0S_lCase = VV1h0S.lower()
    for match in iFinditer(patt, txt, IGNORECASE):
     refCode = match.group(1).upper()
     url  = match.group(2).strip()
     chName = match.group(3).strip()
     if self.VVNowk(chName): chNameMod = self.VVumjC(chName)
     else        : chNameMod = chName
     row = (str(chNum), chNameMod, VV1h0S, chType + (" SRel" if FFqWLZ(url) else ""), refCode, url)
     if self.VVOuIF(mode, refCode, FFlOsc(url).lower(), chName, words, VV1h0S_lCase, asPrefix):
      VVX3wb.append(row)
      chNum += 1
  VVX3wb = self.VVW8Tp(mode, VVX3wb)
  return VVX3wb
 def VVW8Tp(self, mode, VVX3wb):
  newRows = []
  if VVX3wb and mode == self.VVswEo:
   counted  = iCounter(elem[4] for elem in VVX3wb)
   for item in VVX3wb:
    tot = counted.get(item[4], 0)
    if tot > 1:
     newRows.append(item)
   return newRows
  else:
   return VVX3wb
 def VVOuIF(self, mode, refCode, tUrl, chName, words, VV1h0S_lCase, asPrefix):
  if   mode == self.VVq3Pd : return True
  elif mode == self.VVswEo : return True
  elif mode == self.VV4iF5  : return ":0:0:0:0:0:0:" in refCode
  elif mode == self.VV0Thk : return FFqWLZ(tUrl)
  elif mode == self.VV4zzI  : return CC9X9s.VVXxn6(tUrl, getAudVid=True) == "vid"
  elif mode == self.VVFh3Q  : return CC9X9s.VVXxn6(tUrl, getAudVid=True) == "aud"
  elif mode == self.VVsM7x  : return CC9X9s.VVXxn6(tUrl, compareType="live")
  elif mode == self.VVsQ1z  : return CC9X9s.VVXxn6(tUrl, compareType="movie")
  elif mode == self.VVygdN : return CC9X9s.VVXxn6(tUrl, compareType="series")
  elif mode == self.VVIp7D  : return CC9X9s.VVXxn6(tUrl, compareType="")
  elif mode == self.VVs4rv  : return CC9X9s.VVXxn6(tUrl, compareExt="mkv")
  elif mode == self.VVLH3J  : return CC9X9s.VVXxn6(tUrl, compareExt="mp4")
  elif mode == self.VVbbdE  : return CC9X9s.VVXxn6(tUrl, compareExt="mp3")
  elif mode == self.VVedlT  : return CC9X9s.VVXxn6(tUrl, compareExt="avi")
  elif mode == self.VVhJnM  : return CC9X9s.VVXxn6(tUrl, compareExt="flv")
  elif mode == self.VVPq0V: return chName.lower().startswith(words[0])
  elif mode == self.VVkE0m: return words[0] in chName.lower()
  elif mode == self.VVaXHN: return bool(iSearch(r"[^\x00-\x7F]", chName))
  elif mode == self.VVXpp9 : return words[0] == VV1h0S_lCase
  elif mode == self.VVyd5U :
   name = chName.lower()
   for word in words:
    if asPrefix:
     if name.startswith(word) : return True
    elif word in name    : return True
  return False
 def VVJKT1(self):
  picker = CCSrvY(self, self.VVxBfP, "Add to Bouquet", self.VVNhhE)
 def VVNhhE(self):
  chUrlLst = []
  for row in self.VVxBfP.VVlHja():
   chUrlLst.append(row[4] + row[5])
  return chUrlLst
 def VVD3Ms(self):
  t1 = FFGB9z("Bouquet" , VVUVAI)
  t2 = FFGB9z("ALL"  , VVLbyB)
  t3 = FFGB9z("Unique"  , VVWOjU)
  t4 = FFGB9z("Identical" , VVMrXw)
  VVZJ87 = []
  VVZJ87.append((VVkIQ9 + "Check System Acceptable Reference Types", "VVrUSA"))
  VVZJ87.append(FFnqNr("Check Reference Codes Format", "VVmMHO", self.iptvFileAvailable, VVkIQ9))
  VVZJ87.append(VVoqHH)
  txt = "Change %s Ref. Types to (1/4097/5001/5002/8192/8193) .."
  VVZJ87.append((txt % t1, "VV95bO" ))
  VVZJ87.append((txt % t2, "VViQLg_all"  ))
  VVZJ87.append(VVoqHH)
  txt = "Change %s References to %s Codes .."
  VVZJ87.append((txt % (t1, t3), "VVFXps" ))
  VVZJ87.append((txt % (t2, t3), "VVRq0M"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Change %s References to %s Codes" % (t2, t4) , "VVXUqD_all"))
  VVkUAu = self.VVGPN9
  FFYySC(self, None, width=1150, title="IPTV Reference Tools", VVZJ87=VVZJ87, VVkUAu=VVkUAu, VVDlGi="#22002233", VVaSSM="#22001122")
 def VVGPN9(self, item=None):
  if item:
   ques = "Continue ?"
   VV4EHV, txt, item, ndx = item
   if   item == "VVrUSA"    : FFJsIX(VV4EHV, self.VVrUSA)
   elif item == "VVmMHO"     : FFJsIX(VV4EHV, self.VVmMHO)
   elif item == "VV95bO" : self.VVIbqa(VV4EHV, self.VVLYzc)
   elif item == "VViQLg_all"  : self.VVLYzc(VV4EHV, None, None)
   elif item == "VVFXps" : self.VVFXps(VV4EHV, txt)
   elif item == "VVRq0M"  : FFNKVM(self, BF(self.VVRq0M , VV4EHV, txt), title=txt, VVILc0=ques)
   elif item == "VVXUqD_all"  : FFNKVM(self, BF(FFJsIX, VV4EHV, self.VVXUqD), title=txt, VVILc0=ques)
 def VVLYzc(self, VV4EHV, bName, bPath):
  VVZJ87 = []
  for rt in CC9X9s.VVOYzb():
   VVZJ87.append(("%s\t ... %s" % (rt, CC9X9s.VVGmcc(rt)), rt))
  FFYySC(self, BF(self.VVrZe0, VV4EHV, bName, bPath), VVZJ87=VVZJ87, width=800, title="Change Reference Types to:")
 def VVrZe0(self, VV4EHV, bName, bPath, rType=None):
  if rType:
   self.VVlWh0(VV4EHV, bName, bPath, rType)
 def VVIbqa(self, VV4EHV, fnc):
  VVZJ87 = CCSrvY.VVSrxf()
  if VVZJ87:
   FFYySC(self, BF(self.VVUXes, VV4EHV, fnc), VVZJ87=VVZJ87, title="IPTV Bouquets", VV18hv=True)
  else:
   FF5uKN(VV4EHV, "No bouquets Found !", 1500)
 def VVUXes(self, VV4EHV, fnc, item=None):
  if item:
   bName, bRef, ndx = item
   span = iSearch(r'BOUQUET "(.+)" ORDER', bRef, IGNORECASE)
   if span:
    bPath = VVNwTu + span.group(1)
    if fileExists(bPath): fnc(VV4EHV, bName, bPath)
    else    : FF5uKN(VV4EHV, "Bouquet file not found!", 2000)
   else:
    FF5uKN(VV4EHV, "Cannot process bouquet !", 2000)
 def VVlWh0(self, VV4EHV, bName, bPath, rType):
  if bPath: title = "Change for Bouquet : %s" % FFGB9z(bName, VVVCGb)
  else : title = "Change for %s" % FFGB9z("All IPTV Services", VVVCGb)
  FFNKVM(self, BF(FFJsIX, VV4EHV, BF(self.VVmcbT, VV4EHV, bName, bPath, rType), title="Changing Type ...")
    , "Change to : %s ?" % FFGB9z(rType, VVVCGb), title=title)
 def VVmcbT(self, VV4EHV, bName, bPath, rType):
  totChange = 0
  if bPath: files = [bPath]
  else : files = CC9X9s.VV3Es2()
  if files:
   newRType = rType + ":"
   piconPath = CCijoe.VV4boJ()
   for path in files:
    if   not fileExists(path)      : err = "Cannot read the file:\n\n%s" % path
    elif not CCCXvS.VVJWb9(self, path) : err = "File is not in 'UTF-8' Encoding:\n\n%s" % path
    else           : err = ""
    if err:
     FFw5OO(self, err)
     return
    newpFile = path + ".tmp"
    totMod = 0
    with open(newpFile, "w") as tFile:
     with ioOpen(path, "r", encoding="utf-8") as f:
      for line in f:
       span = iSearch(r"#SERVICE\s+([A-Fa-f0-9]+[:]).+http.+", line)
       if span:
        oldRType = span.group(1)
        if not oldRType == newRType:
         totMod += 1
         totChange += 1
         span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
         if span : oldPicon = piconPath + span.group(1).strip(":").replace(":", "_") + ".png"
         else : oldPicon = ""
         line = iSub(r"(#SERVICE)\s+[A-Fa-f0-9]+[:](.+http.+)", r"\1 %s\2" % newRType, line)
         if fileExists(oldPicon):
          span = iSearch(r"((?:[A-Fa-f0-9]+[:]){10})", line)
          if span:
           FFuB0V("mv -f '%s' '%s'" % (oldPicon, piconPath + span.group(1).strip(":").replace(":", "_") + ".png"))
       tFile.write(line)
    if totMod: cmd = "mv -f '%s' '%s'" % (newpFile, path)
    else  : cmd = "rm -f '%s'" % newpFile
    FFuB0V(cmd)
  self.VVuVya(totChange > 0, 'Change Ref. Codes to "%s"' % rType, "Changes = %d" % totChange)
 def VVdexc(self):
  totFiles = 0
  files  = CC9X9s.VV3Es2()
  if files:
   totFiles = len(files)
  totChans = 0
  VVX3wb = self.VVIbVP()
  if VVX3wb:
   totChans = len(VVX3wb)
  FF90Bc(self, "Total Files\t: %d\nTotal Channels\t: %d" % (totFiles, totChans))
 def VVmMHO(self):
  files = CC9X9s.VV3Es2()
  if files:
   totInvalid = 0
   invTxt  = ""
   for path in files:
    txt = FFQ5la(path)
    for match in iFinditer(r"#SERVICE\s+(?!(?:(?:[A-Fa-f0-9]+[:]){10})).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE):
     totInvalid += 1
     invTxt += "%s\t: %s\n" % (os.path.basename(path), match.group(1))
   if totInvalid == 0 : color = VVVjNM
   else    : color = VVsObI
   totInvalid = FFGB9z(str(totInvalid), color)
   txt  = "Processed Files\t\t: %d\n" % len(files)
   txt += "Invalid References\t: %s\n" % totInvalid
   if invTxt:
    txt += FFGB9z("\nInvalid Refrences (File & Chan. Name):\n", color)
    txt += invTxt
  else:
   txt = "No IPTV Files processed."
  FF90Bc(self, txt, title="Check IPTV References")
 def VVrUSA(self):
  bName  = "%s_IPTV_TMP_BOUQUET_DEL" % PLUGIN_NAME
  userBName = "userbouquet.%s.tv"  % bName
  chPrefix = "Testing RType "
  rTypeList = CC9X9s.VVOYzb()
  chUrlLst = []
  for rType in (rTypeList):
   ref = "%s:0:1:DDD:DDD:DDD:DDD:0:0:0:http%%3a//testUrl.com/aa/bb.m3u8:Testing RType %s" % (rType, rType)
   chUrlLst.append(ref)
  CCSrvY.VV03W9(self, "", bName, "", chUrlLst, showRes=False)
  acceptedList = []
  VVnPFY = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % userBName)
  if VVnPFY:
   VVAFho = FFw4Nf(VVnPFY)
   if VVAFho:
    for service in VVAFho:
     chName = service[1]
     acceptedList.append(chName.replace(chPrefix, ""))
  path = VVNwTu + userBName
  bFile = VVNwTu + "bouquets.tv"
  tmpF = bFile + ".tmp"
  cmd = FFIV1X("grep -v '%s' '%s' > '%s'; mv '%s' '%s'" % (userBName, bFile, tmpF, tmpF, bFile))
  cmd += ";"
  cmd += FFIV1X("rm -f '%s'" % path)
  FFuB0V(cmd)
  FFAvBD()
  title = "System Acceptable Reference Types"
  if acceptedList:
   txt = ""
   for item in rTypeList:
    if item in acceptedList : res, color = "Yes", VVVjNM
    else     : res, color = "No" , VVsObI
    pl = CC9X9s.VVGmcc(item)
    txt += "    %s\t: %s%s\n" % (item, FFGB9z(res, color), FFGB9z("\t... %s" % pl, VVGb6D) if pl else "")
   FF90Bc(self, txt, title=title)
  else:
   txt = FFw5OO(self, "Could not complete the test on your system!", title=title)
 def VVUbKS(self):
  VVht0T, err = CCdAiy.VVcFnp(self, CCdAiy.VVuhUG)
  if VVht0T:
   totChannels = 0
   totChange = 0
   for path in CC9X9s.VV3Es2():
    toSave = False
    txt = FFQ5la(path)
    for match in iFinditer(r"(#SERVICE\s+[A-Fa-f0-9]+:)0:(?:[A-Fa-f0-9]+[:]){8}(.+\n#DESCRIPTION\s+(?:.+[:()|\]\[])*(.+))", txt, IGNORECASE):
     totChannels += 1
     chName = match.group(3).strip(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
     refCode = VVht0T.get(chName, "")
     if refCode:
      refCode  = refCode[refCode.index(":") + 1:]
      toSave  = True
      totChange += 1
      txt = txt.replace(match.group(0), match.group(1) + refCode + ":" + match.group(2))
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
   txt  = "Channels\t: %d\n" % totChannels
   txt += "Changed\t: %d\n" % totChange
   self.VVuVya(totChange > 0, "Copy Ref. from existing Channels", txt)
  else:
   FFw5OO(self, 'No channels in "lamedb" !')
 def VVRq0M(self, VV4EHV, title):
  bFiles = CC9X9s.VV3Es2()
  if bFiles: self.VVmyDt(bFiles, title)
  else  : FF5uKN(VV4EHV, "No bouquets files !", 1500)
 def VVFXps(self, VV4EHV, title):
  self.VVIbqa(VV4EHV, BF(self.VVJEMY, title))
 def VVJEMY(self, title, VV4EHV, bName, bPath):
  self.VVmyDt([bPath], title)
 def VVmyDt(self, bFiles, title):
  self.session.open(CCmNws, barTheme=CCmNws.VV3z22
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVwJSN, bFiles)
      , VVCeou = BF(self.VVObh4, title))
 def VVwJSN(self, bFiles, VVXLiB):
  VVXLiB.VVlaij = ""
  VVXLiB.VVHdrq("Calculating Reference ...")
  totLines = 0
  patt = r"#SERVICE\s+(?:[A-Fa-f0-9]+[:]){10}(.+\/\/.+)"
  for path in bFiles:
   if fileExists(path):
    lines = FFZQjt(path)
    for line in lines:
     span = iSearch(patt, line)
     if span:
      totLines += 1
  if not VVXLiB or VVXLiB.isCancelled:
   return
  elif not totLines:
   VVXLiB.VVlaij = "No IPTV Services !"
   return
  else:
   VVXLiB.VVCnyB(totLines)
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVXLiB or VVXLiB.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName  = os.path.basename(path)
    lines  = FFZQjt(path)
    for ndx, line in enumerate(lines):
     if not VVXLiB or VVXLiB.isCancelled:
      return
     if ndx == 0:
      span = iSearch(r"#NAME\s+(.+)", line, IGNORECASE)
      if span:
       bName = span.group(1)
      if VVXLiB:
       VVXLiB.VVHdrq("Processing : %s " % bName)
     span = iSearch(patt, line)
     if span:
      if VVXLiB:
       VVXLiB.VV1Vtn(1)
      refCode, startId, startNS = CCSrvY.VVwA2l(rType, CCSrvY.VViQzL, [], startId, startNS)
      if refCode:
       lines[ndx] = "#SERVICE %s" % (refCode + span.group(1))
       toSave = True
      else:
       if VVXLiB:
        VVXLiB.VVlaij = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
 def VVObh4(self, title, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  txt  = "Found\t: %d\n"  % threadTotal
  txt += "Changed\t: %d\n" % threadCounter
  if VVlaij:
   txt += "\n\n%s\n%s" % (FFGB9z("Ended with Error:", VVsObI), VVlaij)
  self.VVuVya(True, title, txt)
 def VV00qe(self):
  bFiles = CC9X9s.VV3Es2()
  if not bFiles:
   FF5uKN(self.VVxBfP, "No bouquets files !", 1500)
   return
  tableRefList = []
  for row in self.VVxBfP.VVlHja():
   tableRefList.append((row[4], row[5]))
  if not tableRefList:
   FF5uKN(self.VVxBfP, "Cannot read list", 1500)
   return
  self.session.open(CCmNws, barTheme=CCmNws.VV3z22
      , titlePrefix = "Renumbering References"
      , fncToRun  = BF(self.VVYIg5, bFiles, tableRefList)
      , VVCeou = BF(self.VVObh4, "Change Current List References to Unique Codes"))
 def VVYIg5(self, bFiles, tableRefList, VVXLiB):
  VVXLiB.VVlaij = ""
  VVXLiB.VVHdrq("Reading System References ...")
  refLst = CCSrvY.VVJujd(CCSrvY.VViQzL, stripRType=True)
  if not VVXLiB or VVXLiB.isCancelled:
   return
  VVXLiB.VVCnyB(len(tableRefList))
  rType = CFG.iptvAddToBouquetRefType.getValue()
  startId = startNS = 0
  for path in bFiles:
   if not VVXLiB or VVXLiB.isCancelled:
    return
   if fileExists(path):
    toSave = False
    bName = os.path.basename(path)
    txt  = FFQ5la(path)
    span = iSearch(r"#NAME\s+(.+)", txt, IGNORECASE)
    if span:
     bName = span.group(1)
    if not VVXLiB or VVXLiB.isCancelled:
     return
    VVXLiB.VVHdrq("Processing : %s " % bName)
    for ref, url in tableRefList:
     if not VVXLiB or VVXLiB.isCancelled:
      return
     fullRef = ref + url
     if fullRef in txt:
      VVXLiB.VV1Vtn(1)
      refCode, startId, startNS = CCSrvY.VVwA2l(rType, CCSrvY.VViQzL, refLst, startId, startNS)
      if refCode:
       tot = txt.count(fullRef)
       if tot > 0:
        txt = txt.replace(fullRef, refCode + url)
        toSave = True
      else:
       if VVXLiB:
        VVXLiB.VVlaij = "Out of Free References while processing the file:\n%s" % path
       return
    if toSave:
     with open(path, "w") as f:
      f.write(txt)
 def VVXUqD(self):
  list = None
  if self.VVxBfP:
   list = []
   for row in self.VVxBfP.VVlHja():
    list.append(row[4] + row[5])
  files = CC9X9s.VV3Es2()
  totChange = 0
  if files:
   for path in files:
    lines = FFZQjt(path)
    toSave = False
    for ndx, line in enumerate(lines):
     span = iSearch(r"#SERVICE\s+(.+\/\/.+)", line, IGNORECASE)
     if span:
      if not list or span.group(1) in list:
       txt, tot = iSubn(r"(#SERVICE\s+(?:[A-Fa-f0-9]+[:]){3})(?:[A-Fa-f0-9]+[:]){7}(.+\/\/.+)", r"\g<1>%s\2" % ("0:" * 7), line, IGNORECASE)
       if tot > 0:
        lines[ndx] = txt
        toSave  = True
        totChange += 1
    if toSave:
     with open(path, "w") as f:
      f.write("\n".join(lines) + "\n")
  self.VVuVya(totChange > 0, "Change to Identical Ref. Codes", "Changes = %d" % totChange)
 def VVuVya(self, isChanged, title, txt, refreshTable=True):
  if isChanged:
   FFAvBD()
   if refreshTable and self.VVxBfP:
    VVX3wb = self.VVIbVP()
    if VVX3wb and self.VVxBfP:
     self.VVxBfP.VVcckS(VVX3wb, self.tableTitle)
     self.VVxBfP.VVIzOr(txt)
   FF90Bc(self, txt, title=title)
  else:
   FF15cM(self, "No changes.")
 @staticmethod
 def VV3Es2(atLeastOne=False, onlyFileName=False):
  types = ('*.tv', '*.radio')
  files = []
  for f in types:
   files.extend(iGlob(VVNwTu + f))
  if files:
   iptvFiles = []
   for path in files:
    if fileExists(path):
     txt = FFQ5la(path)
     span = iSearch(r"#SERVICE.+\/\/.+\n#DESCRIPTION.+", txt, IGNORECASE)
     if span:
      iptvFiles.append(os.path.basename(path) if onlyFileName else path)
      if atLeastOne:
       return iptvFiles
   return iptvFiles
  else:
   return None
 def VV4SVi(self, VVxBfP, title, txt, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = FFlOsc(colList[5]).strip()
  iptvRef = refCode.rstrip(":") + ":" + url
  if not iptvRef.endswith(":" + chName):
   iptvRef += ":" + chName
  ndx = txt.find("URL")
  if ndx > -1:
   txt = txt[:ndx]
  txt = "%s\n\n%s" % (title, txt)
  FFcpNw(self, fncMode=CCjQ0P.VV1gCU, refCode=refCode, chName=chName, text=txt, decodedUrl=url, iptvRef=iptvRef)
 def VVGdbS(self, VVxBfP, colList):
  chName = colList[1]
  refCode = colList[4]
  url  = colList[5]
  chUrl = refCode + url
  return chName, chUrl
 def VVNCPR(self, VVxBfP, title, txt, colList):
  chName, chUrl = self.VVGdbS(VVxBfP, colList)
  self.VVeKlc(VVxBfP, chName, chUrl, "localIptv")
 def VV4Npj(self, mode, VVxBfP, colList):
  chName, chUrl, picUrl, refCode = self.VVAlWq(mode, colList)
  return chName, chUrl
 def VVkZUb(self, mode, VVxBfP, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVAlWq(mode, colList)
  self.VVeKlc(VVxBfP, chName, chUrl, mode)
 def VVeKlc(self, VVxBfP, chName, chUrl, playerFlag):
  chName = FFxmTk(chName)
  if self.VVNowk(chName):
   FF5uKN(VVxBfP, "This is a marker!", 300)
  else:
   FFJsIX(VVxBfP, BF(self.VVP6TD, VVxBfP, chUrl, playerFlag), title="Playing ...")
 def VVP6TD(self, VVxBfP, chUrl, playerFlag):
  FFkwBg(self, chUrl, VVIC8r=False)
  CCb9j4.VV6JFp(self.session, iptvTableParams=(self, VVxBfP, playerFlag))
 @staticmethod
 def VVNowk(chName):
  mark = ("--", "__", "==", "##",  "**", str(u"\u2605" * 2))
  if chName.startswith(mark) and chName.endswith(mark):
   return True
  return False
 def VV1Zbj(self, VVxBfP, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  if refCode:
   url1 = FFlOsc(origUrl.strip())
   for ndx, row in enumerate(VVxBfP.VVlHja()):
    if refCode in row[4]:
     tableRow = FFlOsc(row[5].strip())
     if url1 in tableRow or tableRow in url1:
      VVxBfP.VVYNxS(ndx)
      break
   else:
    FF5uKN(VVxBfP, "No found", 1000)
 def VV3ZT5(self, m3uMode):
  lines = self.VV0R5t(3)
  if lines:
   lines.sort()
   VVZJ87 = []
   for line in lines:
    VVZJ87.append((line, line))
   if m3uMode == CC9X9s.VVrdZ4:
    title = "Browse Server from M3U URLs"
    VV2YYF = ("All to Playlist", self.VV7mqZ)
   else:
    title = "M3U/M3U8 File Browser"
    VV2YYF = None
   VVkUAu = BF(self.VVu99f, m3uMode, title)
   VVXyZL = self.VVcPFq
   FFYySC(self, None, title=title, VVZJ87=VVZJ87, width=1200, VVkUAu=VVkUAu, VVXyZL=VVXyZL, VVAL4K="", VV2YYF=VV2YYF, VVDlGi="#11221122", VVaSSM="#11221122")
 def VVu99f(self, m3uMode, title, item=None):
  if item:
   VV4EHV, txt, path, ndx = item
   if m3uMode == CC9X9s.VVrdZ4:
    FFJsIX(VV4EHV, BF(self.VVXlfO, title, path))
   else:
    FFJsIX(VV4EHV, BF(self.VV9sGF, path))
 def VV9sGF(self, path, m3uFilterParam=None, VVxBfP=None):
  self.m3uOrM3u8BName = os.path.splitext(os.path.basename(path))[0]
  txt = FFQ5la(path)
  span = iSearch(r"#EXTINF:.+\n(.+)\n.+", txt, IGNORECASE)
  if span:
   self.curUrl = span.group(1)
  lst  = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  groups = []
  mode, words, asPrefix, fTitle = m3uFilterParam or (0, (), False, "")
  for ndx, cols in enumerate(lst, start=1):
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVDEOp(propLine, "group-title") or "-"
   if not group == "-" and self.VV3HOG(group):
    if not chName or self.VVbGFt(chName):
     if self.VVOuIF(mode, "", url.lower(), chName, words, "", asPrefix):
      groups.append(group)
  VVX3wb = []
  if groups:
   totAll = 0
   for name, tot in iCounter(groups).items():
    VVX3wb.append((name, str(tot), name))
    totAll += tot
   VVX3wb.sort(key=lambda x: x[0].lower())
   VVX3wb.insert(0, ("ALL", str(totAll), ""))
  if VVX3wb:
   title = "Groups" + m3uFilterParam[3] if m3uFilterParam else ""
   if VVxBfP:
    VVxBfP.VVcckS(VVX3wb, newTitle=title, VVuO90Msg=True)
   else:
    VV0xpR = self.VV2wbj
    VVwmV1  = ("Select" , BF(self.VVst1k, path, m3uFilterParam)  , [])
    VVFadD = ("Filter" , BF(self.VVQvnX, path, m3uFilterParam), [])
    header   = ("Group" , "Total" , "grp" )
    widths   = (85  , 15  , 0  )
    VVFvCJ  = (LEFT  , CENTER , LEFT )
    FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, width= 1400, height= 1000, VVTFXq=28, VVwmV1=VVwmV1, VVFadD=VVFadD, VV0xpR=VV0xpR, lastFindConfigObj=CFG.lastFindIptv
      , VVDlGi="#11110022", VVaSSM="#11110022", VVzgHY="#11110022", VVkUYa="#00444400")
  elif VVxBfP:
   FFzLBa(VVxBfP, "Not found !", 1500)
  else:
   self.VVgGPz(FFQ5la(path), "", m3uFilterParam)
 def VVst1k(self, path, m3uFilterParam, VVxBfP, title, txt, colList):
  self.VVgGPz(FFQ5la(path), colList[2], m3uFilterParam)
 def VVQvnX(self, path, m3uFilterParam, VVxBfP, title, txt, colList):
  VVZJ87 = []
  VVZJ87.append(("All"      , "all"  ))
  VVZJ87.append(FFHf46("Category"))
  VVZJ87.append(("Live TV"     , "live" ))
  VVZJ87.append(("VOD"      , "vod"  ))
  VVZJ87.append(("Series"     , "series" ))
  VVZJ87.append(("Uncategorised"   , "uncat" ))
  VVZJ87.append(FFHf46("Media"))
  VVZJ87.append(("Video"     , "video" ))
  VVZJ87.append(("Audio"     , "audio" ))
  VVZJ87.append(FFHf46("File Type"))
  VVZJ87.append(("MKV"      , "MKV"  ))
  VVZJ87.append(("MP4"      , "MP4"  ))
  VVZJ87.append(("MP3"      , "MP3"  ))
  VVZJ87.append(("AVI"      , "AVI"  ))
  VVZJ87.append(("FLV"      , "FLV"  ))
  filterObj = CCdUgX(self, VVDlGi="#11332244", VVaSSM="#11222244")
  filterObj.VV0Gkf(VVZJ87, [], BF(self.VVegk7, VVxBfP, path), inFilterFnc=None)
 def VVegk7(self, VVxBfP, path, item):
  if item is not None:
   if   item == "all"    : mode, words, fTitle = self.VVq3Pd , ""  , ""
   elif item == "live"    : mode, words, fTitle = self.VVsM7x  , ""  , "Live"
   elif item == "vod"    : mode, words, fTitle = self.VVsQ1z  , ""  , "VOD"
   elif item == "series"   : mode, words, fTitle = self.VVygdN  , ""  , "Series"
   elif item == "uncat"   : mode, words, fTitle = self.VVIp7D  , ""  , "Uncategorised"
   elif item == "video"   : mode, words, fTitle = self.VV4zzI  , ""  , "Video"
   elif item == "audio"   : mode, words, fTitle = self.VVFh3Q  , ""  , "Audio"
   elif item == "MKV"    : mode, words, fTitle = self.VVs4rv  , ""  , "MKV"
   elif item == "MP4"    : mode, words, fTitle = self.VVLH3J  , ""  , "MP4"
   elif item == "MP3"    : mode, words, fTitle = self.VVbbdE  , ""  , "MP3"
   elif item == "AVI"    : mode, words, fTitle = self.VVedlT  , ""  , "AVI"
   elif item == "FLV"    : mode, words, fTitle = self.VVhJnM  , ""  , "FLV"
   elif item.startswith("__w__") : mode, words, fTitle = self.VVyd5U  , item[5:] , item[5:]
   else       : return
   words, asPrefix = CCdUgX.VV0Xfy(words)
   if not mode == self.VVq3Pd:
    fTitle = "  Filter: %s" % (",".join(words) if words else fTitle)
    if len(fTitle) > 40: fTitle = fTitle[:40] + ".."
    fTitle = FFGB9z(fTitle, VVGb6D)
   m3uFilterParam = (mode, words, asPrefix, fTitle)
   FFJsIX(VVxBfP, BF(self.VV9sGF, path, m3uFilterParam, VVxBfP), title="Filtering ...")
 def VVgGPz(self, txt, filterGroup="", m3uFilterParam=None):
  lst   = iFindall(r"#EXTINF:(.+),(.+)\n(?:#EXTGRP:(.+)\n)*(http.+)", txt, IGNORECASE)
  bName = filterGroup or self.m3uOrM3u8BName or "ALL"
  title = ("Group : %s" % (filterGroup or "ALL")) + m3uFilterParam[3] if m3uFilterParam else ""
  if lst:
   self.session.open(CCmNws, barTheme=CCmNws.VVkie3
       , titlePrefix = "Reading File Lines", endTitle="Loading channels ..."
       , fncToRun  = BF(self.VVfqEG, lst, filterGroup, m3uFilterParam)
       , VVCeou = BF(self.VV2SXu, title, bName))
  else:
   self.VVkdsd("No valid lines found !", title)
 def VVfqEG(self, lst, filterGroup, m3uFilterParam, VVXLiB):
  VVXLiB.VVlaij = []
  VVXLiB.VVCnyB(len(lst))
  num = 0
  for cols in lst:
   if not VVXLiB or VVXLiB.isCancelled:
    return
   VVXLiB.VV1Vtn(1, True)
   propLine, chName, group, url = list(map(str.strip, cols))
   if not group:
    group = self.VVDEOp(propLine, "group-title") or "-"
   picon = self.VVDEOp(propLine, "tvg-logo")
   if not filterGroup or filterGroup == group:
    skip = False
    if   group and not self.VV3HOG(group) : skip = True
    elif chName and not self.VVbGFt(chName)   : skip = True
    elif m3uFilterParam:
     mode, words, asPrefix, fTitle = m3uFilterParam
     skip = not self.VVOuIF(mode, "", FFlOsc(url).lower(), chName, words, "", asPrefix)
    if not skip and VVXLiB:
     num += 1
     VVXLiB.VVlaij.append((str(num), chName, group.capitalize(), url, picon, "Yes" if len(picon) > 0 else ""))
 def VV2SXu(self, title, bName, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  if VVlaij:
   VV0xpR = self.VV2wbj
   VVwmV1  = ("Select"   , BF(self.VVEiEm, title)   , [])
   VVs5AA = (""    , self.VVwLRl        , [])
   VVX66G = ("Download PIcons", self.VVOBQ8       , [])
   VVIrDY = ("Options"  , BF(self.VVOXnV, "m3Ch", "", bName) , [])
   VVFadD = ("Posters Mode" , BF(self.VVjfVG, "m3u", 0)    , [])
   header   = ("Num" , "Name", "Group" , "URL" , "piconUrl", "Logo" )
   widths   = (10  , 54 , 28  , 0  , 0   , 8   )
   VVFvCJ  = (CENTER , LEFT , CENTER , LEFT , LEFT  , CENTER )
   FF1Dpj(self, None, title=title, header=header, VVarfR=VVlaij, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=28, VVwmV1=VVwmV1, VV0xpR=VV0xpR, VVs5AA=VVs5AA, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindIptv, VVUdUN=True, searchCol=1
     , VVDlGi="#0a00192B", VVaSSM="#0a00192B", VVzgHY="#0a00192B", VVkUYa="#00000000")
  else:
   self.VVkdsd("Not found !", title)
 def VVOBQ8(self, VVxBfP, title, txt, colList):
  self.VVii94(VVxBfP, "m3u/m3u8")
 def VVECbN(self, rowNum, url, chName):
  refCode = self.VVq9yy(rowNum, url, chName)
  chUrl = "%s%s:%s" % (refCode, FFGN9H(url), chName)
  return chUrl
 def VVq9yy(self, rowNum, url, chName):
  fName = os.path.basename(url)
  catID = "333"
  stID  =  "444"
  if fName:
   num = os.path.splitext(fName)[0]
   if num.isdigit() and int(num) < 0xeeee0000:
    stID = num
  chNum = str(rowNum + 1)
  refCode = self.VVcDWB(catID, stID, chNum)
  return refCode
 def VVDEOp(self, line, param):
  span = iSearch(r'%s="(.*?)"' % param, line, IGNORECASE)
  if span : return span.group(1).strip()
  else : return ""
 def VVEiEm(self, Title, VVxBfP, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  if url.endswith((".m3u", ".m3u8")):
   FFJsIX(VVxBfP, BF(self.VVJBVW, Title, VVxBfP, colList), title="Checking Server ...")
  else:
   self.VVh18j(VVxBfP, url, chName)
 def VVJBVW(self, title, VVxBfP, colList):
  if not CC2hCu.VViy1e(self):
   return
  chName = colList[1]
  group = colList[2]
  url  = colList[3]
  txt, err =  CCsdD3.VV8GpE(url, verify=True)
  if not err:
   if "#EXT-X-STREAM-INF" in txt:
    lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", txt, IGNORECASE)
    VVZJ87 = []
    for resol, fPath in lst:
     resol = str(resol).replace("x", " x ")
     fPath = str(fPath)
     fullUrl = CC9X9s.VVr5Ek(url, fPath)
     VVZJ87.append((resol, fullUrl))
    if VVZJ87:
     if len(VVZJ87) > 1:
      FFYySC(self, BF(self.VVQ7An, VVxBfP, chName), VVZJ87=VVZJ87, title="Resolution", VV18hv=True, VVhe5b=True)
     else:
      self.VVh18j(VVxBfP, VVZJ87[0][1], chName)
    else:
     span = iSearch(r"(http.+)", txt, IGNORECASE)
     if span:
      self.VVh18j(VVxBfP, span.group(1), chName)
     else:
      span = iSearch(r"#EXT-X-STREAM-INF.*\n(.+)", txt, IGNORECASE)
      if span:
       fullUrl = CC9X9s.VVr5Ek(url, span.group(1))
       self.VVh18j(VVxBfP, fullUrl, chName)
      else:
       self.VVl8O9("Cannot process server response !")
   elif "#EXTINF:" in txt:
    if url.endswith((".m3u", ".m3u8")) :
     span = iSearch(r"#EXTINF:.+\n(.+\.ts)", txt, IGNORECASE)
     if not span:
      self.VVgGPz(txt, filterGroup="")
      return
    self.VVh18j(VVxBfP, url, chName)
   else:
    self.VVkdsd("Cannot process this channel !", title)
  else:
   self.VVkdsd(err, title)
 def VVQ7An(self, VVxBfP, chName, item=None):
  if item:
   txt, resolUrl, ndx = item
   self.VVh18j(VVxBfP, resolUrl, chName)
 def VVh18j(self, VVxBfP, url, chName):
  FFJsIX(VVxBfP, BF(self.VVB2IP, VVxBfP, url, chName), title="Playing ...")
 def VVB2IP(self, VVxBfP, url, chName):
  chUrl = self.VVECbN(VVxBfP.VVgu5W(), url, chName)
  FFkwBg(self, chUrl, VVIC8r=False)
  CCb9j4.VV6JFp(self.session, iptvTableParams=(self, VVxBfP, "m3u/m3u8"))
 def VVWajK(self, VVxBfP, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  chUrl = self.VVECbN(VVxBfP.VVgu5W(), url, chName)
  return chName, chUrl
 def VVwLRl(self, VVxBfP, title, txt, colList):
  chName = colList[1].strip()
  url  = colList[3].strip()
  picUrl = colList[4].strip()
  txt = "%s\n\n%s" % (title, txt)
  FFcpNw(self, fncMode=CCjQ0P.VV1gCU, chName=chName, text=txt, decodedUrl=url, picUrl=picUrl)
 def VVkdsd(self, err, title):
  FFw5OO(self, err, title=title)
  if self.m3uOrM3u8File:
   self.close()
 def VV2wbj(self, VVxBfP):
  if self.m3uOrM3u8File:
   self.close()
  VVxBfP.cancel()
 def VV7mqZ(self, VVbBRSObj, item=None):
  FFJsIX(VVbBRSObj, BF(self.VVZSfD, VVbBRSObj, item))
 def VVZSfD(self, VVbBRSObj, item):
  if item:
   pList = []
   dupl = 0
   for ndx, item in enumerate(VVbBRSObj.VVZJ87):
    path = item[1]
    if fileExists(path):
     enc = CCqdtK.VVAtdG(path)
     if not enc == -1:
      with ioOpen(path, "r", encoding=enc) as f:
       for line in f:
        line = str(line).strip()
        if not line or len(line) > 500:
         continue
        url = CC9X9s.VVku8l(line)
        if url:
         if not url in pList : pList.append(url)
         else    : dupl += 1
         break
   title = "Create Playlist from m3u Files"
   if pList:
    pList.sort()
    path = CC9X9s.VVU5JK()
    pListF = "%sPlaylist_%s.txt" % (path, FFUD38())
    with open(pListF, "w") as f:
     for url in pList:
      f.write(url + "\n")
    txt = ""
    txt += "Prcessed Files\t: %d\n"    % len(VVbBRSObj.VVZJ87)
    if dupl > 0:
     txt += "Duplicates\t: %d  (removed)\n" % dupl
    txt += "Created Lines\t: %d\n"    % len(pList)
    txt += "Playlist File\t: %s"    % pListF
    FF90Bc(self, txt, title=title)
   else:
    FFw5OO(self, "Could not obtain URLs from this file list !", title=title)
 def VVNxZn(self, mode):
  if   mode == 1: title, okFnc = "Select Playlist File", self.VVdu79
  elif mode == 2: title, okFnc = "Select Portal File"  , self.VV0F6Q
  lines = self.VV0R5t(mode)
  if lines:
   lines.sort()
   VVZJ87 = []
   for line in lines:
    VVZJ87.append((FFGB9z(line, VVUVAI) if "Bookmarks" in line else line, line))
   VVXyZL = self.VVcPFq
   FFYySC(self, None, title=title, VVZJ87=VVZJ87, width=1200, VVkUAu=okFnc, VVXyZL=VVXyZL, VVAL4K="")
 def VVcPFq(self, VV4EHV, txt, ref, ndx):
  txt = ref
  sz = FFqLWj(ref)
  if sz > 0:
   txt += "\n\nSize: %s" % CCCXvS.VVutW7(sz)
  FF90Bc(self, txt, title="File Path")
 def VVdu79(self, item=None):
  if item:
   VV4EHV, txt, path, ndx = item
   FFJsIX(VV4EHV, BF(self.VVV6vy, VV4EHV, path), title="Processing File ...")
 def VVV6vy(self, VVYDp3, path):
  enc = CCqdtK.VVAtdG(path, self)
  if enc == -1:
   return
  VVX3wb = []
  num = lineNum = 0
  with ioOpen(path, "r", encoding=enc) as f:
   for line in f:
    lineNum += 1
    line = str(line).strip()
    if not line or len(line) > 500:
     continue
    line = iSub(r"([^\x00-\x7F]+)", r" ", line, flags=IGNORECASE)
    span = iSearch(r".*(http.+php.+username=.+password=.+)", line, IGNORECASE)
    url = ""
    if span:
     url = span.group(1)
     url = url.split(" ")[0].split("\t")[0].strip("'\"")
    else:
     span = iSearch(r"(http.+)\s+username(.+)\s+password\s+(.+)", line, IGNORECASE)
     if span:
      host = FF1vNj(span.group(1).strip())
      user1 = span.group(2).strip()
      pass1 = span.group(3).strip()
      url = "%sget.php?username=%s&password=%s&type=m3u" % (host, user1, pass1)
    if url:
     modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC9X9s.VVxGb5(url)
     uURL  = uURL.rstrip("/")
     equalTo  = ""
     for item in VVX3wb:
      if item[2] == uURL and item[3] == uUser and item[4] == uPass:
       equalTo = ",".join(list(filter(None, [item[5], item[0]])))
     num += 1
     VVX3wb.append((str(num), str(lineNum), uURL, uUser, uPass, equalTo, url))
  if VVX3wb:
   title = "Playlist File : %s" % os.path.basename(path)
   VVwmV1  = ("Start"    , BF(self.VVRt6Y, "Playlist File")      , [])
   VVZ224 = ("Home Menu"   , FFJgMq             , [])
   VVX66G = ("Download M3U File" , self.VVggh1         , [])
   VVIrDY = ("Edit File"   , BF(self.VV5rlQ, path)        , [])
   VVFadD = ("Check & Filter"  , BF(self.VVSybd, VVYDp3, path) , [])
   header   = ("Num" , "LineNum" , "Address" , "User" , "Password" , "Duplicate Line" , "URL" )
   widths   = (10  , 0   , 35  , 20  , 20   , 15    , 0.03 )
   VVFvCJ  = (CENTER , CENTER , LEFT  , LEFT   , LEFT   , LEFT    , LEFT  )
   FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVZ224=VVZ224, VVFadD=VVFadD, VVX66G=VVX66G, VVIrDY=VVIrDY, VVDlGi="#11001116", VVaSSM="#11001116", VVzgHY="#11001116", VVkUYa="#00003635", VVivoO="#0a333333", VVdjpa="#11331100", VVUdUN=True, searchCol=2, lastFindConfigObj=CFG.lastFindServers)
  else:
   FFw5OO(self, "No valid URLs line in this file:\n\n%s" % path, title="Get Play list URLs")
 def VVggh1(self, VVxBfP, title, txt, colList):
  host = colList[2]
  url  = colList[6]
  title = "Download Server M3U File"
  t = "&type=m3u"
  if not url.endswith(t):
   url += t
  url = url.replace("player_api.php", "get.php" )
  FFNKVM(self, BF(FFJsIX, VVxBfP, BF(self.VVn2bV, title, url), title="Downloading ..."), "Download m3u file for ?\n\n%s" % host, title=title)
 def VVn2bV(self, title, url):
  path, err = FFtKyC(url, "ajp_tmp.m3u", timeout=3)
  errTitle = "Download Problem"
  if err:
   FFw5OO(self, err, title=errTitle)
  elif fileExists(path):
   txt = FFQ5la(path)
   if '{"user_info":{"auth":0}}' in txt:
    FFzyFM(path)
    FFw5OO(self, "Unauthorized", title=errTitle)
   elif not "#EXTM3U" in txt:
    FFzyFM(path)
    FFw5OO(self, "Incorrect M3U file received !", title=errTitle)
   else:
    fName = os.path.basename(path)
    newPath = CC9X9s.VVU5JK() + fName
    FFuB0V("mv -f '%s' '%s'" % (path, newPath))
    if fileExists(newPath):
     path = newPath
    FF15cM(self, "Downloaded to:\n\n%s" % path, title=title)
  else:
   FFw5OO(self, "Could not download the M3U file!", title=errTitle)
 def VVRt6Y(self, Title, VVxBfP, title, txt, colList):
  url = colList[6]
  FFJsIX(VVxBfP, BF(self.VVcKAy, Title, url), title="Checking Server ...")
 def VV5rlQ(self, path, VVxBfP, title, txt, colList):
  rowNum = int(colList[1].strip()) - 1
  if fileExists(path) : CCQ3ND(self, path, VVCeou=BF(self.VVXw3b, VVxBfP), curRowNum=rowNum)
  else    : FFZoTn(self, path)
 def VVXw3b(self, VVxBfP, fileChanged):
  if fileChanged:
   VVxBfP.cancel()
 def VVN5El(self, title):
  curChName = self.VVxBfP.VVYzwE(1)
  FFaSvq(self, BF(self.VVn7sp, title), defaultText=curChName, title=title, message="Enter Name:")
 def VVn7sp(self, title, name):
  if name:
   VVht0T, err = CCdAiy.VVcFnp(self, CCdAiy.VVeJkE, VV7D78=False, VVPhms=False)
   list = []
   if VVht0T:
    name = self.VVrS8k(name)
    ratio = "1"
    for item in VVht0T:
     if name in item[0].lower():
      list.append((item[0], FF0JDR(item[2]), item[3], ratio))
   if list : self.VVxVJf(list, title)
   else : FFw5OO(self, "Not found:\n\n%s" % name, title=title)
 def VVKfcx(self, title):
  curChName = self.VVxBfP.VVYzwE(1)
  self.session.open(CCmNws, barTheme=CCmNws.VVkie3
      , titlePrefix = "Find similar names"
      , fncToRun  = self.VVO4hC
      , VVCeou = BF(self.VVqUJ8, title, curChName))
 def VVO4hC(self, VVXLiB):
  curChName = self.VVxBfP.VVYzwE(1)
  VVht0T, err = CCdAiy.VVcFnp(self, CCdAiy.VVPj3L, VV7D78=False, VVPhms=False)
  if not VVht0T or not VVXLiB or VVXLiB.isCancelled:
   return
  VVXLiB.VVlaij = []
  VVXLiB.VVCnyB(len(VVht0T))
  curCh = self.VVrS8k(curChName)
  for refCode in VVht0T:
   chName, sat, inDB = VVht0T.get(refCode, ("", "", 0))
   ratio = CCijoe.VV5jiJ(chName.lower(), curCh)
   if not VVXLiB or VVXLiB.isCancelled:
    return
   VVXLiB.VV1Vtn(1, True)
   if VVXLiB and ratio > 50:
    VVXLiB.VVlaij.append((chName, FF0JDR(sat), refCode.replace("_", ":"), str(ratio)))
 def VVqUJ8(self, title, curChName, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  if VVlaij: self.VVxVJf(VVlaij, title)
  elif VVeObj: FFw5OO(self, "No similar names found for:\n\n%s" % curChName, title)
 def VVxVJf(self, VVX3wb, title):
  curChName = self.VVxBfP.VVYzwE(1)
  VVgYnt = self.VVxBfP.VVYzwE(4)
  curUrl  = self.VVxBfP.VVYzwE(5)
  VVX3wb.sort(key=lambda x: (100-int(x[3]), x[0].lower()))
  VVwmV1  = ("Share Sat/C/T Ref.", BF(self.VVKx7j, title, curChName, VVgYnt, curUrl), [])
  header   = ("Name" , "Sat"  , "Reference" , "Ratio" )
  widths   = (34  , 33  , 33   , 0   )
  FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVDlGi="#0a00112B", VVaSSM="#0a001126", VVzgHY="#0a001126", VVkUYa="#00000000")
 def VVKx7j(self, newtitle, curChName, VVgYnt, curUrl, VVxBfP, title, txt, colList):
  newChName = colList[0]
  newRefCode = colList[2]
  data  = newtitle, curChName, VVgYnt, curUrl, newChName, newRefCode
  ques  = "IPTV Channel\t: %s\n\nSat/C/T Chan. \t: %s\n" % (curChName, newChName)
  FFNKVM(self.VVxBfP, BF(FFJsIX, self.VVxBfP, BF(self.VVi83I, VVxBfP, data)), ques, title=newtitle, VV4evd=True)
 def VVi83I(self, VVxBfP, data):
  VVxBfP.cancel()
  title, curChName, VVgYnt, curUrl, newChName, newRefCode = data
  curUrl  = curUrl.strip()
  VVgYnt = VVgYnt.strip()
  newRefCode = newRefCode.strip()
  if not VVgYnt.endswith(":") : VVgYnt += ":"
  if not newRefCode.endswith(":") : newRefCode += ":"
  curFullUrl = newFullUrl = ""
  span = iSearch(r"([A-Fa-f0-9]+:).+", VVgYnt, IGNORECASE)
  if span:
   curRType = span.group(1)
   span = iSearch(r"[A-Fa-f0-9]+:(.+)", newRefCode, IGNORECASE)
   if span:
    newRefCode = curRType + span.group(1)
    curFullUrl = VVgYnt + curUrl
    newFullUrl = newRefCode + curUrl
  totChanges = 0
  resTxt = resErr = ""
  if curFullUrl and newFullUrl:
   for path in CC9X9s.VV3Es2():
    txt = FFQ5la(path)
    if curFullUrl in txt:
     totChanges += 1
     txt = txt.replace(curFullUrl, newFullUrl)
     with open(path, "w") as f:
      f.write(txt)
   if totChanges > 0:
    FFAvBD()
    newRow = []
    for i in range(6):
     newRow.append(self.VVxBfP.VVYzwE(i))
    newRow[4] = newRefCode
    done = self.VVxBfP.VVBaiu(newRow)
    resTxt = "Done"
   else:
    resErr = "Not found in IPTV files"
  else:
   resErr = "Cannot read Chan. Info."
  if   resTxt: FFFANg(BF(FF15cM , self, resTxt, title=title))
  elif resErr: FFFANg(BF(FFw5OO, self, resErr, title=title))
 def VVSybd(self, VVYDp3, path, VVxBfP, title, txt, colList):
  self.session.open(CCmNws, barTheme=CCmNws.VV3z22
      , titlePrefix = "Checking Authorized Servers"
      , fncToRun  = BF(self.VVKYzf, VVxBfP)
      , VVCeou = BF(self.VVsO4X, VVYDp3, path, VVxBfP))
 def VVKYzf(self, VVxBfP, VVXLiB):
  VVXLiB.VVCnyB(VVxBfP.VVLC76())
  VVXLiB.VVlaij = []
  for row in VVxBfP.VVlHja():
   if not VVXLiB or VVXLiB.isCancelled:
    return
   VVXLiB.VV1Vtn(1, True)
   qUrl = self.VVskoG(self.VVe1w4, row[6])
   txt, err = self.VVuaOC(qUrl, timeout=1)
   if not err:
    try:
     tDict = jLoads(txt)
     if tDict and not err and "server_info" in tDict:
      item = tDict["user_info"]
      if not self.VVV2zK(item, "auth") == "0":
       VVXLiB.VVlaij.append(qUrl)
    except:
     pass
 def VVsO4X(self, VVYDp3, path, VVxBfP, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  if VVeObj:
   list = VVlaij
   title = "Authorized Servers"
   if list:
    totChk = VVxBfP.VVLC76()
    totAuth = len(list)
    if not totAuth == totChk:
     newPath = path + "_OK_%s.txt" % FFUD38()
     with open(newPath, "w") as f:
      for item in list:
       f.write("%s\n" % item)
     self.VVNxZn(1)
     txt = ""
     txt += "Checked\t: %d\n"  %  totChk
     txt += "Authorized\t: %s\n\n" %  FFGB9z(str(totAuth), VVVjNM)
     txt += "%s\n\n%s"    %  (FFGB9z("Result File:", VVUVAI), newPath)
     FF90Bc(self, txt, title=title)
     VVxBfP.close()
     VVYDp3.close()
    else:
     FF15cM(self, "All URLs are authorized.", title=title)
   else:
    FFw5OO(self, "No authorized URL found !", title=title)
 @staticmethod
 def VVuaOC(url, timeout=3, allowDocType=False):
  if not iRequest:
   return "" , "Cannot import URLLIB/URLLIB2 !"
  try:
   req = iRequest(url)
   req.add_header('User-Agent', 'Mozilla/5.0')
   res = iUrlopen(req, timeout=timeout)
   resCode = res.code
   if resCode == 200 :
    cont = res.headers.get("Content-Type")
    if cont:
     if not any(x in cont for x in ("/json", "/ld+json", "text/html")):
      return "", "Unexpected server data type ( %s )" % cont
     res = res.read().decode("UTF-8")
     if res:
      if not allowDocType and "<!DOCTYPE html>" in res: return "", "Incorrect data format from server."
      else           : return res, ""
     else:
      return "", "No data from server."
    else:
     return "", "No data received from server"
   elif resCode == 401 : err = "Unauthorized"
   elif resCode == 402 : err = "Payment Required"
   elif resCode == 408 : err = "Request Timeout"
   else    : err = "err=%d" % resCode
   return "", err
  except Exception as e:
   return "", str(e)
 @staticmethod
 def VVxGb5(url):
  uURL = uProtoc = uHost = uPort = uQuery = uUser = uPass = ""
  modified = False
  uQueryParam = {}
  span  = iSearch(r"\s*(?:(.+):\/\/)*([^:^\/]*)(?::(\d*)\/)*\/*([^\?]*)\?*(.+)", url, IGNORECASE)
  if span:
   modified = True
   uProtoc = span.group(1) or ""
   uHost = span.group(2) or ""
   uPort = span.group(3) or ""
   uQuery = span.group(4) or ""
   param = span.group(5) or ""
   for part in param.split("&"):
    if "=" in part:
     if   part.lower().startswith("username"): uUser = part.split("=")[1]
     elif part.lower().startswith("password"): uPass = part.split("=")[1]
     parts = part.split("=")
     key = parts[0]
     val = parts[1]
     uQueryParam[key] = val
  if uProtoc : uProtoc += "://"
  if uPort : uPort = ":" + uPort
  uURL = "%s%s%s/" % (uProtoc, uHost, uPort)
  return modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam
 @staticmethod
 def VVXxn6(url, justValidate=False, getAudVid=False, compareType=None, compareExt=None, justRetDotExt=False):
  res = scheme = netloc = path = params = query = fragment = username = password = hostname = port = ""
  try:
   if not iUrlparse(url).scheme:
    url = url.lstrip("/")
    url = "http://" + url
   res   = iUrlparse(url)
   scheme  = res.scheme
   netloc  = res.netloc
   path  = res.path
   params  = res.params
   query  = res.query
   fragment = res.fragment
   username = res.username or ""
   password = res.password or ""
   hostname = res.hostname or ""
   port  = res.port  or ""
  except:
   pass
  if justValidate:
   return all([scheme, netloc, path])
  tmpPath = path.strip("/")
  if   path.startswith("/live/")            : chType, tmpPath = "live" , path[6:]
  elif path.startswith("/movie/")            : chType, tmpPath = "movie" , path[7:]
  elif path.startswith("/series/")           : chType, tmpPath = "series", path[8:]
  elif any(x in tmpPath for x in (".m3u8", ".ts", "deviceUser", "deviceMac")) : chType = "live"
  else                  : chType = ""
  parts = tmpPath.split("/")
  if len(parts) >= 2:
   username = parts[0]
   password = parts[1]
   if len(parts) > 2:
    tmpPath  = "/".join(parts[2:])
  parts  = tmpPath.split(":")
  fileName = parts[0]
  if len(parts) > 1: chName = ":".join(parts[1:])
  elif ":" in query: chName = query.split(":")[1]
  else    : chName = ""
  streamId, dotExt = os.path.splitext(fileName)
  ext = dotExt[1:]
  if justRetDotExt:
   return dotExt
  if compareExt:
   if compareExt == ext: return True
   else    : return False
  if getAudVid:
   if ext:
    tDict = CCA8jA.VV1p4d()
    if   ext in list(tDict["mov"]): return "vid"
    elif ext in list(tDict["mus"]): return "aud"
   return ""
  if streamId.isdigit():
   if not chType :
    if not ext              : chType = "live"
    elif iSearch(r"(s\d\d.*e\d\d|e\d\d.*s\d\d)", chName, IGNORECASE): chType = "series"
    else               : chType = "movie:"
  else:
   streamId = ""
  if compareType is not None:
   if compareType == chType: return True
   else     : return False
  else:
   if scheme:
    scheme += "://"
   host = scheme + netloc
   return chType, host, username, password, streamId, chName
 @staticmethod
 def VVwzsj(decodedUrl):
  return CC9X9s.VVXxn6(decodedUrl, justRetDotExt=True)
 def VVskoG(self, mode, url, Id="0"):
  Id = str(Id).strip()
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVxGb5(url)
  url = "%splayer_api.php?username=%s&password=%s" % (uURL, uUser, uPass)
  if   mode == self.VVe1w4   : return "%s"            % url
  elif mode == self.VVymqZ   : return "%s&action=get_live_categories"     % url
  elif mode == self.VVJ6qH   : return "%s&action=get_vod_categories"      % url
  elif mode == self.VVKYG7  : return "%s&action=get_series_categories"     % url
  elif mode == self.VVCUx4  : return "%s&action=get_live_categories"     % url
  elif mode == self.VVFVA3 : return "%s&action=get_series_info&series_id=%s"   % (url, Id)
  elif mode == self.VVTObo   : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
  elif mode == self.VVPA9X    : return "%s&action=get_vod_streams&category_id=%s"   % (url, Id)
  elif mode == self.VVhOAc  : return "%s&action=get_series&category_id=%s"    % (url, Id)
  elif mode == self.VV6X6H : return "%s&action=get_live_streams"      % url
  elif mode == self.VVW6Tp  : return "%s&action=get_live_streams&category_id=%s"  % (url, Id)
 @staticmethod
 def VVV2zK(item, key, isDate=False, is_base64=False, isToHHMMSS=False):
  if key in item:
   val = str(item[key])
   try:
    if   isDate  : val = FFC3u1(int(val))
    elif is_base64 : val = FFH6Pe(val)
    elif isToHHMMSS : val = FF3Odj(int(val))
   except:
    pass
   if val == "None": return ""
   else   : return val.strip()
  else:
   return ""
 def VVXlfO(self, title, path):
  if fileExists(path):
   enc = CCqdtK.VVAtdG(path, self)
   if enc == -1:
    return
   qUrl = ""
   with ioOpen(path, "r", encoding=enc) as f:
    for line in f:
     line = str(line).strip()
     if not line or len(line) > 500:
      continue
     qUrl = CC9X9s.VVku8l(line)
     if qUrl:
      break
   if qUrl : self.VVcKAy(title, qUrl)
   else : FFw5OO(self, "Invalid M3U line format in:\n\n%s" % path, title=title)
  else:
   FFw5OO(self, "Cannot open file :\n\n%s" % path, title=title)
 def VV0AUe(self):
  title = "Current Channel Server"
  qUrl, iptvRef = CC9X9s.VVxFip(self)
  if qUrl or "chCode" in iptvRef:
   p = CCsdD3()
   valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query = p.VVdTlz(iptvRef)
   if valid:
    self.VV7fmP(self, host, mac)
    return
   elif qUrl:
    FFJsIX(self, BF(self.VVcKAy, title, qUrl), title="Checking Server ...")
    return
  FFw5OO(self, "Error in current channel URL !", title=title)
 @staticmethod
 def VVxFip(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(SELF)
  qUrl = CC9X9s.VVku8l(decodedUrl)
  return qUrl, iptvRef
 @staticmethod
 def VVku8l(url):
  if url.startswith("#"):
   return ""
  url = url.strip(" /")
  try:
   res = iUrlparse(url)
  except:
   return ""
  scheme = res.scheme
  netloc = res.netloc
  if not scheme or not netloc:
   return ""
  host = scheme + "://" +  netloc
  path = res.path.strip("/")
  if   path.startswith("live/") : path = path[5:]
  elif path.startswith("movie/") : path = path[6:]
  elif path.startswith("series/") : path = path[7:]
  parts = path.split("/")
  if len(parts) == 3 and len(parts[0]) > 1: return "%s/get.php?username=%s&password=%s&type=m3u" % (host, parts[0], parts[1])
  else         : return ""
 def VVcKAy(self, title, url):
  self.curUrl = url
  self.VVMcR7Data = {}
  qUrl = self.VVskoG(self.VVe1w4, url)
  txt, err = self.VVuaOC(qUrl)
  if err:
   err = "Server Error:\n\n%s" % err
  tDict = {}
  if not err:
   try:
    tDict = jLoads(txt)
   except:
    pass
   if not tDict:
    err = "Could not parse server data !"
  if tDict and not err:
   self.VVMcR7Data = {"playListURL": url}
   if "user_info" in tDict and "server_info" in tDict:
    item = tDict["user_info"]
    self.VVMcR7Data["username"    ] = self.VVV2zK(item, "username"        )
    self.VVMcR7Data["password"    ] = self.VVV2zK(item, "password"        )
    self.VVMcR7Data["message"    ] = self.VVV2zK(item, "message"        )
    self.VVMcR7Data["auth"     ] = self.VVV2zK(item, "auth"         )
    self.VVMcR7Data["status"    ] = self.VVV2zK(item, "status"        )
    self.VVMcR7Data["exp_date"    ] = self.VVV2zK(item, "exp_date"    , isDate=True )
    self.VVMcR7Data["is_trial"    ] = self.VVV2zK(item, "is_trial"        )
    self.VVMcR7Data["active_cons"   ] = self.VVV2zK(item, "active_cons"       )
    self.VVMcR7Data["created_at"   ] = self.VVV2zK(item, "created_at"   , isDate=True )
    self.VVMcR7Data["max_connections"  ] = self.VVV2zK(item, "max_connections"      )
    self.VVMcR7Data["allowed_output_formats"] = self.VVV2zK(item, "allowed_output_formats"    )
    key = "allowed_output_formats"
    val = item.get(key, None)
    if isinstance(val, list):
     self.VVMcR7Data[key] = " , ".join(val)
    item = tDict["server_info"]
    self.VVMcR7Data["url"    ] = self.VVV2zK(item, "url"        )
    self.VVMcR7Data["port"    ] = self.VVV2zK(item, "port"        )
    self.VVMcR7Data["https_port"  ] = self.VVV2zK(item, "https_port"      )
    self.VVMcR7Data["server_protocol" ] = self.VVV2zK(item, "server_protocol"     )
    self.VVMcR7Data["rtmp_port"   ] = self.VVV2zK(item, "rtmp_port"       )
    self.VVMcR7Data["timezone"   ] = self.VVV2zK(item, "timezone"       )
    self.VVMcR7Data["timestamp_now"  ] = self.VVV2zK(item, "timestamp_now"  , isDate=True )
    self.VVMcR7Data["time_now"   ] = self.VVV2zK(item, "time_now"       )
    VVZJ87  = self.VVS5Zj(True)
    VVkUAu = self.VVTkjN
    VVXyZL = self.VVgtnM
    VV6LYc = ("Home Menu", FFJgMq)
    VV3ba7= ("Add to Menu", BF(CC9X9s.VViT6z, self, False, self.VVMcR7Data["playListURL"]))
    VV2YYF = ("Bookmark Server", BF(CC9X9s.VVU5D0, self, False, self.VVMcR7Data["playListURL"]))
    FFYySC(self, None, title="IPTV Server Resources", VVZJ87=VVZJ87, VVkUAu=VVkUAu, VVXyZL=VVXyZL, VV6LYc=VV6LYc, VV3ba7=VV3ba7, VV2YYF=VV2YYF)
   else:
    err = "Could not get data from server !"
  if err:
   FFw5OO(self, err, title=title)
  FF5uKN(self)
 def VVTkjN(self, item=None):
  if item:
   VV4EHV, title, ref, ndx = item
   wTxt = "Downloading ..."
   if   ref == "live"   : FFJsIX(VV4EHV, BF(self.VV0X1B, self.VVymqZ  , title=title), title=wTxt)
   elif ref == "vod"   : FFJsIX(VV4EHV, BF(self.VV0X1B, self.VVJ6qH  , title=title), title=wTxt)
   elif ref == "series"  : FFJsIX(VV4EHV, BF(self.VV0X1B, self.VVKYG7 , title=title), title=wTxt)
   elif ref == "catchup"  : FFJsIX(VV4EHV, BF(self.VV0X1B, self.VVCUx4 , title=title), title=wTxt)
   elif ref == "accountInfo" : FFJsIX(VV4EHV, BF(self.VVbL3J           , title=title), title=wTxt)
 def VVgtnM(self, VV4EHV, txt, ref, ndx):
  FFJsIX(VV4EHV, self.VVL3ag)
 def VVL3ag(self):
  txt = self.curUrl
  if VV8Ixy:
   ver, err = self.VVr1jo(self.VV95q4())
   txt += "\n\n"
   txt += "Original\t: %s\n" % self.curUrl
   txt += "Modified\t: %s\n" % self.VV4Xnp
   txt += "PHP\t: %s\n"  % self.VVTex6
   txt += "Extra\t: %s\n"  % {2:"Big", 3:"Sml"}.get(self.VVUq9A, "-")
   txt += "Version\t: %s"  % (ver or err)
  FF90Bc(self, txt, title="Current Server URL")
 def VVbL3J(self, title):
  rows = []
  for key, val in self.VVMcR7Data.items():
   if isinstance(val, list): val = str(" , ".join(val))
   else     : val = str(val)
   if any(x in key for x in ("url", "port", "https_port", "server_protocol", "rtmp_port", "timezone", "timestamp_now", "time_now")):
    num, part = "2", self.VVpyaD
   else:
    num, part = "1", self.VVDPUO
   rows.append((num, part, str(key).replace("_", " ").title(), str(val)))
  rows.sort(key=lambda x: (x[0], x[2]))
  VVZ224  = ("Home Menu", FFJgMq, [])
  VVX66G  = None
  if VV8Ixy:
   VVX66G = ("Get JS" , BF(self.VVZ9xI, "/".join(self.VVMcR7Data["playListURL"].split("/")[:-1])), [])
  header    = ("Num", "User/Server" , "Subject" , "Value" )
  widths    = (0 , 15   , 35  , 50  )
  FF1Dpj(self, None, title=title, width=1200, header=header, VVarfR=rows, VVhAo0=widths, VVTFXq=26, VVZ224=VVZ224, VVX66G=VVX66G, VVDlGi="#0a00292B", VVaSSM="#0a002126", VVzgHY="#0a002126", VVkUYa="#00000000", searchCol=2)
 def VVcAc5(self, mode, jData):
  list = []
  err  = ""
  try:
   tDict = jLoads(jData)
   if tDict:
    if mode in (self.VVTObo, self.VVW6Tp):
     for ndx, item in enumerate(tDict, start=1):
      num      = self.VVV2zK(item, "num"         )
      name     = self.VVV2zK(item, "name"        )
      stream_id    = self.VVV2zK(item, "stream_id"       )
      stream_icon    = self.VVV2zK(item, "stream_icon"       )
      epg_channel_id   = self.VVV2zK(item, "epg_channel_id"      )
      added     = self.VVV2zK(item, "added"    , isDate=True )
      is_adult    = self.VVV2zK(item, "is_adult"       )
      category_id    = self.VVV2zK(item, "category_id"       )
      tv_archive    = self.VVV2zK(item, "tv_archive"       )
      direct_source   = self.VVV2zK(item, "direct_source"      )
      tv_archive_duration  = self.VVV2zK(item, "tv_archive_duration"     )
      name = self.VVbGFt(name, is_adult)
      if name:
       if mode == self.VVTObo or mode == self.VVW6Tp and tv_archive == "1":
        hasPicon = "Yes" if stream_icon else ""
        catchupTxt = ""
        if tv_archive == "1":
         catchupTxt = "Yes"
         if tv_archive_duration:
          if tv_archive_duration == "1" : catchupTxt = "1 day"
          else       : catchupTxt = "%s days" % tv_archive_duration
        list.append((num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source))
    elif mode == self.VVPA9X:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVV2zK(item, "num"         )
      name    = self.VVV2zK(item, "name"        )
      stream_id   = self.VVV2zK(item, "stream_id"       )
      stream_icon   = self.VVV2zK(item, "stream_icon"       )
      added    = self.VVV2zK(item, "added"    , isDate=True )
      is_adult   = self.VVV2zK(item, "is_adult"       )
      category_id   = self.VVV2zK(item, "category_id"       )
      container_extension = self.VVV2zK(item, "container_extension"     ) or "mp4"
      name = self.VVbGFt(name, is_adult)
      if name:
       isPicon = "Yes" if stream_icon else ""
       list.append((num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon))
    elif mode == self.VVhOAc:
     for ndx, item in enumerate(tDict, start=1):
      num     = self.VVV2zK(item, "num"        )
      name    = self.VVV2zK(item, "name"       )
      series_id   = self.VVV2zK(item, "series_id"      )
      cover    = self.VVV2zK(item, "cover"       )
      genre    = self.VVV2zK(item, "genre"       )
      episode_run_time = self.VVV2zK(item, "episode_run_time"    )
      category_id   = self.VVV2zK(item, "category_id"      )
      container_extension = self.VVV2zK(item, "container_extension"    ) or "mp4"
      name = self.VVbGFt(name)
      if name:
       isPicon = "Yes" if cover else ""
       list.append((num, name, category_id, series_id, genre, episode_run_time, container_extension, cover, isPicon))
  except:
   err = "Cannot parse received data !"
  return list, err
 def VV0X1B(self, mode, title):
  cList, err = self.VVS1XI(mode)
  if cList and mode == self.VVCUx4:
   cList = self.VVwLhG(cList)
  if err:
   FFw5OO(self, err, title=title)
  elif cList:
   cList.sort(key=lambda x: x[0].lower())
   VVDlGi, VVaSSM, VVzgHY, VVkUYa = self.VVU1Pf(mode)
   mName = self.VVzaKN(mode)
   if   mode == self.VVymqZ  : fMode = self.VVTObo
   elif mode == self.VVJ6qH  : fMode = self.VVPA9X
   elif mode == self.VVKYG7 : fMode = self.VVhOAc
   elif mode == self.VVCUx4 : fMode = self.VVW6Tp
   if mode == self.VVCUx4:
    VVIrDY = None
    VVFadD = None
   else:
    VVIrDY = ("Find in %s" % mName , BF(self.VVLuiy, fMode, True) , [])
    VVFadD = ("Find in Selected" , BF(self.VVLuiy, fMode, False) , [])
   VVwmV1   = ("Show List"   , BF(self.VVUIsT, mode)  , [])
   VVZ224  = ("Home Menu"   , FFJgMq         , [])
   header   = None
   widths   = (100   , 0  , 0    )
   FF1Dpj(self, None, title=title, width=1200, header=header, VVarfR=cList, VVhAo0=widths, VVTFXq=30, VVZ224=VVZ224, VVIrDY=VVIrDY, VVFadD=VVFadD, VVwmV1=VVwmV1, VVDlGi=VVDlGi, VVaSSM=VVaSSM, VVzgHY=VVzgHY, VVkUYa=VVkUYa, lastFindConfigObj=CFG.lastFindIptv)
  else:
   FFw5OO(self, "No list from server !", title=title)
  FF5uKN(self)
 def VVS1XI(self, mode):
  qUrl  = self.VVskoG(mode, self.VVMcR7Data["playListURL"])
  txt, err = self.VVuaOC(qUrl)
  if err:
   return [], "Server Error:\n\n" + err
  list = []
  try:
   hideAdult = CFG.hideIptvServerAdultWords.getValue()
   tDict = jLoads(txt)
   if tDict:
    for item in tDict:
     category_id  = self.VVV2zK(item, "category_id"  )
     category_name = self.VVV2zK(item, "category_name" )
     parent_id  = self.VVV2zK(item, "parent_id"  )
     category_name = self.VV3HOG(category_name)
     if category_name:
      list.append((category_name, category_id, parent_id))
  except:
   return "", "Cannot parse received data !"
  return list, ""
 def VVwLhG(self, catList):
  mode  = self.VVW6Tp
  qUrl  = self.VVskoG(mode, self.VVMcR7Data["playListURL"])
  txt, err = self.VVuaOC(qUrl)
  chanList = []
  if err:
   return []
  chanList, err = self.VVcAc5(mode, txt)
  newCatList = []
  for cat in catList:
   for ch in chanList:
    if cat[1] == ch[2] and not cat in newCatList:
     newCatList.append(cat)
  return newCatList
 def VVUIsT(self, mode, VVxBfP, title, txt, colList):
  title = colList[1]
  FFJsIX(VVxBfP, BF(self.VVGOmq, mode, VVxBfP, title, txt, colList), title="Downloading ...")
 def VVGOmq(self, mode, VVxBfP, title, txt, colList):
  bName  = colList[0]
  catID  = colList[1]
  parentID = colList[2]
  title = self.VVzaKN(mode) + " : "+ bName
  if   mode == self.VVymqZ  : mode = self.VVTObo
  elif mode == self.VVJ6qH  : mode = self.VVPA9X
  elif mode == self.VVKYG7 : mode = self.VVhOAc
  elif mode == self.VVCUx4 : mode = self.VVW6Tp
  qUrl  = self.VVskoG(mode, self.VVMcR7Data["playListURL"], catID)
  txt, err = self.VVuaOC(qUrl)
  list  = []
  if not err and mode in (self.VVTObo, self.VVPA9X, self.VVhOAc, self.VVW6Tp):
   list, err = self.VVcAc5(mode, txt)
  if err:
   FFw5OO(self, err, title=title)
  elif list:
   VVZ224  = ("Home Menu"   , FFJgMq            , [])
   if mode in (self.VVTObo, self.VVW6Tp):
    VVDlGi, VVaSSM, VVzgHY, VVkUYa = self.VVU1Pf(mode)
    VVs5AA = (""     , BF(self.VVyszI, mode)      , [])
    VVX66G = ("Download Options" , BF(self.VVjmFH, mode, "", "")   , [])
    VVIrDY = ("Options"   , BF(self.VVOXnV, "lv", mode, bName)   , [])
    VVFadD = ("Posters Mode"  , BF(self.VVjfVG, mode, False)     , [])
    if mode == self.VVTObo:
     VVwmV1 = ("Play"    , BF(self.VVkZUb, mode)       , [])
    else:
     VVwmV1 = ("Programs"   , BF(self.VVuWwE, mode, bName) , [])
   elif mode == self.VVPA9X:
    VVDlGi, VVaSSM, VVzgHY, VVkUYa = self.VVU1Pf(mode)
    VVwmV1  = ("Play"    , BF(self.VVkZUb, mode)       , [])
    VVs5AA = (""     , BF(self.VVyszI, mode)      , [])
    VVX66G = ("Download Options" , BF(self.VVjmFH, mode, "v", "")   , [])
    VVIrDY = ("Options"   , BF(self.VVOXnV, "v", mode, bName)   , [])
    VVFadD = ("Posters Mode"  , BF(self.VVjfVG, mode, False)     , [])
   elif mode == self.VVhOAc:
    VVDlGi, VVaSSM, VVzgHY, VVkUYa = self.VVU1Pf("series2")
    VVwmV1  = ("Show Seasons"  , BF(self.VVlG8r, mode)       , [])
    VVs5AA = (""     , BF(self.VVU7uG, mode)     , [])
    VVX66G = None
    VVIrDY = None
    VVFadD = ("Posters Mode"  , BF(self.VVjfVG, mode, True)      , [])
   header, widths, VVFvCJ = self.VVCCMD(mode)
   FF1Dpj(self, None, title=title, header=header, VVarfR=list, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindIptv, VVs5AA=VVs5AA, VVDlGi=VVDlGi, VVaSSM=VVaSSM, VVzgHY=VVzgHY, VVkUYa=VVkUYa, VVUdUN=True, searchCol=1)
  else:
   FFw5OO(self, "No Channels found !", title=title)
  FF5uKN(self)
 def VVCCMD(self, mode):
  if mode in (self.VVTObo, self.VVW6Tp):
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "epgID" , "Is Adult", "Logo", "Catch-up", "Link")
   widths   = (8  , 55  , 0   , 0   , 0  , 22  , 0   , 0   , 6  , 9   , 0.03 )
   VVFvCJ  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER , CENTER, CENTER , CENTER)
  elif mode == self.VVPA9X:
   header   = ("Num" , "Name", "catID", "ID"  , "Icon" , "Added" , "isAdult" , "Ext" , "Logo")
   widths   = (8  , 62  , 0   , 0   , 0  , 24  , 0   , 0  , 6  )
   VVFvCJ  = (CENTER, LEFT  , CENTER , CENTER, LEFT , CENTER , CENTER , CENTER, CENTER)
  elif mode == self.VVhOAc:
   header   = ("Num" , "Name", "catID", "ID"  , "Genre" , "Dur.", "Ext" , "Cover" , "Logo" )
   widths   = (8  , 56  , 0   , 0   , 30  , 0  , 0  , 0   , 6   )
   VVFvCJ  = (CENTER, LEFT  , LEFT   , CENTER , LEFT , CENTER, CENTER, LEFT  , CENTER )
  return header, widths, VVFvCJ
 def VVuWwE(self, mode, bName, VVxBfP, title, txt, colList):
  chName  = colList[1]
  catId  = colList[2]
  streamId = colList[3]
  hostUrl  = self.VVMcR7Data["playListURL"]
  ok_fnc  = BF(self.VVLEk9, hostUrl, chName, catId, streamId)
  FFJsIX(VVxBfP, BF(CC9X9s.VVAIn3, self, hostUrl, chName, streamId, ok_fnc), title="Reading Program List ...")
 def VVLEk9(self, chUrl, chName, catId, streamId, VVxBfP, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC9X9s.VVxGb5(chUrl)
   chNum = "333"
   refCode = CC9X9s.VVcDWB(catId, streamId, chNum)
   chUrl = "%stimeshift/%s/%s/%s/%s/%s.ts" % (uURL, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = refCode + chUrl + ":" + chName + " >> " + pTitle
   FFkwBg(self, chUrl, VVIC8r=False)
   CCb9j4.VV6JFp(self.session)
  else:
   FFw5OO(self, "Incorrect Timestamp", pTitle)
 def VVlG8r(self, mode, VVxBfP, title, txt, colList):
  title = colList[1]
  FFJsIX(VVxBfP, BF(self.VVcWbl, mode, VVxBfP, title, txt, colList), title="Downloading ...")
 def VVcWbl(self, mode, VVxBfP, title, txt, colList):
  series_id = colList[3]
  qUrl  = self.VVskoG(self.VVFVA3, self.VVMcR7Data["playListURL"], series_id)
  txt, err = self.VVuaOC(qUrl)
  list  = []
  if not err:
   list = []
   err  = ""
   try:
    tDict = jLoads(txt)
    if tDict:
     title  = "Seasons"
     category_id = "222"
     icon  = ""
     if "info" in tDict:
      title  = self.VVV2zK(tDict["info"], "name"   )
      category_id = self.VVV2zK(tDict["info"], "category_id" )
      icon  = self.VVV2zK(tDict["info"], "cover"   )
     if "episodes" in tDict:
      seasons = tDict["episodes"]
      for season in seasons:
       item = seasons[season]
       for EP in item:
        stream_id   = self.VVV2zK(EP, "id"     )
        episode_num   = self.VVV2zK(EP, "episode_num"   )
        epTitle    = self.VVV2zK(EP, "title"     )
        container_extension = self.VVV2zK(EP, "container_extension" )
        seasonNum   = self.VVV2zK(EP, "season"    )
        epTitle = self.VVbGFt(epTitle)
        list.append((seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension))
   except:
    err = "Cannot parse received data !"
  if err:
   FFw5OO(self, err, title=title)
  elif list:
   VVZ224 = ("Home Menu"   , FFJgMq          , [])
   VVX66G = ("Download Options" , BF(self.VVjmFH, mode, "s", title), [])
   VVIrDY = ("Options"   , BF(self.VVOXnV, "s", mode, title) , [])
   VVFadD = ("Posters Mode"  , BF(self.VVjfVG, mode, False)   , [])
   VVs5AA = (""     , BF(self.VVyszI, mode)    , [])
   VVwmV1  = ("Play"    , BF(self.VVkZUb, mode)     , [])
   header   = ("Season" , "Episode" , "Title" , "catID" , "stID", "Icon", "Ext" )
   widths   = (10  , 10  , 80  , 0   , 0  , 0  , 0  )
   VVFvCJ  = (CENTER , CENTER , LEFT  , CENTER , CENTER, LEFT , CENTER)
   FF1Dpj(self, None, title=title, header=header, VVarfR=list, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVZ224=VVZ224, VVX66G=VVX66G, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VVIrDY=VVIrDY, VVFadD=VVFadD, lastFindConfigObj=CFG.lastFindIptv, VVDlGi="#0a00292B", VVaSSM="#0a002126", VVzgHY="#0a002126", VVkUYa="#00000000")
  else:
   FFw5OO(self, "No Channels found !", title=title)
  FF5uKN(self)
 def VVLuiy(self, mode, isAll, VVxBfP, title, txt, colList):
  onlyCatID = None if isAll else colList[1]
  VVZJ87 = []
  VVZJ87.append(("Keyboard"  , "manualEntry"))
  VVZJ87.append(("From Filter" , "fromFilter"))
  FFYySC(self, BF(self.VVatqn, VVxBfP, mode, onlyCatID), title="Input Type", VVZJ87=VVZJ87, width=400)
 def VVatqn(self, VVxBfP, mode, onlyCatID, item=None):
  if item is not None:
   if   item == "manualEntry":
    FFaSvq(self, BF(self.VVTg8O, VVxBfP, mode, onlyCatID), defaultText=CFG.lastFindIptv.getValue(), title="Find", message="Enter Name (or names separated by a comma)")
   elif item == "fromFilter":
    filterObj = CCdUgX(self)
    filterObj.VV4D6G(BF(self.VVTg8O, VVxBfP, mode, onlyCatID))
 def VVTg8O(self, VVxBfP, mode, onlyCatID, item):
  if not item is None:
   title = "Find in names"
   words = None
   toFind = item.strip()
   FFdEZ4(CFG.lastFindIptv, toFind)
   if toFind:
    words, asPrefix = CCdUgX.VV0Xfy(toFind)
    if words:
     if len(words) == 1 and len(words[0]) < 3:
      FFw5OO(self, "Enter at least 3 characters.", title=title)
      return
     else:
      for word in words:
       if len(word) < 3:
        FFw5OO(self, "All words must be at least 3 characters !", title=title)
        return
     if CFG.hideIptvServerAdultWords.getValue() and self.VVEvvi(words):
      FFw5OO(self, self.VVVfjQ(), title="Find: %s" % " , ".join(words))
      return
     else:
      self.session.open(CCmNws, barTheme=CCmNws.VVkie3
          , titlePrefix = "Searching for:%s" % toFind[:15]
          , fncToRun  = BF(self.VVvYnJ, VVxBfP, mode, onlyCatID, title, words, toFind, asPrefix)
          , VVCeou = BF(self.VVohFR, mode, toFind, title))
   if not words:
    FF5uKN(VVxBfP, "Nothing to find !", 1500)
 def VVvYnJ(self, VVxBfP, mode, onlyCatID, title, words, toFind, asPrefix, VVXLiB):
  VVXLiB.VVCnyB(VVxBfP.VVWnGz() if onlyCatID is None else 1)
  VVXLiB.VVlaij = []
  for row in VVxBfP.VVlHja():
   catName = row[0]
   catID = row[1]
   if not onlyCatID is None and not catID == onlyCatID:
    continue
   if not VVXLiB or VVXLiB.isCancelled:
    return
   VVXLiB.VV1Vtn(1)
   VVXLiB.VVezfw(catName)
   qUrl  = self.VVskoG(mode, self.VVMcR7Data["playListURL"], catID)
   txt, err = self.VVuaOC(qUrl)
   if not err:
    tList, err = self.VVcAc5(mode, txt)
    if tList:
     for item in tList:
      name = item[1].strip().lower()
      name = self.VVbGFt(name)
      if name:
       if asPrefix and not name.startswith(words) : continue
       elif any(x in name for x in words)   : pass
       else          : continue
       if not VVXLiB or VVXLiB.isCancelled:
        return
       VVXLiB.VVlaij.append(item)
       VVXLiB.VVezfw(catName)
 def VVohFR(self, mode, toFind, title, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  if VVlaij:
   title = self.VVfC9z(mode, toFind)
   if mode == self.VVTObo or mode == self.VVPA9X:
    if mode == self.VVPA9X : typ = "v"
    else          : typ = ""
    bName   = CC9X9s.VVRoT5(toFind)
    VVwmV1  = ("Play"     , BF(self.VVkZUb, mode)     , [])
    VVX66G = ("Download Options" , BF(self.VVjmFH, mode, typ, "") , [])
    VVIrDY = ("Options"   , BF(self.VVOXnV, "fnd", mode, bName), [])
    VVFadD = ("Posters Mode"  , BF(self.VVjfVG, mode, False)   , [])
    VVs5AA = (""     , BF(self.VVyszI, mode)    , [])
   elif mode == self.VVhOAc:
    VVwmV1  = ("Show Seasons"  , BF(self.VVlG8r, mode)     , [])
    VVIrDY = None
    VVX66G = None
    VVFadD = ("Posters Mode"  , BF(self.VVjfVG, mode, True)    , [])
    VVs5AA = (""     , BF(self.VVU7uG, mode)   , [])
   VVZ224  = ("Home Menu"   , FFJgMq          , [])
   header, widths, VVFvCJ = self.VVCCMD(mode)
   VVxBfP = FF1Dpj(self, None, title=title, header=header, VVarfR=VVlaij, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, VVs5AA=VVs5AA, VVDlGi="#0a00292B", VVaSSM="#0a002126", VVzgHY="#0a002126", VVkUYa="#00000000", VVUdUN=True, searchCol=1)
   if not VVeObj:
    FF5uKN(VVxBfP, "Stopped" , 1000)
  else:
   if VVeObj:
    FFw5OO(self, "Not found in names !\n\n( %s )" % toFind, title=title)
 def VVAlWq(self, mode, colList):
  colList = list(map(str.strip, colList))
  if mode in (self.VVTObo, self.VVW6Tp):
   num, name, category_id, stream_id, stream_icon, added, epg_channel_id, is_adult, hasPicon, catchupTxt, direct_source = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "", ""
  elif mode == self.VVPA9X:
   num, name, category_id, stream_id, stream_icon, added, is_adult, container_extension, isPicon = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = num, name, category_id, stream_id, stream_icon, "." + container_extension, "movie/"
  else:
   seasonNum, episode_num, epTitle, category_id, stream_id, icon, container_extension = colList
   chNum, chName, catID, stID, picUrl, ext, uCat = "222", epTitle, category_id, stream_id, icon, "." + container_extension, "series/"
  chName = FFxmTk(chName)
  url = self.VVMcR7Data["playListURL"]
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = self.VVxGb5(url)
  refCode = self.VVcDWB(catID, stID, chNum)
  chUrl = "%s%s%s/%s/%s%s"  % (uURL, uCat, uUser, uPass, stID, ext)
  chUrl = chUrl.replace(":", "%3a")
  chUrl = refCode + chUrl + ":" + chName
  return chName, chUrl, picUrl, refCode
 def VVyszI(self, mode, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VVKuZI, mode, VVxBfP, title, txt, colList))
 def VVKuZI(self, mode, VVxBfP, title, txt, colList):
  chName, chUrl, picUrl, refCode = self.VVAlWq(mode, colList)
  txt = "%s\n\n%s" % (title, txt)
  FFcpNw(self, fncMode=CCjQ0P.VVufbi, refCode=refCode, chName=chName, text=txt, chUrl=chUrl, picUrl=picUrl)
 def VVU7uG(self, mode, VVxBfP, title, txt, colList):
  FFJsIX(VVxBfP, BF(self.VVTC8b, mode, VVxBfP, title, txt, colList))
 def VVTC8b(self, mode, VVxBfP, title, txt, colList):
  name = colList[1]
  Dur  = colList[5]
  Cover = colList[7]
  txt  = "%s\n\n%s" % (title, txt)
  txt  += "Duration\t: %s" % Dur
  FFcpNw(self, fncMode=CCjQ0P.VVzinH, chName=name, text=txt, picUrl=Cover)
 def VVjfVG(self, mode, isSerNames, VVxBfP, title, txt, colList):
  if   mode in ("itv"  , CC9X9s.VVTObo, CC9X9s.VVW6Tp): category = "live"
  elif mode in ("vod"  , CC9X9s.VVPA9X )          : category = "vod"
  elif mode in ("series" , CC9X9s.VVhOAc)          : category = "series"
  elif mode == "m3u"                      : category = "m3u"
  if mode == "m3u":
   nameCol, picCol, descCol, descTxt = 1, 4, 2, "Group"
  elif mode in ("itv", "vod", "series"):
   if isSerNames: nameCol, picCol, descCol, descTxt = 0, 12, 9, "Genre"
   else   : nameCol, picCol, descCol, descTxt = 1, 4 , 6, "Category/Genre"
  else:
   nameCol = 1
   if isSerNames         : picCol, descCol, descTxt = 7, 4, "Genre"
   elif mode == self.VVTObo : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVW6Tp : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVPA9X  : picCol, descCol, descTxt = 4, 5, "Added"
   elif mode == self.VVhOAc : picCol, descCol, descTxt = 5, 0, "Season"
  FFJsIX(VVxBfP, BF(self.session.open, CCDFOS, VVxBfP, category, nameCol, picCol, descCol, descTxt))
 def VVjmFH(self, mode, typ, seriesName, VVxBfP, title, txt, colList):
  VVZJ87 = []
  isMulti = VVxBfP.VVQW9r
  tot  = VVxBfP.VVsyP1()
  if isMulti:
   if tot < 1:
    FF5uKN(VVxBfP, "Select rows first.", 1000)
    return
   else:
    name = "%d Selected" % tot
  else:
   name = "ALL"
  VVZJ87.append(("Download %s PIcon%s" % (name, FF1I1d(tot)), "dnldPicons" ))
  if typ:
   VVZJ87.append(VVoqHH)
   tName = "Movie" if typ.startswith("v") else "Series"
   VVZJ87.append(("Download Current %s" % tName    , "dnldSel"  ))
   VVZJ87.append(("Add Current %s to Download List" % tName , "addSel"  ))
   if typ.startswith("s"):
    VVZJ87.append(("Add All Episodes to Download List" , "addAllEp" ))
   if not CCrhIe.VVyUPR():
    VVZJ87.append(VVoqHH)
    VVZJ87.append(("Download Manager"      , "dload_stat" ))
  FFYySC(self, BF(self.VVcyhf, VVxBfP, mode, typ, seriesName, colList), title="Download Options", VVZJ87=VVZJ87)
 def VVcyhf(self, VVxBfP, mode, typ, seriesName, colList, item=None):
  if item:
   if   item == "dnldPicons" : self.VVii94(VVxBfP, mode)
   elif item == "dnldSel"  : self.VVFkQu(VVxBfP, mode, typ, colList, True)
   elif item == "addSel"  : self.VVFkQu(VVxBfP, mode, typ, colList, False)
   elif item == "addAllEp"  : self.VVfFyT(VVxBfP, mode, typ, seriesName)
   elif item == "dload_stat" : CCrhIe.VVFNli(self, VVxBfP)
 def VVFkQu(self, VVxBfP, mode, typ, colList, startDnld):
  chName, decodedUrl = self.VVQRun(mode, typ, colList)
  if startDnld:
   CCrhIe.VVoAzB(self, decodedUrl)
  else:
   self.VVrZot(VVxBfP, "Add to Download list", chName, [decodedUrl], startDnld)
 def VVfFyT(self, VVxBfP, mode, typ, seriesName):
  decodedUrl_list = []
  for row in VVxBfP.VVlHja():
   chName, decodedUrl = self.VVQRun(mode, typ, row)
   decodedUrl_list.append(decodedUrl)
  self.VVrZot(VVxBfP, "Add to Download list", "%s\n\n( %d Episodes )" % (seriesName, len(decodedUrl_list)), decodedUrl_list, False)
 def VVrZot(self, VVxBfP, title, chName, decodedUrl_list, startDnld):
  FFNKVM(self, BF(self.VV44Ek, VVxBfP, decodedUrl_list, startDnld), chName, title=title)
 def VV44Ek(self, VVxBfP, decodedUrl_list, startDnld):
  added, skipped = CCrhIe.VVgpip(decodedUrl_list)
  FF5uKN(VVxBfP, "Added", 1000)
 def VVQRun(self, mode, typ, colList):
  if typ in ("v", "s"):
   chName, chUrl, picUrl, refCode = self.VVAlWq(mode, colList)
  elif typ in ("vp", "sp"):
   chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVPMtD(mode, colList)
   refCode, chUrl = self.VVJNpF(self.VV4Xnp, self.VVktxB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
  refCode, decodedUrl, origUrl, iptvRef = FFzRjC(chUrl)
  return chName, decodedUrl
 def VVii94(self, VVxBfP, mode):
  if FFhcfU("ffmpeg"):
   self.session.open(CCmNws, barTheme=CCmNws.VV3z22
       , titlePrefix = "Downloading PIcons"
       , fncToRun  = BF(self.VVH9of, VVxBfP, mode)
       , VVCeou = self.VV4dlx)
  else:
   FFNKVM(self, BF(CC9X9s.VVHlli, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title="Download all PIcons")
 def VV4dlx(self, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  txt  = ""
  txt += "Total Processed\t\t: %d of %d\n" % (VVlaij["proces"], VVlaij["total"])
  txt += "Download Success\t: %d of %s\n"  % (VVlaij["ok"], VVlaij["attempt"])
  txt += "Skipped (PIcon exist)\t: %d\n"  % VVlaij["exist"]
  txt += "Skipped (Size = 0)\t: %d\n"   % VVlaij["size0"]
  txt += "Incorrect PIcon URL\t: %d\n"  % VVlaij["badURL"]
  txt += "Download Failure\t: %d\n"   % VVlaij["fail"]
  txt += "PIcons Path\t\t: %s\n"    % VVlaij["path"]
  if not VVeObj  : color = "#11402000"
  elif VVlaij["err"]: color = "#11201000"
  else     : color = "#22001122"
  if VVlaij["err"]:
   txt = "Critical Error\t\t: %s\n\n%s"  % (VVlaij["err"], txt)
  title = "PIcons Download Result"
  if not VVeObj:
   title += "  (cancelled)"
  FF90Bc(self, txt, title=title, VVzgHY=color)
 def VVH9of(self, VVxBfP, mode, VVXLiB):
  isMulti = VVxBfP.VVQW9r
  if isMulti : totRows = VVxBfP.VVsyP1()
  else  : totRows = VVxBfP.VVWnGz()
  VVXLiB.VVCnyB(totRows)
  VVXLiB.VV3u9K(0)
  counter     = VVXLiB.counter
  maxValue    = VVXLiB.maxValue
  pPath     = CCijoe.VV4boJ()
  VVXLiB.VVlaij = {   "total" : totRows
         , "proces" : 0
         , "attempt" : 0
         , "fail" : 0
         , "ok"  : 0
         , "size0" : 0
         , "exist" : 0
         , "badURL" : 0
         , "path" : pPath
         , "err"  : "" }
  try:
   for rowNum, row in enumerate(VVxBfP.VVlHja()):
    if VVXLiB.isCancelled:
     break
    if not isMulti or VVxBfP.VVE8c8(rowNum):
     VVXLiB.VVlaij["proces"] += 1
     VVXLiB.VV1Vtn(1)
     if mode in ("itv", "vod", "series"):
      chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVPMtD(mode, row)
      refCode = CC9X9s.VVcDWB(catID, stID, chNum)
     elif mode == "m3u/m3u8":
      chName = row[1].strip()
      url  = row[3].strip()
      picUrl = row[4].strip()
      refCode = self.VVq9yy(rowNum, url, chName)
     else:
      chName, chUrl, picUrl, refCode = self.VVAlWq(mode, row)
     if picUrl:
      picon = refCode.replace(":", "_").rstrip("_") + ".png"
      if not fileExists(pPath + picon):
       VVXLiB.VVlaij["attempt"] += 1
       path, err = FFtKyC(picUrl, picon, timeout=1, mustBeImage=True)
       if path:
        if VVXLiB:
         VVXLiB.VVlaij["ok"] += 1
         VVXLiB.VV3u9K(VVXLiB.VVlaij["ok"])
        if FFqLWj(path) > 0:
         cmd = CCjQ0P.VV92Yh(path)
         cmd += FFIV1X("mv -f '%s' '%s'" % (path, pPath)) + ";"
         FFuB0V(cmd)
        else:
         if VVXLiB:
          VVXLiB.VVlaij["size0"] += 1
         FFzyFM(path)
       elif err:
        if VVXLiB:
         VVXLiB.VVlaij["fail"] += 1
        if any(x in err.lower() for x in ("time-out", "unauthorized")):
         if VVXLiB:
          VVXLiB.VVlaij["err"] = err.title()
         break
      else:
       if VVXLiB:
        VVXLiB.VVlaij["exist"] += 1
     else:
      if VVXLiB:
       VVXLiB.VVlaij["badURL"] += 1
  except:
   pass
 def VVUCe8(self):
  title = "Download PIcons for Current Bouquet"
  if FFhcfU("ffmpeg"):
   self.session.open(CCmNws, barTheme=CCmNws.VV3z22
       , titlePrefix = ""
       , fncToRun  = self.VVSVYL
       , VVCeou = BF(self.VVdu4R, title))
  else:
   FFNKVM(self, BF(CC9X9s.VVHlli, self), '"FFmpeg" is required to resize the PIcons.\n\nInstall FFmpeg ?', title=title)
 def VVSVYL(self, VVXLiB):
  bName = CCSrvY.VVqbQQ()
  pPath = CCijoe.VV4boJ()
  totNotIptv = totServErr = totParseErr = totUnauth = totCh = totIptv = totPic = totPicOK = totInvServ = totInvPicUrl = totSize0 = totExist = 0
  VVXLiB.VVlaij = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
  services = CCSrvY.VVQ4Kz()
  if not VVXLiB or VVXLiB.isCancelled:
   return
  if not services or len(services) == 0:
   VVXLiB.VVlaij = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   return
  totCh = len(services)
  VVXLiB.VVCnyB(totCh)
  VVXLiB.VV3u9K(0)
  for serv in services:
   if not VVXLiB or VVXLiB.isCancelled:
    return
   VVXLiB.VVlaij = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
   VVXLiB.VV1Vtn(1)
   VVXLiB.VV3u9K(totPic)
   fullRef  = serv[0]
   if FF4Jai(fullRef):
    totIptv += 1
   else:
    totNotIptv += 1
    continue
   refCode, decodedUrl, origUrl, iptvRef = FFzRjC(fullRef)
   picon = refCode.replace(":", "_").rstrip("_") + ".png"
   if fileExists(pPath + picon):
    totExist += 1
    continue
   span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
   if span:
    valid, ph1, playHost, mode, host, mac, epNum, epId, chCm, catID, stID, query, m3u_Url, host1, user1, pass1, streamId, err = CCsdD3.VVN5jb(decodedUrl)
    uHost, uUser, uPass, uId, uChName = host, user1, pass1, streamId, span.group(1)
   else:
    m3u_Url = decodedUrl
    uType, uHost, uUser, uPass, uId, uChName = CC9X9s.VVXxn6(m3u_Url)
   if not all([uHost, uUser, uPass, uId]):
    totInvServ += 1
    continue
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC9X9s.VVuaOC(qUrl)
   if err:
    totServErr += 1
    if "Unauth" in err:
     totUnauth += 1
    continue
   try:
    epg, picUrl = CCjQ0P.VVRvxH(jLoads(txt))
   except:
    totParseErr += 1
    continue
   if not picUrl:
    totInvPicUrl += 1
    continue
   totPic += 1
   path, err = FFtKyC(picUrl, picon, timeout=1, mustBeImage=True)
   if path:
    if VVXLiB:
     VVXLiB.VV3u9K(totPic)
    if FFqLWj(path) > 0:
     cmd = CCjQ0P.VV92Yh(path)
     cmd += FFIV1X("mv -f '%s' '%s'" % (path, pPath)) + ";"
     FFuB0V(cmd)
     totPicOK += 1
    else:
     totSize0
     FFzyFM(path)
  if VVXLiB:
   VVXLiB.VVlaij = (bName, "", totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist)
 def VVdu4R(self, title, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totParseErr, totUnauth, totCh, totIptv, totPic, totPicOK, totInvServ, totInvPicUrl, totSize0, totExist = VVlaij
  if err:
   FFw5OO(self, err, title=title)
  else:
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "\n"
   txt += "PIcons Found\t: %d\n" % totPic
   txt += "PIcons Added\t: %d\n" % totPicOK
   if totUnauth or totExist or totNotIptv or totServErr or totParseErr or totInvServ or totInvPicUrl or totSize0:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totExist  : txt += "PIcons Exist\t: %s\n"  % FFGB9z(str(totExist)  , VVsObI)
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFGB9z(str(totNotIptv)  , VVsObI)
    if totServErr : txt += "Server Errors\t: %s\n" % FFGB9z(str(totServErr) + t1, VVsObI)
    if totParseErr : txt += "Parse Errors\t: %s\n"  % FFGB9z(str(totParseErr) , VVsObI)
    if totInvServ : txt += "Invalid Ser. URL\t: %s\n" % FFGB9z(str(totInvServ)  , VVsObI)
    if totInvPicUrl : txt += "Invalid Pic. URL\t: %s\n" % FFGB9z(str(totInvPicUrl) , VVsObI)
    if totSize0  : txt += "PIcons Size = 0\t: %s\n" % FFGB9z(str(totSize0)  , VVsObI)
   if not VVeObj:
    title += "  (stopped)"
   FF90Bc(self, txt, title=title)
 @staticmethod
 def VVHlli(SELF):
  cmd = FFETOG(VV33Lu, "ffmpeg")
  if cmd : FF1Q61(SELF, cmd, title="Installing FFmpeg")
  else : FFgq4o(SELF)
 @staticmethod
 def VVCBtN(SELF):
  SELF.session.open(CCmNws, barTheme=CCmNws.VV3z22
      , titlePrefix = ""
      , fncToRun  = CC9X9s.VVMzv1
      , VVCeou = BF(CC9X9s.VVvsm7, SELF))
 @staticmethod
 def VVMzv1(VVXLiB):
  bName = CCSrvY.VVqbQQ()
  uChName = ""
  totNotIptv = totServErr = totUnauth = totCh = totIptv = totEpg = totEpgOK = totInv = 0
  VVXLiB.VVlaij = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  services = CCSrvY.VVQ4Kz()
  if not VVXLiB or VVXLiB.isCancelled:
   return
  if services and len(services) > 0:
   totCh = len(services)
   VVXLiB.VVCnyB(totCh)
   for serv in services:
    if not VVXLiB or VVXLiB.isCancelled:
     return
    VVXLiB.VV1Vtn(1)
    fullRef = serv[0]
    if FF4Jai(fullRef):
     totIptv += 1
     refCode, decodedUrl, origUrl, iptvRef = FFzRjC(fullRef)
     span = iSearch(r"mode=.+&end=:(.+)", fullRef, IGNORECASE)
     pList, err = [], ""
     if span:
      pList, err = CCsdD3.VVNA3Q(decodedUrl, retLst=True)
     else:
      uType, uHost, uUser, uPass, uId, uChName = CC9X9s.VVXxn6(decodedUrl)
      if all([uHost, uUser, uPass, uId]):
       url = "%s/get.php?username=%s&password=%s" % (uHost, uUser, uPass)
       pList, err = CC9X9s.VVi78m(url, uId)
      else:
       totInv += 1
     if err:
      totServErr += 1
      if "Unauth" in err:
       totUnauth += 1
     if VVXLiB:
      VVXLiB.VVYpSy(totEpgOK, uChName)
     if pList:
      totEv, totOK = CCvWMS.VV2PtB(refCode, pList)
      totEpg += totEv
      totEpgOK += totOK
    else:
     totNotIptv += 1
    if VVXLiB:
     VVXLiB.VVlaij = (bName, "", totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
  else:
   VVXLiB.VVlaij = (bName, 'Invalid Services in Bouquet: \n\n"%s"' % bName, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv)
 @staticmethod
 def VVvsm7(SELF, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  bName, err, totNotIptv, totServErr, totUnauth, totCh, totIptv, totEpg, totEpgOK, totInv = VVlaij
  title = "IPTV EPG Import"
  if err:
   FFw5OO(SELF, err, title=title)
  else:
   if VVeObj and totEpgOK > 0:
    CCvWMS.VVUXih()
   txt = ""
   txt += "Bouquet\t: %s\n"  % bName
   txt += "Services\t: %d\n\n"  % totCh
   txt += "Processed\t: %d\n"  % totIptv
   txt += "Events Found\t: %d\n" % totEpg
   txt += "Events Added\t: %d\n" % totEpgOK
   if totNotIptv or totInv or totServErr or totUnauth:
    txt += "\n"
    t1 = ""
    if totUnauth:
     if totUnauth == totServErr : t1 = "  (All Unauthorized)"
     else      : t1 = "  (%d Unauthorized)" % totUnauth
    if totNotIptv : txt += "Not IPTV\t: %s\n"   % FFGB9z(str(totNotIptv), VVsObI)
    if totServErr : txt += "Server Errors\t: %s\n" % FFGB9z(str(totServErr) + t1, VVsObI)
    if totInv  : txt += "Invalid URL\t: %s\n"  % FFGB9z(str(totInv), VVsObI)
   if not VVeObj:
    title += "  (stopped)"
   FF90Bc(SELF, txt, title=title)
 @staticmethod
 def VVi78m(chUrl, streamId, isForCatchupTV=False):
  modified, uURL, uProtoc, uHost, uPort, uQuery, uUser, uPass, uQueryParam = CC9X9s.VVxGb5(chUrl)
  qUrl = "%splayer_api.php?username=%s&password=%s&action=get_simple_data_table&stream_id=%s" % (uURL, uUser, uPass, streamId)
  txt, err = CC9X9s.VVuaOC(qUrl)
  if err:
   return "", err
  pList = []
  try:
   tDict = jLoads(txt)
   for item in tDict["epg_listings"]:
    description   = CC9X9s.VVV2zK(item, "description" , is_base64=True ).replace("\n", " .. ")
    lang    = CC9X9s.VVV2zK(item, "lang"        ).upper()
    now_playing   = CC9X9s.VVV2zK(item, "now_playing"      )
    start    = CC9X9s.VVV2zK(item, "start"        )
    start_timestamp  = CC9X9s.VVV2zK(item, "start_timestamp", isDate=True  )
    start_timestamp_unix= CC9X9s.VVV2zK(item, "start_timestamp"     )
    stop_timestamp  = CC9X9s.VVV2zK(item, "stop_timestamp" , isDate=True  )
    stop_timestamp_unix = CC9X9s.VVV2zK(item, "stop_timestamp"      )
    tTitle    = CC9X9s.VVV2zK(item, "title"   , is_base64=True )
    if isForCatchupTV:
     try:
      if int(start_timestamp_unix) < iTime():
       dur = str(int((int(stop_timestamp_unix) - int(start_timestamp_unix)) / 60))
       pList.append((start_timestamp[:-3], stop_timestamp[:-3], lang, tTitle, description, start, now_playing, dur))
     except:
      pass
    else:
     try:
      if int(stop_timestamp_unix) > iTime():
       start  = int(start_timestamp_unix)
       dur   = int(int(stop_timestamp_unix) - int(start_timestamp_unix))
       shortDesc = ("Language : %s" % lang) if lang else ""
       pList.append((start, dur, tTitle, shortDesc, description, 1))
     except:
      pass
  except:
   return "", "Cannot parse received data !"
  return pList, ""
 @staticmethod
 def VVcDWB(catID, stID, chNum):
  MAX_4b = 65535
  MAX_8b = 4294967295
  SID  = CC9X9s.VVAssW(catID, MAX_4b)
  TSID = CC9X9s.VVAssW(chNum, MAX_4b)
  ONID = CC9X9s.VVAssW(chNum, MAX_4b)
  NS  = CC9X9s.VVAssW(stID, MAX_8b)
  if len(NS) == 4:
   NS = "1" + NS
  rType = CFG.iptvAddToBouquetRefType.getValue()
  return "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, TSID, ONID, NS)
 @staticmethod
 def VVAssW(numStr, limit):
  if numStr.isdigit():
   i = int(numStr)
   if i > limit:
    i = limit
   return (hex(i))[2:].upper()
  else:
   return "222"
 @staticmethod
 def VVRoT5(txt):
  txt = iSub(iCompile('\W'), "_", txt)
  while "__" in txt:
   txt = txt.replace("__", "_")
  txt = txt.strip("_")
  if txt : return txt
  else : return "Bouquet"
 @staticmethod
 def VVU1Pf(mode):
  if   mode in ("itv"  , CC9X9s.VVymqZ)  : return "#0a21303C", "#0a21303C", "#0a21303C", "#04224040"
  elif mode in ("vod"  , CC9X9s.VVJ6qH)  : return "#1a260518", "#1a260518", "#1a260518", "#04224040"
  elif mode in ("series" , CC9X9s.VVKYG7) : return "#1a36013F", "#1a26012F", "#1a26012F", "#04224040"
  elif mode in ("catchup" , CC9X9s.VVCUx4) : return "#0a213044", "#0a213044", "#0a21303C", "#04224040"
  elif mode == CC9X9s.VVW6Tp    : return "#0a202020", "#0a202020", "#0a202020", "#04224040"
  elif mode == "series2"            : return "#0a462538", "#0a462538", "#0a462538", "#04224040"
  else                : return "#0a00292B", "#0a002126", "#0a002126", "#00000000"
 def VV0R5t(self, mode):
  err = excl = ""
  dirs = []
  path = "/"
  if CFG.iptvHostsMode.getValue() == VVqj4V:
   excl = FFEZzf(1)
  else:
   lst = list(set(list(map(str.strip, CFG.iptvHostsDirs.getValue().split(",")))))
   tList = []
   for Dir in lst:
    if pathExists(Dir):
     tList.append(Dir)
   lst = sorted(tList, key=len)
   for Dir in lst:
    for dir1 in dirs:
     if len(Dir) > len(dir1) and Dir.startswith(dir1):
      break
    else:
     dirs.append(Dir)
   if   len(dirs) == 1 : path = dirs[0]
   elif len(dirs) > 1 : path = "{%s}" % ",".join(dirs)
   if not dirs:
    FFw5OO(self, 'Directory not found !\n\nCheck your settings option:\n\n"IPTV Hosts Files Path (Playlist, Portal, M3U)"')
    return []
  if   mode == 1: par = '-iname "*playlist*" | grep -i ".txt"'
  elif mode == 2: par = '\( -iname "*portal*" -o -iname "*stalker*" \) | grep -i "\.txt\|\.conf"'
  elif mode == 3: par = "-iname '*.m3u' -o -iname '*.m3u8' | grep -i '.m3u*'"
  files = FFnAC3('find %s %s %s' % (path, excl, par))
  if files:
   err = CCCXvS.VVgw5W(files)
   if err : FFw5OO(self, err + FFGB9z('\n\n( Change "IPTV Hosts Files Path" to "Custom" and try again )', VVUVAI))
   else : return files
  else:
   if   path == "/": txt = "!"
   elif dirs  : txt = "in directories listed in settings !"
   else   : txt = "in :\n%s" % path
   if   mode == 1: err = 'No Playlist files found %s\n\n Expecting ".txt" files\n(names must include the word "playlist")' % txt
   elif mode == 2: err = 'No portal files found %s\n\n Expecting ".txt" or ".conf" files\n(name must include the word "portal" or "stalker")' % txt
   elif mode == 3: err = 'No ".m3u" files found %s' % txt
   FFw5OO(self, err)
  return []
 @staticmethod
 def VVU5JK():
  for path in (CFG.backupPath.getValue(), CFG.exportedTablesPath.getValue(), "/tmp/"):
   if pathExists(path):
    return FF1vNj(path)
  return "/"
 @staticmethod
 def VVAIn3(SELF, hostUrl, chName, streamId, ok_fnc):
  pList, err = CC9X9s.VVi78m(hostUrl, streamId, True)
  title = "Catch-up TV Programs"
  if err:
   FFw5OO(SELF, "Server Error:\n\n%s" % err, title=title)
  elif pList:
   pList.sort(key=lambda x: x[0], reverse=True)
   c = "#f#00FFFF55#"
   for ndx, item in enumerate(pList):
    if item[6] == "1":
     pList[ndx] = (c + item[0], c + item[1], c + item[2], c + item[3], c + item[4], c + item[5], c + item[6], c + item[7])
     break
   VVDlGi, VVaSSM, VVzgHY, VVkUYa = CC9X9s.VVU1Pf("")
   VVZ224 = ("Home Menu" , FFJgMq, [])
   VVwmV1  = ("Play"  , ok_fnc , [])
   header   = ("Start" , "End" , "Lang", "Title" , "Description" , "sTime" , "Playing" , "Duration")
   widths   = (17  , 17 , 6  , 31  , 31   , 0   , 0   , 0   )
   VVFvCJ  = (CENTER , CENTER, CENTER, LEFT  , LEFT   , CENTER , CENTER , CENTER )
   FF1Dpj(SELF, None, title="Programs for : " + chName, header=header, VVarfR=pList, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=24, VVwmV1=VVwmV1, VVZ224=VVZ224, VVDlGi=VVDlGi, VVaSSM=VVaSSM, VVzgHY=VVzgHY, VVkUYa=VVkUYa)
  else:
   FFw5OO(SELF, "No Programs from server", title=title)
 @staticmethod
 def VVr5Ek(rUrl, fPath):
  fPath = fPath.strip()
  if fPath.startswith("http://"):
   return fPath
  elif fPath.startswith("/"):
   try:
    res = iUrlparse(rUrl)
    scheme = res.scheme
    netloc = res.netloc
    if scheme and netloc:
     host = "%s://%s" % (scheme, netloc)
     return os.path.join(host, fPath.lstrip("/"))
   except:
    pass
   return ""
  else:
   baseUrl = os.path.dirname(rUrl).strip()
   fName = os.path.basename(rUrl).strip()
   return os.path.join(baseUrl, fPath)
 def VViT6z(self, isPortal, line, VVbBRSObj, item):
  title = "Add server to IPTV Menu (for easy access)"
  if isPortal : txt, confItem = "Portal" , CFG.favServerPortal
  else  : txt, confItem = "Playlist", CFG.favServerPlaylist
  if confItem.getValue().strip() == line.strip():
   FFNKVM(self, BF(self.VV5qdf, title, confItem), "Already in IPTV Menu !\n\nRemove ?", title=title)
  else:
   FFdEZ4(confItem, line)
   FF15cM(self, 'Added to IPTV Menu.\n\nWill be shown as "Favourite %s Server"' % txt, title=title)
 def VV5qdf(self, title, confItem):
  FFdEZ4(confItem, "")
  FF15cM(self, "Removed from IPTV Menu.", title=title)
 def VViJ8B(self, isPortal):
  if isPortal:
   span = iSearch(r"(.+)\s((?:[A-Fa-f0-9]+:){5}.+[A-Fa-f0-9]+)", CFG.favServerPortal.getValue(), IGNORECASE)
   if span:
    self.VV7fmP(self, span.group(1), span.group(2))
    return
  else:
   span = iSearch(r"(http.+\/\/.+\/.+username=.+&password=\w+)", CFG.favServerPlaylist.getValue(), IGNORECASE)
   if span:
    FFJsIX(self, BF(self.VVcKAy, "Favourite Playlist Server", span.group(1)), title="Checking Server ...")
    return
  FFw5OO(self, "Incorrect server data !")
 @staticmethod
 def VVU5D0(SELF, isPortal, line, VVbBRSObj, item):
  myPath = "/media/usb/AAA/IPTV-Files/"
  if pathExists(myPath) : path = myPath
  else     : path = CC9X9s.VVU5JK()
  if isPortal : path += "Portal_Bookmarks.txt"
  else  : path += "Playlist_Bookmarks.txt"
  title = "Bookmark Current Server"
  try:
   if fileExists(path):
    with ioOpen(path, "r", encoding="utf-8") as f:
     for fLine in f:
      if str(line) in str(fLine):
       FFw5OO(SELF, "Already added to file:\n\n%s" % path, title=title)
       return
   with open(path, "a") as f:
    f.write(line + "\n")
   FF15cM(SELF, "Added to file:\n\n%s" % path, title=title)
  except Exception as e:
   FFw5OO(SELF, "Error:\n\n%s" % str(e), title=title)
 def VVOXnV(self, source, mode, curBName, VVxBfP, title, txt, colList):
  isMulti = VVxBfP.VVQW9r
  itemsOK = True
  totTxt = "ALL"
  if isMulti:
   tot = VVxBfP.VVsyP1()
   totTxt = "%d Service%s" % (tot, FF1I1d(tot))
   if tot < 1:
    itemsOK = False
  totTxt = FFGB9z(totTxt, VVUVAI)
  curBName2 = ""
  if self.curUrl:
   name = iUrlparse(self.curUrl).netloc
   if name:
    curBName2 = "%s (%s)" % (curBName, name.split(":")[0])
  title = "Add to Bouquet"
  mSel = CCHw3d(self, VVxBfP, addSep=False)
  thTxt = "Adding Services ..."
  VVZJ87, cbFncDict = [], None
  VVZJ87.append(VVoqHH)
  if itemsOK:
   VVZJ87.append(("Add %s to New Bouquet : %s"    % (totTxt, FFGB9z(curBName , VVVjNM)), "addToCur1"))
   if curBName2: VVZJ87.append(("Add %s to New Bouquet : %s" % (totTxt, FFGB9z(curBName2, VVkqaK)) , "addToCur2"))
   VVZJ87.append(("Add %s to Existing Bouquet ..."   % (totTxt)            , "addToNew" ))
   cbFncDict = { "addToCur1": BF(FFJsIX, mSel.VVxBfP, BF(self.VViN2r,source, mode, curBName , VVxBfP, title), title=thTxt)
      , "addToCur2": BF(FFJsIX, mSel.VVxBfP, BF(self.VViN2r,source, mode, curBName2, VVxBfP, title), title=thTxt)
      , "addToNew" : BF(self.VVIO2y, source, mode, curBName, VVxBfP, title)
      }
  else:
   VVZJ87.append(("Add to Bouquet (nothing selected)", ))
  mSel.VVsKHw(VVZJ87, cbFncDict, width=1400)
 def VViN2r(self, source, mode, curBName, VVxBfP, Title):
  chUrlLst = self.VVtTYl(source, mode, VVxBfP)
  CCSrvY.VV03W9(self, Title, curBName, "", chUrlLst)
 def VVIO2y(self, source, mode, curBName, VVxBfP, Title):
  picker = CCSrvY(self, VVxBfP, Title, BF(self.VVtTYl, source, mode, VVxBfP), defBName=curBName)
 def VVtTYl(self, source, mode, VVxBfP):
  totChange = 0
  isMulti = VVxBfP.VVQW9r
  chUrlLst = []
  rowNum = 0
  for ndx, row in enumerate(VVxBfP.VVlHja()):
   if not isMulti or VVxBfP.VVE8c8(ndx):
    chUrl = chName = 0
    if source in ("pEp", "pCh"):
     chName, catID, stID, chNum, chCm, serCode, serId, picUrl = self.VVPMtD(mode, row)
     refCode, chUrl = self.VVJNpF(self.VV4Xnp, self.VVktxB, mode, chName, catID, stID, chNum, chCm, serCode, serId)
    elif source == "m3Ch":
     chName = row[1].strip()
     url  = row[3].strip()
     chUrl = self.VVECbN(rowNum, url, chName)
     rowNum += 1
    elif source in ("lv", "v", "s", "fnd"):
     chName, chUrl, picUrl, refCode = self.VVAlWq(mode, row)
    if chUrl and chName:
     chUrlLst.append(chUrl)
  return chUrlLst
 @staticmethod
 def VVHe8S():
  return {"1": "DVB Stream", "4097": "servicemp3", "5001": "GST Player", "5002": "Ext-3 EPlayer", "8192": "HDMI input", "8193": "eServiceUri"}
 @staticmethod
 def VVOYzb():
  return sorted(tuple(CC9X9s.VVHe8S()))
 @staticmethod
 def VVGmcc(rt):
  return CC9X9s.VVHe8S().get(str(rt), "")
 @staticmethod
 def VVE8iD(refCode):
  span = iSearch(r"(?:([A-Fa-f0-9]+):){1}(?:[A-Fa-f0-9]+:){8}", refCode)
  return CC9X9s.VVGmcc(span.group(1)) if span else ""
 @staticmethod
 def VVXe1d(rt):
  if   rt == "1"  : return True
  elif rt == "4097": return True
  elif rt == "5001": return fileExists("/usr/bin/gstplayer") or fileExists("/usr/bin/gstplayer_gst-1.0")
  elif rt == "5002": return fileExists("/usr/bin/exteplayer3")
  elif rt == "8192": return False
  elif rt == "8193": return os.path.exists("/usr/bin/apt-get")
  else    : return False
 @staticmethod
 def VVrdGZ():
  defRt = CFG.iptvAddToBouquetRefType.getValue()
  VVZJ87 = []
  for ndx, rt in enumerate(CC9X9s.VVOYzb()):
   VVZJ87.append(FFnqNr("%s\t... %s" % (CC9X9s.VVGmcc(rt), rt), rt, CC9X9s.VVXe1d(rt), VVkIQ9 if rt == defRt else ""))
   if ndx < 4 and ndx % 2: VVZJ87.append(VVoqHH)
  return VVZJ87
class CCgxry(object):
 def __init__(self, SELF):
  SELF["mySbFrm"] = Label()
  SELF["mySbBak"] = Label()
  SELF["mySbSld"] = Label()
  self.frm, self.bak, self.sld = SELF["mySbFrm"], SELF["mySbBak"], SELF["mySbSld"]
  self.frmI = self.bakI = self.sldI = None
  self.sldX = self.sldY = self.sldW = self.sldH = 0
  for obj in (self.frm, self.bak, self.sld): obj.hide()
 def VV6kkS(self, x, y, w, h, bW=1, frmColor="#11aaaaaa", bakColor="#11003344", sldColor="#11ff8000"):
  x, y, w, h = int(x), int(y), int(w), int(h)
  FFWN9Z(self.frm, frmColor)
  FFWN9Z(self.bak, bakColor)
  FFWN9Z(self.sld, sldColor)
  self.frmI, self.bakI, self.sldI = self.frm.instance, self.bak.instance, self.sld.instance
  self.frmI.move(ePoint(x, y))
  self.frmI.resize(eSize(w, h))
  self.bakI.move(ePoint(x + bW, y + bW))
  self.bakI.resize(eSize(w - bW * 2, h - bW * 2))
  self.sldX = x + bW
  self.sldY = y + bW
  self.sldW = w - bW * 2
  self.sldH = h - bW * 2
  self.sldI.move(ePoint(self.sldX, self.sldY))
  self.sldI.resize(eSize(self.sldW, self.sldH))
 def VVL7yY(self, val, maxN):
  if maxN < 2:
   for obj in (self.frm, self.bak, self.sld): obj.hide()
  else:
   for obj in (self.frm, self.bak, self.sld): obj.show()
   visH = max(self.sldH / maxN, self.sldH * 0.05)
   self.sldI.resize(eSize(self.sldW, int(visH)))
   y = FF6NMP(val, 1, maxN, 0, self.sldH - visH)
   self.sldI.move(ePoint(self.sldX, int(self.sldY + y)))
class CCIoFg(CCgxry):
 def __init__(self, rows, cols, colorCfg):
  self.TOTAL_ROWS   = rows
  self.TOTAL_COLS   = cols
  self.PAGE_ITEMS   = self.TOTAL_ROWS * self.TOTAL_COLS
  self.colorCfg   = colorCfg
  self.totalItems   = 0
  self.totalPages   = 0
  self.curPage   = 0
  self.curRow    = 0
  self.curCol    = 0
  self.curIndex   = 0
  self.lastRow   = 0
  self.lastCol   = 0
  self.isBusy    = False
  CCgxry.__init__(self, self)
  self["myPiconPtr"]  = Label()
  self["myPiconF"]  = Label()
  self["myPiconBG"]  = Label()
  self["myPiconPic"]  = Pixmap()
  self["myPiconF"].hide()
  self["myPiconBG"].hide()
  self["myPiconPic"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)] = Label()
    self["myPosterPic%d%d" % (row, col)] = Pixmap()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)] = Label()
    self["myPosterLbl%d%d" % (row, col)].hide()
  self.VV2QeP()
  for i in range(6):
   self["myPiconInf%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "up" : self.VV09f2   ,
   "down" : self.VVVvF4  ,
   "left" : self.VVn01Q  ,
   "right" : self.VVbYcO  ,
   "next" : self.VVNeOF ,
   "last" : self.VV9Iu6
  }, -1)
 def VVBCeA(self):
  self["myPiconPic"].instance.setScale(1)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterPic%d%d" % (row, col)].instance.setScale(1)
  gap = int(self.skinParam["marginLeft"] / 1)
  topBox = self["myPosterPic%d%d" % (0, 0)].instance
  botBox = self["myPosterPic%d%d" % (self.TOTAL_ROWS - 1, self.TOTAL_COLS - 1)].instance
  w = 20
  y = topBox.position().y() - int(self.skinParam["marginTop"] / 2) + 2
  h = self.skinParam["height"] - self.skinParam["barHeight"] - y - 2
  x = self.skinParam["width"] - w - 2
  self.VV6kkS(x, y, w, h)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    try:
     inst = (self["myPosterLbl%d%d" % (row, col)]).instance
     inst.setBorderColor(parseColor("#000000"))
     inst.setBorderWidth(2)
    except:
     pass
  self.VV40Gt()
 def VVxFW3(self):
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > self.totalItems: f1 = self.totalItems
  if f2 > self.totalItems: f2 = self.totalItems
  return f1, f2
 def VV09f2(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVNKOq()
  else:
   if self.curPage == 0 and self.curRow == 0: self.curCol = 0
   else          : self.curRow -= 1
   self.VVvnUE()
 def VVVvF4(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVOtGy()
  else:
   if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow:
    self.curCol = self.lastCol
   else:
    self.curRow += 1
   self.VVvnUE()
 def VVn01Q(self):
  if self.curPage == self.curRow == self.curCol == 0:
   self.VVNKOq()
  else:
   self.curCol -= 1
   self.VVvnUE()
 def VVbYcO(self):
  if self.curPage == self.totalPages - 1 and self.curRow == self.lastRow and self.curCol == self.lastCol:
   self.VVOtGy()
  else:
   self.curCol += 1
   self.VVvnUE()
 def VV9Iu6(self):
  oldPage = self.curPage
  if self.curPage == 0:
   self.curRow = 0
   self.curCol = 0
  else:
   self.curPage -= 1
  self.VVvnUE(oldPage != self.curPage)
 def VVNeOF(self):
  oldPage = self.curPage
  if self.curPage == self.totalPages - 1:
   self.curRow = self.lastRow
   self.curCol = self.lastCol
  else:
   self.curPage += 1
  self.VVvnUE(oldPage != self.curPage)
 def VVOtGy(self):
  force = self.curPage != 0
  self.curRow  = 0
  self.curCol  = 0
  self.curPage = 0
  self.VVvnUE(force)
 def VVNKOq(self):
  force = self.curPage != self.totalPages - 1
  self.curPage = self.totalPages - 1
  self.curRow  = (self.TOTAL_ROWS - 1)
  self.curCol  = (self.TOTAL_COLS - 1)
  self.VVvnUE(force)
 def VVvnUE(self, force=False):
  if self.isBusy:
   return
  oldPage = self.curPage
  if self.curCol > self.TOTAL_COLS - 1:
   self.curCol = 0
   self.curRow += 1
  elif self.curCol < 0:
   self.curCol = self.TOTAL_COLS - 1
   self.curRow -= 1
  if self.curRow > self.TOTAL_ROWS - 1:
   self.curRow = 0
   self.curPage += 1
  elif self.curRow < 0:
   self.curRow = self.TOTAL_ROWS - 1
   self.curPage -= 1
  VVLZqP = self.totalPages -1
  if   self.curPage < 0  : self.curPage = 0
  elif self.curPage > VVLZqP: self.curPage = VVLZqP
  if self.curRow > self.TOTAL_ROWS - 1: self.curRow = self.TOTAL_ROWS - 1
  if self.curCol < 0     : self.curCol = 0
  self.VVJpuW()
  self["myPiconPtr"].hide()
  self.VVL7yY(self.curPage + 1, self.totalPages)
  FFFANg(BF(self.VVVQkN, force or not oldPage == self.curPage, VVLZqP))
 def VVVQkN(self, force, VVLZqP):
  try:
   if force:
    self.VVRUUk()
   if self.curPage == VVLZqP:
    if self.curRow > self.lastRow:
     self.curRow = self.lastRow
    if self.curRow == self.lastRow and self.curCol > self.lastCol:
     self.curCol = self.lastCol
   self.curIndex = self.curPage * self.PAGE_ITEMS + self.curRow * self.TOTAL_COLS + self.curCol
   self.VVJpuW()
   boxX, boxY, boxW, boxH = self.skinParam["extraPar"]
   self["myPiconPtr"].instance.move(ePoint(int(boxX + boxW * self.curCol), int(boxY + boxH * self.curRow)))
   self["myPiconPtr"].show()
  except:
   pass
  self["myPiconPtr"].show()
 def VVdh99(self, ndx):
  if ndx > -1 and ndx < self.totalItems:
   oldPage   = self.curPage
   self.curPage = int(ndx / self.PAGE_ITEMS)
   firstInPage  = self.curPage * self.PAGE_ITEMS
   diff   = ndx - firstInPage
   self.curRow  = int(diff / self.TOTAL_COLS)
   firstInRow  = self.curRow * self.TOTAL_COLS
   diff   = ndx - firstInPage
   self.curCol  = diff - self.curRow * self.TOTAL_COLS
   self.VVvnUE(False if oldPage == self.curPage else True)
  else:
   FF5uKN(self, "Not found", 1000)
 def VVHvPA(self):
  self.VVdh99(self.totalItems - 1 if self.curIndex == 0 else 0)
 def VVxLQD(self):
  self["myPiconPtr"].hide()
 def VV2QeP(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myPosterRep%d%d" % (row, col)].hide()
    self["myPosterPic%d%d" % (row, col)].hide()
    self["myPosterLbl%d%d" % (row, col)].hide()
 def VVkqAc(self):
  if self.colorCfg:
   fg = bg = self.colorCfg.getValue()
   self.session.openWithCallback(self.VVbFLT, CCrMdZ, defFG=fg, defBG=bg, onlyBG=True)
 def VVbFLT(self, fg, bg):
  if self.colorCfg and bg:
   FFdEZ4(self.colorCfg, bg)
   self.VV40Gt()
 def VV40Gt(self):
  if self.colorCfg:
   for row in range(self.TOTAL_ROWS):
    for col in range(self.TOTAL_COLS):
     FFWN9Z(self["myPosterRep%d%d" % (row, col)], self.colorCfg.getValue())
 def VVbcZ7(self, lbl, txt, color=""):
  CCIoFg.VV2us7(lbl, txt, color)
 @staticmethod
 def VV2us7(lbl, txt, color=""):
  lbl.show()
  lbl.setText(txt)
  txtW = lbl.instance.calculateSize().width()
  lblW = lbl.instance.size().width() - 15
  if txtW > lblW:
   for i in range(len(txt), 5, -1):
    txt = txt[:-1]
    lbl.setText("%s.." % txt)
    txtW = lbl.instance.calculateSize().width()
    if txtW < lblW:
     break
  if color:
   lbl.setText("%s%s" % (color, txt))
 @staticmethod
 def VVWEbm(pic, path):
  pic.show()
  if fileExists(path):
   try:
    png = LoadPixmap(path)
    pic.instance.setScale(1)
    pic.instance.setPixmap(png)
    return png
   except:
    pass
  return None
class CCDFOS(Screen, CCIoFg):
 def __init__(self, session, VVxBfP, category, nameCol, picCol, descCol, descTxt):
  self.skin, self.skinParam = FFRBRO(VVGa0l, 1870, 1030, 50, 3, 3, "#33000000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "Server Browser"
  self.VVxBfP  = VVxBfP
  self.category   = category
  self.nameCol   = nameCol
  self.picCol    = picCol
  self.descCol   = descCol
  self.descTxt   = descTxt
  self.timer    = eTimer()
  self.myThread   = None
  self.totDownloads  = 0
  self.stopThread   = False
  self.VVarfR    = []
  self.totPosterUrls  = 0
  self.totalItems   = 0
  FFmmH7(self, self.Title)
  CCIoFg.__init__(self, 2, 6, CFG.transpColorPosters)
  subPath = ""
  if   category == "live"  : subPath = "Live/"
  elif category == "vod"  : subPath = "VOD/"
  elif category == "series" : subPath = "Series/"
  elif category == "m3u"  : subPath = "M3U/"
  self.pPath = "%sPosters/%s" % (VVNemM, subPath)
  if not pathExists(self.pPath):
   FFuB0V("mkdir -p '%s'" % self.pPath)
   if not pathExists(self.pPath):
    self.pPath = "/tmp/"
  self["myAction"].actions.update(
  {
   "ok" : self.VVxCTS    ,
   "cancel": self.close    ,
   "menu" : self.VVdxuU ,
   "info" : self.VVek9u  ,
   "0"  : self.VVHvPA
  })
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFj9eW(self)
  FFHLqT(self)
  self.VVBCeA()
  self.VVKAaD()
 def onExit(self):
  self.stopThread = True
  self.timer.stop()
 def VVdxuU(self):
  chName, subj, desc, fName, picUrl = self.VVarfR[self.curIndex]
  VVZJ87 = []
  VVZJ87.append(FFnqNr("Show Selected Picture"        , "VVgc20"  , fName))
  VVZJ87.append(FFnqNr("Copy Selected Picture to Export-Directory"   , "VVNARN" , fName))
  VVZJ87.append(FFnqNr("Set Selected Picture as a Poster for a Local Media" , "VVmUbw", fName))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Cache details"       , "VVpyDj"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Change Poster/Picon Transparency Color" , "VVkqAc" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Help (Keys)"        , "help"     ))
  FFYySC(self, self.VVkogE, title=self.Title, VVZJ87=VVZJ87)
 def VVkogE(self, item=None):
  if item is not None:
   if   item == "VVgc20"   : self.VVgc20()
   elif item == "VVNARN"   : self.VVNARN()
   elif item == "VVmUbw"  : self.VVmUbw()
   elif item == "VVpyDj"  : FFJsIX(self, self.VVpyDj, title="Calculating ...")
   elif item == "VVkqAc": self.VVkqAc()
   elif item == "help"     : FFqsYG(self, "_help_servBr", "Server Browser (Keys)")
 def VVxCTS(self):
  self.VVxBfP.VVYNxS(self.curIndex)
  self.VVxBfP.VVi1LJ()
 def VVek9u(self):
  self.VVxBfP.VVYNxS(self.curIndex)
  self.VVxBfP.VVc83A()
 def VVKAaD(self):
  for colList in self.VVxBfP.VVlHja():
   chName = colList[self.nameCol]
   url  = colList[self.picCol]
   desc = colList[self.descCol]
   fName = picUrl = ""
   if url:
    tmpFile = os.path.basename(url)
    if fileExists(self.pPath + tmpFile):
     fName = tmpFile
    else:
     picUrl = url
     self.totPosterUrls += 1
   self.VVarfR.append((chName, self.descTxt, desc, fName, picUrl))
  self.totalItems = len(self.VVarfR)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  ndx = self.VVxBfP.VVgu5W()
  self.curPage = int(ndx / self.PAGE_ITEMS)
  ndx     -= self.curPage * self.PAGE_ITEMS
  self.curRow  = int((ndx / self.TOTAL_COLS))
  ndx     -= self.curRow * self.TOTAL_COLS
  self.curCol  = int((ndx % self.TOTAL_COLS))
  self.VVvnUE(True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VViV2i)
  except:
   self.timer.callback.append(self.VViV2i)
  self.timer.start(500, False)
  self.myThread = iThread(name="ajp_progBar", target=self.VVuVeA)
  self.myThread.start()
 def VVuVeA(self):
  try:
   for ndx, (chName, subj, desc, fName, picUrl) in enumerate(self.VVarfR):
    if not self.stopThread:
     if picUrl and not fName:
      fName = os.path.basename(picUrl)
      path, err = FFtKyC(picUrl, fName, timeout=1, mustBeImage=True)
      if path:
       self.totDownloads += 1
       FFuB0V("mv -f '%s' '%s'" % (path, self.pPath + fName))
       self.VVarfR[ndx] = (chName, subj, desc, fName, "-")
  except:
   pass
 def VViV2i(self):
  txt = ""
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
  else:
   txt = VVGe5h + "   >> Downloading %d/%d ..." % (self.totDownloads, self.totPosterUrls)
  self["myTitle"].setText("  %s%s" % (self.Title, txt))
  last = self.totalItems
  f1 = self.curPage * self.PAGE_ITEMS
  f2 = f1 + self.PAGE_ITEMS
  if f1 > last: f1 = last
  if f2 > last: f2 = last
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVarfR[ndx]
   if fName and picUrl == "-":
    path = self.pPath + fName
    if fileExists(path):
     self.VVarfR[ndx] = (chName, subj, desc, fName, "")
     CCIoFg.VVWEbm(self["myPosterPic%d%d" % (row, col)], path)
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVRUUk(self):
  self.VV2QeP()
  f1, f2 = self.VVxFW3()
  row = col = 0
  for ndx in range(f1, f2):
   chName, subj, desc, fName, picUrl = self.VVarfR[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVbcZ7(lbl, chName)
   path = ""
   if fName    : path = self.pPath + fName
   if not fileExists(path) : path = VVrrZu + "iptv.png"
   CCIoFg.VVWEbm(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVJpuW(self):
  chName, subj, desc, fName, picUrl = self.VVarfR[self.curIndex]
  self["myPiconInf0"].setText("  " + chName + "  ")
  self["myPiconInf1"].setText("   " + "%s : %s" % (subj, desc) if desc else "" + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVgc20(self):
  chName, subj, desc, fName, picUrl = self.VVarfR[self.curIndex]
  if fName and fileExists(self.pPath + fName) : CCo6hs.VVhaNU(self, self.pPath + fName)
  else          : FF5uKN(self, "File not found", 1500)
 def VVNARN(self):
  title = "Copy Poster/PIcon"
  chName, subj, desc, fName, picUrl = self.VVarfR[self.curIndex]
  if fName:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = dstPath + (chName + os.path.splitext(fName)[1] if chName else fName)
   if FFuB0V("cp -f '%s' '%s'" % (self.pPath + fName, dstF)):
    FF15cM(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFw5OO(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstPath), title=title)
  else:
   FFw5OO(self, "No Poster/PIcon found", title=title)
 def VVmUbw(self):
  self.session.openWithCallback(self.VVcLS5, BF(CCCXvS, patternMode="movies", VVMbDq=CFG.MovieDownloadPath.getValue()))
 def VVcLS5(self, path):
  if path:
   title = "Set Selected Picture as a Poster for a Local Media"
   chName, subj, desc, fName, picUrl = self.VVarfR[self.curIndex]
   if fName:
    srcF = self.pPath + fName
    dstF = "%s%s" % (os.path.splitext(path)[0], os.path.splitext(srcF)[1])
    if FFuB0V("cp -f '%s' '%s'" % (srcF, dstF)):
     FF15cM(self, "File copied to:\n\n%s" % dstF, title=title)
    else:
     FFw5OO(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (fName, dstF), title=title)
    CCC4Ww.VVEwVI(dstF)
   else:
    FFw5OO(self, "No Poster/PIcon found", title=title)
 def VVpyDj(self):
  txt = "\n"
  totSize = 0
  for path in ("Live/", "VOD/", "Series/", "M3U/"):
   path = "%sPosters/%s" % (VVNemM, path)
   size = "Dir. not found !"
   if pathExists(path):
    size = FF3RLi("find '%s' ! -type d -print0 2> /dev/null | xargs -0 ls -lsa 2> /dev/null | awk '{sum+=$6;} END {print sum;}'" % path)
    if size.isdigit():
     size = int(size)
     totSize += size
     size = CCCXvS.VVutW7(size)
   txt += "%s\n    %s\n\n" % (FFGB9z(path, VVUVAI), size)
  mainPath = "%sPosters" % VVNemM
  totFiles = FF3RLi("find '%s' ! -type d | wc -l" % mainPath)
  totFTxt = " (%s file%s)" % (totFiles, FF1I1d(int(totFiles))) if totFiles.isdigit() else ""
  txt += "%s\n    %s\n\n" % (FFGB9z("Total space used by Posters/PIcons%s:" % totFTxt, VVVCGb), CCCXvS.VVutW7(totSize))
  mountPath = CCCXvS.VV6sdc(mainPath)
  if pathExists(mountPath):
   totSize  = CCCXvS.VVlZtT(mountPath)
   freeSize = CCCXvS.VVOsjP(mountPath)
   usedSize = CCCXvS.VVutW7(totSize - freeSize)
   totSize  = CCCXvS.VVutW7(totSize)
   freeSize = CCCXvS.VVutW7(freeSize)
   txt += "%s\n" % SEP
   txt += FFGB9z("Media Space:\n", VVMrXw)
   txt += "    Media Path\t: %s\n" % FFGB9z(mountPath, VVWOjU)
   txt += "    Total Size\t: %s\n" % totSize
   txt += "    Used Size\t: %s\n" % usedSize
   txt += "    Free Size\t: %s\n" % freeSize
  FF90Bc(self, txt, title="Cache Used Size", height=1000)
class CCC4Ww(Screen, CCIoFg):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFRBRO(VVC6jd, 1870, 1030, 50, 3, 3, "#33440000", "#33000000", 50, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = title
  self.VVarfR    = lst
  FFmmH7(self, self.Title)
  CCIoFg.__init__(self, 2, 6, CFG.transpColorMovies)
  self["myAction"].actions.update(
  {
   "ok" : self.VVxCTS    ,
   "cancel": self.close    ,
   "menu" : self.VVmoSk ,
   "info" : self.VVLq3s  ,
   "0"  : self.VVHvPA
  })
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFj9eW(self)
  FFHLqT(self)
  self.VVBCeA()
  self.totalItems = len(self.VVarfR)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVvnUE(True)
 def VVRUUk(self):
  self.VV2QeP()
  f1, f2 = self.VVxFW3()
  mPath = CFG.MovieDownloadPath.getValue()
  row = col = 0
  for ndx in range(f1, f2):
   path, movie, poster = self.VVarfR[ndx]
   path = os.path.join(mPath, path)
   path = os.path.join(path, movie)
   if poster: poster = os.path.join(os.path.dirname(path), poster)
   else  : poster = VVrrZu + "noPos.png"
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVbcZ7(lbl, os.path.splitext(os.path.basename(path))[0])
   CCIoFg.VVWEbm(pic, poster)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVK5lE(self):
  path, movie, poster = self.VVarfR[self.curIndex]
  path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
  path = os.path.join(path, movie)
  if poster:
   poster = os.path.join(os.path.dirname(path), poster)
  return path, poster
 def VVJpuW(self):
  path, poster = self.VVK5lE()
  self["myPiconInf0"].setText("  " + os.path.splitext(os.path.basename(path))[0] + "  ")
  self["myPiconInf1"].setText("   " + os.path.dirname(path) + "   ")
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 def VVmoSk(self):
  path, poster = self.VVK5lE()
  VVZJ87 = []
  VVZJ87.append(("Go to movie ...", "VVu61G"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(FFnqNr("Show Poster"      , "VVgc20" , poster))
  VVZJ87.append(FFnqNr("Copy Poster to Export-Directory" , "VVNARN", poster))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Change Poster/Picon Transparency Color"  , "VVkqAc" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Change Poster (from current movie path) ..." , "VVsMww1"  ))
  VVZJ87.append(("Change Poster (locate manually) ..."   , "VVsMww2"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Help (Keys)"         , "help"     ))
  FFYySC(self, self.VVTtPg, title=self.Title, VVZJ87=VVZJ87)
 def VVTtPg(self, item=None):
  if item is not None:
   if   item == "VVu61G"    : self.VVu61G()
   elif item == "VVNARN"    : self.VVNARN()
   elif item == "VVgc20"    : self.VVgc20()
   elif item == "VVkqAc" : self.VVkqAc()
   elif item == "VVsMww1"  : self.VVsMww()
   elif item == "VVsMww2"  : self.VVsMww(True)
   elif item == "help"      : FFqsYG(self, "_help_movBr", "Movies Browser (Keys)")
 def VVu61G(self):
  VVX3wb = []
  for ndx, item in enumerate(self.VVarfR):
   path, movie, poster = item
   path = os.path.join(CFG.MovieDownloadPath.getValue(), path)
   VVX3wb.append((os.path.splitext(movie)[0], path, str(ndx)))
  VVX3wb.sort(key=lambda x: x[0].lower())
  VVwmV1 = ("Select" , self.VVL95k, [])
  header  = ("Name" , "Path", "NDX.")
  widths  = (60  , 40 , 0  )
  FF1Dpj(self, None, title="Select Movie", width=1800, height=1000, header=header, VVarfR=VVX3wb, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, lastFindConfigObj=CFG.lastFindMovie)
 def VVL95k(self, VVxBfP, title, txt, colList):
  self.VVdh99(int(colList[2].strip()))
  VVxBfP.cancel()
 def VVxCTS(self):
  path, poster = self.VVK5lE()
  FFJsIX(self, BF(CCCXvS.VVDPDb, self, path), title="Playing Media ...")
 def VVLq3s(self):
  path, poster = self.VVK5lE()
  txt = "%s:\n%s\n\n" % (FFGB9z("Path", VVUVAI), path)
  size = FFqLWj(path)
  if size > -1:
   txt += "%s:\n%s\n\n" % (FFGB9z("File Size", VVUVAI), CCCXvS.VVutW7(size))
  if poster:
   txt += "%s:\n%s" % (FFGB9z("Poster", VVUVAI), poster)
  FF90Bc(self, txt, title="Media File Information")
 def VVgc20(self):
  path, poster = self.VVK5lE()
  if fileExists(poster): CCo6hs.VVhaNU(self, poster)
  else     : FF5uKN(self, "No Poster", 1500)
 def VVNARN(self):
  title = "Copy Poster"
  path, poster = self.VVK5lE()
  if poster:
   dstPath = CFG.exportedPIconsPath.getValue()
   dstF = os.path.join(dstPath, os.path.basename(poster))
   if FFuB0V("cp -f '%s' '%s'" % (poster, dstF)):
    FF15cM(self, "File copied to:\n\n%s" % dstF, title=title)
   else:
    FFw5OO(self, "Cannot copy the file:\n%s\n\nTo:\n%s" % (poster, dstPath), title=title)
  else:
   FF5uKN(self, "No Poster", 1500)
 def VVsMww(self, isManual=False):
  path, poster = self.VVK5lE()
  sDir = FF1vNj(os.path.dirname(path))
  if isManual:
   self.session.openWithCallback(BF(self.VV4VXF, sDir, path), BF(CCCXvS, patternMode="poster", VVMbDq=sDir))
  else:
   VVZJ87 = []
   for item in [f for f in os.listdir(sDir) if iSearch(r"^.*\.(jpg|png)", f, IGNORECASE)]:
    VVZJ87.append((os.path.basename(item), sDir + item))
   if VVZJ87:
    VVZJ87.sort(key=lambda x: x[0].lower())
    VVXyZL = self.VVJMyf
    FFYySC(self, BF(self.VV4VXF, sDir, path), VVZJ87=VVZJ87, title="Posters", VVXyZL=VVXyZL, VVAL4K=sDir)
   else:
    FF5uKN(self, "No jpg/png in current dir", 1500)
 def VVJMyf(self, VV4EHV, txt, ref, ndx):
  CCo6hs.VVhaNU(self, VVbLQv=ref)
 def VV4VXF(self, sDir, path, pPath=None):
  if pPath:
   newPath = sDir + os.path.splitext(os.path.basename(path))[0] + os.path.splitext(pPath)[1].lower()
   if FFuB0V("cp -f '%s' '%s'" % (pPath, newPath)) or pPath == newPath:
    self.VVarfR[self.curIndex] = (self.VVarfR[self.curIndex][0], self.VVarfR[self.curIndex][1], os.path.basename(newPath))
    FFJsIX(self, self.VVRUUk)
    CCC4Ww.VVEwVI(newPath)
   else:
    FF5uKN(self, "Cannot copy file", 1000)
 @staticmethod
 def VVEwVI(path):
  if path.endswith(".png"):
   fileNoExt = path[:-4]
   jpgF = fileNoExt + ".jpg"
   if fileExists(jpgF):
    c = 1
    newF = "%s_%d.jpg" % (fileNoExt, c)
    while fileExists(newF):
     c += 1
     newF = "%s_%d.jpg" % (fileNoExt, c)
    FFuB0V("mv -f '%s' '%s'" % (jpgF, newF))
 @staticmethod
 def VVQCAN(SELF):
  eLst = CCA8jA.VV1p4d()["mov"]
  mPath = CFG.MovieDownloadPath.getValue()
  lst = []
  for (Dir, dirs, files) in os.walk(mPath):
   for f in files:
    if os.path.splitext(f)[1].lstrip(".").lower() in eLst:
     path = os.path.join(Dir, f)
     poster = ""
     for ext in ("jpg", "png"):
      pic = "%s.%s" % (os.path.splitext(path)[0], ext)
      if fileExists(pic):
       poster = os.path.basename(pic)
       break
     lst.append((os.path.dirname(path).replace(mPath, ""), os.path.basename(path), poster))
  title = "Movies Browser"
  lst.sort(key=lambda x: x[1].lower())
  if lst: SELF.session.open(CCC4Ww, title, lst)
  else  : FFw5OO(SELF, "No movies found in:\n\n%s\n\nYou can change the path from settings." % mPath, title=title)
class CC3TAu(Screen, CCIoFg):
 def __init__(self, session, bName, lst):
  self.skin, self.skinParam = FFRBRO(VV3Lt2, 1840, 1040, 50, 3, 3, "#22003344", "#22001122", 45, barHeight=40, topRightBtns=1, vSliderW=20)
  self.session   = session
  self.Title    = bName
  self.VVarfR    = lst
  self.pPath    = CCijoe.VV4boJ()
  self.totalItems   = 0
  self.isFirstTime  = True
  FFmmH7(self, self.Title)
  FFR9Qm(self["keyRed"] , "OK = Zap (Review)")
  FFR9Qm(self["keyGreen"] , "Zap & Exit")
  FFR9Qm(self["keyYellow"], "Find Current Service")
  CCIoFg.__init__(self, 5, 7, CFG.transpColorChannels)
  self["myAction"].actions.update(
  {
   "ok"  : BF(self.VVMeMP, False),
   "cancel" : self.VVunSf      ,
   "menu"  : self.VV65tO   ,
   "red"  : self.VVunSf      ,
   "green"  : BF(self.VVMeMP, True) ,
   "yellow" : BF(self.VVgsgh, True)  ,
   "0"   : self.VVHvPA
  })
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  if self.isFirstTime:
   force = True
   self.isFirstTime = False
   FFj9eW(self)
   FFHLqT(self)
   FFWN9Z(self["keyRed"], "#0a333333")
   self.VVBCeA()
  else:
   pName, srvLst = CC3TAu.VVptD3()
   if srvLst and not srvLst == self.VVarfR:
    force = True
    self.Title = pName
    self["myTitle"].setText("  %s  " % self.Title)
    self.VVarfR = srvLst
   else:
    force = False
  self.totalItems = len(self.VVarfR)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVvnUE(force)
  self.VVgsgh()
 def VV65tO(self):
  VVZJ87 = []
  VVZJ87.append(("Find Name (sorted list)" , "findSrt"  ))
  VVZJ87.append(("Find Name (as listed)" , "findNoSrt"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Change Background Color" , "VVkqAc"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Help (Keys)", "help"))
  FFYySC(self, self.VVAdsc, title="Options", VVZJ87=VVZJ87)
 def VVAdsc(self, item=None):
  if item:
   if   item == "findSrt"    : self.VVmVS1(True)
   elif item == "findNoSrt"   : self.VVmVS1(False)
   elif item == "VVkqAc": self.VVkqAc()
   elif item == "help"     : FFqsYG(self, "_help_srvcBr", "Services Browser (Keys)")
 def VVmVS1(self, isSort):
  VVZJ87 = []
  for ndx, item in enumerate(self.VVarfR):
   VVZJ87.append((item[1], ndx))
  if isSort:
   VVZJ87.sort(key=lambda x: x[0].lower())
  FFYySC(self, self.VVFLBM, title="Find Name", VVZJ87=VVZJ87, width=1300)
 def VVFLBM(self, ndx=None):
  if ndx is not None:
   self.VVdh99(ndx)
 def VVunSf(self):
  if self.shown: self.close()
  else   : self.show()
 def VVMeMP(self, isExit):
  FFJsIX(self, BF(self.VV8aS1, isExit), title="Starting ...")
 def VV8aS1(self, isExit):
  try:
   if self.shown:
    FFkwBg(self, self.VVarfR[self.curIndex][0], VVIC8r=False)
    if isExit: self.close()
    else  : CCb9j4.VV6JFp(self.session)
   else:
    self.show()
  except:
   pass
 def VVgsgh(self, VV70Sp=False):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  err = ""
  if serv:
   curRef = serv.toString()
   for ndx, item in enumerate(self.VVarfR):
    if curRef == item[0]:
     self.VVdh99(ndx)
     return ndx
   else:
    err = "Not found"
  else:
   err = "No active service"
  if VV70Sp and err:
   FF5uKN(self, err, 500)
  return -1
 def VVRUUk(self):
  self.VV2QeP()
  f1, f2 = self.VVxFW3()
  row = col = 0
  noPos = VVrrZu + "noPos.png"
  for ndx in range(f1, f2):
   ref, name = self.VVarfR[ndx]
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVbcZ7(lbl, name)
   path = CCijoe.VVB5jv(self.pPath, ref, name) or noPos
   CCIoFg.VVWEbm(pic, path)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVJpuW(self):
  ref, name = self.VVarfR[self.curIndex]
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % ref)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVIbAu():
  refCode = refName = rootRef = rootName = ""
  inBouquet = False
  VVhMBa = InfoBar.instance
  if VVhMBa:
   csel = VVhMBa.servicelist
   if csel:
    currSel  = csel.getCurrentSelection()
    rootRef  = csel.getRoot().toString()
    refCode  = currSel.toString()
    rootName = FFyNG3(rootRef)
    refName  = FFyNG3(refCode)
    inBouquet = csel.inBouquet()
  return refCode, refName, rootRef, rootName, inBouquet
 @staticmethod
 def VVptD3(refCode="", refName="", rootRef="", rootName="", inBouquet=False):
  refCode, rootRef = refCode.strip(), rootRef.strip()
  if not refCode and not rootRef:
   refCode, refName, rootRef, rootName, inBouquet = CC3TAu.VVIbAu()
   refCode, rootRef = refCode.strip(), rootRef.strip()
  pName, srvLst = "", []
  if refCode and rootRef:
   if   refCode.startswith("1:7:") : ref, name = refCode, refName
   elif rootRef.startswith("1:7:") : ref, name = rootRef, rootName
   else       : return "", []
   srvLst = FFw4Nf(eServiceReference(ref))
   pName = name or "No-Name"
   if not inBouquet: srvLst.sort(key=lambda x: x[1].lower())
  else:
   srvLst = CCSrvY.VVQ4Kz()
   pName  = CCSrvY.VVqbQQ() or "ALL (Group)"
  return pName, srvLst
 @staticmethod
 def VVjodP(SELF):
  pName, srvLst = CC3TAu.VVptD3()
  if srvLst: SELF.session.open(CC3TAu, pName, srvLst)
  else  : FFw5OO(SELF, "No services found:\n\n%s" % pName, title="Channels Browser")
class CCo7ti(Screen, CCIoFg):
 def __init__(self, session, title, lst):
  self.skin, self.skinParam = FFRBRO(VV8OK0, 1600, 1000, 50, 20, 20, "#2200202a", "#2200101a", 45, barHeight=40, topRightBtns=2, vSliderW=20, morePar={"gapX":30, "gapY":30, "mGap":5, "lblC":"#2200101a", "lblTr":1, "picBgTr":1, "cursC":"#00336070"})
  self.session   = session
  self.Title    = title
  self.VVarfR    = CCo7ti.VVKuAa(lst)
  self.totalItems   = 0
  self.useOrigSize  = False
  FFmmH7(self, self.Title)
  FFR9Qm(self["keyRed"] , "OK = Start Plugin")
  FFR9Qm(self["keyYellow"], "Package Info.")
  FFR9Qm(self["keyBlue"] , "Plugins Group")
  CCIoFg.__init__(self, 4, 5, "")
  self["myAction"].actions.update(
  {
   "ok"  : self.VVspTA   ,
   "cancel" : self.VVunSf    ,
   "menu"  : self.VVveYD ,
   "info"  : self.VVvjo6  ,
   "red"  : self.VVunSf    ,
   "yellow" : BF(FFJsIX, self, self.VVRb7f),
   "blue"  : self.VVAaXB  ,
   "0"   : self.VVHvPA
  })
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFj9eW(self)
  FFHLqT(self)
  FFWN9Z(self["keyRed"], "#0a333333")
  self.VVBCeA()
  self.totalItems = len(self.VVarfR)
  self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  self.VVvnUE(True)
 def VVunSf(self):
  self.close()
 def VVspTA(self):
  name, desc = self.VVRiWX(self.curIndex)
  if name == PLUGIN_NAME:
   FF5uKN(self, "Already running.", 500)
  else:
   try:
    p = self.VVarfR[self.curIndex]
    p(session=self.session)
   except:
    FFw5OO(self, "Cannot start from here !", title="Error in : %s" % name)
 def VVvjo6(self):
  def VVYPGf(key, val):
   return key + "\t: " + str(val) + "\n"
  p = self.VVarfR[self.curIndex]
  txt = ""
  try:
   txt += VVYPGf("Path"  , p.path  )
   txt += VVYPGf("Description" , p.description )
   txt += VVYPGf("Icon"  , p.iconstr  )
   txt += VVYPGf("Wakeup Fnc" , p.wakeupfnc )
   txt += VVYPGf("NeedsRestart", p.needsRestart)
   txt += VVYPGf("Internal" , p.internal )
   txt += VVYPGf("Weight"  , p.weight  )
  except:
   pass
  name, desc = self.VVRiWX(self.curIndex)
  if txt : FF90Bc(self, txt, title=name)
  else : FFw5OO(self, "Could not read plugin info.", title=name)
 def VVRb7f(self):
  p = self.VVarfR[self.curIndex]
  name, desc = self.VVRiWX(self.curIndex)
  path = p.path
  pkg, err = CCXYqv.VVMWQB(path)
  if pkg : CCXYqv.VVnhoE(self, pkg, name)
  else : FFzLBa(self, err, 1000)
 def VVveYD(self):
  path = self.VVarfR[self.curIndex].path
  VVZJ87 = []
  txt = "Open Plugin Path in File Manager"
  VVZJ87.append(FFnqNr("Open Plugin Path in File Manager", "inFileMan", pathExists(path)))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Use Original Icon Size", "setOrigSize"))
  FFYySC(self, self.VVwGRH, title="Plugins Group", VVZJ87=VVZJ87)
 def VVwGRH(self, item=None):
  if item:
   if item == "inFileMan":
    self.session.open(CCCXvS, mode=CCCXvS.VVsRn5, VVMbDq=self.VVarfR[self.curIndex].path)
   elif item == "setOrigSize":
    self.useOrigSize = True
    self.VVvnUE(True)
 def VVAaXB(self):
  FFYySC(self, self.VVHcM5, title="Plugins Group", VVZJ87=CCo7ti.VVSyZr(True, True), width=700, VV18hv=True)
 def VVHcM5(self, item=None):
  if item:
   title, where, ndx = item
   self["myTitle"].setText("  %s (%s)" % (self.Title, title))
   lst = CCo7ti.VV1hEj(where)
   if lst:
    self.VVarfR = CCo7ti.VVKuAa(lst)
    self.curPage = self.curCol = self.curRow = self.curIndex = 0
    self.totalItems = len(self.VVarfR)
    self.totalPages  = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
    self.VVvnUE(True)
   else:
    FFw5OO(self, "Not found !", title=self.Title)
 def VVRUUk(self):
  self.VV2QeP()
  f1, f2 = self.VVxFW3()
  row = col = 0
  for ndx in range(f1, f2):
   name, desc = self.VVRiWX(ndx)
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   self.VVbcZ7(lbl, name)
   iconOk = False
   pngSz = None
   if self.VVarfR[ndx].icon:
    try:
     pngSz = self.VVarfR[ndx].icon.size()
     pic.instance.setScale(1)
     pic.instance.setPixmap(self.VVarfR[ndx].icon)
     pic.show()
     iconOk = True
    except:
     pass
   if not iconOk:
    icons = []
    path = self.VVarfR[ndx].path
    if pathExists(path):
     for f in ("iconfhd.png", "iconhd.png", "icon.png"):
      icons.append(os.path.join(path, f))
    icons.append(resolveFilename(SCOPE_CURRENT_SKIN, "icons/plugin.png"))
    icons.append(VVrrZu + "plugin.png")
    for path in icons:
     pixMap = CCIoFg.VVWEbm(pic, path)
     if pixMap:
      pngSz = pixMap.size()
      break
   if self.useOrigSize and pngSz:
    try:
     boxSz = pic.instance.size()
     picPos = pic.instance.position()
     pngW, pngH = pngSz.width(), pngSz.height()
     boxW, boxH = boxSz.width(), boxSz.height()
     if boxW > pngW and boxH > pngH:
      pic.instance.resize(pngSz)
      pic.instance.move(ePoint(picPos.x() + (boxW - pngW) // 2, picPos.y() + (boxH - pngH) // 2))
    except:
     pass
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 def VVRiWX(self, ndx):
  name = str(self.VVarfR[ndx].name).strip()
  desc = str(self.VVarfR[ndx].description).strip().replace("\n", " >> ")
  if not name or name == "Plugin":
   name = desc or FF65m2(self.VVarfR[ndx].path)
  return name, desc
 def VVJpuW(self):
  name, desc = self.VVRiWX(self.curIndex)
  self["myPiconInf0"].setText("  %s  " % name)
  self["myPiconInf1"].setText("   %s" % desc)
  self["myPiconInf2"].setText("Num. : %d / %d" % (self.curIndex + 1, self.totalItems))
  self["myPiconInf3"].setText("Page: %d / %d"  % (self.curPage  + 1, self.totalPages))
 @staticmethod
 def VVSyZr(isMenu=False, addTot=False):
  lst =[("Plugin Menu"   , PluginDescriptor.WHERE_PLUGINMENU    )
   , ("Audio Menu"    , PluginDescriptor.WHERE_AUDIOMENU    )
   , ("Auto-Start Menu"  , PluginDescriptor.WHERE_AUTOSTART    )
   , ("Channel Context Menu" , PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU )
   , ("Event Info"    , PluginDescriptor.WHERE_EVENTINFO    )
   , ("Extensions Menu"  , PluginDescriptor.WHERE_EXTENSIONSMENU   )
   , ("File Scan"    , PluginDescriptor.WHERE_FILESCAN    )
   , ("Main Menu"    , PluginDescriptor.WHERE_MAINMENU    )
   , ("Menu"     , PluginDescriptor.WHERE_MENU     )
   , ("Movie List"    , PluginDescriptor.WHERE_MOVIELIST    )
   , ("Network Configuration" , PluginDescriptor.WHERE_NETWORKCONFIG_READ  )
   , ("Network Setup"   , PluginDescriptor.WHERE_NETWORKSETUP   )
   , ("Session Start"   , PluginDescriptor.WHERE_SESSIONSTART   )
   , ("Software Manager"  , PluginDescriptor.WHERE_SOFTWAREMANAGER  )
   , ("Teletext"    , PluginDescriptor.WHERE_TELETEXT    )
   , ("Wizard"     , PluginDescriptor.WHERE_WIZARD     )]
  if addTot:
   for ndx, item in enumerate(lst):
    tot = len(CCo7ti.VV1hEj(item[1]))
    lst[ndx] = ("%s   %s(%d)" % (lst[ndx][0], VVGb6D, tot), lst[ndx][1])
  if isMenu: lst.insert(1, VVoqHH)
  else  : lst.sort(key=lambda x: x[0].lower())
  return lst
 @staticmethod
 def VV1hEj(where):
  try: return iPlugins.getPlugins(where)
  except: return []
 @staticmethod
 def VVKuAa(lst):
  tmp = []
  for item in lst:
   name = str(item.name).strip()
   if not name or name == "Plugin":
    name = str(item.description).strip() or FF65m2(item.path)
   tmp.append((name, item))
  tmp.sort(key=lambda x: x[0].lower())
  lst = []
  for nm, obj in tmp:
   lst.append(obj)
  return lst
 @staticmethod
 def VVjodP(SELF):
  title = "Plugins Browser"
  lst = CCo7ti.VV1hEj(PluginDescriptor.WHERE_PLUGINMENU)
  if lst : SELF.session.open(CCo7ti, title, lst)
  else : FFw5OO(SELF, "No plugins found !", title=title)
class CC42f6(Screen):
 def __init__(self, session, title="", csel=None, refCode="", servName="", isFind=False):
  self.skin, self.skinParam = FFRBRO(VVF5EY, 700, 800, 50, 40, 30, "#22000033", "#22000011", 30)
  self.session     = session
  self.csel      = csel
  self.refCode     = refCode
  self.servName     = servName
  self.findTxt     = servName
  self.isFindMode     = isFind
  self.VVE5Gd  = 0
  self.VV0M7o = 1
  self.VVUOgz  = 2
  VVZJ87 = []
  VVZJ87.append(("Find in All Service (from filter)" , "VV6gXu" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Find in All (Manual Entry)"   , "VVAbGw"    ))
  VVZJ87.append(("Find in TV"       , "VVdlQ7"    ))
  VVZJ87.append(("Find in Radio"      , "VV3rmD"   ))
  if self.VVfh6o():
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Hide Channel: %s" % self.servName , "VV0BBx"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Zap History"       , "VVesyd"    ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("IPTV Tools"       , "iptv"      ))
  VVZJ87.append(("PIcons Tools"       , "PIconsTools"     ))
  VVZJ87.append(("Services/Channels Tools"    , "ChannelsTools"    ))
  VVZJ87.append(("EPG Tools"       , "epgTools"     ))
  FFmmH7(self, VVZJ87=VVZJ87, title=title)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self)
  if self.isFindMode:
   self.VVG8qK(self.VVCskv())
 def VVxCTS(self):
  global VVc5QS
  VVc5QS = self["myMenu"].l.getCurrentSelection()[0]
  item   = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "VVAbGw"    : self.VVAbGw()
   elif item == "VV6gXu" : self.VV6gXu()
   elif item == "VVdlQ7"    : self.VVdlQ7()
   elif item == "VV3rmD"   : self.VV3rmD()
   elif item == "VV0BBx"   : self.VV0BBx()
   elif item == "VVesyd"    : self.VVesyd()
   elif item == "iptv"       : self.session.open(CC9X9s)
   elif item == "PIconsTools"     : self.session.open(CCijoe)
   elif item == "ChannelsTools"    : self.session.open(CCdAiy)
   elif item == "epgTools"      : self.session.open(CCvWMS)
   if item in ("iptv", "PIconsTools", "ChannelsTools"):
    self.close()
 def VVdlQ7(self) : self.VVG8qK(self.VVE5Gd)
 def VV3rmD(self) : self.VVG8qK(self.VV0M7o)
 def VVAbGw(self) : self.VVG8qK(self.VVUOgz)
 def VVG8qK(self, mode):
  title = "Find %s Service" % ("TV", "Radio", "All")[mode]
  FFaSvq(self, BF(self.VVPW6Z, mode), defaultText=self.findTxt, title=title, message="Enter Name:")
 def VV6gXu(self):
  filterObj = CCdUgX(self)
  filterObj.VV4D6G(self.VV9ExK)
 def VV9ExK(self, item):
  self.VVPW6Z(self.VVUOgz, item)
 def VVfh6o(self):
  if self.servName.strip() == ""      : return False
  if self.refCode.strip()  == ""      : return False
  if self.refCode.startswith("1:7:1:0:0:0:0:0:0:0:") : return False
  if FF4Jai(self.refCode)        : return False
  return True
 def VVPW6Z(self, mode, VVzirJ):
  FFJsIX(self, BF(self.VVAOqq, mode, VVzirJ), title="Searching ...")
 def VVAOqq(self, mode, VVzirJ):
  if VVzirJ:
   VVzirJ = VVzirJ.strip()
  if VVzirJ:
   self.findTxt = VVzirJ
   CFG.lastFindContextFind.setValue(VVzirJ)
   if   mode == self.VVE5Gd  : titlTxt, servTypes = "TV"  , service_types_tv
   elif mode == self.VV0M7o : titlTxt, servTypes = "Radio"  , service_types_radio
   else          : titlTxt, servTypes = "All" , "1:7:"
   title = 'Find %s : "%s"' % (titlTxt, VVzirJ)
   if len(title) > 55:
    title = title[:55] + ".."
   VVX3wb = self.VVUj3C(VVzirJ, servTypes)
   if self.isFindMode or mode == self.VVUOgz:
    VVX3wb += self.VVBJ5n(VVzirJ)
   if VVX3wb:
    VVX3wb.sort(key=lambda x: x[0].lower())
    VV0xpR = self.VVxknP
    VVwmV1  = ("Zap"   , self.VVjOO7    , [])
    VVX66G = ("Current Service", self.VVQHWf , [])
    VVIrDY = ("Options"  , self.VViSSl , [])
    VVs5AA = (""    , self.VVaqlx , [])
    header   = ("Name" , "Type", "Ref.", "Sat.", "Freq." , "Pol.", "FEC" , "SR" )
    widths   = (38  , 17 , 0  , 10 , 10  , 7  , 8  , 10 )
    VVFvCJ  = (LEFT  , CENTER, LEFT  , CENTER, CENTER , CENTER, CENTER, CENTER)
    FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VV0xpR=VV0xpR, VVX66G=VVX66G, VVIrDY=VVIrDY, VVs5AA=VVs5AA, lastFindConfigObj=CFG.lastFindContextFind)
   else:
    self.VVG8qK(self.VVCskv())
    FF15cM(self, "Not found", title=title)
  elif self.isFindMode:
   self.close()
  else:
   self.findTxt = self.servName
 def VVUj3C(self, VVzirJ, servTypes):
  VVarfR = CCdAiy.VVTLlJ(servTypes)
  VVX3wb = []
  if VVarfR:
   VVqcet, VVT9rY = FFHW7H()
   tp = CCyH2c()
   words, asPrefix = CCdUgX.VV0Xfy(VVzirJ)
   colorYellow  = CCspY4.VV0CtV(VVVCGb)
   colorWhite  = CCspY4.VV0CtV(VVqFea)
   for s in VVarfR:
    name = s[1]
    for word in words:
     ok = False
     tName = name.lower()
     if asPrefix:
      if tName.startswith(word):
       ok = True
     elif word in tName:
      ok = True
     if ok:
      refCode = s[0]
      if refCode.count(":") > 8:
       if asPrefix:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, count=1, flags=IGNORECASE)
       else:
        name = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (colorYellow, colorWhite), name, flags=IGNORECASE)
       sat = FFPqiq(refCode, False)
       STYPE  = refCode.split(":")[2]
       sTypeInt = int(STYPE, 16)
       if sTypeInt in VVqcet:
        STYPE = VVT9rY[sTypeInt]
       freq, pol, fec, sr, syst = tp.VVZ8Ib(refCode)
       if not "-S" in syst:
        sat = syst
       VVX3wb.append((name, STYPE, refCode, sat, freq, pol, fec, sr))
  return VVX3wb
 def VVBJ5n(self, VVzirJ):
  VVzirJ = VVzirJ.lower()
  VVX3wb = []
  colorYellow  = CCspY4.VV0CtV(VVVCGb)
  colorWhite  = CCspY4.VV0CtV(VVqFea)
  for b in CCSrvY.VVcTqV():
   VV1h0S  = b[0]
   VVzWJg  = b[1].toString()
   VVnPFY = eServiceReference(VVzWJg)
   VVAFho = FFw4Nf(VVnPFY)
   for service in VVAFho:
    refCode  = service[0]
    if FF4Jai(refCode):
     servName = service[1]
     if VVzirJ in servName.lower():
      servName = iSub(r"(%s)" % iEscape(VVzirJ), r"%s\1%s" % (colorYellow, colorWhite), servName, flags=IGNORECASE)
      VVX3wb.append((servName, "IPTV", refCode, "-", "-", "-", "-", "-"))
  return VVX3wb
 def VVCskv(self):
  VVhMBa = InfoBar.instance
  if VVhMBa:
   VVsufg = VVhMBa.servicelist
   if VVsufg:
    return VVsufg.mode == 1
  return self.VVUOgz
 def VVxknP(self, VVxBfP):
  self.close()
  VVxBfP.cancel()
 def VVjOO7(self, VVxBfP, title, txt, colList):
  FFkwBg(VVxBfP, colList[2], VVIC8r=False, checkParentalControl=True)
 def VVQHWf(self, VVxBfP, title, txt, colList):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(VVxBfP)
  if refCode:
   VVxBfP.VVr96u(2, FFunPR(refCode, iptvRef, chName), True)
 def VViSSl(self, VVxBfP, title, txt, colList):
  servName = colList[0]
  mSel = CCHw3d(self, VVxBfP)
  VVZJ87, cbFncDict = CCdAiy.VVoNaY(self, VVxBfP, servName, 2)
  mSel.VVsKHw(VVZJ87, cbFncDict)
 def VVaqlx(self, VVxBfP, title, txt, colList):
  chName = colList[0]
  refCode = colList[2]
  ndx = txt.find("Sat.")
  if ndx > -1:
   txt = txt[:ndx]
  FFcpNw(self, fncMode=CCjQ0P.VVLHuP, refCode=refCode, chName=chName, text=txt)
 def VV0BBx(self):
  FFNKVM(self, self.VVj0Ot, 'Hide "%s" ?' % self.servName, title="Hide Channel")
 def VVj0Ot(self):
  ret = FFxl59(self.refCode, True)
  if ret:
   self.VVjDuX()
   self.close()
  else:
   FF5uKN(self, "Cannot change state" , 1000)
 def VVjDuX(self):
  if self.csel:
   self.csel.servicelist.removeCurrent()
  try:
   self.VVdxx1()
  except:
   self.VVwC3M()
  if self.refCode.count(":") > 8:
   servRef = self.session.nav.getCurrentlyPlayingServiceReference()
   if servRef and self.refCode in servRef.toString():
    self.session.nav.stopService()
    if self.csel:
     serviceRef = self.csel.servicelist.getCurrent()
     if serviceRef:
      FFeWbP(self, serviceRef)
 def VVdxx1(self):
  if self.refCode:
   servRef = eServiceReference(self.refCode)
   VVhMBa = InfoBar.instance
   if VVhMBa:
    VVsufg = VVhMBa.servicelist
    if VVsufg:
     hList = VVsufg.history
     newList = []
     for rec in hList:
      for servRef in rec:
       if self.refCode in servRef.toString():
        break
      else:
       newList.append(rec)
     if newList:
      oldLen = len(hList)
      newLen = len(newList)
      diff = oldLen - newLen
      if not diff == 0:
       pos = VVsufg.history_pos - diff
       if pos > newLen -1 : pos = newLen - 1
       if pos < 0   : pos = 0
       VVsufg.history  = newList
       VVsufg.history_pos = pos
 def VVwC3M(self):
  VVhMBa = InfoBar.instance
  if VVhMBa:
   VVsufg = VVhMBa.servicelist
   if VVsufg:
    VVsufg.history  = []
    VVsufg.history_pos = 0
 def VVesyd(self):
  VVhMBa = InfoBar.instance
  VVX3wb = []
  if VVhMBa:
   VVsufg = VVhMBa.servicelist
   if VVsufg:
    VVqcet, VVT9rY = FFHW7H()
    for serv in VVsufg.history:
     refCode = serv[-1].toString()
     chName = FFyNG3(refCode)
     path = serv[-1].getPath()
     isLocal = path and path.startswith("/")
     isIptv = FF4Jai(refCode)
     isSRel = FFqWLZ(refCode)
     sat = "-" if isIptv and not isSRel or isLocal else FFPqiq(refCode, True)
     if isIptv : STYPE = "Stream Relay" if isSRel else "IPTV"
     elif isLocal: STYPE = "Local Media"
     else:
      STYPE  = refCode.split(":")[2]
      sTypeInt = int(STYPE, 16)
      if sTypeInt in VVqcet:
       STYPE = VVT9rY[sTypeInt]
     VVX3wb.append((chName, sat, STYPE, refCode))
  title = "Zap History"
  if VVX3wb:
   VVwmV1  = ("Zap"   , self.VVbfQG   , [])
   VVIrDY = ("Clear History" , self.VVB8jm   , [])
   VVs5AA = (""    , self.VVu2IU , [] )
   header   = ("Service Name", "Satellite" , "Type" , "Ref. Code" )
   widths   = (41    , 41   , 18  , 0    )
   VVFvCJ  = (LEFT    , LEFT   , CENTER , LEFT   )
   FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=28, VVwmV1=VVwmV1, VVIrDY=VVIrDY, VVs5AA=VVs5AA)
  else:
   FF15cM(self, "History is empty.", title=title)
 def VVbfQG(self, VVxBfP, title, txt, colList):
  FFkwBg(VVxBfP, colList[3], VVIC8r=False, checkParentalControl=True)
 def VVB8jm(self, VVxBfP, title, txt, colList):
  FFNKVM(self, BF(self.VVKBp8, VVxBfP), "Clear Zap History ?")
 def VVKBp8(self, VVxBfP):
  self.VVwC3M()
  VVxBfP.cancel()
 def VVu2IU(self, VVxBfP, title, txt, colList):
  chName = colList[0]
  refCode = colList[3]
  FFcpNw(self, fncMode=CCjQ0P.VVoozH, refCode=refCode, chName=chName, text=txt)
 @staticmethod
 def VVzEzC():
  try:
   global VVDCOh
   if VVDCOh is None:
    VVDCOh    = ChannelContextMenu.__init__
   ChannelContextMenu.__init__   = CC42f6.VVYgG8
   ChannelContextMenu.VVtJrw = CC42f6.VVtJrw
  except:
   pass
 @staticmethod
 def VVYgG8(SELF, session, csel):
  from Components.ChoiceList import ChoiceEntryComponent
  VVDCOh(SELF, session, csel)
  if CFG.showInChannelListMenu.getValue():
   t = ( PLUGIN_NAME + " - Channels Browser"
    , PLUGIN_NAME + " - Find"
    , PLUGIN_NAME + " - Channels Tools"  )
   for i in range(3):
    SELF["menu"].list.insert(i, ChoiceEntryComponent(key=" ", text=(t[i] , BF(SELF.VVtJrw, t[i], csel, mode=i))))
 @staticmethod
 def VVtJrw(self, title, csel, mode):
  try:
   currSel  = csel.getCurrentSelection()
   refCode  = currSel.toString()
   refName  = FFyNG3(refCode)
  except:
   refCode = refName = ""
  if mode == 0: CC3TAu.VVjodP(self)
  else  : self.session.open(BF(CC42f6, title=title, csel=csel, refCode=refCode, servName=refName, isFind=True if mode == 1 else False))
  self.close()
class CCijoe(Screen, CCIoFg, CC6gLq):
 VV3a50   = 0
 VVdp3Z  = 1
 VVVAyQ  = 2
 VVZb86  = 3
 VVpHTA  = 4
 VVJ67O  = 5
 VV82l0  = 6
 VVhrPP  = 7
 VVBpfD = 8
 VVC5Nk = 9
 VVYSFl = 10
 VVQMlx = 11
 def __init__(self, session):
  self.skin, self.skinParam = FFRBRO(VVa8YL, 1400, 840, 30, 0, 0, "#22201000", "#33000000", 30, barHeight=40, topRightBtns=2, vSliderW=20)
  self.session   = session
  self.Title    = "PIcons Tools"
  self.pPath    = CCijoe.VV4boJ()
  self.curChanName  = ""
  self.curChanFile  = ""
  self.curChanIndex  = -1
  self.curChanRefCode  = 0
  self.curChanIptvRef  = ""
  self.VVarfR    = []
  self.nsList    = set()
  self.lastSortCol  = 0
  self.lastMode   = 0
  self.lastWords   = ['']
  self.lastAsPrefix  = False
  self.lastTimeStamp  = 0
  self.lastSTypeList  = 0
  self.lastFind   = ""
  self.filterTitle  = ""
  FFmmH7(self, self.Title)
  FFR9Qm(self["keyRed"] , "OK = Zap")
  FFR9Qm(self["keyGreen"] , "Current Service")
  FFR9Qm(self["keyYellow"], "Page Options")
  FFR9Qm(self["keyBlue"] , "Filter")
  CCIoFg.__init__(self, 5, 7, CFG.transpColorPicons)
  CC6gLq.__init__(self)
  self["myAction"].actions.update(
  {
   "ok"  : self.VVwn9M     ,
   "green"  : self.VVVEUn    ,
   "yellow" : self.VVgoH8     ,
   "blue"  : self.VVbEJF     ,
   "menu"  : self.VVj67V     ,
   "info"  : self.VV0oiN    ,
   "pageUp" : BF(self.VVcmmO, True) ,
   "chanUp" : BF(self.VVcmmO, True) ,
   "pageDown" : BF(self.VVcmmO, False) ,
   "chanDown" : BF(self.VVcmmO, False) ,
   "0"   : self.VVHvPA  ,
   "cancel" : self.close
  })
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFj9eW(self)
  FFHLqT(self)
  FFWN9Z(self["keyRed"], "#0a333333")
  self.VVBCeA()
  self.VVxLQD()
  FFJsIX(self, BF(self.VVpoDy, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, isFirstTime=True))
 def VVj67V(self):
  if not self.isBusy:
   VVZJ87 = []
   VVZJ87.append(("Statistics"           , "VVtdMl"    ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Suggest PIcons for Current Channel"     , "VVxT3t"   ))
   VVZJ87.append(("Set to Current Channel (copy file)"     , "VVoWs3_file"  ))
   VVZJ87.append(("Set to Current Channel (as SymLink)"     , "VVoWs3_link"  ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Export Current File Names List"      , "VVd93y" ))
   VVZJ87.append(CCijoe.VV5A2L())
   VVZJ87.append(VVoqHH)
   c, cond = VVLbyB, self.filterTitle == "PIcons without Channels"
   VVZJ87.append(FFnqNr("Move Unused PIcons to a Directory", "VV8ew7" , cond, c))
   VVZJ87.append(FFnqNr("DELETE Unused PIcons"    , "VVE6RA" , cond, c))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Delete Broken PIcons SymLinks (in PIcons Directory)" , "VV5kyR"  ))
   VVZJ87.append(VVoqHH)
   VVZJ87 += CCijoe.VVuPbO()
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Change Poster/Picon Transparency Color"    , "VVkqAc" ))
   VVZJ87.append(("Keys Help"           , "VVonME"    ))
   FFYySC(self, self.VVzO14, width=1100, height=1050, title=self.Title, VVZJ87=VVZJ87)
 def VVzO14(self, item=None):
  if item is not None:
   if   item == "VVtdMl"    : self.VVtdMl()
   elif item == "VVxT3t"   : self.VVxT3t()
   elif item == "VVoWs3_file"  : self.VVoWs3(0)
   elif item == "VVoWs3_link"  : self.VVoWs3(1)
   elif item == "VVd93y"  : self.VVd93y()
   elif item == "VVsVVN"  : CCijoe.VVsVVN(self)
   elif item == "VV8ew7"   : self.VV8ew7()
   elif item == "VVE6RA"  : self.VVE6RA()
   elif item == "VV5kyR"  : self.VV5kyR()
   elif item == "VVi5EK"  : CCijoe.VVi5EK(self)
   elif item == "findPiconBrokenSymLinks" : CCijoe.VVVQKj(self, True)
   elif item == "FindAllBrokenSymLinks" : CCijoe.VVVQKj(self, False)
   elif item == "VVkqAc" : self.VVkqAc()
   elif item == "VVonME"     : FFqsYG(self, "_help_picons", "PIcons Tools (Keys Help)")
 def VVgoH8(self):
  if not self.isBusy:
   VVZJ87 = []
   VVZJ87.append(("Go to First PIcon"  , "VVOtGy"  ))
   VVZJ87.append(("Go to Last PIcon"   , "VVNKOq"  ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Sort by Channel Name"     , "sortByChan" ))
   VVZJ87.append(("Sort by File Name"  , "sortByFile" ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Find from File List .." , "VVZ3Ug" ))
   FFYySC(self, self.VVAZEi, title=self.Title, VVZJ87=VVZJ87)
 def VVAZEi(self, item=None):
  if item is not None:
   if   item == "VVOtGy"   : self.VVOtGy()
   elif item == "VVNKOq"   : self.VVNKOq()
   elif item == "sortByChan"  : self.VVvK29(2)
   elif item == "sortByFile"  : self.VVvK29(0)
   elif item == "VVZ3Ug"  : self.VVZ3Ug()
 def VVZ3Ug(self):
  VVZJ87 = []
  for item in self.VVarfR:
   VVZJ87.append((item[0], item[0]))
  FFYySC(self, self.VVY7dZ, title='PIcons ".png" Files', VVZJ87=VVZJ87, VV18hv=True)
 def VVY7dZ(self, item=None):
  if item:
   txt, ref, ndx = item
   self.VVdh99(ndx)
 def VVwn9M(self):
  if not self.isBusy and self["keyRed"].getVisible():
   filName, refCode, chName, sat, inDB = self.VVqe46()
   if refCode:
    FFkwBg(self, refCode)
    self.VVtipE()
    self.VVJpuW()
 def VVcmmO(self, isUp):
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.VVtipE()
   self.VVJpuW()
  except:
   pass
 def VVVEUn(self):
  if self["keyGreen"].getVisible():
   self.VVdh99(self.curChanIndex)
 def VVvK29(self, col):
  reverseSort = self.lastSortCol == col
  self.lastSortCol = col
  FFJsIX(self, BF(self.VVpoDy, mode=self.lastMode, words=self.lastWords, asPrefix=self.lastAsPrefix, reverseSort=reverseSort), title="Sorting ...")
 def VVoWs3(self, mode):
  title = "Change Current Channel PIcon"
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  curChF = "%s%s.png" % (self.pPath, refCode.replace(":", "_"))
  if refCode:
   filName, refCode, chName, sat, inDB = self.VVqe46()
   selPiconF = "%s%s"  % (self.pPath, filName)
   if not curChF == selPiconF:
    if fileExists(curChF):
     VVZJ87 = []
     VVZJ87.append(("Overwrite current PIcon"    ,  "overwrite" ))
     VVZJ87.append(('Rename current PIcon to ".bak.png"' ,  "backup" ))
     FFYySC(self, BF(self.VVyRMP, mode, curChF, selPiconF), VVZJ87=VVZJ87, title="Current Channel PIcon (already exists)")
    else:
     self.VVyRMP(mode, curChF, selPiconF, "overwrite")
   else:
    FFw5OO(self, "Cannot change PIcon to itself !", title=title)
  else:
   FFw5OO(self, "Could not read current channel info. !", title=title)
 def VVyRMP(self, mode, curChF, selPiconF, item=None):
  if item is not None:
   cmd  = ""
   if item == "backup" : cmd += "mv -f '%s' '%s';" % (curChF, curChF + ".bak.png")
   else    : cmd += "rm -f '%s';" % curChF
   if mode == 0: cmd += "cp -f '%s' '%s'" % (selPiconF, curChF)
   else  : cmd += "ln -sf '%s' '%s'" % (selPiconF, curChF)
   FFuB0V(cmd)
   FFJsIX(self, BF(self.VVpoDy, goToFirst=False), title="PIcon Changed.\nRefreshing ...")
 def VV8ew7(self):
  defDir = FF1vNj(CCijoe.VV4boJ() + "picons_backup")
  FFuB0V("mkdir '%s'" % defDir)
  self.session.openWithCallback(BF(self.VVIVww, defDir), BF(CCCXvS
         , mode=CCCXvS.VVutD6, VVMbDq=CCijoe.VV4boJ()))
 def VVIVww(self, defDir, path):
  if len(path) > 0:
   title = "Move Unused PIcons"
   if path == CCijoe.VV4boJ():
    FFw5OO(self, "Cannot move to same directory !", title=title)
   else:
    if not FF1vNj(path) == FF1vNj(defDir):
     self.VVaWQi(defDir)
    FFNKVM(self, BF(FFJsIX, self, BF(self.VVAS6z, title, defDir, path), title="Moving Files ..."), "Move %d files to:\n\n%s" % (len(self.VVarfR), path), title=title)
  else:
   self.VVaWQi(defDir)
 def VVAS6z(self, title, defDir, toPath):
  if not iMove:
   self.VVaWQi(defDir)
   FFw5OO(self, "Module not found:\n\nshutil", title=title)
   return
  toPath = FF1vNj(toPath)
  pPath = CCijoe.VV4boJ()
  err  = ""
  totOK = 0
  for fName, fType, chName, sat, inDB in self.VVarfR:
   if fName:
    fName += ".png"
    From = "%s%s" % (pPath, fName)
    try:
     iMove(From, "%s%s" % (toPath, fName))
     totOK +=1
    except Exception as e:
     err  = "\nError while moving the file:\n   %s\n\n" % From
     err += "Error:\n   %s" % str(e)
     break
  txt  = "Files\t: %d\n" % len(self.VVarfR)
  txt += "Moved\t: %d\n" % totOK
  txt += err
  FF90Bc(self, txt, title=title, VVzgHY="#22330000" if err else "#22002020")
  if totOK > 0:
   self.VV2kaa("all")
 def VVaWQi(self, defDir):
  try:
   os.rmdir(defDir)
  except:
   pass
 def VVE6RA(self):
  title = "Delete Unused PIcons"
  tot = len(self.VVarfR)
  FFNKVM(self, BF(FFJsIX, self, BF(self.VVVX2u, title), title="Deleting Files ..."), "Delete %s unused PIcon file%s ?" % (tot, FF1I1d(tot)), title=title)
 def VVVX2u(self, title):
  pPath = CCijoe.VV4boJ()
  totErr = 0
  for fName, fType, chName, sat, inDB in self.VVarfR:
   if fName:
    fName = "%s%s.png" % (pPath, fName)
    try:
     os.remove(fName)
    except:
     totErr += 1
  tot = len(self.VVarfR)
  txt  = "Found\t: %d\n"  % tot
  txt += "Deleted\t: %d\n" % (tot - totErr)
  if totErr:
   txt += "Errors\t: %s" % FFGB9z(str(totErr), VVsObI)
  FF90Bc(self, txt, title=title)
 def VV5kyR(self):
  lines = FFnAC3("find -L '%s' -type l -print" % self.pPath)
  if lines:
   tot = len(lines)
   FFNKVM(self, BF(self.VVo6dg, lines), "\n".join(lines), title="Delete %d Broken SymLink%s ?" % (tot, FF1I1d(tot)), VV4evd=True)
  else:
   FF15cM(self, "No broken SymLinks in:\n\n%s" % self.pPath)
 def VVo6dg(self, fList):
  FFuB0V("find -L '%s' -type l -delete" % self.pPath)
  FF15cM(self, "Files deleted:\n\n%s" % "\n".join(fList), title=self.Title)
 def VV0oiN(self):
  FFJsIX(self, self.VVqcEW)
 def VVqcEW(self):
  if self.isBusy:
   return
  filName, refCode, chName, sat, inDB = self.VVqe46()
  if filName:
   path = self.pPath + filName
   txt  = ""
   txt += FFGB9z("PIcon Directory:\n", VVkqaK)
   txt += "  Path\t: %s\n"  % self.pPath
   target = FFGQYc(self.pPath)
   if target:
    txt += "  Target\t: %s\n" % target
   txt += "\n"
   target = FFGQYc(path)
   txt += FFGB9z("PIcon File:\n", VVkqaK)
   if target:
    txt += "  SymLink\t: %s\n"   % filName
    txt += "  Target File\t: %s\n" % (os.path.dirname(target) + "/" + os.path.basename(target))
   else:
    txt += "  File\t: %s\n" % filName
   txt += "\n"
   slLst = []
   if not os.path.islink(path):
    OrigRealPath = os.path.realpath(path)
    for fName in os.listdir(self.pPath):
     fPath = os.path.join(self.pPath, fName)
     if os.path.islink(fPath):
      fRealPath = os.path.realpath(fPath)
      if fRealPath == OrigRealPath:
       slLst.append(fRealPath)
    if slLst:
     tot = len(slLst)
     txt += FFGB9z("Found %d SymLink%s to this file from:\n" % (tot, FF1I1d(tot)), VVkqaK)
     for fPath in slLst:
      txt += "  %s\n" % FFGB9z(fPath, VVGb6D)
     txt += "\n"
   if chName:
    txt += FFGB9z("Channel:\n", VVkqaK)
    if refCode:
     txt += "  Reference\t: %s\n" % (refCode)
    txt += "  Channel\t: %s\n" % FFGB9z(chName, VVVjNM)
    if sat and not sat == "IPTV":
     txt += "  Satellite\t: %s" % sat
   elif not slLst:
    txt += FFGB9z("Remarks:\n", VVkqaK)
    txt += "  %s\n" % FFGB9z("Unused", VVsObI)
  else:
   txt = "No info found"
  FFcpNw(self, fncMode=CCjQ0P.VVPCZ6, refCode=refCode, chName=chName, text=txt, picPath=self.pPath + filName)
 def VVqe46(self):
  fName = refCode = chName = sat = inDB = ""
  if self.curIndex > -1 and self.curIndex < self.totalItems:
   fName, fType, chName, sat, inDB = self.VVarfR[self.curIndex]
   if fName.count("_") > 8 : refCode = fName.replace("_", ":").upper()
   else     : refCode = ""
   fName += ".png"
   sat  = FF0JDR(sat)
  return fName, refCode, chName, sat, inDB
 def VVtipE(self):
  self.curChanName = ""
  self.curChanFile = ""
  self.curChanIndex = -1
  self.curChanRefCode = ""
  self.curChanIptvRef = ""
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  if refCode:
   self.curChanRefCode = refCode
   self.curChanName = chName
   self.curChanFile = self.curChanRefCode.rstrip(":").replace(":", "_")
   self.curChanIptvRef = iptvRef
   path = self.pPath + self.curChanFile + ".png"
   self["myPiconF"].hide()
   self["myPiconBG"].hide()
   self["myPiconPic"].hide()
   if fileExists(path):
    try:
     self["myPiconPic"].instance.setPixmapFromFile(path)
     self["myPiconF"].show()
     self["myPiconBG"].show()
     self["myPiconPic"].show()
    except:
     pass
   for ndx, item in enumerate(self.VVarfR):
    if item[0] == self.curChanFile:
     self.curChanIndex = ndx
     break
  if self.curChanIndex > -1 : self["keyGreen"].show()
  else       : self["keyGreen"].hide()
 def VVJpuW(self):
  title = "  " + self.Title
  if self.filterTitle:
   title += "  ..  Filter = " + self.filterTitle
  if len(title) > 65:
   title = title[:65] + ".."
  self["myTitle"].setText(title)
  tabLft = " " * 4
  filName, refCode, chName, sat, inDB = self.VVqe46()
  fNum = "Num. : %d / %d" % (self.curIndex + 1, self.totalItems)
  page = "Page: %d / %d"  % (self.curPage + 1, self.totalPages)
  self["myPiconInf0"].setText(FFGB9z("%s%s%s%s" % (tabLft, fNum, " " * 12, page), VVkqaK))
  self["myPiconInf1"].setText("%sFile : %s" % (tabLft, filName))
  self["myPiconInf2"].setText("%sRef. : %s" % (tabLft, self.VVqe46()[1]))
  if self.curChanIptvRef : typ = "Stream Relay" if FFqWLZ(self.curChanIptvRef) else "IPTV"
  else     : typ = "Current Ch."
  self["myPiconInf3"].setText("%s%s : %s" % (tabLft, typ, FFGB9z(self.curChanName, VVVCGb)))
  self["myPiconInf4"].setText("%sFile : %s\n" % (tabLft, (self.curChanFile + ".png")))
  self["myPiconInf5"].setText("%sRef. : %s" % (tabLft, self.curChanRefCode))
  filName, refCode, chName, sat, inDB = self.VVqe46()
  if inDB and not sat == "IPTV" : self["keyRed"].show()
  else       : self["keyRed"].hide()
 def VVtdMl(self):
  VVqcet, VVT9rY = FFHW7H()
  sTypeNameDict = {}
  for key, val in VVT9rY.items():
   sTypeNameDict[key] = 0
  totUsedFiles = 0
  totUsedLinks = 0
  totSymLinks  = 0
  totInDB   = 0
  totNoRefCode = 0
  totNoSType  = 0
  sTypeDict  = {}
  for fName, fType, chName, sat, inDB in self.VVarfR:
   if chName:
    if fType == 0 : totUsedFiles += 1
    else   : totUsedLinks += 1
   if fType == 1:
    totSymLinks += 1
   if inDB == 1:
    totInDB += 1
   span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
   if span:
    stNum = int(span.group(1), 16)
    if stNum in VVT9rY: sTypeDict[VVT9rY[stNum]] = sTypeDict.get(VVT9rY[stNum], 0) + 1
    else     : totNoSType += 1
   else:
    totNoRefCode += 1
  totBrokSL = FF3RLi("find -L '%s' -type l -print | wc -l" % self.pPath)
  VVX3wb = []
  c = "#b#11003333#"
  VVX3wb.append((c + "PIcons" , "%d\tUsed = %s" % (self.totalItems, totUsedFiles + totUsedLinks)))
  VVX3wb.append((c + "Files" , "%d\tUsed = %s" % (self.totalItems - totSymLinks, totUsedFiles)))
  VVX3wb.append((c + "SymLinks" , "%d\tUsed = %s" % (totSymLinks, totUsedLinks)))
  c = "#b#11004040#"
  VVX3wb.append((c + "In Database (lamedb)"  , str(totInDB)))
  VVX3wb.append((c + "Not In Database (lamedb)" , str(self.totalItems - totInDB)))
  VVX3wb.append((c + "Satellites"    , str(len(self.nsList))))
  VVX3wb.append((c + "Broken SymLinks"   , str(totBrokSL)))
  if totNoRefCode : VVX3wb.append((c + "File name is not a Reference Code" , str(totNoRefCode)))
  if totNoSType : VVX3wb.append((c + "Unknown Service Type"    , str(totNoSType)))
  s = "Service Type "
  if sTypeDict:
   sTypeRows = []
   for key, val in sTypeDict.items():
    sTypeRows.append(("Service Type (%s)" % key, str(val)))
   sTypeRows.sort(key=lambda x: x[0].lower())
   VVX3wb.extend(sTypeRows)
  FF1Dpj(self, None, title=self.Title, VVarfR=VVX3wb, VVTFXq=28, VVkUYa="#00003333", VVivoO="#00222222")
 def VVd93y(self):
  if self.filterTitle:
   txt = iSub(r"([^a-zA-Z0-9])", r"_", self.filterTitle, flags=IGNORECASE)
   while "__" in txt: txt = txt.replace("__", "_")
   txt = "FilteredBy_%s_" % txt.strip("_")
  else:
   txt = "All_"
  path = "%sPIconsList_%s%s.txt" % (FF1vNj(CFG.exportedTablesPath.getValue()), txt, FFUD38())
  with open(path, "w") as f:
   for fName, fType, chName, sat, inDB in self.VVarfR:
    f.write("%s%s.png\n" % (self.pPath, fName))
  FF15cM(self, "List exported to file:\n\n%s" % path, title=self.Title)
 def VVbEJF(self):
  if not self.isBusy:
   VVZJ87 = []
   VVZJ87.append(("All"        , "all"  ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Used by Channels"     , "used" ))
   VVZJ87.append(("Unused PIcons"     , "unused" ))
   VVZJ87.append(("IPTV PIcons"      , "iptv" ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("PIcons Files"      , "pFiles" ))
   VVZJ87.append(("SymLinks to PIcons"    , "pLinks" ))
   VVZJ87.append(("PIcons Files Targeted by SymLinks", "pTargets"))
   VVZJ87.append(("By Files Date ..."    , "pDate" ))
   VVZJ87.append(("By Service Type ..."    , "servType"))
   if self.nsList:
    VVZJ87.append(FFHf46("Satellites"))
    satsHex = list(self.nsList)
    satsHex.sort()
    for sHex in satsHex:
     val = int(sHex, 16)
     if val > 0:
      sat = FFXHW8(val)
      VVZJ87.append((sat, "__s__" + sHex + "__sat__" + sat))
   filterObj = CCdUgX(self)
   filterObj.VV0Gkf(VVZJ87, self.nsList, self.VV98hR)
 def VV98hR(self, item=None):
  if item is not None:
   self.VV2kaa(item)
 def VV2kaa(self, item=None):
   if   item == "all"    : mode, words, self.filterTitle = self.VV3a50   , ""  , ""
   elif item == "used"    : mode, words, self.filterTitle = self.VVdp3Z   , ""  , "PIcons with Channels"
   elif item == "unused"   : mode, words, self.filterTitle = self.VVVAyQ  , ""  , "PIcons without Channels"
   elif item == "iptv"    : mode, words, self.filterTitle = self.VV82l0   , "iptv" , "IPTV PIcons"
   elif item == "pFiles"   : mode, words, self.filterTitle = self.VVZb86  , ""  , "PIcons Files"
   elif item == "pLinks"   : mode, words, self.filterTitle = self.VVpHTA  , ""  , "SymLinks"
   elif item == "pTargets"   : mode, words, self.filterTitle = self.VVJ67O  , ""  , "Targets"
   elif item == "pDate"   : mode, words, self.filterTitle = self.VVYSFl , ""  , "Date"
   elif item == "servType"   : mode, words, self.filterTitle = self.VVQMlx , ""  , "Service Type"
   elif item.startswith("__s__") : mode, words, self.filterTitle = self.VVhrPP   , item[5:].split("__sat__")[0] , item[5:].split("__sat__")[1]
   elif item.startswith("__w__") : mode, words, self.filterTitle = self.VVBpfD , item[5:] , item[5:]
   else       : return
   asPrefix = self.lastAsPrefix
   if mode == self.VVJ67O:
    words = []
    pngFiles = self.pPath + "*.png"
    lines = FFnAC3("find %s -type l | while read -r FILE; do if [ -L \"$FILE\" ] && [ -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=$10=\"\";print}' | xargs; fi; done" % pngFiles)
    if lines:
     for f in lines:
      fName = FF65m2(f)
      if fName.endswith(".png"):
       fName = fName[:-4]
       words.append(fName)
    if not words:
     FF5uKN(self, "Not found", 1000)
     return
   elif mode == self.VVYSFl:
    self.VVQhKi(mode)
    return
   elif mode == self.VVQMlx:
    self.VVEkG1(mode)
    return
   elif mode == self.VVC5Nk:
    return
   else:
    words, asPrefix = CCdUgX.VV0Xfy(words)
   if not words and mode in (self.VVhrPP, self.VVBpfD):
    FF5uKN(self, "Incorrect filter", 2000)
   elif not self.lastMode == mode or not self.lastWords == words or not self.lastAsPrefix == asPrefix:
    FFJsIX(self, BF(self.VVpoDy, mode=mode, words=words, asPrefix=asPrefix), title="Filtering ...", clearMsg=False)
 def VVQhKi(self, mode):
  VVZJ87 = []
  VVZJ87.append(("Today"   , "today" ))
  VVZJ87.append(("Since Yesterday" , "yest" ))
  VVZJ87.append(("Since 7 days"  , "week" ))
  FFYySC(self, BF(self.VVcu63, mode), VVZJ87=VVZJ87, title="Filter by Added/Modified Date")
 def VVcu63(self, mode, item=None):
  if item:
   if   item == "today": stamp, self.filterTitle = FFznCE(0) , "Today"
   elif item == "yest" : stamp, self.filterTitle = FFznCE(-1), "Yesterday"
   elif item == "week" : stamp, self.filterTitle = FFznCE(-7), "Last 7 Days"
   self.filterTitle = "File Date (%s)" % self.filterTitle
   if not self.lastMode == mode or not self.lastTimeStamp == stamp:
    FFJsIX(self, BF(self.VVpoDy, mode=mode, timeStamp=stamp), title="Filtering ...", clearMsg=False)
 def VVEkG1(self, mode):
  VVqcet, VVT9rY = FFHW7H()
  lst = set()
  for key, val in VVT9rY.items():
   lst.add(val)
  VVZJ87 = []
  for item in lst:
   VVZJ87.append((item, item))
  VVZJ87.sort(key=lambda x: x[0])
  FFYySC(self, BF(self.VVNhhZ, mode), VVZJ87=VVZJ87, title="Filter by Service Type")
 def VVNhhZ(self, mode, item=None):
  if item:
   VVqcet, VVT9rY = FFHW7H()
   sTypeList = []
   for key, val in VVT9rY.items():
    if item == val:
     self.filterTitle = val
     sTypeList.append(("%01x" % key).upper())
   if not self.lastMode == mode or not self.lastSTypeList == sTypeList:
    FFJsIX(self, BF(self.VVpoDy, mode=mode, sTypeList=sTypeList), title="Filtering ...", clearMsg=False)
 def VVxT3t(self):
  self.session.open(CCmNws, barTheme=CCmNws.VVkie3
      , titlePrefix = ""
      , fncToRun  = self.VVfhMY
      , VVCeou = self.VVQmH8)
 def VVfhMY(self, VVXLiB):
  VVht0T, err = CCdAiy.VVcFnp(self, CCdAiy.VVPj3L, VV7D78=False, VVPhms=False)
  files = []
  words = []
  if not VVXLiB or VVXLiB.isCancelled:
   return
  VVXLiB.VVlaij = []
  VVXLiB.VVCnyB(len(VVht0T))
  if VVht0T:
   curCh = self.VVrS8k(self.curChanName)
   for refCode in VVht0T:
    if not VVXLiB or VVXLiB.isCancelled:
     return
    VVXLiB.VV1Vtn(1, True)
    chName, sat, inDB = VVht0T.get(refCode, ("", "", 0))
    ratio = CCijoe.VV5jiJ(chName.lower(), curCh)
    if ratio > 50:
     allPath, fName, refCodeFile, pList = CCijoe.VVsBzM(refCode.replace("_", ":"), self.curChanName)
     if pList:
      for f in pList:
       f = FF65m2(f)
       fil = f.replace(".png", "")
       if not fil in VVXLiB.VVlaij:
        VVXLiB.VVlaij.append(fil)
 def VVQmH8(self, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  if VVlaij : FFJsIX(self, BF(self.VVpoDy, mode=self.VVC5Nk, words=VVlaij), title="Loading ...")
  else   : FF5uKN(self, "Not found", 2000)
 def VVpoDy(self, mode=0, words=None, asPrefix=False, reverseSort=False, isFirstTime=False, goToFirst=True, timeStamp=None, sTypeList=None):
  if not self.VVPo2O(isFirstTime):
   return
  self.isBusy = True
  VVPhms = True if isFirstTime else False
  VVht0T, err = CCdAiy.VVcFnp(self, CCdAiy.VVPj3L, VV7D78=False, VVPhms=VVPhms)
  if err:
   self.close()
  iptvRefList = self.VVlZHP()
  tList = []
  for fName, fType in CCijoe.VV5WZn(self.pPath):
   fName = fName[:-4]
   namSp = ""
   if fName.count("_") > 8 and VVht0T:
    if fName in VVht0T:
     chName, sat, inDB = VVht0T.get(fName)
     chName = chName or "?"
     namSp = fName.split("_")[6].zfill(8)[:4]
    elif fName in iptvRefList:
     chName = iptvRefList.get(fName) or "?"
     sat, inDB = "IPTV", 1
    else:
     chName, sat, inDB = "", "", 0
   else:
    chName, sat, inDB = "", "", 0
   entry = (fName, fType, chName, sat, inDB)
   isAdd = False
   if mode == self.VV3a50:
    if namSp:
     self.nsList.add(namSp)
    isAdd = True
   elif mode == self.VVdp3Z  and chName         : isAdd = True
   elif mode == self.VVVAyQ and not chName        : isAdd = True
   elif mode == self.VVZb86  and fType == 0        : isAdd = True
   elif mode == self.VVpHTA  and fType == 1        : isAdd = True
   elif mode == self.VVJ67O  and fName in words       : isAdd = True
   elif mode == self.VVC5Nk and fName in words       : isAdd = True
   elif mode == self.VV82l0  and sat.lower() == words[0]     : isAdd = True
   elif mode == self.VVhrPP  and namSp.lower() == words[0]    : isAdd = True
   elif mode == self.VVBpfD:
    if asPrefix:
     if any(chName.lower().startswith(x) for x in words)       : isAdd = True
    elif any(x in chName.lower() for x in words)         : isAdd = True
   elif mode == self.VVYSFl:
    try:
     if os.stat("%s%s.png" % (self.pPath, fName)).st_ctime >= timeStamp   : isAdd = True
    except:
     pass
   elif mode == self.VVQMlx:
    span = iSearch(r"(?:[A-Fa-f0-9]+_){2}([A-Fa-f0-9]+)(?:_[A-Fa-f0-9]+){7}", fName, IGNORECASE)
    if span and span.group(1) in sTypeList           : isAdd = True
   if isAdd:
    tList.append(entry)
  if len(tList) > 0:
   self.VVarfR   = list(tList)
   tList    = None
   self.lastMode  = mode
   self.lastWords  = words
   self.lastAsPrefix = asPrefix
   self.lastTimeStamp = timeStamp
   self.lastSTypeList = sTypeList
   FF5uKN(self)
  else:
   self.isBusy = False
   FF5uKN(self, "Not found", 1000)
   return
  self.VVarfR.sort(key=lambda x: x[self.lastSortCol], reverse=reverseSort)
  self.VVtipE()
  self.totalItems = len(self.VVarfR)
  self.totalPages = int(self.totalItems / self.PAGE_ITEMS) + (self.totalItems % self.PAGE_ITEMS > 0)
  if goToFirst:
   self.curPage = 0
   self.curRow  = 0
   self.curCol  = 0
   self.curIndex = 0
   self.lastRow = 0
   self.lastCol = 0
  self.isBusy = False
  self.VVvnUE(True)
 def VVPo2O(self, isFirstTime):
  if fileExists(self.pPath):
   for fName, fType in CCijoe.VV5WZn(self.pPath):
    if fName:
     return True
   if isFirstTime : FFw5OO(self, 'No ".png" files in path:\n\n%s' % self.pPath, title=self.Title)
   else   : FF5uKN(self, "Not found", 1000)
  else:
   FFw5OO(self, "PIcons path not found.\n\n%s" % self.pPath)
  if isFirstTime:
   self.close()
  return False
 def VVlZHP(self):
  VVX3wb = {}
  files  = CC9X9s.VV3Es2()
  if files:
   for path in files:
    txt = FFQ5la(path)
    list = iFindall(r"#SERVICE\s+([A-Fa-f0-9]+:0:(?:[A-Fa-f0-9]+[:]){8}).+\n#DESCRIPTION\s+(.+)", txt, IGNORECASE)
    if list:
     for item in list:
      refCode = item[0].upper().replace(":", "_").strip("_")
      VVX3wb[refCode] = item[1]
  return VVX3wb
 def VVRUUk(self):
  self.VV2QeP()
  f1, f2 = self.VVxFW3()
  row = col = 0
  for ndx in range(f1, f2):
   fName, fType, chName, sat, inDB = self.VVarfR[ndx]
   fName = self.VVarfR[ndx][0]
   path  = self.pPath + fName + ".png"
   refCode  = fName.replace("_", ":").upper()
   self["myPosterRep%d%d" % (row, col)].show()
   pic = self["myPosterPic%d%d" % (row, col)]
   lbl = self["myPosterLbl%d%d" % (row, col)]
   if CCIoFg.VVWEbm(pic, path) : color = VVVjNM if inDB else ""
   elif not chName           : color = ""
   else             : color = VV21C5
   self.VVbcZ7(lbl, chName or "-", color)
   self.lastRow = row
   self.lastCol = col
   col += 1
   if col > (self.TOTAL_COLS - 1):
    col = 0
    row += 1
 @staticmethod
 def VV5jiJ(s1, s2):
  rows, cols, dist = len(s1) + 1, len(s2) + 1, []
  for i in range(rows): dist.append([0.] * cols)
  for i in range(1, rows):
   for j in range(1,cols): dist[i][0], dist[0][j] = i, j
  for col in range(1, cols):
   for row in range(1, rows):
    cost = 0 if s1[row-1] == s2[col-1] else 2
    dist[row][col] = min(dist[row-1][col] + 1, dist[row][col-1] + 1, dist[row-1][col-1] + cost)
  return int( ( ( len(s1) + len(s2) ) - dist[row][col] ) / ( len(s1) + len(s2) ) * 100 )
 @staticmethod
 def VV5A2L():
  return ("Copy Current Channel PIcon (to PIcons Export Path)", "VVsVVN")
 @staticmethod
 def VVuPbO():
  VVZJ87 = []
  VVZJ87.append(("Find SymLinks (to PIcon Directory)"   , "VVi5EK"  ))
  VVZJ87.append(("Find Broken SymLinks (to PIcon Directory)" , "findPiconBrokenSymLinks" ))
  VVZJ87.append(("Find all Broken SymLinks"      , "FindAllBrokenSymLinks" ))
  return VVZJ87
 @staticmethod
 def VVsVVN(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(SELF)
  png, path = CCijoe.VVZ9qg(refCode)
  if path : CCijoe.VV79QH(SELF, png, path)
  else : FFw5OO(SELF, "No PIcon found for current channel in:\n\n%s" % CCijoe.VV4boJ())
 @staticmethod
 def VVi5EK(SELF):
  if VVVCGb:
   sed1 = FFXRSi("->", VVVCGb)
   sed2 = FFXRSi("picon", VVsObI)
   sed3 = "| sed 's/... Broken Link/\\t\\%s&\%s/gI'" % (VV21C5, VVqFea)
  else:
   sed1 = sed2 = sed3 = ""
  grep = "| grep -i 'picon'"
  FFleea(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then BROK='... Broken Link'; else BROK=''; fi; ls -l \"$FILE\" 2> /dev/null | sed \"s/$/${BROK}/\" | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; done %s %s %s" % (FFEZzf(), grep, sed1, sed2, sed3))
 @staticmethod
 def VVVQKj(SELF, isPIcon):
  sed1 = FFXRSi("->", VV21C5)
  if isPIcon:
   grep = "| grep -i 'picon'"
   sed2 = FFXRSi("picon", VVsObI)
  else:
   grep = "| grep -v /proc | grep -v /run | grep -v /etc/rcS.d"
   sed2 = ""
  FFleea(SELF, "find / %s -type l %s | while read -r FILE; do if [ -L \"$FILE\" ] && [ ! -e \"$FILE\" ]; then ls -l \"$FILE\" 2> /dev/null | awk '{$1=$2=$3=$4=$5=$6=$7=$8=\"\";print}' | xargs; fi; done %s %s" % (FFEZzf(), grep, sed1, sed2))
 @staticmethod
 def VV79QH(SELF, png, path):
  dest = CFG.exportedPIconsPath.getValue()
  andTxt = "echo -e 'PIcon file copied to:\n\n%s%s' %s" % (dest, png, FFXRSi("%s%s" % (dest, png), VVVjNM))
  errTxt = "Could not copy PIcon file!"
  orTxt = "echo -e '%s' %s" % (errTxt, FFXRSi(errTxt, VVGe5h))
  cmd = "cp -f '%s' '%s' &> /dev/null && %s || %s" % (path, dest, andTxt, orTxt)
  FF6Z0v(SELF, cmd)
 @staticmethod
 def VV5WZn(path):
  for f in os.listdir(path):
   if f.endswith(".png"):
    p = path + f
    if os.path.islink(p) and os.path.exists(p) : yield f , 1
    elif os.path.isfile(p)      : yield f , 0
 @staticmethod
 def VV4boJ():
  path = CFG.PIconsPath.getValue()
  return FF1vNj(path)
 @staticmethod
 def VVZ9qg(refCode, chName=None):
  if FF4Jai(refCode):
   refCode, decodedUrl, origUrl, iptvRef = FFzRjC(refCode)
  allPath, fName, refCodeFile, pList = CCijoe.VVsBzM(refCode, chName)
  if pList:
   if refCodeFile : return fName, refCodeFile
   else   : return fName, pList[0]
  else:
   return "", ""
 @staticmethod
 def VVB5jv(pPath, refCode, chName):
  span = iSearch(r"^((?:[A-Fa-f0-9]+:){10})", refCode.strip())
  if span:
   exts = ("png", "jpg")
   refCode = span.group(1).rstrip(":").replace(":", "_")
   tPath = "%s%s." % (pPath, refCode)
   for ext in exts:
    path = tPath + ext
    if fileExists(path):
     return path
   refParts = refCode.split("_", 1)
   for rType in CC9X9s.VVOYzb():
    if not rType == refParts[0]:
     for ext in exts:
      path = "%s%s_%s.%s" %  (pPath, rType, refParts[1], ext)
      if fileExists(path):
       return path
   chName = FFxmTk(chName)
   for ext in exts:
    path = "%s%s.%s" % (pPath, chName, ext)
    if fileExists(path):
     return path
  return ""
 @staticmethod
 def VVsBzM(refCode, chName=None):
  allPath = fName = refCodeFile = pList = None
  if refCode.count(":") > 8:
   refCode = refCode.rstrip(":")
   fName = refCode.strip()
   fName = fName.rstrip(":")
   fName = refCode.replace(":", "_") + ".png"
   allPath = CCijoe.VV4boJ()
   pList = []
   lst = FFzSvJ(allPath, "*_" + "_".join(fName.split("_")[3:]))
   if lst:
    pList += lst
   if chName:
    chName = FFxmTk(chName)
    path = allPath + chName + ".png"
    if fileExists(path):
     pList.append(chName + ".png")
   refCodeFile = ""
   if pList:
    for item in pList:
     if fName == FF65m2(item):
      refCodeFile = item
    pList.sort()
  return allPath, fName, refCodeFile, pList
class CC9sX9():
 def __init__(self):
  noService = "Service unavailable"
  self.type   = type
  self.VV3Jjc  = None
  self.VVbgol = ""
  self.VVWFxL  = noService
  self.VVRd5S = 0
  self.VV6sBs  = noService
  self.VVvSGv = 0
  self.VV6u8I  = "-"
  self.VVACOd = 0
  self.VVvfTB  = ""
  self.serviceName = ""
  self.infoAvailable = False
 def VV1rna(self, service):
  if service:
   self.infoAvailable = False
   feinfo = service.frontendInfo()
   if feinfo:
    self.infoAvailable = True
    frontEndStatus = feinfo.getFrontendStatus()
    if frontEndStatus:
     self.VV3Jjc = frontEndStatus
     self.VVPMFP()
   info = service.info()
   if info:
    self.serviceName = info.getName()
 def VVPMFP(self):
  if self.VV3Jjc:
   val = self.VV3Jjc.get("tuner_signal_quality_db", 0x12345678)
   if val is not None and val != 0x12345678: self.VVbgol = "%3.02f dB" % (val / 100.0)
   else         : self.VVbgol = ""
   val = self.VV3Jjc.get("tuner_signal_quality", 0) * 100 / 65536
   self.VVRd5S = int(val)
   self.VVWFxL  = "%d%%" % val
   val = self.VV3Jjc.get("tuner_signal_power" , 0) * 100 / 65536
   self.VVvSGv = int(val)
   self.VV6sBs  = "%d%%" % val
   val = self.VV3Jjc.get("tuner_bit_error_rate", 0)
   if not val:
    val = 0
   self.VV6u8I  = "%d" % val
   val = int(val * 100 / 500)
   self.VVACOd = min(500, val)
   val = self.VV3Jjc.get("tuner_locked", 0)
   if val == 1 : self.VVvfTB = "Locked"
   else  : self.VVvfTB = "Not locked"
 def VVAMeI(self)   : return self.VVbgol
 def VVKl5B(self)   : return self.VVWFxL
 def VV7ZE4(self)  : return self.VVRd5S
 def VVWcPZ(self)   : return self.VV6sBs
 def VVJMuj(self)  : return self.VVvSGv
 def VVLttO(self)   : return self.VV6u8I
 def VVmL9E(self)  : return self.VVACOd
 def VVkPtR(self)   : return self.VVvfTB
 def VVZt1r(self) : return self.serviceName
class CCyH2c():
 def __init__(self):
  self.sat1 = self.sat2 = self.freq = self.sr = self.syst = self.inv = self.pol = self.fec    = ""
  self.mod = self.rolof = self.pil = self.plsMod = self.plsCod = self.iStId = self.t2PlId = self.t2PId = ""
  self.data  = None
  self.namespace = ""
  self.txMedia = ""
  self.D_POL  = {0:"Horizontal" , 1:"Vartical" , 2:"Left" , 3:"Right"}
  self.D_SYS_S = {0:"DVB-S", 1:"DVB-S2"}
  self.D_SYS_T = {0:"DVB-T", 1:"DVB-T2"}
  self.D_SYS_C = {0:"DVB-C", 1:"DVB-C2", 2:"DVB-C3", 3:"ATSC"}
  self.D_PIL_INV = {0:"Off" , 1:"On" , 2:"Auto"}
  self.D_PLS_MOD = {0:"Root" , 1:"Gold" , 2:"Combo" , 3:"Unknown"}
  self.D_ROLOF = {0:"35%" , 1:"25%" , 2:"20%" , 3:"Auto"}
  self.D_MOD  = {0:"Auto" , 1:"QPSK" , 2:"8PSK" , 3:"QAM16" , 4:"16APSK", 5:"32APSK"}
  self.D_FEC  = {0:"Auto" , 1:"1/2" , 2:"2/3" , 3:"3/4" , 4:"5/6" , 5:"7/8", 6:"8/9", 7:"3/5", 8:"4/5", 9:"9/10", 10:"6/7", 15:"None"}
  self.FREQ  = "frequency"
  self.SR   = "symbol_rate"
  self.POL  = "polarization"
  self.FEC  = "fec_inner"
  self.ORPOS  = "orbital_position"
  self.SYST  = "system"
  self.INV  = "inversion"
 def VVMaf1(self, refCode):
  self.data = None
  if refCode:
   self.namespace = FFqAbm(refCode)
   if   self.namespace.startswith("EEEE") : self.txMedia, syst = "DVB-T", self.D_SYS_T
   elif self.namespace.startswith("FFFF") : self.txMedia, syst = "DVB-C", self.D_SYS_C
   else         : self.txMedia, syst = "DVB-S", self.D_SYS_S
   servRef = eServiceReference(refCode)
   if servRef:
    info = eServiceCenter.getInstance().info(servRef)
    if info:
     self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
     if self.data:
      self.sat1  = self.VVbJIV(self.ORPOS  , mod=1   )
      self.sat2  = self.VVbJIV(self.ORPOS  , mod=2   )
      self.freq  = self.VVbJIV(self.FREQ  , mod=3   )
      self.sr   = self.VVbJIV(self.SR   , mod=4   )
      self.inv  = self.VVbJIV(self.INV  , self.D_PIL_INV)
      self.pol  = self.VVbJIV(self.POL  , self.D_POL )
      self.fec  = self.VVbJIV(self.FEC  , self.D_FEC )
      self.syst  = self.VVbJIV(self.SYST  , syst   )
      if "S2" in self.syst:
       self.mod = self.VVbJIV("modulation" , self.D_MOD )
       self.rolof = self.VVbJIV("rolloff"  , self.D_ROLOF )
       self.pil = self.VVbJIV("pilot"   , self.D_PIL_INV)
       self.plsMod = self.VVbJIV("pls_mode"  , self.D_PLS_MOD)
       self.plsCod = self.VVbJIV("pls_code"  )
       self.iStId = self.VVbJIV("is_id"   )
       self.t2PlId = self.VVbJIV("t2mi_plp_id" )
       self.t2PId = self.VVbJIV("t2mi_pid"  )
 def VVbJIV(self, key, valDict=None, mod=0):
  val = self.data.get(key, "?")
  if   val in ("?", -1) : return ""
  elif valDict   : return valDict.get(val, str(val))
  elif mod == 1   : return FFXHW8(val)
  elif mod == 2   : return FFWHDS(val)
  elif mod == 3   : return str(int(val) // 1000)
  elif mod == 4   : return str(int(val) // 1000)
  else     : return str(val)
 def VV5Spu(self, refCode):
  txt = ""
  self.VVMaf1(refCode)
  if self.data:
   def VVYPGf(subj, val):
    if val : return "%s\t: %s\n" % (subj, val)
    else : return ""
   if self.txMedia == "DVB-S":
    txt += VVYPGf("System"   , self.syst)
    txt += VVYPGf("Satellite"  , self.sat2)
    txt += VVYPGf("Frequency"  , self.freq)
    txt += VVYPGf("Inversion"  , self.inv)
    txt += VVYPGf("Symbol Rate"  , self.sr)
    txt += VVYPGf("Polarization" , self.pol)
    txt += VVYPGf("FEC"    , self.fec)
    if "S2" in self.syst:
     txt += VVYPGf("Modulation" , self.mod)
     txt += VVYPGf("Roll-Off" , self.rolof)
     txt += VVYPGf("Pilot"  , self.pil)
     txt += VVYPGf("Input Stream", self.iStId)
     txt += VVYPGf("T2MI PLP ID" , self.t2PlId)
     txt += VVYPGf("T2MI PID" , self.t2PId)
     txt += VVYPGf("PLS Mode" , self.plsMod)
     txt += VVYPGf("PLS Code" , self.plsCod)
   else:
    txt += VVYPGf("System"   , self.txMedia)
    txt += VVYPGf("Frequency"  , self.freq)
  return txt, self.namespace
 def VV1b6Z(self, refCode):
  txt = "Transpoder : ?"
  self.VVMaf1(refCode)
  tpTxt = "?"
  if self.data:
   maxLen = 50 + 10
   if self.txMedia == "DVB-S":
    tpTxt = ("%s %s %s %s" % (self.freq, self.pol[:1], self.fec, self.sr)).strip()
   else:
    tpTxt = "Freq = %s  (%s)" % (self.freq, self.txMedia)
   if len(tpTxt) > maxLen : txt = tpTxt[:maxLen] + ".."
   else     : txt = tpTxt
  return tpTxt, self.sat2
 def VVZ8Ib(self, refCode):
  if refCode and refCode.count(":") > 8: servRef = eServiceReference(refCode)
  else         : servRef = None
  self.data = None
  if servRef:
   info = eServiceCenter.getInstance().info(servRef)
   if info:
    self.data = info.getInfoObject(servRef, iServiceInformation.sTransponderData)
    if self.data:
     self.namespace = FFqAbm(refCode)
     if   self.namespace.startswith("EEEE") : isSat, syst = False, self.VVbJIV(self.SYST, self.D_SYS_T)
     elif self.namespace.startswith("FFFF") : isSat, syst = False, self.VVbJIV(self.SYST, self.D_SYS_C)
     else         : isSat, syst = True , self.VVbJIV(self.SYST, self.D_SYS_S)
     freq = self.VVbJIV(self.FREQ , mod=3  )
     if isSat:
      pol = self.VVbJIV(self.POL , self.D_POL)
      fec = self.VVbJIV(self.FEC , self.D_FEC)
      sr = self.VVbJIV(self.SR  , mod=4  )
      return freq, pol[:1], fec, sr, syst
     else:
      return freq, "-", "-", "-", syst
  return "-", "-", "-", "-", ""
 def VVgElx(self, refCode):
  self.data = None
  self.VVMaf1(refCode)
  if self.data and self.freq : return True
  else      : return False
class CCQ3ND():
 def __init__(self, VVFe7k, path, VVCeou=None, curRowNum=-1):
  self.VVFe7k  = VVFe7k
  self.origFile   = path
  self.Title    = "File Editor: " + FF65m2(path)
  self.VVCeou  = VVCeou
  self.tmpFile   = "/tmp/ajp_edit"
  self.fileChanged  = False
  self.fileSaved   = False
  self.insertMode   = 0
  self.lastLineNum  = -1
  if FFuB0V("cp -f '%s' '%s'" % (self.origFile, self.tmpFile)):
   FFJsIX(self.VVFe7k, BF(self.VVWcSO, curRowNum), title="Loading file ...")
  else:
   FFw5OO(self.VVFe7k, "Error while preparing edit!")
 def VVWcSO(self, curRowNum):
  VVX3wb = self.VVPTve()
  VVX66G = ("Save Changes" , self.VVR27l   , [])
  VVwmV1  = ("Edit Line"  , self.VV2cRN    , [])
  VVIrDY = ("Go to Line Num" , self.VVU60V   , [])
  VVFadD = ("Line Options" , self.VVRjpB   , [])
  VVotuX = (""    , self.VVLfzE , [])
  VV0xpR = self.VVTOmm
  VVxxkd  = self.VVI28V
  header   = ("Line No." , "Text" )
  widths   = (8   , 92  )
  VVFvCJ  = (CENTER  , LEFT  )
  VVxBfP = FF1Dpj(self.VVFe7k, None, title=self.Title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVX66G=VVX66G, VVwmV1=VVwmV1, VVIrDY=VVIrDY, VVFadD=VVFadD, VV0xpR=VV0xpR, VVxxkd=VVxxkd, VVotuX=VVotuX, VVUdUN=True, searchCol=1, lastFindConfigObj=CFG.lastFindEditor
    , VVDlGi   = "#11001111"
    , VVaSSM   = "#11001111"
    , VVzgHY   = "#11001111"
    , VVkUYa  = "#05333333"
    , VVivoO  = "#00222222"
    , VVdjpa  = "#11331133"
    )
  VVxBfP.VVYNxS(curRowNum)
 def VVU60V(self, VVxBfP, title, txt, colList):
  totRows = VVxBfP.VVWnGz()
  lineNum = VVxBfP.VVgu5W() + 1 if self.lastLineNum == -1 else self.lastLineNum
  FFaSvq(self.VVFe7k, BF(self.VVPoHz, VVxBfP, lineNum, totRows), title="Go to Line Num (1 - %d)" % totRows, defaultText="%d" % lineNum, message="Enter Line Number")
 def VVPoHz(self, VVxBfP, lineNum, totRows, VVYwVo):
  if VVYwVo:
   VVYwVo = VVYwVo.strip()
   if VVYwVo.isdigit():
    num = FFgevD(int(VVYwVo) - 1, 0, totRows)
    VVxBfP.VVYNxS(num)
    self.lastLineNum = num + 1
   else:
    FF5uKN(VVxBfP, "Incorrect number", 1500)
 def VVRjpB(self, VVxBfP, title, txt, colList):
  lineNum = int(colList[0])
  totRows = VVxBfP.VVLC76()
  VVZJ87 = []
  VVZJ87.append(  ("Insert Empty Line (before line-%d)" % lineNum , "insertLineBefore" ))
  if lineNum == totRows:
   VVZJ87.append( ("Insert Empty Line (after line-%d)"  % lineNum , "VVDqtK"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(  ("Copy to clipboard"       , "copyToClipboard"  ))
  if VVnuVz:
   VVZJ87.append( ("Paste from clipboard (overwrite)"    , "pasteFromClipboard" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(  ("Delete Line"         , "deleteLine"   ))
  FFYySC(self.VVFe7k, BF(self.VVuCyt, VVxBfP, lineNum), VVZJ87=VVZJ87, title="Line Options")
 def VVuCyt(self, VVxBfP, lineNum, item=None):
  if item:
   if   item == "insertLineBefore"  : self.VVqPlb("sed -i '%d i %s' '%s'" % (lineNum, "", self.tmpFile), VVxBfP)
   elif item == "VVDqtK"  : self.VVDqtK(VVxBfP, lineNum)
   elif item == "copyToClipboard"  : self.VVWhQx(VVxBfP, lineNum)
   elif item == "pasteFromClipboard" : self.VVIARr(VVxBfP, lineNum)
   elif item == "deleteLine"   : self.VVqPlb("sed -i '%dd' '%s'" % (lineNum, self.tmpFile), VVxBfP)
 def VVI28V(self, VVxBfP):
  VVxBfP.VVJSaW()
 def VVLfzE(self, VVxBfP, title, txt, colList):
  if   self.insertMode == 1: VVxBfP.VVa8Hj()
  elif self.insertMode == 2: VVxBfP.VV5srZ()
  self.insertMode = 0
 def VVDqtK(self, VVxBfP, lineNum):
  if lineNum == VVxBfP.VVLC76():
   self.insertMode = 1
   self.VVqPlb("echo '' >> '%s'" % self.tmpFile, VVxBfP)
  else:
   self.insertMode = 2
   self.VVqPlb("sed -i '%d i %s' '%s'" % (lineNum + 1, "", self.tmpFile), VVxBfP)
 def VVWhQx(self, VVxBfP, lineNum):
  global VVnuVz
  VVnuVz = FF3RLi("sed '%sq;d' '%s'" % (lineNum, self.tmpFile) )
  VVxBfP.VVIzOr("Copied to clipboard")
 def VVR27l(self, VVxBfP, title, txt, colList):
  if self.fileChanged:
   if FFn7Bv(self.origFile):
    if FFuB0V("cp -f '%s' '%s'" % (self.tmpFile, self.origFile)):
     VVxBfP.VVIzOr("Saved")
     self.fileSaved   = True
     self.fileChanged = False
     VVxBfP.VVJSaW()
    else:
     FFw5OO(self.VVFe7k, "Cannot save file!")
   else:
    FFw5OO(self.VVFe7k, "Cannot create backup copy of original file!")
 def VVTOmm(self, VVxBfP):
  if self.fileChanged:
   FFNKVM(self.VVFe7k, BF(self.VVHTSM, VVxBfP), "Cancel changes ?")
  else:
   FFuB0V("cp -f '%s' '%s'" % (self.tmpFile, self.origFile))
   self.VVHTSM(VVxBfP)
 def VVHTSM(self, VVxBfP):
  VVxBfP.cancel()
  FFzyFM(self.tmpFile)
  if self.VVCeou:
   self.VVCeou(self.fileSaved)
 def VV2cRN(self, VVxBfP, title, txt, colList):
  lineNum = int(colList[0])
  lineTxt = colList[1]
  message = VVqFea + "ORIGINAL TEXT:\n" + VVGb6D + lineTxt
  FFaSvq(self.VVFe7k, BF(self.VVrAd1, lineNum, VVxBfP), title="File Line", defaultText=lineTxt, message=message)
 def VVrAd1(self, lineNum, VVxBfP, VVYwVo):
  if not VVYwVo is None:
   if VVxBfP.VVLC76() <= 1:
    self.VVqPlb("echo %s > '%s'" % (VVYwVo, self.tmpFile), VVxBfP)
   else:
    self.VVimle(VVxBfP, lineNum, VVYwVo)
 def VVIARr(self, VVxBfP, lineNum):
  if lineNum == VVxBfP.VVLC76() and VVxBfP.VVLC76() == 1:
   self.VVqPlb("echo %s >> '%s'" % (VVnuVz, self.tmpFile), VVxBfP)
  else:
   self.VVimle(VVxBfP, lineNum, VVnuVz)
 def VVimle(self, VVxBfP, lineNum, newTxt):
  VVxBfP.VVx85I("Saving ...")
  lines = FFZQjt(self.tmpFile)
  with open(self.tmpFile, "w") as f:
   for ndx, line in enumerate(lines, start=1):
    if lineNum == ndx:
     line = newTxt
    f.write(line + "\n")
  self.fileChanged = True
  VVxBfP.VV1uwH()
  VVX3wb = self.VVPTve()
  VVxBfP.VVcckS(VVX3wb)
 def VVqPlb(self, cmd, VVxBfP):
  tCons = CC1WBa()
  tCons.ePopen(cmd, BF(self.VVqNDu, VVxBfP))
  self.fileChanged = True
  VVxBfP.VV1uwH()
 def VVqNDu(self, VVxBfP, result, retval):
  VVX3wb = self.VVPTve()
  VVxBfP.VVcckS(VVX3wb)
 def VVPTve(self):
  if fileExists(self.tmpFile):
   lines = FFZQjt(self.tmpFile)
   VVX3wb = []
   if lines:
    for ndx, line in enumerate(lines, start=1):
     VVX3wb.append((str(ndx), line.strip()))
   if not VVX3wb:
    VVX3wb.append((str(1), ""))
   return VVX3wb
  else:
   FFZoTn(self.VVFe7k, self.tmpFile)
class CCdUgX():
 def __init__(self, callingSELF, VVDlGi="#22003344", VVaSSM="#22002233"):
  self.callingSELF = callingSELF
  self.VVZJ87  = []
  self.satList  = []
  self.VVDlGi  = VVDlGi
  self.VVaSSM   = VVaSSM
 def VV4D6G(self, VVCeou):
  self.VVZJ87 = []
  VVZJ87, VVXkSw = CCdUgX.VVwE3y(self.callingSELF, False, True)
  if VVZJ87:
   self.VVZJ87 += VVZJ87
   self.VVRjg8(VVCeou, VVXkSw)
 def VV4hrU(self, mode, VVxBfP, satCol, VVCeou, inFilterFnc=None):
  VVxBfP.VVx85I("Loading Filters ...")
  self.VVZJ87 = []
  self.VVZJ87.append(("All Services" , "all"))
  if mode == 1:
   self.VVZJ87.append(VVoqHH)
   self.VVZJ87.append(("Parental Control", "parentalControl" ))
   self.VVZJ87.append(("Hidden Services" , "hiddenServices" ))
  elif mode == 2:
   self.VVZJ87.append(VVoqHH)
   self.VVZJ87.append(("Selected Transponder"   , "selectedTP" ))
   self.VVZJ87.append(("Channels with no Transponder" , "emptyTP"  ))
  self.VV17cg(VVxBfP, satCol)
  VVZJ87, VVXkSw = CCdUgX.VVwE3y(self.callingSELF, True, False)
  if VVZJ87:
   VVZJ87.insert(0, FFHf46("Custom Words"))
   self.VVZJ87 += VVZJ87
  VVxBfP.VVW7OH()
  self.VVRjg8(VVCeou, VVXkSw, inFilterFnc)
 def VV0Gkf(self, VVZJ87, sats, VVCeou, inFilterFnc=None):
  self.VVZJ87 = VVZJ87
  VVZJ87, VVXkSw = CCdUgX.VVwE3y(self.callingSELF, True, False)
  if VVZJ87:
   self.VVZJ87.append(FFHf46("Custom Words"))
   self.VVZJ87 += VVZJ87
  self.VVRjg8(VVCeou, VVXkSw, inFilterFnc)
 def VVRjg8(self, VVCeou, VVXkSw, inFilterFnc=None):
  VVbiUc  = ("Filter in Filter", inFilterFnc) if inFilterFnc else None
  VV3ba7 = ("Edit Filter"  , BF(self.VVI12l, VVXkSw))
  VV2YYF  = ("Filter Help"  , BF(self.VVH3yo, VVXkSw))
  FFYySC(self.callingSELF, BF(self.VVE9PN, VVCeou), VVZJ87=self.VVZJ87, title="Select Filter", VVbiUc=VVbiUc, VV3ba7=VV3ba7, VV2YYF=VV2YYF, VVhe5b=True, VVDlGi=self.VVDlGi, VVaSSM=self.VVaSSM)
 def VVE9PN(self, VVCeou, item):
  if item:
   VVCeou(item)
 def VVI12l(self, VVXkSw, VVbBRSObj, sel):
  if fileExists(VVXkSw) : CCQ3ND(self.callingSELF, VVXkSw, VVCeou=None)
  else       : FFZoTn(self.callingSELF, VVXkSw)
  VVbBRSObj.cancel()
 def VVH3yo(self, VVXkSw, VVbBRSObj, sel):
  FFqsYG(self.callingSELF, "_help_service_filter", "Service Filter")
 def VV17cg(self, VVxBfP, satColNum):
  if not self.satList:
   satList = VVxBfP.VVdiFM(satColNum)
   if satList:
    satList = set(satList)
    satList = list(satList)
    if satList:
     sats = []
     for ndx, sat in enumerate(satList):
      if not sat.strip() == "":
       self.satList.append((FF0JDR(sat), "__s__" + sat))
     self.satList.sort(key=lambda x: x[0])
     self.satList.insert(0, FFHf46("Satellites"))
  if self.VVZJ87:
   self.VVZJ87 += self.satList
 @staticmethod
 def VVwE3y(SELF, addTag, VV70Sp):
  FFDEHe()
  fileName  = "ajpanel_services_filter"
  VVXkSw = VVNemM + fileName
  VVZJ87  = []
  if not fileExists(VVXkSw):
   FFuB0V("cp -f '%s' '%s'" % (VVrrZu + fileName, VVXkSw))
  fileFound = False
  if fileExists(VVXkSw):
   fileFound = True
   lines = FFZQjt(VVXkSw)
   if lines:
    for line in lines:
     line = line.strip()
     if line and not line.startswith("#"):
      if "#" in line:
       line = line.split("#")[0].strip()
      if "," in line:
       lst = list(map(str.strip, line.split(",")))
       lst = list(filter(None, lst))
       if lst: line = ",".join(lst)
       else  : line = ""
      if line:
       if addTag: VVZJ87.append((line, "__w__" + line))
       else  : VVZJ87.append((line, line))
  if VV70Sp:
   if   not fileFound : FFZoTn(SELF, VVXkSw)
   elif not VVZJ87 : FF5BXO(SELF, VVXkSw)
  return VVZJ87, VVXkSw
 @staticmethod
 def VV0Xfy(txt):
  txt = txt.strip()
  lst = []
  prefix = False
  if "," in txt:
   lst = list(map(str.strip, txt.split(",")))
   lst = list(filter(None, lst))
   if lst and len(lst) > 1 and lst[0] == "^":
    lst = lst[1:]
    prefix = True
  else:
   txt = txt.strip()
   if txt:
    if len(txt) > 1 and txt.startswith("^"):
     txt = txt[1:]
     prefix = True
    lst = [txt]
  return tuple(map(str.lower, lst)), prefix
class CCHw3d():
 def __init__(self, callingSELF, VVxBfP, addSep=True):
  self.callingSELF = callingSELF
  self.VVxBfP = VVxBfP
  self.VVZJ87 = []
  iMulSel = self.VVxBfP.VVT9wK()
  if iMulSel : self.VVZJ87.append( ("Disable Multi-Select " , "MultSelDisab" ))
  else  : self.VVZJ87.append( ("Enable Multi-Select"  , "multSelEnab"  ))
  tot = self.VVxBfP.VVsyP1()
  self.VVZJ87.append(    ("Select all"    , "selectAll"  ))
  if iMulSel and tot > 0:
   self.VVZJ87.append(   ("Unselect all"    , "unselectAll"  ))
  if addSep:
   self.VVZJ87.append(VVoqHH)
 def VVsKHw(self, extraMenu, cbFncDict, width=1000, okFnc=None):
  if extraMenu:
   self.VVZJ87.extend(extraMenu)
  FFYySC(self.callingSELF, BF(self.VVSJL3, cbFncDict, okFnc), width=width, title="Options", VVZJ87=self.VVZJ87)
 def VVSJL3(self, cbFncDict, okFnc, item=None):
  if item:
   if   item == "multSelEnab" : self.VVxBfP.VVDjjC(True)
   elif item == "MultSelDisab" : self.VVxBfP.VVDjjC(False)
   elif item == "selectAll" : self.VVxBfP.VV2Vwg()
   elif item == "unselectAll" : self.VVxBfP.VV6pZ8()
   elif cbFncDict:
    fnc = cbFncDict.get(item)
    if fnc:
     fnc()
   if okFnc:
    okFnc()
class CCfRDb(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVwFfF, 900, 480, 50, 0, 0, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFmmH7(self)
  FFR9Qm(self["keyRed"]  , "Exit")
  FFR9Qm(self["keyGreen"]  , "Save")
  FFR9Qm(self["keyYellow"] , "Refresh")
  FFR9Qm(self["keyBlue"]  , "NTP Mode")
  self["curTime"]  = Label()
  self["yearTitle"] = Label("Year")
  self["monthTitle"] = Label("Month")
  self["dayTitle"] = Label("Day")
  self["gapTitle"] = Label()
  self["hourTitle"] = Label("Hour")
  self["minTitle"] = Label("Min")
  self["secTitle"] = Label("Sec")
  self["year"]  = Label()
  self["month"]  = Label()
  self["day"]   = Label()
  self["gap"]   = Label()
  self["hour"]  = Label()
  self["min"]   = Label()
  self["sec"]   = Label()
  self.index   = 0
  self.list   = [self["year"], self["month"], self["day"], self["hour"], self["min"], self["sec"]]
  self.timer   = eTimer()
  self["gapTitle"].hide()
  self["gap"].hide()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVjlTA  ,
   "green" : self.VVqUee ,
   "yellow": self.VV3eS8  ,
   "blue" : self.VVLWV4   ,
   "up" : self.VV09f2    ,
   "down" : self.VVVvF4   ,
   "left" : self.VVn01Q   ,
   "right" : self.VVbYcO   ,
   "cancel": self.VVjlTA
  }, -1)
  self["myTitle"].setText("  Date/Time -> Manual Mode")
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  self.VV3eS8()
  self.VV9zTT()
  FFHLqT(self)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVX2dx)
  except:
   self.timer.callback.append(self.VVX2dx)
  self.timer.start(1000, False)
  self.VVX2dx()
 def onExit(self):
  self.timer.stop()
 def VVjlTA(self) : self.close(True)
 def VVT9hw(self) : self.close(False)
 def VVLWV4(self):
  self.session.openWithCallback(self.VVdfCk, BF(CC8KEc))
 def VVdfCk(self, closeAll):
  if closeAll:
   self.close()
 def VVX2dx(self):
  self["curTime"].setText(str(FFC3u1(iTime())))
 def VV09f2(self):
  self.VVjVuY(1)
 def VVVvF4(self):
  self.VVjVuY(-1)
 def VVn01Q(self):
  self.index -= 1
  if self.index < 0:
   self.index = 5
  self.VV9zTT()
 def VVbYcO(self):
  self.index += 1
  if self.index > 5:
   self.index = 0
  self.VV9zTT()
 def VVjVuY(self, increment):
  year = int(self["year" ].getText())
  month = int(self["month"].getText())
  if   self.index == 0: minVal, maxVal = 2000, 3000
  elif self.index == 1: minVal, maxVal = 1, 12
  elif self.index == 2: minVal, maxVal = 1, self.VVJV7I(month, year)
  elif self.index == 3: minVal, maxVal = 0, 59
  elif self.index == 4: minVal, maxVal = 0, 59
  elif self.index == 5: minVal, maxVal = 0, 59
  val  = int(self.list[self.index].getText()) + increment
  if val < minVal: val = maxVal
  if val > maxVal: val = minVal
  if self.index == 0:
   val = "%04d" % val
  else:
   val = "%02d" % val
  self.list[self.index].setText(val)
  if self.index < 2:
   year = int(self["year" ].getText())
   month = int(self["month"].getText())
   day = int(self["day"].getText())
   monthDays = self.VVJV7I(month, year)
   if day > monthDays:
    self["day"].setText("%02d" % monthDays)
 def VVJV7I(self, month, year):
  MonthList = [31,28,31,30,31,30,31,31,30,31,30,31]
  days = MonthList[month-1]
  if (month == 2) and (self.VVYwnZ(year)):
   days += 1
  return days
 def VVYwnZ(self, year):
  if year % 4 == 0:
   if year % 100 == 0:
    if year % 400 == 0:
     return True
    else:
     return False
   else:
    return True
  else:
   return False
 def VV9zTT(self):
  for obj in self.list:
   FFWN9Z(obj, "#11404040")
  FFWN9Z(self.list[self.index], "#11ff8000")
 def VV3eS8(self):
  year, month, day, hour, minute, second, weekDay, yearDay, dayLight = localtime()
  self["year" ].setText("%04d" % year)
  self["month"].setText("%02d" % month)
  self["day"  ].setText("%02d" % day)
  self["hour" ].setText("%02d" % hour)
  self["min"  ].setText("%02d" % minute)
  self["sec"  ].setText("%02d" % second)
 def VVqUee(self):
  year = int(self["year" ].getText())
  month = self["month"].getText()
  day  = self["day"  ].getText()
  hour = self["hour" ].getText()
  minute = self["min"  ].getText()
  second = self["sec"  ].getText()
  cmd = "date -s '%s-%s-%s %s:%s:%s'" % (year, month, day, hour, minute, second)
  tCons = CC1WBa()
  tCons.ePopen("echo -e 'System Response:\n'; %s" % cmd, self.VVNHWG)
 def VVNHWG(self, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   FF15cM(self, "Nothing returned from the system!")
  else:
   FF15cM(self, str(result))
class CC8KEc(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVq2lk, 900, 480, 50, 40, 10, "#22660066", "#22330033", 35, barHeight=40)
  self.session  = session
  FFmmH7(self, addLabel=True)
  FFR9Qm(self["keyRed"]  , "Exit")
  FFR9Qm(self["keyGreen"]  , "Sync")
  FFR9Qm(self["keyYellow"] , "Refresh")
  FFR9Qm(self["keyBlue"]  , "Manual Mode")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red" : self.VVjlTA   ,
   "green" : self.VV06Nz  ,
   "yellow": self.VVnFb0 ,
   "blue" : self.VVvsLU  ,
   "cancel": self.VVjlTA
  }, -1)
  self["myTitle"].setText("  Date/Time -> NTP Mode")
  self.VVuO90()
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  FFHLqT(self)
  FFFANg(self.VVoH7z)
 def VVoH7z(self):
  self.VV88WL()
  self.VVjjWf(False)
 def VVjlTA(self)  : self.close(True)
 def VVvsLU(self) : self.close(False)
 def VVuO90(self):
  self["myLabel"].setText("Getting NTP time ... ")
 def VV88WL(self):
  self.VVY0As()
  self.VVUhnf()
  self.VVu5LA()
  self.VVF2AZ()
 def VVnFb0(self):
  if len(self["keyYellow"].getText()) > 0:
   self.VVuO90()
   self.VV88WL()
   FFFANg(self.VVoH7z)
 def VV06Nz(self):
  if len(self["keyGreen"].getText()) > 0:
   FFNKVM(self, self.VV63QS, "Synchronize with Internet Date/Time ?")
 def VV63QS(self):
  self.VV88WL()
  FFFANg(BF(self.VVjjWf, True))
 def VVY0As(self)  : self["keyRed"].show()
 def VV732h(self)  : self["keyGreen"].show()
 def VVfOp3(self) : self["keyYellow"].show()
 def VV1KYZ(self)  : self["keyBlue"].show()
 def VVUhnf(self)  : self["keyGreen"].hide()
 def VVu5LA(self) : self["keyYellow"].hide()
 def VVF2AZ(self)  : self["keyBlue"].hide()
 def VVjjWf(self, sync):
  localTime = FFxN8A()
  ok = False
  server_list = ['ntp.iitb.ac.in', 'time.nist.gov', 'time.windows.com', 'pool.ntp.org']
  for server in server_list:
   epoch_time = self.VVGCWj(server)
   if epoch_time is not None:
    ntpTime = FFC3u1(epoch_time)
    time1 = mktime(datetime.strptime(localTime, "%Y-%m-%d %H:%M:%S").timetuple())
    time2 = mktime(datetime.strptime(ntpTime  , "%Y-%m-%d %H:%M:%S").timetuple())
    diff = time1 - time2
    if   diff == 0 : timeDiff = "None"
    elif diff == 1 : timeDiff = "%d second"  % diff
    else   : timeDiff = "%d seconds" % diff
    timeDiff = "Difference\t=  %s" % timeDiff
    if sync:
     tCons = CC1WBa()
     tCons.ePopen("echo -e '\nSystem Response:\n'; date -s '%s'" % ntpTime, BF(self.VVNHWG, True))
    else:
     txt = "Local Time\t= %s\nInternet Time\t= %s\n%s\n" % (localTime, ntpTime, timeDiff)
     self["myLabel"].setText(txt)
    ok = True
    break
   else:
    pass
  self.VVfOp3()
  self.VV1KYZ()
  if ok:
   self.VV732h()
  else:
   self["myLabel"].setText("Local Time\t= %s\n\nCould not get NTP time !\n" % localTime)
 def VVNHWG(self, syncAgain, result, retval):
  result = str(result.strip())
  if len(result) == 0:
   result = "\n\nNothing returned from the system!"
  elif result.count("\n") < 20:
   result = "\n\n" + result
  try:
   self["myLabel"].setText(result)
   if syncAgain:
    self.VVjjWf(False)
  except:
   pass
 def VVGCWj(self, addr='time.nist.gov'):
  from socket import socket, AF_INET, SOCK_DGRAM
  from struct import unpack as iUnpack
  time1970 = 2208988800
  data  = '\x1b' + 47 * '\0'
  data  = data.encode()
  if CC66h0.VVP0Wq():
   try:
    client = socket(AF_INET, SOCK_DGRAM)
    client.settimeout(1.0)
    client.sendto(data, (addr, 123))
    data, address = client.recvfrom(1024)
    if data:
     epoch_time = iUnpack('!12I', data)[10]
     epoch_time -= time1970
     return epoch_time
   except:
    pass
  return None
class CCWSaK(Screen):
 def __init__(self, session, args=0):
  self.skin, self.skinParam = FFRBRO(VVe3Gb, 900, 300, 50, 20, 0, "#22000060", "#22000020", 35)
  self.session  = session
  FFmmH7(self, addLabel=True, addCloser=True)
  self["myTitle"].setText("  Internet Connectivity")
  self["myLabel"].setText("Checking Connection ...")
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFFANg(self.VVrf9x)
 def VVrf9x(self):
  if CC66h0.VVP0Wq() : color, txt = "#22002020", "Internet Connection = Successful."
  else     : color, txt = "#22500000", "Cannot connect (or server is down) !"
  try:
   self["myLabel"].setText("  " + txt)
   FFWN9Z(self["myBody"], color)
   FFWN9Z(self["myLabel"], color)
  except:
   pass
class CCn3nB(Screen):
 VViaTx = None
 def __init__(self, session):
  size = CFG.signalSize.getValue()
  screenW = FFwz8B()[0]
  ratio = size / 5.0
  self.skin, self.skinParam = FFRBRO(VVGUPT, 650, 320, 26, 20, 20, "#22003040", "#22001122", 25, winRatio=ratio)
  self.session   = session
  self["mySNRdB"]   = Label()
  self["mySNR"]   = Label()
  self["myAGC"]   = Label()
  self["myBER"]   = Label()
  self["mySliderSNR"]  = Pixmap()
  self["mySliderAGC"]  = Pixmap()
  self["mySliderBER"]  = Pixmap()
  self["mySliderCovSNR"] = Label()
  self["mySliderCovAGC"] = Label()
  self["mySliderCovBER"] = Label()
  color     = self.skinParam["bodyColor"]
  self.sliderSNR   = CCONCD(self, self["mySliderSNR"], self["mySliderCovSNR"], minN=0, maxN=100, covColor=color)
  self.sliderAGC   = CCONCD(self, self["mySliderAGC"], self["mySliderCovAGC"], minN=0, maxN=100, covColor=color)
  self.sliderBER   = CCONCD(self, self["mySliderBER"], self["mySliderCovBER"], minN=0, maxN=100, covColor=color)
  self["myTPInfo"]  = Label()
  self.timer    = eTimer()
  self.tunerInfo   = CC9sX9()
  self.stateCounter  = 0
  self.top    = 0
  self.left    = 0
  self.curPosNum   = CFG.signalPos.getValue()
  self.curSize   = CFG.signalSize.getValue()
  FFmmH7(self, title="Signal")
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.close      ,
   "up"  : self.VV09f2       ,
   "down"  : self.VVVvF4      ,
   "left"  : self.VVn01Q      ,
   "right"  : self.VVbYcO      ,
   "info"  : self.VVpIF1     ,
   "epg"  : self.VVpIF1     ,
   "menu"  : self.VVonME      ,
   "cancel" : self.close      ,
   "red"  : self.close      ,
   "last"  : BF(self.VVA5It, -1)  ,
   "next"  : BF(self.VVA5It, 1)  ,
   "pageUp" : BF(self.VVDpTm, True) ,
   "chanUp" : BF(self.VVDpTm, True) ,
   "pageDown" : BF(self.VVDpTm, False) ,
   "chanDown" : BF(self.VVDpTm, False) ,
   "0"   : BF(self.VVA5It, 0)  ,
   "1"   : BF(self.VV17U5, pos=1) ,
   "2"   : BF(self.VV17U5, pos=2) ,
   "3"   : BF(self.VV17U5, pos=3) ,
   "4"   : BF(self.VV17U5, pos=4) ,
   "5"   : BF(self.VV17U5, pos=5) ,
   "6"   : BF(self.VV17U5, pos=6) ,
   "7"   : BF(self.VV17U5, pos=7) ,
   "8"   : BF(self.VV17U5, pos=8) ,
   "9"   : BF(self.VV17U5, pos=9) ,
  }, -1)
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  if not CCn3nB.VViaTx:
   CCn3nB.VViaTx = self
  self.sliderSNR.VVVWv0()
  self.sliderAGC.VVVWv0()
  self.sliderBER.VVVWv0(isBER=True)
  pos   = self.instance.position()
  self.left = pos.x()
  self.top = pos.y()
  self.VV17U5()
  self.VVTl0F()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVHTxw)
  except:
   self.timer.callback.append(self.VVHTxw)
  self.timer.start(500, False)
 def VVTl0F(self):
  service = self.session.nav.getCurrentService()
  self.tunerInfo.VV1rna(service)
  serviceName = self.tunerInfo.VVZt1r()
  if not serviceName   : serviceName = "Signal"
  if len(serviceName) > 25 : serviceName = serviceName[:25] + ".."
  self["myTitle"].setText("  " + serviceName)
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  tp = CCyH2c()
  tpTxt, satTxt = tp.VV1b6Z(refCode)
  if tpTxt == "?" :
   tpTxt = FFGB9z("NO SIGNAL", VVLbyB)
  self["myTPInfo"].setText(tpTxt + "  " + FFGB9z(satTxt, VVUVAI))
 def VVHTxw(self):
  service  = self.session.nav.getCurrentService()
  self.tunerInfo.VV1rna(service)
  if self.tunerInfo.infoAvailable:
   self["mySNRdB"].setText(self.tunerInfo.VVAMeI())
   self["mySNR"].setText(self.tunerInfo.VVKl5B())
   self["myAGC"].setText(self.tunerInfo.VVWcPZ())
   self["myBER"].setText(self.tunerInfo.VVLttO())
   self.sliderSNR.VVEaN2(self.tunerInfo.VV7ZE4())
   self.sliderAGC.VVEaN2(self.tunerInfo.VVJMuj())
   self.sliderBER.VVEaN2(self.tunerInfo.VVmL9E())
  else:
   self["mySNRdB"].setText("")
   self["mySNR"].setText("?")
   self["myAGC"].setText("?")
   self["myBER"].setText("?")
   self.sliderSNR.VVEaN2(0)
   self.sliderAGC.VVEaN2(0)
   self.sliderBER.VVEaN2(0)
  if self.stateCounter > -1:
   self.stateCounter += 1
   if self.stateCounter > 8:
    self.stateCounter = -1
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
    if state and not state == "Tuned":
     FF5uKN(self, state.replace(" (", "\n("), 1500)
     self.stateCounter = -1
 def VVpIF1(self):
  FFcpNw(self, fncMode=CCjQ0P.VV6sNs)
 def VVonME(self):
  FFqsYG(self, "_help_signal", "Signal Monitor (Keys)")
 def VV09f2(self)  : self.VV17U5(posMap={7:4, 4:1, 8:5, 5:2, 9:6, 6:3})
 def VVVvF4(self) : self.VV17U5(posMap={1:4, 4:7, 2:5, 5:8, 3:6, 6:9})
 def VVn01Q(self) : self.VV17U5(posMap={3:2, 2:1, 6:5, 5:4, 9:8, 8:7})
 def VVbYcO(self) : self.VV17U5(posMap={1:2, 2:3, 4:5, 5:6, 7:8, 8:9})
 def VV17U5(self, posMap=None, pos=-1):
  if pos > -1 or posMap:
   if pos > -1:
    self.curPosNum = pos
   elif posMap:
    self.curPosNum = posMap.get(self.curPosNum, self.curPosNum)
   FFdEZ4(CFG.signalPos, self.curPosNum)
  scrSize = getDesktop(0).size()
  gapH = gapV = 20
  w  = self.instance.size().width()
  h  = self.instance.size().height()
  left = self.left
  top  = self.top
  bot  = scrSize.height() - h - gapV
  rigth = scrSize.width()  - w - gapH
  if   self.curPosNum == 1: left, top = gapH , gapV
  elif self.curPosNum == 2: left, top = left , gapV
  elif self.curPosNum == 3: left, top = rigth , gapV
  elif self.curPosNum == 4: left, top = gapH , top
  elif self.curPosNum == 5: left, top = left , top
  elif self.curPosNum == 6: left, top = rigth , top
  elif self.curPosNum == 7: left, top = gapH , bot
  elif self.curPosNum == 8: left, top = left , bot
  elif self.curPosNum == 9: left, top = rigth , bot
  else     : left, top = left , top
  self.instance.move(ePoint(left, top))
 def VVA5It(self, sizeNum):
  oldSizeNum = CFG.signalSize.getValue()
  if sizeNum == 0:
   sizeNum = 5
  else:
   sizeNum += oldSizeNum
   sizeNum = FFgevD(sizeNum, 1, 13)
  if not oldSizeNum == sizeNum:
   FFdEZ4(CFG.signalSize, sizeNum)
   self.close(True)
 def onExit(self):
  self.timer.stop()
  CCn3nB.VViaTx = None
 def VVDpTm(self, isUp):
  FF5uKN(self)
  try:
   if isUp : InfoBar.instance.zapDown()
   else : InfoBar.instance.zapUp()
   self.stateCounter = 0
   self.VVTl0F()
  except:
   pass
class CCONCD(object):
 def __init__(self, SELF, barObj, covObj, minN=0, maxN=100, covColor="#00440000"):
  self.SELF   = SELF
  self.barObj   = barObj
  self.covObj   = covObj
  self.minN   = minN
  self.maxN   = maxN
  self.covColor  = covColor
  self.isColormode = False
 def VVVWv0(self, isBER=False):
  self.barWidth = self.barObj.instance.size().width()
  self.barHeight = self.barObj.instance.size().height()
  self.barLeft = self.barObj.getPosition()[0]
  self.barTop  = self.barObj.getPosition()[1]
  if isBER:
   FFWN9Z(self.covObj, "#0aaa0000")
   self.isColormode = True
  else:
   path = VVrrZu +  "bar_sig.png"
   if fileExists(path):
    self.barObj.instance.setScale(1)
    self.barObj.instance.setPixmapFromFile(path)
    FFWN9Z(self.covObj, self.covColor)
   else:
    FFWN9Z(self.covObj, "#00006688")
    self.isColormode = True
  self.VVEaN2(0)
 def VVEaN2(self, val):
  val  = FFgevD(val, self.minN, self.maxN)
  width = int(FF6NMP(val, 0, 100, 0, self.barWidth))
  height = int(self.barHeight)
  if self.isColormode:
   self.covObj.instance.resize(eSize(*(width, height)))
  else:
   width = int(FFgevD(self.barWidth - width, 0, self.barWidth))
   top  = int(self.barTop)
   left = int(self.barLeft + self.barWidth - width)
   self.covObj.hide()
   self.covObj.instance.resize(eSize(*(width, height)))
   self.covObj.instance.move(ePoint(left, top))
   self.covObj.show()
class CCmNws(Screen):
 VVkie3    = 0
 VV3z22 = 1
 VVEO7C = 2
 def __init__(self, session, titlePrefix="Processing ...", endTitle="Finishing ...", fncToRun=None, VVCeou=None, barTheme=VVkie3, titleBg="#0a042328", bodyBg="#0a042328"):
  ratio = self.VVNMOe(barTheme)
  self.skin, self.skinParam = FFRBRO(VVASkO, 900, 200, 30, 40, 30, titleBg, bodyBg, 30, winRatio=ratio)
  self.session  = session
  self.barTheme  = barTheme
  self.titlePrefix = titlePrefix
  self.newTitle  = ""
  self.endTitle  = endTitle
  self.fncToRun  = fncToRun
  self.VVCeou = VVCeou
  self.isCancelled = False
  self.isError  = False
  self.maxValue  = 0
  self.barWidth  = 0
  self.barHeight  = 0
  self.counter  = 0
  self.VVlaij = None
  self.timer   = eTimer()
  self.myThread  = None
  FFmmH7(self, title=self.titlePrefix)
  self["myProgBar"]  = Label()
  self["myProgBarVal"] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], { "cancel" : self.cancel }, -1)
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  self.VVdIxw()
  self["myProgBarVal"].setText("0%")
  FFWN9Z(self["myProgBar"], "#0a915332")
  size = self["myProgBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self.VVdRNO()
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVdRNO)
  except:
   self.timer.callback.append(self.VVdRNO)
  self.timer.start(300, False)
  self.myThread = iThread(name="ajp_progBar", target=BF(self.fncToRun, self))
  self.myThread.start()
 def VVCnyB(self, val):
  self.maxValue = val
  self.newTitle = self.titlePrefix
 def VVezfw(self, catName):
  self.newTitle = "Found %d\t%d/%d %s" % (len(self.VVlaij), self.counter, self.maxValue, catName)
 def VVYpSy(self, totEpgOK, uChName):
  self.newTitle = "Events: %d   (%d/%d)  %s" % (totEpgOK, self.counter, self.maxValue, uChName)
 def VV3u9K(self, tot):
  self.newTitle = "Downloaded %d    Processed : %d of %d" % (tot, self.counter, self.maxValue)
 def VVaVYA(self, tot, evName):
  self.newTitle = "Translated: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, evName)
 def VVmZZM(self, action, tot, name):
  self.newTitle = "%s: %d   ... %d/%d >> %s" % (action, tot, self.counter, self.maxValue, name)
 def VVJetR(self, tot, name):
  self.newTitle = "Added: %d   ... %d/%d >> %s" % (tot, self.counter, self.maxValue, name)
 def VVHdrq(self, txt):
  self.newTitle = txt
 def VV1Vtn(self, addVal, showFound=False):
  try:
   self.counter += addVal
   if showFound:
    self.newTitle = "Found %d\t .. Processed : %d of %d" % (len(self.VVlaij), self.counter, self.maxValue)
  except:
   pass
 def VVOWUW(self, val):
  try:
   self.counter = val
  except:
   pass
 def VVxY4d(self):
  try:
   return self.counter >= self.maxValue
  except:
   return True
 def VV4dPB(self):
  self.isError = True
  self.cancel()
 def onExit(self):
  self.timer.stop()
 def cancel(self):
  self.timer.stop()
  FF5uKN(self, "Cancelling ...")
  self.isCancelled = True
  self.VVHfq2(False)
 def VVHfq2(self, isDone):
  FFFANg(BF(self.VVk1dx, isDone))
 def VVk1dx(self, isDone):
  if self.VVCeou:
   self.VVCeou(isDone, self.VVlaij, self.counter, self.maxValue, self.isError)
  self.close()
 def VVdRNO(self):
  val = FFgevD(self.counter, 0, self.maxValue)
  if self.maxValue > 0:
   width = int(FF6NMP(val, 0, self.maxValue, 0, self.barWidth))
   self["myProgBarVal"].setText(str(int(val * 100.0 / self.maxValue)) + "%")
   if   self.newTitle  : self["myTitle"].setText("  %s  " % self.newTitle)
   elif self.maxValue > 0 : self["myTitle"].setText("  %s  ( %d of %d ) ..." % (self.titlePrefix, self.counter, self.maxValue))
  else:
   width = 0
  self["myProgBar"].instance.resize(eSize(*(width, self.barHeight)))
  if self.myThread and not self.myThread.is_alive():
   self.timer.stop()
   if not self.isCancelled:
    self["myTitle"].setText("  %s  " % self.endTitle)
    self.VVHfq2(True)
 def VVdIxw(self):
  scrW = getDesktop(0).size().width()
  winW = self.instance.size().width()
  gap  = 30
  if self.barTheme in (self.VV3z22, self.VVEO7C):
   self.instance.move(ePoint(int(scrW - winW - gap), gap))
 def VVNMOe(self, barTheme):
  if   barTheme == self.VV3z22 : return 0.7
  if   barTheme == self.VVEO7C : return 0.5
  else             : return 1
class CC1WBa(object):
 def __init__(self):
  self.appContainers = {}
  self.appResults  = {}
  self.dataAvailFnc = {}
  self.VVCeou = {}
  self.commandRunning = False
  self.VVFsmA  = fileExists("/etc/apt/apt.conf")
 def ePopen(self, cmd, VVCeou, dataAvailFnc=None, curDir=None):
  self.commandRunning = True
  name = cmd
  i  = 0
  while name in self.appContainers:
   name = cmd +'_'+ str(i)
   i += 1
  self.appResults[name] = ""
  self.dataAvailFnc[name] = dataAvailFnc
  self.VVCeou[name] = VVCeou
  try:
   from enigma import eConsoleAppContainer
   self.appContainers[name] = eConsoleAppContainer()
   if self.VVFsmA:
    self.appContainers[name].dataAvail_conn = self.appContainers[name].dataAvail.connect(BF(self.VVj2hS, name))
    self.appContainers[name].appClosed_conn = self.appContainers[name].appClosed.connect(BF(self.VVyx3l , name))
   else:
    self.appContainers[name].dataAvail.append(BF(self.VVj2hS, name))
    self.appContainers[name].appClosed.append(BF(self.VVyx3l , name))
  except:
   self.commandRunning = False
   return False
  if isinstance(cmd, str):
   cmd = [cmd]
  if curDir:
   try:
    self.appContainers[name].setCWD(curDir)
   except:
    pass
  retval = self.appContainers[name].execute(*cmd)
  if retval:
   self.VVyx3l(name, retval)
  return True
 def VVj2hS(self, name, data):
  try:
   data = data.decode("UTF-8")
  except:
   data = "%s%s\n" % ("" if self.appResults[name].endswith("\n") else "\n", FFGB9z("[UN-DECODED STRING]", VVLbyB))
  self.appResults[name] += data
  if self.dataAvailFnc[name]:
   self.dataAvailFnc[name](data)
 def VVyx3l(self, name, retval):
  if not self.VVFsmA:
   del self.appContainers[name].dataAvail[:]
   del self.appContainers[name].appClosed[:]
  del self.appContainers[name]
  del self.dataAvailFnc[name]
  self.commandRunning = False
  if self.VVCeou[name]:
   self.VVCeou[name](self.appResults[name], retval)
  del self.VVCeou[name]
 def VVGTWr(self):
  return self.commandRunning
 def kill(self, name):
  if name in self.appContainers:
   self.appContainers[name].kill()
 def killAll(self):
  for name in self.appContainers:
   self.kill(name)
  self.commandRunning = False
class CCUEpT(Screen):
 def __init__(self, session, title="", VVA1ht=None, VVMP7V=False, VVpphv=False, VVWnWi=False, VVk2KC=False, VVw8D9=False, VV0qCB=False, VV4VK0=VVP6Rb, VVYxQ2=None, VV6oi7=False, VVOuQk=None, VVRkcg="", checkNetAccess=False, VVTFXq=30, consFont=False, enableSaveRes=True):
  self.skin, self.skinParam = FFRBRO(VVAtoE, 1600, 1000, 50, 40, 20, "#22003040", "#22001122", VVTFXq, usefixedFont=consFont)
  self.session   = session
  self.VVRkcg = VVRkcg
  FFmmH7(self, addScrollLabel=True)
  self.VVMP7V   = VVMP7V
  self.VVpphv   = VVpphv
  self.VVWnWi   = VVWnWi
  self.VVk2KC  = VVk2KC
  self.VVw8D9 = VVw8D9
  self.VV0qCB = VV0qCB
  self.VV4VK0   = VV4VK0
  self.VVYxQ2 = VVYxQ2
  self.VV6oi7  = VV6oi7
  self.VVOuQk  = VVOuQk
  self.checkNetAccess  = checkNetAccess
  self.enableSaveRes  = enableSaveRes
  self.cmdNum    = 0
  self.container   = CC1WBa()
  self.justStarted  = True
  self.dataFound   = False
  if len(title) == 0:
   title = FFwrBW()
  self["myTitle"].setText("  %s" % title)
  if isinstance(VVA1ht, str):
   self.VVA1ht = [VVA1ht]
  else:
   self.VVA1ht = VVA1ht
  if self.VVWnWi or self.VVk2KC:
   restartNote = "%s\\\\nGUI WILL RESTART NOW\\\\n%s" % (SEP, SEP)
   self.VVA1ht.append("echo -e '\n%s\n' %s" % (restartNote, FFXRSi(restartNote, VVVCGb)))
   if self.VVWnWi:
    self.VVA1ht.append("sleep 3; if which systemctl > /dev/null 2>&1; then systemctl restart enigma2; else init 4; sleep 3; init 3; fi")
   else:
    self.VVA1ht.append("sleep 3; killall -9 enigma2; if which systemctl > /dev/null 2>&1; then systemctl start enigma2; else init 3; fi")
  if self.VVw8D9:
   FF5uKN(self, "Processing ...")
  self.onLayoutFinish.append(self.VVUhFE)
  self.onClose.append(self.VV59NM)
 def VVUhFE(self):
  self["myLabel"].VVlfXl(outputFileToSave="console" if self.enableSaveRes else "")
  self["myLabel"].setText("   %s" % (self.VVRkcg or "Processing ..."))
  if self.VVMP7V:
   self["myLabel"].VVFhN7()
  if self.checkNetAccess:
   self["myLabel"].setText("  Checking Internet ...")
   self.VV4iu5()
  else:
   self.VVZMdr()
 def VV4iu5(self):
  if CC66h0.VVP0Wq():
   self["myLabel"].setText("Processing ...")
   self.VVZMdr()
  else:
   self["myLabel"].setText(FFGB9z("\n   No connection to internet!", VVsObI))
 def VVZMdr(self):
  allOK = self.container.ePopen(self.VVA1ht[0], self.VVBZn0, dataAvailFnc=self.dataAvail)
  if not allOK:
   self.VVBZn0("Cannot connect to Console!", -1)
 def dataAvail(self, txt):
  if len(txt) > 0:
   self.dataFound = True
  if self.justStarted:
   self.justStarted = False
   if self.VV0qCB or self.VVWnWi or self.VVk2KC:
    self["myLabel"].setText(FFfR82("STARTED", VVVCGb) + "\n")
   else:
    self["myLabel"].setText("")
  if self.VVOuQk:
   colorWhite = CCspY4.VV0CtV(VVqFea)
   color  = CCspY4.VV0CtV(self.VVOuQk[0])
   words  = self.VVOuQk[1:]
   for word in words:
    txt = iSub(r"(%s)" % iEscape(word), r"%s\1%s" % (color, colorWhite), txt, flags=IGNORECASE)
  self["myLabel"].appendText(txt, VV4VK0=self.VV4VK0)
 def VVBZn0(self, data, retval):
  self.cmdNum += 1
  if self.cmdNum != len(self.VVA1ht):
   allOK = self.container.ePopen(self.VVA1ht[self.cmdNum], self.VVBZn0, dataAvailFnc=self.dataAvail)
   if not allOK:
    self.VVBZn0("Cannot connect to Console!", -1)
  else:
   if self.VVw8D9 and FFBF0K(self):
    FF5uKN(self)
   if not self.dataFound:
    self["myLabel"].setText("No result.")
   if self.VV0qCB:
    self["myLabel"].appendText("\n" + FFfR82("FINISHED", VVVCGb), self.VV4VK0)
   if self.VVMP7V or self.VVpphv:
    self["myLabel"].VVFhN7()
   if self.VVYxQ2 is not None:
    self.VVYxQ2()
   if not retval and self.VV6oi7:
    self.VV59NM()
 def VV59NM(self):
  if self.container.VVGTWr():
   self.container.killAll()
class CC03Db(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFRBRO(VVAtoE, 1650, 950, 40, 20, 20, "#22200010", "#0a202020", 28, barHeight=40, usefixedFont=True)
  self.session   = session
  self.commandHistoryFile = VVNemM + "ajpanel_terminal.history"
  self.customCommandsFile = ""
  self.lastCommand  = "ls"
  self.prompt    = ">>"
  self.curDir    = FF3RLi("pwd") or "/home/root"
  self.container   = CC1WBa()
  self.commandsList  = []
  self.exitBtnText  = "Exit = Interrupt"
  FFmmH7(self, title="Terminal", addScrollLabel=True)
  FFR9Qm(self["keyRed"] , self.exitBtnText)
  FFR9Qm(self["keyGreen"] , "OK = History")
  FFR9Qm(self["keyYellow"], "Menu = Custom Cmds")
  FFR9Qm(self["keyBlue"] , "0 - 9 = Keyboard")
  self["myAction"].actions.update(
  {
   "ok" : self.VVa0qP ,
   "cancel": self.VVRmYm  ,
   "menu" : self.VV35Ci ,
   "last" : self.VV7dMN  ,
   "next" : self.VV7dMN  ,
   "1"  : self.VV7dMN  ,
   "2"  : self.VV7dMN  ,
   "3"  : self.VV7dMN  ,
   "4"  : self.VV7dMN  ,
   "5"  : self.VV7dMN  ,
   "6"  : self.VV7dMN  ,
   "7"  : self.VV7dMN  ,
   "8"  : self.VV7dMN  ,
   "9"  : self.VV7dMN  ,
   "0"  : self.VV7dMN
  })
  self.onLayoutFinish.append(self.VV0wap)
  self.onClose.append(self.VVzlMt)
 def VV0wap(self):
  self["myLabel"].VVlfXl(isResizable=False, outputFileToSave="terminal")
  FFHNWi(self["keyRed"]  , "#00ff8000")
  FFWN9Z(self["keyRed"]  , self.skinParam["titleColor"])
  FFWN9Z(self["keyGreen"]  , self.skinParam["titleColor"])
  FFWN9Z(self["keyYellow"] , self.skinParam["titleColor"])
  FFWN9Z(self["keyBlue"] , self.skinParam["titleColor"])
  self.VVBmJ9(FF3RLi("date"), 5)
  result = FF3RLi("tUSER=$(whoami) || tUSER=""; tHOST=$(hostname) || tHOST=""; echo $tUSER,$tHOST")
  if result and "," in result:
   result = result.replace(",", "@")
   if len(result) < 15:
    self.prompt = result + " "
  self.prompt = "\n" + self.prompt
  self.VVcwDq()
  self.VVDj5B()
 def VVDj5B(self):
  userFile = CFG.terminalCmdFile.getValue()
  alterFile = VVNemM + "LinuxCommands.lst"
  templPath = VVrrZu + "ajpanel_cmd_list"
  if   fileExists(userFile) : self.customCommandsFile = userFile
  elif fileExists(alterFile): self.customCommandsFile = alterFile
  else:
   res = FFuB0V("cp -f '%s' '%s'" % (templPath, alterFile))
   if not res == 0:
    with open(alterFile, "w") as f:
     f.write("pwd\ncd\ncd /tmp\nls\nls -ls\n")
   self.customCommandsFile = alterFile
 def VVzlMt(self):
  if self.container.VVGTWr():
   self.container.killAll()
   self.VVBmJ9("Process killed\n", 4)
   self.VVcwDq()
 def VVRmYm(self):
  if self.container.VVGTWr():
   self.VVzlMt()
  else:
   FFNKVM(self, self.close, "Exit ?", VVvAFb=False)
 def VVcwDq(self):
  self.VVBmJ9(self.prompt, 1)
  self["keyRed"].hide()
 def VVBmJ9(self, txt, mode):
  if   mode == 1 : color = VVVCGb
  elif mode == 2 : color = VVkqaK
  elif mode == 3 : color = VVqFea
  elif mode == 4 : color = VVsObI
  elif mode == 5 : color = VVGb6D
  elif mode == 6 : color = VV7jS2
  else   : color = VVqFea
  try:
   self["myLabel"].appendText(FFGB9z(txt, color))
  except:
   pass
 def VVa0qP(self):
  title = "Command History"
  if not fileExists(self.commandHistoryFile) or self.VVo9NV() == "":
   self.VVdDlb("cd /tmp")
   self.VVdDlb("ls")
  VVX3wb = []
  if fileExists(self.commandHistoryFile):
   lines  = FFZQjt(self.commandHistoryFile)
   c  = 0
   lNum = len(lines) + 1
   for line in reversed(lines):
    line = line.strip()
    lNum -= 1
    if line and not line.startswith("#"):
     c += 1
     VVX3wb.append((str(c), line, str(lNum)))
   self.VVWTro(VVX3wb, title, self.commandHistoryFile, isHistory=True)
  else:
   FFZoTn(self, self.commandHistoryFile, title=title)
 def VVo9NV(self):
  lastLine = FF3RLi("grep '.' '%s' | tail -1" % self.commandHistoryFile)
  return lastLine.strip()
 def VVdDlb(self, cmd):
  with open(self.commandHistoryFile, "a") as f:
   f.write("%s\n" % cmd)
 def VV35Ci(self, VVxBfP=None):
  title = "Custom Commands"
  if fileExists(self.customCommandsFile):
   lines = FFZQjt(self.customCommandsFile)
   VVX3wb = []
   c  = 0
   lNum = 0
   for line in lines:
    line = line.strip()
    lNum += 1
    if line:
     c += 1
     if not iMatch("^[a-zA-Z0-9_]", line):
      line = "#f#00FF8055#" + line
     VVX3wb.append((str(c), line, str(lNum)))
   if VVxBfP:
    VVxBfP.VVcckS(VVX3wb)
    VVxBfP.VVYNxS(CFG.lastTerminalCustCmdLineNum.getValue())
   else:
    self.VVWTro(VVX3wb, title, filePath=self.customCommandsFile, isHistory=False)
  else:
   FFZoTn(self, self.customCommandsFile, title=title)
 def VVWTro(self, VVX3wb, title, filePath=None, isHistory=False):
  if VVX3wb:
   VVkUYa = "#05333333"
   if isHistory: VVDlGi = VVaSSM = VVzgHY = "#11000020"
   else  : VVDlGi = VVaSSM = VVzgHY = "#06002020"
   VVwmV1   = ("Send"   , BF(self.VVOL8p, isHistory)  , [])
   VVX66G  = ("Modify & Send" , self.VVCJ8C     , [])
   if isHistory:
    VVIrDY = ("Clear History" , self.VV01U4     , [])
    VVFadD = None
    VVs5AA = None
   elif filePath:
    VVIrDY = ("Options"  , self.VV63Os      , [])
    VVFadD = ("Edit File"  , BF(self.VVNtA4, filePath) , [])
    VVs5AA = (""    , self.VVZ35m     , [])
   header  = ("No." , "Commands", "LineNum" )
   widths  = (7  , 93   , 0    )
   VVFvCJ = (CENTER , LEFT   , CENTER )
   VVxBfP = FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD, VVs5AA=VVs5AA, lastFindConfigObj=CFG.lastFindTerminal, VVUdUN=True, searchCol=1
         , VVDlGi=VVDlGi, VVaSSM=VVaSSM, VVzgHY=VVzgHY, VVkUYa=VVkUYa)
   if not isHistory:
    VVxBfP.VVYNxS(CFG.lastTerminalCustCmdLineNum.getValue())
  else:
   FFNKVM(self, BF(self.VVGguy, None, "Change Custom Commands File"), "File is empty:\n\n%s\n\nSelect another file ?" % self.customCommandsFile, title=title)
 def VVZ35m(self, VVxBfP, title, txt, colList):
  txt  = "%s\n%s\n\n" % (FFGB9z("Command:", VVUVAI), colList[1])
  txt += "%s\n%s\n\n" % (FFGB9z("Line %s in File:" % colList[2], VVUVAI), self.customCommandsFile)
  FF90Bc(self, txt, title=title)
 def VV63Os(self, VVxBfP, title, txt, colList):
  mSel = CCHw3d(self, VVxBfP)
  VVZJ87 = []
  txt1 = "Change Custom Commands File"
  if VVxBfP.VVQW9r:
   VVZJ87.append((txt1, ))
   VVZJ87.append(VVoqHH)
   totSel = VVxBfP.VVsyP1()
   totTxt = str(totSel)
   txt2 = "Send %s Command%s" % (FFGB9z(totTxt, VVVCGb) if totSel else totTxt, FF1I1d(totSel))
   VVZJ87.append((txt2, "send") if totSel else (txt2,))
  else:
   VVZJ87.append((txt1, "newFile"))
   VVZJ87.append(VVoqHH)
   txt2 = "Send current line"
   VVZJ87.append((txt2, "send"))
  cbFncDict = { "newFile" : BF(self.VVGguy, VVxBfP, txt1)
     , "send" : BF(self.VVOL8p, False, VVxBfP, title, txt2, colList) }
  mSel.VVsKHw(VVZJ87, cbFncDict, okFnc=BF(self.VVYlcv, VVxBfP))
 def VVGguy(self, VVxBfP, title):
  VVZJ87 = []
  for fName in os.listdir(VVNemM):
   path = os.path.join(VVNemM, fName)
   if fName.lower().startswith(("ajpanel_cmd", "linuxcommands")) and os.path.isfile(path):
    VVZJ87.append((fName, path))
  VVZJ87.sort(key=lambda x: x[0].lower())
  if VVZJ87 : FFYySC(self, BF(self.VVeGeA, VVxBfP, title), VVZJ87=VVZJ87, title=title, minRows=3, VVDlGi="#11220000", VVaSSM="#11220000")
  else  : FFw5OO(self, "No valid files found in:\n\n%s" % VVNemM, title=title)
 def VVeGeA(self, VVxBfP, title, path=None):
  if path:
   if CCCXvS.VVkuoi(path):
    FFw5OO(self, "Incorrect file format:\n\n%s" % path, title=title)
   else:
    lines = FFZQjt(path)
    for line in lines:
     if line.strip():
      oldF = self.customCommandsFile
      self.customCommandsFile = path
      FFdEZ4(CFG.terminalCmdFile, path)
      if not oldF == self.customCommandsFile:
       FFdEZ4(CFG.lastTerminalCustCmdLineNum, 0)
      self.VV35Ci(VVxBfP)
      break
    else:
     FFw5OO(self, "File is empty:\n\n%s" % path, title=title)
 def VVYlcv(self, VVxBfP):
  if VVxBfP.VVQW9r : VVxBfP.VVJSaW()
  else        : VVxBfP.VV1uwH()
 def VVOL8p(self, isHistory, VVxBfP, title, txt, colList):
  if VVxBfP.VVQW9r:
   lst = VVxBfP.VVf36z(1)
   curNdx = VVxBfP.VVoXzr()
  else:
   lst = [colList[1]]
   curNdx = VVxBfP.VVgu5W()
  if not isHistory:
   FFdEZ4(CFG.lastTerminalCustCmdLineNum, curNdx)
  self.commandsList = lst
  VVxBfP.cancel()
  FFFANg(self.VVHGeu)
 def VVHGeu(self):
  if self.commandsList:
   cmd = self.commandsList[0]
   self.commandsList.pop(0)
   if not iMatch("^[a-zA-Z0-9_]", cmd):
    self.VVBmJ9("\n%s\n" % cmd, 6)
    self.VVBmJ9(self.prompt, 1)
    self.VVHGeu()
   else:
    self.VVoDgc(cmd)
 def VVoDgc(self, cmd):
  tot = len(self.commandsList)
  self["keyRed"].setText("%s%s" % (self.exitBtnText, " (%s)" % tot if tot > 0 else ""))
  self["keyRed"].show()
  if cmd.startswith("passwd"):
   self.VVBmJ9(cmd, 2)
   self.VVBmJ9("\nCannot change passwrod from Console this way. Try using:\n", 4)
   txt = 'echo -e "NEW_PASSWORD\#nNEW_PASSWORD" | passwd'
   for ch in txt:
    if not ch == "#":
     self.VVBmJ9(ch, 0)
   self.VVBmJ9("\nor\n", 4)
   self.VVBmJ9("echo root:NEW_PASSWORD | chpasswd\n", 0)
   self.VVcwDq()
  else:
   cmd = cmd.strip()
   if "#" in cmd:
    parts = cmd.split("#")
    left  = FFGB9z(parts[0].strip(), VVkqaK)
    right = FFGB9z("#" + parts[1].strip(), VV7jS2)
    txt = "%s    %s\n" % (left, right)
   else:
    txt = "%s\n" % cmd
   self.VVBmJ9(txt, 2)
   lastLine = self.VVo9NV()
   if not lastLine or not cmd == lastLine:
    self.lastCommand = cmd
    self.VVdDlb(cmd)
   span = iSearch(r".*cd\s+([\/?\w\.+\~]+)", cmd + ";")
   if span:
    self.curDir = span.group(1)
   allOK = self.container.ePopen(cmd, self.VVBZn0, dataAvailFnc=self.dataAvail, curDir=self.curDir)
   if not allOK:
    FFw5OO(self, "Cannot connect to Console!")
   self.lastCommand = cmd
 def dataAvail(self, data):
  self.VVBmJ9(data, 3)
 def VVBZn0(self, data, retval):
  if not retval == 0:
   self.VVBmJ9("Exit Code : %d\n" % retval, 4)
  self.VVcwDq()
  if self.commandsList:
   self.VVHGeu()
 def VVCJ8C(self, VVxBfP, title, txt, colList):
  if VVxBfP.VV0aFP():
   cmd = colList[1]
   self.VVrNQQ(VVxBfP, cmd)
 def VV01U4(self, VVxBfP, title, txt, colList):
  FFNKVM(self, BF(self.VVAK7I, VVxBfP), "Reset History File ?", title="Command History")
 def VVAK7I(self, VVxBfP):
  FFuB0V("echo '' > %s" % self.commandHistoryFile)
  VVxBfP.cancel()
 def VVNtA4(self, filePath, VVxBfP, title, txt, colList):
  rowNum = int(colList[2].strip()) - 1
  if fileExists(filePath) : CCQ3ND(self, filePath, VVCeou=BF(self.VV734p, VVxBfP), curRowNum=rowNum)
  else     : FFZoTn(self, filePath)
 def VV734p(self, VVxBfP, fileChanged):
  if fileChanged:
   VVxBfP.cancel()
   FFFANg(self.VV35Ci)
 def VV7dMN(self):
  self.VVrNQQ(None, self.lastCommand)
 def VVrNQQ(self, VVxBfP, cmd):
  if "#" in cmd:
   cmd = cmd.split("#")[0].strip()
  FFaSvq(self, BF(self.VVI7jE, VVxBfP), title="Terminal", defaultText=cmd, message="Enter Command:")
 def VVI7jE(self, VVxBfP, cmd):
  if cmd and len(cmd) > 0:
   self.VVoDgc(cmd)
   if VVxBfP:
    VVxBfP.cancel()
class CCQGiA(Screen):
 def __init__(self, session, title="", message="", VV4VK0=VVP6Rb, width=1400, height=900, VVbYzk=False, titleBg="#22002020", VVzgHY="#22001122", VVTFXq=30, titleFontSize=50, outputFileToSave=""):
  self.skin, self.skinParam = FFRBRO(VVAtoE, width, height, titleFontSize, 30, 20, titleBg, VVzgHY, VVTFXq)
  self.session   = session
  FFmmH7(self, title, addScrollLabel=True)
  self.VV4VK0   = VV4VK0
  self.VVbYzk   = VVbYzk
  self.VVzgHY   = VVzgHY
  self.outputFileToSave = outputFileToSave
  if isinstance(message, list):
   try:
    self.message = "\n".join(message)
   except:
    pass
  self.message = str(message)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  self["myLabel"].VVlfXl(VVbYzk=self.VVbYzk, outputFileToSave=self.outputFileToSave)
  self["myLabel"].setText(self.message, self.VV4VK0)
  self["myLabel"].VVFhN7()
class CCCCSM(Screen):
 def __init__(self, session, title="", message=""):
  self.skin, self.skinParam = FFRBRO(VVQI2Y, 1200, 300, 50, 20, 0, "#22330000", "#22200000", 30)
  self.session = session
  FFmmH7(self, title, addLabel=True, addCloser=True)
  self["errPic"] = Pixmap()
  self["myLabel"].setText(message)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFDhpr(self["errPic"], "err")
class CCBOyu(Screen):
 def __init__(self, session, txt, fntSize):
  self.skin, self.skinParam = FFRBRO(VV2Zdx, 1000, 50, 20, 30, 20, "#FF000000", "#FF000000", fntSize)
  self.session  = session
  self["myWinTitle"] = Label()
  FFmmH7(self, " ", addCloser=True)
class CC03RI():
 def __init__(self, session, txt, timeout=1500, fonSize=24):
  self.session = session
  self.win  = CC03RI.VV9BLi(session, txt, fonSize)
  self.timer  = eTimer()
  try: self.timer_conn = self.timer.timeout.connect(self.VVnNQd)
  except: self.timer.callback.append(self.VVnNQd)
  self.timer.start(timeout, True)
 def VVnNQd(self):
  self.session.deleteDialog(self.win)
 @staticmethod
 def VV9BLi(session, txt, fonSize, shadW=2, shadColor="#440000", x=30, y=20):
  win = session.instantiateDialog(CCBOyu, txt.strip(), fonSize)
  win.instance.move(ePoint(x, y))
  win.show()
  FFy4xL(win["myWinTitle"], shadColor, shadW)
  CC03RI.VVxNiI(win, txt)
  return win
 @staticmethod
 def VVxNiI(win, txt):
  win["myWinTitle"].setText(txt.strip())
  inst = win["myWinTitle"].instance
  w = inst.calculateSize().width() + 30
  h = int(inst.size().height())
  inst.resize(eSize(*(w, h)))
  win.instance.resize(eSize(*(w, h)))
class CCrhIe():
 VVuKyr    = 0
 VVjJlp  = 1
 VVPSlX   = ""
 VV1woa    = "ajpDownload"
 def __init__(self, SELF, mode, title, startDnld, decodedUrl=""):
  self.SELF     = SELF
  self.mode     = mode
  self.Title     = title
  self.VVxBfP   = None
  self.timer     = eTimer()
  self.VVcuW1   = 0
  self.VVYGCu  = 1
  self.VV2Hjl  = 2
  self.VVxnPU   = 3
  self.VVLYwy   = 4
  VVX3wb = self.VVTEig()
  if VVX3wb:
   self.VVxBfP = self.VVXEXp(VVX3wb)
  if not VVX3wb and mode == self.VVuKyr:
   self.VVl8O9("Download list is empty !")
   self.cancel()
  if mode == self.VVjJlp:
   FFJsIX(self.VVxBfP or self.SELF, BF(self.VVPWQM, startDnld, decodedUrl), title="Checking Server ...")
  self.VV9Fn3(force=True)
  try:
   self.timer_conn = self.timer.timeout.connect(self.VV9Fn3)
  except:
   self.timer.callback.append(self.VV9Fn3)
  self.timer.start(1000, False)
 def VVXEXp(self, VVX3wb):
  VVX3wb.sort(key=lambda x: int(x[0]))
  VV0xpR = self.VVekS2
  VVwmV1  = ("Play"  , self.VVgND2 , [])
  VVs5AA = (""   , self.VVBxaU  , [])
  VVZ224 = ("Stop"  , self.VVOaaH  , [])
  VVX66G = ("Resume"  , self.VVa6UO , [])
  VVIrDY = ("Options" , self.VVj67V  , [])
  header   = ("No." , "Name" , "Type", "File Size", "Status" , "Progress", "Path", "sizeVal" , "URL" , "decodedUrl" , "oldSize" , "Speed" , "m3u8Log" )
  widths   = (5  , 39  , 8  , 13   , 13   , 11   , 0.01 , 0   , 0.01 , 0    , 0   , 11  , 0   )
  VVFvCJ  = (CENTER, LEFT  , CENTER, CENTER  , CENTER , CENTER , LEFT , CENTER , LEFT , LEFT   , CENTER , CENTER , LEFT  )
  return FF1Dpj(self.SELF, None, title=self.Title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VVwmV1=VVwmV1, VVs5AA=VVs5AA, VV0xpR=VV0xpR, VVZ224=VVZ224, VVX66G=VVX66G, VVIrDY=VVIrDY, lastFindConfigObj=CFG.lastFindIptv, VVDlGi="#11220022", VVaSSM="#11110011", VVzgHY="#11110011", VVkUYa="#00223025", VVivoO="#0a333333", VVdjpa="#0a400040", VVUdUN=True, searchCol=1)
 def VVTEig(self):
  lines = CCrhIe.VVLbph()
  VVX3wb = []
  if lines:
   for ndx, line in enumerate(lines):
    if "," in line:
     parts  = line.split(",", 1)
     left  = parts[0].strip()
     decodedUrl = parts[1].strip()
     if left == "-1" or left.isdigit(): size, m3u8Log = int(left), ""
     else        : size, m3u8Log = -1  , left
     if decodedUrl:
      fName, chName, url = self.VV4Ojj(decodedUrl)
      if fName:
       if   FF7cGO(decodedUrl) : sType = "Movie"
       elif FFe0eK(decodedUrl) : sType = "Series"
       else      : sType = ""
       path = self.VV7qK2(decodedUrl, fName)
       if size > -1: sizeTxt = CCCXvS.VVutW7(size, mode=4)
       else  : sizeTxt = ""
       status = prog = speed = oldSize = ""
       VVX3wb.append((str(len(VVX3wb) + 1), chName, sType, sizeTxt, status, prog, path, str(size), url, decodedUrl, oldSize, speed, m3u8Log))
  return VVX3wb
 def VVJRI7(self):
  VVX3wb = self.VVTEig()
  if VVX3wb:
   if self.VVxBfP : self.VVxBfP.VVcckS(VVX3wb, VVuO90Msg=False)
   else     : self.VVxBfP = self.VVXEXp(VVX3wb)
  else:
   self.cancel()
 def VV9Fn3(self, force=False):
  if self.VVxBfP:
   thrListUrls = self.VVyZ0J()
   VVX3wb = []
   changed = False
   for ndx, row in enumerate(self.VVxBfP.VVlHja()):
    row = list(map(str.strip, row))
    num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log = row
    flag = self.VVcuW1
    if m3u8Log:
     percent = CCrhIe.VVMUAC(m3u8Log)
     if percent > -1:
      if percent < 100: flag, progr = self.VVxnPU , "%.2f %%" % percent
      else   : flag, progr = self.VVLYwy , "100 %"
     mPath = m3u8Log[:-9]
     curSize = FFqLWj(mPath)
     if curSize > -1:
      fSize = CCCXvS.VVutW7(curSize, mode=4)
     try:
      if not oldSize in ("", "0", "-"):
       diff = int(curSize - int(oldSize))
       if diff:
        speed = CCCXvS.VVutW7(diff, mode=4) + "/s"
     except:
      pass
    else:
     curSize = FFqLWj(path)
     if curSize > -1:
      if sizeV.isdigit():
       percent = float(curSize) / float(sizeV) * 100.0
       if percent < 100: flag, progr = self.VVxnPU , "%.2f %%" % percent
       else   : flag, progr = self.VVLYwy , "100 %"
       try:
        if not oldSize in ("", "0", "-"):
         diff = int(curSize - int(oldSize))
         if diff:
          speed = CCCXvS.VVutW7(diff, mode=4) + "/s"
       except:
        pass
    if decodedUrl in thrListUrls:
     flag = self.VV2Hjl
     if m3u8Log :
      if not speed and not force : flag = self.VVYGCu
      elif curSize == -1   : self.VV7Jgq(False)
    elif flag == self.VVcuW1  : speed = progr = "-"
    else        : speed = "-"
    color1 = "#f#00FF9999#" if m3u8Log else ""
    if   flag == self.VVcuW1  : color2 = "#f#00555555#"
    elif flag == self.VVYGCu : color2 = "#f#0000FFFF#"
    elif flag == self.VV2Hjl : color2 = "#f#0000FFFF#"
    elif flag == self.VVxnPU  : color2 = "#f#00FF8000#"
    elif flag == self.VVLYwy  : color2 = "#f#0000FF00#"
    else        : color2 = "#f#00AAAAAA#"
    state = self.VVhhBz(flag)
    oldSize = str(curSize)
    if [num, name, typ, fSize, state, progr, path, sizeV, url, decodedUrl, oldSize, speed, m3u8Log] != row:
     changed = True
    row[1]  = color1 + name
    row[2]  = color1 + typ
    row[3]  = color1 + fSize
    row[4]  = color2 + state
    row[5]  = color2 + progr
    row[10] = oldSize
    row[11] = speed if not speed.startswith("-") else "-"
    VVX3wb.append(row)
   if changed or force:
    self.VVxBfP.VVcckS(VVX3wb, VVuO90Msg=False)
 def VVhhBz(self, flag):
  tDict = self.VVxV61()
  return tDict.get(flag, "?")
 def VVZIja(self, state):
  for flag, txt in self.VVxV61().items():
   if txt == state:
    return flag
  return -1
 def VVxV61(self):
  return { self.VVcuW1: "Not started", self.VVYGCu: "Connecting", self.VV2Hjl: "Downloading", self.VVxnPU: "Stopped", self.VVLYwy: "Completed" }
 def VVMlIQ(self, title):
  colList = self.VVxBfP.VVc6YJ()
  path = colList[6]
  url  = colList[8]
  if self.VVYkNc() : self.VVl8O9("Cannot delete !\n\nFile is downloading.")
  else      : FFNKVM(self.SELF, BF(self.VV0twv, path, url), "Delete ?\n\n%s" % path, title=title)
 def VV0twv(self, path, url):
  m3u8Log = self.VVxBfP.VVc6YJ()[12]
  if m3u8Log : FFuB0V("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  else  : FFuB0V("rm -rf '%s'" % path)
  self.VVHPgY(False)
  self.VVJRI7()
 def VVHPgY(self, VV70Sp=True):
  if self.VVYkNc():
   FF5uKN(self.VVxBfP, self.VVhhBz(self.VV2Hjl), 500)
  else:
   colList  = self.VVxBfP.VVc6YJ()
   state  = colList[4]
   decodedUrl = colList[9]
   if self.VVZIja(state) in (self.VVcuW1, self.VVLYwy, self.VVxnPU):
    lines = CCrhIe.VVLbph()
    newLines = []
    found = False
    for line in lines:
     if CCrhIe.VVUXpP(decodedUrl, line): found = True
     else            : newLines.append(line)
    if found:
     self.VVrY0U(newLines)
     self.VVJRI7()
     FF5uKN(self.VVxBfP, "Removed.", 1000)
    else:
     FF5uKN(self.VVxBfP, "Not found.", 1000)
   elif VV70Sp:
    self.VVl8O9("Cannot remove partial download !\n\nYou can delete the file (from options).")
 def VVxUi8(self, flag, title):
  ques = "Only remove from table (no file deletion).\n\nContinue ?"
  FFNKVM(self.SELF, BF(self.VVmgAk, flag), ques, title=title)
 def VVmgAk(self, flag):
  list = []
  for ndx, row in enumerate(self.VVxBfP.VVlHja()):
   state  = row[4].strip()
   decodedUrl = row[9].strip()
   flagVal  = self.VVZIja(state)
   if   flag == flagVal == self.VVLYwy: list.append(decodedUrl)
   elif flag == flagVal == self.VVcuW1 : list.append(decodedUrl)
  lines = CCrhIe.VVLbph()
  totRem = 0
  newLines = []
  for line in lines:
   if any(x in line for x in list) : totRem += 1
   else       : newLines.append(line)
  if totRem > 0:
   self.VVrY0U(newLines)
   self.VVJRI7()
   FF5uKN(self.VVxBfP, "%d removed." % totRem, 1000)
  else:
   FF5uKN(self.VVxBfP, "Not found.", 1000)
 def VVlFGs(self):
  colList  = self.VVxBfP.VVc6YJ()
  path  = colList[6]
  decodedUrl = colList[9]
  png   = "%s.png" % os.path.splitext(path)[0]
  if fileExists(png) : FF5uKN(self.VVxBfP, "Poster exists", 1500)
  else    : FFJsIX(self.VVxBfP, BF(self.VV1T3s, decodedUrl, path, png), title="Checking Server ...")
 def VV1T3s(self, decodedUrl, path, png):
  err = self.VVwaHL(decodedUrl, path, png)
  if err:
   FFw5OO(self.SELF, err, title="Poster Download")
 def VVwaHL(self, decodedUrl, path, png):
  if "chCode" in decodedUrl:
   decodedUrl = CCsdD3.VVF0ln(decodedUrl)
   if not decodedUrl:
    return "Portal connection error !"
  pUrl = ""
  uType, uHost, uUser, uPass, uId, uChName = CC9X9s.VVXxn6(decodedUrl)
  if all([uHost, uUser, uPass, uId]):
   qUrl = "%s/player_api.php?username=%s&password=%s&action=get_vod_info&vod_id=%s" % (uHost, uUser, uPass, uId)
   txt, err = CC9X9s.VVuaOC(qUrl, timeout=1)
   if err:
    return "Cannot get Poster URL from server !\n\n%s" % err
   else:
    try:
     tDict = jLoads(txt)
     pUrl = CC9X9s.VVV2zK(tDict["info"], "movie_image")
    except:
     return "Cannot parse Poster URL !"
  if not pUrl:
   return "No Poster data from server !"
  ext = os.path.splitext(pUrl)[1] or ".png"
  tPath, err = FFtKyC(pUrl, "ajp_tmp%s" % ext, timeout=2, mustBeImage=True)
  if err:
   return "Cannot download poster !\n\n%s" % err
  else:
   png = "%s%s" % (os.path.splitext(path)[0], ext)
   FFuB0V("mv -f '%s' '%s'" % (tPath, png))
   CCo6hs.VVhaNU(self.SELF, VVbLQv=png, showGrnMsg="Downloaded")
   return ""
 def VVBxaU(self, VVxBfP, title, txt, colList):
  def VVpQZy(key, val) : return "%s\t: %s\n" % (key, val.strip())
  def VVYPGf(key, val) : return "\n%s:\n%s\n" % (FFGB9z(key, VVUVAI), val.strip())
  heads  = self.VVxBfP.VVCpTV()
  txt = ""
  for i in range(6):
   if i == 3:
    totSize = colList[7].strip()
    curSize = colList[10].strip()
    if totSize and totSize.isdigit(): txt += VVpQZy(heads[i]  , CCCXvS.VVutW7(int(totSize), mode=0))
    if curSize and curSize.isdigit(): txt += VVpQZy("Downloaded" , CCCXvS.VVutW7(int(curSize), mode=0))
   else:
    txt += VVpQZy(heads[i], colList[i])
  if not "j.php" in colList[9]:
   for i in (6, 8):
    txt += VVYPGf(heads[i], colList[i])
  FF90Bc(self.SELF, txt, title=title)
 def VVgND2(self, VVxBfP, title, txt, colList):
  path = colList[6].strip()
  m3u8Log = colList[12].strip()
  if m3u8Log:
   path = m3u8Log[:-9]
  if fileExists(path) : CCCXvS.VVDPDb(self.SELF, path)
  else    : FF5uKN(self.VVxBfP, "File not found", 1000)
 def VVekS2(self, VVxBfP):
  self.cancel()
 def cancel(self):
  self.timer.stop()
  if self.VVxBfP:
   self.VVxBfP.cancel()
  del self
 def VVj67V(self, VVxBfP, title, txt, colList):
  c1, c2, c3 = VVMrXw, VVsObI, VVUVAI
  path  = colList[6].strip()
  decodedUrl = colList[9].strip()
  resumeTxt = "Disable" if CFG.downloadAutoResume.getValue() else "Enable"
  showMonitor = "Disable" if CFG.downloadMonitor.getValue() else "Enable"
  VVZJ87 = []
  VVZJ87.append((c1 + "Remove current row"       , "VVHPgY" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c1 + 'Remove all "Completed"'      , "remFinished"   ))
  VVZJ87.append((c1 + 'Remove all "Not started"'     , "remPending"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c2 + "Delete the file (and remove from list)"  , "VVMlIQ"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((resumeTxt + " Auto Resume"       , "VV22ap" ))
  VVZJ87.append((showMonitor + " On-screen Download Monitor"  , "toggleMonitor"  ))
  VVZJ87.append(VVoqHH)
  cond = FF7cGO(decodedUrl)
  VVZJ87.append(FFnqNr("Download Movie Poster %s" % ("(from server)" if cond else "... Movies only"), "VVlFGs", cond, c3))
  VVZJ87.append(FFnqNr("Open in File Manager", "inFileMan,%s" % path, fileExists(path), c3))
  FFYySC(self.SELF, BF(self.VVsV3o, VVxBfP), VVZJ87=VVZJ87, title=self.Title, VV18hv=True, width=800, VVhe5b=True, VVDlGi="#1a001122", VVaSSM="#1a001122")
 def VVsV3o(self, VVxBfP, item=None):
  if item:
   txt, ref, ndx = item
   if   ref == "VVHPgY"  : self.VVHPgY()
   elif ref == "remFinished"   : self.VVxUi8(self.VVLYwy, txt)
   elif ref == "remPending"   : self.VVxUi8(self.VVcuW1, txt)
   elif ref == "VVMlIQ" : self.VVMlIQ(txt)
   elif ref == "VVlFGs"  : self.VVlFGs()
   elif ref == "VV22ap"  : FFdEZ4(CFG.downloadAutoResume, not CFG.downloadAutoResume.getValue())
   elif ref == "toggleMonitor"   : FFdEZ4(CFG.downloadMonitor, not CFG.downloadMonitor.getValue())
   elif ref.startswith("inFileMan,") :
    path = ref.split(",", 1)[1]
    if pathExists(path) : self.SELF.session.open(CCCXvS, mode=CCCXvS.VVcDZO, jumpToFile=path)
    else    : FF5uKN(VVxBfP, "Path not found !", 1500)
 def VVPWQM(self, startDnld, decodedUrl):
  refreshToken = True
  if not decodedUrl:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self.SELF)
  else:
   ndx = decodedUrl.find("j.php")
   if ndx > -1:
    url = CCsdD3.VVF0ln(decodedUrl)
    if url:
     decodedUrl = url + decodedUrl[ndx + 5:]
     refreshToken = False
    else:
     self.VVl8O9("Could not get download link !\n\nTry again later.")
     return
  for line in CCrhIe.VVLbph():
   if CCrhIe.VVUXpP(decodedUrl, line):
    if self.VVxBfP:
     self.VV8GY8(decodedUrl)
     FFFANg(BF(FF5uKN, self.VVxBfP, "Already listed !", 2000))
    break
  else:
   params = self.VVIM0Y(decodedUrl, refreshToken)
   if len(params) == 1:
    self.VVl8O9(params[0])
   elif len(params) == 2:
    FFNKVM(self.SELF, BF(self.VVRAoq, params[0], decodedUrl), "Start downloading ?", title="Download (m3u8)")
   else:
    url, fSize, path, resp, resumable = params
    title= "Download : %s\n\n" % CCCXvS.VVutW7(fSize)
    FFNKVM(self.SELF, BF(self.VVPrTe, decodedUrl, url, fSize, path, resp, startDnld), "Download to\n\n%s" % path, title=title)
 def VVPrTe(self, decodedUrl, url, fSize, path, resp, startDnld):
  with open(CCrhIe.VVtjUp(), "a") as f:
   f.write("%s,%s\n" % (fSize, decodedUrl))
  self.VVJRI7()
  if self.VVxBfP:
   self.VVxBfP.VV5srZ()
  if startDnld:
   threadName = "%s{%s,Sz,}%s" % (CCrhIe.VV1woa, path, decodedUrl)
   self.VVCJV7(threadName, url, decodedUrl, path, resp)
 def VV8GY8(self, decodedUrl):
  if self.VVxBfP:
   for ndx, row in enumerate(self.VVxBfP.VVlHja()):
    decodedUrl2 = row[9].strip()
    if decodedUrl == decodedUrl2 and self.VVxBfP:
     self.VVxBfP.VVYNxS(ndx)
     break
 def VVIM0Y(self, decodedUrl, checkExist=True, resumeByte=-1, refreshToken=True):
  fName = ""
  if decodedUrl:
   fName, chName, url = self.VV4Ojj(decodedUrl)
  if not fName:
   return ["Cannot process URL parameters !"]
  path = self.VV7qK2(decodedUrl, fName)
  if checkExist and fileExists(path):
   return ["File already exists:\n\n%s" % path]
  if refreshToken and "chCode" in decodedUrl:
   url = CCsdD3.VVF0ln(decodedUrl)
   if not url:
    return ["Could not get download link from server!"]
  fSize = resumeFrom = resumeTo = 0
  resumable = False
  try:
   headers = CCsdD3.VVvvDS()
   if resumeByte > -1:
    headers["Range"] = "bytes=%d-" % resumeByte
   import requests
   resp = requests.get(url, headers=headers, timeout=3, stream=True, verify=False)
   if not resp.ok:
    return ["Err-%d : %s" % (resp.status_code, resp.reason)]
   head = resp.headers
   fSize = head.get("Content-Length", "")
   cType = head.get("Content-Type", "")
   resumable = CCrhIe.VV1r2k(resp)
  except:
   return ["Could not get file info from server !"]
  if not fSize or not fSize.isdigit():
   return ["Cannot get file size from server !"]
  fSize = int(fSize)
  if not "video" in cType and not "application/octet-stream" in cType:
   if resp.url.endswith(".m3u8"):
    return [resp, 1]
   elif not cType and resumable:
    pass
   else:
    return ["Cannot download this video !\n\nIncorrect download data (or not allowed by server)."]
  err = CCrhIe.VVhg69(fSize)
  if err:
   return [err]
  return [url, fSize, path, resp, resumable]
 def VVRAoq(self, resp, decodedUrl):
  if not FFhcfU("ffmpeg"):
   FFNKVM(self.SELF, BF(CC9X9s.VVHlli, self.SELF), '"FFmpeg" not found !\n\nInstall FFmpeg ?', title=chName)
   return
  fName, chName, url = self.VV4Ojj(decodedUrl)
  dest = os.path.join(CFG.MovieDownloadPath.getValue(), fName)
  self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
  rTxt = str(resp.text)
  rUrl = str(resp.url)
  if "#EXT-X-STREAM-INF" in rTxt:
   self.VVE1nW(rTxt, rUrl)
  elif "#EXTINF:" in rTxt:
   if fileExists(dest) : FFNKVM(self.SELF, BF(self.VVcUnc, rTxt, rUrl), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else    : self.VVcUnc(rTxt, rUrl)
  else:
   self.VVl8O9("Cannot process m3u8 file !")
 def VVE1nW(self, rTxt, rUrl):
  lst   = iFindall(r"RESOLUTION=(\d+x\d+).*\n(.+)", rTxt, IGNORECASE)
  VVZJ87 = []
  for resol, fPath in lst:
   resol = str(resol).replace("x", " x ")
   fPath = str(fPath)
   fullUrl = CC9X9s.VVr5Ek(rUrl, fPath)
   VVZJ87.append((resol, fullUrl))
  if VVZJ87:
   FFYySC(self.SELF, self.VVGE4a, VVZJ87=VVZJ87, title="Resolution", VV18hv=True, VVhe5b=True)
  else:
   self.VVl8O9("Cannot get Resolutions list from server !")
 def VVGE4a(self, item=None):
  if item:
   txt, resolUrl, ndx = item
   resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
   resol = txt.replace(" ", "")
   fPath, fExt = os.path.splitext(fName)
   fName = "%s_%s%s" % (fPath, resol, fExt)
   fPath, fExt = os.path.splitext(dest)
   dest = "%s_%s%s" % (fPath, resol, fExt)
   self.m3u8_params = resp, decodedUrl, dest, fName, chName, url
   if fileExists(dest):
    FFNKVM(self.SELF, BF(FFFANg, BF(self.VV3ahl, resolUrl)), "Overwrite existing file ?\n\n%s" % dest, title=chName)
   else:
    FFFANg(BF(self.VV3ahl, resolUrl))
 def VV3ahl(self, resolUrl):
  txt, err = CCsdD3.VV8GpE(resolUrl)
  if err : self.VVl8O9(err)
  else : self.VVcUnc(txt, resolUrl)
 def VVco96(self, logF, decodedUrl):
  found = False
  lines = CCrhIe.VVLbph()
  with open(CCrhIe.VVtjUp(), "w") as f:
   for line in lines:
    if CCrhIe.VVUXpP(decodedUrl, line):
     line = "%s,%s" % (logF, decodedUrl)
     found = True
    f.write(line + "\n")
  if not found:
   with open(CCrhIe.VVtjUp(), "a") as f:
    f.write("%s,%s\n" % (logF, decodedUrl))
  self.VVJRI7()
  if self.VVxBfP:
   self.VVxBfP.VV5srZ()
 def VVcUnc(self, rTxt, rUrl):
  resp, decodedUrl, dest, fName, chName, url = self.m3u8_params
  fName = fName.replace("(", "_").replace(")", "_")
  dest = dest.replace("(", "_").replace(")", "_")
  m3u8File = os.path.join(CFG.MovieDownloadPath.getValue(), "%s.m3u8" % fName)
  with open(m3u8File, "w") as f:
   lines = rTxt.splitlines()
   for line in lines:
    line = line.strip()
    if line.startswith(("#EXTM", "#EXT-")) and not line.startswith("#EXT-X-ENDLIST"):
     f.write(line + "\n")
  lst = iFindall(r"(#EXTINF:.+)\n(.+)", rTxt, IGNORECASE)
  if lst:
   with open(m3u8File, "a") as f:
    for extInf, fPath in lst:
     extInf = str(extInf)
     fPath = str(fPath)
     fPath = CC9X9s.VVr5Ek(rUrl, fPath)
     f.write(extInf + "\n")
     f.write(fPath + "\n")
    f.write("#EXT-X-ENDLIST\n")
  else:
   self.VVl8O9("Incorrect m3u8 file from server !")
   return
  logF = "%s.log" % m3u8File
  self.VVco96(logF, decodedUrl)
  cmd  = "ffmpeg -y -hide_banner -protocol_whitelist file,http,https,tcp,tls,crypto -i '%s' -c copy '%s' > %s 2>&1" % (m3u8File, dest, logF)
  cmd += " && %s" % FFIV1X("rm -f '%s' '%s'" % (m3u8File, logF))
  threadName = "%s{%s,,%s}%s" % (CCrhIe.VV1woa, dest, logF, decodedUrl)
  myThread = iThread(name=threadName, target=BF(os.system, cmd))
  myThread.start()
 @staticmethod
 def VVMUAC(dnldLog):
  if fileExists(dnldLog):
   dur = CCrhIe.VVmyVJ(dnldLog)
   if dur > -1:
    tim = CCrhIe.VVv6YG(dnldLog)
    if tim > -1:
     return float(tim) / float(dur) * 100
  elif fileExists(dnldLog[:-9]):
   return 100
  return -1
 @staticmethod
 def VVmyVJ(dnldLog):
  lines = FFnAC3("head -n 15 %s" % dnldLog)
  for line in lines:
   span = iSearch(r"Duration:\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 @staticmethod
 def VVv6YG(dnldLog):
  lines = FFnAC3("tail -n 15 %s" % dnldLog)
  for line in reversed(lines):
   span = iSearch(r"time=\s*(\d+):(\d+):(\d+.\d+)\s*", line, IGNORECASE)
   if span:
    return int(span.group(1)) * 3600 + int(span.group(2)) * 60 + float(span.group(3))
  return -1
 def VV7qK2(self, url, fName):
  path = CFG.MovieDownloadPath.getValue()
  if FFe0eK(url):
   span = iSearch(r"(.+)_(Season_[0-9]*|S[0-9]*E[0-9]*|E[0-9]*S[0-9]*)_.+", fName, IGNORECASE)
   if span:
    path1 = path + span.group(1)
    FFuB0V("mkdir '%s'" % path1)
    if pathExists(path1):
     return path1 + "/" + fName
  return path + fName
 def VVCJV7(self, threadName, url, decodedUrl, path, resp, isAppend=False):
  totFileSize = int(self.VVxBfP.VVc6YJ()[7])
  threadName = threadName.replace(",Sz,", ",%s," % totFileSize)
  myThread = iThread(name=threadName, target=BF(self.VV88k2, url, decodedUrl, path, resp, totFileSize, isAppend))
  myThread.start()
 def VV88k2(self, url, decodedUrl, path, resp, totFileSize, isAppend):
  totBytes = 0
  try:
   with open(path, "ab" if isAppend else "wb") as f:
    for chunk in resp.iter_content(chunk_size=8192):
     if fileExists(path):
      if chunk:
       try:
        f.write(chunk)
       except:
        return
      if self.VVPSlX == path:
       break
     else:
      break
  except:
   return
  if CCrhIe.VVPSlX:
   CCrhIe.VVPSlX = ""
  elif CFG.downloadAutoResume.getValue():
   curSize = FFqLWj(path)
   if curSize > -1 and not curSize == totFileSize:
    params = self.VVIM0Y(decodedUrl, checkExist=False, resumeByte=curSize)
    if len(params) > 1:
     url, fSize, path, resp, resumable = params
     if resumable:
      self.VV88k2(url, decodedUrl, path, resp, totFileSize, True)
 def VVOaaH(self, VVxBfP, title, txt, colList):
  m3u8Log = colList[12].strip()
  decodedUrl = colList[9].strip()
  if       self.VVd7lx() : FF5uKN(self.VVxBfP, self.VVhhBz(self.VVLYwy), 500)
  elif not self.VVYkNc() : FF5uKN(self.VVxBfP, self.VVhhBz(self.VVxnPU), 500)
  elif m3u8Log      : FFNKVM(self.SELF, self.VV7Jgq, "This may stop other non-resumable files !\n\nStop anyway ?", title="Stopping non-resumable download")
  else:
   if decodedUrl in self.VVyZ0J():
    CCrhIe.VVPSlX = colList[6]
    FF5uKN(self.VVxBfP, "Stopping ...", 1000)
   else:
    FF5uKN(self.VVxBfP, "Stopped", 500)
 def VV7Jgq(self, withMsg=True):
  if withMsg:
   FF5uKN(self.VVxBfP, "Stopping ...", 1000)
  FFuB0V("killall -INT ffmpeg")
 def VVa6UO(self, *args):
  if   self.VVd7lx() : FF5uKN(self.VVxBfP, self.VVhhBz(self.VVLYwy) , 500)
  elif self.VVYkNc() : FF5uKN(self.VVxBfP, self.VVhhBz(self.VV2Hjl), 500)
  else:
   resume = False
   m3u8Log = self.VVxBfP.VVc6YJ()[12]
   if m3u8Log:
    if fileExists(m3u8Log) : FFNKVM(self.SELF, BF(self.VV9yhc, m3u8Log), "Cannot resume m3u8 type !\n\nDelete file and restart download ?", title="Resume")
    else     : resume = True
   elif self.VVtpYg():
    resume = True
   if resume: FFJsIX(self.VVxBfP, BF(self.VVkr3c), title="Checking Server ...")
   else  : FF5uKN(self.VVxBfP, "Cannot resume !", 500)
 def VV9yhc(self, m3u8Log):
  FFuB0V("rm -f '%s' '%s' '%s'" % (m3u8Log, m3u8Log[:-4], m3u8Log[:-9]))
  FFJsIX(self.VVxBfP, BF(self.VVkr3c), title="Checking Server ...")
 def VVkr3c(self):
  colList  = self.VVxBfP.VVc6YJ()
  path  = colList[6]
  size  = colList[7]
  decodedUrl = colList[9]
  if "j.php" in decodedUrl:
   url = CCsdD3.VVF0ln(decodedUrl)
   if url:
    decodedUrl = self.VVZrWY(decodedUrl, url)
   else:
    self.VVl8O9("Could not get download link !\n\nTry again later.")
    return
  curSize = FFqLWj(path)
  params = self.VVIM0Y(decodedUrl, checkExist=False, resumeByte=curSize)
  if len(params) == 1:
   self.VVl8O9(params[0])
   return
  elif len(params) == 2:
   self.VVRAoq(params[0], decodedUrl)
   return
  url, fSize, path, resp, resumable = params
  if size == "-1":
   decodedUrl = self.VVZrWY(decodedUrl, url, fSize)
  threadName = "%s{%s,Sz,}%s" % (CCrhIe.VV1woa, path, decodedUrl)
  if resumable: self.VVCJV7(threadName, url, decodedUrl, path, resp, isAppend=True)
  else  : self.VVl8O9("Cannot resume from server !")
 def VV4Ojj(self, decodedUrl):
  fileExt = CC9X9s.VVwzsj(decodedUrl) or ".mp4"
  fixName = True
  url = fName = chName = ""
  tUrl = iSub(r"[&?]mode=.+end=", r"", decodedUrl, flags=IGNORECASE)
  span = iSearch(r"(https?:\/\/.+\/(?:movie|series).+\/.+\/)(.+)(:.+)", tUrl, IGNORECASE)
  if span:
   url  = span.group(1)
   fName = span.group(2)
   chName = span.group(3)
  elif "j.php" in tUrl:
   span = iSearch(r"(.+j.php)(:.+)", tUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = "tmp"
    chName = span.group(2)
  elif "/play/" in decodedUrl:
   span = iSearch(r"(.+)&mode.+&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url = span.group(1)
    chName = span.group(2)
   span = iSearch(r".+movie.php?.+stream=(.+\..{3,4})&.+", decodedUrl, IGNORECASE)
   if span     : fName = span.group(1)
   elif fileExt == ".php" : fName = ".mkv" if ".mkv" in decodedUrl else ".mp4"
   else     : fName = fileExt
  elif "get_download_link" in decodedUrl:
   span = iSearch(r"(.+)&mode.+chCm=(.+)&end=(:.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = os.path.basename(span.group(2))
    chName = span.group(3).replace(":", "_").strip("_")
    fixName = False
  else:
   ok = False
   span = iSearch(r"(.+\/(.+.mp4).+m3u8).+:(.+)", decodedUrl, IGNORECASE)
   if span:
    url  = span.group(1)
    fName = span.group(2)
    chName = span.group(3)
    fixName = False
    ok  = True
   if not ok:
    span = iSearch(r"(.+\/.+m3u8).*:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
     ok  = True
   if not ok and FFEjXT(decodedUrl):
    span = iSearch(r"(.+)\?\:(.+)", decodedUrl, IGNORECASE)
    if span:
     url  = span.group(1)
     chName = span.group(2)
     fName = chName + fileExt
     fixName = False
    else:
     span = iSearch(r"(.+):(.+)", decodedUrl, IGNORECASE)
     if span:
      url  = span.group(1)
      chName = span.group(2)
      fName = chName + fileExt
      fixName = False
  if url and fName and chName:
   if fixName:
    mix  = fName + chName
    parts = mix.split(":", 1)
    fName = parts[0]
    chName = parts[1]
    fName = iSub(r"[?]play_token.+", r"", fName, flags=IGNORECASE)
    url += fName
   chName1 = chName.replace(" ", "_")
   chName1 = "".join(x for x in chName1 if x.isalnum() or x in "_-.")
   fName = chName1 + "_" + fName.lstrip("_")
   fName = fName.replace("_-_", "_")
   while "__" in fName:
    fName = fName.replace("__", "_")
   fName = fName.strip("_.")
   return fName, chName, url
  else:
   return "", "", ""
 def VVl8O9(self, txt):
  FFw5OO(self.SELF, txt, title=self.Title)
 def VVyZ0J(self):
  thrListUrls = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{.+})*(.+)" % CCrhIe.VV1woa, thr.name, IGNORECASE)
   if span:
    thrListUrls.append(span.group(1))
  return thrListUrls
 def VVYkNc(self):
  decodedUrl = self.VVxBfP.VVc6YJ()[9]
  return decodedUrl in self.VVyZ0J()
 def VVd7lx(self):
  colList = self.VVxBfP.VVc6YJ()
  path = colList[6]
  size = colList[7]
  m3u8Log = colList[12]
  if m3u8Log:
   return fileExists(m3u8Log[:-9]) and not fileExists(m3u8Log)
  else:
   if size == "-1" : return False
   else   : return str(FFqLWj(path)) == size
 def VVtpYg(self):
  colList = self.VVxBfP.VVc6YJ()
  path = colList[6]
  size = int(colList[7])
  curSize = FFqLWj(path)
  if curSize > -1:
   size -= curSize
  err = CCrhIe.VVhg69(size)
  if err:
   FFw5OO(self.SELF, err, title=self.Title)
   return False
  return True
 def VVrY0U(self, list):
  with open(CCrhIe.VVtjUp(), "w") as f:
   for line in list:
    f.write(line + "\n")
 def VVZrWY(self, decodedUrl, newUrl, newSize=-1):
  found = False
  lines = CCrhIe.VVLbph()
  url = decodedUrl
  with open(CCrhIe.VVtjUp(), "w") as f:
   for line in lines:
    if CCrhIe.VVUXpP(decodedUrl, line):
     parts = line.split(",", 1)
     oldUrl = parts[1].strip()
     if newSize and not newSize == -1: fSize = str(newSize)
     else       : fSize = parts[0]
     ndx = url.find("j.php")
     if ndx > -1:
      url = newUrl + url[ndx + 5:]
     line = "%s,%s" % (fSize, url)
     found = True
    f.write(line + "\n")
  if found:
   self.VVJRI7()
  return url
 @staticmethod
 def VVLbph():
  list = []
  if fileExists(CCrhIe.VVtjUp()):
   for line in FFZQjt(CCrhIe.VVtjUp()):
    line = line.strip()
    if line:
     list.append(line)
  return list
 @staticmethod
 def VVUXpP(decodedUrl, line):
  span = iSearch(r"(mode=.+end=.+)", decodedUrl, IGNORECASE)
  if span: decodedUrl = span.group(1)
  span = iSearch(r"(mode=.+end=.+)", line, IGNORECASE)
  if span: line = span.group(1)
  return decodedUrl in line
 @staticmethod
 def VVhg69(size):
  dest = CFG.MovieDownloadPath.getValue()
  if pathExists(dest):
   free = CCCXvS.VVOsjP(dest)
   if free > size : return ""
   else   : return "No enough space on:\n%s\n\nFile Size = %s\nFree Space = %s" % (dest, CCCXvS.VVutW7(size), CCCXvS.VVutW7(free))
  else:
   return "Path not found !\n\n%s" % dest
 @staticmethod
 def VVXe12(SELF):
  tot = CCrhIe.VVGiT5()
  if tot:
   FFw5OO(SELF, "Cannot change while downloading.", title="")
   return True
  else:
   return False
 @staticmethod
 def VVGiT5():
  c = 0
  for thr in iEnumerate():
   if thr.name.startswith(CCrhIe.VV1woa):
    c += 1
  return c
 @staticmethod
 def VVjUzR():
  lst = []
  for thr in iEnumerate():
   span = iSearch(r"%s(?:{(.+),(.*),(.*)}).+" % CCrhIe.VV1woa, thr.name, IGNORECASE)
   if span:
    lst.append((span.group(1), span.group(2), span.group(3)))
  return lst
 @staticmethod
 def VVyUPR():
  return len(CCrhIe.VVLbph()) == 0
 @staticmethod
 def VVJNRX():
  list = []
  for p in harddiskmanager.getMountedPartitions():
   list.append(p.mountpoint)
  return list
 @staticmethod
 def VVdTgj():
  mPoints = CCrhIe.VVJNRX()
  list = []
  for mPath in mPoints:
   if not mPath == "/":
    path = mPath + "/movie/"
    if pathExists(path) : return path
    else    : list.append(mPath)
  drives = ("/hdd", "/usb", "/sd")
  for mPath in list:
   if any(x in mPath for x in drives):
    path = mPath + "/movie/"
    FFuB0V("mkdir '%s'" % path)
    if pathExists(path):
     return path
  return "/tmp/"
 @staticmethod
 def VVtjUp():
  f = "ajpanel_downloads"
  if pathExists("/home/root/"): return "/home/root/%s" % f
  else      : return "/home/%s" % f
 @staticmethod
 def VVFNli(SELF, waitMsgObj=None):
  FFJsIX(waitMsgObj or SELF, BF(CCrhIe.VVTjG4, SELF, CCrhIe.VVuKyr))
 @staticmethod
 def VVXfcN(SELF):
  CCrhIe.VVTjG4(SELF, CCrhIe.VVjJlp, startDnld=True)
 @staticmethod
 def VVoAzB(SELF, url):
  CCrhIe.VVTjG4(SELF, CCrhIe.VVjJlp, startDnld=True, decodedUrl=url)
 @staticmethod
 def VVgDTr(SELF):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(SELF)
  added, skipped = CCrhIe.VVgpip([decodedUrl])
  FF5uKN(SELF, "Added", 1000)
 @staticmethod
 def VVgpip(list):
  added = skipped = 0
  for line in CCrhIe.VVLbph():
   for ndx, url in enumerate(list):
    if url and CCrhIe.VVUXpP(url, line):
     skipped += 1
     list[ndx] = ""
     break
  with open(CCrhIe.VVtjUp(), "a") as f:
   for url in list:
    if url:
     added += 1
     f.write("-1,%s\n" % url)
  return added, skipped
 @staticmethod
 def VVTjG4(SELF, mode, startDnld=False, decodedUrl=""):
  title = "Download Manager"
  if not CC2hCu.VViy1e(SELF):
   return
  if mode == CCrhIe.VVuKyr and CCrhIe.VVyUPR():
   FFw5OO(SELF, "Download list is empty !", title=title)
  else:
   inst = CCrhIe(SELF, mode, title, startDnld=startDnld, decodedUrl=decodedUrl)
 @staticmethod
 def VV1r2k(res):
  if res.status_code == 206:
   return True
  else:
   hResume = res.headers.get("Accept-Ranges" , "")
   if hResume and not hResume == "none":
    return True
  return False
class CCb9j4(Screen, CCdmJK):
 VVavYK = None
 def __init__(self, session, enableZapping=True, iptvTableParams=None, enableDownloadMenu=True):
  self.skin, self.skinParam = FFRBRO(VVmZLR, 1600, 190, 28, 10, 6, "#1100202a", "#1100202a", 24, topRightBtns=2)
  CCdmJK.__init__(self)
  self.session    = session
  self.enableZapping   = enableZapping
  self.iptvTableParams  = iptvTableParams
  self.enableDownloadMenu  = enableDownloadMenu
  self.Title     = ""
  self.cutListBtn    = "Cut-List"
  self.timer     = eTimer()
  self.barWidth    = 0
  self.barHeight    = 0
  self.isManualSeek   = False
  self.manualSeekSec   = 0
  self.manualSeekPts   = 0
  self.jumpMinutes   = CFG.playerJumpMin.getValue()
  self.noteTime    = 0
  self.satInfo_TP    = ""
  self.lastPlayPos   = 0
  self.lastPlayPosTicker  = 0
  self.lastSubtitle   = None
  self.restoreLastPlayPos  = False
  self.autoReplay    = False
  FFmmH7(self, "")
  self["myPlayBarF"] = Label()
  self["myPlayBarBG"] = Label()
  self["myPlayBar"] = Label()
  self["myPlayMov"] = Label()
  self["myPlayVal"] = Label()
  self["myPlayPos"] = Label()
  self["myPlaySkp"] = Label()
  self["myPlayMsg"] = Label()
  self["myPlayRem"] = Label()
  self["myPlayDur"] = Label()
  self["myPlaySep"] = Label()
  self["myPlayGrn"] = Label("Refresh")
  self["myPlayJmp"] = Label(self.VVTyJX())
  self["myPlayDat"] = Label("")
  self["myPlayTim"] = Label("")
  self["myPlayMrk"] = Label("<< || >>")
  self["myPlayRes"] = Label("")
  self["myPlayFps"] = Label()
  self["myPlayAsp"] = Label()
  self["myPlayBlu"] = Label(self.cutListBtn)
  self["myPlayTyp"] = Label()
  self["myPlayPic"] = Pixmap()
  self["myPlayDnld"] = Pixmap()
  self["myPlayRpt"] = Pixmap()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVxCTS       ,
   "info"  : self.VVpIF1      ,
   "epg"  : self.VVpIF1      ,
   "menu"  : self.VV9DoB     ,
   "cancel" : self.cancel       ,
   "red"  : self.VVfpeQ   ,
   "green"  : self.VVZwqW  ,
   "blue"  : self.VVr0ak      ,
   "yellow" : self.VVpe6c ,
   "left"  : BF(self.VVuzwV, -1)    ,
   "right"  : BF(self.VVuzwV,  1)    ,
   "play"  : self.VVQYp2      ,
   "pause"  : self.VVQYp2      ,
   "playPause" : self.VVQYp2      ,
   "stop"  : self.VVQYp2      ,
   "rewind" : self.VVcfe0      ,
   "forward" : self.VVLBVG      ,
   "rewindDm" : self.VVcfe0      ,
   "forwardDm" : self.VVLBVG      ,
   "last"  : self.VVGSdy      ,
   "next"  : self.VV1yoO      ,
   "pageUp" : BF(self.VVasrG, True)  ,
   "pageDown" : BF(self.VVasrG, False)  ,
   "chanUp" : BF(self.VVasrG, True)  ,
   "chanDown" : BF(self.VVasrG, False)  ,
   "up"  : BF(self.VVasrG, True)  ,
   "down"  : BF(self.VVasrG, False)  ,
   "audio"  : BF(self.VVrb5m, True)  ,
   "subtitle" : BF(self.VVrb5m, False)  ,
   "text"  : self.VVbO51  ,
   "0"   : BF(self.VVpJTA , 10)   ,
   "1"   : BF(self.VVpJTA , 1)   ,
   "2"   : BF(self.VVpJTA , 2)   ,
   "3"   : BF(self.VVpJTA , 3)   ,
   "4"   : BF(self.VVpJTA , 4)   ,
   "5"   : BF(self.VVpJTA , 5)   ,
   "6"   : BF(self.VVpJTA , 6)   ,
   "7"   : BF(self.VVpJTA , 7)   ,
   "8"   : BF(self.VVpJTA , 8)   ,
   "9"   : BF(self.VVpJTA , 9)
  }, -1)
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFj9eW(self)
  if not CCb9j4.VVavYK:
   CCb9j4.VVavYK = self
  left = self["keyInfo"].getPosition()[0]
  top  = self["myPlayDnld"].getPosition()[1]
  left -= self.skinParam["titleH"]
  self["myPlayDnld"].instance.move(ePoint(int(left), int(top)))
  self["myPlayDnld"].hide()
  FFDhpr(self["myPlayDnld"], "dnld")
  left -= self.skinParam["titleH"]
  self["myPlayRpt"].instance.move(ePoint(int(left), int(top)))
  self["myPlayRpt"].hide()
  FFDhpr(self["myPlayRpt"], "rpt")
  self.VVGvdh()
  self.instance.move(ePoint(40, 40))
  self.VVUfgb(CFG.playerPos.getValue())
  self["myPlayMov"].hide()
  self["myPlaySkp"].hide()
  size = self["myPlayBar"].instance.size()
  self.barWidth = int(size.width())
  self.barHeight = int(size.height())
  self["myPlayBar"].instance.resize(eSize(*(1, self.barHeight)))
  try:
   self.timer_conn = self.timer.timeout.connect(self.VVQKYE)
  except:
   self.timer.callback.append(self.VVQKYE)
  self.timer.start(250, False)
  self.VVQKYE("Checking ...")
  if not bool(self.iptvTableParams):
   self.VVHll7()
 def VVZwqW(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  self.lastSubtitle = CC4K9R.VVcS6O()
  if "chCode" in iptvRef:
   if CC2hCu.VViy1e(self):
    self.VVHll7(True)
  else:
   self.VVQKYE("Refreshing")
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv:
    self.session.nav.stopService()
    self.session.nav.playService(serv)
   self.restoreLastPlayPos = True
 def VVGvdh(self):
  self.satInfo_TP = ""
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVv3rj()
  chName = FFxmTk(chName)
  if refCode : self.Title = chName.replace("\n", " > ")
  else  : self.Title = VVLbyB + "No Service !"
  self["myTitle"].setText("  " + self.Title + "  ")
  FFWN9Z(self["myTitle"], tColor)
  FFWN9Z(self["myBody"], tColor)
  for item in ("Pos", "Skp", "Msg", "Rem", "Dur", "Jmp", "Dat", "Tim", "Mrk", "Res", "Fps", "Asp", "Pic", "Typ"):
   FFWN9Z(self["myPlay%s" % item], tColor)
  picFile = CCjQ0P.VVcMJR(refCode)
  if not fileExists(picFile):
   fPath, fDir, fName, picFile = CCjQ0P.VVo8yW(self)
  cl = CC5J0P.VVDKxb(self["myPlayPic"], picFile, tColor)
  if cl:
   self["myPlayPic"].show()
   self["myPlayTyp"].hide()
  else:
   self["myPlayPic"].hide()
   self["myPlayTyp"].show()
   self["myPlayTyp"].setText(typeTxt)
 def VVQKYE(self, stateTxt="", highlight=False):
  if not self.shown:
   return
  self["myPlayDat"].setText(datetime.now().strftime("%Y-%m-%d"))
  self["myPlayTim"].setText(datetime.now().strftime("%H:%M:%S"))
  tot = CCrhIe.VVGiT5()
  if tot : self["myPlayDnld"].show()
  else : self["myPlayDnld"].hide()
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVv3rj()
  if evName:
   evName = "    %s    " % FFGB9z(evName, VVGb6D)
  self["myTitle"].setText("  %s%s  " % (self.Title, evName))
  if seekable and self.VVMprH():
   FFHNWi(self["myPlayBlu"], "#00FFFFFF")
   FFWN9Z(self["myPlayBlu"], "#0a18188b")
   self["myPlayBlu"].setText(self.cutListBtn)
   self["myPlayBlu"].show()
  elif prov:
   FFHNWi(self["myPlayBlu"], "#00FFFF88")
   FFWN9Z(self["myPlayBlu"], tColor)
   self["myPlayBlu"].setText(prov)
   self["myPlayBlu"].show()
  else:
   self["myPlayBlu"].hide()
  if not self.isManualSeek:
   player = CC9X9s.VVE8iD(refCode)
   if player:
    self["myPlaySkp"].show()
    self["myPlaySkp"].setText(VV7jS2 + player)
   else:
    self["myPlaySkp"].hide()
  self["myPlayRes"].setText(res)
  self["myPlayFps"].setText(fr)
  self["myPlayAsp"].setText(ratio)
  self["myPlayPos"].setText(posTxt if posTxt else "")
  self["myPlayVal"].setText(percTxt if percTxt else "")
  self["myPlayRem"].setText("-%s" % remTxt if remTxt else "")
  self["myPlayDur"].setText(durTxt if durTxt else "")
  if durTxt:
   FFWN9Z(self["myPlayBarBG"], "#11000000")
   self["myPlayBarBG"].show()
   self["myPlayBarF"].show()
   self["myPlayBar"].show()
   width = 0
   percent = FFgevD(percVal, 0, 100)
   width = int(FF6NMP(percent, 0, 100, 0, self.barWidth))
   self["myPlayBar"].instance.resize(eSize(*(width, self.barHeight)))
  else:
   self["myPlayBarBG"].hide()
   self["myPlayBarF"].hide()
   self["myPlayBar"].hide()
   self["myPlayVal"].setText(">>>>")
   FFWN9Z(self["myPlayBarBG"], tColor)
  if stateTxt:
   if highlight: FFHNWi(self["myPlayMsg"], "#0000ffff")
   else  : FFHNWi(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText(stateTxt)
   self.noteTime = iTime()
  if self.noteTime and iTime() - self.noteTime < 1:
   return
  else:
   self.noteTime = 0
   FFHNWi(self["myPlayMsg"], "#00ffaa00")
   self["myPlayMsg"].setText("No system info")
  if isDvb:
   FFHNWi(self["myPlayMsg"], "#00aaaaaa")
   self["myPlayMsg"].setText(self.satInfo_TP)
  if not seekable:
   return
  stateTxt = ""
  if not posTxt and not durTxt:
   stateTxt = "Not playing yet ..."
  state = self.VV6eNY()
  if state:
   if state == "Playing" and not posTxt: stateTxt = "Waiting for state change"
   elif percVal == 100     : stateTxt = "End"
   else        : stateTxt = state
   if state == "Playing" and posTxt:
    if self.restoreLastPlayPos:
     if self.lastPlayPos > 0:
      move = end = False
      s = "." * self.lastPlayPosTicker
      stateTxt = ("%s Restoring Posistion %s" % (s, s)).strip()
      self.lastPlayPosTicker += 1
      diff = abs(posVal - self.lastPlayPos)
      if   diff < 10     : end = True
      elif self.lastPlayPosTicker == 1: move = True
      elif self.lastPlayPosTicker >= 10:
       if diff > 10:
        move = True
       end = True
      if move:
       self.VVpnoK(self.lastPlayPos * 90000.0)
      if end:
       self.lastPlayPosTicker = 0
       self.restoreLastPlayPos = False
       CC4K9R.VVUEXq(self.lastSubtitle)
     else:
      self.restoreLastPlayPos = False
    else:
     self.lastPlayPos = posVal
   elif stateTxt == "End" and self.autoReplay:
    self.VVGSdy()
  state = self.VVWEh8()
  if state:
   stateTxt = state
  if stateTxt == "Playing": FFHNWi(self["myPlayMsg"], "#0000ff00")
  else     : FFHNWi(self["myPlayMsg"], "#00FF8F5F")
  self["myPlayMsg"].setText(stateTxt)
 def VVv3rj(self, isFromSession=False, addInfoObj=False):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state, info = FFGh4f(self, addInfoObj=True)
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCb9j4.VVdw0i(self)
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCjQ0P.VV4GBq(serv)
  if   isDvb        : tColor = "#1100102a"
  elif isLocal       : tColor = "#0a401100"
  elif "chCode" in decodedUrl:
   if "get_download_link" in decodedUrl: tColor = "#1120101a"
   else        : tColor = "#1120002a"
  elif "/timeshift/" in decodedUrl  : tColor = "#11223322"
  elif isFtp        : tColor = "#11222222"
  else         : tColor = "#11001c1c"
  chPath = serv and serv.getPath() or ""
  satTxt = ""
  if isDvb and not self.satInfo_TP:
   tp = CCyH2c()
   tpTxt, satTxt = tp.VV1b6Z(refCode)
   self.satInfo_TP = tpTxt + "  " + FFGB9z(satTxt, VVWOjU)
  evName = evNameNext = ""
  evLst = CCvWMS.VVLpmH(refCode)
  if evLst:
   evName, evShort, evDesc, genre, PR, evTime, evTimeTxt, evDur, evDurTxt, evEnd, evEndTxt, evPos, evPosTxt, evRem, evRemTxt, evCom, evComTxt = evLst[0]
   if not durVal:
    if len(evLst) > 1:
     evNameNext = evLst[1][0]
    if evPos >= evDur:
     percVal = 100
     percTxt = "%d %%" % percVal
    else:
     percVal = float(evPos) * 100.0 / float(evDur)
     percTxt = "%.2f %%" % percVal
    posVal, remVal, percTxt, durTxt, posTxt, remTxt = evPos, evRem, percTxt, evDurTxt, evPosTxt, evRemTxt
  fr = res = ""
  if info:
   w = FFSmtF(info, iServiceInformation.sVideoWidth) or -1
   h = FFSmtF(info, iServiceInformation.sVideoHeight) or -1
   if w != -1 and h != -1 and not w == "0" and not h == "0":
    res = "%s x %s" % (w, h)
   rate = FFSmtF(info, iServiceInformation.sFrameRate)
   if rate.isdigit() and not rate == "0":
    fr = "%d fps" % (int(rate) / 1000)
  ratio = CCjQ0P.VVm3uK(info)
  return refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 @staticmethod
 def VVdw0i(SELF):
  percVal = durVal = posVal = remVal = seekable = 0
  percTxt = durTxt = posTxt = remTxt = ""
  isEnded = False
  try:
   service = SELF.session.nav.getCurrentService()
   if service:
    pSeek = service.seek()
    if pSeek:
     seekable = pSeek.isCurrentlySeekable()
     durLst  = pSeek.getLength()
     posLst  = pSeek.getPlayPosition()
     if durLst[0] == 0:
      durVal = durLst[1] / 90000.0
      if durVal:
       durTxt = FF3Odj(durVal)
     if posLst[0] == 0:
      posVal = posLst[1] / 90000.0
      posTxt = FF3Odj(posVal)
     if durVal > 0 and posVal > 0:
      remVal = durVal - posVal + 1
      remTxt = FF3Odj(remVal)
     if durVal > 0:
      if round(posVal) >= int(durVal):
       percVal = 100
       percTxt = "%d %%" % percVal
       posVal = durVal
       posTxt = durTxt
       remTxt = ""
      else:
       percVal = float(posVal) * 100.0 / float(durVal)
       percTxt = "%.2f %%" % percVal
  except:
   pass
  return seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt
 def VV9DoB(self):
  refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVv3rj()
  FF7cGOSeries = FFEjXT(decodedUrl)
  VVZJ87 = []
  if not "VVofuN" in globals() and not "VVbfpk" in globals():
   VVZJ87.append((VVWOjU + "IPTV Menu", "iptv"))
   VVZJ87.append(VVoqHH)
  if isIptv and not "&end=" in decodedUrl and not FF7cGOSeries:
   uType, uHost, uUser, uPass, uId, uChName = CC9X9s.VVXxn6(decodedUrl)
   if all([uHost, uUser, uPass, uId]):
    VVZJ87.append((VVWOjU + "Catchup Programs", "catchup" ))
    VVZJ87.append(VVoqHH)
  if refCode:
   c = VVLbyB
   VVZJ87.append((c + "Stop Current Service"  , "stop"  ))
   VVZJ87.append((c + "Restart Current Service" , "restart"  ))
   VVZJ87.append(FFnqNr("Replay with ..." , "replayWith", not isDvb, c))
   VVZJ87.append(VVoqHH)
  if FF7cGOSeries:
   VVZJ87.append((VVWOjU + "File Size (on server)", "fileSize" ))
   VVZJ87.append(VVoqHH)
  if self.enableDownloadMenu:
   c = VVWOjU
   addSep = False
   if isIptv and FF7cGOSeries:
    VVZJ87.append((c + "Start Download"  , "dload_cur" ))
    VVZJ87.append((c + "Add to Download List" , "addToDload" ))
    addSep = True
   if not CCrhIe.VVyUPR():
    VVZJ87.append((VVWOjU + "Download Manager", "dload_stat" ))
    addSep = True
   if addSep:
    VVZJ87.append(VVoqHH)
  fPath, fDir, fName = CCCXvS.VV6Qx4(self)
  if fPath:
   c = VVkIQ9
   if not "VVB4XJ" in globals():
    VVZJ87.append((c + "Open path in File Manager", "VVp4PA"))
   VVZJ87.append((c + "Add to Bouquet"             , "VVsoDF" ))
   VVZJ87.append((c + "%s Auto-Repeat" % ("Disable" if self.autoReplay else "Enable") , "VV5ewC"  ))
   VVZJ87.append(VVoqHH)
  elif isFtp:
   VVZJ87.append((VVUVAI + "Add FTP Media to Bouquet"     , "VVFwEG"))
  if isDvb:
   VVZJ87.append((VVWOjU + "Signal Monitor", "sigMon"))
  if posTxt and durTxt:
   VVZJ87.append((VVUVAI + "Start Subtitle", "VVLUJQ"))
   VVZJ87.append(VVoqHH)
  if CFG.playerPos.getValue() : VVZJ87.append(("Move Bar to Bottom" , "botm"))
  else      : VVZJ87.append(("Move Bar to Top" , "top" ))
  VVZJ87.append(("Help", "help"))
  FFYySC(self, self.VVv6mi, VVZJ87=VVZJ87, width=600, title="Options")
 def VVv6mi(self, item=None):
  if item:
   if item == "iptv"     : self.close("close_iptvMenu")
   elif item == "catchup"    : self.VVpe6c()
   elif item == "stop"     : self.VVRsNw(0)
   elif item == "restart"    : self.VVRsNw(1)
   elif item == "replayWith"   : self.VV8JVh()
   elif item == "fileSize"    : FFJsIX(self, BF(CCjQ0P.VVBOlG, self), title="Checking Server")
   elif item == "dload_cur"   : CCrhIe.VVXfcN(self)
   elif item == "addToDload"   : CCrhIe.VVgDTr(self)
   elif item == "dload_stat"   : CCrhIe.VVFNli(self)
   elif item == "VVp4PA" : self.close("close_openInFileMan")
   elif item == "VVsoDF" : self.VVsoDF()
   elif item == "VVFwEG" : self.VVFwEG()
   elif item == "VVLUJQ"  : self.VVYyUy()
   elif item == "VV5ewC"  : self.VV5ewC()
   elif item == "botm"     : self.VVUfgb(0)
   elif item == "top"     : self.VVUfgb(1)
   elif item == "sigMon"    : self.VVfpeQ()
   elif item == "help"     : FFqsYG(self, "_help_player", "Player Bar (Keys)")
 def onExit(self):
  self.timer.stop()
  CCb9j4.VVavYK = None
 def VVRsNw(self, typ):
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv:
   if typ == 0:
    self.session.nav.stopService()
    self.show()
    self.VVGvdh()
   elif typ == 1:
    self.VVQKYE("Restarting Service ...")
    FFFANg(BF(self.VVYhed, serv))
 def VVYhed(self, serv):
  self.session.nav.stopService()
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  if "&end=" in decodedUrl: BF(self.VVHll7, True)
  else     : self.session.nav.playService(serv)
 def VV8JVh(self):
  FFYySC(self, self.VV077A, VVZJ87=CC9X9s.VVrdGZ(), width=650, title="Select Player", VVDlGi="#11220000", VVaSSM="#11220000")
 def VV077A(self, rType=None):
  if rType:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   if serv : FFeWbP(self, eServiceReference(rType + ":" + serv.toString().split(":", 1)[1]))
   else : self.VVQKYE("No active service !")
 def VVsoDF(self):
  fPath, fDir, fName = CCCXvS.VV6Qx4(self)
  if fPath: picker = CCSrvY(self, self, "Add Current Movie to a Bouquet", BF(self.VVnPKx, [fPath]))
  else : FF5uKN(self, "Path not found !", 1500)
 def VVnPKx(self, pathLst):
  return CCSrvY.VVlFFp(pathLst)
 def VVFwEG(self):
  picker = CCSrvY(self, self, "Add FTP Media to Bouquet", self.VVInu0)
 def VVInu0(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  return CCSrvY.VVlFFp([origUrl], rType=refCode.split(":", 1)[0])
 def VV5ewC(self):
  ok = False
  if self.autoReplay:
   self.autoReplay = False
   txt = "Auto-Repeat OFF"
   ok = True
  else:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCb9j4.VVdw0i(self)
   if seekable and durVal > 0:
    if durVal >= 60:
     self.autoReplay = True
     txt = "Auto-Repeat ON"
     ok = True
    else: txt = "Too short (min = 1 minute)"
   else: txt = "Cannot Auto-Repeat"
  if self.autoReplay : self["myPlayRpt"].show()
  else    : self["myPlayRpt"].hide()
  self.VVQKYE(txt, highlight=ok)
 def VVUfgb(self, pos):
  scrSize = getDesktop(0).size()
  scrW = scrSize.width()
  scrH = scrSize.height()
  x  = (scrW - self.instance.size().width()) / 2.0
  if pos == 0 : y = (scrH - self.instance.size().height() - 20)
  else  : y = 20
  self.instance.move(ePoint(int(x), int(y)))
  if not pos == CFG.playerPos.getValue():
   FFdEZ4(CFG.playerPos, pos)
 def VVfpeQ(self):
  if self.shown:
   serv = self.session.nav.getCurrentlyPlayingServiceReference()
   isLocal, isIptv, isFtp, isDvb, isDvbS, isDvbC, isDvbT, typeTxt, chPath = CCjQ0P.VV4GBq(serv)
   if isDvb: self.close("close_sig")
   else : self.VVQKYE("No Signal for Current Service")
 def VVYyUy(self):
  self.session.openWithCallback(self.VVHOvt, BF(CC4K9R))
 def VVbO51(self):
  if self.shown:
   refCode, decodedUrl, chName, evName, evNameNext, prov, fr, res, ratio, isDvb, isIptv, isFtp, typeTxt, tColor, seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = self.VVv3rj()
   if posTxt and durTxt: self.VVYyUy()
   else    : self.VVQKYE("No duration Info. !")
 def VVHOvt(self, reason):
  self.show()
  txt = ""
  if   reason == "subtExit" : pass
  elif reason == "subtCancel" : pass
  elif reason == "subtEnd" : txt = "End of subtitle reached"
  elif reason == "subtInval" : txt = "Invalid srt file"
  elif reason == "subtNoSrt" : txt = "Not found"
  elif reason == "subtZapUp" : self.VVasrG(True)
  elif reason == "subtZapDn" : self.VVasrG(False)
  elif reason == "pause"  : self.VVQYp2()
  elif reason == "audio"  : self.VVrb5m(True)
  elif reason == "subtitle" : self.VVrb5m(False)
  elif reason == "rewind"     : self.VVcfe0()
  elif reason == "forward" : self.VVLBVG()
  elif reason == "rewindDm" : self.VVcfe0()
  elif reason == "forwardDm" : self.VVLBVG()
  else      : txt = reason
  if txt:
   FF5uKN(self, txt, 2000)
 def VVxCTS(self):
  if self.isManualSeek:
   self.VVTVPS()
   self.VVpnoK(self.manualSeekPts)
  elif self.shown:
   if CC4K9R.VVoodB(self): self.VVYyUy()
   elif self.shown       : self.hide()
  else:
   self.show()
 def cancel(self):
  if self.isManualSeek: self.VVTVPS()
  else    : self.close()
 def VVpIF1(self):
  FFcpNw(self, fncMode=CCjQ0P.VVy2hO)
 def VVQYp2(self):
  inst = InfoBar.instance
  try:
   inst.playpauseService()
  except:
   pass
  self.VVQKYE("Toggling Play/Pause ...")
 def VVTVPS(self):
  if self.isManualSeek:
   self.isManualSeek = False
   self["myPlayMov"].hide()
   self["myPlaySkp"].hide()
 def VVuzwV(self, direc):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCb9j4.VVdw0i(self)
  if seekable and durVal > 0:
   if not self.isManualSeek:
    self.isManualSeek = True
    self["myPlayMov"].show()
    self["myPlaySkp"].show()
    self.manualSeekSec = posVal + direc * self.VVFfFb()
   else:
    self.manualSeekSec += direc * self.VVFfFb()
    self.manualSeekSec = FFgevD(self.manualSeekSec, 0, durVal)
   minLeft = self["myPlayBar"].getPosition()[0] - 1
   maxLeft = self["myPlayBarBG"].getPosition()[0] + self["myPlayBarBG"].instance.size().width() - self["myPlayMov"].instance.size().width() + 1
   left = int(FF6NMP(self.manualSeekSec, 0, durVal, minLeft, maxLeft))
   self["myPlayMov"].instance.move(ePoint(left, int(self["myPlayMov"].getPosition()[1])))
   self["myPlaySkp"].setText(FF3Odj(self.manualSeekSec))
   self.manualSeekPts = self.manualSeekSec * 90000.0
 def VVpJTA(self, val):
  if not self.jumpMinutes == val:
   self.jumpMinutes = val
   self["myPlayJmp"].setText(self.VVTyJX())
   FFdEZ4(CFG.playerJumpMin, self.jumpMinutes)
  self.VVQKYE("Changed Seek Time to : %d%s" % (val, self.VV4Orp()))
 def VVTyJX(self):
  return "Seek=%d%s" % (self.jumpMinutes, self.VV4Orp())
 def VV4Orp(self) : return "s"   if self.jumpMinutes == 10 else "m"
 def VVLRr4(self): return "sec" if self.jumpMinutes == 10 else "min"
 def VVFfFb(self) : return 10    if self.jumpMinutes == 10 else self.jumpMinutes * 60
 def VV6eNY(self):
  if "VV94uO" in globals():
   global VV94uO
   if VV94uO:
    VV94uO = VV94uO[1:-1]
    if len(VV94uO) == 3: VV94uO = ""
    else     : return VV94uO
  try:
   inst = InfoBar.instance
   st   = inst.seekstate
   if   st == inst.SEEK_STATE_PAUSE: return "PAUSED"
   elif st == inst.SEEK_STATE_EOF : return "END"
   elif st == inst.SEEK_STATE_PLAY : return "Playing"
  except:
   pass
  return ""
 def VVr0ak(self):
  cList = self.VVMprH()
  if cList:
   VVZJ87 = []
   for pts, what in cList:
    txt = FF3Odj(int(pts) / 90000.0)
    if   what == 0 : t = "In"
    elif what == 1 : t = "Out"
    elif what == 2 : t = "Mark"
    elif what == 3 : t = "Last"
    else   : t = ""
    if t: txt += "  ( %s )" % t
    VVZJ87.append((txt, pts))
   FFYySC(self, self.VViWzu, VVZJ87=VVZJ87, title="Cut List")
  else:
   self.VVQKYE("No Cut-List for this channel !")
 def VViWzu(self, item=None):
  if item:
   self.VVpnoK(item)
 def VVMprH(self):
  cList = []
  try:
   cList = InfoBar.instance.cut_list or []
  except:
   pass
  return cList
 def VVLBVG(self) : self.VVNPy2(1)
 def VVcfe0(self) : self.VVNPy2(-1)
 def VVNPy2(self, direc):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCb9j4.VVdw0i(self)
   if durVal > 0:
    maxPts = (durVal - posVal- 10) * 90000.0
    pts = direc * self.VVFfFb() * 90000.0
    pts = min(maxPts, pts)
    inst = InfoBar.instance
    inst.doSeekRelative(int(pts))
    inst.hide()
    if   direc > 0 : txt = "Forawrd"
    else   : txt = "Rewind"
    txt += " (%d %s) ..." % (self.jumpMinutes, self.VVLRr4())
    self.VVQKYE(txt)
  except:
   self.VVQKYE("Cannot jump")
 def VVpnoK(self, pts):
  try:
   InfoBar.instance.doSeek(int(pts))
  except:
   pass
  self.VVQKYE("Changing Time ...")
 def VVGSdy(self):
  self.VVRsNw(1)
  self.VVQKYE("Replaying ...")
  self.VVTVPS()
 def VV1yoO(self):
  try:
   seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCb9j4.VVdw0i(self)
   if durVal > 0:
    pts = int((durVal - 10) * 90000.0)
    InfoBar.instance.doSeek(int(pts))
    self.VVQKYE("Jumping to end ...")
  except:
   pass
 def VVWEh8(self):
  try:
   service = self.session.nav.getCurrentService()
   info = service and service.info()
   if info:
    val = info.getInfo(iServiceInformation.sBuffer)
    if val and val > 0 and not val == 100:
     return "Buffering %d %%" % val
  except:
   pass
  return ""
 def VVasrG(self, isUp):
  if self.enableZapping:
   self.VVQKYE("Zap %s ..." % ("Up" if isUp else "Down"))
   self.VVTVPS()
   if self.iptvTableParams:
    FFFANg(BF(self.VVcwak, isUp))
   else:
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
    if "/timeshift/" in decodedUrl:
     self.VVQKYE("Cannot Zap Catch-up TV")
    else:
     try:
      if isUp : InfoBar.instance.zapDown()
      else : InfoBar.instance.zapUp()
     except:
      pass
     self.VVuLrX()
  else:
   self.VVQKYE("Zap Disabled !")
 def VVuLrX(self):
  self.lastPlayPos = 0
  self.VVGvdh()
  self.VVHll7()
 def VVcwak(self, isUp):
  CC9X9s_inatance, VVxBfP, mode = self.iptvTableParams
  if isUp : VVxBfP.VVT9T9()
  else : VVxBfP.VVA5vi()
  colList = VVxBfP.VVc6YJ()
  if mode == "localIptv":
   chName, chUrl = CC9X9s_inatance.VVGdbS(VVxBfP, colList)
  elif mode == "m3u/m3u8":
   chName, chUrl = CC9X9s_inatance.VVWajK(VVxBfP, colList)
  elif isinstance(mode, int):
   chName, chUrl = CC9X9s_inatance.VV4Npj(mode, VVxBfP, colList)
  elif any(x in mode for x in ("itv", "vod", "series")):
   chName, chUrl = CC9X9s_inatance.VV0Eue(mode, VVxBfP, colList)
  else:
   self.VVQKYE("Cannot Zap")
   return
  FFkwBg(self, chUrl, VVIC8r=False)
  self.VVuLrX()
 def VVHll7(self, forceRefresh=False):
  try:
   if not forceRefresh:
    seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCb9j4.VVdw0i(self)
    if posTxt:
     return
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
   if not self.VVfc6w(refCode, chName, decodedUrl, iptvRef):
    return
   self.VVQKYE("Refreshing Portal")
   FFFANg(self.VVmo4Z)
  except:
   pass
 def VVmo4Z(self):
  self.restoreLastPlayPos = self.VVwvmQ()
 def VVpe6c(self):
  refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
  if not decodedUrl or FFEjXT(decodedUrl):
   self.VVQKYE("Not a Catchup TV")
   return
  qUrl = streamId = ""
  ok_fnc = None
  if not "&end=" in decodedUrl:
   if "/timeshift/" in decodedUrl:
    span = iSearch(r"(.+)\/timeshift\/(.+)\/(.+)\/(.+)\/(.+)\/(.+)[.]+", decodedUrl, IGNORECASE)
    if span:
     uHost, uUser, uPass = span.group(1), span.group(2), span.group(3)
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
     streamId = span.group(6)
     ndx = chName.find(" >> ")
     if ndx > -1:
      chName = chName[:ndx]
   else:
    uType, uHost, uUser, uPass, uId, uChName = CC9X9s.VVXxn6(decodedUrl)
    if all([uHost, uUser, uPass, uId]):
     streamId = uId
     qUrl = "%s/player_api.php?username=%s&password=%s" % (uHost, uUser, uPass)
  if qUrl:
   self.VVQKYE("Reading Program List ...")
   ok_fnc = BF(self.VVkQpK, refCode, chName, streamId, uHost, uUser, uPass)
   FFFANg(BF(CC9X9s.VVAIn3, self, qUrl, chName, streamId, ok_fnc))
  else:
   self.VVQKYE("Cannot process this channel")
 def VVkQpK(self, refCode, chName, streamId, uHost, uUser, uPass, VVxBfP, title, txt, colList):
  pTitle = colList[3]
  sTime = colList[5]
  dur  = colList[7]
  VVxBfP.cancel()
  span = iSearch(r"(\d{4}-\d{2}-\d{2})\s(\d{2}):(\d{2})", sTime, IGNORECASE)
  if span:
   sTime = span.group(1) + ":" + span.group(2) + "-" + span.group(3)
   chUrl = "%s/timeshift/%s/%s/%s/%s/%s.ts" % (uHost, uUser, uPass, dur, sTime, streamId)
   chUrl = chUrl.replace(":", "%3a")
   chUrl = "%s:%s:%s >> %s" % (refCode, chUrl, chName, pTitle)
   self.VVQKYE("Changing Program ...")
   FFFANg(BF(self.VVViqh, chUrl))
  else:
   self.VVQKYE("Incorrect Timestamp !")
 def VVViqh(self, chUrl):
  FFkwBg(self, chUrl, VVIC8r=False)
  self.lastPlayPos = 0
  self.VVGvdh()
 def VVrb5m(self, isAudio):
  try:
   VVhMBa = InfoBar.instance
   if VVhMBa:
    from Screens.AudioSelection import AudioSelection, SubtitleSelection
    if isAudio : self.session.open(AudioSelection, infobar=VVhMBa)
    else  : self.session.open(SubtitleSelection, VVhMBa)
  except:
   pass
 @staticmethod
 def VVcvKH(session, mode=None):
  if   mode == "close_sig"   : FFdawr(session, reopen=True)
  elif mode == "close_iptvMenu"  : session.open(CC9X9s)
  elif mode == "close_openInFileMan" : session.open(CCCXvS, gotoMovie=True)
 @staticmethod
 def VV6JFp(session, **kwargs):
  session.openWithCallback(BF(CCb9j4.VVcvKH, session), CCb9j4, **kwargs)
class CCyNBo(Screen):
 def __init__(self, session, title="", VVILc0="Continue?", VVvAFb=True, VV4evd=False):
  self.skin, self.skinParam = FFRBRO(VVRoYj, 1200, 800, 50, 20, 20, "#11221122", "#11221122", 30)
  self.session = session
  self["myLine"] = Label()
  self.VVILc0 = VVILc0
  self.VV4evd = VV4evd
  self.maxHeight = 0
  no  = ("No" , "no" )
  yes = ("Yes", "yes")
  if VVvAFb : VVZJ87 = [no , yes]
  else   : VVZJ87 = [yes, no ]
  FFmmH7(self, title, VVZJ87=VVZJ87, addLabel=True)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVxCTS ,
   "cancel": self.cancel ,
   "red" : self.cancel ,
  }, -1)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  self.maxHeight = self.instance.size().height()
  self["myLabel"].setText("\n%s\n" % self.VVILc0)
  if self.VV4evd:
   self["myLabel"].instance.setHAlign(0)
  self.VVy1nH()
  FFplRG(self["myMenu"], fg="#08ffff00", bg="#08223333")
  FFQQYI(self["myMenu"])
  FFSK9d(self, self["myMenu"])
 def VVxCTS(self):
  item = self["myMenu"].l.getCurrentSelection()[1]
  if item is not None:
   if   item == "no" : self.close(False)
   elif item == "yes" : self.close(True)
  else:
   self.close(False)
 def cancel(self):
  self.close(False)
 def VVy1nH(self):
  winW  = self.instance.size().width()
  winH  = self.instance.size().height()
  labelW  = self["myLabel"].instance.size().width()
  labelH  = self["myLabel"].instance.size().height()
  textSize = self["myLabel"].instance.calculateSize()
  diff  = textSize.height() - labelH
  winNewH  = winH + diff
  if winNewH < winH:
   screenSize = getDesktop(0).size()
   self["myLabel"].instance.resize(eSize(*(labelW, labelH + diff)))
   self.instance.resize(eSize(*(winW, winNewH)))
   self.instance.move(ePoint((screenSize.width() - winW) // 2, (screenSize.height() - winNewH) // 2))
   names = [ "myMenu", "myLine" ]
   for name in names:
    try:
     obj = self[name]
     pos = obj.getPosition()
     obj.instance.move(ePoint(pos[0], pos[1] + diff))
    except:
     pass
class CCcsto(Screen):
 def __init__(self, session, title="", VVZJ87=None, width=1000, height=850, VVTFXq=30, barText="", minRows=1, VVkUAu=None, VVXyZL=None, VV6LYc=None, VVbiUc=None, VV3ba7=None, VV2YYF=None, VV18hv=False, VVhe5b=False, VVAL4K=None, VVIBI3=True, VVDlGi="#22003344", VVaSSM="#22002233"):
  self.skin, self.skinParam = FFRBRO(VVF5EY, width, height, 50, 40, 30, VVDlGi, VVaSSM, VVTFXq, barHeight=40, topRightBtns=3 if VVXyZL else 0)
  self.session   = session
  self.VVZJ87   = VVZJ87
  self.barText   = barText
  self.minRows   = minRows
  self.VVkUAu   = VVkUAu
  self.VVXyZL   = VVXyZL
  self.VV6LYc   = VV6LYc
  self.VVbiUc  = VVbiUc
  self.VV3ba7  = ("Delete File", BF(self.VVa4by, VVAL4K)) if not VVAL4K is None else VV3ba7
  self.VV2YYF   = VV2YYF
  self.VV18hv  = VV18hv
  self.VVhe5b  = VVhe5b
  self.Title    = title
  FFmmH7(self, title, VVZJ87=VVZJ87)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVxCTS    ,
   "cancel" : self.cancel    ,
   "info"  : self.VVaih8   ,
   "red"  : self.VVTzjg   ,
   "green"  : self.VVmWRu   ,
   "yellow" : self.VVKMjs   ,
   "blue"  : self.VVb2CP   ,
   "pageUp" : self.VVr6b9 ,
   "chanUp" : self.VVr6b9 ,
   "pageDown" : self.VVqiDF  ,
   "chanDown" : self.VVqiDF  ,
   "0"   : BF(self.VVeywt, 0) ,
   "1"   : BF(self.VVeywt, 1) ,
   "2"   : BF(self.VVeywt, 2) ,
   "3"   : BF(self.VVeywt, 3) ,
   "4"   : BF(self.VVeywt, 4) ,
   "5"   : BF(self.VVeywt, 5) ,
   "6"   : BF(self.VVeywt, 6) ,
   "7"   : BF(self.VVeywt, 7) ,
   "8"   : BF(self.VVeywt, 8) ,
   "9"   : BF(self.VVeywt, 9)
  }, -1)
  if VVIBI3:
   FF5k1E(self, self["myMenu"], isMenu=True)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFplRG(self["myMenu"])
  FFR3zK(self, minRows=self.minRows)
  FFj9eW(self)
  self.VVIzag(self["keyRed"]  , self.VV6LYc )
  self.VVIzag(self["keyGreen"] , self.VVbiUc )
  self.VVIzag(self["keyYellow"] , self.VV3ba7 )
  self.VVIzag(self["keyBlue"]  , self.VV2YYF )
  if self.barText      : self["myBar"].setText("  %s" % self.barText)
  elif not self["keyRed"].getVisible(): self["myBar"].setText("  OK = Select")
  else        : self["myBar"].setText("")
  FFHLqT(self)
 def VVIzag(self, btnObj, btnFnc):
  if btnFnc:
   FFR9Qm(btnObj, btnFnc[0])
 def VVWr0F(self, fnc=None):
  self.VVbiUc = fnc
  if fnc : self.VVIzag(self["keyGreen"], self.VVbiUc)
  else : self["keyGreen"].hide()
 def VVeywt(self, digit):
  digit = str(digit)
  VVZJ87 = self["myMenu"].list
  for ndx, item in enumerate(VVZJ87):
   if len(item) == 2:
    span = iSearch(r"^\[(\d)\]\s.+", FFxmTk(item[0]), IGNORECASE)
    if span and span.group(1) == digit:
     self.VV6zBC(ndx)
     self.VVxCTS()
     break
 def VVxCTS(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if item is not None:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   if self.VVkUAu:
    self.VVkUAu((self, txt, ref, ndx))
   else:
    if self.VV18hv: self.close((txt, ref, ndx))
    else     : self.close(item)
 def VVaih8(self):
  obj = self["myMenu"].l
  item = obj.getCurrentSelection()[1]
  if self.VVXyZL and item:
   txt = obj.getCurrentSelection()[0]
   ref = obj.getCurrentSelection()[1]
   ndx = obj.getCurrentSelectionIndex()
   self.VVXyZL(self, txt, ref, ndx)
 def cancel(self):
  self.close(None)
 def VVTzjg(self)  : self.VVT9pU(self.VV6LYc)
 def VVmWRu(self) : self.VVT9pU(self.VVbiUc)
 def VVKMjs(self) : self.VVT9pU(self.VV3ba7)
 def VVb2CP(self) : self.VVT9pU(self.VV2YYF)
 def VVT9pU(self, btnFnc):
  if btnFnc:
   item = self["myMenu"].l.getCurrentSelection()[1]
   fnc = btnFnc[1]
   fnc(self, item)
   if self.VVhe5b:
    self.cancel()
 def VVMQZS(self):
  ndx = self["myMenu"].getSelectedIndex()
  VVZJ87 = self["myMenu"].list
  VVZJ87.pop(ndx)
  if len(VVZJ87) > 0: self["myMenu"].setList(VVZJ87)
  else    : self.close()
 def VVa4by(self, basePath, menuObj, fName):
  FFNKVM(self, BF(self.VVbtLd, basePath + fName), "Delete this file ?\n\n%s" % fName, title=self.Title)
 def VVbtLd(self, path):
  FFzyFM(path)
  if fileExists(path) : FF5uKN(self, "Not deleted", 1000)
  else    : self.VVMQZS()
 def VVIEvp(self, VVZJ87):
  if len(VVZJ87) > 0:
   newList = []
   for item in VVZJ87:
    newList.append((item, item))
   self["myMenu"].setList(newList)
   FFR3zK(self, minRows=self.minRows)
  else:
   self.close("")
 def VVYAqb(self, newRow, isSort=False):
  lst = self["myMenu"].list
  lst.append(newRow)
  if isSort:
   lst.sort(key=lambda x: x[0].lower())
  self["myMenu"].setList(lst)
  FFR3zK(self, minRows=self.minRows)
  for ndx, item in enumerate(self["myMenu"].list):
   if item[1] == newRow[1]:
    self["myMenu"].moveToIndex(ndx)
    break
 def VVB0MO(self, isUp):
  ndx = self["myMenu"].getSelectionIndex()
  if   isUp and ndx > 0         : newIndex = ndx - 1
  elif not isUp and ndx < len(self["myMenu"].list) - 1 : newIndex = ndx + 1
  else             : return None
  newList = self["myMenu"].list
  newList.insert(newIndex, newList.pop(ndx))
  self["myMenu"].moveToIndex(newIndex)
  newList = []
  for item in self["myMenu"].list:
   newList.append(item[0])
  return newList
 def VV6zBC(self, ndx):
  self["myMenu"].moveToIndex(ndx)
 def VVJ8Ll(self, refTxt):
  for ndx, item in enumerate(self["myMenu"].list):
   if refTxt == item[1]:
    self.VV6zBC(ndx)
    break
 def VVCLkK(self, txt):
  for ndx, item in enumerate(self["myMenu"].list):
   if txt == item[0]:
    self.VV6zBC(ndx)
    break
 def VVr6b9(self) : self["myMenu"].moveToIndex(0)
 def VVqiDF(self) : self["myMenu"].moveToIndex(len(self["myMenu"].list) - 1)
class CCw8v2(Screen):
 def __init__(self, session, title="", width=1600, height=900, vMargin=5, header=None, VVarfR=None, VVFvCJ=None, VVhAo0=None, VVTFXq=26, VVUdUN=False, VVcLcW=0, VVwmV1=None, VVs5AA=None, menuButtonFnc=None, VVZ224=None, VVX66G=None, VVIrDY=None, VVFadD=None, VVxxkd=None, VVotuX=None, VV0xpR=None, VVqC9o=-1, VVqDAH=0, searchCol=0, lastFindConfigObj=None, VVDlGi=None, VVaSSM=None, VV6XYq="#00dddddd", VVzgHY="#11002233", VVqSOL=None, VVkUYa="#11111111", VVivoO="#0a555555", VV4y9R="#0affffff", VVdjpa="#11552200", VVm9xu="#0055ff55", VVm9xuRev="#0000bbff"):
  self.skin, self.skinParam = FFRBRO(VVFX81, width, height, 50, 10, vMargin, "#22003344", "#22002233", 26, barHeight=40, topRightBtns=2, lineGap=0.6)
  self.session    = session
  FFmmH7(self, title)
  self.Title     = title
  self.header     = header
  self.VVarfR     = VVarfR
  self.totalCols    = len(VVarfR[0])
  self.VVcLcW   = VVcLcW
  self.lastSortModeIsReverese = False
  self.VVUdUN   = VVUdUN
  self.VVAfAx   = 0.01
  self.VVcl83   = 0.02
  self.VVtMNb = 0.03
  self.VVYQ3x  = 1
  self.VVhAo0 = VVhAo0
  self.colWidthPixels   = []
  self.VVwmV1   = VVwmV1
  self.OKButtonObj   = None
  self.VVs5AA   = VVs5AA
  self.VVZ224   = VVZ224
  self.VVX66G   = VVX66G
  self.VVIrDY  = VVIrDY
  self.VVFadD   = VVFadD
  self.VVxxkd    = VVxxkd
  self.VVotuX   = VVotuX
  self.tableRefreshCB   = None
  self.VV0xpR  = VV0xpR
  self.menuButtonFnc   = menuButtonFnc
  self.VVqC9o    = VVqC9o
  self.VVqDAH   = VVqDAH
  self.searchCol    = searchCol
  self.VVFvCJ    = VVFvCJ
  self.keyPressed    = -1
  self.VVTFXq    = FFq3UP(VVTFXq)
  self.VVNyBH    = FFdrU1(self.VVTFXq, self.skinParam["lineGap"])
  self.scrollBarWidth   = self.skinParam["scrollBarW"]
  self.VVDlGi    = VVDlGi
  self.VVaSSM      = VVaSSM
  self.VV6XYq    = FFkR1T(VV6XYq)
  self.VVzgHY    = FFkR1T(VVzgHY)
  self.VVqSOL    = VVqSOL
  self.VVkUYa    = FFkR1T(VVkUYa)
  self.VVivoO   = FFkR1T(VVivoO)
  self.VV4y9R    = FFkR1T(VV4y9R)
  self.VVdjpa    = FFkR1T(VVdjpa)
  self.VVm9xu   = FFkR1T(VVm9xu)
  self.VVm9xuRev  = FFkR1T(VVm9xuRev)
  self.VVQW9r  = False
  self.selectedItems   = 0
  self.VVQ3TM   = FFkR1T("#01fefe01")
  self.VVsPMt   = FFkR1T("#11400040")
  self.VVWZQO  = self.VVQ3TM
  self.VVocRQ  = self.VVkUYa
  self.lastFindConfigObj  = lastFindConfigObj or CFG.lastFindGeneral
  if self.VVqDAH:
   self["keyMenu"].hide()
   self["keyInfo"].hide()
   if self.VVqDAH == 1: self["myBar"].setText("  OK = Row Info.")
  self["myTableH"] = MenuList([], True, eListboxPythonMultiContent)
  self["myTable"]  = MenuList([], True, eListboxPythonMultiContent)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVi1LJ  ,
   "red"  : self.VV6SHB  ,
   "green"  : self.VVqjte ,
   "yellow" : self.VVWm3K ,
   "blue"  : self.VVrKDC  ,
   "menu"  : self.VVLDuT ,
   "info"  : self.VVc83A  ,
   "cancel" : self.VVvtol  ,
   "up"  : self.VVA5vi    ,
   "down"  : self.VVT9T9  ,
   "left"  : self.VV9Iu6   ,
   "right"  : self.VVNeOF  ,
   "next"  : self.VV3Rs1  ,
   "last"  : self.VVMW52  ,
   "home"  : self.VVJxaX  ,
   "pageUp" : self.VVJxaX  ,
   "chanUp" : self.VVJxaX  ,
   "end"  : self.VV5srZ  ,
   "pageDown" : self.VV5srZ  ,
   "chanDown" : self.VV5srZ
  }, -1)
  FF5k1E(self, self["myTable"], self.searchCol)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFj9eW(self)
  try:
   self.VVp3gG()
  except Exception as e:
   FFw5OO(self, str(e), title=self.Title)
   self.close(None)
 def VVp3gG(self):
  FFHLqT(self)
  if self.VVDlGi:
   FFWN9Z(self["myTitle"], self.VVDlGi)
  if self.VVaSSM:
   FFWN9Z(self["myBody"] , self.VVaSSM)
   FFWN9Z(self["myTableH"] , self.VVaSSM)
   FFWN9Z(self["myTable"] , self.VVaSSM)
   FFWN9Z(self["myBar"]  , self.VVaSSM)
  self.VVIzag(self.VVZ224  , self["keyRed"])
  self.VVIzag(self.VVX66G  , self["keyGreen"])
  self.VVIzag(self.VVIrDY , self["keyYellow"])
  self.VVIzag(self.VVFadD  , self["keyBlue"])
  if self.VVwmV1:
   if   not self["keyRed"].getVisible() : self.OKButtonObj = self["keyRed"]
   elif not self["keyBlue"].getVisible() : self.OKButtonObj = self["keyBlue"]
   else         : self.OKButtonObj = None
   if self.OKButtonObj and self.VVwmV1[0]:
    self.OKButtonObj.show()
    self.OKButtonObj.setText("OK = %s" % self.VVwmV1[0])
    FFWN9Z(self.OKButtonObj, "#11000000")
  self["myTableH"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTable"].l.setSelectionClip(eRect(0, 0, 0, 0))
  self["myTableH"].l.setItemHeight(self.VVNyBH)
  self["myTableH"].l.setFont(0, gFont(VVR8AG, self.VVTFXq))
  self["myTable"].l.setItemHeight(self.VVNyBH)
  self["myTable"].l.setFont(0, gFont(VVR8AG, self.VVTFXq))
  try:
   self["myTable"].instance.setScrollbarSliderBorderWidth(0)
  except:
   pass
  w = self["myTable"].instance.size().width()
  h = self["myTable"].instance.size().height()
  pos = self["myTable"].getPosition()
  if self.header:
   self["myTableH"].instance.resize(eSize(*(w, self.VVNyBH)))
   self["myTable"].instance.move(ePoint(pos[0], pos[1] + self.VVNyBH))
   self["myTable"].instance.resize(eSize(*(w, h - self.VVNyBH)))
  h  = self["myTable"].instance.size().height()
  pos  = self["myTable"].getPosition()
  part = self["myTable"].instance.size().height() % self.VVNyBH
  half = int(part / 2)
  self["myTable"].instance.resize(eSize(*(w, h - part)))
  self["myTable"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.header:
   pos = self["myTableH"].getPosition()
   self["myTableH"].instance.move(ePoint(pos[0], pos[1] + half))
  menuWidth = self["myTable"].instance.size().width()
  if self.VVNyBH * len(self.VVarfR) > self["myTable"].instance.size().height():
   menuWidth = menuWidth - int(self.scrollBarWidth) - 5
  if not self.VVhAo0:
   self.VVhAo0 = ([float(100.0 / self.totalCols)] * self.totalCols)
  self.colWidthPixels = list(self.VVhAo0)
  if not self.colWidthPixels:
   self.colWidthPixels = int([menuWidth / self.totalCols] * self.totalCols)
  else:
   for i, item in enumerate(self.colWidthPixels):
    self.colWidthPixels[i] = int(item * menuWidth / 100)
  if not self.VVFvCJ:
   self.VVFvCJ = [LEFT | RT_VALIGN_CENTER] * self.totalCols
  else:
   tmpList = self.VVFvCJ
   self.VVFvCJ = []
   for item in tmpList:
    self.VVFvCJ.append(item | RT_VALIGN_CENTER)
  self.VVJzBl()
  if self.VVxxkd:
   self.VVxxkd(self)
 def VVIzag(self, btnFnc, btn):
  if btnFnc : FFR9Qm(btn, btnFnc[0])
  else  : FFR9Qm(btn, "")
 def VVeEC2(self, waitTxt):
  FFJsIX(self, self.VVJzBl, title=waitTxt)
 def VVJzBl(self, onlyHeader=False):
  try:
   if self.header:
    sortedFg = self.VVm9xuRev if self.lastSortModeIsReverese else self.VVm9xu
    self["myTableH"].setList([self.VV7Zz5(0, self.header, self.VV4y9R, self.VVdjpa, self.VV4y9R, self.VVdjpa, sortedFg)])
   if onlyHeader:
    return
   self["myTable"].list = []
   for c, row in enumerate(self.VVarfR):
    self["myTable"].list.append(self.VV7Zz5(c, row, self.VV6XYq, self.VVzgHY, self.VVqSOL, self.VVkUYa, None))
   self.VVarfR = []
   self["myTable"].setList(self["myTable"].list)
   if self.VVqC9o > -1:
    self["myTable"].moveToIndex(self.VVqC9o )
   self.VVKZIT()
   if self.VVqDAH:
    tableH = self["myTable"].instance.size().height()
    rowsH = self.VVNyBH * len(self["myTable"].list)
    if rowsH < tableH:
     diff = tableH - rowsH
     newH = self.instance.size().height() - diff
     screenSize = getDesktop(0).size()
     width = self.instance.size().width()
     self.instance.resize(eSize(*(width, newH)))
     self.instance.move(ePoint((screenSize.width() - width) // 2, (screenSize.height() - newH) // 2))
     names = [ "keyRed", "keyGreen", "keyYellow", "keyBlue", "myBar", "myLine" ]
     for name in names:
      obj = self[name]
      pos = obj.getPosition()
      obj.instance.move(ePoint(pos[0], pos[1] - diff))
     FFYIKB(self, width, newH)
   if self.VVotuX:
    self.VVT9pU(self.VVotuX, None)
   if self.tableRefreshCB:
    self.VVT9pU(self.tableRefreshCB, None)
    self.tableRefreshCB = None
  except AttributeError as attrErr:
   pass
  except Exception as e:
   try:
    FFw5OO(self, str(e), title=self.Title)
    self.close()
   except:
    pass
 def VV7Zz5(self, keyIndex, columns, VV6XYq, VVzgHY, VVqSOL, VVkUYa, VVm9xu):
  row = [keyIndex]
  posX = 0
  for ndx, entry in enumerate(columns):
   if VVm9xu and ndx == self.VVcLcW : textColor = VVm9xu
   else           : textColor = VV6XYq
   span = iSearch(r"\s*#(.)(#[a-fA-F0-9]{8})#(.*)", entry, IGNORECASE)
   if span:
    c = FFkR1T(span.group(2))
    if span.group(1) == "f" : textColor = c
    else     : VVzgHY = c
    entry = span.group(3)
   if self.VVFvCJ[ndx] & LEFT:
    entry = " " + entry + " "
   row.append(MultiContentEntryText( pos   = (posX, 0)
           , size   = (self.colWidthPixels[ndx], self.VVNyBH)
           , font   = 0
           , flags   = self.VVFvCJ[ndx]
           , text   = entry
           , color   = textColor
           , backcolor  = VVzgHY
           , color_sel  = VVqSOL or textColor
           , backcolor_sel = VVkUYa
           , border_width = 1
           , border_color = self.VVivoO
           ))
   posX += self.colWidthPixels[ndx]
  return row
 def VVc83A(self):
  rowData = self.VVwSVU()
  if rowData:
   title, txt, colList = rowData
   if self.VVs5AA:
    fnc  = self.VVs5AA[1]
    params = self.VVs5AA[2]
    fnc(self, title, txt, colList)
   else:
    FF90Bc(self, txt, title)
 def VVi1LJ(self):
  if   self.VVQW9r : self.VVV4ZZ(self.VVgu5W(), mode=2)
  elif self.VVwmV1  : self.VVT9pU(self.VVwmV1, None)
  else      : self.VVc83A()
 def VV6SHB(self) : self.VVT9pU(self.VVZ224 , self["keyRed"])
 def VVqjte(self) : self.VVT9pU(self.VVX66G , self["keyGreen"])
 def VVWm3K(self): self.VVT9pU(self.VVIrDY , self["keyYellow"])
 def VVrKDC(self) : self.VVT9pU(self.VVFadD , self["keyBlue"])
 def VVT9pU(self, buttonFnc, btnObj):
  if btnObj and not btnObj.getVisible():
   return
  if buttonFnc:
   if len(buttonFnc) > 3 and buttonFnc[3]:
    FF5uKN(self, buttonFnc[3])
    FFFANg(BF(self.VVBlkH, buttonFnc))
   else:
    self.VVBlkH(buttonFnc)
 def VVBlkH(self, buttonFnc):
  fnc   = buttonFnc[1]
  params  = buttonFnc[2]
  rowData = self.VVwSVU()
  if rowData:
   title, txt, colList = rowData
   if not params : fnc(self, title, txt, colList)
   else   : fnc(self, *params)
 def VVV4ZZ(self, ndx, mode=0):
  try:  row = self["myTable"].list[ndx]
  except: row = None
  if row:
   isSelected = row[1][9] == self.VVQ3TM
   newRow = self.VVc6YJ()
   if mode == 0 or (mode == 2 and isSelected):
    newRow = self.VV7Zz5(ndx, newRow, self.VV6XYq, self.VVzgHY, self.VVqSOL, self.VVkUYa, None)
    if isSelected:
     self.selectedItems -= 1
   else:
    newRow = self.VV7Zz5(ndx, newRow, self.VVQ3TM, self.VVsPMt, self.VVWZQO, self.VVocRQ, None)
    self.selectedItems += 1
   self["myTable"].list.pop(ndx)
   self["myTable"].list.insert(ndx, newRow)
   if self.VVgu5W() < len(self["myTable"].list) - 1:
    self.VVT9T9()
   else:
    self.VVKZIT()
 def VV2Vwg(self)  : FFJsIX(self, BF(self.VVw9zi, True ), title="Selecting all ..."  )
 def VV6pZ8(self) : FFJsIX(self, BF(self.VVw9zi, False), title="Unselecting all ...")
 def VVw9zi(self, isSel=True):
  if isSel:
   fg, bg = self.VVQ3TM, self.VVsPMt
   self.selectedItems = len(self["myTable"].list)
   self.VVDjjC(True)
  else:
   fg, bg = self.VV6XYq, self.VVzgHY
   self.selectedItems = 0
  for ndx, row in enumerate(self["myTable"].list):
   isPainted = row[1][9] == self.VVQ3TM
   if (isSel and not isPainted) or (not isSel and isPainted):
    for col in range(1, len(row)):
     param = list(self["myTable"].list[ndx][col])
     param[8]  = fg
     param[9]  = fg
     param[10] = bg
     self["myTable"].list[ndx][col] = tuple(param)
  self["myTable"].l.invalidate()
 def VVwSVU(self):
  item = self["myTable"].getCurrent()
  if item:
   colList = []
   txt  = ""
   tot  = 0
   for i in range(self.totalCols):
    colTxt = item[i + 1][7].strip()
    colList.append(colTxt)
    if self.VVhAo0[i] > 1 or self.VVhAo0[i] == self.VVAfAx or self.VVhAo0[i] == self.VVtMNb:
     tot += 1
     if self.header : name = self.header[i]
     else   : name = "Column-%d" % (i + 1)
     txt += "%s\t: %s\n" % (name, colTxt)
   if tot == 1:
    txt = colList[0]
   rowNum = "Row Number\t: %d of %d" % (item[0] + 1, len(self["myTable"].list))
   return rowNum, txt, colList
  else:
   return None
 def VVvtol(self):
  if self.VV0xpR : self.VV0xpR(self)
  else     : self.close(None)
 def cancel(self):
  self["myTable"].onSelectionChanged = []
  self.close(None)
 def VVLGq4(self):
  return self["myTitle"].getText().strip()
 def VVCpTV(self):
  return self.header
 def VVanwx(self, title):
  self.Title = title
  self["myTitle"].setText("  " + title.strip() + "  ")
 def VVmvmG(self, title, color=None):
  self["myBar"].setText("  " + title.strip() + "  ")
  if color:
   FFHNWi(self["myBar"], color)
 def VVx85I(self, txt):
  FF5uKN(self, txt)
 def VVIzOr(self, txt, Time=1000):
  FF5uKN(self, txt, Time)
 def VV1uwH(self): self["keyGreen"].show()
 def VVJSaW(self): self["keyGreen"].hide()
 def VV0aFP(self): return self["keyGreen"].visible
 def VVW7OH(self):
  FF5uKN(self)
 def VVByXR(self, fnc):
  self["myTable"].onSelectionChanged.append(fnc)
 def VVLC76(self):
  return len(self["myTable"].list)
 def VVgu5W(self):
  return self["myTable"].l.getCurrentSelectionIndex()
 def VVWnGz(self):
  return len(self["myTable"].list)
 def VVDjjC(self, isOn):
  self.VVQW9r = isOn
  if isOn:
   color = "#01883366"
   self["keyMenu"].hide()
   if self.VVFadD: self["keyBlue"].hide()
   if self.VVwmV1 and self.OKButtonObj: self.OKButtonObj.setText("OK = Select")
  else:
   color = self.skinParam["titleColor"]
   self["keyMenu"].show()
   if self.VVFadD: self["keyBlue"].show()
   if self.VVwmV1 and self.OKButtonObj: self.OKButtonObj.setText("OK = %s" % self.VVwmV1[0])
   self.VV6pZ8()
  FFWN9Z(self["myTitle"], color)
  FFWN9Z(self["myBar"]  , color)
 def VVT9wK(self):
  return self.VVQW9r
 def VVsyP1(self):
  return self.selectedItems
 def VVa8Hj(self):
  curRow = self["myTable"].l.getCurrentSelectionIndex()
  self["myTable"].moveToIndex(curRow + 1)
  self.VVKZIT()
 def VVa6qz(self, colNum):
  if colNum < self.totalCols:
   if self.header : subj = self.header[colNum]
   else   : subj = ""
   lst = set()
   for item in self["myTable"].list:
    lst.add(item[colNum + 1][7])
   return subj, str(len(lst))
  else:
   return "", ""
 def VVMqm3(self):
  txt  = "Total Rows\t: %d\n\n" % self.VVLC76()
  txt += FFfR82("Total Unique Items", VVsObI)
  for i in range(self.totalCols):
   if self.VVhAo0[i - 1] > 1 or self.VVhAo0[i - 1] == self.VVAfAx or self.VVhAo0[i - 1] == self.VVtMNb:
    name, tot = self.VVa6qz(i)
    txt +=  "%s\t: %s\n" % (name, tot)
  FF90Bc(self, txt)
 def VVYzwE(self, colNum):
  item = self["myTable"].getCurrent()
  if item : return item[colNum + 1][7].strip()
  else : return None
 def VVc6YJ(self):
  return self.VVzNXU(self["myTable"].l.getCurrentSelectionIndex())
 def VVzNXU(self, rowNdx):
  colList = []
  item = self["myTable"].list[rowNdx]
  if item:
   for i in range(1, self.totalCols + 1):
    colList.append(item[i][7].strip())
  return colList
 def VVcckS(self, newList, newTitle="", VVuO90Msg=True, tableRefreshCB=None, isSort=True):
  if newTitle:
   self.VVanwx(newTitle)
  if newList:
   self.VVarfR = newList
   if tableRefreshCB:
    self.tableRefreshCB = ("", tableRefreshCB, [])
   isNum = False
   if self.VVUdUN and self.VVcLcW == 0:
    isNum = True
   else:
    for cols in self.VVarfR:
     if not FFOPNa(cols[self.VVcLcW]): break
    else:
     isNum = True
   if isSort:
    if isNum: self.VVarfR.sort(key=lambda x: int(x[self.VVcLcW])  , reverse=self.lastSortModeIsReverese)
    else : self.VVarfR.sort(key=lambda x: x[self.VVcLcW].lower() , reverse=self.lastSortModeIsReverese)
   if VVuO90Msg : self.VVeEC2("Refreshing ...")
   else   : self.VVJzBl()
  else:
   FFw5OO(self, "Cannot refresh list", title=self.Title)
   self.cancel()
 def VVjWa0(self, row, moveCurs=True):
  row = self["myTable"].list.append(self.VV7Zz5(self.VVWnGz(), row, self.VV6XYq, self.VVzgHY, self.VVqSOL, self.VVkUYa, None))
  self["myTable"].l.setList(self["myTable"].list)
  if moveCurs: self.VV5srZ()
 def VVrBGY(self):
  self["myTable"].list.pop(self.VVgu5W())
  self["myTable"].l.setList(self["myTable"].list)
 def VVBaiu(self, data):
  ndx = self.VVgu5W()
  newRow = self.VV7Zz5(ndx, data, self.VV6XYq, self.VVzgHY, self.VVqSOL, self.VVkUYa, None)
  if newRow:
   self["myTable"].list[ndx] = newRow
   self.VVKZIT()
   return True
  else:
   return False
 def VVr9B1(self, ndx, data):
  if ndx >=0 and ndx < len(self["myTable"].list):
   newRow = self.VV7Zz5(ndx, data, self.VV6XYq, self.VVzgHY, self.VVqSOL, self.VVkUYa, None)
   if newRow:
    self["myTable"].list[ndx] = newRow
    self.VVGHPP()
 def VVGHPP(self):
  self["myTable"].l.setList(self["myTable"].list)
 def VVOiFn(self, colNum=0):
  for ndx, item in enumerate(self["myTable"].list):
   lst = list(self["myTable"].list[ndx][colNum + 1])
   lst[7] = str(ndx + 1)
   self["myTable"].list[ndx][colNum + 1] = tuple(lst)
  self["myTable"].l.setList(self["myTable"].list)
 def VVr96u(self, colNum, textToFind, VV70Sp=False):
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   if textToFind in item:
    self["myTable"].moveToIndex(i)
    self.VVKZIT()
    break
  else:
   if VV70Sp:
    FF5uKN(self, "Not found", 1000)
 def VVp2CY(self, colDict, VV70Sp=False):
  for i in range(len(self["myTable"].list)):
   for colNum, txt in colDict.items():
    if not txt == self["myTable"].list[i][colNum + 1][7].strip():
     break
   else:
    self["myTable"].moveToIndex(i)
    self.VVKZIT()
    return
  if VV70Sp:
   FF5uKN(self, "Not found", 1000)
 def VVdiFM(self, colNum):
  tList = []
  for i in range(len(self["myTable"].list)):
   item = self["myTable"].list[i][colNum + 1][7].strip()
   tList.append(item)
  return tList
 def VVnd97(self, colNum):
  for i in range(len(self["myTable"].list)):
   if not FFOPNa(self["myTable"].list[i][colNum + 1][7].strip()):
    return False
  return True
 def VVf36z(self, colNum):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVQ3TM:
    item = self["myTable"].list[ndx][colNum + 1][7].strip()
    tList.append(item)
  return tList
 def VVoXzr(self):
  if self.selectedItems:
   for ndx, row in enumerate(self["myTable"].list):
    if row[1][9] == self.VVQ3TM:
     return ndx
  return -1
 def VVJKAn(self):
  tList = []
  for ndx, row in enumerate(self["myTable"].list):
   if row[1][9] == self.VVQ3TM:
    item = self["myTable"].list[ndx]
    colList = []
    for i in range(1, self.totalCols + 1):
     colList.append(item[i][7].strip())
    tList.append(colList)
  return tList
 def VVE8c8(self, colNum):
  row = self["myTable"].list[colNum]
  if row[1][9] == self.VVQ3TM: return True
  else        : return False
 def VVlHja(self):
  for ndx, row in enumerate(self["myTable"].list):
   item = self["myTable"].list[ndx]
   colList = []
   for i in range(1, self.totalCols + 1):
    colTxt = item[i][7].strip()
    colList.append(colTxt)
   yield colList
 def VVLDuT(self):
  if self.menuButtonFnc:
   self.VVBlkH(self.menuButtonFnc)
   return
  if not self["keyMenu"].getVisible() or self.VVqDAH:
   return
  txt  = self.lastFindConfigObj.getValue()
  curRow = self.VVgu5W()
  totRows = len(self["myTable"].list)
  itemOf = lambda cond, p1, p2: (p1, p2) if cond else (p1, )
  VVZJ871, VVXkSw = CCdUgX.VVwE3y(self, False, False)
  VVZJ87 = []
  VVZJ87.append(itemOf(txt and curRow < totRows - 1 , "Find Next\t\t>"     , "findNext"  ))
  VVZJ87.append(itemOf(txt and curRow > 0   , "Find Previous\t\t<"    , "findPrev"  ))
  VVZJ87.append(("Find ...\t\t%s" % (FFGB9z(txt, VVkqaK) if txt else ""), "findNew"   ))
  VVZJ87.append(itemOf(bool(VVZJ871)    , "Find (from Filter) ..."   , "filter"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Table Statistcis"             , "tableStat"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((FFGB9z("Export Table to .html"     , VVsObI) , "VVGXqn" ))
  VVZJ87.append((FFGB9z("Export Table to .csv"     , VVsObI) , "VVS4ku" ))
  VVZJ87.append((FFGB9z("Export Table to .txt (Tab Separated)", VVsObI) , "VVoe4G" ))
  sList = []
  tot  = 0
  for i in range(self.totalCols):
   if self.VVhAo0[i] > 1 or self.VVhAo0[i] == self.VVcl83:
    tot += 1
    if self.header : name = self.header[i]
    else   : name = "Column-%d" % (i + 1)
    sList.append(("Sort by : %s" % name, i))
  if tot:
   VVZJ87.append(VVoqHH)
   if tot == 1 : VVZJ87.append(("Sort", sList[0][1]))
   else  : VVZJ87 += sList
  VV2YYF = ("Keys Help", self.FF1DpjHelp)
  FFYySC(self, self.VV1fCz, VVZJ87=VVZJ87, title=self.VVLGq4(), VV2YYF=VV2YYF)
 def VV1fCz(self, item=None):
  if item is not None:
   title="Exporting ..."
   if   item == "findNext"  : self.VViQjN()
   elif item == "findPrev"  : self.VViQjN(isPrev=True)
   elif item == "findNew"  : self.VVCqTW()
   elif item == "filter"  : self.VVrjgl()
   elif item == "tableStat" : self.VVMqm3()
   elif item == "VVGXqn": FFJsIX(self, self.VVGXqn, title=title)
   elif item == "VVS4ku" : FFJsIX(self, self.VVS4ku , title=title)
   elif item == "VVoe4G" : FFJsIX(self, self.VVoe4G , title=title)
   else:
    if self.VVcLcW == item: self.lastSortModeIsReverese = not self.lastSortModeIsReverese
    else      : self.VVcLcW, self.lastSortModeIsReverese = item, False
    if self.VVUdUN and self.VVcLcW == 0 or self.VVnd97(item):
     self["myTable"].list.sort(key=lambda x: int(x[item + 1][7]), reverse=self.lastSortModeIsReverese)
    else:
     self["myTable"].list.sort(key=lambda x: x[item + 1][7].lower(), reverse=self.lastSortModeIsReverese)
    self["myTable"].l.setList(self["myTable"].list)
    self.VVJzBl(onlyHeader=True)
 def FF1DpjHelp(self, VV4EHV, path):
  FFqsYG(self, "_help_table", "Table (Keys Help)")
 def VVA5vi(self):
  self["myTable"].up()
  self.VVKZIT()
 def VVT9T9(self):
  self["myTable"].down()
  self.VVKZIT()
 def VV9Iu6(self):
  self["myTable"].pageUp()
  self.VVKZIT()
 def VVNeOF(self):
  self["myTable"].pageDown()
  self.VVKZIT()
 def VVJxaX(self):
  self["myTable"].moveToIndex(0)
  self.VVKZIT()
 def VV5srZ(self):
  self["myTable"].moveToIndex(len(self["myTable"].list) - 1)
  self.VVKZIT()
 def VVYNxS(self, rowNdx):
  self["myTable"].moveToIndex(rowNdx)
  self.VVKZIT()
 def VV3Rs1(self):
  if self.lastFindConfigObj.getValue():
   if self.VVgu5W() == len(self["myTable"].list) - 1 : FF5uKN(self, "End reached", 1000)
   else              : self.VViQjN()
  else:
   FF5uKN(self, 'Set "Find" in Menu', 1500)
 def VVMW52(self):
  if self.lastFindConfigObj.getValue():
   if self.VVgu5W() == 0 : FF5uKN(self, "Top reached", 1000)
   else       : self.VViQjN(isPrev=True)
  else:
   FF5uKN(self, 'Set "Find" in Menu', 1500)
 def VVWzv4(self, txt):
  FFdEZ4(self.lastFindConfigObj, txt)
 def VVCqTW(self):
  FFaSvq(self, self.VV8YJA, title="Find in Table", defaultText=self.lastFindConfigObj.getValue(), message="Enter Text:")
 def VV8YJA(self, VVYwVo):
  if not VVYwVo is None:
   txt = VVYwVo.strip()
   self.VVWzv4(txt)
   if VVYwVo: self.VViQjN(reset=True)
   else  : FF5uKN(self, "Nothing to find !", 1500)
 def VVrjgl(self):
  VVZJ87, VVXkSw = CCdUgX.VVwE3y(self, False, False)
  VV3ba7 = ("Edit Filter", BF(self.VVsni2, VVXkSw))
  if VVZJ87 : FFYySC(self, self.VVCfQu, VVZJ87=VVZJ87, VV3ba7=VV3ba7, title="Find from Filter")
  else  : FF5uKN(self, "Filter Error !", 1500)
 def VVCfQu(self, item=None):
  if item is not None:
   txt = item.strip()
   if txt:
    self.VVWzv4(txt)
    self.VViQjN(reset=True)
   else:
    FF5uKN(self, "No entry !", 1500)
 def VVsni2(self, VVXkSw, VVbBRSObj, sel):
  if fileExists(VVXkSw) : CCQ3ND(self, VVXkSw, VVCeou=None)
  else       : FFZoTn(self, VVXkSw)
  VVbBRSObj.cancel()
 def VViQjN(self, reset=False, isPrev=False):
  curRow = self.VVgu5W()
  totRows = len(self["myTable"].list)
  if   reset : row1, row2, steps = 0, totRows, 1
  elif isPrev : row1, row2, steps = curRow - 1, -1, -1
  else  : row1, row2, steps = curRow + 1, totRows, 1
  tupl, asPrefix = CCdUgX.VV0Xfy(self.lastFindConfigObj.getValue())
  if tupl:
   for i in range(row1, row2, steps):
    line = self["myTable"].list[i][self.searchCol + 1][7]
    line = line.strip().lower()
    if asPrefix:
     if line.startswith(tupl):
      self.VVYNxS(i)
      break
    elif any(x in line for x in tupl):
     self.VVYNxS(i)
     break
   else:
    FF5uKN(self, "Not found", 1000)
  else:
   FF5uKN(self, "Check your query", 1500)
 def VVoe4G(self):
  expFile = self.VVWgw4() + ".txt"
  with open(expFile, "w") as f:
   filteredHeader = self.VVZHar()
   if filteredHeader:
    f.write("\t".join(filteredHeader) + "\n")
   for i in range(len(self["myTable"].list)):
    row = self.VVzNXU(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVhAo0[ndx] > self.VVYQ3x or self.VVhAo0[ndx] == self.VVtMNb:
      col = self.VVwwyq(col)
      col = col.replace("\n", " _ ")
      newRow.append(col)
    f.write("\t".join(newRow) + "\n")
  self.VVdQos(expFile)
 def VVS4ku(self):
  expFile = self.VVWgw4() + ".csv"
  with open(expFile, "w") as f:
   filteredHeader = self.VVZHar()
   if filteredHeader:
    f.write(",".join(filteredHeader) + "\n")
   pattern = "^[0-9a-fA-F]*$"
   for i in range(len(self["myTable"].list)):
    row = self.VVzNXU(i)
    newRow = []
    for ndx, col in enumerate(row):
     if self.VVhAo0[ndx] > self.VVYQ3x or self.VVhAo0[ndx] == self.VVtMNb:
      if iMatch(pattern, col) : prefix = "'"
      else     : prefix = ""
      col = self.VVwwyq(col)
      col = col.replace(",", ";").replace("\n", " _ ")
      newRow.append(prefix + col)
    f.write(",".join(newRow) + "\n")
  self.VVdQos(expFile)
 def VVGXqn(self):
  txt   = '<!DOCTYPE html>\n'
  txt  += '<html>\n'
  txt  += ' <head>\n'
  txt  += ' <meta charset="utf-8">\n'
  txt  += ' <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
  txt  += ' <TITLE>%s - %s (%s)</TITLE>\n' % (self.VVLGq4(), PLUGIN_NAME, VVLBtR)
  txt  += ' <style>\n'
  txt  += '  table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }\n'
  txt  += '  td,th { border: 1px solid #dddddd; text-align: left; padding: 5px; }\n'
  txt  += '  td { font-size: 0.8em; }\n'
  txt  += '  th { color:#006000; background-color:#FFFFaa; font-size: 1.2em; }\n'
  txt  += '  tr:nth-child(even) { background-color: #f8f8f8; }\n'
  txt  += ' </style>\n'
  txt  += ' </head>\n'
  txt  += ' <body>\n'
  txt  += '  <h2 style="color:#006000;">%s</h2>\n' % self.VVLGq4()
  txt  += '  <table>\n'
  txt  +=     '#colgroup#'
  txt  += '   <tr>#tableHead#</tr>\n'
  txt2  = '  <table>\n'
  txt2 += ' </body>\n'
  txt2 += '</html>\n'
  tableHead  = ""
  filteredHeader = self.VVZHar()
  if filteredHeader:
   for col in filteredHeader:
    tableHead += '<th>%s</th>' % col
  txt = txt.replace("#tableHead#", tableHead)
  colgroup = ""
  if self.VVhAo0:
   colgroup += '   <colgroup>'
   for w in self.VVhAo0:
    if w > self.VVYQ3x or w == self.VVtMNb:
     colgroup += '<col style="width: %d%s;" />' % (w, "%")
   colgroup += "</colgroup>\n"
  txt = txt.replace("#colgroup#", colgroup)
  expFile = self.VVWgw4() + ".html"
  with open(expFile, "w") as f:
   f.write(txt)
   for i in range(len(self["myTable"].list)):
    row = self.VVzNXU(i)
    newRow = "   <tr>"
    for ndx, col in enumerate(row):
     if self.VVhAo0[ndx] > self.VVYQ3x or self.VVhAo0[ndx] == self.VVtMNb:
      col = self.VVwwyq(col)
      newRow += '<td>%s</td>' % col
    newRow += "</tr>\n"
    f.write(newRow)
   f.write(txt2)
  self.VVdQos(expFile)
 def VVZHar(self):
  newRow = []
  if self.header:
   for ndx, col in enumerate(self.header):
    if self.VVhAo0[ndx] > self.VVYQ3x or self.VVhAo0[ndx] == self.VVtMNb:
     newRow.append(col.strip())
  return newRow
 def VVwwyq(self, col):
  if col.count(":") > 8:
   col = col.replace(":", "_")
   col = col.rstrip("_")
  col = iSub(r"(#.#[a-fA-F0-9]{8}#)" ,"" , col, flags=IGNORECASE)
  return FFxmTk(col)
 def VVWgw4(self):
  fileName = iSub("[^0-9a-zA-Z]+", "_", self.VVLGq4())
  fileName = fileName.replace("__", "_")
  path  = FF1vNj(CFG.exportedTablesPath.getValue())
  expFile  = path + fileName + "_" + FFUD38()
  return expFile
 def VVdQos(self, expFile):
  FF15cM(self, "File exported to:\n\n%s" % expFile, title=self.VVLGq4())
 def VVKZIT(self):
  row = self["myTable"].l.getCurrentSelection()
  if row:
   firstColumn = row[1]
   lastColumn = row[len(row) - 1]
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), True)
   self["myTable"].l.setSelectionClip(eRect(int(firstColumn[1]), int(firstColumn[0]), int(lastColumn[1] + lastColumn[3]), int(lastColumn[4])), False)
class CC5J0P():
 def __init__(self, pixmapObj, picPath, VVzgHY=None):
  from enigma import ePicLoad
  from Components.AVSwitch import AVSwitch
  self.picLoad  = ePicLoad()
  self.scale   = AVSwitch().getFramebufferScale()
  self.picload_conn = None
  self.pixmapObj  = pixmapObj
  self.picPath  = picPath
  self.VVzgHY  = VVzgHY or "#2200002a"
 def VV4kcy(self):
  if self.pixmapObj and self.picPath and fileExists(self.picPath):
   try:
    try:
     self.picload_conn = self.picLoad.PictureData.connect(self.VV1Rb3)
    except:
     self.picLoad.PictureData.get().append(self.VV1Rb3)
    size = self.pixmapObj.instance.size()
    self.picLoad.setPara([size.width(), size.height(), self.scale[0], self.scale[1], False, 1, self.VVzgHY])
    self.picLoad.startDecode(self.picPath)
    return True
   except:
    pass
  return False
 def VV1Rb3(self, pInfo=""):
  if self.picLoad and pInfo:
   ptr = self.picLoad.getData()
   if ptr != None:
    try:
     self.pixmapObj.instance.setPixmap(ptr)
    except:
     pass
 def VVMxHB(self):
  del self.picLoad
  self.picLoad = None
  self.picload_conn = None
 @staticmethod
 def VVDKxb(pixmapObj, path, VVzgHY=None):
  cl = CC5J0P(pixmapObj, path, VVzgHY)
  ok = cl.VV4kcy()
  if ok: return cl
  else : return None
class CCo6hs(Screen):
 def __init__(self, session, VVbLQv, title="", showGrnMsg="", fileList=None, curIndex=0, fakePath=None, cbFnc=None):
  scrW, scrH = FFwz8B()
  w = 1700
  h = int(min(w * scrH / scrW + 51, 1040))
  self.skin, self.skinParam = FFRBRO(VVsieY, w, h, 30, 0, 0, "#22000060", "#2200002a", 30, topRightBtns=3)
  self.session  = session
  self.Title   = title
  self["myPic"]  = Pixmap()
  self.VVbLQv = VVbLQv
  self.showGrnMsg  = showGrnMsg
  self.fileList  = fileList
  self.curIndex  = curIndex
  self.fakePath  = fakePath
  self.cbFnc   = cbFnc
  self.picViewer  = None
  FFmmH7(self)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.close    ,
   "red" : self.close    ,
   "cancel": self.close    ,
   "info" : self.VVSppW  ,
   "up" : BF(self.VVq71U, -1),
   "down" : BF(self.VVq71U,  1),
   "left" : BF(self.VVq71U, -1),
   "right" : BF(self.VVq71U,  1)
  }, -1)
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFj9eW(self)
  self.VVjGbj()
  self.picViewer = CC5J0P.VVDKxb(self["myPic"], self.VVbLQv)
  if self.picViewer:
   if self.showGrnMsg:
    FF5uKN(self, self.showGrnMsg, 1000, isGrn=True)
  else:
   FFw5OO(self, "Cannot view picture file:\n\n%s" % self.VVbLQv)
   self.close()
 def onExit(self):
  if self.picViewer: self.picViewer.VVMxHB()
  if self.cbFnc  : self.cbFnc(self.VVbLQv)
 def VVq71U(self, direc):
  if self.fileList:
   oldNdx = self.curIndex
   self.curIndex += direc
   if direc == -1 and self.curIndex < 0      : self.curIndex = len(self.fileList) - 1
   if direc ==  1 and self.curIndex > len(self.fileList) - 1 : self.curIndex = 0
   if not oldNdx == self.curIndex:
    fName = self.fileList[self.curIndex]
    self.VVbLQv = FF1vNj(os.path.dirname(self.VVbLQv)) + fName
    self.picViewer.picPath = self.VVbLQv
    self.picViewer.VV4kcy()
    self.VVjGbj()
 def VVSppW(self):
  txt = "%s:\n  %s" % (FFGB9z("Path", VVUVAI), self.fakePath or self.VVbLQv)
  size, sizeTxt, resTxt, form, mode = CCMSfE.VVhox0(self.VVbLQv)
  if any((size, sizeTxt, resTxt, form, mode)):
   txt += "\n\n%s:\n" % FFGB9z("Properties", VVUVAI)
   if sizeTxt: txt += "  File Size\t: %s\n" % sizeTxt
   if resTxt : txt += "  Dimensions\t: %s\n" % resTxt
   if form   : txt += "  Format\t: %s\n"  % form
   if mode   : txt += "  Mode\t: %s\n"   % mode
  FF90Bc(self, txt, title="File Information")
 def VVjGbj(self):
  if self.fileList: title = "%d/%d : %s" % (self.curIndex + 1, len(self.fileList), self.fileList[self.curIndex])
  elif self.Title : title = self.Title
  else   : title = os.path.basename(self.VVbLQv)
  self["myTitle"].setText("  %s  " % title)
 @staticmethod
 def VVhaNU(SELF, VVbLQv, **kwargs):
  SELF.session.open(CCo6hs, VVbLQv, **kwargs)
class CChDqL(Screen):
 def __init__(self, session, mviFile=None):
  self.skin, self.skinParam = FFRBRO(VVkWtE, 400, 55, 30, 0, 0, "#22004455", "#00ff0000", 30)
  self.session  = session
  self.mviFile  = mviFile
  FFmmH7(self, "Click Cancel to exit", addCloser=True)
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.onExit)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  self.curServ = self.session.nav.getCurrentlyPlayingServiceOrGroup()
  self.session.nav.stopService()
  if not FFuB0V("showiframe %s" % self.mviFile):
   self.close(-1)
 def onExit(self):
  self.session.nav.playService(self.curServ, checkParentalControl=False, forceRestart=False)
 @staticmethod
 def VVY3TZ(SELF, mviFile):
  SELF.session.openWithCallback(BF(CChDqL.VVf3KY, SELF), CChDqL, mviFile)
 @staticmethod
 def VVf3KY(SELF, reason=None):
  if reason == -1: FFw5OO(SELF, "Error while viewing mvi file.", title="MVI Viewer")
class CCcHsQ(Screen, ConfigListScreen):
 VVMWyx = "ajpanel_update_url"
 def __init__(self, session):
  self.skin, self.skinParam = FFRBRO(VVTnM0, 1400, 1050, 50, 15, 15, "#11201010", "#11101010", 27, barHeight=40, topRightBtns=1)
  self.session  = session
  self.Title   = "%s Settings" % PLUGIN_NAME
  FFmmH7(self, title=self.Title)
  FFR9Qm(self["keyGreen"], "Save")
  lst = []
  lst.append(getConfigListEntry("Show in Main Menu"           , CFG.showInMainMenu   ))
  lst.append(getConfigListEntry("Show in Extensions Menu"          , CFG.showInExtensionMenu  ))
  lst.append(getConfigListEntry("Show in Channel List Context Menu"       , CFG.showInChannelListMenu  ))
  lst.append(getConfigListEntry("Show in Events Info Menu"         , CFG.EventsInfoMenu   ))
  lst.append(getConfigListEntry("Input Type"             , CFG.keyboard     ))
  lst.append(getConfigListEntry("Exit-Button Action (in File Manager and FTP)"    , CFG.FileManagerExit   ))
  lst.append(getConfigListEntry("Player Bar Hotkey"           , CFG.hotkey_signal    ))
  lst.append(getConfigListEntry("Screenshot"             , CFG.screenshotFType   ))
  lst.append(getConfigListEntry("Subtitle Files Encoding Priority"       , CFG.subtDefaultEnc   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Default IPTV Reference Type (defines the player)"   , CFG.iptvAddToBouquetRefType ))
  lst.append(getConfigListEntry("Auto Reset Frozen Live Channels (player dependent)"   , CFG.autoResetFrozenIptvChan ))
  lst.append(getConfigListEntry("Skip Adults Channels (from IPTV Server)"      , CFG.hideIptvServerAdultWords ))
  lst.append(getConfigListEntry("Remove IPTV Channel Name Prefix (|EN| , |AR|Drama|)"   , CFG.hideIptvServerChannPrefix ))
  lst.append(getConfigListEntry("Portal Servers Connection Timeout (seconds)"     , CFG.portalConnTimeout   ))
  lst.append(getConfigListEntry("IPTV Hosts Files Path (Playlist, Portal, M3U)"    , CFG.iptvHostsMode    ))
  lst.append(getConfigListEntry("Local Movies and IPTV Download Path"       , CFG.MovieDownloadPath   ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("PIcons Path"             , CFG.PIconsPath    ))
  lst.append(getConfigListEntry(SEP *2              ,         ))
  lst.append(getConfigListEntry("Backup/Restore Path"           , CFG.backupPath    ))
  lst.append(getConfigListEntry("Created Package Files (IPK/DEB/etc.) + Package Projects"  , CFG.packageOutputPath   ))
  lst.append(getConfigListEntry("Downloaded Packages (from feeds)"       , CFG.downloadedPackagesPath ))
  lst.append(getConfigListEntry("Exported Tables"            , CFG.exportedTablesPath  ))
  lst.append(getConfigListEntry("Exported PIcons/Screenshots/Pictures"      , CFG.exportedPIconsPath  ))
  ConfigListScreen.__init__(self, lst, session)
  self.VVu131()
  self.onShown.append(self.VV0wap)
 def VVu131(self):
  kList = {
    "ok" : self.VVxCTS   ,
    "green" : self.VVAEJE ,
    "menu" : self.VV3p6L ,
    "cancel": self.VVunoC ,
    }
  kLeft = kRight = None
  try:
   from Components.config import ConfigSubList, KEY_LEFT as kLeft, KEY_RIGHT as kRight
  except:
   try:
    from Components.config import ConfigSubList, ACTIONKEY_LEFT as kLeft, ACTIONKEY_RIGHT as kRight
   except:
    pass
  if not (kLeft == kRight == None):
   kList["left"] = BF(self["config"].handleKey, kLeft)
   kList["right"] = BF(self["config"].handleKey, kRight)
   try:
    kList["chanUp"]  = self["config"].pageUp
    kList["chanDown"] = self["config"].pageDown
   except:
    try:
     kList["chanUp"]  = BF(self["config"].VVOgnU, 0)
     kList["chanDown"] = BF(self["config"].VVOgnU, len(self["config"].list) - 1)
    except:
     pass
   self["config_actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
  else:
   self["actions"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"], kList, -1)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFj9eW(self)
  FFplRG(self["config"])
  FFR3zK(self, self["config"])
  FFHLqT(self)
  self["config"].onSelectionChanged.append(self.VVEC7p)
  FFWN9Z(self["keyRed"], "#11000000")
  self["keyRed"].show()
  self.VVEC7p()
 def VVEC7p(self):
  cfg = self["config"].getCurrent()[1]
  if   isinstance(cfg, ConfigDirectory): txt = "Change Path"
  else         : txt = "Show Choices"
  self["keyRed"].setText("OK = %s" % txt)
 def VVxCTS(self):
  title, item = self["config"].getCurrent()
  if item:
   if   item == CFG.iptvHostsMode   : self.VVqKno()
   elif item == CFG.MovieDownloadPath   : self.VVR8jC(item, self["config"].getCurrent()[0])
   elif item == CFG.subtDefaultEnc   : self.VVaGjA()
   elif isinstance(item, ConfigDirectory) : self.VVjIha(item)
   else         : CCcHsQ.VVsrg7(self, item, title)
 @staticmethod
 def VVsrg7(SELF, confItem, title, lst=None, cbFnc=None, isSave=False):
  if not lst:
   if   isinstance(confItem, ConfigYesNo)  : lst = [(True, "ON"), (False, "OFF")]
   elif isinstance(confItem, ConfigSelection) : lst = confItem.choices.choices
   else          : return
  curNdx = defNdx = -1
  VVZJ87 = []
  for ndx, item in enumerate(lst):
   if len(item) == 1:
    val, txt = ("dum",SEP)
   else:
    val, txt = item
    if   val == confItem.value : curNdx, txt = ndx, VVkqaK + txt
    elif val == confItem.default: defNdx, txt = ndx, VVVCGb + txt
   VVZJ87.append((txt, val))
  if defNdx == -1: defNdx = curNdx
  VV2YYF  = ("Current", BF(CCcHsQ.VV4sYT, curNdx))
  VV3ba7 = ("Default", BF(CCcHsQ.VV4sYT, defNdx))
  VV4EHV = FFYySC(SELF, BF(CCcHsQ.VV2H8l, confItem, cbFnc, isSave), VVZJ87=VVZJ87, width=1200, VV3ba7=VV3ba7, VV2YYF=VV2YYF, title=title, VVDlGi="#33221111", VVaSSM="#33110011")
  VV4EHV.VV6zBC(curNdx)
 @staticmethod
 def VV2H8l(confItem, cbFnc, isSave, item=None):
  if not item is None:
   confItem.setValue(item)
   if isSave: FFdEZ4(confItem, item)
   if cbFnc: cbFnc()
 @staticmethod
 def VV4sYT(ndx, VVbBRSObj, item):
  VVbBRSObj.VV6zBC(ndx)
 @staticmethod
 def VVGSZb(confItem, lst):
  for ndx, item in enumerate(lst):
   if item[0] == confItem.value:
    return ndx
  return -1
 def VVR8jC(self, item, title):
  tot = CCrhIe.VVGiT5()
  if tot : FFw5OO(self, "Cannot change while downloading.", title=title)
  else : self.VVjIha(item)
 def VVaGjA(self):
  curEnc = CFG.subtDefaultEnc.getValue()
  lst = CCqdtK.VV5WsH(self, "", curEnc)
  if lst:
   VV3ba7 = ("Default", self.VVSWNh)
   VV2YYF  = ("Current", self.VVnDGS)
   VV4EHV = FFYySC(self, self.VVHr2v, title="Select Priority Encoding", VVZJ87=lst, width=1000, height=1000, VV2YYF=VV2YYF, VV3ba7=VV3ba7, VVDlGi="#22220000", VVaSSM="#22220000", VV18hv=True)
   VV4EHV.VVJ8Ll(curEnc)
 def VVHr2v(self, item=None):
  if item:
   txt, enc, ndx = item
   CFG.subtDefaultEnc.setValue(enc)
 def VVSWNh(self, VV4EHV, item): VV4EHV.VVJ8Ll(VVhRht)
 def VVnDGS(self, VV4EHV, item): VV4EHV.VVJ8Ll(CFG.subtDefaultEnc.getValue())
 def VVqKno(self):
  VVZJ87 = []
  VVZJ87.append(("Auto Find" , "auto"))
  VVZJ87.append(("Custom Path" , "cust"))
  FFYySC(self, self.VVtyOl, VVZJ87=VVZJ87, title="IPTV Hosts Files Path")
 def VVtyOl(self, item=None):
  if item:
   if item == "auto":
    CFG.iptvHostsMode.setValue(VVqj4V)
   elif item == "cust":
    VVX3wb = self.VVDUW7()
    if VVX3wb : self.VVCogB(VVX3wb)
    else  : self.session.openWithCallback(self.VVe6HD, BF(CCCXvS, mode=CCCXvS.VVutD6, VVMbDq="/"))
 def VVCogB(self, VVX3wb):
  VV0xpR = self.VVdDuQ
  VVZ224 = ("Remove"  , self.VVubEM , [])
  VVIrDY = ("Add "  , self.VVK8Xf, [])
  header   = ("Directory" , "Remarks" )
  widths   = (80   , 20  )
  VVFvCJ  = (LEFT   , LEFT  )
  FF1Dpj(self, None, title="IPTV Hosts Search Paths", header=header, VVarfR=VVX3wb, width=1200, height=700, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=26, VV0xpR=VV0xpR, VVZ224=VVZ224, VVIrDY=VVIrDY
    , VVDlGi="#22220000", VVaSSM="#22110000", VVzgHY="#22110011", VVkUYa="#11223025", VVivoO="#0a333333", VVdjpa="#11400040")
 def VVdDuQ(self, VVxBfP):
  if CFG.iptvHostsDirs.getValue():
   CFG.iptvHostsMode.setValue(VVT2YZ)
  VVxBfP.cancel()
 def VVe6HD(self, path):
  if path:
   FFdEZ4(CFG.iptvHostsDirs, FF1vNj(path.strip()))
   VVX3wb = self.VVDUW7()
   if VVX3wb : self.VVCogB(VVX3wb)
   else  : FF5uKN(self, "Cannot add dir", 1500)
 def VVSXRg(self):
  lst = CFG.iptvHostsDirs.getValue().split(",")
  lst = list(set(list(map(str.strip, lst))))
  if len(lst) == 0 or len(lst[0]) == 0 or lst[0] == VVqj4V:
   return []
  return lst
 def VVDUW7(self):
  lst = self.VVSXRg()
  if lst:
   VVX3wb = []
   for Dir in lst:
    VVX3wb.append((Dir, "#f#0000ff00#Dir exists" if pathExists(Dir) else "#f#00ffa000#Not found"))
   VVX3wb.sort(key=lambda x: x[0].lower())
   return VVX3wb
  else:
   return []
 def VVK8Xf(self, VVxBfP, title, txt, colList):
  sDir = parent = os.path.abspath(os.path.join(colList[0], os.pardir))
  self.session.openWithCallback(BF(self.VVsd6j, VVxBfP)
         , BF(CCCXvS, mode=CCCXvS.VVutD6, VVMbDq=sDir))
 def VVsd6j(self, VVxBfP, path):
  if path:
   path = FF1vNj(path.strip())
   if self.VV72EJ(VVxBfP, path):
    FF5uKN(VVxBfP, "Already added", 1500)
   else:
    lst = self.VVSXRg()
    lst.append(path)
    FFdEZ4(CFG.iptvHostsDirs, ",".join(lst))
    VVX3wb = self.VVDUW7()
    VVxBfP.VVcckS(VVX3wb, tableRefreshCB=BF(self.VVwqFD, path))
 def VVwqFD(self, path, VVxBfP, title, txt, colList):
  self.VV72EJ(VVxBfP, path)
 def VV72EJ(self, VVxBfP, path):
  for ndx, row in enumerate(VVxBfP.VVlHja()):
   if row[0].strip() == path.strip():
    VVxBfP.VVYNxS(ndx)
    return True
  return False
 def VVubEM(self, VVxBfP, title, txt, colList):
  path = colList[0]
  FFNKVM(self, BF(self.VVRora, VVxBfP), "Remove this path from list?\n\n%s" % path, title="Remove path from list")
 def VVRora(self, VVxBfP):
  row = VVxBfP.VVc6YJ()
  path, rem = row[0], row[1]
  VVX3wb = []
  lst = []
  for ndx, row in enumerate(VVxBfP.VVlHja()):
   tPath, tRem = row[0].strip(), row[1].strip()
   if not path == tPath:
    lst.append(tPath)
    VVX3wb.append((tPath, tRem))
  if len(VVX3wb) > 0:
   FFdEZ4(CFG.iptvHostsDirs, ",".join(lst))
   VVxBfP.VVcckS(VVX3wb)
   FF5uKN(VVxBfP, "Deleted", 1500)
  else:
   FFdEZ4(CFG.iptvHostsMode, VVqj4V)
   FFdEZ4(CFG.iptvHostsDirs, "")
   VVxBfP.cancel()
   FFFANg(BF(FF5uKN, self, "Changed to Auto-Find", 1500))
 def VVjIha(self, configObj):
  sDir = configObj.getValue()
  self.session.openWithCallback(BF(self.VVJhaf, configObj)
         , BF(CCCXvS, mode=CCCXvS.VVutD6, VVMbDq=sDir))
 def VVJhaf(self, configObj, path):
  if len(path) > 0:
   configObj.setValue(path)
 def VVunoC(self):
  for x in self["config"].list:
   try:
    if x[1].isChanged():
     FFNKVM(self, self.VVAEJE, "Save Changes ?", callBack_No=self.cancel, title=self.Title)
     break
   except:
    pass
  else:
   self.cancel()
 def VVAEJE(self):
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVZBdN()
  self.close()
 def cancel(self):
  for x in self["config"].list:
   try:
    x[1].cancel()
   except:
    pass
  self.close()
 def VV3p6L(self):
  VVZJ87 = []
  txt = "Use Backup Path for Package/Download/Tables/PIcons"
  if not CFG.backupPath.isChanged() : VVZJ87.append((txt    , "VVZS50"   ))
  else        : VVZJ87.append((txt    ,       ))
  VVZJ87.append(("Change Text Color Scheme (fix Transparent Text)"  , "changeColorScheme" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Reset %s Settings" % PLUGIN_NAME      , "VVLRNo"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Backup %s Settings" % PLUGIN_NAME      , "VVKliN"  ))
  VVZJ87.append(("Restore %s Settings" % PLUGIN_NAME     , "VVTLDN"  ))
  if fileExists(VVNemM + CCcHsQ.VVMWyx):
   VVZJ87.append(VVoqHH)
   if CFG.checkForUpdateAtStartup.getValue() : txt1, txt2 = "Disable", "disableChkUpdate"
   else          : txt1, txt2 = "Enable" , "enableChkUpdate"
   VVZJ87.append(('%s Checking for Update' % txt1     , txt2     ))
   VVZJ87.append(("Reinstall %s" % PLUGIN_NAME      , "VVEfmR"  ))
   VVZJ87.append(("Update %s" % PLUGIN_NAME      , "VV6YwV"   ))
  FFYySC(self, self.VVDNtK, VVZJ87=VVZJ87, title="Config. Options")
 def VVDNtK(self, item=None):
  if item:
   if   item == "VVZS50"  : FFNKVM(self, self.VVZS50 , "Use Backup directory in all other paths (and save) ?")
   elif item == "changeColorScheme": self.session.open(CCspY4)
   elif item == "VVLRNo"  : FFNKVM(self, BF(self.VVLRNo, True), "Clear all settings (including File Manager bookmarks) ?")
   elif item == "VVKliN" : self.VVKliN()
   elif item == "VVTLDN" : FFJsIX(self, self.VVTLDN, title="Searching for Settings ...")
   elif item == "enableChkUpdate" : FFdEZ4(CFG.checkForUpdateAtStartup, True)
   elif item == "disableChkUpdate" : FFdEZ4(CFG.checkForUpdateAtStartup, False)
   elif item == "VVEfmR" : FFJsIX(self, BF(self.VVxl6y, True ), "Checking Server ...")
   elif item == "VV6YwV"  : FFJsIX(self, BF(self.VVxl6y, False), "Checking Server ...")
 def VVKliN(self):
  path = "%sajpanel_settings_%s" % (VVNemM, FFUD38())
  FFuB0V("grep .%s. %ssettings > %s" % (PLUGIN_NAME, VVNwTu, path))
  FF15cM(self, "Saved to file:\n\n%s" % path, title="Export %s Settings" % PLUGIN_NAME)
 def VVTLDN(self):
  title = "Import %s Settings" % PLUGIN_NAME
  name  = "ajpanel_settings_"
  files = FFnAC3("find / %s -iname '%s*' | grep %s" % (FFEZzf(1), name, name))
  if files:
   err = CCCXvS.VVgw5W(files)
   if err:
    FFNKVM(self, BF(self.VV7BRU, title), "No valid settings files found !\n\nLocate Manually ?", title=title)
   else:
    files = sorted(files, key=lambda t: -os.stat(t).st_mtime)
    VVZJ87 = []
    for line in files:
     VVZJ87.append((line, line))
    FFYySC(self, BF(self.VVioTD, title), title=title, VVZJ87=VVZJ87, width=1200, VVAL4K="")
  else:
   FFw5OO(self, "No settings files found !", title=title)
 def VV7BRU(self, title, path=None):
  sDir = "/"
  for path in (VVNemM, "/media/usb/", "/media/hdd/", "/media/"):
   if pathExists(path):
    sDir = path
    break
  self.session.openWithCallback(BF(self.VVioTD, title), BF(CCCXvS, patternMode="ajpSet", VVMbDq=sDir))
 def VVioTD(self, title, path=None):
  if path:
   if pathExists(path):
    lines  = FFZQjt(path)
    self.VVLRNo()
    for line in lines:
     name, _, val = line.partition("=")
     try:
      confItem = eval(name)
      if confItem is not None:
       if   isinstance(confItem, ConfigInteger)  : val = int(val)
       elif isinstance(confItem, ConfigSelectionNumber): val = int(val)
       elif isinstance(confItem, ConfigYesNo)   : val = { "true": True, "false": False }.get(val.lower())
       if not val is None:
        confItem.setValue(val)
        confItem.save()
     except:
      pass
    self.VVZBdN()
    FFDEHe()
    FF5uKN(self, "Apllied", 1500, isGrn=True)
   else:
    FFZoTn(self, path, title=title)
 def VVZS50(self):
  newPath = FF1vNj(VVNemM)
  CFG.packageOutputPath.setValue(newPath)
  CFG.downloadedPackagesPath.setValue(newPath)
  CFG.exportedTablesPath.setValue(newPath)
  CFG.exportedPIconsPath.setValue(newPath)
  CFG.packageOutputPath.save()
  CFG.downloadedPackagesPath.save()
  CFG.exportedTablesPath.save()
  CFG.exportedPIconsPath.save()
  self.VVZBdN()
 @staticmethod
 def VVorgX():
  backUpPath = "/media/usb/"
  if pathExists(backUpPath):
   return backUpPath
  else:
   return "/"
 def VVLRNo(self, exit=False):
  for (key, cfg) in CFG.content.items.items():
   cfg.setValue(cfg.default)
  for x in self["config"].list:
   try:
    x[1].save()
   except:
    pass
  self.VVZBdN()
  if exit:
   self.close()
 def VVZBdN(self):
  configfile.save()
  global VVNemM
  VVNemM = CFG.backupPath.getValue()
  FFxCEh()
 def VVxl6y(self, force):
  pre = "Reinstall" if force else "Update"
  title = "%s %s (from server)" % (pre, PLUGIN_NAME)
  curVer, webVer, url, isHigher, err = CCcHsQ.VVS4em()
  if   err    : FFw5OO(self, err, title)
  elif isHigher or force : FFNKVM(self, BF(FFJsIX, self, BF(self.VVqEfP, webVer, url, title, force)), "%s v%s and Restart ?" % ("Reinstall" if force else "Upgrade to", webVer), title=title)
  else     : FF15cM(self, FFGB9z("No update required.", VVVjNM) + "\n\nCurrent Version = v%s\n\nWeb Version = v%s" % (curVer, webVer), title)
 def VVqEfP(self, webVer, url, title, force):
  fName = "enigma2-plugin-extensions-ajpanel_v%s_all.%s" % (webVer, "deb" if FFX0mI() == "dpkg" else "ipk")
  path, err = FFtKyC(url + fName, fName, timeout=2)
  if path:
   if force: cmd = FFETOG(VVDaFy, path)
   else : cmd = FFETOG(VV57oW, path)
   if cmd:
    cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'; rm -rf '%s'" % (cmd, path)
    FF1Q61(self, cmd, title=title)
   else:
    FFgq4o(self, title=title)
  else:
   FFw5OO(self, err, title=title)
 @staticmethod
 def VVS4em():
  span = iSearch(r"v*(\d.\d.\d)", VVLBtR, IGNORECASE)
  if span : curVer = span.group(1)
  else : return "", "", "", False, "Incorrect local version format !"
  path = VVNemM + CCcHsQ.VVMWyx
  if fileExists(path):
   span = iSearch(r"(http.+)", FFQ5la(path), IGNORECASE)
   if span : url = FF1vNj(span.group(1))
   else : return curVer, "", "", False, err
  else:
   return curVer, "", "", False, "Update File not found:\n\n%s" % path
  path, err = FFtKyC(url + "version", "ajp_tmp.ver", timeout=2)
  if err:
   return curVer, "", url, False, err
  if fileExists(path):
   txt  = FFQ5la(path).strip().replace(" ", "")
   FFzyFM(path)
   span = iSearch(r"v*(\d.\d.\d)", txt.partition("=")[2], IGNORECASE)
   if span:
    webVer = span.group(1)
    webTup = tuple(map(int, (webVer.split("."))))
    curTup = tuple(map(int, (curVer.split("."))))
    return curVer, webVer, url, webTup > curTup, ""
   else:
    return curVer, "", url, False, "Incorrect version format (from server) !"
  else:
   return curVer, "", url, False, "Cannot download Version File !"
class CCspY4(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFRBRO(VVQNPR, 1200, 620, 50, 20, 0, "#22002020", "#22001122", 30)
  self.cursorPos = VV5yC1
  self.Title  = "Select Color Scheme (for areas with mixed-color text)"
  self.session = session
  FFmmH7(self, title=self.Title)
  sp = "    "
  self["myColorF"] = Label()
  for i in range(4):
   txt = "\n"
   txt += self.VV0jge("\c00FFFFFF", i) + sp + "WHITE\n"
   txt += self.VV0jge("\c00888888", i) + sp + "GREY\n"
   txt += self.VV0jge("\c005A5A5A", i) + sp + "DARK GREY\n"
   txt += self.VV0jge("\c00FF0000", i) + sp + "RED\n"
   txt += self.VV0jge("\c00FF5000", i) + sp + "ORANGE\n"
   txt += self.VV0jge("\c00FFFF00", i) + sp + "YELLOW\n"
   txt += self.VV0jge("\c00FFFFAA", i) + sp + "B. YELLOW\n"
   txt += self.VV0jge("\c0000FF00", i) + sp + "GREEN\n"
   txt += self.VV0jge("\c000066FF", i) + sp + "BLUE\n"
   txt += self.VV0jge("\c0000FFFF", i) + sp + "CYAN\n"
   txt += self.VV0jge("\c00FA55E7", i) + sp + "PURPLE\n"
   txt += self.VV0jge("\c00FF8F5F", i) + sp + "PEACH\n"
   self["myColor%s" % i] = Label(txt)
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVxCTS ,
   "green" : self.VVxCTS ,
   "left" : self.VVn01Q ,
   "right" : self.VVbYcO ,
   "cancel": self.close
  }, -1)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  self.VVwajY()
 def VVxCTS(self):
  if self.cursorPos == 0 : txt = "No Colors"
  else     : txt = "Color Scheme-%d" % self.cursorPos
  FFNKVM(self, self.VV0uyB, "Change to : %s" % txt, title=self.Title)
 def VV0uyB(self):
  FFdEZ4(CFG.mixedColorScheme, self.cursorPos)
  global VV5yC1
  VV5yC1 = self.cursorPos
  self.VVbqDw()
  self.close()
 def VVn01Q(self):
  self.cursorPos -= 1
  if self.cursorPos < 0:
   self.cursorPos = 3
  self.VVwajY()
 def VVbYcO(self):
  self.cursorPos += 1
  if self.cursorPos > 3:
   self.cursorPos = 0
  self.VVwajY()
 def VVwajY(self):
  left = []
  for i in range(4):
   left.append(self["myColor%s" % i].getPosition()[0])
  left = left[self.cursorPos] - 4
  top = self["myColor0"].getPosition()[1] - 4
  self.cursorPos
  self["myColorF"].instance.move(ePoint(left, top))
 @staticmethod
 def VV0jge(color, mode):
  if   mode == 1 : return color
  elif mode == 2 : return color.replace("A", "9").replace("B", "9").replace("C", "9").replace("D", "9").replace("E", "9").replace("F", "9")
  elif mode == 3 : return color.replace("A", ":").replace("B", ";").replace("C", "<").replace("D", "=").replace("E", ">").replace("F", "?")
  else   : return ""
 @staticmethod
 def VV0CtV(color):
  if VVVCGb: return "\\" + color
  else    : return ""
 @staticmethod
 def VVbqDw():
  global VV7jS2, VVGb6D, VVGe5h, VVLbyB, VVsObI, VVMrXw, VVO6N6, VVD5sL, VVVjNM, VVkIQ9, VVVCGb, VVUVAI, VVkqaK, VVWOjU, VV21C5, VVqFea
  VVqFea   = CCspY4.VV0jge("\c00FFFFFF", VV5yC1)
  VVGb6D    = CCspY4.VV0jge("\c00888888", VV5yC1)
  VV7jS2  = CCspY4.VV0jge("\c005A5A5A", VV5yC1)
  VVD5sL    = CCspY4.VV0jge("\c00FF0000", VV5yC1)
  VVGe5h   = CCspY4.VV0jge("\c00FF5000", VV5yC1)
  VVLbyB   = CCspY4.VV0jge("\c00FFBB66", VV5yC1)
  VVVCGb   = CCspY4.VV0jge("\c00FFFF00", VV5yC1)
  VVUVAI = CCspY4.VV0jge("\c00FFFFAA", VV5yC1)
  VVVjNM   = CCspY4.VV0jge("\c0000FF00", VV5yC1)
  VVkIQ9  = CCspY4.VV0jge("\c00AAFFAA", VV5yC1)
  VVO6N6    = CCspY4.VV0jge("\c000066FF", VV5yC1)
  VVkqaK    = CCspY4.VV0jge("\c0000FFFF", VV5yC1)
  VVWOjU  = CCspY4.VV0jge("\c00AAFFFF", VV5yC1)  #
  VV21C5   = CCspY4.VV0jge("\c00FA55E7", VV5yC1)
  VVsObI    = CCspY4.VV0jge("\c00FF8F5F", VV5yC1)
  VVMrXw  = CCspY4.VV0jge("\c00FFC0C0", VV5yC1)
CCspY4.VVbqDw()
class CCjJUX(Screen):
 def __init__(self, session, path, VVFsmA):
  self.skin, self.skinParam = FFRBRO(VVq2lk, 1400, 850, 50, 30, 20, "#11001020", "#11001122", 26, barHeight=40)
  self.session    = session
  self.Path     = path
  self.VVyVeY   = path
  self.VVb58G   = ""
  self.VVekRX   = ""
  self.VVFsmA    = VVFsmA
  self.VVHDjS    = ""
  self.VVykmD  = ""
  self.VVTvh0    = False
  self.VV4Qg4  = False
  self.origPackageName  = ""
  self.postInstAcion   = 0
  self.VV35G5  = "enigma2-plugin-extensions-"
  self.VV8HcE  = "enigma2-plugin-systemplugins-"
  self.VVlddZ = "enigma2-"
  self.VVD8Fs  = 0
  self.VVkicv  = 1
  self.VVjq71  = 2
  if pathExists(self.Path + "DEBIAN") : self.VVTjtN = "DEBIAN"
  else        : self.VVTjtN = "CONTROL"
  self.controlPath = self.Path + self.VVTjtN
  self.controlFile = self.controlPath + "/control"
  self.preinstFile = self.controlPath + "/preinst"
  self.postinstFile = self.controlPath + "/postinst"
  self.prermFile  = self.controlPath + "/prerm"
  self.postrmFile  = self.controlPath + "/postrm"
  self.newControlPath = ""
  if self.VVFsmA:
   self.packageExt  = ".deb"
   self.VVzgHY  = "#11001010"
  else:
   self.packageExt  = ".ipk"
   self.VVzgHY  = "#11001020"
  FFmmH7(self, "Create Package (%s)" % self.packageExt, addLabel=True)
  FFR9Qm(self["keyRed"] , "Create")
  FFR9Qm(self["keyGreen"] , "Post Install")
  FFR9Qm(self["keyYellow"], "Installation Path")
  FFR9Qm(self["keyBlue"] , "Change Version")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "red"   : self.VVnzxn  ,
   "green"   : self.VVWBRT ,
   "yellow"  : self.VV7B56  ,
   "blue"   : self.VVtfti  ,
   "cancel"  : self.VVjlTA
  }, -1)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFHLqT(self)
  if self.VVzgHY:
   FFWN9Z(self["myBody"], self.VVzgHY)
   FFWN9Z(self["myLabel"], self.VVzgHY)
  self.VV5KWB(True)
  self.VVPIPu(True)
 def VVPIPu(self, isFirstTime=False):
  controlInfo, errTxt, package = self.VVa2K0()
  if isFirstTime:
   if   package.startswith(self.VV35G5) : self.VVyVeY = VVh8TB + self.VVHDjS + "/"
   elif package.startswith(self.VV8HcE) : self.VVyVeY = VVZk2h + self.VVHDjS + "/"
   else            : self.VVyVeY = self.Path
  if self.VVTvh0 : myColor = VVsObI
  else    : myColor = VVqFea
  txt  = ""
  txt += "Source Path\t: %s\n" % FFGB9z(self.Path  , myColor)
  txt += "Installation\t: %s\n" % FFGB9z(self.VVyVeY, VVVCGb)
  if self.VVekRX : txt += "Package File\t: %s\n" % FFGB9z(self.VVekRX, VVGb6D)
  elif errTxt   : txt += "Warning\t: %s\n"  % FFGB9z("Check Control File fields : %s" % errTxt, VVGe5h)
  if self["keyGreen"].getVisible():
   if   self.postInstAcion == 1: act = "Add commands to %s after installation." % FFGB9z("Restart GUI", VVsObI)
   elif self.postInstAcion == 2: act = "Add commands to %s after installation." % FFGB9z("Reboot Device", VVsObI)
   else      : act = "No action."
   txt += "\n%s\t: %s\n" % (FFGB9z("Post Install", VVVjNM), act)
  if not errTxt and VVGe5h in controlInfo:
   txt += "Warning\t: %s\n" % FFGB9z("Errors in control file may affect the result package.", VVGe5h)
  txt += "\nControl File\t: %s\n" % FFGB9z(self.controlFile, VVGb6D)
  txt += controlInfo.replace(":", "\t:")
  self["myLabel"].setText(txt)
 def VVWBRT(self):
  if self["keyGreen"].getVisible():
   VVZJ87 = []
   VVZJ87.append(("No Action"    , "noAction"  ))
   VVZJ87.append(("Restart GUI"    , "VVWnWi"  ))
   VVZJ87.append(("Reboot Device"   , "rebootDev"  ))
   FFYySC(self, self.VVMUFT, title="Package Installation Option (after completing installation)", VVZJ87=VVZJ87)
 def VVMUFT(self, item=None):
  if item is not None:
   if   item == "noAction"   : self.postInstAcion = 0
   elif item == "VVWnWi"  : self.postInstAcion = 1
   elif item == "rebootDev"  : self.postInstAcion = 2
   self.VV5KWB(False)
   self.VVPIPu()
 def VV7B56(self):
  rootPath = FFGB9z("/%s/" % self.VVHDjS, VVUVAI)
  VVZJ87 = []
  VVZJ87.append(("Current Path"        , "toCurrent"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Extension Path"       , "toExtensions" ))
  VVZJ87.append(("System Plugins Path"      , "toSystemPlugins" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Package Name in Root : %s" % rootPath  , "toRootPath"  ))
  VVZJ87.append(('Root "/" (Multiple Directories Package)' , "toRoot"   ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Pick Path with File Manager ..."   , "toOthers"  ))
  FFYySC(self, self.VVig1l, title="Installation Path", VVZJ87=VVZJ87)
 def VVig1l(self, item=None):
  if item is not None:
   if   item == "toCurrent"  : self.VV8A0g(FF0y7s(self.Path, True))
   elif item == "toExtensions"  : self.VV8A0g(VVh8TB)
   elif item == "toSystemPlugins" : self.VV8A0g(VVZk2h)
   elif item == "toRootPath"  : self.VV8A0g("/")
   elif item == "toRoot"   : self.VV8A0g("/", False)
   elif item == "toOthers"   : self.session.openWithCallback(self.VVY43j, BF(CCCXvS, mode=CCCXvS.VVutD6, VVMbDq=VVNemM))
 def VVY43j(self, path):
  if len(path) > 0:
   self.VV8A0g(path)
 def VV8A0g(self, parent, withPackageName=True):
  if withPackageName : self.VVyVeY = parent + self.VVHDjS + "/"
  else    : self.VVyVeY = "/"
  mode = self.VVcwqy()
  FFuB0V("sed -i '/Package/c\Package: %s' %s" % (self.VVNLt2(mode), self.controlFile))
  self.VVPIPu()
 def VVtfti(self):
  if fileExists(self.controlFile):
   lines = FFZQjt(self.controlFile)
   version = ""
   for line in lines:
    if ":" in line:
     parts = line.split(":")
     key  = parts[0].strip()
     val  = parts[1].strip()
     if key == "Version":
      version = val
      break
   if version : FFaSvq(self, self.VVtwnk, title="Change Package Version", defaultText=version, message="Enter Version:")
   else  : FFw5OO(self, "Version not found or incorrectly set !")
  else:
   FFZoTn(self, self.controlFile)
 def VVtwnk(self, VVYwVo):
  if VVYwVo:
   version, color = self.VVQaSK(VVYwVo, False)
   if color == VVkqaK:
    FFuB0V("sed -i '/Version:/c\Version: %s' %s" % (VVYwVo, self.controlFile))
    self.VVPIPu()
   else:
    FFw5OO(self, "Incorrect Version Syntax !\n\nAllowed characters : letter, digits and _+-.~")
 def VVjlTA(self):
  if self.newControlPath:
   if self.VVTvh0:
    self.VViqCC()
   else:
    txt  = "Control Files were created in:\n%s\n\n" % FFGB9z(self.newControlPath, VVGb6D)
    txt += FFGB9z("Do you want to keep these files ?", VVVCGb)
    FFNKVM(self, self.close, txt, callBack_No=self.VViqCC, title="Create Package", VV4evd=True)
  else:
   self.close()
 def VViqCC(self):
  FFuB0V("rm -rf '%s'" % self.newControlPath)
  self.close()
 def VVNLt2(self, mode):
  prefix, name = "", ""
  package = self.origPackageName or self.VVykmD
  if package.startswith(self.VVlddZ):
   span = iSearch(r"(.+-)(.+)", package)
   if span:
    prefix, name = span.group(1).strip(), span.group(2)
  if not name:
   prefix, name = self.VVlddZ, package
  prefix = iSub(r"([^a-z0-9+-.]+)", r"-", prefix)
  name = iSub(r"([^a-z0-9+-.]+)", r"-", name)
  if   mode == self.VVkicv : prefix = self.VV35G5
  elif mode == self.VVjq71 : prefix = self.VV8HcE
  return (prefix + name).lower()
 def VVcwqy(self):
  if   self.VVyVeY.startswith(VVh8TB) : return self.VVkicv
  elif self.VVyVeY.startswith(VVZk2h) : return self.VVjq71
  else            : return self.VVD8Fs
 def VV5KWB(self, isFirstTime):
  self.VVHDjS   = FF65m2(self.Path)
  self.VVHDjS   = "_".join(self.VVHDjS.split())
  self.VVykmD = self.VVHDjS.lower()
  self.VVTvh0 = self.VVykmD == VV1aX3.lower()
  if self.VVTvh0 and self.VVykmD.endswith(VV1aX3.lower()):
   self.VVykmD += "el"
  if self.VVTvh0 : self.VVb58G = VVNemM
  else    : self.VVb58G = CFG.packageOutputPath.getValue()
  self.VVb58G = FF1vNj(self.VVb58G)
  if not pathExists(self.controlPath):
   FFuB0V("mkdir '%s'" % self.controlPath)
   self.newControlPath = self.controlPath
  else:
   self.newControlPath = ""
  mode = self.VVcwqy()
  if fileExists(self.controlFile):
   lines = FFZQjt(self.controlFile)
   for line in lines:
    if line.strip().startswith("Package") and line.count(":") == 1:
     self.origPackageName = line.split(":")[1].strip()
     break
  else:
   if self.VVTvh0 : version, descripton, maintainer = VVLBtR , PLUGIN_DESCRIPTION, "AMA-Jamry"
   else    : version, descripton, maintainer = "v1.0"   , self.VVHDjS , self.VVHDjS
   txt = ""
   txt += "Package: %s\n"  % self.VVNLt2(mode)
   txt += "Version: %s\n"  % version
   txt += "Description: %s\n" % descripton
   txt += "Maintainer: %s\n" % maintainer
   txt += "Architecture: all\n"
   txt += "Priority: optional\n"
   txt += "Section: base\n"
   txt += "License: none\n"
   txt += "OE: enigma2\n"
   txt += "Homepage: unknown\n"
   txt += "Depends: enigma2\n"
   txt += "Source: none\n"
   with open(self.controlFile, "w") as f:
    f.write(txt)
  if self.VVTvh0 : t = PLUGIN_NAME
  else    : t = self.VVHDjS
  self.VVOsP6(self.prermFile, "echo 'Removing package : %s ...'\n" % t)
  self.VVOsP6(self.postrmFile, "echo 'Package removed.'\n")
  if self.VVTvh0 : self.VVOsP6(self.preinstFile, "echo 'Installing %s (%s) ...'\n" % (PLUGIN_NAME, VVLBtR))
  else    : self.VVOsP6(self.preinstFile, "echo 'Installing Package : %s ...'\n" % self.VVHDjS)
  if isFirstTime and not mode == self.VVD8Fs:
   self.postInstAcion = 1
  txt = self.VV4KD4(self.postInstAcion)
  canChange = True
  self["keyGreen"].show()
  if fileExists(self.postinstFile):
   fText = FFQ5la(self.postinstFile).strip()
   if txt.strip() == fText:
    canChange = False
   else:
    for action in range(3):
     if fText.strip() == self.VV4KD4(action).strip():
      break
    else:
     canChange = False
     self["keyGreen"].hide()
  if canChange:
   with open(self.postinstFile, "w") as f:
    f.write(txt)
  FFuB0V("chmod 755 '%s' '%s' '%s' '%s' " % (self.preinstFile, self.postinstFile, self.prermFile, self.postrmFile))
 def VVOsP6(self, path, lines):
  if not fileExists(path):
   with open(path, "w") as f:
    f.write("#!/bin/bash\n")
    f.write(lines)
    f.write("exit 0\n")
 def VV4KD4(self, action):
  sep  = "echo '%s'\n" % SEP
  txt = "#!/bin/bash\n" + sep
  if action == 0:
   txt += "echo '--- FINISHED ---'\n"
   txt += sep
   txt += "echo 'You may need to Restart GUI.'\n"
  elif action == 1:
   txt += "echo 'RESTARTING GUI ...'\n"
   txt += sep
   txt += "if which systemctl; then sleep 2; systemctl restart enigma2; elif [ -r '/usr/lib/enigma2/python/EGAMI' ]; then sleep 2; killall -9 enigma2; else init 4; sleep 4; init 3; fi\n"
  elif action == 2:
   txt += "echo 'REBOOTING DEVICE ...'\n"
   txt += sep
   txt += "sleep 3; reboot\n"
  else:
   return ""
  txt += "exit 0\n"
  return txt
 def VVa2K0(self):
  txt = package = version = descr = arch = maint = ""
  if fileExists(self.controlFile):
   lines = FFZQjt(self.controlFile)
   descrFound  = False
   ignoreList  = []
   descrIndex  = -1
   isDescrValid = False
   for ndx, line in enumerate(lines):
    if line.strip().startswith("Description"):
     descrFound = True
     descrIndex = ndx
     descr  = line + "\n"
     ignoreList.append(ndx)
     if ":" in line:
      parts = line.split(":")
      key, val= parts[0].strip(), parts[1].strip()
      if key == "Description":
       isDescrValid = True
    elif descrFound and not ":" in line:
     if line.startswith(" .") and len(line) > 2 : line = FFGB9z(line, VVGe5h)
     elif not line.startswith(" ")    : line = FFGB9z(line, VVGe5h)
     else          : line = FFGB9z(line, VVkqaK)
     descr += line + "\n"
     ignoreList.append(ndx)
    elif descrFound and ":" in line:
     break
   if isDescrValid : color = VVkqaK
   else   : color = VVGe5h
   descr = FFGB9z(descr, color)
   for ndx, line in enumerate(lines):
    if ndx not in ignoreList:
     if line.strip() == "":
      line = "[ EMPTY LINES ARE NOT ALLOWED ]"
      color = VVGe5h
     elif line.startswith((" ", "\t")) : color = VVGe5h
     elif line.startswith("#")   : color = VVGb6D
     elif ":" in line:
      parts = line.split(":")
      key  = parts[0].strip()
      val  = parts[1].strip()
      if   key == "Package"  : package, color = self.VVQaSK(val, True)
      elif key == "Version"  : version, color = self.VVQaSK(val, False)
      elif key == "Maintainer" : maint  , color = val, VVkqaK
      elif key == "Architecture" : arch  , color = val, VVkqaK
      else:
       color = VVkqaK
      if not key == "OE" and not key.istitle():
       color = VVGe5h
     else:
      color = VVsObI
     txt += FFGB9z(line, color) + "\n"
    else:
     if ndx == descrIndex:
      txt += descr
  if package and version and arch and descr and maint:
   packageName   = "%s_%s_%s%s" % (package, version, arch, self.packageExt)
   packageName   = packageName.replace(" ", "")
   self.VVekRX = self.VVb58G + packageName
   self.VV4Qg4 = True
   errTxt = ""
  else:
   self.VVekRX  = ""
   self.VV4Qg4 = False
   err = []
   if not package : err.append("Package")
   if not descr : err.append("Description")
   if not version : err.append("Version")
   if not arch  : err.append("Architecture")
   if not maint : err.append("Maintainer")
   errTxt = " , ".join(err) + ")"
  return txt, errTxt, package
 def VVQaSK(self, val, isPackage):
  if   isPackage : pattern = r"^[a-z]+[a-z0-9+-_.]+$"
  else   : pattern = r"^[a-zA-Z0-9_+-.~]*$"
  if iMatch(pattern, val) and len(val) >= 2 : return val, VVkqaK
  else          : return val, VVGe5h
 def VVnzxn(self):
  if not self.VV4Qg4:
   FFw5OO(self, "Please fix Control File errors first.")
   return
  if self.VVFsmA: tarParam, tarExt = "-cJhf", ".tar.xz"
  else   : tarParam, tarExt = "-czhf", ".tar.gz"
  projDir   = "/tmp/_%s/" % PLUGIN_NAME
  parent   = FF0y7s(self.VVyVeY, True)
  dataFile  = projDir + "data"   + tarExt
  controlFile  = projDir + "control" + tarExt
  debianFile  = projDir + "debian-binary"
  dataTmpPath  = projDir + "DATA/"
  newPath   = dataTmpPath + parent[1:]
  symlink   = dataTmpPath + parent[1:] + self.VVHDjS
  symlinkTo  = FFAxSo(self.Path)
  dataDir   = self.VVyVeY.rstrip("/")
  removePorjDir = FFIV1X("rm -rf '%s'"  % projDir) + ";"
  cmd  = ""
  cmd += FFIV1X("rm -f '%s'" % self.VVekRX) + ";"
  cmd += removePorjDir
  cmd += "mkdir -p '%s';"  % newPath
  cmd += "ln -sf '%s' '%s';" % (symlinkTo, symlink)
  cmd += FFcMGy()
  if self.VVFsmA:
   cmd += 'if [ "$allOK" -eq "1" ]; then '
   cmd +=   FF09Tg("xz", "xz", "XZ")
   cmd += "fi;"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += " echo 'Creating Package ...';"
  tarExclude = "--exclude CONTROL --exclude DEBIAN --exclude __pycache__"
  if self.VVTvh0:
   tarExclude += " --exclude OBF --exclude *.pyo --exclude *.pyc"
  cmd += "cd '%s';"       % dataTmpPath
  if self.VVyVeY == "/":
   cmd += " tar -C '%s' %s %s '%s' ./;" % (self.Path, tarExclude, tarParam, dataFile)
  else:
   cmd += " tar %s %s '%s' '.%s';" % (tarExclude, tarParam, dataFile, dataDir)
  cmd += " cd '%s%s';"  % (self.Path, self.VVTjtN)
  cmd += " tar %s '%s' ./*;" % (tarParam, controlFile)
  cmd += " echo '2.0' > %s;" % debianFile
  checkCmd = " if [ ! -f '%s' ]; then allOK='0'; echo 'Cannot create %s'; fi;"
  cmd += checkCmd % (debianFile , "debian-binary")
  cmd += checkCmd % (controlFile , "control.tar")
  cmd += checkCmd % (dataFile  , "data.tar")
  cmd += ' if [ "$allOK" -eq "1" ]; then '
  cmd += "  cd '%s';"  % projDir
  cmd += "  ar -r '%s' %s %s %s;" % (self.VVekRX, debianFile, controlFile, dataFile)
  cmd += " fi;"
  myTarCmd = ""
  result  = "Package:"
  instPath = "Designed to be installed in:"
  failed  = "Process Failed."
  cmd += " if [ -f '%s' ]; then "   % self.VVekRX
  cmd += "  echo -e '\n%s\n%s' %s;" % (result  , self.VVekRX, FFXRSi(result  , VVVjNM))
  cmd +=    myTarCmd
  cmd += "  echo -e '\n%s\n%s' %s;" % (instPath, self.VVyVeY, FFXRSi(instPath, VVkqaK))
  cmd += " else"
  cmd += "  echo -e '\n%s' %s;" % (failed, FFXRSi(failed, VVGe5h))
  cmd += " fi;"
  cmd += "fi;"
  cmd += removePorjDir
  FF1Q61(self, cmd)
class CCSrvY():
 VVgr9Z  = "666"
 VViQzL   = "888"
 def __init__(self, SELF, waitMsgSELF, title, servRefListFnc, defBName="Bouquet1"):
  self.SELF     = SELF
  self.waitMsgSELF   = waitMsgSELF
  self.Title     = title
  self.servRefListFnc   = servRefListFnc
  self.defBName    = defBName
  self.VV4EHV   = None
  self.VVFAzu()
 def VVFAzu(self):
  VVZJ87 = CCSrvY.VVSrxf()
  if VVZJ87:
   VV3ba7 = ("Create New", self.VVugDG)
   self.VV4EHV = FFYySC(self.SELF, self.VV7I2X, VVZJ87=VVZJ87, title=self.Title, VV3ba7=VV3ba7, VV18hv=True, VVDlGi="#22222233", VVaSSM="#22222233")
  else:
   self.VVugDG()
 def VV7I2X(self, item):
  if item:
   bName, bRef, ndx = item
   self.VVCVAM(bName, bRef)
  else:
   CCSrvY.VVuCdO(self)
 def VVugDG(self, VVbBRSObj=None, item=None):
  FFaSvq(self.SELF, BF(self.VVGOA8), defaultText=self.defBName, title="Create New Bouquet", message="Enter Bouquet Name:")
 def VVGOA8(self, bName):
  if bName:
   bName = bName.strip()
   if bName:
    if self.VV4EHV:
     self.VV4EHV.cancel()
    self.VVCVAM(bName, "")
   else:
    FF5uKN(self.VV4EHV, "Incorrect Bouquet Name !", 2000)
    CCSrvY.VVuCdO(self)
 def VVCVAM(self, bName, bRef):
  FFJsIX(self.waitMsgSELF, BF(self.VVKXgW, bName, bRef), title="Adding Services ...")
 def VVKXgW(self, bName, bRef):
  CCSrvY.VV03W9(self.SELF, self.Title, bName, bRef, self.servRefListFnc())
 @staticmethod
 def VVuCdO(classObj):
  del classObj
 @staticmethod
 def VV03W9(SELF, title, bName, bRef, servRefLst, showRes=True):
  if not servRefLst:
   FFw5OO(SELF, "No services to add !", title=title)
   return
  tvBouquetFile = VVNwTu + "bouquets.tv"
  if not fileExists(tvBouquetFile):
   FFZoTn(SELF, tvBouquetFile, title=title)
   return
  if bRef:
   bFile = CCSrvY.VVArA6(bRef)
   bPath = VVNwTu + bFile
  else:
   fName = CC9X9s.VVRoT5(bName)
   bFile = "userbouquet.%s.tv" % fName
   bPath = VVNwTu + bFile
   num   = 0
   while fileExists(bPath):
    num += 1
    bFile = "userbouquet.%s_%d.tv" % (fName, num)
    bPath = VVNwTu + bFile
   with open(bPath, "w") as f:
    f.write("#NAME %s\n" % bName)
  FFA11O(bPath)
  with open(bPath, "a") as f:
   for chUrl in servRefLst:
    serv = eServiceReference(chUrl)
    chName = serv and serv.getName() or ""
    try:
     chName = chName.encode("UTF-8", "replace").decode()
    except:
     chName = iSub(r"([^\x00-\x7F]+)", r"?", chName)
    f.write("#SERVICE %s\n"  % chUrl)
    f.write("#DESCRIPTION %s\n" % chName)
  if not bRef and fileExists(bPath):
   FFA11O(tvBouquetFile)
   with open(tvBouquetFile, "a") as f:
    f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\n' % bFile)
  totPicons = 0
  piconPath = CCijoe.VV4boJ()
  for chUrl in servRefLst:
   span = iSearch(r"((?:[A-Fa-f0-9]+:){10})", chUrl.rstrip(":"))
   if span:
    serv = eServiceReference(chUrl)
    if serv:
     picon = piconPath + span.group(1).strip(":").replace(":", "_").upper() + ".png"
     fPath = serv.getPath()
     fNameNoExt = os.path.splitext(serv.getPath())[0]
     for ext in ("png", "jpg", "bmp", "gif", "jpe", "jpeg"):
      poster = "%s.%s" % (fNameNoExt, ext)
      if fileExists(poster):
       totPicons += 1
       FFuB0V("cp -f '%s' '%s'" % (poster, picon))
       FFuB0V(CCjQ0P.VV92Yh(picon))
       break
  FFAvBD()
  if showRes:
   txt  = "Bouquet Name\t\t: %s\n"  % bName
   txt += "Added Services\t\t: %d\n" % len(servRefLst)
   if totPicons:
    txt += "Added PIcons\t\t: %s" % totPicons
   FF90Bc(SELF, txt, title=title)
 @staticmethod
 def VVSrxf(mode=2, showTitle=True, prefix="", onlyIptv=False):
  VVZJ87 = []
  if mode in (0, 2): VVZJ87.extend(CCSrvY.VVTaJK(0, showTitle, prefix, onlyIptv))
  if mode in (1, 2): VVZJ87.extend(CCSrvY.VVTaJK(1, showTitle, prefix, onlyIptv))
  return VVZJ87
 @staticmethod
 def VVTaJK(mode, showTitle, prefix, onlyIptv):
  VVZJ87 = []
  lst = CCSrvY.VV4yAK(mode)
  if onlyIptv:
   lst = CCSrvY.VV1gPU(lst)
  if lst:
   if showTitle:
    VVZJ87.append(FFHf46("TV Bouquets" if mode == 0 else "Radio Bouquets"))
   if prefix:
    for item in lst : VVZJ87.append((item[0], prefix + item[0]))
   else:
    for item in lst : VVZJ87.append((item[0], item[1].toString()))
  return VVZJ87
 @staticmethod
 def VV1gPU(lst):
  fLst = CC9X9s.VV3Es2(onlyFileName=True)
  newLst = []
  if fLst:
   for item in lst:
    span = iSearch(r".+(userbouquet\..+\.(tv|radio))", item[1].toString())
    if span and span.group(1) in fLst:
     newLst.append(item)
  return newLst
 @staticmethod
 def VVcTqV():
  bLise = CCSrvY.VV4yAK(0)
  bLise.extend(CCSrvY.VV4yAK(1))
  return bLise
 @staticmethod
 def VV4yAK(mode=0):
  bList = []
  VVhMBa = InfoBar.instance
  VVsufg = VVhMBa and VVhMBa.servicelist
  if VVsufg:
   curMode = VVsufg.mode
   CCSrvY.VVaLXs(VVsufg, mode)
   bList.extend(VVsufg.getBouquetList() or [])
   CCSrvY.VVaLXs(VVsufg, curMode)
  return bList
 @staticmethod
 def VVaLXs(VVsufg, mode):
  if not mode == VVsufg.mode:
   if   mode == 0: VVsufg.setModeTv()
   elif mode == 1: VVsufg.setModeRadio()
 @staticmethod
 def VVArA6(bRef):
  span = iSearch(r'BOUQUET\s+"(.+)"\s+ORDER', bRef, IGNORECASE)
  if span : return span.group(1)
  else : ""
 @staticmethod
 def VVPlYj():
  try:
   fName = CCSrvY.VVArA6(InfoBar.instance.servicelist.getRoot().toString())
   path = "%s%s" % (VVNwTu, fName)
   if fileExists(path):
    return path
  except:
   pass
  return ""
 @staticmethod
 def VVqbQQ():
  path = CCSrvY.VVPlYj()
  if path:
   txt = FFQ5la(path, maxSize=300)
   span = iSearch(r"#NAME\s+(.*)", txt, IGNORECASE)
   if span:
    return span.group(1).strip()
  return ""
 @staticmethod
 def VVQ4Kz():
  return FFw4Nf(InfoBar.instance.servicelist.getRoot())
 @staticmethod
 def VV7U5I():
  lst = []
  for b in CCSrvY.VVcTqV():
   bName = b[0]
   bRef  = b[1].toString()
   path = VVNwTu + CCSrvY.VVArA6(bRef)
   if fileExists(path):
    lines = FFZQjt(path)
    for line in lines:
     if line.startswith("#SERVICE"):
      if not line.startswith("#SERVICE 1:64:"):
       break
    else:
     if not "userbouquet.favourites." in bRef:
      lst.append((bName, bRef))
  return lst
 @staticmethod
 def VVKMP5(SID, stripRType):
  if stripRType: return r"(?:[A-Fa-f0-9]+:)((?:[A-Fa-f0-9]+:){2}%s:(?:[A-Fa-f0-9]+:){6})" % SID
  else   : return r"((?:[A-Fa-f0-9]+:){3}%s:(?:[A-Fa-f0-9]+:){6})" % SID
 @staticmethod
 def VVJujd(SID="", stripRType=False):
  if SID : patt = CCSrvY.VVKMP5(SID, stripRType)
  else : patt = r"((?:[A-Fa-f0-9]+:){10})"
  lst = []
  for b in CCSrvY.VVcTqV():
   for service in FFw4Nf(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper())
  return lst
 @staticmethod
 def VVOuEy():
  patt = r"((?:[A-Fa-f0-9]+:){10})http.+"
  lst = []
  for b in CCSrvY.VVcTqV():
   for service in FFw4Nf(b[1]):
    span = iSearch(patt, service[0])
    if span:
     lst.append(span.group(1).upper().rstrip(":"))
  return lst
 @staticmethod
 def VVwA2l(rType, SID, refLst, startId, startNS):
  for Id in range(max(6, startId), 65535):
   hexId = ("%1x" % Id).upper()
   for NS in range(startNS, 65535):
    hexNS = ("FFF%04x" % NS).upper()
    tRef = "0:1:%s:%s:%s:%s:0:0:0:" % (SID, hexId, hexId, hexNS)
    if not tRef in refLst:
     refCode = "%s:0:1:%s:%s:%s:%s:0:0:0:" % (rType, SID, hexId, hexId, hexNS)
     if NS < 65535 - 1: NS += 1
     else    : NS, Id = 6, Id + 1
     return refCode, Id, NS
  return "", 0, 0
 @staticmethod
 def VVlFFp(pathLst, rType=""):
  refLst = CCSrvY.VVJujd(CCSrvY.VVgr9Z, stripRType=True)
  chUrlLst = []
  startId  = startNS = 0
  rType  = rType or CFG.iptvAddToBouquetRefType.getValue()
  for path in pathLst:
   refCode, startId, startNS = CCSrvY.VVwA2l(rType, CCSrvY.VVgr9Z, refLst, startId, startNS)
   if refCode:
    chName = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").replace(".", " ")
    chUrl = "%s%s:%s" % (refCode, path, chName)
    chUrlLst.append(chUrl)
   else:
    break
  return chUrlLst
class CCCXvS(Screen):
 VVcDZO   = 0
 VVsRn5  = 1
 VVutD6  = 2
 VVaAkG = 3
 VVO7aF    = 20
 VVheLL   = 0
 VVzAF2   = 1
 VVUzfM   = 2
 def __init__(self, session, VVMbDq="/", mode=VVcDZO, VVDuqR="Select", width=1400, height=920, VVTFXq=30, VVDlGi="#22001111", VVaSSM="#22000000", pickTitleBG="#11001144", pickBodyBG="#11002255", cursorBG="#06003333", gotoMovie=False, jumpToFile="", patternMode=""):
  self.skin, self.skinParam = FFRBRO(VVF5EY, width, height, 30, 40, 20, VVDlGi, VVaSSM, VVTFXq, barHeight=40, topRightBtns=2)
  self.session   = session
  self.VVDlGi   = VVDlGi
  self.VVaSSM    = VVaSSM
  self.pickTitleBG  = pickTitleBG
  self.pickBodyBG   = pickBodyBG
  FFmmH7(self)
  FFR9Qm(self["keyRed"] , "Exit")
  FFR9Qm(self["keyYellow"], "More Options")
  FFR9Qm(self["keyBlue"] , "Bookmarks")
  self.maxTitleWidth  = 1000
  self.mode    = mode
  self.VVDuqR = VVDuqR
  self.jumpToFile   = jumpToFile
  self.patternMode  = patternMode
  self.gotoMovie   = gotoMovie
  self.bookmarkMenu  = None
  self.bigDirSize   = 300
  self.edited_newFile  = "file1"
  self.edited_newDir  = "dir1"
  self.cursorBG   = cursorBG
  self.multiSelectState = False
  VVQtTJ = None
  if patternMode:
   self.mode = self.VVaAkG
   if   patternMode == "srt"  : VVQtTJ = ("^.*\.srt$"    , IGNORECASE)
   elif patternMode == "ajpSet" : VVQtTJ = ("^.*\/ajpanel_settings_" , 0    )
   elif patternMode == "poster" : VVQtTJ = ("^.*\.(jpg|png)$"    , IGNORECASE)
   elif patternMode == "pkgCtrl": VVQtTJ = ("^.*\/(control|preinst|prerm|postinst|postrm)$", 0)
   elif patternMode == "movies" : VVQtTJ = ("^.*\.(%s)$" % "|".join(CCA8jA.VV1p4d()["mov"]), IGNORECASE)
   else       : VVQtTJ = None
  if self.mode in (self.VVutD6, self.VVaAkG):
   FFR9Qm(self["keyRed"], "Cancel")
  if   self.jumpToFile       : VVnjO1, self.VVMbDq = True , FF0y7s(self.jumpToFile, True) or "/"
  elif self.gotoMovie        : VVnjO1, self.VVMbDq = True , CCCXvS.VV6Qx4(self)[1] or "/"
  elif self.mode == self.VVcDZO  : VVnjO1, self.VVMbDq = True , CFG.browserStartPath.getValue()
  elif self.mode == self.VVutD6 : VVnjO1, self.VVMbDq = False, VVMbDq
  elif self.mode == self.VVaAkG : VVnjO1, self.VVMbDq = True , VVMbDq
  else           : VVnjO1, self.VVMbDq = True , VVMbDq
  self.VVMbDq = FF1vNj(self.VVMbDq)
  self["myMenu"] = CCA8jA(  directory   = None
         , VVQtTJ = VVQtTJ
         , VVnjO1   = VVnjO1
         , VVfklg = True
         , VVfGT7 = True
         , VVx14V   = self.skinParam["width"]
         , VVTFXq   = self.skinParam["bodyFontSize"]
         , VVNyBH  = self.skinParam["bodyLineH"] )
  self["myActionMap"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok" : self.VVxCTS    ,
   "red" : self.VVfNcv   ,
   "green" : self.VVWUxT,
   "yellow": self.VV6zJm  ,
   "blue" : self.VVjGok ,
   "menu" : self.VVfZMG  ,
   "info" : self.VVjva3  ,
   "cancel": self.VV8Yjr    ,
   "pageUp": self.VV7vKN   ,
   "chanUp": self.VV7vKN
  }, -1)
  FF5k1E(self, self["myMenu"])
  self.onShown.append(self.start)
  self.onClose.append(self.onExit)
  self["myMenu"].onSelectionChanged.append(self.VV9zTT)
  global VVB4XJ
  VVB4XJ = True
 def onExit(self):
  self["myMenu"].onSelectionChanged = []
  global VVB4XJ
  del VVB4XJ
 def start(self):
  self.onShown.remove(self.start)
  self.onShown.append(self.VV9zTT)
  FFj9eW(self)
  FFplRG(self["myMenu"], bg=self.cursorBG)
  FFHLqT(self)
  self.maxTitleWidth = self["keyInfo"].getPosition()[0] - 40
  if self.mode in (self.VVutD6, self.VVaAkG):
   FFR9Qm(self["keyGreen"], self.VVDuqR)
   self.VVuWU2(self.VVzAF2)
  self.VV9zTT()
  w  = self["myMenu"].instance.size().width()
  h  = self["myMenu"].instance.size().height()
  pos  = self["myMenu"].getPosition()
  part = self["myMenu"].instance.size().height() % self.skinParam["bodyLineH"]
  half = int(part / 2)
  self["myMenu"].instance.resize(eSize(*(w, h - part)))
  self["myMenu"].instance.move(ePoint(pos[0], pos[1] + half))
  if self.VVi7u8(self.VVMbDq) > self.bigDirSize: FFJsIX(self, self.VVHgUg, title="Changing directory...")
  else              : self.VVHgUg()
 def VVHgUg(self):
  if self.jumpToFile : self.VVWv4o(self.jumpToFile)
  elif self.gotoMovie : self.VVSqts(chDir=False)
  else    : self["myMenu"].VVb5JY(self.VVMbDq)
 def VVYNxS(self, rowNdx):
  self["myMenu"].moveToIndex(rowNdx)
 def VVZvbR(self):
  FFJsIX(self, self.VV20Ut, title="Refreshing list ...")
 def VV20Ut(self):
  isSel = self["myMenu"].VVbc1I()
  if not isSel:
   self.VVSqqL(False)
  FFsMPf()
 def VVxRZb(self, saved):
  if saved: self.VVZvbR()
 def VVi7u8(self, path):
  try:
   return len(os.listdir(path))
  except:
   return 0
 def VVxCTS(self):
  if self.multiSelectState:
   ok = self["myMenu"].VVmD2t()
   if ok : self["keyBlue"].setText(self.VV8H8J())
   else : FF5uKN(self, "Cannot select item", 500)
  elif self["myMenu"].VVdbmt(): self.VViSoy()
  else       : self.VV9snL()
 def VV7vKN(self):
  if self.multiSelectState:
   FF5uKN(self, "Disable Multi-Select first", 1000)
  else:
   self["myMenu"].moveToIndex(0)
   if self["myMenu"].VVrNA2():
    self.VViSoy()
 def VViSoy(self, isDirUp=False):
  if self["myMenu"].VVdbmt():
   if not self["myMenu"].getSelection() is None: path = self["myMenu"].getSelection()[0]
   else          : path = self.VV6ywF(self.VVbBRS())
   if self.VVi7u8(path) > self.bigDirSize : FFJsIX(self, self.VVY19q, title="Changing directory...")
   else           : self.VVY19q()
 def VVY19q(self):
  self["myMenu"].descent()
  self.VV9zTT()
 def VV8Yjr(self):
  if   self.multiSelectState     : self.VVSqqL(False, True)
  elif CFG.FileManagerExit.getValue() == "e" : self.VVfNcv()
  else          : self.VV7vKN()
 def VVfNcv(self):
  if not FFBF0K(self):
   self.close("")
 def VVWUxT(self):
  path = self.VV6ywF(self.VVbBRS())
  if self.mode == self.VVutD6:
   self.close(path)
  elif self.mode == self.VVaAkG:
   if os.path.isfile(path) : self.close(path)
   else     : FF5uKN(self, "Cannot access this file", 1000)
 def VVjva3(self):
  FFJsIX(self, self.VVMX58, title="Calculating size ...")
 def VVMX58(self):
  path = self.VV6ywF(self.VVbBRS())
  param = self.VVu4KM(path)
  if param:
   path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles = param
   contents = totSize = freeSize = ""
   if typeChar == "d":
    exclude = "-type d \( -ipath '/media' -o -ipath '/mnt' -o -ipath '*boot*' -o -ipath '*/ba' \) -prune -o"
    result = FF3RLi("totDirs=$(find '%s' %s -type d -print | wc -l); totFiles=$(find '%s' %s ! -type d | wc -l); echo $totDirs','$totFiles" % (path, exclude, path, exclude))
    if iMatch("^[0-9]*,[0-9]*", result):
     parts = result.split(",")
     contents += "Directories\t: %s\n" % format(int(parts[0]), ',d')
     contents += "Files\t: %s\n"   % format(int(parts[1]), ',d')
    if os.path.ismount(path):
     typeStr += " (Mount)"
     totSize  = CCCXvS.VVlZtT(path)
     freeSize = CCCXvS.VVOsjP(path)
     size = totSize - freeSize
     totSize  = CCCXvS.VVutW7(totSize)
     freeSize = CCCXvS.VVutW7(freeSize)
    else:
     size = FFkSE4(path)
   usedSize = CCCXvS.VVutW7(size)
   if len(path) < 58 : pathTxt = path
   else    : pathTxt = "\n" + path
   pathTxt = FFGB9z(pathTxt, VVsObI) + "\n"
   if slBroken : fileTime = self.VVvqgA(path)
   else  : fileTime = self.VV7evA(path)
   def VVpQZy(key, val):
    return "%s\t: %s\n" % (key, str(val))
   txt = ""
   txt += VVpQZy("Path"    , pathTxt)
   txt += VVpQZy("Type"    , typeStr)
   if len(slTarget) > 0:
    txt += VVpQZy("Target"   , slTarget)
   if os.path.ismount(path):
    txt += VVpQZy("Total Size"   , "%s" % totSize)
    txt += VVpQZy("Used Size"   , "%s" % usedSize)
    txt += VVpQZy("Free Size"   , "%s" % freeSize)
   else:
    txt += VVpQZy("Size"    , "%s" % usedSize)
   txt += contents
   txt += "\n"
   txt += VVpQZy("Owner"    , owner)
   txt += VVpQZy("Group"    , group)
   txt += VVpQZy("Perm. (User)"  , permUser)
   txt += VVpQZy("Perm. (Group)"  , permGroup)
   txt += VVpQZy("Perm. (Other)"  , permOther)
   if len(permExtra) > 0:
    txt += VVpQZy("Perm. (Ext.)" , permExtra)
   txt += VVpQZy("iNode"    , iNode)
   txt += VVpQZy("Hard Links"   , hLinks)
   txt += fileTime
   if hLinkedFiles:
    txt += "\n%s\nHard Linked Files (files with same iNode)\n%s\n" % (SEP, SEP)
    txt += hLinkedFiles
   txt += self.VVC28f(path)
  else:
   FFw5OO(self, "Cannot access information !")
  if len(txt) > 0:
   FF90Bc(self, txt)
 def VVu4KM(self, path):
  path = path.strip()
  path = FFAxSo(path)
  result = FF3RLi("FILE='%s'; BROKEN=$(if [ ! -e \"$FILE\" ]; then echo 'yes'; else echo 'no'; fi); LINE=$(ls -lid \"$FILE\" 2> /dev/null); PARAM=$(echo $LINE | awk '{print $1\",\"$2\",\"$3\",\"$4\",\"$5\",\"$6}'); SLINK=$(echo $LINE | awk '{$1=$2=$3=$4=$5=$6=$7=$8=$9=\"\";print}'  | sed 's/ -> /,/g' | xargs); echo $PARAM','$BROKEN','$SLINK" % path)
  parts = result.split(",")
  if len(parts) > 7:
   iNode  = parts[0]
   perm  = parts[1]
   hLinks  = parts[2]
   owner  = parts[3]
   group  = parts[4]
   size  = parts[5]
   slBroken = parts[6]
   fName  = parts[7]
   slTarget = ""
   if len(parts) > 8:
    slTarget = parts[8]
   size = int(size)
   def VVvuP9(perm, start, end):
    val = perm[start : end]
    p  = { "---": "0" , "--x": "1" , "-w-": "2" , "-wx": "3" , "r--": "4" , "r-x": "5" , "rw-": "6" , "rwx": "7" , "+": "ACL" }
    if val in p : return "%s\t%s" % (val, p[val])
    else  : return val
   permUser = VVvuP9(perm, 1, 4)
   permGroup = VVvuP9(perm, 4, 7)
   permOther = VVvuP9(perm, 7, 10)
   permExtra = VVvuP9(perm, 10, 100)
   typeChar = perm[0:1]
   if   typeChar == "-": typeStr = "File"
   elif typeChar == "b": typeStr = "Block Device File"
   elif typeChar == "c": typeStr = "Character Device File"
   elif typeChar == "d": typeStr = "Directory"
   elif typeChar == "l": typeStr = "Symbolic Link"
   elif typeChar == "n": typeStr = "Network File"
   elif typeChar == "p": typeStr = "Named Pipe"
   elif typeChar == "s": typeStr = "Local Socket File"
   else    : typeStr = "Unknown"
   if "yes" in slBroken:
    slBroken = True
    typeStr  = "Broken Symlink (target not found)"
   else:
    slBroken = False
   hLinkedFiles = ""
   if typeChar != "d" and int(hLinks) > 1:
    hLinkedFiles = FF5IiQ("find / -inum %s | grep -v /proc/" % iNode)
   return path, typeStr, typeChar, iNode, permUser, permGroup, permOther, permExtra, hLinks, owner, group, size, slTarget, slBroken, hLinkedFiles
  else:
   return None
 def VVC28f(self, path):
  txt  = ""
  res  = FF3RLi("lsattr -d %s" % path)
  span = iSearch(r"([acdeijstuACDST-]{13})\s", res, IGNORECASE)
  if span:
   res = span.group(1)
   tDict = { "a": "Append only", "c": "Compressed", "d": "No dump", "e": "Extent format", "i": "Immutable", "j": "Data journalling", "s": "Secure deletion (s)", "t": "Tail-merging", "u": "Undeletable", "A": "No atime updates", "C": "No copy on write", "D": "Synchronous directory updates", "S": "Synchronous updates", "T": "Top of directory hierarchy", "h": "Huge file", "E": "Compression error", "I": "Indexed directory", "X": "Compression raw access", "Z": "Compressed dirty file" }
   lst = []
   for key, val in tDict.items():
    if key in res:
     lst.append("%s  ( %s )\n" % (val, key))
   if lst:
    lst.sort()
    for item in lst:
     txt += "    %s" % item
    txt = "\n%s\n%s" % (FFGB9z("File Attributes:", VV21C5), txt)
  return txt
 def VV7evA(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FFC3u1(os.path.getatime(path))
  txt += "Modified time\t: %s\n" % FFC3u1(os.path.getmtime(path))
  txt += "Change time\t: %s\n" % FFC3u1(os.path.getctime(path))
  return txt
 def VVvqgA(self, path):
  txt = "\n"
  txt += "Access time\t: %s\n" % FF3RLi("stat -c %%x '%s'" % path).replace(".000000000", "")
  txt += "Modified time\t: %s\n" % FF3RLi("stat -c %%y '%s'" % path).replace(".000000000", "")
  txt += "Change time\t: %s\n" % FF3RLi("stat -c %%z '%s'" % path).replace(".000000000", "")
  return txt
 def VV6ywF(self, currentSel):
  currentDir  = self["myMenu"].VVbpXR()
  if currentDir is None:
   path = currentSel
  elif currentSel is None:
   path = currentDir
  else:
   if currentSel == "/":
    path = currentDir
   else:
    if not self["myMenu"].VVdbmt():
     path = currentDir + currentSel
    else:
     if len(currentDir) > len(currentSel):
      path = currentDir
     else:
      path = currentSel
  return str(path)
 def VVbBRS(self):
  sel = self["myMenu"].getSelection()
  if sel : return sel[0]
  else : return None
 def VV9zTT(self):
  path = self.VV6ywF(self.VVbBRS())
  self["myTitle"].setText("  " + path)
  if self["myTitle"].instance:
   textW = self["myTitle"].instance.calculateSize().width()
   if textW > self.maxTitleWidth:
    length = len(path)
    tmpPath = path[4:]
    for i in range(length, 40, -1):
     self["myTitle"].setText("  .." + tmpPath)
     textW = self["myTitle"].instance.calculateSize().width()
     if textW > self.maxTitleWidth: tmpPath = tmpPath[1:]
     else       : break
  self.VVEKCm()
  if self.mode == self.VVcDZO:
   if len(path) > 0: self["keyMenu"].show()
   else   : self["keyMenu"].hide()
  if self.mode == self.VVaAkG:
   path = self.VV6ywF(self.VVbBRS())
   if os.path.isfile(path) : self["keyGreen"].show()
   else     : self["keyGreen"].hide()
 def VVfZMG(self):
  color1 = VVMrXw
  color2 = VVUVAI
  color3 = VVWOjU
  totSel = 0
  menuW = 1000
  title = "Options"
  VVZJ87= []
  if self.multiSelectState:
   menuW = 850
   totSel = self["myMenu"].VVvB6E()
   if totSel > 0:
    if iTar:
     txt1 = "Archive to .tar.gz"
     txt2 = " (Preserve Path Structure)"
     title = "Options  (%d item%s)" % (totSel, FF1I1d(totSel))
     VVZJ87.append((color1 + txt1     , "VV69Cb1" ))
     VVZJ87.append((color1 + txt1 + txt2   , "VV69Cb2" ))
     VVZJ87.append(VVoqHH)
    VVZJ87.append(("[6] Copy"       , "copyBulk" ))
    VVZJ87.append(("[7] Move"       , "moveBulk" ))
    VVZJ87.append(("[8] %sDELETE" % VVsObI , "VV3i4q" ))
   else:
    FF5uKN(self, "Nothing selected", 700)
    return
  elif self.mode in (self.VVutD6, self.VVaAkG):
   VVZJ87.append(("Properties"           , "properties" ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append((color3 + "Create New Directory (in current directory)" , "createNewDir"))
  else:
   menuW = 1000
   path  = self.VV6ywF(self.VVbBRS())
   isEditable = self["myMenu"].VVo11O()
   VVZJ87.append(("Properties", "properties"))
   if os.path.isdir(path):
    if isEditable:
     VVZJ87.append(VVoqHH)
     VVZJ87.append((color1 + "Archiving / Packaging", "VVTLv8_dir"))
   elif os.path.isfile(path):
    selFile = self.VVbBRS()
    isArch = selFile.endswith((".tar", ".gz", ".tar.bz2", "tar.xz", ".zip", ".rar"))
    if not isArch:
     VVZJ87.append((color1 + "Archive ...", "VVTLv8_file"))
    isText = False
    txt = ""
    if   isArch            : VVZJ87.extend(self.VVl5Gg(path, True))
    elif selFile.endswith((".ipk", ".deb"))     : txt = "Package Tools"
    elif selFile.endswith((".m3u", ".m3u8"))    : VVZJ87.extend(self.VVkeBL(True))
    elif selFile.endswith(".sh"):
     VVZJ87.extend(self.VV5JQs(True))
     isText = True
    elif selFile.endswith((".py", ".xml", ".txt", ".htm", ".html", ".cfg", ".conf")) or not CCCXvS.VVkuoi(path):
     VVZJ87.append(VVoqHH)
     VVZJ87.append((color2 + "View"     , "textView_def"))
     VVZJ87.append((color2 + "View (Select Encoder)" , "textView_enc"))
     VVZJ87.append((color2 + "Edit"     , "text_Edit" ))
     isText = True
    elif self["myMenu"].VV79WD(path) == "pic":
     VVZJ87.append(VVoqHH)
     VVZJ87.append((color2 + "Set as PIcon for current channel" , "VV91tE" ))
     if FFhcfU("ffmpeg") and selFile.lower().endswith((".jpg", ".png")):
      VVZJ87.append(VVoqHH)
      VVZJ87.append((color2 + "Convert to MVI (1280 x 720 )" , "VVBvnHHd"   ))
      VVZJ87.append((color2 + "Convert to MVI (1920 x 1080)" , "VVBvnHFhd"   ))
    elif selFile.endswith(CCCXvS.VV3Mcc()):
     if selFile.endswith(".mvi"):
      if FFhcfU("showiframe"):
       VVZJ87.append(VVoqHH)
       VVZJ87.append((color2 + "View as Bootlogo (will interrupt the playing service)", "viewAsBootlogo"))
     else:
      VVZJ87.append(VVoqHH)
      VVZJ87.append((color2 + "Add Media File to a Bouquet"    , "addMovieToBouquet"  ))
      VVZJ87.append((color2 + "Add all Media in Directory to a Bouquet" , "addAllMoviesToBouquet" ))
      VVZJ87.append((color2 + "Play with ..."       , "playWith"    ))
    if isText:
     VVZJ87.append((color1 + "Save as UTF-8 ..."      , "textSave_encUtf8"))
     VVZJ87.append((color1 + "Save as other Encoding ..."    , "textSave_encOthr"))
     VVZJ87.append((color1 + "Convert Line-Breaks to Unix Format..." , "VV2VHL" ))
    if len(txt) > 0:
     VVZJ87.append(VVoqHH)
     VVZJ87.append((color1 + txt, "VV9snL"))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("[4] Create SymLink", "VV41MO"))
   if isEditable:
    VVZJ87.append(("[5] Rename"      , "VVcKyN" ))
    VVZJ87.append(("[6] Copy"       , "copyFileOrDir" ))
    VVZJ87.append(("[7] Move"       , "moveFileOrDir" ))
    VVZJ87.append(("[8] %sDELETE" % VVsObI , "VVGo85" ))
    if fileExists(path):
     VVZJ87.append(VVoqHH)
     perm = oct(os.stat(path).st_mode)[-3:]
     if   perm == "644" : show644, show755, show777 = False, True , True
     elif perm == "755" : show644, show755, show777 = True , False , True
     elif perm == "777" : show644, show755, show777 = True , True , False
     else    : show644, show755, show777 = True , True , True
     chmodTxt = "Change Permissions (from %s to " % perm
     if show644 : VVZJ87.append((chmodTxt + "644)", "chmod644"))
     if show755 : VVZJ87.append((chmodTxt + "755)", "chmod755"))
     if show777 : VVZJ87.append((chmodTxt + "777)", "chmod777"))
   VVZJ87.append(VVoqHH)
   VVZJ87.append((color3 + "Create New File (in current directory)"  , "createNewFile" ))
   VVZJ87.append((color3 + "Create New Directory (in current directory)" , "createNewDir" ))
   fPath, fDir, fName = CCCXvS.VV6Qx4(self)
   if fPath:
    VVZJ87.append(VVoqHH)
    VVZJ87.append((color2 + "Go to Current Movie Dir", "VVSqts"))
  FFYySC(self, self.VVE9Sf, width=menuW, height=1050, title=title, VVZJ87=VVZJ87, VVIBI3=False, VVDlGi="#00101020", VVaSSM="#00101A2A")
 def VVE9Sf(self, item=None):
  if item is not None:
   path = self.VV6ywF(self.VVbBRS())
   selFile = self.VVbBRS()
   if   item == "VV69Cb1"    : self.VV69Cb(False)
   if   item == "VV69Cb2"    : self.VV69Cb(True)
   elif item == "copyBulk"     : self.VVBraG(False)
   elif item == "moveBulk"     : self.VVBraG(True)
   elif item == "VV3i4q"    : self.VV3i4q()
   elif item == "properties"    : self.VVjva3()
   elif item == "VVTLv8_dir" : self.VVTLv8(path, True)
   elif item == "VVTLv8_file" : self.VVTLv8(path, False)
   elif item == "VV777S"  : self.VV777S(path)
   elif item == "VV7qiv"  : self.VV7qiv(path)
   elif item.startswith("extract_")  : self.VVPs2y(path, selFile, item)
   elif item.startswith("script_")   : self.VVqiio(path, selFile, item)
   elif item.startswith("m3u_")   : self.VVSpTD(path, selFile, item)
   elif item.startswith("textView_def") : FFF5Ye(self, path)
   elif item.startswith("textView_enc") : self.VVE1PR(path)
   elif item.startswith("text_Edit")  : FFJsIX(self, BF(CCQ3ND, self, path, VVCeou=self.VVxRZb), title="Opening File ...")
   elif item.startswith("textSave_encUtf8"): self.VVbQLK(path, "Save as UTF-8"   , True)
   elif item.startswith("textSave_encOthr"): self.VVbQLK(path, "Save as Other Encoding", False)
   elif item.startswith("VV2VHL") : self.VV2VHL(path)
   elif item == "viewAsBootlogo"   : self.VVFSCT(path, True)
   elif item == "addMovieToBouquet"  : self.VV0B8T(path, False)
   elif item == "addAllMoviesToBouquet" : self.VV0B8T(path, True)
   elif item == "playWith"     : self.VVJI1S(path)
   elif item == "VV91tE" : self.VV91tE(path)
   elif item == "VVBvnHHd"   : FFJsIX(self, BF(self.VVBvnH, path, False))
   elif item == "VVBvnHFhd"   : FFJsIX(self, BF(self.VVBvnH, path, True))
   elif item == "VV41MO"   : self.VV41MO(path, selFile)
   elif item == "VVcKyN"   : self.VVcKyN(path, selFile)
   elif item == "copyFileOrDir"   : self.VVECWP(path, False)
   elif item == "moveFileOrDir"   : self.VVECWP(path, True)
   elif item == "VVGo85"   : self.VVGo85(path, selFile)
   elif item == "chmod644"     : self.VVq52G(path, selFile, "644")
   elif item == "chmod755"     : self.VVq52G(path, selFile, "755")
   elif item == "chmod777"     : self.VVq52G(path, selFile, "777")
   elif item == "createNewFile"   : self.VVcCX2(path, True)
   elif item == "createNewDir"    : self.VVcCX2(path, False)
   elif item == "VVSqts"   : self.VVSqts()
   elif item == "VV9snL"    : self.VV9snL()
 def VV9snL(self):
  if self.mode == self.VVaAkG and not self.patternMode == "poster":
   return
  selFile = self.VVbBRS()
  path  = self.VV6ywF(selFile)
  if os.path.isfile(path):
   cat = self["myMenu"].VV79WD(path)
   if   cat == "pic"       : self.VViUTh(path)
   elif cat == "txt"       : FFF5Ye(self, path)
   elif cat in ("tar", "zip", "rar")   : self.VVCnLA(path, selFile)
   elif cat == "scr"       : self.VVZR8u(path, selFile)
   elif cat == "m3u"       : self.VVDH0V(path, selFile)
   elif cat in ("ipk", "deb")     : self.VV4oYf(path, selFile)
   elif cat in ("mov", "mus")     : self.VVFSCT(path)
   elif not CCCXvS.VVkuoi(path) : FFF5Ye(self, path)
 def VViUTh(self, path):
  curIndex = 0
  curFile = os.path.basename(path)
  lst = []
  for item in self["myMenu"].list:
   if not item[0][1]:
    category = self["myMenu"].VV79WD(item[1][7])
    if category == "pic":
     if curFile == item[1][7]:
      curIndex = len(lst)
     lst.append(item[1][7])
  CCo6hs.VVhaNU(self, path, fileList=lst, curIndex=curIndex, cbFnc=self.VVr3y8)
 def VVr3y8(self, path):
  self.VVWv4o(path)
 def VVFSCT(self, path, asLogo=False):
  if asLogo : CChDqL.VVY3TZ(self, path)
  else  : FFJsIX(self, BF(self.VVDPDb, self, path), title="Playing Media ...")
 def VVjGok(self):
  if self["keyBlue"].getVisible():
   VVarfR = self.VVpHRy()
   if VVarfR:
    path = self.VV6ywF(self.VVbBRS())
    enableGreenBtn = False if path in self.VVpHRy() else True
    newList = []
    for line in VVarfR:
     newList.append((line, line))
    VV6LYc  = ("Delete"    , self.VVUjKm    )
    VVbiUc  = ("Add Current Dir"   , BF(self.VViVp2, path) ) if enableGreenBtn else None
    VV3ba7 = ("Move Up"     , self.VVMnuc    )
    VV2YYF  = ("Move Down"   , self.VVNqwr    )
    self.bookmarkMenu = FFYySC(self, self.VVAgWU, width=1200, title="Bookmarks", VVZJ87=newList, minRows=10 ,VV6LYc=VV6LYc, VVbiUc=VVbiUc, VV3ba7=VV3ba7, VV2YYF=VV2YYF, VVDlGi="#00000022", VVaSSM="#00000022")
 def VVUjKm(self, VV4EHV=None, path=None):
  VVarfR = self.VVpHRy()
  if VVarfR:
   while path in VVarfR:
    VVarfR.remove(path)
   self.VV4usu(VVarfR)
  if self.bookmarkMenu:
   self.bookmarkMenu.VVIEvp(VVarfR)
   self.bookmarkMenu.VVWr0F(("Add Current Dir", BF(self.VViVp2, path)))
  else:
   FF5uKN(self, "Removed", 800)
  self.VVEKCm()
 def VViVp2(self, path, VV4EHV=None, item=None):
  VVarfR = self.VVpHRy()
  if len(VVarfR) >= self.VVO7aF:
   FFw5OO(SELF, "Max bookmarks reached (max=%d)." % self.VVO7aF)
  elif not path in VVarfR:
   if not os.path.isdir(path):
    path = FF0y7s(path, True)
   newList = [path] + VVarfR
   self.VV4usu(newList)
   if self.bookmarkMenu:
    self.bookmarkMenu.VVIEvp(newList)
    self.bookmarkMenu.VVWr0F()
   else:
    FF5uKN(self, "Added", 800)
  self.VVEKCm()
 def VVMnuc(self, VVbBRSObj, path):
  if self.bookmarkMenu:
   VVarfR = self.bookmarkMenu.VVB0MO(True)
   if VVarfR:
    self.VV4usu(VVarfR)
 def VVNqwr(self, VVbBRSObj, path):
  if self.bookmarkMenu:
   VVarfR = self.bookmarkMenu.VVB0MO(False)
   if VVarfR:
    self.VV4usu(VVarfR)
 def VVAgWU(self, folder=None):
  if folder:
   folder = FF1vNj(folder)
   self["myMenu"].VVb5JY(folder)
   self["myMenu"].moveToIndex(0)
  self.VV9zTT()
 def VVpHRy(self):
  line = CFG.browserBookmarks.getValue().strip()
  while " ," in line : line.replace(" ,", ",")
  while ", " in line : line.replace(", ", ",")
  if   "," in line : return line.split(",")
  elif len(line) > 0 : return [line]
  else    : return []
 def VVeVn5(self):
  return True if VVpHRy() else False
 def VV4usu(self, VVarfR):
  line = ",".join(VVarfR)
  FFdEZ4(CFG.browserBookmarks, line)
 def VVWv4o(self, path):
  if fileExists(path):
   fDir  = FF1vNj(os.path.dirname(path))
   if fDir:
    self["myMenu"].VVb5JY(fDir)
   fName = os.path.basename(path)
   for ndx, item in enumerate(self["myMenu"].list):
    if fName == item[0][0]:
     self["myMenu"].moveToIndex(ndx)
     break
  else:
   FF5uKN(self, "Not found", 1000)
 def VVSqts(self, chDir=True):
  fPath, fDir, fName = CCCXvS.VV6Qx4(self)
  self.VVWv4o(fPath)
 def VV6zJm(self):
  path = self.VV6ywF(self.VVbBRS())
  isAdd = False if path in self.VVpHRy() else True
  dirTxt = "Selected" if os.path.isdir(path) else "Current"
  c1, c2 , c3 = VVkqaK, VVkIQ9, VVUVAI
  VVZJ87 = []
  VVZJ87.append(("Find Files ..." , "find"))
  VVZJ87.append(("Sort ..."   , "sort"))
  VVZJ87.append(VVoqHH)
  if isAdd: VVZJ87.append((c1 + "Add %s Dir to Bookmarks"  % dirTxt, "addBM"))
  else : VVZJ87.append((c1 + "Remove %s Dir from Bookmarks" % dirTxt, "remBM"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(    (c2 + 'Set %s Dir as "Startup Dir"' % dirTxt, "start"))
  if self.mode == self.VVcDZO:
   VVZJ87.append(VVoqHH)
   if self.multiSelectState: VVZJ87.append( (c3 + "Disable Multi-Select ", "multiOff"))
   else     : VVZJ87.append( (c3 + "Enable Multi-Select"  , "multiOn" ))
   VVZJ87.append(       (c3 + "Select all"    , "selAll"  ))
  FFYySC(self, BF(self.VV7N3Q, path), width=750, title="More Options", VVZJ87=VVZJ87, VVDlGi="#00221111", VVaSSM="#00221111")
 def VV7N3Q(self, path, item):
  if item:
   if   item == "find"  : self.VVGDvs(path)
   elif item == "sort"  : self.VV6vFa()
   elif item == "addBM" : self.VViVp2(path)
   elif item == "remBM" : self.VVUjKm(None, path)
   elif item == "start" : self.VVcuN8(path)
   elif item == "multiOn" : self.VVSqqL(True)
   elif item == "multiOff" : self.VVSqqL(False)
   elif item == "selAll" : self.VVSqqL(True, True)
 def VVSqqL(self, isOn, isAll=False):
  self.multiSelectState = isOn
  if isAll or not isOn:
   FFJsIX(self, BF(self["myMenu"].VV7OzW, isOn), title="Selecting ..." if isOn else "Unselecting ...")
  self.VVuWU2(self.VVUzfM if isOn else self.VVheLL)
 def VVuWU2(self, mode=0):
  if   mode == self.VVzAF2 : titBg, bodBg = self.pickTitleBG, self.pickBodyBG
  elif mode == self.VVUzfM: titBg, bodBg = "#01883366", "#11002233"
  else        : titBg, bodBg = self.VVDlGi, self.VVaSSM
  FFWN9Z(self["myTitle"], titBg)
  FFWN9Z(self["myBar"], titBg)
  FFWN9Z(self["myBody"], bodBg)
  FFWN9Z(self["myMenu"], bodBg)
  if self.multiSelectState: bg, txt = "#01883366", self.VV8H8J()
  else     : bg, txt = VV6Q1c[3], "Bookmarks"
  FFR9Qm(self["keyBlue"], txt)
  FFWN9Z(self["keyBlue"], bg)
  self.VVEKCm()
 def VV8H8J(self):
  return "Selected Items = %d" % self["myMenu"].VVvB6E()
 def VVEKCm(self):
  if self.VVpHRy() or self.multiSelectState: self["keyBlue"].show()
  else            : self["keyBlue"].hide()
 def VVGDvs(self, path):
  VVZJ87 = []
  VVZJ87.append(("Find in Current Directory"    , "findCur"  ))
  VVZJ87.append(("Find in Current Directory (recursive)" , "findCurR" ))
  VVZJ87.append(("Find in all Storage Systems"    , "findAll"  ))
  FFYySC(self, BF(self.VV8F6v, path), width=700, title="Find File/Pattern", VVZJ87=VVZJ87, VV18hv=True, VVhe5b=True, VVDlGi="#00221111", VVaSSM="#00221111")
 def VV8F6v(self, path, item):
  if item:
   title, item, ndx = item
   if   item == "findCur" : self.VV0iVr(0, path, title)
   elif item == "findCurR" : self.VV0iVr(1, path, title)
   elif item == "findAll" : self.VV0iVr(2, path, title)
 def VV0iVr(self, mode, path, title):
  if CFG.lastFileManFindPatt.getValue(): txt = CFG.lastFileManFindPatt.getValue()
  else         : txt = "*.ipk"
  FFaSvq(self, BF(self.VVIoSw, mode, path, title), defaultText=txt, title=title, message="Enter Name/Pattern:")
 def VVIoSw(self, mode, path, title, filePatt):
  if filePatt is not None:
   filePatt = filePatt.strip()
   FFdEZ4(CFG.lastFileManFindPatt, filePatt)
   badLst = filePatt.replace(" ", "") in ("*.*", "*.", ".*")
   if not filePatt : FF5uKN(self, "No entery", 1500)
   elif badLst  : FF5uKN(self, "Too many file !", 1500)
   else   : FFJsIX(self, BF(self.VVFW31, mode, path, title, filePatt), title="Searching ...")
 def VVFW31(self, mode, path, title, filePatt):
  lst = FFnAC3(FF627U("find '%s' -type f -iname '%s' %s" % ("/" if mode==2 else path, filePatt, "-maxdepth 1" if mode == 0 else "")))
  if lst:
   err = CCCXvS.VVgw5W(lst)
   if err:
    FFw5OO(self, err)
   else:
    for ndx, path in enumerate(lst):
     lst[ndx] = (os.path.basename(path), os.path.dirname(path))
    lst.sort(key=lambda x: x[0].lower())
    header = ("File", "Directory" )
    widths = (50  , 50   )
    VVs5AA = (""     , self.VVpSCJ , [])
    VVX66G = ("Go to File Location", self.VVQyM7  , [])
    FF1Dpj(self, None, title="%s : %s" % (title, filePatt), header=header, VVarfR=lst, VVhAo0=widths, VVTFXq=26, VVs5AA=VVs5AA, VVX66G=VVX66G)
  else:
   FFzLBa(self, "Not found !", 2000)
 def VVQyM7(self, VVxBfP, title, txt, colList):
  path = os.path.join(colList[1], colList[0])
  if fileExists(path):
   VVxBfP.cancel()
   self.VVWv4o(path)
  else:
   FF5uKN(VVxBfP, "Path not found !", 1000)
 def VVpSCJ(self, VVxBfP, title, txt, colList):
  txt = "%s\n%s\n\n" % (FFGB9z("File:"  , VVUVAI), colList[0])
  txt += "%s\n%s"  % (FFGB9z("Directory:", VVUVAI), FF1vNj(colList[1]))
  FF90Bc(VVxBfP, txt, title=title)
 def VV6vFa(self):
  nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVJLcG()
  VVZJ87 = []
  VVZJ87.append(("Name\t%s" % nameAlpTxt, "nameAlp"))
  VVZJ87.append(("Name\t%s" % nameNumTxt, "nameNum"))
  VVZJ87.append(("Date\t%s" % dateTxt, "dateAlp"))
  VVZJ87.append(("Type\t%s" % typeTxt, "typeAlp"))
  VV2YYF = ("Mix", BF(self.VVJfhJ, True))
  FFYySC(self, BF(self.VVkYv0, False), barText=txt, width=650, title="Sort Options", VVZJ87=VVZJ87, VV2YYF=VV2YYF, VVhe5b=True, VVDlGi="#00221111", VVaSSM="#00221111")
 def VVJfhJ(self, isMix, VV4EHV, item):
  self.VVkYv0(True, item)
 def VVkYv0(self, isMix, item):
  if item:
   nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt , dateMode, dateTxt, typeMode, typeTxt, txt = self["myMenu"].VVJLcG()
   title = "Sorting ... "
   if   item == "nameAlp": FFJsIX(self, BF(self["myMenu"].VVwZ5z, nameAlpMode, isMix, False), title=title)
   elif item == "nameNum": FFJsIX(self, BF(self["myMenu"].VVwZ5z, nameNumMode, isMix, True ), title=title)
   elif item == "dateAlp": FFJsIX(self, BF(self["myMenu"].VVwZ5z, dateMode , isMix, False), title=title)
   elif item == "typeAlp": FFJsIX(self, BF(self["myMenu"].VVwZ5z, typeMode , isMix, False), title=title)
 def VVcuN8(self, path):
  if not os.path.isdir(path):
   path = FF0y7s(path, True)
  FFdEZ4(CFG.browserStartPath, path)
  FF5uKN(self, "Done", 500)
 def VVleol(self, selFile, VVILc0, command):
  FFNKVM(self, BF(FF1Q61, self, command, consFont=True, VVYxQ2=self.VVZvbR), "%s\n\n%s" % (VVILc0, selFile))
 def VVl5Gg(self, path, calledFromMenu):
  destPath = self.VV9FFy(path)
  lastPart = FF65m2(destPath)
  color = VVUVAI if calledFromMenu else ""
  VVZJ87 = []
  if path.endswith(".gz") and not path.endswith(".tar.gz"):
   VVZJ87.append((color + "Extract Content"           , "extract_gz" ))
  else:
   if calledFromMenu: VVZJ87.append(VVoqHH)
   VVZJ87.append((color + "List Archived Files"          , "extract_listFiles" ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append((color + 'Extract to "%s"' % lastPart        , "extract_toDir"  ))
   VVZJ87.append((color + 'Extract to Root Directory "/"  (recommended for plugins)' , "extract_toRoot"  ))
   VVZJ87.append((color + "Extract Here"            , "extract_here"  ))
   if iTar and iZip:
    if path.endswith(".zip"):
     if not calledFromMenu: VVZJ87.append(VVoqHH)
     VVZJ87.append((color + "Convert .zip to .tar.gz"       , "VV777S" ))
    elif path.endswith(".tar.gz"):
     if not calledFromMenu: VVZJ87.append(VVoqHH)
     VVZJ87.append((color + "Convert .tar.gz to .zip"       , "VV7qiv" ))
  return VVZJ87
 def VVCnLA(self, path, selFile):
  FFYySC(self, BF(self.VVPs2y, path, selFile), title="Compressed File Options", VVZJ87=self.VVl5Gg(path, False))
 def VVPs2y(self, path, selFile, item=None):
  if item is not None:
   parent  = FF0y7s(path, False)
   destPath = self.VV9FFy(path)
   lastPart = FF65m2(destPath)
   cmd   = ""
   if item == "extract_listFiles":
    linux_sep = "echo -e %s;" % SEP
    cmd += linux_sep
    if path.endswith(".zip"):
     cmd += FF09Tg("unzip", "unzip", "Unzip")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unzip -l '%s';" % path
     cmd += "fi;"
    elif path.endswith(".rar"):
     cmd += FF09Tg("unrar", "unrar", "Unrar")
     cmd += 'if [ "$allOK" -eq "1" ]; then '
     cmd += " echo '';"
     cmd += " unrar l '%s';" % path
     cmd += "fi;"
    else:
     cmd += "echo -e 'Archive:\n%s\n';" % path
     cmd += "echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
     cmd += "tar -tf '%s';" % path
    cmd += "echo '';"
    cmd += linux_sep
    FFleea(self, cmd)
   elif path.endswith(".zip"):
    if item == "VV777S" : self.VV777S(path)
    else       : self.VVxu5n(item, path, parent, destPath, "Unzip this file ?\n\n%s" % selFile)
   elif item == "VV7qiv" and path.endswith(".tar.gz"):
    self.VV7qiv(path)
   elif item == "extract_gz":
    title = 'Extract ".gz" file'
    res = FF3RLi("RES=$(gzip -dk '%s') && echo ok || echo $RES" % path)
    if res == "ok":
     FF15cM(self, "Result:\n\n%s" % path[:-3], title=title)
     self.VVZvbR()
    else:
     FFw5OO(self, "Error:\n\n%s" % res, title=title)
   elif path.endswith(".rar"):
    self.VVqNSR(item, path, parent, destPath, "Unrar this file ?\n\n%s" % selFile)
   elif item == "extract_toDir":
    cmd += "cd '%s';" % parent
    cmd += FFIV1X("mkdir '%s'"   % lastPart) + ";"
    cmd += 'if [ -d "%s" ]; then '  % lastPart
    cmd += " tar -xvf '%s' -C '%s';" % (path, lastPart)
    cmd += "else"
    cmd += " echo -e 'Cannot create directory:\n%s';" % lastPart
    cmd += "fi"
    self.VVleol(selFile, 'Extract to "%s" ?' % lastPart  , cmd)
   elif item == "extract_toRoot":
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s' -C /" % path
    self.VVleol(selFile, 'Extract to Root Directory ("/") ?' , cmd)
   elif item == "extract_here":
    parent = FF0y7s(path, False)
    cmd += "cd '%s';" % parent
    cmd += "tar -xvf '%s'" % path
    self.VVleol(selFile, "Extract Here ?"      , cmd)
 def VV9FFy(self, path, addSep=False):
  if   path.endswith(".tar")  : extLen = 4
  elif path.endswith(".tar.gz") : extLen = 7
  elif path.endswith(".tar.xz") : extLen = 7
  elif path.endswith(".tar.bz2") : extLen = 8
  elif path.endswith(".zip")  : extLen = 4
  elif path.endswith(".rar")  : extLen = 4
  else       : extLen = 0
  return path[:-extLen]
 def VVxu5n(self, item, path, parent, destPath, VVILc0):
  FFNKVM(self, BF(self.VV074a, item, path, parent, destPath), VVILc0)
 def VV074a(self, item, path, parent, destPath):
  archCmd = ""
  if item == "extract_toDir":
   archCmd += " cd '%s';" % parent
   archCmd += " [ ! -d '%s' ] && mkdir '%s';" % (destPath, destPath)
  elif item == "extract_toRoot":
   destPath = "/"
  elif item == "extract_here":
   destPath = parent
  archCmd += " unzip -l '%s';"   % path
  archCmd += " unzip -o -q '%s' -d '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FF09Tg("unzip", "unzip", "Unzip")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFXRSi(destPath, VVVjNM))
  cmd +=   sep
  cmd += "fi;"
  FF3aHD(self, cmd, VVYxQ2=self.VVZvbR)
 def VVqNSR(self, item, path, parent, destPath, VVILc0):
  FFNKVM(self, BF(self.VVZM46, item, path, parent, destPath), VVILc0)
 def VVZM46(self, item, path, parent, destPath):
  archCmd = ""
  if   item == "extract_toDir" : destPath = FF1vNj(destPath)
  elif item == "extract_toRoot" : destPath = "/"
  elif item == "extract_here"  : destPath = parent
  archCmd += " unrar x '%s' '%s';" % (path, destPath)
  sep   = " echo -e '%s\n';" % SEP
  cmd  = FF09Tg("unrar", "unrar", "Unrar")
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   archCmd
  cmd +=   sep
  cmd += " echo -e 'Done.\n\nFiles extracted to:\n%s\n' %s;" % (destPath, FFXRSi(destPath, VVVjNM))
  cmd +=   sep
  cmd += "fi;"
  FF3aHD(self, cmd, VVYxQ2=self.VVZvbR)
 def VV5JQs(self, addSep=False):
  VVZJ87 = []
  if addSep:
   VVZJ87.append(VVoqHH)
  VVZJ87.append((VVUVAI + "View Script File"  , "script_View"  ))
  VVZJ87.append((VVUVAI + "Execute Script File" , "script_Execute" ))
  VVZJ87.append((VVUVAI + "Edit"     , "script_Edit"  ))
  return VVZJ87
 def VVZR8u(self, path, selFile):
  FFYySC(self, BF(self.VVqiio, path, selFile), title="Script File Options", VVZJ87=self.VV5JQs())
 def VVqiio(self, path, selFile, item=None):
  if item is not None:
   if   item == "script_View"  : FFF5Ye(self, path)
   elif item == "script_Execute" : self.VVleol(selFile, "Run Script File ?", "chmod +x '%s'; '%s'" % (path, path))
   elif item == "script_Edit"  : CCQ3ND(self, path, VVCeou=self.VVxRZb)
 def VVkeBL(self, addSep=False):
  VVZJ87 = []
  if addSep:
   VVZJ87.append(VVoqHH)
  VVZJ87.append((VVUVAI + "Browse IPTV Channels" , "m3u_Browse" ))
  VVZJ87.append((VVUVAI + "Edit"     , "m3u_Edit" ))
  VVZJ87.append((VVUVAI + "View"     , "m3u_View" ))
  return VVZJ87
 def VVDH0V(self, path, selFile):
  FFYySC(self, BF(self.VVSpTD, path, selFile), title="M3U/M3U8 File Options", VVZJ87=self.VVkeBL())
 def VVSpTD(self, path, selFile, item=None):
  if item is not None:
   if   item == "m3u_Browse" : FFJsIX(self, BF(self.session.open, CC9X9s, m3uOrM3u8File=path))
   elif item == "m3u_Edit"  : CCQ3ND(self, path, VVCeou=self.VVxRZb)
   elif item == "m3u_View"  : FFF5Ye(self, path)
 def VVE1PR(self, path):
  if fileExists(path) : FFJsIX(self, BF(CCqdtK.VVpZ7B, self, path, BF(self.VVyxX4, path)), title="Loading Codecs ...")
  else    : FFZoTn(self, path)
 def VVyxX4(self, path, item=None):
  if item:
   FFF5Ye(self, path, encLst=item)
 def VVbQLK(self, path, title, asUtf8):
  if fileExists(path) : FFJsIX(self, BF(CCqdtK.VVpZ7B, self, path, BF(self.VV5GE3, path, title, asUtf8), title="Original Encoding"), title="Loading Codecs ...")
  else    : FFZoTn(self, path)
 def VV5GE3(self, path, title, asUtf8, fromEnc=None):
  if fromEnc:
   if asUtf8: self.VVOwLx(path, title, fromEnc, "UTF-8")
   else  : CCqdtK.VV56Pf(self, BF(self.VVOwLx, path, title, fromEnc), title="Convert to Encoding")
 def VVOwLx(self, path, title, fromEnc, item):
  if item:
   txt, toEnc, ndx = item
   if fileExists(path):
    try:
     outFile = "%s_%s%s" % (path, toEnc, os.path.splitext(path)[1])
     with ioOpen(path, "r", encoding=fromEnc) as src:
      BLOCK_1MB = 1048576
      with ioOpen(outFile, "w", encoding=toEnc) as dest:
       while True:
        cont = src.read(BLOCK_1MB)
        if not cont:
         break
        dest.write(cont)
      txt  = FFGB9z("Successful\n\n", VVVjNM)
      txt += FFGB9z("From Encoding (%s):\n" % fromEnc, VVVCGb)
      txt += "%s\n\n" % path
      txt += FFGB9z("To Encoding (%s):\n" % toEnc, VVVCGb)
      txt += "%s\n\n" % outFile
      FF90Bc(self, txt, title=title)
    except:
     FFw5OO(self, 'Cannot encode the file:\n%s\n\nFrom "%s" to "%s"' % (path, fromEnc, toEnc), title=title)
   else:
    FF5uKN(self, "Cannot open file", 2000)
   self.VVZvbR()
 def VV2VHL(self, path):
  title = "File Line-Break Conversion"
  FFNKVM(self, BF(self.VVALtn, path, title), "Convert Line-Breaks to Unix for the file:\n\n%s" % path, title=title)
 def VVALtn(self, path, title):
  if fileExists:
   with open(path, 'rb') as f:
    data = f.read()
   done = False
   if data:
    CRLF, LF, To = b"\r\n", b"\r", b"\n"
    totCRLF = data.count(CRLF)
    totLF = data.count(LF)
    if totCRLF or totLF:
     done = True
     with open(path, 'wb') as f:
      f.write(data.replace(CRLF, To).replace(LF, To))
   if done : txt = "%s\n\n%s" % (FFGB9z("File converted:", VVVjNM), path)
   else : txt = "Nothing to convert in:\n\n%s" % path
   FF15cM(self, txt, title=title)
  else:
   FFZoTn(self, path, title=title)
 def VVq52G(self, path, selFile, newChmod):
  FFNKVM(self, BF(self.VVYqaC, path, newChmod), "Change Permission to %s ?\n\n%s" % (newChmod, selFile))
 def VVYqaC(self, path, newChmod):
  cmd = "chmod %s '%s' %s" % (newChmod, path, VV5wTt)
  result = FF3RLi(cmd)
  if result == "Successful" : FF15cM(self, result)
  else      : FFw5OO(self, result)
 def VV41MO(self, path, selFile):
  parent = FF0y7s(path, False)
  self.session.openWithCallback(self.VVaHug, BF(CCCXvS, mode=CCCXvS.VVutD6, VVMbDq=parent, VVDuqR="Create Symlink here"))
 def VVaHug(self, newPath):
  if len(newPath) > 0:
   target = self.VV6ywF(self.VVbBRS())
   target = FFAxSo(target)
   linkName = FF65m2(target)
   dotIndex = linkName.find(".")
   if dotIndex > -1:
    linkName = linkName[:dotIndex]
   newPath = FF1vNj(newPath)
   link = newPath + linkName
   if   os.path.islink(link) : txt = ""
   elif os.path.ismount(link) : txt = "MOUNT:"
   elif os.path.isfile(link) : txt = "FILE:"
   elif os.path.isdir(link) : txt = "DIRECTORY:"
   else      : txt = ""
   if len(txt) > 0:
    FFw5OO(self, "Name already used for %s\n\n%s" % (txt, link))
    return
   txt  = "-> TARGET:\n%s\n\n" % target
   txt += "<- LINK:\n%s"  % link
   FFNKVM(self, BF(self.VVFlQc, target, link), "Create Soft Link ?\n\n%s" % txt, VV4evd=True)
 def VVFlQc(self, target, link):
  cmd = "LINK='%s'; if [ -e $LINK ]; then rm $LINK; fi; ln -sfv '%s' '%s' &>/dev/null %s" % (link, target, link, VV5wTt)
  result = FF3RLi(cmd)
  if result == "Successful" : FF15cM(self, result)
  else      : FFw5OO(self, result)
 def VVcKyN(self, path, selFile):
  lastPart = FF65m2(path)
  FFaSvq(self, BF(self.VVFvXh, path, selFile), title="Rename", defaultText=lastPart, message="Enter New Name:")
 def VVFvXh(self, path, selFile, VVYwVo):
  if VVYwVo:
   parent = FF0y7s(path, True)
   if os.path.isdir(path):
    path = FFAxSo(path)
   newName = parent + VVYwVo
   cmd = "mv '%s' '%s' %s" % (path, newName, VV5wTt)
   if VVYwVo:
    if selFile != VVYwVo:
     message = "%s\n\nTo:\n\n%s" % (path, newName)
     FFNKVM(self, BF(self.VVlVdT, cmd), message, title="Rename file?")
    else:
     FFw5OO(self, "Cannot use same name!", title="Rename")
 def VVlVdT(self, cmd):
  result = FF3RLi(cmd)
  if "Fail" in result:
   FFw5OO(self, result)
  self.VVZvbR()
 def VV69Cb(self, preserve):
  title="Archive to .tar.gz"
  self.session.open(CCmNws, barTheme=CCmNws.VV3z22, titleBg="#22003344", bodyBg="#22001122"
      , titlePrefix = title
      , fncToRun  = BF(self.VVBdxg, title, preserve)
      , VVCeou = BF(self.VV0Evl, title))
 def VVBdxg(self, title, preserve, VVXLiB):
  totSel = self["myMenu"].VVvB6E()
  totOk = totFail = 0
  VVXLiB.VVCnyB(totSel)
  VVXLiB.VVlaij = ["", totSel, totOk, totFail, ""]
  VVXLiB.VVHdrq("Prepareing targz file")
  curDir = self["myMenu"].VVbpXR()
  lastPart = FF65m2(curDir) or "archive"
  outF = os.path.join(curDir, lastPart + ".tar.gz")
  c = 0
  while fileExists(outF):
   c += 1
   outF = os.path.join(curDir, lastPart + "_%d.tar.gz" % c)
  totOk = totFail = 0
  path = ""
  try:
   with iTar.open(outF, mode="w:gz") as tarF:
    for row in self["myMenu"].list:
     if not VVXLiB or VVXLiB.isCancelled:
      return
     if row[2][6]:
      VVXLiB.VV1Vtn(1)
      name  = FFAxSo(row[0][0])
      lastPath = FF65m2(name)
      path  = os.path.join(curDir, name)
      tarF.add(path, arcname=None if preserve else lastPath)
      totOk += 1
      if VVXLiB:
       VVXLiB.VVlaij = [outF, totSel, totOk, totFail, path]
       VVXLiB.VVJetR(totOk, lastPath)
  except:
   totFail += 1
   if VVXLiB:
    VVXLiB.VVlaij = [outF, totSel, totOk, totFail, path]
 def VV0Evl(self, title, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  outF, totSel, totOk, totFail, path = VVlaij
  txt  = "%s:\n%s\n\n"   % (FFGB9z("Output File", VVVjNM), outF)
  txt += "Total\t: %d\n"  % totSel
  txt += "Archived\t: %d\n" % totOk
  if totFail   : txt += FFGB9z("Failed\t: %d\n" % totFail, VVsObI)
  if not VVeObj: txt += "%s\n%s" % (FFGB9z("\nCancelled while copying:", VVsObI), path)
  FF90Bc(self, txt, title=title)
  self.VVZvbR()
 def VVBraG(self, isMove):
  self.session.openWithCallback(BF(self.VV0W0q, isMove), BF(CCCXvS, mode=CCCXvS.VVutD6, VVMbDq=self["myMenu"].VVbpXR(), VVDuqR="Move to here" if isMove else "Paste here"))
 def VV0W0q(self, isMove, newPath):
  if newPath:
   if isMove : title, action = "Move Items", "Moved"
   else  : title, action = "Copy Items", "Copied"
   self.session.open(CCmNws, barTheme=CCmNws.VV3z22, titleBg="#22003344", bodyBg="#22001122"
       , titlePrefix = title
       , fncToRun  = BF(self.VVyRgQ, title, action, isMove, newPath)
       , VVCeou = BF(self.VV1rFa, title, action, isMove, newPath))
 def VVyRgQ(self, title, action, isMove, newPath, VVXLiB):
  curDir = self["myMenu"].VVbpXR()
  totOk = totFail = 0
  totSel = self["myMenu"].VVvB6E()
  if isMove: cmd = "mv -f"
  else  : cmd = "cp -frp"
  VVXLiB.VVCnyB(totSel)
  VVXLiB.VVlaij = [totSel, totOk, totFail, ""]
  for row in self["myMenu"].list:
   if not VVXLiB or VVXLiB.isCancelled:
    return
   if row[2][6]:
    VVXLiB.VV1Vtn(1)
    VVXLiB.VVmZZM(action, totOk, FF65m2(row[0][0]))
    path = os.path.join(curDir, row[0][0])
    lastPart = FF65m2(path)
    if os.path.isdir(path): path = FFAxSo(path)
    dest = os.path.join(newPath, lastPart)
    if FFuB0V("%s '%s' '%s'" % (cmd, path, dest)) : totOk += 1
    else            : totFail += 1
    if VVXLiB:
     VVXLiB.VVlaij = [totSel, totOk, totFail, path]
     VVXLiB.VVmZZM(action, totOk, FF65m2(row[0][0]))
 def VV1rFa(self, title, action, isMove, newPath, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  totSel, totOk, totFail, path = VVlaij
  txt  = "Total\t: %d\n" % totSel
  txt += "%s\t: %d\n"  % (action, totOk)
  if totFail   : txt += FFGB9z("Failed\t: %d\n" % totFail, VVsObI)
  if not VVeObj: txt += "%s\n%s" % (FFGB9z("\nCancelled while copying:", VVsObI), path)
  FF90Bc(self, txt, title=title)
  self.VVZvbR()
 def VV3i4q(self):
  tot = self["myMenu"].VVvB6E()
  FFNKVM(self, BF(FFJsIX, self, self.VVwbCS, title="Deleting ...", clearMsg=False), "Delete %d item%s ?" % (tot, FF1I1d(tot)), title="Delete Selection")
 def VVwbCS(self):
  path = self["myMenu"].VVbpXR()
  for row in self["myMenu"].list:
   if row[2][6]:
    FF1bsb(os.path.join(path, row[0][0]))
  FF5uKN(self)
  self.VVZvbR()
 def VVECWP(self, path, isMove):
  self.session.openWithCallback(BF(self.VVvrv9, isMove, path), BF(CCCXvS, mode=CCCXvS.VVutD6, VVMbDq=FF0y7s(path, False), VVDuqR="Move to here" if isMove else "Paste here"))
 def VVvrv9(self, isMove, src, dst):
  if not dst:
   return
  action = "Move" if isMove else "Copy"
  src = FFAxSo(src)
  if os.path.isfile(src) or os.path.islink(src): isFile, srcSubj = True , "File"
  else           : isFile, srcSubj = False, "Directory"
  title = "%s %s" % (action, srcSubj)
  src = FFAxSo(src)
  dst = os.path.join(dst, FF65m2(src))
  if src == dst:
   FFw5OO(self, "From:\n%s\n\n To:\n%s" % (src, dst), title=("Cannot %s %s to itself" % (action, srcSubj)).capitalize())
   return
  prams = title, isFile, isMove, srcSubj, src, dst
  if fileExists(dst) or pathExists(dst): FFNKVM(self, BF(self.VVKOB9, prams), "Overwrite Destination %s ?\n\n%s" % (srcSubj, dst), title=title)
  elif not isFile       : FFNKVM(self, BF(self.VVKOB9, prams), "Overwrite Destination Files", title=title)
  else         : self.VVKOB9(prams)
 def VVKOB9(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isMove and CCCXvS.VV6sdc(src) == CCCXvS.VV6sdc(dst):
   FFJsIX(self, BF(self.VVMvrx, prams), title="Moving %s ..." % srcSubj)
  else:
   FFJsIX(self, BF(self.VV9udf, prams), title="Calculating Size ...")
 def VVMvrx(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  res = FF3RLi("RES=$(mv -f '%s' '%s') && echo ok || echo $RES" % (src, dst))
  if res == "ok":
   self.VVZvbR()
  else:
   FFw5OO(self, "Error : %s\n\n%s" % (res, src), title=title)
 def VV9udf(self, prams):
  title, isFile, isMove, srcSubj, src, dst = prams
  if isFile: size = FFqLWj(src)
  else  : size = FFkSE4(src)
  if size > -1:
   self.session.open(CCmNws, barTheme=CCmNws.VV3z22, titleBg="#22220022", bodyBg="#22220022"
       , titlePrefix = "Moving %s ..." % srcSubj if isMove else "Copying %s ..." % srcSubj
       , fncToRun  = BF(self.VV3CPq, prams, size)
       , VVCeou = BF(self.VV8aRA, prams))
  else:
   FFw5OO(self, "Cannot get size for:\n\n%s" % src, title=title)
 def VV3CPq(self, prams, size, VVXLiB):
  title, isFile, isMove, srcSubj, src, dst = prams
  VVXLiB.VVCnyB(size)
  VVXLiB.VVlaij = ("", "", False)
  def VVzU5F(srcFile, dstFile):
   if os.path.islink(srcFile):
    if fileExists(dstFile):
     FFzyFM(dstFile)
    os.symlink(os.readlink(srcFile), dstFile)
   elif os.path.isfile(srcFile):
    with open(srcFile, "rb") as srcF:
     with open(dstFile, "wb") as dstF:
      while True:
       if not VVXLiB or VVXLiB.isCancelled:
        VVXLiB.VVlaij = (srcFile, "", True)
        FFzyFM(dstFile)
        return False
       try:
        data = srcF.read(1024)
        if not data:
         break
        dstF.write(data)
        VVXLiB.VV1Vtn(len(data))
       except Exception as e:
        VVXLiB.VVlaij = (srcFile, str(e), False)
        FFzyFM(dstFile)
        return False
   if iCopymode: iCopymode(srcFile, dstFile)
   if isMove: FFzyFM(srcFile)
   return True
  if isFile:
   tot = 1
   VVzU5F(src, dst)
  else:
   VVXLiB.VVHdrq("Calculating Dirs/Files ...")
   totDir, totFile, totLink = FF9Mxg(src)
   if not VVXLiB or VVXLiB.isCancelled:
    VVXLiB.VVlaij = ("", "", True)
    return
   tot = totFile + totLink
   fCount = 0
   for Dir, dirs, files in os.walk(src):
    files = os.listdir(Dir)
    dstDir = os.path.join(dst, Dir[len(src):].lstrip("/"))
    if not pathExists(dstDir):
     try:
      os.makedirs(dstDir)
     except Exception as e:
      VVXLiB.VVlaij = (os.path.join(Dir, f), str(e), False)
    for f in files:
     srcFile = os.path.join(Dir, f)
     dstFile = os.path.join(dst, srcFile[len(src):].lstrip("/"))
     if os.path.islink(srcFile) or os.path.isfile(srcFile):
      fCount += 1
      VVXLiB.VVHdrq("File: %d/%d >> %s" % (fCount, tot, f))
      if not VVzU5F(srcFile, dstFile):
       return
    if isMove and not os.listdir(Dir):
     FFuB0V("rm -fr '%s'" % Dir)
   if isMove:
    FFuB0V("rm -fr '%s'" % src)
 def VV8aRA(self, prams, VVeObj, VVlaij, threadCounter, threadTotal, threadErr):
  title, isFile, isMove, srcSubj, src, dst = prams
  lastFile, err, isCancelled = VVlaij
  if err:
   FFw5OO(self, "%s\n\n%s" % (err, lastFile), title=title + " ... Error")
  elif isCancelled:
   if isFile: FF5uKN(self, "Canelled", 1000)
   else  : FFw5OO(self, "Cancelled at file:\n\n%s" % lastFile if lastFile else "Process Stopped.", title=title + " ... Cancelled")
  else:
   FF5uKN(self, "Done", 1500, isGrn=True)
  if VVeObj and isMove:
   self.VVZvbR()
 def VVGo85(self, path, fileName):
  path = FFAxSo(path)
  if   os.path.islink(path) : pathType = "SymLink"
  elif os.path.isfile(path) : pathType = "File"
  elif os.path.isdir(path) : pathType = "Directory"
  elif os.path.ismount(path) : pathType = "Mount"
  else      : pathType = ""
  FFNKVM(self, BF(FFJsIX, self, BF(self.VVgbog, path), title="Deleting ...", clearMsg=False), "%s\n\nDelete %s ?" % (path, pathType), title="Delete %s" % pathType)
 def VVgbog(self, path):
  FF1bsb(path)
  FF5uKN(self)
  self.VVZvbR()
 def VVcCX2(self, path, isFile):
  dirName = FF1vNj(os.path.dirname(path))
  if isFile : objName, VVYwVo = "File"  , self.edited_newFile
  else  : objName, VVYwVo = "Directory" , self.edited_newDir
  title="Create New %s" % objName
  FFaSvq(self, BF(self.VVFE7E, dirName, isFile, title), title=title, defaultText=VVYwVo, message="Enter %s Name:" % objName)
 def VVFE7E(self, dirName, isFile, title, VVYwVo):
  if VVYwVo:
   if isFile : self.edited_newFile = VVYwVo
   else  : self.edited_newDir  = VVYwVo
   path = dirName + VVYwVo
   if not fileExists(path):
    if isFile : cmd = "touch '%s' %s" % (path, VV5wTt)
    else  : cmd = "mkdir '%s' %s" % (path, VV5wTt)
    result = FF3RLi(cmd)
    if "Fail" in result:
     FFw5OO(self, result)
    self.VVZvbR()
   else:
    FFw5OO(self, "Name already exists !\n\n%s" % path, title)
 def VV4oYf(self, path, selFile):
  c1, c2, c3 = VVkIQ9, VVUVAI, VVMrXw
  VVZJ87 = []
  VVZJ87.append((c1 + "List Package Files"         , "VVBLWB"     ))
  VVZJ87.append((c1 + "Package Information"         , "VV62VJ"     ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c2 + "Install Package"          , "VViBiV_CheckVersion" ))
  VVZJ87.append((c2 + "Install Package (force reinstall)"     , "VViBiV_ForceReinstall" ))
  VVZJ87.append((c2 + "Install Package (force overwrite)"     , "VViBiV_ForceOverwrite" ))
  VVZJ87.append((c2 + "Install Package (force downgrade)"     , "VViBiV_ForceDowngrade" ))
  VVZJ87.append((c2 + "Install Package (ignore failed dependencies)"  , "VViBiV_IgnoreDepends" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c3 + "Remove Related Package"        , "VVTNT5_ExistingPackage" ))
  VVZJ87.append((c3 + "Remove Related Package (force remove)"    , "VVTNT5_ForceRemove"  ))
  VVZJ87.append((c3 + "Remove Related Package (ignore failed dependencies)" , "VVTNT5_IgnoreDepends" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Extract Files"           , "VVOy2R"     ))
  VVZJ87.append(("Unbuild Package"           , "VV6rH8"     ))
  FFYySC(self, BF(self.VV9E0f, path, selFile), VVZJ87=VVZJ87)
 def VV9E0f(self, path, selFile, item=None):
  if item is not None:
   if   item == "VVBLWB"      : self.VVBLWB(path, selFile)
   elif item == "VV62VJ"      : self.VV62VJ(path)
   elif item == "VViBiV_CheckVersion"  : self.VViBiV(path, selFile, VV33Lu     )
   elif item == "VViBiV_ForceReinstall" : self.VViBiV(path, selFile, VVDaFy )
   elif item == "VViBiV_ForceOverwrite" : self.VViBiV(path, selFile, VV57oW )
   elif item == "VViBiV_ForceDowngrade" : self.VViBiV(path, selFile, VVygvf )
   elif item == "VViBiV_IgnoreDepends" : self.VViBiV(path, selFile, VVfGaS )
   elif item == "VVTNT5_ExistingPackage" : self.VVTNT5(path, selFile, VVi1yR     )
   elif item == "VVTNT5_ForceRemove"  : self.VVTNT5(path, selFile, VVbez3  )
   elif item == "VVTNT5_IgnoreDepends"  : self.VVTNT5(path, selFile, VV0vnU )
   elif item == "VVOy2R"     : self.VVOy2R(path, selFile)
   elif item == "VV6rH8"     : self.VV6rH8(path, selFile)
   else           : self.close()
 def VVBLWB(self, path, selFile):
  if FFhcfU("ar") : cmd = "allOK='1';"
  else    : cmd  = FFcMGy()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  echo -e '%s\nFile:\n%s\n';" % (SEP, path)
  cmd += "  echo -e '%s\n--- Contents:\n%s';" % (SEP, SEP)
  cmd += "  ar -t '%s';" % path
  cmd += "fi;"
  FFvYk0(self, cmd, VVYxQ2=self.VVZvbR)
 def VVOy2R(self, path, selFile):
  lastPart = FF65m2(path)
  dest  = FF0y7s(path, True) + selFile[:-4]
  cmd  =  FFcMGy()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=    FFIV1X("mkdir '%s'" % dest) + ";"
  cmd +=    FFIV1X("cd '%s'" % dest) + ";"
  cmd += "  echo 'Extrcting files ...';"
  cmd += "  ar -xo '%s';" % path
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e 'Output Directory:\n%s' %s;" % (dest, FFXRSi(dest, VVVjNM))
  cmd += "fi;"
  FF1Q61(self, cmd, VVYxQ2=self.VVZvbR)
 def VV6rH8(self, path, selFile):
  if path.endswith((".ipk", ".deb")) : VV31vM = os.path.splitext(path)[0]
  else        : VV31vM = path + "_"
  if path.endswith(".deb")   : VVTjtN = "DEBIAN"
  else        : VVTjtN = "CONTROL"
  cmd  = FFcMGy()
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd += "  rm -rf '%s' %s;"   % (VV31vM, FFZSD6())
  cmd += "  mkdir '%s';"    % VV31vM
  cmd += "  CONTPATH='%s/%s';"  % (VV31vM, VVTjtN)
  cmd += '  mkdir "$CONTPATH";'
  cmd += "  cd '%s';"     % VV31vM
  cmd += "  echo 'Unpacking ...';"
  cmd += "  ar -x '%s';"    % path
  cmd += "  FILE='%s/data.tar.gz';    [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VV31vM, VV31vM)
  cmd += "  FILE='%s/control.tar.gz'; [ -f \"$FILE\" ] && tar -xzf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VV31vM
  cmd += "  FILE='%s/data.tar.xz';    [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C '%s'          && rm -f \"$FILE\";" % (VV31vM, VV31vM)
  cmd += "  FILE='%s/control.tar.xz'; [ -f \"$FILE\" ] && tar -xJf \"$FILE\" -C \"$CONTPATH\" && rm -f \"$FILE\";" %  VV31vM
  cmd += "  FILE='%s/debian-binary';  [ -f \"$FILE\" ]                                        && rm -f \"$FILE\";" %  VV31vM
  cmd += "  echo -e 'Done.\n';"
  cmd += "  echo -e '\nOutput Directory:\n%s' %s;" % (VV31vM, FFXRSi(VV31vM, VVVjNM))
  cmd += "fi;"
  FF1Q61(self, cmd, VVYxQ2=self.VVZvbR)
 def VV62VJ(self, path):
  listCmd  = FF8jae(VVcrnB, "")
  infoCmd  = FFETOG(VVqsbt , "")
  filesCmd = FFETOG(VVWyGQ, "")
  if listCmd and infoCmd and filesCmd:
   txt  = "Installed-Time: "
   sep  = FFgg7s(VVVCGb)
   notInst = "Package not installed."
   cmd  = FFfCOf("File Info", VVVCGb)
   cmd += "FILE='%s';" % path
   cmd += "echo -e 'File = '$FILE'\n';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " %s \"$FILE\" | sed 's/:/\t:/g';" % infoCmd
   cmd +=   FFfCOf("System Info", VVVCGb)
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  echo -e '%s\n' %s;" % (notInst, FFXRSi(notInst, VVsObI))
   cmd += " else"
   cmd += "  %s $PACK | sed 's/:/\t:/g';" % infoCmd
   cmd += "  TIME=$(%s $PACK | grep %s | sed 's/%s//g');" % (infoCmd, txt, txt)
   cmd += "  HTIME=$(date -d @$TIME);"
   cmd += "  echo %s$HTIME | sed 's/: /\t: /g';" % txt
   cmd += "  echo '';"
   cmd +=    FFfCOf("Related Files", VVVCGb)
   cmd += "  %s $PACK | awk 'NR<2{print $0;next}{print $0| \"sort\"}' | sed 's/files:/files:\\n/g';" % filesCmd
   cmd += " fi;"
   cmd += "fi;"
   cmd += "echo '';"
   cmd += sep
   FFleea(self, cmd)
  else:
   FFgq4o(self)
 def VViBiV(self, path, selFile, cmdOpt):
  cmd = FFETOG(cmdOpt, path)
  if cmd:
   cmd = "%s && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'" % cmd
   FFNKVM(self, BF(FF1Q61, self, cmd, VVYxQ2=FFsMPf), "Install Package ?\n\n%s" % selFile)
  else:
   FFgq4o(self)
 def VVTNT5(self, path, selFile, cmdOpt):
  listCmd  = FF8jae(VVcrnB, "")
  infoCmd  = FFETOG(VVqsbt, "")
  instRemCmd = FFETOG(cmdOpt    , "")
  if listCmd and infoCmd and instRemCmd:
   result  = " && echo -e '\nSUCCESSFUL' || echo -e '\nERROR FOUND !'"
   cannotTxt = "Cannot remove with Packaging Tools!"
   tryTxt  = "Try to delete the directory:"
   errTxt  = "Package not found by Packaging Tools!"
   cmd  = "FILE='%s';" % path
   cmd += "echo -e 'Reading package name ...';"
   cmd += "PACK=$(%s \"$FILE\" | grep Package | sed 's/Package: //g');" % infoCmd
   cmd += "if [[ -z \"$PACK\" ]]; then "
   cmd += " echo -e 'Cannot read Package Name from file.\n';"
   cmd += "else"
   cmd += " echo 'Package = '$PACK;"
   cmd += " FOUND=$(%s | grep $PACK);" % listCmd
   cmd += " if [[ -z \"$FOUND\" ]]; then "
   cmd += "  pNAME=$(echo $PACK | awk -F- '{print $NF}');"
   cmd += "  tLOC=$(find %s -iname $pNAME);" % resolveFilename(SCOPE_PLUGINS)
   cmd += "  if [[ -z \"$tLOC\" ]]; then "
   cmd += "   echo -e '\n%s' %s;" % (errTxt, FFXRSi(errTxt, VVsObI))
   cmd += "  else"
   cmd += "   echo -e '\n%s' %s;" % (cannotTxt, FFXRSi(cannotTxt, VVsObI))
   cmd += "   echo -e '\n%s' %s;" % (tryTxt, FFXRSi(tryTxt, VVsObI))
   cmd += "   echo $tLOC;"
   cmd += "  fi;"
   cmd += " else"
   cmd += "  %s $PACK %s;" % (instRemCmd, result)
   cmd += " fi;"
   cmd += "fi"
   cmdIsOK = True
   FFNKVM(self, BF(FF1Q61, self, cmd, VVYxQ2=FFsMPf), "Remove package related to this file ?\n\n%s" % selFile)
  else:
   FFgq4o(self)
 def VVS8D7(self, path):
  hostName = FF3RLi("hostname").lower()
  kernelFile = path + hostName + "/kernel.bin"
  rootfsFile = path + hostName + "/rootfs.tar.bz2"
  versionFile = path + hostName + "/imageversion"
  return hostName, kernelFile, rootfsFile, versionFile
 def VVTLv8(self, path, isDir):
  txt1 = "Archive to "
  txt2 = "Archive (Preserve Path Structure) to "
  VVZJ87 = []
  VVZJ87.append(("%s.tar"  % txt1 , "archDir_tar"  ))
  VVZJ87.append(("%s.tar.gz" % txt1 , "archDir_tar_gz" ))
  VVZJ87.append(("%s.tar.xz" % txt1 , "archDir_tar_xz" ))
  VVZJ87.append(("%s.tar.bz2" % txt1 , "archDir_tar_bz2" ))
  VVZJ87.append(("%s.zip"  % txt1 , "archDir_zip"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("%s.tar"  % txt2 , "archPath_tar" ))
  VVZJ87.append(("%s.tar.gz" % txt2 , "archPath_tar_gz" ))
  VVZJ87.append(("%s.tar.xz" % txt2 , "archPath_tar_xz" ))
  VVZJ87.append(("%s.tar.bz2" % txt2 , "archPath_tar_bz2"))
  VVZJ87.append(("%s.zip"  % txt2 , "archPath_zip" ))
  if isDir and not self.multiSelectState:
   VVZJ87.append(VVoqHH)
   VVZJ87.append(('Convert to ".ipk" Package', "convertDirToIpk" ))
   VVZJ87.append(('Convert to ".deb" Package', "convertDirToDeb" ))
  if isDir: c1, c2, title = "#11003322", "#11002222", "Archive Directory"
  else : c1, c2, title = "#11003344", "#11002244", "Archive File"
  FFYySC(self, BF(self.VVkDqs, path, isDir, title), VVZJ87=VVZJ87, title=title, VVDlGi=c1, VVaSSM=c2)
 def VVkDqs(self, path, isDir, title, item):
  if item is not None:
   if   item == "archDir_tar"  : self.VVgH1R(title, path, isDir, ".tar" , False)
   elif item == "archDir_tar_gz" : self.VVgH1R(title, path, isDir, ".tar.gz" , False)
   elif item == "archDir_tar_xz" : self.VVgH1R(title, path, isDir, ".tar.xz" , False)
   elif item == "archDir_tar_bz2" : self.VVgH1R(title, path, isDir, ".tar.bz2", False)
   elif item == "archDir_zip"  : self.VVgH1R(title, path, isDir, ".zip" , False)
   elif item == "archPath_tar"  : self.VVgH1R(title, path, isDir, ".tar" , True)
   elif item == "archPath_tar_gz" : self.VVgH1R(title, path, isDir, ".tar.gz" , True)
   elif item == "archPath_tar_xz" : self.VVgH1R(title, path, isDir, ".tar.xz" , True)
   elif item == "archPath_tar_bz2" : self.VVgH1R(title, path, isDir, ".tar.bz2", True)
   elif item == "archPath_zip"  : self.VVgH1R(title, path, isDir, ".zip" , True)
   elif item == "convertDirToIpk" : self.VVmcmB(path, False)
   elif item == "convertDirToDeb" : self.VVmcmB(path, True)
 def VVmcmB(self, path, VVFsmA):
  self.session.openWithCallback(self.VVZvbR, BF(CCjJUX, path=path, VVFsmA=VVFsmA))
 def VVgH1R(self, title, path, isDir, fileExt, preserveDirStruct):
  parent  = FF0y7s(path, True)
  lastPart = FF65m2(path)
  archFile = lastPart + fileExt
  resultFile = parent + archFile
  if preserveDirStruct:
   archFile = resultFile
   targetDir = parent + lastPart
  else:
   targetDir = lastPart
  if isDir: outFile, srcTxt = archFile , "Source Directory"
  else : outFile, srcTxt = resultFile , "Source File"
  if   fileExt == ".tar"  : archCmd, toolCmd = "tar -cvf"  , "allOK='1';"
  elif fileExt == ".tar.gz" : archCmd, toolCmd = "tar -cvzf" , "allOK='1';"
  elif fileExt == ".tar.xz" : archCmd, toolCmd = "tar -cvJf" , FF09Tg("xz" , "xz"  , "XZ"  )
  elif fileExt == ".tar.bz2" : archCmd, toolCmd = "tar -cvjf" , FF09Tg("bzip2" , "bzip2" , "BZip2" )
  elif fileExt == ".zip"  : archCmd, toolCmd = "zip -r"  , FF09Tg("zip" , "zip"  , "Zip"  )
  if preserveDirStruct:
   if archCmd.startswith("tar") and targetDir.startswith("/") : archCmd = "%s '%s' -C / '%s';" % (archCmd, outFile, targetDir[1:])
   else              : archCmd = "%s '%s' '%s';"    % (archCmd, outFile, targetDir)
  else:
   if isDir: archCmd = "cd '%s'; %s '../%s' *;" % (path, archCmd, outFile)
   else : archCmd = "cd '%s'; %s '%s' '%s';" % (parent, archCmd, outFile, os.path.basename(path))
  failed = "Process failed !"
  sep  = " echo -e '%s';" % SEP
  cmd  = toolCmd
  cmd += "echo -e 'Archiving ...\n';"
  cmd += 'if [ "$allOK" -eq "1" ]; then '
  cmd +=   sep
  cmd +=   FFIV1X("rm -f '%s'" % archFile) + ";"
  cmd +=   archCmd
  cmd += " cd '%s';"      % parent
  cmd +=   sep
  cmd += " if [ $? -ne 0 ]; then "
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFXRSi(failed, VVLbyB))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " elif [ -f '%s' ]; then "  % archFile
  cmd += "  chmod 644 '%s';"    % archFile
  cmd += "  echo -e '\nDONE\n';"
  cmd += "  echo -e '%s:' %s;"   % (srcTxt, FFXRSi(srcTxt, VVkqaK))
  cmd += "  echo -e '%s:\n';"    % path
  cmd += "  echo -e '%s:' %s;"   % ("Output", FFXRSi("Output", VVVjNM))
  cmd += "  echo -e '%s\n';"    % outFile
  cmd += " else"
  cmd += "  echo -e '\n%s\n' %s;"   % (failed, FFXRSi(failed, VVGe5h))
  cmd += "  rm -f '%s' > /dev/null 2>&1;" % archFile
  cmd += " fi;"
  cmd +=   sep
  cmd += "fi;"
  FFvYk0(self, cmd, VVYxQ2=self.VVZvbR, title=title)
 def VV0B8T(self, path, isAll):
  if isAll: title, pathLst = "Add all Media in Directory to a Bouquet", CCCXvS.VVtupS(FF0y7s(path, True))
  else : title, pathLst = "Add Media File to a Bouquet"   , [path]
  picker = CCSrvY(self, self, title, BF(self.VVnPKx, pathLst))
 def VVnPKx(self, pathLst):
  return CCSrvY.VVlFFp(pathLst)
 def VV777S(self, zipPath):
  title = "Convert .zip to .tar.gz"
  if iZip.is_zipfile(zipPath):
   tarPath = os.path.splitext(zipPath)[0] + ".tar.gz"
   fnc  = BF(self.VVLl3W, zipPath, tarPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFNKVM(self, BF(FFJsIX, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFJsIX(self, fnc, title=txt)
  else:
   FFw5OO(self, "Invalid zip file:\n\n%s" % os.path.basename(zipPath), title=title)
 def VVLl3W(self, zipPath, tarPath, title):
  try:
   with iZip.ZipFile(zipPath) as zipF:
    with iTar.open(tarPath, "w:gz") as tarF:
     for zipInfo in zipF.infolist():
      tarInfo = iTar.TarInfo(name=zipInfo.filename)
      tarInfo.size = zipInfo.file_size
      tarInfo.mtime = mktime(tuple(list(zipInfo.date_time) + [-1, -1, -1]))
      tarF.addfile(tarinfo=tarInfo, fileobj=zipF.open(zipInfo.filename))
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FF90Bc(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(zipPath), os.path.basename(tarPath)), title=title)
   self.VVZvbR()
  else:
   FFzyFM(tarPath)
   FFw5OO(self, "Error while converting.", title=title)
 def VV7qiv(self, tarPath):
  title = "Convert .tar.gz to .zip"
  if iTar.is_tarfile(tarPath):
   zipPath = tarPath[:-7] + ".zip"
   fnc  = BF(self.VVDeDI, tarPath, zipPath, title)
   txt  = "Converting ..."
   if fileExists(tarPath) : FFNKVM(self, BF(FFJsIX, self, fnc, title=txt), "File already exists:\n\n%s\n\nOverwrite ?" % os.path.basename(tarPath), title=title)
   else     : FFJsIX(self, fnc, title=txt)
  else:
   FFw5OO(self, "Invalid tar file:\n\n%s" % os.path.basename(tarPath), title=title)
 def VVDeDI(self, tarPath, zipPath, title):
  try:
   with iTar.open(tarPath) as tar:
    with iZip.ZipFile(zipPath, mode='w', compression=iZip.ZIP_DEFLATED) as zipF:
     for mem in tar.getmembers():
      if mem.isfile():
       mtime = datetime.fromtimestamp(mem.mtime)
       zipInfo = iZip.ZipInfo(filename=mem.name, date_time=(mtime.year, mtime.month, mtime.day, mtime.hour, mtime.minute, mtime.second))
       zipF.writestr(zipInfo, tar.extractfile(mem).read(), compress_type=iZip.ZIP_DEFLATED)
   ok = True
  except:
   ok = False
  if ok and fileExists(tarPath):
   FF90Bc(self, "Done\n\nSource File\t: %s\nOutput File\t: %s" % (os.path.basename(tarPath), os.path.basename(zipPath)), title=title)
   self.VVZvbR()
  else:
   FFzyFM(zipPath)
   FFw5OO(self, "Error while converting.", title=title)
 def VVBvnH(self, path, isFhd):
  size = "1920x1080" if isFhd else "1280x720"
  title = "Convert to MVI (%s)" % size
  Dir  = FF1vNj(os.path.dirname(path))
  filName = os.path.splitext(os.path.basename(path))[0]
  m1v  = "%s%s_%s.m1v" % (Dir, filName, size)
  mvi  = "%s%s_%s.mvi" % (Dir, filName, size)
  FFuB0V("rm -f '%s' '%s'" % (m1v, mvi))
  if FFuB0V("ffmpeg -i '%s' -r 25 -b:v 20000 -s %s '%s'" % (path, size, m1v)) and fileExists(m1v):
   FFuB0V("mv -f '%s' '%s'" % (m1v, mvi))
   self.VVZvbR()
   FF15cM(self, "Converted to:\n\n%s" % os.path.basename(mvi), title=title)
  else:
   FFw5OO(self, "Cannot convert this file !", title=title)
 def VV91tE(self, path):
  title = "Set as PIcon for current channel"
  pPath = CCijoe.VV4boJ()
  if pathExists(pPath):
   if CCMSfE.VVftxD(self, title, False, cbFnc=BF(self.VV91tE, path)):
    refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
    picon = "%s%s.png" % (pPath, refCode.strip(":").replace(":", "_").upper())
    VVZJ87 = []
    for item in ((50,30),(96,64),(100,60),(220,132),(400,160),(400,240),(500,300)):
     VVZJ87.append(("%d x %d" % (item), item))
    VVXyZL = self.VVvlCv
    VV2YYF = ("Stretch", BF(self.VVsFMa, title, path, picon))
    VV4EHV = FFYySC(self, BF(self.VVNWwu, title, path, picon, False), VVZJ87=VVZJ87, width=700, title='PIcon Max. Size', VVXyZL=VVXyZL, VV2YYF=VV2YYF, barText="OK = Fit within size")
    VV4EHV.VV6zBC(3)
  else:
   FFw5OO(self, "PIcons path not found:\n\n%s\n\n( You can change it in Settings )" % pPath, title=title)
 def VVsFMa(self, title, path, picon, VVbBRSObj, item):
  self.VVNWwu(title, path, picon, True, item)
  VVbBRSObj.cancel()
 def VVNWwu(self, title, path, picon, stretch, sz=None):
  if sz:
   try:
    from PIL import Image
    im = Image.open(path)
    if stretch: im = im.resize(sz, Image.ANTIALIAS)
    else   : im.thumbnail(sz)
    im.save(picon)
    FFcpNw(self, fncMode=CCjQ0P.VV2TAI)
   except Exception as e:
    FFw5OO(self, "Image Processing error:\n\n%s" % e)
 def VVvlCv(self, VV4EHV, txt, ref, ndx):
  FFqsYG(self, "_help_resize", "Picture File Resizing")
 def VVJI1S(self, path):
  FFYySC(self, BF(self.VVhSRX, path), VVZJ87=CC9X9s.VVrdGZ(), width=650, title="Select Player", VVDlGi="#11220000", VVaSSM="#11220000")
 def VVhSRX(self, path, rType=None):
  if rType:
   FFJsIX(self, BF(self.VVDPDb, self, path, rType), title="Playing Media ...")
 @staticmethod
 def VVDPDb(SELF, path, rType=""):
  try:
   if   rType     : prefix = rType
   elif path.endswith(".ts") : prefix = "1"
   elif path.endswith(".m2ts") : prefix = "3"
   else      : prefix = CFG.iptvAddToBouquetRefType.getValue()
   refCode = "%s:%s%s" % (prefix, "0:" * 9, path)
   SELF.session.nav.playService(eServiceReference(refCode))
   CCb9j4.VV6JFp(SELF.session, enableZapping= False, enableDownloadMenu=False)
  except:
   pass
 @staticmethod
 def VV6Qx4(SELF):
  serv = SELF.session.nav.getCurrentlyPlayingServiceReference()
  fPath = serv and serv.getPath()
  if fPath and fileExists(fPath):
   fDir, fName = os.path.split(fPath)
   return fPath, FF1vNj(fDir), fName
  return "", "", ""
 @staticmethod
 def VVlZtT(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_blocks
 @staticmethod
 def VVOsjP(path):
  Stat = os.statvfs(path)
  return Stat.f_frsize * Stat.f_bfree
 @staticmethod
 def VVutW7(size, mode=0):
  txt = CCCXvS.VViVOR(size)
  if size >= 1024 :
   commaSize = format(size, ',d')
   if mode == 1: return "%s (%s)"   % (txt, commaSize)
   if mode == 2: return "%s (%s)"   % (commaSize, txt)
   if mode == 3: return "%s (%s)"   % (size, txt)
   if mode == 4: return "%s"    % txt
   else  : return "%s  ( %s bytes )" % (txt, commaSize)
  else:
   return txt
 @staticmethod
 def VViVOR(bytes):
  kilo, unit = 1024.0, ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
  if bytes < kilo:
   return "%d B" % bytes
  i = int(iFloor(iLog(bytes, 1024)))
  s = str("%.2f" % (bytes / (kilo ** i))).rstrip(".0")
  return "%s %s" % (s, unit[i])
 @staticmethod
 def VVkuoi(path):
  rangeList = list(range(0x20, 0x100))
  with open(path, 'rb') as f:
   bytes = f.read(1024)
  textchars = bytearray({7,8,9,10,12,13,27} | set(rangeList) - {0x7f})
  return bool(bytes.translate(None, textchars))
 @staticmethod
 def VVJWb9(SELF, path, title=""):
  try:
   with ioOpen(path, "r", encoding="UTF-8") as f:
    txt = f.read()
   return True
  except:
   if title:
    FFw5OO(SELF, "File is not in 'UTF-8' Encoding:\n\n%s" % path, title=title)
   return False
 @staticmethod
 def VV3Mcc():
  tDict = CCA8jA.VV1p4d()
  lst = list(tDict["mov"])
  lst.extend(list(tDict["mus"]))
  return tuple(lst)
 @staticmethod
 def VVtupS(path):
  lst = []
  for ext in CCCXvS.VV3Mcc():
   lst.extend(FFzSvJ(path, "*.%s" % ext))
  return sorted(lst, key=FFDgxV(FFAyBN))
 @staticmethod
 def VV7YC3(path):
  return FFuB0V("tar -tzf '%s'" % path)
 @staticmethod
 def VV6sdc(path):
  path = os.path.abspath(path)
  while not os.path.ismount(path):
   path = os.path.dirname(path)
  return path
 @staticmethod
 def VVgw5W(lst, fromFind=True):
  if len(lst) == 1 and lst[0] == VVzo6v:
   return VVzo6v
  elif fromFind:
   for line in lst:
    span = iSearch(r"find:\s*(.+):\s*Input\/output error", line, IGNORECASE)
    if span:
     return 'Filesystem Error in:\n\n%s' % span.group(1)
  return ""
class CCA8jA(MenuList):
 VVyGN7   = 0
 VVr5f1   = 1
 VV5iqA   = 2
 VVgyFx   = 3
 VV8kbc   = 4
 VVzy1d   = 5
 VV78Sa   = 6
 VVs8tJ   = 7
 VV2eDT   = "<List of Storage Devices>"
 VVUfaS  = "<Parent Directory>"
 VVBhvm   = 0
 VV3zSZ   = 1
 VVSUfE = 2
 VVemwh  = 3
 VVuc05   = 4
 VV4Uf8   = 5
 FILE_TYPE_LINK   = 6
 VV8wHe  = 7
 PROHIBITED_FILES  = ["/%s/" % x for x in ("DEBIAN","bin","boot","dev","etc","hdd","home","lib","media","mnt","network","proc","run","sbin","sys","tmp","usr","var")]
 def __init__(self, VVfGT7=False, directory="/", VV65hB=True, VVnjO1=True, VVfklg=True, VVQtTJ=None, VVYgJg=False, VVk8ZO=False, VVmPgp=False, isTop=False, VVEGDe=None, VVx14V=1000, VVTFXq=30, VVNyBH=30):
  MenuList.__init__(self, list, VVfGT7, eListboxPythonMultiContent)
  self.VV65hB  = VV65hB
  self.VVnjO1    = VVnjO1
  self.VVfklg  = VVfklg
  self.VVQtTJ  = VVQtTJ
  self.VVYgJg   = VVYgJg
  self.VVk8ZO   = VVk8ZO or []
  self.VVmPgp   = VVmPgp or []
  self.isTop     = isTop
  self.additional_extensions = VVEGDe
  self.VVx14V    = VVx14V
  self.VVTFXq    = VVTFXq
  self.VVNyBH    = VVNyBH
  self.EXTENSIONS    = CCA8jA.VV1p4d()
  self.VVkVSB   = eServiceCenter.getInstance()
  self.mountpoints   = []
  self.current_directory  = None
  self.current_mountpoint  = None
  self.multiSelect_color  = FFkR1T("#11ff4444")
  self.l.setFont(0, gFont(VVR8AG, self.VVTFXq))
  self.l.setItemHeight(self.VVNyBH)
  self.png_mem   = CCA8jA.VV4Yr5("mem")
  self.png_usb   = CCA8jA.VV4Yr5("usb")
  self.png_fil   = CCA8jA.VV4Yr5("fil")
  self.png_dir   = CCA8jA.VV4Yr5("dir")
  self.png_dirup   = CCA8jA.VV4Yr5("dirup")
  self.png_srv   = CCA8jA.VV4Yr5("srv")
  self.png_slwfil   = CCA8jA.VV4Yr5("slwfil")
  self.png_slbfil   = CCA8jA.VV4Yr5("slbfil")
  self.png_slwdir   = CCA8jA.VV4Yr5("slwdir")
  self.VVu5ID()
  self.VVb5JY(directory)
 @staticmethod
 def VV4Yr5(category):
  return LoadPixmap("%s%s.png" % (VVrrZu, category), getDesktop(0))
 @staticmethod
 def VV1p4d():
  return {"pic":("bmp","gif","jpe","jpeg","jpg","png"),"mov":("3g2","3gp","asf","avi","divx","flv","ifo","iso","m2ts","m4v","mkv","mod","mov","mp4","mpe","mpeg","mpg","mts","mvi","ogm","ogv","pva","rm","rmvb","stream","ts","vob","webm","wmv","wtv","h264","h265","mjpeg","mk3d","mks","xvid"),"mus":("aac","ac3","alac","amr","ape","au","dts","flac","m2a","m4a","mid","mka","mp2","mp3","oga","ogg","wav","wave","wma","wv","m3u","m4b","m4p","mpc","wpl"),"txt":("cfg","conf","htm","html","py","txt","xml"),"tar":("bz2","gz","tar","xz"),"rar":("rar"),"zip":("zip"),"ipk":("ipk"),"deb":("deb"),"scr":("sh"),"m3u":("m3u","m3u8")}
 def VVxfdW(self, name, absolute=None, isDir=False, typ=None, png=None):
  if absolute and isDir:
   path = absolute
   path = FFAxSo(path)
   if os.path.islink(path):
    png = self.png_slwdir
    name += FFGB9z(" -> " , VVVCGb) + FFGB9z(os.readlink(path), VVVjNM)
  tableRow = [ (absolute, isDir, typ) ]
  tableRow.append((eListboxPythonMultiContent.TYPE_TEXT, self.VVNyBH + 10, 0, self.VVx14V, self.VVNyBH, 0, LEFT | RT_VALIGN_CENTER, name))
  if png is not None:
   if VVnvLp: tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVNyBH-4, self.VVNyBH-4, png, None, None, VVnvLp))
   else   : tableRow.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 0, 2, self.VVNyBH-4, self.VVNyBH-4, png, None, None))
  return tableRow
 def VV79WD(self, name):
  ext = os.path.splitext(name)[1]
  if ext:
   ext = ext.lstrip(".").lower()
   for cat, lst in self.EXTENSIONS.items():
    if ext in lst:
     return cat
  return ""
 def VVu5ID(self):
  self.mountpoints = [os.path.join(p.mountpoint, "") for p in harddiskmanager.getMountedPartitions()]
  self.mountpoints.sort(reverse=True)
 def VV4KMM(self, file):
  file = os.path.join(os.path.realpath(file), "")
  for m in self.mountpoints:
   if file.startswith(m):
    return m
  return False
 def VVy313(self, file):
  if os.path.realpath(file) == file:
   return self.VV4KMM(file)
  else:
   if file[-1] == "/":
    file = file[:-1]
   mp = self.VV4KMM(file)
   last = file
   file = os.path.dirname(file)
   while last != "/" and mp == self.VV4KMM(file):
    last = file
    file = os.path.dirname(file)
   return os.path.join(last, "")
 def getSelection(self):
  if self.l.getCurrentSelection() is None:
   return None
  return self.l.getCurrentSelection()[0]
 def VVmD2t(self):
  ndx = self.l.getCurrentSelectionIndex()
  row = self.list[ndx]
  bg = self.multiSelect_color if row[2][6] == None else None
  ndx = self.getSelectionIndex()
  if ndx < len(self.list) - 1:
   self.moveToIndex(self.getSelectionIndex() + 1)
  iconData = self.VVevJ5(row, bg)
  if iconData:
   row[2] = iconData
   self.l.setList(self.list)
   return True
  else:
   return False
 def VV7OzW(self, isSel):
  bg = self.multiSelect_color if isSel else None
  for ndx, row in enumerate(self.list):
   iconData = self.VVevJ5(row, bg)
   if iconData:
    row[2] = iconData
  self.l.setList(self.list)
 def VVevJ5(self, row, bg):
  if self.VVclz4(row):
   iconData = list(row[2])
   iconData[6] = bg
   iconData[7] = bg
   return tuple(iconData)
  else:
   return None
 def VVclz4(self, row):
  if not row[0][0] in self.mountpoints:
   if   row[0][2] in (self.VV4Uf8, self.FILE_TYPE_LINK): return True
   elif row[0][2] == self.VVuc05:
    if   VVoWDM           : return True
    elif not row[0][0] in self.PROHIBITED_FILES    : return True
  return False
 def VVo11O(self):
  return self.VVclz4(self.list[self.l.getCurrentSelectionIndex()])
 def VVvB6E(self):
  tot = 0
  for row in self.list:
   if row[2][6]:
    tot += 1
  return tot
 def VVY3Q2(self, dir, parents):
  dir = os.path.realpath(dir)
  for p in parents:
   if dir.startswith(p):
    return True
  return False
 def VVb5JY(self, directory, selItem=None):
  self.list = []
  directories = []
  files = []
  if self.current_directory is None:
   if directory and self.VVfklg:
    self.current_mountpoint = self.VVy313(directory)
   else:
    self.current_mountpoint = None
  self.current_directory = directory
  if directory is None:
   if self.VVfklg:
    for p in harddiskmanager.getMountedPartitions():
     path = os.path.join(p.mountpoint, "")
     if path not in self.VVmPgp and not self.VVY3Q2(path, self.VVk8ZO):
      if path == "/" : png = self.png_mem
      else   : png = self.png_usb
      self.list.append(self.VVxfdW(name=p.description, absolute=path, isDir=True, typ=self.VVBhvm, png=png))
    path = "/"
    if path not in self.VVmPgp and not self.VVY3Q2(path, self.VVk8ZO):
     for item in self.list:
      if path == item[0][0]:
       break
     else:
      self.list.append(self.VVxfdW(name="INTERNAL FLASH", absolute="/", isDir=True, typ=self.VV3zSZ, png=self.png_mem))
  elif self.VVYgJg:
   root = eServiceReference(2, 0, directory)
   if self.additional_extensions:
    root.setName(self.additional_extensions)
   VVkVSB = eServiceCenter.getInstance()
   list = VVkVSB.list(root)
   while 1:
    s = list.getNext()
    if not s.valid():
     del list
     break
    if s.flags & s.mustDescent:
     directories.append(s.getPath())
    else:
     files.append(s)
  else:
   if fileExists(directory):
    try:
     files = os.listdir(directory)
    except:
     files = []
    tmpfiles = files[:]
    for x in tmpfiles:
     if os.path.isdir(directory + x):
      directories.append(directory + x + "/")
      files.remove(x)
  if directory is not None and self.VV65hB and not self.isTop:
   if directory == self.current_mountpoint and self.VVfklg:
    self.list.append(self.VVxfdW(name=self.VV2eDT, absolute=None, isDir=True, typ=self.VVSUfE, png=self.png_dirup))
   elif (directory != "/") and not (self.VVmPgp and self.VV4KMM(directory) in self.VVmPgp):
    self.list.append(self.VVxfdW(name=self.VVUfaS, absolute='/'.join(directory.split('/')[:-2]) + '/', isDir=True, typ=self.VVemwh, png=self.png_dirup))
  if self.VV65hB:
   for x in directories:
    if not (self.VVmPgp and self.VV4KMM(x) in self.VVmPgp) and not self.VVY3Q2(x, self.VVk8ZO):
     name = x.split('/')[-2]
     if x in self.mountpoints: png = self.png_usb
     else     : png = self.png_dir
     self.list.append(self.VVxfdW(name=name, absolute=x, isDir=True, typ=self.FILE_TYPE_LINK if os.path.islink(FFAxSo(x)) else self.VVuc05, png=png))
  if self.VVnjO1:
   for x in files:
    if self.VVYgJg:
     path = x.getPath()
     name = path.split('/')[-1]
     png  = self.png_srv
    else:
     path = directory + x
     name = x
     png  = self.png_fil
     if os.path.islink(path):
      try:
       target = os.readlink(path)
       if fileExists(target):
        png = self.png_slwfil
        name += FFGB9z(" -> " , VVVCGb) + FFGB9z(target, VVVjNM)
       else:
        png = self.png_slbfil
        name += FFGB9z(" -> " , VVVCGb) + FFGB9z(target, VVGe5h)
      except:
       png = self.png_slbfil
     elif "." in name:
      category = self.VV79WD(name)
      if category:
       png = LoadPixmap("%s%s.png" % (VVrrZu, category))
    if (self.VVQtTJ is None) or iCompile(self.VVQtTJ[0], flags=self.VVQtTJ[1]).search(path):
     self.list.append(self.VVxfdW(name=name, absolute=x , isDir=False, typ=self.VV4Uf8, png=png))
  if self.VVfklg and len(self.list) == 0:
   self.list.append(self.VVxfdW(name=FFGB9z("No USB connected", VVGb6D), absolute=None, isDir=False, typ=self.VV8wHe, png=self.png_usb))
  self.l.setList(self.list)
  self.VVwZ5z()
  if selItem is not None:
   i = 0
   self.moveToIndex(0)
   for x in self.list:
    p = x[0][0]
    if isinstance(p, eServiceReference): p = p.getPath()
    if p == selItem: self.moveToIndex(i)
    i += 1
 def VVbpXR(self):
  return self.current_directory
 def VVdbmt(self):
  if self.getSelection() is None:
   return False
  return self.getSelection()[1]
 def VVrNA2(self):
  return self.VVolBI() and self.VVbpXR()
 def VVolBI(self):
  return self.list[0][1][7] in (self.VV2eDT, self.VVUfaS)
 def descent(self):
  if self.getSelection() is None:
   return
  self.VVb5JY(self.getSelection()[0], self.current_directory)
 def VV7KMN(self):
  if self.getSelection() is None:
   return None
  x = self.getSelection()[0]
  if isinstance(x, eServiceReference):
   x = x.getPath()
  return x
 def execBegin(self):
  harddiskmanager.on_partition_list_change.append(self.VVd2qI)
 def execEnd(self):
  harddiskmanager.on_partition_list_change.remove(self.VVd2qI)
 def VVd2qI(self, action, device):
  self.VVu5ID()
  if self.current_directory is None:
   self.VVbc1I()
 def VVbc1I(self):
  tDict = {}
  for row in self.list:
   if row[2][6]:
    tDict[row[0][0]] = 1
  self.VVb5JY(self.current_directory, self.VV7KMN())
  isSel = 0
  if tDict:
   for row in self.list:
    if tDict.get(row[0][0], 0):
     row[2] = list(row[2])
     row[2][6] = row[2][7] = self.multiSelect_color
     row[2] = tuple(row[2])
     isSel = 1
   self.l.setList(self.list)
  return isSel
 def VVJLcG(self):
  mode = CFG.browserSortMode.getValue()
  mix  = CFG.browserSortMix.getValue()
  sAZ, sZA, s09, s90, sNO, sON = "A > Z", "Z > A", "0 > 9", "9 > 0", "New > Old", "Old > New"
  if mode == self.VVyGN7 : nameAlpMode, nameAlpTxt = self.VVr5f1, sZA
  else       : nameAlpMode, nameAlpTxt = self.VVyGN7, sAZ
  if mode == self.VV5iqA : nameNumMode, nameNumTxt = self.VVgyFx, s90
  else       : nameNumMode, nameNumTxt = self.VV5iqA, s09
  if mode == self.VV8kbc : dateMode, dateTxt = self.VVzy1d, sON
  else       : dateMode, dateTxt = self.VV8kbc, sNO
  if mode == self.VV78Sa : typeMode, typeTxt = self.VVs8tJ, sZA
  else       : typeMode, typeTxt = self.VV78Sa, sAZ
  if   mode in (self.VVyGN7, self.VVr5f1): txt = "Name (%s)" % (sAZ if mode == self.VVyGN7 else sZA)
  elif mode in (self.VV5iqA, self.VVgyFx): txt = "Name (%s)" % (s09 if mode == self.VVyGN7 else s90)
  elif mode in (self.VV8kbc, self.VVzy1d): txt = "Date (%s)" % (sNO if mode == self.VV8kbc else sON)
  elif mode in (self.VV78Sa, self.VVs8tJ): txt = "Type (%s)" % (sAZ if mode == self.VV78Sa else sZA)
  if mix:
   txt += " .. Mixed"
  return nameAlpMode, nameAlpTxt, nameNumMode, nameNumTxt, dateMode, dateTxt, typeMode, typeTxt, "Cur = by %s" % txt
 def VVwZ5z(self, mode=None, isMix=False, isNum=False):
  if not mode is None:
   FFdEZ4(CFG.browserSortMode, mode)
   FFdEZ4(CFG.browserSortMix, isMix)
  if self.list:
   if self.VVolBI() : item0, topRow = 1, self.list[0]
   else    : item0, topRow = 0, None
   mode = CFG.browserSortMode.getValue()
   isMix = CFG.browserSortMix.getValue()
   if mode in (self.VVyGN7, self.VVr5f1):
    rev = True if mode == self.VVr5f1 else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: x[1][7]         , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], x[1][7]), reverse=rev)
   elif mode in (self.VV5iqA, self.VVgyFx):
    rev = True if mode == self.VVgyFx else False
    self.list = sorted(self.list[item0:], key=FFDgxV(BF(self.VVkIbN, isMix, rev)), reverse=rev)
   elif mode in (self.VV8kbc, self.VVzy1d):
    rev = True if mode == self.VVzy1d else False
    self.list = sorted(self.list[item0:], key=FFDgxV(BF(self.VVGE2c, isMix)), reverse=rev)
   else:
    rev = True if mode == self.VVs8tJ else False
    if isMix: self.list = sorted(self.list[item0:], key=lambda x: os.path.splitext(x[1][7])[1]            , reverse=rev)
    else : self.list = sorted(self.list[item0:], key=lambda x: (x[0][1] if rev else not x[0][1], os.path.splitext(x[1][7])[1], x[1][7]) , reverse=rev)
   if topRow:
    self.list.insert(0, topRow)
   self.l.setList(self.list)
 def VVkIbN(self, mix, rev, p1, p2):
  dir1, name1 = p1[0][1], p1[1][7]
  dir2, name2 = p2[0][1], p2[1][7]
  if mix:
   return FFAyBN(name1.lower(), name2.lower())
  else:
   if rev: dir1, dir2 = dir2, dir1
   return FFtF9Z(dir2, dir1) or FFAyBN(name1, name2)
 def VVGE2c(self, mix, p1, p2):
  dir1 = p1[0][1]
  dir2 = p2[0][1]
  if mix or dir1 == dir2:
   path1 = "" if dir1 else self.current_directory
   path2 = "" if dir2 else self.current_directory
   try:
    stat1 = os.stat(path1 + p1[0][0])
    stat2 = os.stat(path2 + p2[0][0])
    if mix : return FFtF9Z(stat2.st_ctime, stat1.st_ctime)
    else : return FFtF9Z(dir2, dir1) or FFtF9Z(stat2.st_ctime, stat1.st_ctime)
   except:
    pass
  return 0
class CCrMdZ(Screen):
 def __init__(self, session, defFG="", defBG="", onlyBG=False):
  self.skin, self.skinParam = FFRBRO(VVdCmB, 900, 700, 35, 10, 14, "#22333333", "#22333333", 30, barHeight=40)
  self.session  = session
  self.onlyBG   = onlyBG
  self.Title   = "Color"
  self.TOTAL_ROWS  = 6
  self.TOTAL_COLS  = 8
  self.VVarfR   = []
  self.curRow   = 0
  self.curCol   = 0
  self.isBgMode  = True
  self.defFG   = self.VVgx8n(defFG, "#00FFFFFF")
  self.defBG   = self.VVgx8n(defBG, "#11000000")
  self.transp   = int(self.defBG[1:3], 16)
  self.colors   = (   ("FFFFFF", "FFC0C0", "FFE0C0", "FFFFC0", "C0FFC0", "C0FFFF", "C0C0FF", "FFC0FF")
        , ("E0E0E0", "FF8080", "FFC080", "FFFF80", "80FF80", "80FFFF", "8080FF", "FF80FF")
        , ("C0C0C0", "FF0000", "FF8000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF")
        , ("808080", "C00000", "C04000", "C0C000", "00C000", "00C0C0", "0000C0", "C000C0")
        , ("404040", "800000", "804000", "808000", "008000", "008080", "000080", "800080")
        , ("000000", "400000", "804040", "404000", "004000", "004040", "000040", "400040")
        )
  FFmmH7(self, self.Title)
  self["keyRed"].show()
  FFR9Qm(self["keyGreen"] , "< > Transp.")
  FFR9Qm(self["keyYellow"], "Foreground")
  FFR9Qm(self["keyBlue"] , "Background")
  if self.onlyBG:
   self["keyYellow"].hide()
   self["keyBlue"].hide()
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    self["myColor%d%d" % (row, col)] = Label()
  self["myColorPtr"] = Label()
  self["myColorTst"] = Label("This is a test message.\n0123456789")
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : self.VVpwLM     ,
   "green"   : self.VVpwLM     ,
   "yellow"  : BF(self.VV8VS4, False)  ,
   "blue"   : BF(self.VV8VS4, True)  ,
   "up"   : self.VV09f2       ,
   "down"   : self.VVVvF4      ,
   "left"   : self.VVn01Q      ,
   "right"   : self.VVbYcO      ,
   "last"   : BF(self.VVK2UY, -5) ,
   "next"   : BF(self.VVK2UY, 5) ,
   "cancel"  : BF(self.close, None, None)
  }, -1)
  self.onShown.append(self.VV0wap)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    FFWN9Z(self["myColor%d%d" % (row, col)], "#11%s" % self.colors[row][col])
  c = "#11333333"
  FFWN9Z(self["keyRed"] , c)
  FFWN9Z(self["keyGreen"] , c)
  self.VVKp5G()
  self.VV3j0h()
  FFHNWi(self["myColorTst"], self.defFG)
  FFWN9Z(self["myColorTst"], self.defBG)
 def VVgx8n(self, color, defColor):
  color = color.upper()
  span = iSearch(r"([#][a-fA-F0-9]{8})", color, IGNORECASE)
  if span : return color
  else : return defColor
 def VV3j0h(self):
  for row in range(self.TOTAL_ROWS):
   for col in range(self.TOTAL_COLS):
    color = self.colors[row][col]
    found = False
    if self.isBgMode:
     if self.defBG[3:] == self.colors[row][col]:
      found = True
    else:
     if self.defFG[3:] == self.colors[row][col]:
      found = True
    if found:
     self.curRow = row
     self.curCol = col
     self.VVw9aX(0, 0)
     return
 def VVpwLM(self):
  self.close(self.defFG, self.defBG)
 def VV09f2(self): self.VVw9aX(-1, 0)
 def VVVvF4(self): self.VVw9aX(1, 0)
 def VVn01Q(self): self.VVw9aX(0, -1)
 def VVbYcO(self): self.VVw9aX(0, 1)
 def VVw9aX(self, row, col):
  self.curRow += row
  self.curCol += col
  if   self.curRow > self.TOTAL_ROWS -1 : self.curRow = 0
  elif self.curRow < 0     : self.curRow = self.TOTAL_ROWS - 1
  if   self.curCol > self.TOTAL_COLS -1 : self.curCol = 0
  elif self.curCol < 0     : self.curCol = self.TOTAL_COLS - 1
  color = self.VV8Y2J()
  self["keyRed"].setText(color)
  if self.isBgMode: self.defBG = color
  else   : self.defFG = color
  gap = int(self.skinParam["marginLeft"] / 2)
  pos = self["myColor%d%d" % (self.curRow, self.curCol)].getPosition()
  self["myColorPtr"].instance.move(ePoint(pos[0] - gap - 2, pos[1] - gap - 2))
  self.VVpIcZ()
 def VVKp5G(self):
  self["myTitle"].setText("  %s %s" % ("Background" if self.isBgMode else "Foreground", self.Title))
 def VVpIcZ(self):
  color = self.VV8Y2J()
  if self.isBgMode: FFWN9Z(self["myColorTst"], color)
  else   : FFHNWi(self["myColorTst"], color)
 def VV8VS4(self, isBg):
  if not self.onlyBG:
   self.isBgMode = isBg
   self.VVKp5G()
   self.VV3j0h()
 def VVK2UY(self, val):
  self.transp += val
  if   self.transp > 255 : self.transp = 255
  elif self.transp < 0 : self.transp = 0
  self. VVw9aX(0, 0)
 def VVucKk(self):
  return hex(self.transp)[2:].zfill(2)
 def VV8Y2J(self):
  return ("#%s%s" % (self.VVucKk(), self.colors[self.curRow][self.curCol])).upper()
class CC4K9R(Screen):
 def __init__(self, session):
  self.skin, self.skinParam = FFRBRO(VVAjlU, 1860, 1030, 20, 20, 30, "#33002233", "#33002233", 25, topRightBtns=2)
  self.session   = session
  self.timerUpdate  = eTimer()
  self.timerEndText  = eTimer()
  self.timerSubtLines  = eTimer()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  self.subtList   = []
  self.lastSubtInfo  = ""
  self.lastSubtFile  = ""
  self.lastSubtEnc  = ""
  self.settingShown  = False
  self.CursorPos   = 0
  self.Title    = "Subtitle Settings"
  self.diac    = u"\u0610\u0611\u0612\u0613\u0614\u0615\u0616\u0617\u0618\u0619\u061a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed"
  FFmmH7(self, title="%s%s%s" % (self.Title, " " * 10, FFGB9z("Change values with Up , Down, < , 0 , >", VVGb6D)))
  self["mySubtCover"] = Label()
  self.ctrlBtns = ("keyRed", "keyGreen", "keyYellow", "keyBlue")
  subj = ("Reset All", "Save", "Reset Delay", "Pick Line")
  for i, name in enumerate(self.ctrlBtns):
   self[name] = Label(subj[i])
  self["mySubtCursor"] = Label()
  subj = ("Delay", "BG Trans %", "Text Color", "Text Font", "Text Size", "Alignment", "Shadow Color", "Shadow Size", "Posision")
  self.settingLabels = ["Del", "BGTr", "TxtFg", "TxtFnt", "TxtSiz", "Align", "ShadFg", "ShadSiz", "Pos"]
  self.settingLabels1 = list(self.settingLabels)
  for i, name in enumerate(self.settingLabels):
   self.settingLabels[i]  = "mySubt%s"   % name
   self.settingLabels1[i] = "mySubt%s1"  % name
   self[self.settingLabels[i]]  = Label(subj[i])
   self[self.settingLabels1[i]] = Label(subj[i])
  self["mySubtFr"] = Label()
  for i in range(3): self["mySubt%d"  % i] = Label()
  for i in range(4): self["mySubtSep%d" % i] = Label()
  self["myAction"] = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"  : self.VVxCTS      ,
   "cancel" : self.VVunSf      ,
   "info"  : self.VV11tR    ,
   "red"  : self.VVBPFt  ,
   "green"  : self.VVac6v   ,
   "yellow" : BF(self.VVJABm, 0)  ,
   "blue"  : self.VVphkp    ,
   "menu"  : self.VVV1Vk      ,
   "left"  : self.VVn01Q      ,
   "right"  : self.VVbYcO      ,
   "last"  : self.VVPIlq     ,
   "next"  : self.VVU4Ou     ,
   "0"   : self.VVzOzv    ,
   "up"  : self.VV09f2       ,
   "down"  : self.VVVvF4      ,
   "pageUp" : BF(self.VVVfhL, True) ,
   "pageDown" : BF(self.VVVfhL, False) ,
   "chanUp" : BF(self.VVVfhL, True) ,
   "chanDown" : BF(self.VVVfhL, False) ,
   "play"  : BF(self.VV2fBl, "pause")  ,
   "pause"  : BF(self.VV2fBl, "pause")  ,
   "playPause" : BF(self.VV2fBl, "pause")  ,
   "stop"  : BF(self.VV2fBl, "pause")  ,
   "audio"  : BF(self.VV2fBl, "audio")  ,
   "subtitle" : BF(self.VV2fBl, "subtitle") ,
   "rewind" : BF(self.VV2fBl, "rewind" ) ,
   "forward" : BF(self.VV2fBl, "forward" ) ,
   "rewindDm" : BF(self.VV2fBl, "rewindDm") ,
   "forwardDm" : BF(self.VV2fBl, "forwardDm")
  }, -1)
  self.VV5TUI()
  self.onShown.append(self.VV0wap)
  self.onClose.append(self.VVrUGk)
 def VV5TUI(self):
  lst = []
  for fil in FFzSvJ(resolveFilename(SCOPE_FONTS), "*.[tToO][tT][fF]"):
   name = os.path.splitext(os.path.basename(fil))[0]
   lst.append((fil, name))
  if lst:
   lst.sort(key=lambda x: x[1].lower())
   default = CFG.subtTextFont.default
   if default == VVW5nC:
    for path, name in lst:
     if "almateen" in name.lower():
      default = name
      break
   CFG.subtTextFont = ConfigSelection(default=default, choices=lst)
 def VV0wap(self):
  self.onShown.remove(self.VV0wap)
  FFHLqT(self)
  FFj9eW(self)
  for i in range(3):
   self["mySubt%d" % i].hide()
  self.VVcOCD()
  self.VV9MEA()
  self.VVLUJQ()
 def VVrUGk(self):
  self.timerUpdate.stop()
  self.timerEndText.stop()
 def VVGSIK(self):
  self.settingShown = True
  for name in self.ctrlBtns: self[name].show()
  for name in self.settingLabels : self[name].show()
  for name in self.settingLabels1: self[name].show()
  for i in range(4): self["mySubtSep%d" % i].show()
  self["myTitle"].show()
  self["mySubtFr"].show()
  FFWN9Z(self["myBody"], "#33002233")
  self["keyMenu"].show()
  self["keyInfo"].show()
  self["mySubtCover"].hide()
  self.VV0eXx()
 def VVcOCD(self):
  self.settingShown = False
  for name in self.ctrlBtns: self[name].hide()
  for name in self.settingLabels : self[name].hide()
  for name in self.settingLabels1: self[name].hide()
  for i in range(4): self["mySubtSep%d" % i].hide()
  self["myTitle"].hide()
  self["mySubtFr"].hide()
  FFWN9Z(self["myBody"], "#ff000000")
  self["keyMenu"].hide()
  self["keyInfo"].hide()
  self["mySubtCover"].show()
 def VVxCTS(self):
  if self.settingShown:
   confItem = self.VV6lc4()[self.CursorPos]
   title = self[self.settingLabels[self.CursorPos]].getText()
   lst = confItem.choices.choices
   VVZJ87 = []
   if isinstance(lst[0], tuple):
    for item in lst: VVZJ87.append((item[1], item[0]))
   else:
    for item in lst: VVZJ87.append((item, item))
   VV4EHV = FFYySC(self, self.VVAvFN, VVZJ87=VVZJ87, width=700, title=title, VVDlGi="#33221111", VVaSSM="#33110011")
   VV4EHV.VVCLkK(confItem.getText())
  else:
   self.close("subtExit")
 def VVAvFN(self, item=None):
  if item:
   self.VV6lc4()[self.CursorPos].setValue(item)
   self.VV0eXx()
   self.VV9MEA()
   self.VVHxjZ(True)
 def VVunSf(self):
  for confItem in self.VV6lc4():
   if confItem.isChanged():
    FFNKVM(self, BF(self.VVzB2c, cbFnc=self.VVFXAN), "Save Changes ?", callBack_No=self.VV3LQu, title=self.Title)
    break
  else:
   self.VVFXAN()
 def VVFXAN(self):
   if self.settingShown: self.VVcOCD()
   else    : self.close("subtExit")
 def VVV1Vk(self):
  if self.settingShown: self.VV6Hlx()
  else    : self.VVGSIK()
 def VVn01Q(self): self.VV14FI(-1)
 def VVbYcO(self): self.VV14FI(1)
 def VV14FI(self, pos):
  if self.settingShown:
   self.CursorPos += pos
   if   self.CursorPos > len(self.settingLabels) - 1: self.CursorPos = 0
   elif self.CursorPos < 0        : self.CursorPos = len(self.settingLabels) - 1
   inst = self[self.settingLabels[self.CursorPos]].instance
   left = inst.position().x() - 5
   inst = self["mySubtCursor"].instance
   inst.move(ePoint(left, int(inst.position().y())))
  else:
   posVal, durVal = self.VVoxzH()
   if pos == -1: ndx = self.VVN17N(posVal)
   else  : ndx = self.VVmZY3(posVal)
   if   ndx < 0      : FF5uKN(self, "Not found" , 500)
   elif ndx == 0      : FF5uKN(self, "First line", 500)
   elif ndx == len(self.subtList) - 1 : FF5uKN(self, "Last line" , 500)
   else:
    capNum, frmSec, toSec, subtLines = self.subtList[ndx]
    delay, color, allow = self.VV4WRY(frmSec)
    if allow:
     self.VVJABm(delay, True)
     self.VVHxjZ(force=True)
     CC03RI(self.session, "Changed Delay to %d sec" % delay, timeout=500, fonSize=35)
    else:
     FF5uKN(self, "Delay out of range", 800)
 def VVVfhL(self, isUp):
  self.close("subtZapUp" if isUp else "subtZapDn")
 def VV2fBl(self, reason):
  if not self.settingShown:
   self.close(reason)
 def VVPIlq(self) : self.VVaiW7(5)
 def VVU4Ou(self) : self.VVaiW7(6)
 def VVzOzv(self) : self.VVaiW7(-1)
 def VV09f2(self):
  if self.settingShown: self.VVaiW7(1)
  else    : self.VVVfhL(True)
 def VVVvF4(self):
  if self.settingShown: self.VVaiW7(0)
  else    : self.VVVfhL(False)
 def VVaiW7(self, direction):
  if self.settingShown:
   confItem = self.VV6lc4()[self.CursorPos]
   if direction == -1:
    confItem.setValue(confItem.default)
   else:
    if direction in (0, 1) and confItem in (CFG.subtTextFg, CFG.subtTextFont, CFG.subtTextAlign, CFG.subtShadowColor, CFG.subtVerticalPos):
     direction = 0 if direction == 1 else 1
    confItem.handleKey(direction)
   if confItem is CFG.subtTextAlign:
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    for i in range(3):
     inst = self["mySubt%d" % i].instance
     w   = inst.calculateSize().width() + 50
     if   align == "0" : left = 0
     elif align == "2" : left = boxWidth - w
     else    : left = int((getDesktop(0).size().width() - w) / 2.0)
     inst.move(ePoint(left, int(inst.position().y())))
   self.VV0eXx()
   self.VV9MEA()
   self.VVHxjZ(True)
 def VV6lc4(self):
  return (  CFG.subtDelaySec
    , CFG.subtBGTransp
    , CFG.subtTextFg
    , CFG.subtTextFont
    , CFG.subtTextSize
    , CFG.subtTextAlign
    , CFG.subtShadowColor
    , CFG.subtShadowSize
    , CFG.subtVerticalPos)
 def VV3LQu(self):
  for confItem in self.VV6lc4(): confItem.cancel()
  self.VV0eXx()
  self.VV9MEA()
  self.VVcOCD()
 def VVBPFt(self):
  if self.settingShown:
   FFNKVM(self, self.VVighY, "Reset Subtitle Settings to default ?", title=self.Title)
 def VVighY(self):
  for confItem in self.VV6lc4(): confItem.setValue(confItem.default)
  self.VVzB2c()
  self.VV0eXx()
  self.VV9MEA()
 def VVJABm(self, delay, force=False):
  if self.settingShown or force:
   FFdEZ4(CFG.subtDelaySec, delay)
   self.VV9lyK()
   self.VV0eXx()
   self.VV9MEA()
   if self.settingShown:
    FF5uKN(self, 'Reset to "0"', 800, isGrn=True)
 def VVac6v(self):
  if self.settingShown:
   self.VVzB2c()
   self.VVcOCD()
 def VVzB2c(self, cbFnc=None):
  for confItem in self.VV6lc4(): confItem.save()
  configfile.save()
  self.VV9lyK()
  FF5uKN(self, "Saved", 1000, isGrn=True)
  if cbFnc:
   cbFnc()
 def VV0eXx(self):
  cfgLst = self.VV6lc4()
  for i, name in enumerate(self.settingLabels1):
   self[name].setText(str(cfgLst[i].getText()))
 def VV9MEA(self):
  path = CFG.subtTextFont.getValue()
  if fileExists(path):
   fnt = "AJP_Subtitle"
   FFJ9zu(path, fnt, isRepl=1)
  else:
   fnt = VVR8AG
  lineH = 0
  top = self["mySubt0"].instance.position().y()
  bg = int(FF6NMP(CFG.subtBGTransp.getValue(), 0, 100, 0, 255))
  try:
   for i in range(3):
    obj = self["mySubt%d" % i]
    inst = obj.instance
    bodyFontSize = CFG.subtTextSize.getValue()
    if CFG.subtTextFg.getValue().startswith("#"):
     FFHNWi(obj, CFG.subtTextFg.getValue())
    inst.setFont(gFont(fnt, bodyFontSize))
    FFWN9Z(obj, "#%0.2X000000" % bg)
    inst.setBorderColor(parseColor(CFG.subtShadowColor.getValue()))
    inst.setBorderWidth(int(CFG.subtShadowSize.getValue()))
    lineH = FFdrU1(bodyFontSize, 0.18)
    inst.resize(eSize(*(int(inst.size().width()), lineH)))
    if i > 0:
     inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
   for i in range(1, 4):
    inst = self["mySubtSep%d" % i].instance
    inst.move(ePoint(int(inst.position().x()), int(top + lineH * i + i * 1 )))
  except:
   pass
  inst = self["mySubt2"].instance
  winH = inst.position().y() + inst.size().height() + 2
  winW = self.instance.size().width()
  self.instance.resize(eSize(*(int(winW), int(winH))))
  y = int(FF6NMP(CFG.subtVerticalPos.getValue(), 0, 100, 0, FFwz8B()[1] - winH))
  self.instance.move(ePoint(int(self.instance.position().x()), y))
  FFYIKB(self, winW, winH)
 def VV11tR(self):
  sp = "    "
  txt  = "%s\n"   % FFGB9z("Subtitle File:", VVUVAI)
  txt += sp + "%s\n\n" % self.lastSubtFile
  txt += "%s\n"     % FFGB9z("Subtitle Settings:", VVUVAI)
  txt += sp + "Encoding\t: %s\n" % (self.lastSubtEnc or "Default")
  txt += sp + "Delay\t: %s sec\n" % CFG.subtDelaySec.getValue()
  if self.subtList:
   posVal, durVal = self.VVoxzH()
   capNum1, frmSec1, toSec1, subtLines1 = self.subtList[0]
   capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
   time1 = FF3Odj(frmSec1)
   time2 = FF3Odj(toSec2)
   txt += "\n"
   txt += "%s\n"       % FFGB9z("Timing:", VVUVAI)
   txt += sp + "Captions\t: %s - %s\n"  % (capNum1, capNum2)
   txt += sp + "Subt. Time\t: %s - %s\n" % (time1, time2)
   txt += sp + "Event Dur.\t: %s\n"  % FF3Odj(durVal)
   txt += sp + "Progress\t: %s\n" % FF3Odj(posVal)
   if posVal > toSec2: txt += sp + "Remarks\t: %s\n" % FFGB9z("Subtitle end reached.", VVLbyB)
  FF90Bc(self, txt, title="Current Subtitle")
 def VVLUJQ(self, path="", delay=0, enc=""):
  FFJsIX(self, BF(self.VVvqfL, path=path, delay=delay, enc=enc), "Checking Subtitle ...", clearMsg=False)
 def VVvqfL(self, path="", delay=0, enc=""):
  FF5uKN(self)
  try:
   self.timerUpdate.stop()
   if path:
    subtList, err = self.VVfCur(path, enc=enc)
    if err    : self.close(err)
    elif not subtList : self.close("subtInval")
    else    :
     self.subtList = subtList
     CFG.subtDelaySec.setValue(int(delay))
     self.VV0eXx()
     self.VV3nGz()
   else:
    path, delay, enc = CC4K9R.VVrMr1(self)
    if path:
     self.VVLUJQ(path=path, delay=delay, enc=enc)
    else:
     self.VV6Hlx()
  except:
   pass
 def VV3nGz(self):
  posVal, durVal = self.VVoxzH()
  if self.VVzc0T(posVal):
   return
  CC4K9R.VVUEXq(None)
  try:
   self.timerUpdate_conn = self.timerUpdate.timeout.connect(self.VVHxjZ)
  except:
   self.timerUpdate.callback.append(self.VVHxjZ)
  self.timerUpdate.start(500, False)
  try:
   self.timerEndText_conn = self.timerEndText.timeout.connect(self.VVrAKP)
  except:
   self.timerEndText.callback.append(self.VVrAKP)
  FF5uKN(self, "Subtitle started", 700, isGrn=True)
 def VVzc0T(self, posVal):
  capNum2, frmSec2, toSec2, subtLines2 = self.subtList[len(self.subtList) - 1]
  if posVal > toSec2:
   path = CC4K9R.VVBL01(self)
   FFzyFM(path)
   self.close("subtEnd")
   return True
  else:
   return False
 def VV6Hlx(self):
  c1, c2, c3, c4, c5 = "", VVUVAI, VVWOjU, VVMrXw, VVLbyB
  VVZJ87 = []
  VVZJ87.append((c1 + "Find srt Files (in all directories)"  , "allSrt"  ))
  VVZJ87.append((c1 + "Find srt Files (in Current Directory)" , "curDirSrt" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c2 + "Manual Search (with File Manager)"  , "fileMan"  ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append((c3 + "Suggest srt files (35% similar)"   , "sugSrt0.35" ))
  VVZJ87.append((c3 + "Suggest srt files (50% similar)"   , "sugSrt0.50" ))
  VVZJ87.append((c3 + "Suggest srt files (80% similar)"   , "sugSrt0.80" ))
  if self.settingShown:
   VVZJ87.append(VVoqHH)
   VVZJ87.append((c4 + "Change Subtitle File Encoding"  , "enc"   ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append((c5 + "Disable Current Subtitle"   , "disab"  ))
   VVZJ87.append(VVoqHH)
   VVZJ87.append(("Help (Keys)"        , "help"  ))
  FFYySC(self, self.VVdqEY, VVZJ87=VVZJ87, width=700, title='Find Subtitle ".srt" File', VVDlGi="#33221111", VVaSSM="#33110011")
 def VVdqEY(self, item=None):
  if item:
   if   item == "allSrt"   : self.VVMgJk(defSrt=self.lastSubtFile, mode=0)
   elif item == "curDirSrt"  : self.VVMgJk(defSrt=self.lastSubtFile, mode=1)
   elif item == "fileMan"   :
    sDir = "/"
    for path in (CFG.lastFileManFindSrt.getValue(), CFG.MovieDownloadPath.getValue(), "/media/usb/movie/", "/media/hdd/movie/", "/media/"):
     if pathExists(path):
      sDir = path
      break
    self.session.openWithCallback(self.VVhICP, BF(CCCXvS, patternMode="srt", VVMbDq=sDir))
   elif item.startswith("sugSrt") : self.VVMgJk(defSrt=self.lastSubtFile, mode=2, coeff=float(item[6:]))
   elif item == "enc":
    if self.lastSubtFile and fileExists(self.lastSubtFile) : FFJsIX(self, BF(CCqdtK.VVpZ7B, self, self.lastSubtFile, self.VVJZwq, self.lastSubtEnc or CFG.subtDefaultEnc.getValue()), title="Loading Codecs ...")
    else             : FF5uKN(self, "SRT File error", 1000)
   elif item == "disab":
    FFzyFM(CC4K9R.VVBL01(self))
    self.close("subtExit")
   elif item == "help"    : FFqsYG(self, "_help_subt", "Subtitle (Keys)")
  elif not self.settingShown:
   self.close("subtCancel")
 def VVJZwq(self, item=None):
  if item:
   FFJsIX(self, BF(self.VVLUJQ, path=self.lastSubtFile, delay=CFG.subtDelaySec.getValue(), enc=item), title="Loading Subtitle ...")
 def VVhICP(self, path):
  if path:
   FFdEZ4(CFG.lastFileManFindSrt, os.path.dirname(path))
   self.VVLUJQ(path=path)
  elif not self.settingShown:
   self.close("subtCancel")
 def VVMgJk(self, defSrt="", mode=0, coeff=0.25):
  FFJsIX(self, BF(self.VVFYRN, defSrt, mode=mode, coeff=coeff), title="Searching for srt files")
 def VVFYRN(self, defSrt="", mode=0, coeff=0.25):
  if mode == 1:
   srtList = CC4K9R.VVjkyT(self)
   srtList.sort()
   title = "Subtitle Files (from Current Path)"
  else:
   srtList = FFnAC3('find / %s \( -iname "*.srt" \) | grep -i "\.srt"' % (FFEZzf(1)))
   if srtList:
    srtList.sort()
    if mode == 2:
     title = "Subtitle Files (with Similar Names)"
     srtList, err = self.VVQ8lV(srtList, coeff)
     if err:
      if self.settingShown: FFzLBa(self, err, 1500)
      else    : self.close(err)
      return
    else:
     title = "Subtitle Files (all srt files)"
  if srtList:
   VVX3wb = []
   curColor = "#f#0000FF00#"
   for path in srtList:
    fName, Dir = os.path.basename(path), FF1vNj(os.path.dirname(path))
    if defSrt == Dir + fName:
     fName, Dir = curColor + fName, curColor + Dir
    VVX3wb.append((fName, Dir))
   VVwmV1  = ("Select"    , self.VV9F4Q     , [])
   VV0xpR = self.VVRh8x
   VVs5AA = (""     , self.VV0iKT       , [])
   VVotuX = (""     , BF(self.VV5VRO, defSrt, False) , [])
   VVX66G = ("Find Current File" , BF(self.VV5VRO, defSrt, True) , [])
   header   = ("File" , "Directory" )
   widths   = (60  , 40   )
   FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVhAo0=widths, VVTFXq=28, VVwmV1=VVwmV1, VV0xpR=VV0xpR, VVs5AA=VVs5AA, VVotuX=VVotuX, VVX66G=VVX66G, lastFindConfigObj=CFG.lastFindSubtitle
     , VVDlGi="#11002222", VVaSSM="#33001111", VVzgHY="#33001111", VVqSOL="#11ffff00", VVkUYa="#11445544", VVivoO="#22222222", VVdjpa="#11002233")
  elif self.settingShown : FFzLBa(self, "Not found", 1500)
  else     : self.close("subtNoSrt")
 def VVRh8x(self, VVxBfP):
  VVxBfP.cancel()
  if not self.settingShown:
   self.close("subtCancel")
 def VV0iKT(self, VVxBfP, title, txt, colList):
  fName, Dir = colList
  FF90Bc(VVxBfP, "%s\n\n%s%s" % (FFGB9z("Path:", VVUVAI), Dir, fName), title=title)
 def VV5VRO(self, path, VV70Sp, VVxBfP, title, txt, colList):
  for ndx, row in enumerate(VVxBfP.VVlHja()):
   if path == row[1].strip() + row[0].strip():
    VVxBfP.VVYNxS(ndx)
    break
  else:
   if VV70Sp:
    FF5uKN(VVxBfP, "Not in list !", 1000)
 def VV9F4Q(self, VVxBfP, title, txt, colList):
  VVxBfP.cancel()
  path = "%s%s" % (colList[1].strip(), colList[0].strip())
  self.VVLUJQ(path=path)
 def VVQ8lV(self, srtList, coeff):
  lst = []
  err = ""
  serv = self.session.nav.getCurrentlyPlayingServiceReference()
  if serv and not serv.getPath():
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCvWMS.VVMkbO(self)
  else:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(self)
   evName = os.path.splitext(os.path.basename(chName))[0]
  if evName:
   if evName and CFG.epgLangTitle.getValue():
    CCvWMS.VVRbBu(evName, "en")[0] or evName
   lst, err = CC4K9R.VVBvy1(evName, srtList, 50, coeff)
   if not err and not lst: err = "No Similar Names !"
  else:
   err = "No event Name !"
  return lst, err
 def VVfCur(self, path, enc=None):
  if enc and CCqdtK.VVpAZI(path, enc)      : enc = enc
  elif CCqdtK.VVpAZI(path, CFG.subtDefaultEnc.getValue()): enc = CFG.subtDefaultEnc.getValue()
  else                   : enc = None
  if not fileExists(path):
   return [], "File not found"
  if (FFqLWj(path) > 1024 * 700):
   return [], "File too big"
  frmSec = toSec = bold = italic = under = 0
  capNum  = ""
  capFound = True
  color  = ""
  subtLines = []
  subtList = []
  lines  = FFZQjt(path, encLst=enc)
  lastNdx  = len(lines) - 1
  for ndx, line in enumerate(lines):
   line = str(line).strip()
   if line:
    if line.isdigit():
     capNum = line
    else:
     span = iSearch(r'(\d{2}:\d{2}:\d{2},\d{3})\s*\-->\s*(\d{2}:\d{2}:\d{2},\d{3})', line, IGNORECASE)
     if span:
      p  = list(map(int, span.group(1).replace(",", ":").split(":")))
      frmSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      p  = list(map(int, span.group(2).replace(",", ":").split(":")))
      toSec = p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 1000.0
      subtLines = []
     else:
      span = iSearch(r'<font color="(.+)">(.+)', line, IGNORECASE)
      if span:
       color = self.VVl0xW(span.group(1))
       line = span.group(2)
      if "<b>" in line: bold = 1
      if "<i>" in line: italic = 1
      if "<u>" in line: under = 1
      line = line.replace("</font>", "").replace("</b>", "").replace("</i>", "").replace("</u>", "")
      line = line.replace("<b>", "").replace("<i>", "").replace("<u>", "")
      span = iSearch(r"{\\a\d}(.+)", line, IGNORECASE)
      if span:
       line = span.group(1)
      line = self.VVl4J3(line)
      subtLines.append((line.strip(), color, bold, italic, under))
      if ndx == lastNdx and subtList and (toSec - frmSec) > 0 and not subtList[len(subtList) - 1] == (capNum, frmSec, toSec, subtLines):
       subtList.append((capNum, frmSec, toSec, subtLines))
   else:
    if toSec > frmSec and subtLines:
     subtList.append((capNum, frmSec, toSec, subtLines))
    frmSec = toSec = bold = italic = under = 0
    capNum  = ""
    color  = ""
    subtLines = []
  if subtList:
   self.lastSubtFile = path
   self.lastSubtEnc  = enc
   self.VV9lyK()
  return subtList, ""
 def VVl4J3(self, line):
  line = line.replace(u"\u202A", "")
  line = line.replace(u"\u202B", "")
  line = line.replace(u"\u202C", "")
  for char in line:
   if 0x600 <= ord(char) <= 0x6FF and char in self.diac:
    line = line.replace(char, "")
  line = line.replace("\r", "..").replace("\n", "..")
  return str(line)
 def VVl0xW(self, color):
  lst = { "black": "#000000", "blue": "#0000ff", "brown":"#a52a2a", "cyan":"#00ffff", "darkblue": "#0000a0", "gray":"#808080", "green":"#008000", "grey": "#808080", "lightblue":"#add8E6", "lime":"#00ff00", "magenta":"#ff00ff", "maroon":"#800000", "olive":"#808000", "orange":"#ffa500", "purple":"#800080", "red":"#ff0000", "silver":"#c0c0c0", "white":"#ffffff", "yellow":"#ffff00"}
  code = lst.get(color.lower(), "")
  if code:
   return code
  else:
   span = iSearch(r"(#[A-Fa-f0-9]{6})", color, IGNORECASE)
   if span : return span.group(1)
   else : return ""
 def VV9lyK(self):
  path = CC4K9R.VVBL01(self)
  if path:
   try:
    with open(path, "w") as f:
     f.write("srt=%s\n" % self.lastSubtFile)
     f.write("delay=%s\n" % CFG.subtDelaySec.getValue())
     if self.lastSubtEnc:
      f.write("enc=%s\n" % self.lastSubtEnc)
   except:
    pass
 def VVHxjZ(self, force=False):
  posVal, durVal = self.VVoxzH()
  if self.VVzc0T(posVal):
   return
  curIndex = self.VV6gVW(posVal)
  if curIndex < 0:
   return
  txtDur = 0
  if posVal:
   capNum, frmSec, toSec, subtLines = self.subtList[curIndex]
   if force or not self.lastSubtInfo == subtLines:
    self.lastSubtInfo = subtLines
    settingColor = ""
    if CFG.subtTextFg.getValue().startswith("#"):
     settingColor = CFG.subtTextFg.getValue()
    self.VVrAKP()
    subtLines = list(subtLines)
    l = len(subtLines)
    for i in range(3 - len(subtLines)):
     subtLines.insert(0, ("", "", 0, 0, 0))
    align = CFG.subtTextAlign.getValue()
    boxWidth= self.instance.size().width()
    txtDur = int(toSec * 1000 - frmSec * 1000)
    if txtDur > 0:
     for ndx, (line, color, bold, italic, under) in enumerate(subtLines):
      if line:
       if   bold   : newColor = "#aaffff"
       elif italic   : newColor = "#aaaaaa"
       elif under   : newColor = "#ffffaa"
       elif settingColor : newColor = settingColor
       elif color   : newColor = color
       else    : newColor = ""
       if ndx < 3:
        obj  = self["mySubt%d" % ndx]
        inst = obj.instance
        if newColor:
         FFHNWi(obj, newColor)
        obj.setText(line)
        obj.show()
        w   = inst.calculateSize().width() + 50
        inst.resize(eSize(*(w, inst.size().height())))
        if   align == "0" : left = 0
        elif align == "2" : left = boxWidth - w
        else    : left = int((getDesktop(0).size().width() - w) / 2.0)
        inst.move(ePoint(left, int(inst.position().y())))
    if txtDur > 0:
     self.timerEndText.start(txtDur, True)
 def VVoxzH(self):
  seekable, percVal, durVal, posVal, remVal, percTxt, durTxt, posTxt, remTxt = CCb9j4.VVdw0i(self)
  if not durVal and not posVal:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCvWMS.VVMkbO(self)
   if evTime and evDur:
    posVal, durVal = iTime() - evTime, evDur
  return posVal, durVal
 def VV6gVW(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if posVal > frmSec and posVal < toSec:
     return ndx
  return -1
 def VVN17N(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if toSec > posVal:
     return ndx -1
  return -1
 def VVmZY3(self, posVal):
  if posVal > 0:
   delay = CFG.subtDelaySec.getValue()
   for ndx, item in enumerate(self.subtList):
    frmSec = item[1] + delay
    toSec = item[2] + delay
    if frmSec > posVal:
     return ndx
  return -1
 def VVrAKP(self):
  for i in range(3):
   self["mySubt%d" % i].setText("")
   FFHNWi(self["mySubt%d" % i], "#00ffffff")
   self["mySubt%d" % i].hide()
 def VVphkp(self):
  FFJsIX(self, self.VV7M8m, title="Loading Lines ...")
 def VV7M8m(self):
  VVX3wb = []
  for cap, frm, to, lines in self.subtList:
   firstLine = lines[0][0] if lines else ""
   VVX3wb.append((cap, FF3Odj(frm), str(frm), firstLine))
  if VVX3wb:
   title = "Select Current Subtitle Line"
   VVxxkd  = self.VVQpHH
   VV0xpR = self.VVH04g
   VVwmV1  = ("Select"   , self.VVqrKt , [title])
   VVX66G = ("Current Line" , self.VVkzvj , [True])
   VVIrDY = ("Reset Delay" , self.VVWec5 , [])
   VVFadD = ("New Delay"  , self.VVtbhs   , [])
   header   = ("Cap" , "Time", "Time Val", "Subtitle Text" )
   widths   = (8  , 15 , 0    , 77    )
   VVFvCJ  = (CENTER , CENTER, CENTER , LEFT    )
   VVxBfP = FF1Dpj(self, None, title=title, header=header, VVarfR=VVX3wb, VVFvCJ=VVFvCJ, VVhAo0=widths, VVTFXq=28, VVxxkd=VVxxkd, VV0xpR=VV0xpR, VVwmV1=VVwmV1, VVX66G=VVX66G, VVIrDY=VVIrDY, VVFadD=VVFadD
          , VVDlGi="#33002222", VVaSSM="#33001111", VVzgHY="#33110011", VVqSOL="#11ffff00", VVkUYa="#0a334455", VVivoO="#22222222", VVdjpa="#33002233")
  else:
   FFzLBa(self, "Cannot read lines !", 2000)
 def VVQpHH(self, VVxBfP):
  self.subtLinesTable = VVxBfP
  if CFG.subtDelaySec.getValue():
   VVxBfP["keyYellow"].show()
   VVxBfP["keyYellow"].setText("Reset Delay (%s sec)" % CFG.subtDelaySec.getValue())
  else:
   VVxBfP["keyYellow"].hide()
  VVxBfP["keyBlue"].setText("New Delay: %s sec" % CFG.subtDelaySec.getValue())
  FFWN9Z(VVxBfP["keyBlue"], "#22222222")
  VVxBfP.VVByXR(BF(self.VVJLTd, VVxBfP))
  self.VVkzvj(VVxBfP, False)
  try:
   self.timerSubtLines_conn = self.timerSubtLines.timeout.connect(self.VVSAdA)
  except:
   self.timerSubtLines.callback.append(self.VVSAdA)
  self.timerSubtLines.start(1000, False)
 def VVH04g(self, VVxBfP):
  self.timerSubtLines.stop()
  self.subtLinesTable  = None
  self.subtLinesTableNdx = -1
  VVxBfP.cancel()
 def VVSAdA(self):
  if self.subtLinesTable:
   VVxBfP = self.subtLinesTable
   posVal, durVal = self.VVoxzH()
   color = "#b#11551111#"
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VV6gVW(posVal)
    if curIndex > -1:
     if self.subtLinesTableNdx > -1:
      row = VVxBfP.VVzNXU(self.subtLinesTableNdx)
      row[0] = row[0].replace(color, "")
      VVxBfP.VVr9B1(self.subtLinesTableNdx, row)
     row = VVxBfP.VVzNXU(curIndex)
     row[0] = color + row[0]
     VVxBfP.VVr9B1(curIndex, row)
     self.subtLinesTableNdx = curIndex
 def VVqrKt(self, VVxBfP, Title):
  delay, color, allow = self.VVy5m3(VVxBfP)
  if allow:
   self.VVH04g(VVxBfP)
   self.VVJABm(delay, True)
  else:
   FF5uKN(VVxBfP, "Delay out of range", 1500)
 def VVkzvj(self, VVxBfP, VV70Sp, onlyColor=False):
  if VVxBfP:
   posVal, durVal = self.VVoxzH()
   if posVal > 0:
    curTime = posVal - float(CFG.subtDelaySec.getValue())
    curIndex = self.VV6gVW(posVal)
    if curIndex > -1:
     VVxBfP.VVYNxS(curIndex)
    else:
     ndx = self.VVN17N(posVal)
     if ndx > -1:
      VVxBfP.VVYNxS(ndx)
 def VVWec5(self, VVxBfP, title, txt, colList):
  if VVxBfP["keyYellow"].getVisible():
   self.VVJABm(0, True)
   VVxBfP["keyYellow"].hide()
   self.VVkzvj(VVxBfP, False)
 def VVJLTd(self, VVxBfP):
  delay, color, allow = self.VVy5m3(VVxBfP)
  VVxBfP["keyBlue"].setText("%sNew Delay: %d sec" % (color, delay))
 def VVy5m3(self, VVxBfP):
  lineTime = float(VVxBfP.VVc6YJ()[2].strip())
  return self.VV4WRY(lineTime)
 def VV4WRY(self, lineTime):
  posVal, durVal = self.VVoxzH()
  delay, color, allow = 0, "", False
  if posVal > 0:
   val = int(round(posVal - lineTime))
   if -600 <= val <= 600: allow, color = True , VVkIQ9
   else     : allow, color = False, VVLbyB
   delay = FFgevD(val, -600, 600)
  return delay, color, allow
 def VVtbhs(self, VVxBfP, title, txt, colList):
  pass
 @staticmethod
 def VVoodB(SELF):
  path, delay, enc = CC4K9R.VVrMr1(SELF)
  return True if path else False
 @staticmethod
 def VVrMr1(SELF):
  path, delay, enc = CC4K9R.VVFJc7(SELF)
  if not path:
   path = CC4K9R.VVQmxO(SELF)
  return path, delay, enc
 @staticmethod
 def VVFJc7(SELF):
  srtCfgPath = CC4K9R.VVBL01(SELF)
  path = enc = ""
  delay = 0
  if srtCfgPath:
   if fileExists(srtCfgPath):
    lines = FFZQjt(srtCfgPath)
    for line in lines:
     line = line.strip()
     if   line.startswith("srt=") : path = line.split("=")[1].strip()
     elif line.startswith("delay=") : delay = line.split("=")[1].strip()
     elif line.startswith("enc=") : enc = line.split("=")[1].strip()
  if path and fileExists(path):
   try:
    delay = int(delay)
   except:
    pass
   return path, delay, enc
  else:
   return "", 0, ""
 @staticmethod
 def VVBL01(SELF):
  fPath, fDir, fName = CCCXvS.VV6Qx4(SELF)
  if not fPath:
   evName, evTime, evDur, evShort, evDesc, genre, PR = CCvWMS.VVMkbO(SELF)
   if evName.strip() and evTime and evDur:
    fPath = "/tmp/" + evName[:30].strip()
  if not fPath:
   refCode, decodedUrl, origUrl, iptvRef, chName, prov, state = FFGh4f(SELF)
   if chName.strip():
    fPath = "/tmp/" + chName.strip()
  if fPath: return fPath + ".ajp"
  else : return ""
 @staticmethod
 def VVQmxO(SELF):
  bestRatio = 0
  fPath, fDir, fName = CCCXvS.VV6Qx4(SELF)
  if fName:
   bestSrt = os.path.splitext(fPath)[0] + ".srt"
   if fileExists(bestSrt):
    return bestSrt
   else:
    movName = os.path.splitext(fName)[0]
    paths = CC4K9R.VVjkyT(SELF)
    bLst, err = CC4K9R.VVBvy1(movName, paths, 1, 0.3)
    if bLst:
     return bLst[0]
  return ""
 @staticmethod
 def VVjkyT(SELF):
  fPath, fDir, fName = CCCXvS.VV6Qx4(SELF)
  if pathExists(fDir):
   files = FFzSvJ(fDir, "*.srt")
   if files:
    return files
  return []
 @staticmethod
 def VVBvy1(word, paths, n=-1, cutoff=0.3):
  lst  = []
  if paths:
   try:
    from difflib import get_close_matches as iClosest
   except:
    return lst, 'Missing "difflib" library'
   if n == -1:
    n = len(paths)
   files = []
   cleanLst = ("25r", "colored", "srt", "REMUX", "AVC", "DTS", "MA", "utf8", "WEB", "DL", "NF", "EVO", "HD", "4k", "8k", "DDP5", "POWER", "WEBRip", "HDRip", "BRRip", "XviD", "HEVC", "Netflix", "MULTISUB", "MULTI", "SUB", "BluRay", "BlueRay", "BrRip", "YIFY", "YTS", "AM", "MX", "HDR", "AAC5", "mora", "AR", "EN", "English", "ARABIC")
   for ndx, p in enumerate(paths):
    fWords = os.path.splitext(os.path.basename(p))[0]
    fWords = iSub(r"([\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+)", ".", fWords)  + "."
    fWords = iSub(r"\.\d{4}\."   , ".", fWords)
    fWords = iSub(r"\.\d{3,4}(p|P)\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]\d{3}\." , ".", fWords)
    fWords = iSub(r"\.\d{1,3}bit[s]?\." , ".", fWords)
    fWords = iSub(r"\.[A-Za-z]{1,3}\d\.", ".", fWords)
    for txt in cleanLst: fWords = iSub(r"\.%s\." % txt, ".", fWords, flags=IGNORECASE)
    while ".." in fWords: fWords = fWords.replace("..", ".")
    fWords = fWords.replace(".", " ").strip()
    files.append("%d,%s" % (ndx, fWords))
   bLst = iClosest(word, files, n=n, cutoff=cutoff)
   if bLst:
    for item in bLst:
     ndx, fName = item.split(",", 1)
     lst.append(paths[int(ndx)])
  return lst, ""
 @staticmethod
 def VVcS6O():
  try:
   return InfoBar.instance.selected_subtitle
  except:
   try:
    return InfoBar.instance.__selected_subtitle
   except:
    return None
 @staticmethod
 def VVUEXq(subt):
  if subt and isinstance(subt, tuple) and len(subt) >= 4 : state = True
  else             : subt, state = None, False
  try:
   InfoBar.instance.enableSubtitle(subt)
  except:
   try:
    if state:
     InfoBar.instance.__selected_subtitle = subt
    InfoBar.instance.setSubtitlesEnable(state)
   except:
    pass
  CC4K9R.VVok3P()
 @staticmethod
 def VVok3P():
  try:
   if config.subtitles.show.value : InfoBar.instance.subtitle_window.show()
   else       : InfoBar.instance.subtitle_window.hide()
  except:
   pass
class CCUveG(ScrollLabel):
 def __init__(self, parentSELF, text="", VVcunV=True):
  ScrollLabel.__init__(self, text)
  self.VVcunV   = VVcunV
  self.long_text    = None
  self.scrollbar    = None
  self.message    = text
  self.instance    = None
  self.VViLAe  = 0
  self.curPos     = 0
  self.pageHeight    = 0
  self.pageLines    = 0
  self.column     = 0
  self.outputFileToSave  = ""
  self.parentSELF    = parentSELF
  self.isResizable   = None
  self.fontFamily    = None
  self.VVTFXq    = None
  self.parentW    = None
  self.parentH    = None
  self.wrapEnabled   = True
  parentSELF["keyRedTop"]  = Label("Menu")
  parentSELF["keyGreenTop"] = Label("Reset")
  parentSELF["keyYellowTop"] = Label("Font -")
  parentSELF["keyBlueTop"] = Label("Font +")
  parentSELF["keyRedTop1"] = Label()
  parentSELF["keyGreenTop1"] = Label()
  parentSELF["keyYellowTop1"] = Label()
  parentSELF["keyBlueTop1"] = Label()
  parentSELF["myAction"]  = ActionMap(["KeyMap_RC", "KeyMap_KeyBoard"],
  {
   "ok"   : parentSELF.close  ,
   "cancel"  : parentSELF.close  ,
   "menu"   : self.VV8KRB ,
   "green"   : self.VVHmgt ,
   "yellow"  : self.VVW91z ,
   "blue"   : self.VVCghp ,
   "up"   : self.VV9Iu6   ,
   "down"   : self.VVNeOF  ,
   "left"   : self.VV9Iu6   ,
   "right"   : self.VVNeOF  ,
   "last"   : BF(self.VVC8mV, 0) ,
   "0"    : BF(self.VVC8mV, 1) ,
   "next"   : BF(self.VVC8mV, 2) ,
   "pageUp"  : self.VVZAg3   ,
   "chanUp"  : self.VVZAg3   ,
   "pageDown"  : self.VVLZqP   ,
   "chanDown"  : self.VVLZqP
  }, -1)
 def VVlfXl(self, isResizable=True, VVbYzk=False, outputFileToSave=""):
  self.outputFileToSave = outputFileToSave
  FFHNWi(self.parentSELF["keyRedTop"], "#0055FF55" if outputFileToSave else "#00FFFFFF" )
  FFWN9Z(self.parentSELF["keyRedTop"], "#113A5365")
  FFHLqT(self.parentSELF, True)
  self.isResizable = isResizable
  if VVbYzk:
   self.long_text.setHAlign(1)
  size    = self.parentSELF.instance.size()
  self.parentW  = size.width()
  self.parentH  = size.height()
  font    = self.long_text.getFont()
  self.fontFamily  = font.family
  self.VVTFXq  = font.pointSize
  try: self.scrollbar.setBorderColor(parseColor("#11555555"))
  except: pass
  try: self.scrollbar.setForegroundColor(parseColor("#11AA8E48"))
  except: pass
  try: self.scrollbar.setBackgroundColor(parseColor("#11111111"))
  except: pass
  color = self.parentSELF.skinParam["bodyColor"]
  FFWN9Z(self, color)
 def VVgbSO(self, color):
  self.long_text.setBackgroundColor(parseColor(color))
 def applySkin(self, desktop, parent):
  import skin
  from enigma import eLabel, eSlider
  self.long_text = eLabel(self.instance)
  self.scrollbar = eSlider(self.instance)
  skin.applyAllAttributes(self.long_text, desktop, self.skinAttributes, parent.scale)
  self.pageWidth = self.long_text.size().width()
  VVNyBH  = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont())) or 30
  self.pageLines = int(self.long_text.size().height() / VVNyBH)
  margin   = int(VVNyBH / 6)
  self.pageHeight = int(self.pageLines * VVNyBH)
  self.instance.move(self.long_text.position())
  self.instance.resize(eSize(self.pageWidth, self.pageHeight + margin))
  w = 20
  self.scrollbar.move(ePoint(self.pageWidth - w, 0))
  self.scrollbar.resize(eSize(w, self.pageHeight + margin))
  self.scrollbar.setOrientation(eSlider.orVertical)
  self.scrollbar.setRange(0, 100)
  self.scrollbar.setBorderWidth(1)
  return True
 def setPos(self, pos):
  self.curPos = max(0, min(pos, self.VViLAe - self.pageHeight))
  self.long_text.move(ePoint(0, -self.curPos))
  self.VVr9g9()
 def VV9Iu6(self):
  if self.VViLAe > self.pageHeight:
   self.setPos(self.curPos - self.pageHeight)
 def VVNeOF(self):
  if self.VViLAe > self.pageHeight:
   self.setPos(self.curPos + self.pageHeight)
 def VVZAg3(self):
  self.setPos(0)
 def VVLZqP(self):
  self.setPos(self.VViLAe-self.pageHeight)
 def VVHbml(self):
  return self.VViLAe <= self.pageHeight or self.curPos == self.VViLAe - self.pageHeight
 def getText(self):
  return self.message
 def VVr9g9(self):
  try:
   vis = int(max(100 * self.pageHeight / self.VViLAe, 3))
   start = int((100 - vis) * self.curPos / (self.VViLAe - self.pageHeight))
   self.scrollbar.setStartEnd(start, start + vis)
  except:
   pass
 def setText(self, text, VV4VK0=VVP6Rb):
  old_VVHbml = self.VVHbml()
  self.message = str(text)
  if self.pageHeight:
   if len(self.message.splitlines()) < self.pageLines - 2:
    if not self.message.startswith("\n"):
     self.message = "\n" + self.message
    self.message = self.message.rstrip() + "\n"
   self.long_text.setText(self.message)
   self.VViLAe = self.long_text.calculateSize().height()
   if self.VVcunV and self.VViLAe > self.pageHeight:
    self.scrollbar.show()
    self.VVr9g9()
    w = self.parentSELF.skinParam["scrollBarW"] + 5
    pageWidth  = self.instance.size().width() - w
    self.long_text.resize(eSize(pageWidth, self.VViLAe))
    self.VViLAe = self.long_text.calculateSize().height()
    self.long_text.resize(eSize(pageWidth, self.VViLAe))
   else:
    self.scrollbar.hide()
   if   VV4VK0 == VVBTEe: self.setPos(0)
   elif VV4VK0 == VV0QS5 : self.VVLZqP()
   elif old_VVHbml    : self.VVLZqP()
 def appendText(self, text, VV4VK0=VV0QS5):
  self.setText(self.message + str(text), VV4VK0=VV4VK0)
 def VVW91z(self):
  size = int(self.long_text.getFont().pointSize * 0.8)
  if size > 5:
   self.VVu1UA(size)
 def VVCghp(self):
  size = int(self.long_text.getFont().pointSize * 1.2)
  if size < 80:
   self.VVu1UA(size)
 def VVHmgt(self):
  self.VVu1UA(self.VVTFXq)
 def VVu1UA(self, VVTFXq):
  self.long_text.setFont(gFont(self.fontFamily, VVTFXq))
  self.setText(self.message, VV4VK0=VVP6Rb)
  self.VVFhN7()
 def VVC8mV(self, align):
  self.long_text.setHAlign(align)
 def VV8KRB(self):
  VVZJ87 = []
  VVZJ87.append(("%s Wrapping" % ("Disable" if self.wrapEnabled else "Enable"), "wrap" ))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Align Left" , "left" ))
  VVZJ87.append(("Align Center" , "center" ))
  VVZJ87.append(("Align Right" , "right" ))
  if self.outputFileToSave:
   VVZJ87.append(VVoqHH)
   VVZJ87.append((FFGB9z("Save to File", VVUVAI), "save"))
  VVZJ87.append(VVoqHH)
  VVZJ87.append(("Keys (Shortcuts)", "help"))
  FFYySC(self.parentSELF, self.VV8b4b, VVZJ87=VVZJ87, title="Text Option", width=500)
 def VV8b4b(self, item=None):
  if item:
   if item == "wrap"  :
    self.wrapEnabled = not self.wrapEnabled
    self.long_text.setNoWrap(not self.wrapEnabled)
   elif item == "left"  : self.VVC8mV(0)
   elif item == "center" : self.VVC8mV(1)
   elif item == "right" : self.VVC8mV(2)
   elif item == "save"  : self.VVHTQm()
   elif item == "help"  : FFqsYG(self.parentSELF, "_help_txt", "Text Viewer (Keys)")
 def VVHTQm(self):
  title = "%s Log File" % self.outputFileToSave.capitalize()
  expPath = CFG.exportedTablesPath.getValue()
  try:
   outF = "%sAJPanel_log_%s_%s.txt" % (FF1vNj(expPath), self.outputFileToSave, FFUD38())
   with open(outF, "w") as f:
    f.write(FFxmTk(self.message))
   FF15cM(self.parentSELF, "Saved to:\n\n%s" % outF, title=title)
  except:
   FFw5OO(self.parentSELF, "Could not save to:\n\n%s" % expPath, title=title)
 def VVFhN7(self, minHeight=0):
  if self.isResizable:
   VVNyBH = int(fontRenderClass.getInstance().getLineHeight(self.long_text.getFont()))
   textH = min(self.pageHeight, VVNyBH * (len(self.message.splitlines()) + 1))
   self.resize(eSize(*(self.instance.size().width(), textH + 6)))
   diff = self.pageHeight - textH
   newH = self.parentH - diff
   if diff < 0:
    newH = self.parentH
   if minHeight > 0:
    newH = max(newH, minHeight + self.parentSELF.skinParam["titleH"] + self.parentSELF.skinParam["marginTop"] * 2 + 1)
   screenSize = getDesktop(0).size()
   self.parentSELF.instance.resize(eSize(*(self.parentW, min(self.parentH, newH))))
   self.parentSELF.instance.move(ePoint((screenSize.width() - self.parentW) // 2, (screenSize.height() - newH) // 2))
