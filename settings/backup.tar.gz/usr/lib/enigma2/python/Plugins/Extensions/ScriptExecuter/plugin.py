##
## ScriptExecuter
## by AliAbdul
## mod by crash
##
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from os import listdir
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.Screen import Screen

############################################

class ScriptExecuter(Screen):
	skin = """
	<screen position="center,center" size="700,340" title="Script Executer" >
		<widget name="list" position="center,center" size="680,320" zPosition="1" font="Regular;24" transparent="1" 
scrollbarMode="showOnDemand" />
	</screen>"""

	def __init__(self, session, args=None):
		Screen.__init__(self, session)
		self.session = session
		
		self["list"] = MenuList([])
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
		
		self.onLayoutFinish.append(self.loadScriptList)

	def loadScriptList(self):
		try:
			list = listdir("/usr/script/")
			list.sort()
			list = [x[:-3] for x in list if x.endswith('.sh')]
		except:
			list = []
		
		self["list"].setList(list)

	def run(self):
		try:
			script = self["list"].getCurrent()
		except:
			script = None
		
		if script is not None:
			title = script
			script = "/usr/script/%s.sh" % script
			
			self.session.open(Console, title, cmdlist=[script])

############################################

def main(session, **kwargs):
	session.open(ScriptExecuter)

def menu(menuid, **kwargs):
	if menuid == "camsetup":
		return [(_("Script..."), main, "ScriptExecuter", 45)]
	return []	

def Plugins(**kwargs):
    return [PluginDescriptor(name=_("Script Executor"), description=_("INFO: Script must be in /usr/script"), where = 
PluginDescriptor.WHERE_PLUGINMENU, icon="scriptexecutor.png", fnc=main),
			PluginDescriptor(name=_("Scripts"), description=_("INFO: Scripts must be in /usr/script"), where = 
PluginDescriptor.WHERE_EXTENSIONSMENU, icon="scriptexecutor.png", fnc=main)]
