wget -O /etc/tuxbox/config/SoftCam.Key http://raw.githubusercontent.com/popking159/SoftCam/master/SoftCam.Key


